package Maps

import (
	"context"
	"database/sql"
	"log"
	"net/http"
	"sync"
	"time"

	"opt360-portal-backend/db"

	"github.com/gin-gonic/gin"
)

// ─── Constants ────────────────────────────────────────────────────────────────

const (
	chQueryTimeout    = 30 * time.Second
	mysqlQueryTimeout = 30 * time.Second
)

// ─── Risk bucket mapping ──────────────────────────────────────────────────────

var riskBucketCode = map[string]string{
	"Low":      "l",
	"Medium":   "m",
	"High":     "h",
	"Critical": "c",
	"No":       "n",
}

// ─── In-memory cache ──────────────────────────────────────────────────────────

// operatorMapEntry represents a single row in the joined result set.
// It is stored as a mixed-type slice so JSON marshalling produces the
// exact [lat, lon, risk_code, operator_id] format requested.
type operatorMapEntry [4]interface{}

type operatorMapCache struct {
	mu        sync.RWMutex
	operators []operatorMapEntry
	lastBuilt time.Time
}

var mapCache = &operatorMapCache{}

// ─── Cache population ─────────────────────────────────────────────────────────

// buildMapCache fetches from both databases, joins in memory, and replaces the
// cached slice atomically.
func buildMapCache() error {
	// ── 1. Fetch latest lat/lon per operator from ClickHouse ─────────────────
	chConn, err := db.GetClickHouseDB()
	if err != nil {
		return err
	}

	chCtx, chCancel := context.WithTimeout(context.Background(), chQueryTimeout)
	defer chCancel()

	// argMax picks the lat/lon associated with the most-recent last_Updated_Date
	// for each operator in a single pass — more efficient than a self-join.
	chQuery := `
SELECT
	operator_id,
	argMaxIf(latitude,  last_Updated_Date, latitude  IS NOT NULL) AS lat,
	argMaxIf(longitude, last_Updated_Date, longitude IS NOT NULL) AS lon
FROM default.operator_center_sync
GROUP BY operator_id
`
	rows, err := chConn.Query(chCtx, chQuery)
	if err != nil {
		return err
	}
	defer rows.Close()

	type chRow struct {
		operatorID string
		lat        float64
		lon        float64
	}

	chData := make(map[string]chRow, 4096)
	for rows.Next() {
		var r chRow
		var lat, lon *float64
		if err := rows.Scan(&r.operatorID, &lat, &lon); err != nil {
			log.Printf("[MapCache] ClickHouse scan error: %v", err)
			continue
		}
		// Skip rows where lat/lon are still NULL after the argMaxIf
		if lat == nil || lon == nil {
			continue
		}
		r.lat = *lat
		r.lon = *lon
		chData[r.operatorID] = r
	}
	if err := rows.Err(); err != nil {
		return err
	}

	// ── 2. Fetch id + risk_bucket from MySQL ──────────────────────────────────
	mysqlConn, err := db.GetDB()
	if err != nil {
		return err
	}

	mysqlCtx, mysqlCancel := context.WithTimeout(context.Background(), mysqlQueryTimeout)
	defer mysqlCancel()

	mysqlRows, err := mysqlConn.QueryContext(mysqlCtx,
		"SELECT id, risk_bucket FROM opt_master WHERE risk_bucket IS NOT NULL",
	)
	if err != nil {
		return err
	}
	defer mysqlRows.Close()

	// ── 3. Join in application memory ────────────────────────────────────────
	joined := make([]operatorMapEntry, 0, len(chData))
	for mysqlRows.Next() {
		var id string
		var riskBucket sql.NullString
		if err := mysqlRows.Scan(&id, &riskBucket); err != nil {
			log.Printf("[MapCache] MySQL scan error: %v", err)
			continue
		}

		chRow, ok := chData[id]
		if !ok {
			// No matching ClickHouse record — skip
			continue
		}

		code, ok := riskBucketCode[riskBucket.String]
		if !ok {
			// Unknown / unmapped risk bucket — skip
			continue
		}

		// [latitude, longitude, risk_code, operator_id]
		joined = append(joined, operatorMapEntry{chRow.lat, chRow.lon, code, id})
	}
	if err := mysqlRows.Err(); err != nil {
		return err
	}

	// ── 4. Atomically replace cached data ────────────────────────────────────
	mapCache.mu.Lock()
	mapCache.operators = joined
	mapCache.lastBuilt = time.Now()
	mapCache.mu.Unlock()

	log.Printf("[MapCache] Rebuilt: %d operator entries", len(joined))
	return nil
}

// ─── Background refresh goroutine ────────────────────────────────────────────

// InitMapCache does an initial cache build at server startup.
// After that the cache is only refreshed by explicitly calling
// POST /operators/refresh.
func InitMapCache() {
	if err := buildMapCache(); err != nil {
		log.Printf("[MapCache] Initial build failed: %v", err)
	}
}

// ─── HTTP handlers ────────────────────────────────────────────────────────────

// GetOperatorMapData serves the cached operator map payload.
//
// GET /operators
// Response:
//
//	{
//	  "operators": [[lat, lon, "risk_code", "operator_id"], ...]
//	}
func GetOperatorMapData(c *gin.Context) {
	mapCache.mu.RLock()
	operators := mapCache.operators
	mapCache.mu.RUnlock()

	if operators == nil {
		c.JSON(http.StatusServiceUnavailable, gin.H{"error": "cache not yet populated"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"operators": operators})
}

// RefreshOperatorMapCache triggers an immediate synchronous cache rebuild and
// returns the new entry count.
//
// POST /operators/refresh
func RefreshOperatorMapCache(c *gin.Context) {
	if err := buildMapCache(); err != nil {
		log.Printf("[MapCache] Manual refresh failed: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "cache refresh failed", "detail": err.Error()})
		return
	}

	mapCache.mu.RLock()
	count := len(mapCache.operators)
	built := mapCache.lastBuilt
	mapCache.mu.RUnlock()

	c.JSON(http.StatusOK, gin.H{
		"message":    "cache refreshed",
		"count":      count,
		"last_built": built.Format(time.RFC3339),
	})
}
