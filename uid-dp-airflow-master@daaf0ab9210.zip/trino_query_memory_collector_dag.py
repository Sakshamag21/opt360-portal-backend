"""
DAG: trino_query_memory_collector
Fetches per-query peak memory from Trino REST API /v1/query on 5 coordinators.
Stores into strot.analytics_services.trino_query_memory with watermark dedup on created.
"""
import subprocess
import sys
import importlib
import threading
import traceback
import time
import requests
import mysql.connector
from datetime import datetime, timedelta, timezone
from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from strot_alert_notification import (
    alert_failure_callback,
    configure
)
configure(channel="dataplatformtesting")

IST = timezone(timedelta(hours=5, minutes=30))

# Install strot_query if not present
package = "strot_query"
try:
    importlib.import_module(package)
except ImportError:
    subprocess.check_call([
        sys.executable, "-m", "pip", "install",
        '--no-cache-dir',
        '--index-url', 'http://10.10.206.59:8080/repository/pypi-local/simple',
        '--trusted-host', '10.10.206.59',
        package
    ])
    importlib.invalidate_caches()
    globals()[package] = importlib.import_module(package)

import pandas as pd
import strot_query as sq

# ---- Configuration ----
DESTINATION_HOST = '10.10.116.75'
DEST_TABLE = 'strot.analytics_services.trino_query_memory'

# Source Trino coordinators (5 hosts including 10.10.118.24)
SOURCE_HOSTS = [
    '10.10.118.10',
    '10.10.118.24',
    '10.10.118.35',
    '10.10.116.39',
    '10.10.116.75',
]
REST_PORT = 8080
REST_USER = 'airflow_collector'

# Metastore Configuration for Lock Clearing
METASTORE_HOST = '10.10.106.159'
METASTORE_DB = 'metastore_iceberg'
METASTORE_USER = 'Data_platform_W'
METASTORE_PASSWORD = 'Dataplat_7634'


# ------------------------------------------------------------------
# Helper Functions
# ------------------------------------------------------------------

def clear_hive_locks_for_table(metastore_host, metastore_db, metastore_user,
                                metastore_password, target_db_name, target_table_name):
    """Checks and clears Hive locks for a specific table."""
    print(f"[LockCleaner] Checking locks on {target_db_name}.{target_table_name} "
          f"in {metastore_host}/{metastore_db}...")
    try:
        connection = mysql.connector.connect(
            host=metastore_host, user=metastore_user,
            password=metastore_password, database=metastore_db
        )
        cursor = connection.cursor()
        check_query = (f"SELECT HL_LOCK_EXT_ID, HL_DB, HL_TABLE, HL_LOCK_STATE "
                       f"FROM HIVE_LOCKS WHERE HL_TABLE = '{target_table_name}' "
                       f"AND HL_DB = '{target_db_name}'")
        cursor.execute(check_query)
        locks = cursor.fetchall()
        if locks:
            print(f"[LockCleaner] Found {len(locks)} stuck lock(s) for "
                  f"{target_db_name}.{target_table_name}. Clearing...")
            delete_query = (f"DELETE FROM HIVE_LOCKS WHERE HL_TABLE = '{target_table_name}' "
                            f"AND HL_DB = '{target_db_name}'")
            cursor.execute(delete_query)
            connection.commit()
            print(f"[LockCleaner] Cleared locks for {target_db_name}.{target_table_name}.")
        else:
            print(f"[LockCleaner] No locks found for {target_db_name}.{target_table_name}.")
        connection.close()
        return True
    except Exception as e:
        print(f"[LockCleaner] Error clearing locks: {e}")
        return False


def log(msg, level="INFO"):
    ts = datetime.now(IST).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    thread_name = threading.current_thread().name
    print(f"[{ts}] [{level}] [Thread={thread_name}] {msg}")


def safe_val(v):
    """Convert None to SQL NULL string, otherwise wrap in single quotes with escaping.
    Truncation happens BEFORE escaping to avoid splitting escaped quote pairs."""
    try:
        if v is None or (isinstance(v, float) and pd.isna(v)):
            return "NULL"
        if isinstance(v, (int, float)):
            return str(v)
        s = str(v)
        # Truncate FIRST (on raw string), then escape — prevents splitting '' pairs
        if len(s) > 5000:
            s = s[:5000]
            log(f"Truncated long value to 5000 chars", "WARN")
        # Escape single quotes AFTER truncation
        s = s.replace("'", "''")
        return f"'{s}'"
    except Exception as e:
        log(f"ERROR in safe_val for value {repr(v)}: {e}", "ERROR")
        return "NULL"


def mem_to_bytes(v):
    """
    Convert Trino REST API memory value to integer bytes.
    Handles: number (bytes), string like '127408B' or '5.49GB',
    or dict {'size':183, 'unit':'GB'}.
    """
    if v is None:
        return "NULL"
    if isinstance(v, (int, float)):
        return str(int(v))
    if isinstance(v, dict):
        size = v.get("size")
        unit = v.get("unit", "B")
        mult = {"B": 1, "KB": 1024, "MB": 1024**2, "GB": 1024**3, "TB": 1024**4}
        try:
            return str(int(float(size) * mult.get(unit, 1)))
        except (TypeError, ValueError):
            return "NULL"
    s = str(v).strip()
    mult = {"B": 1, "KB": 1024, "MB": 1024**2, "GB": 1024**3, "TB": 1024**4}
    for suf in ("TB", "GB", "MB", "KB", "B"):
        if s.endswith(suf):
            try:
                return str(int(float(s[:-len(suf)]) * mult[suf]))
            except ValueError:
                return "NULL"
    try:
        return str(int(float(s)))
    except ValueError:
        return "NULL"


def duration_to_ms(v):
    """
    Convert Trino duration to integer milliseconds.
    Handles: number (assume ms), string like '59.14s', '32.08m', '1.43h'.
    """
    if v is None:
        return "NULL"
    if isinstance(v, (int, float)):
        return str(int(v))
    s = str(v).strip()
    units = {"ns": 1e-6, "us": 0.001, "ms": 1, "s": 1000,
             "m": 60000, "h": 3600000, "d": 86400000}
    for suf in ("ns", "us", "ms", "s", "m", "h", "d"):
        if s.endswith(suf):
            try:
                return str(int(float(s[:-len(suf)]) * units[suf]))
            except ValueError:
                return "NULL"
    try:
        return str(int(float(s)))
    except ValueError:
        return "NULL"


def parse_trino_timestamp(ts_str):
    """
    Parse REST API timestamp and return UTC string 'YYYY-MM-DD HH:MM:SS.ffffff'.
    Handles: '2026-10-19T15:00:25.420Z', '2026-10-19T15:00:25.420+00:00',
    or naive '2026-10-19T15:00:25.420' (assumed UTC).
    No IST conversion — stores UTC consistently.
    """
    if not ts_str:
        return None
    s = str(ts_str).strip().replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        dt_utc = dt.astimezone(timezone.utc)
        return dt_utc.strftime('%Y-%m-%d %H:%M:%S.%f')
    except (ValueError, TypeError):
        try:
            dt = datetime.strptime(s[:26], "%Y-%m-%dT%H:%M:%S.%f")
            dt = dt.replace(tzinfo=timezone.utc)
            return dt.strftime('%Y-%m-%d %H:%M:%S.%f')
        except (ValueError, TypeError):
            return None


# ------------------------------------------------------------------
# Watermark: get max(created) per host from dest table
# ------------------------------------------------------------------

def get_last_check_times():
    """Queries the destination table to find the last inserted 'created' per host.
    Returns UTC strings — NO IST conversion (consistent with parse_trino_timestamp)."""
    log("=" * 80)
    log("STEP 1: Fetching last check times (watermarks) from destination")
    log(f"Destination host: {DESTINATION_HOST}")
    log(f"Destination table: {DEST_TABLE}")
    log("=" * 80)

    query = f"""
        SELECT host, max(created) AS last_created
        FROM {DEST_TABLE}
        GROUP BY host
    """
    log(f"Watermark query:\n{query}")

    try:
        t0 = time.time()
        result = sq.query(query, host=DESTINATION_HOST)
        elapsed = time.time() - t0
        log(f"sq.query returned in {elapsed:.2f}s")

        if isinstance(result, dict):
            for k, v in result.items():
                if k == 'df':
                    log(f"  result['df'] shape: {v.shape if hasattr(v, 'shape') else 'N/A'}")
                elif k == 'data':
                    log(f"  result['data'] length: {len(v) if v is not None else 'None'}")
                else:
                    log(f"  result['{k}'] = {repr(v)[:200]}")

        if 'df' in result and not result['df'].empty:
            df_times = result['df']
            log(f"Watermark rows:\n{df_times.to_string()}")
            time_dict = {}
            for _, row in df_times.iterrows():
                host_val = row['host']
                ts = pd.to_datetime(row['last_created'])
                # Treat as UTC — strip any tz and use wall-clock value
                if ts.tzinfo is not None:
                    ts = ts.tz_convert('UTC').tz_localize(None)
                ts_str = ts.strftime('%Y-%m-%d %H:%M:%S.%f')
                time_dict[host_val] = ts_str
                log(f"  Host={repr(host_val)} -> last_created(UTC)={ts_str}")

            log(f"Final last_check_times: {time_dict}")
            return time_dict
        else:
            log("No existing watermark rows. First run scenario.", "WARN")
    except Exception as e:
        log(f"EXCEPTION fetching last check times: {e}", "ERROR")
        log(f"Traceback:\n{traceback.format_exc()}", "ERROR")

    return {}


# ------------------------------------------------------------------
# REST API Fetch
# ------------------------------------------------------------------

def fetch_queries_rest(coord_host):
    """
    Hit /v1/query on a coordinator. Returns list of query dicts.
    X-Trino-User header authenticates; returns ALL users' queries.
    """
    url = f"http://{coord_host}:{REST_PORT}/v1/query"
    headers = {"X-Trino-User": REST_USER}
    log(f"REST GET {url} (user={REST_USER})")
    r = requests.get(url, headers=headers, timeout=15)
    r.raise_for_status()
    data = r.json()
    log(f"  Received {len(data)} queries from {coord_host}")
    return data


# ------------------------------------------------------------------
# Main Processing (sequential, no threads — avoids Hive locks)
# ------------------------------------------------------------------

def process_servers(host_list, last_check_times, target_insert_host):
    """
    Fetches query memory via REST from each host in host_list.
    Collects rows, then batch-inserts into target_insert_host.
    Returns stats dict.
    """
    thread_name = threading.current_thread().name
    log("=" * 80)
    log(f"PROCESSING STARTED: {thread_name}")
    log(f"  Source hosts: {host_list}")
    log(f"  Target insert host: {target_insert_host}")
    log("=" * 80)

    stats = {'total_found': 0, 'total_inserted': 0, 'total_failed': 0}
    now = datetime.now(timezone.utc)
    captured_at = now.strftime('%Y-%m-%d %H:%M:%S.%f')

    all_rows_to_insert = []

    columns = [
        'query_id', 'state', 'user_name', 'source', 'query_text',
        'created', 'end_time',
        'peak_user_memory_bytes', 'peak_total_memory_bytes',
        'peak_node_total_memory_bytes', 'cumulative_user_memory',
        'revocable_memory_bytes', 'memory_pool',
        'cpu_time_ms', 'elapsed_ms', 'input_bytes', 'output_bytes',
        'host', 'captured_at'
    ]
    col_names = ", ".join(columns)

    # ---------------- FETCH PHASE ----------------
    for src_host in host_list:
        log("-" * 70)
        log(f"FETCH START: REST API host = {src_host}")

        last_time = last_check_times.get(src_host)
        if last_time is None:
            last_time_obj = now - timedelta(minutes=30)
            last_time = last_time_obj.strftime('%Y-%m-%d %H:%M:%S.%f')
            log(f"  No watermark for {src_host}. Defaulting to 30 mins ago (UTC): {last_time}", "WARN")
        else:
            log(f"  Watermark for {src_host}: only fetch queries created after (UTC): {last_time}")

        try:
            t_fetch_start = time.time()
            queries = fetch_queries_rest(src_host)
            elapsed_fetch = time.time() - t_fetch_start
            log(f"  REST fetch completed in {elapsed_fetch:.2f}s, total queries received: {len(queries)}")
        except Exception as e:
            log(f"  EXCEPTION fetching from {src_host}: {e}", "ERROR")
            log(f"  Traceback:\n{traceback.format_exc()}", "ERROR")
            continue

        # ---- Filter and extract ----
        kept = 0
        skipped_running = 0
        skipped_watermark = 0
        skipped_self = 0

        for q in queries:
            state = q.get("state")
            if state not in ("FINISHED", "FAILED"):
                skipped_running += 1
                continue

            qs = q.get("queryStats", {}) or {}
            sess = q.get("session", {}) or {}

            created_raw = qs.get("createTime") or q.get("createTime")
            created_str = parse_trino_timestamp(created_raw)

            if created_str and last_time and created_str <= last_time:
                skipped_watermark += 1
                continue

            query_text = q.get("query") or ""
            if DEST_TABLE in query_text or 'system.runtime.queries' in query_text:
                skipped_self += 1
                continue

            end_raw = qs.get("endTime") or q.get("endTime")
            end_str = parse_trino_timestamp(end_raw)

            v_query_id = safe_val(q.get("queryId"))
            v_state = safe_val(state)
            v_user = safe_val(sess.get("user"))
            v_source = safe_val(q.get("source"))
            v_query_text = safe_val(query_text)
            v_created = f"CAST({safe_val(created_str)} AS timestamp(6))"
            v_end = f"CAST({safe_val(end_str)} AS timestamp(6))"
            v_peak_user = mem_to_bytes(qs.get("peakUserMemoryReservation"))
            v_peak_total = mem_to_bytes(qs.get("peakTotalMemoryReservation"))
            v_peak_node = mem_to_bytes(qs.get("peakNodeTotalMemoryReservation"))
            v_cumulative = safe_val(qs.get("cumulativeUserMemory"))
            v_revocable = mem_to_bytes(qs.get("revocableMemoryReservation"))
            v_pool = safe_val(qs.get("memoryPool"))
            v_cpu_ms = duration_to_ms(qs.get("totalCpuTime") or qs.get("cpuTime"))
            v_elapsed_ms = duration_to_ms(qs.get("elapsedTime"))
            v_input_bytes = mem_to_bytes(qs.get("physicalInputBytes") or qs.get("inputBytes"))
            v_output_bytes = mem_to_bytes(qs.get("outputBytes"))
            v_host = safe_val(src_host)
            v_captured = f"CAST({safe_val(captured_at)} AS timestamp(6))"

            vals_str = (f"({v_query_id}, {v_state}, {v_user}, {v_source}, {v_query_text}, "
                        f"{v_created}, {v_end}, "
                        f"{v_peak_user}, {v_peak_total}, {v_peak_node}, "
                        f"{v_cumulative}, {v_revocable}, {v_pool}, "
                        f"{v_cpu_ms}, {v_elapsed_ms}, {v_input_bytes}, {v_output_bytes}, "
                        f"{v_host}, {v_captured})")
            all_rows_to_insert.append(vals_str)
            kept += 1

        log(f"  Filtering results: kept={kept}, skipped_running={skipped_running}, "
            f"skipped_watermark={skipped_watermark}, skipped_self={skipped_self}")
        log(f"FETCH END: REST API host = {src_host}")

    # ---------------- INSERT PHASE ----------------
    log("=" * 70)
    log(f"INSERT PHASE START: target host = {target_insert_host}")
    log(f"Total rows to insert: {len(all_rows_to_insert)}")

    stats['total_found'] = len(all_rows_to_insert)

    if not all_rows_to_insert:
        log("No new queries found. Skipping insert.", "WARN")
        return stats

    chunk_size = 50
    total_chunks = (len(all_rows_to_insert) + chunk_size - 1) // chunk_size
    total_inserted = 0
    total_failed = 0

    log(f"Will process {total_chunks} chunks of size {chunk_size}")

    for chunk_idx in range(total_chunks):
        i = chunk_idx * chunk_size
        chunk = all_rows_to_insert[i:i + chunk_size]
        log(f"  -- Chunk {chunk_idx + 1}/{total_chunks}: {len(chunk)} rows --")

        batch_insert_sql = (f"INSERT INTO {DEST_TABLE} ({col_names}) "
                            f"VALUES {', '.join(chunk)}")
        log(f"    SQL length: {len(batch_insert_sql)} chars")

        max_retries = 2
        for attempt in range(1, max_retries + 1):
            try:
                t_insert_start = time.time()
                query_res = sq.query(batch_insert_sql, host=target_insert_host)
                elapsed_insert = time.time() - t_insert_start
                log(f"    sq.query() returned in {elapsed_insert:.2f}s")

                is_error = False
                err_msg = ""
                if isinstance(query_res, dict):
                    if query_res.get('success') == 0:
                        is_error = True
                        err_msg = str(query_res.get('msg', 'Unknown error'))
                    elif query_res.get('msg') and 'Error' in str(query_res.get('msg')):
                        is_error = True
                        err_msg = str(query_res.get('msg'))

                if is_error:
                    if 'HIVE_TABLE_LOCK_NOT_ACQUIRED' in err_msg or 'HIVE_METASTORE_LOCK' in err_msg:
                        log(f"    Lock not acquired! Triggering cleanup "
                            f"(Attempt {attempt}/{max_retries})...", "WARN")
                        clear_hive_locks_for_table(
                            metastore_host=METASTORE_HOST,
                            metastore_db=METASTORE_DB,
                            metastore_user=METASTORE_USER,
                            metastore_password=METASTORE_PASSWORD,
                            target_db_name='analytics_services',
                            target_table_name='trino_query_memory'
                        )
                        if attempt < max_retries:
                            log(f"    Sleeping 10s before retry...", "WARN")
                            time.sleep(10)
                            continue
                        else:
                            total_failed += len(chunk)
                            log(f"    Failed chunk {chunk_idx + 1} after lock cleanup.", "ERROR")
                            break
                    else:
                        total_failed += len(chunk)
                        log(f"    Failed chunk {chunk_idx + 1}: {err_msg[:300]}", "ERROR")
                        break
                else:
                    total_inserted += len(chunk)
                    log(f"    Chunk {chunk_idx + 1} SUCCESS: inserted {len(chunk)} rows")
                    log(f"    Running total inserted: {total_inserted}")
                    break

            except Exception as e:
                total_failed += len(chunk)
                log(f"    EXCEPTION inserting chunk {chunk_idx + 1}: {e}", "ERROR")
                log(f"    Traceback:\n{traceback.format_exc()}", "ERROR")
                break

    log("=" * 70)
    log(f"INSERT PHASE END")
    log(f"  Total inserted: {total_inserted}")
    log(f"  Total failed:   {total_failed}")
    log("=" * 70)

    stats['total_inserted'] = total_inserted
    stats['total_failed'] = total_failed
    return stats


# ------------------------------------------------------------------
# Main DAG Task
# ------------------------------------------------------------------

def fetch_and_store_trino_memory(**kwargs):
    """Main DAG function."""
    log("#" * 80)
    log("DAG TASK STARTED: fetch_and_store_trino_memory")
    log(f"Airflow run_id: {kwargs.get('run_id')}")
    log(f"Execution date: {kwargs.get('ds')}")
    log("#" * 80)

    try:
        last_check_times = get_last_check_times()

        cleaned_times = {}
        for k, v in last_check_times.items():
            if k is None or (isinstance(k, float) and pd.isna(k)):
                log(f"  Skipping NULL/NaT host key: {repr(k)} -> {v}", "WARN")
                continue
            cleaned_times[k] = v
        last_check_times = cleaned_times
        log(f"Cleaned last_check_times: {last_check_times}")

        # Process all 5 hosts sequentially (no threads -> avoids locks)
        # Single group: all hosts -> insert into 10.10.116.75
        all_hosts = SOURCE_HOSTS
        target_host = DESTINATION_HOST

        log("-" * 80)
        log("Starting Sequential Processing (No Threads)")
        log(f"  Fetch from: {all_hosts}")
        log(f"  Insert into: {target_host}")
        log("-" * 80)

        stats = process_servers(all_hosts, last_check_times, target_host)

        grand_found = stats.get('total_found', 0)
        grand_inserted = stats.get('total_inserted', 0)
        grand_failed = stats.get('total_failed', 0)

        log("\n" + "=" * 80)
        log("FINAL AGGREGATED STATS")
        log(f"  Total rows found:   {grand_found}")
        log(f"  Total rows inserted: {grand_inserted}")
        log(f"  Total rows failed:   {grand_failed}")
        log("=" * 80)

        if grand_found > 0 and grand_inserted == 0:
            raise Exception(
                f"CRITICAL: Fetched {grand_found} rows but inserted 0. "
                f"All chunks failed. Check logs for locks or sq.query errors."
            )

        if grand_failed > 0 and grand_inserted > 0:
            log(f"WARNING: {grand_failed} rows failed, but {grand_inserted} succeeded. "
                f"DAG will not fail.", "WARN")

        log("#" * 80)
        log("DAG TASK COMPLETE: fetch_and_store_trino_memory")
        log("#" * 80)

    except Exception as e:
        log(f"FATAL EXCEPTION: {e}", "ERROR")
        log(f"Traceback:\n{traceback.format_exc()}", "ERROR")
        raise


# ------------------------------------------------------------------
# DAG Definition
# ------------------------------------------------------------------

default_args = {
    'owner': 'Goverdhan',
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=2),
    'on_failure_callback': alert_failure_callback,
}

with DAG(
    dag_id='trino_query_memory_collector',
    default_args=default_args,
    description='Captures per-query peak memory from Trino REST API on 5 coordinators',
    schedule='*/5 * * * *',
    start_date=datetime(2026, 10, 19, tzinfo=IST),
    catchup=False,
    max_active_runs=1,
    max_active_tasks=1,
    tags=['trino', 'memory', 'monitoring', 'rest-api'],
) as dag:

    collect_memory_task = PythonOperator(
        task_id='fetch_and_store_trino_memory',
        python_callable=fetch_and_store_trino_memory,
    )

    collect_memory_task