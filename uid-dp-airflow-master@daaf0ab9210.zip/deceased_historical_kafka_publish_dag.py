from datetime import date, datetime
import json

from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from pyspark.sql import SparkSession
from kafka import KafkaProducer
from strot_alert_notification import alert_failure_callback, configure

configure(channel="dataplatformtesting")

JOB_NAME = "deceased_historical_kafka_publish"
SPARK_CONNECT_URL = "sc://spark-connect-service.strot-spark.svc.cluster.local:15002"
UID_MASTER_CUTOFF_DATE = date(2026, 9, 30)
UID_MASTER_TABLE = "strot.mysql_uid_v2.uid_master"
ORIGIN_TRACKER_TABLE = "strot.mysql_uid_v2.uid_origin_tracker"
PAIR_TABLE = "warm_store.refid_store.refid_subaua_store"
KAFKA_TOPIC = "STROT.DECEASED.NOTIFY.V1"
KAFKA_BROKERS = ",".join([
    "10.10.105.225:9092", "10.10.106.171:9092", "10.10.107.110:9092",
    "10.10.105.75:9092", "10.10.105.98:9092", "10.10.105.238:9092",
    "10.10.107.130:9092", "10.10.105.33:9092", "10.10.106.195:9092",
    "10.10.105.227:9092",
])
MYSQL_URL = "jdbc:mysql://10.10.126.51:3306/uidmasterv1_1"
MYSQL_USERNAME = "data_platform_R"
MYSQL_PASSWORD = "Data_p!atform_7634"

default_args = {
    "owner": "harshag.nisg",
    "depends_on_past": False,
    "start_date": datetime(2026, 9, 3),
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 0,
    "on_failure_callback": alert_failure_callback,
}

dag = DAG(
    JOB_NAME,
    default_args=default_args,
    description="One-time historical deceased UID Kafka publisher via Spark Connect",
    schedule=None,
    catchup=False,
    tags=["deceased", "kafka", "historical", "spark-connect"],
)


def publish_deceased_historical_events():
    spark = SparkSession.builder.remote(SPARK_CONNECT_URL).appName(JOB_NAME).getOrCreate()

    def read_mysql(table_name):
        return spark.read.format("jdbc").option("url", MYSQL_URL).option(
            "dbtable", table_name
        ).option("user", MYSQL_USERNAME).option("password", MYSQL_PASSWORD).option(
            "driver", "com.mysql.cj.jdbc.Driver"
        ).load()

    try:
        organizations = read_mysql("organization")
        subauas = organizations.selectExpr("org_code AS subaua", "org_key AS subaua_org_key")
        associations = read_mysql("org_association").selectExpr("from_org_key", "to_org_key AS aua_org_key")
        auas = organizations.selectExpr("org_key AS aua_org_key", "org_code AS actual_aua")
        subauas.createOrReplaceTempView("historical_subaua_organizations")
        associations.createOrReplaceTempView("historical_org_associations")
        auas.createOrReplaceTempView("historical_aua_organizations")

        records = spark.sql(f"""
            WITH matched_pairs AS (
                SELECT DISTINCT master.uid, CAST(master.res_dod AS STRING) AS res_dod,
                       CAST(master.uid_status_key AS STRING) AS code, tracker.refid, pairs.subaua
                FROM {UID_MASTER_TABLE} master
                JOIN {ORIGIN_TRACKER_TABLE} tracker ON tracker.uid = master.uid AND tracker.enr_status = 'C'
                JOIN {PAIR_TABLE} pairs ON pairs.refid = tracker.refid
                WHERE master.uid_status_key = 99
                  AND to_date(master.last_updated_date) <= DATE '{UID_MASTER_CUTOFF_DATE.isoformat()}'
            ),
            mapped_pairs AS (
                SELECT matched_pairs.*, COALESCE(aua_org.actual_aua, matched_pairs.subaua) AS aua
                FROM matched_pairs
                LEFT JOIN historical_subaua_organizations subaua_org ON subaua_org.subaua = matched_pairs.subaua
                LEFT JOIN historical_org_associations association ON association.from_org_key = subaua_org.subaua_org_key
                LEFT JOIN historical_aua_organizations aua_org ON aua_org.aua_org_key = association.aua_org_key
            ),
            one_refid_per_uid AS (
                SELECT uid, MIN(refid) AS refid FROM mapped_pairs GROUP BY uid
            )
            SELECT DISTINCT mapped_pairs.uid, selected.refid, mapped_pairs.code, mapped_pairs.res_dod,
                            mapped_pairs.aua, mapped_pairs.subaua
            FROM mapped_pairs
            JOIN one_refid_per_uid selected ON selected.uid = mapped_pairs.uid
        """)
        record_count = records.count()
        print(f"Historical deceased publisher: {record_count} Kafka events to publish")
        if record_count == 0:
            return

        records.createOrReplaceTempView("historical_deceased_kafka_records")
        spark.sql("""
            CREATE OR REPLACE TEMP VIEW historical_deceased_kafka_payload AS
            SELECT
                CONCAT(refid, subaua) AS key,
                to_json(named_struct(
                    'eventId', CONCAT(refid, subaua),
                    'eventTimestamp', date_format(current_timestamp(), "yyyy-MM-dd'T'HH:mm:ss'Z'"),
                    'version', '1.0',
                    'category', 'KYC_UPDATE',
                    'data', named_struct(
                        'uid', uid, 'refid', refid, 'uidStatus', code, 'csrTimestamp', res_dod,
                        'auaDetails', array(named_struct('aua_code', aua, 'sub_aua_code', subaua))
                    )
                )) AS value
            FROM historical_deceased_kafka_records
        """)
        # Publish to Kafka using foreachPartition for scalability
        headers = [
            ("event-source", b"scanner"),
            ("__TypeId__", b"com.uidai.strot.deceased.refid.notifications"),
        ]
        
        def send_partition(partition):
            producer = KafkaProducer(
                bootstrap_servers=KAFKA_BROKERS.split(","),
                key_serializer=lambda value: str(value).encode("utf-8"),
                value_serializer=lambda value: json.dumps(value).encode("utf-8") if isinstance(value, dict) else value,
            )
            try:
                for row in partition:
                    record = row.asDict()
                    producer.send(KAFKA_TOPIC, key=record['key'], value=json.loads(record['value']), headers=headers)
                producer.flush()
            finally:
                producer.close()
        
        spark.table("historical_deceased_kafka_payload").foreachPartition(send_partition)
        print(f"Historical deceased publisher: published {record_count} Kafka events")
    finally:
        spark.stop()


task = PythonOperator(
    task_id="publish_deceased_historical_events",
    python_callable=publish_deceased_historical_events,
    dag=dag,
)