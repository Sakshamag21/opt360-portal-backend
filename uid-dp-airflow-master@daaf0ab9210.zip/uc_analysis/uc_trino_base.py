"""
Shared utilities for UC analysis pipeline (Trino-based).

Provides:
  - Trino DB-API connection helper
  - Query execution that returns list[dict]
  - Kafka producer helper (send rows to topic)
  - IST timestamp helper
"""

import logging
import datetime
import json

import trino
from kafka import KafkaProducer
import pytz

logger = logging.getLogger(__name__)

# ── Trino configuration ──────────────────────────────────────────────
TRINO_HOST = "10.10.116.75"
TRINO_PORT = 8080
TRINO_USER = "opt360job"
TRINO_HTTP_SCHEME = "http"
TRINO_CATALOG = "flink_stream"
TRINO_SCHEMA = "stream_enu"

# ── Kafka configuration ──────────────────────────────────────────────
KAFKA_BROKERS = [
    "10.10.105.225:9092",
    "10.10.106.171:9092",
    "10.10.107.110:9092",
    "10.10.105.75:9092",
]


def get_trino_connection():
    """Create and return a Trino DB-API connection."""
    conn = trino.dbapi.connect(
        host=TRINO_HOST,
        port=TRINO_PORT,
        user=TRINO_USER,
        catalog=TRINO_CATALOG,
        schema=TRINO_SCHEMA,
        http_scheme=TRINO_HTTP_SCHEME,
    )
    return conn


def execute_query(query, params=None):
    """
    Execute a Trino query and return rows as a list of dicts.

    Args:
        query: SQL string (Trino dialect).
        params: Optional parameters for parameterised queries.

    Returns:
        list[dict] — each dict maps column name → value.
    """
    conn = get_trino_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(query, params)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        result = [dict(zip(columns, row)) for row in rows]
        logger.info("Trino query returned %d rows", len(result))
        return result
    finally:
        cursor.close()
        conn.close()


def get_ist_now():
    """Return current IST time as a formatted string."""
    ist_tz = pytz.timezone("Asia/Kolkata")
    ist_time = datetime.datetime.now(ist_tz)
    return ist_time.strftime("%Y-%m-%d %H:%M:%S")


def send_to_kafka(rows, topic, key_func, message_func):
    """
    Send rows to a Kafka topic.

    Args:
        rows:        list[dict] from execute_query().
        topic:       Kafka topic name.
        key_func:    callable(row) -> str  (Kafka message key).
        message_func: callable(row) -> dict (Kafka message value).

    Returns:
        (sent_count, error_count)
    """
    producer = KafkaProducer(
        bootstrap_servers=KAFKA_BROKERS,
        acks=1,
        retries=2,
        value_serializer=lambda v: json.dumps(v).encode("utf-8"),
        key_serializer=lambda k: k.encode("utf-8") if isinstance(k, str) else k,
    )
    sent = 0
    errors = 0
    for row in rows:
        try:
            key = key_func(row)
            message = message_func(row)
            producer.send(topic=topic, key=key, value=message)
            sent += 1
        except Exception as exc:
            logger.error("Failed to send message for row %s: %s", row, exc)
            errors += 1
    producer.flush()
    producer.close()
    logger.info(
        "Kafka publish complete: %d sent, %d errors, topic=%s",
        sent, errors, topic,
    )
    return sent, errors
