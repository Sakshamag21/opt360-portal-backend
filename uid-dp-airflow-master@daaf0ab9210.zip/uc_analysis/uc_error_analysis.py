"""
UC error code analysis (Trino-based).

Joins telemetry_uc (error events) with enu_uc_opt_action_v2 (operator
actions) on transaction ID, counts errors per error_type × entity
(operator, stage, machine_id, enrolment_type) over the last hour, and
publishes results to Kafka topic DE.UC.ERROR.ANALYTICS.AGGREGATION.

The two UNION queries are split into separate Trino calls to keep
each query lightweight (same approach as the original Spark code).
"""

import logging
import datetime

from uc_analysis.uc_trino_base import execute_query, send_to_kafka, get_ist_now

logger = logging.getLogger(__name__)

OUTPUT_TOPIC = "DE.UC.ERROR.ANALYTICS.AGGREGATION"

# ── Query 1: errors by operator and stage ────────────────────────────
QUERY_OPERATOR_STAGE = """
WITH tab1 AS (
    SELECT DISTINCT eid, sid, error_type
    FROM flink_stream.stream_enu.telemetry_uc
    WHERE ets >= CURRENT_TIMESTAMP - INTERVAL '1' HOUR
),
tab2 AS (
    SELECT DISTINCT
        station_machine_code,
        upper(operator_id) AS operator_id,
        resident_sid,
        enrolment_type,
        stage,
        txn_id
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE event_timestamp >= CURRENT_TIMESTAMP - INTERVAL '1' HOUR
),
tab3 AS (
    SELECT t1.error_type, t2.operator_id, t2.stage, t2.station_machine_code, t2.enrolment_type
    FROM tab2 t2
    LEFT JOIN tab1 t1 ON t2.txn_id = t1.eid
)
SELECT error_type, COUNT(*) AS count, operator_id AS entity_id, 'Operator' AS entity
FROM tab3
WHERE operator_id IS NOT NULL AND operator_id != ''
  AND error_type IS NOT NULL AND error_type != ''
GROUP BY error_type, operator_id
UNION ALL
SELECT error_type, COUNT(*) AS count, stage AS entity_id, 'Stage' AS entity
FROM tab3
WHERE stage IS NOT NULL AND stage != ''
  AND error_type IS NOT NULL AND error_type != ''
GROUP BY error_type, stage
"""

# ── Query 2: errors by machine and enrolment type ───────────────────
QUERY_MACHINE_ENROLMENT = """
WITH tab1 AS (
    SELECT DISTINCT eid, sid, error_type
    FROM flink_stream.stream_enu.telemetry_uc
    WHERE ets >= CURRENT_TIMESTAMP - INTERVAL '1' HOUR
),
tab2 AS (
    SELECT DISTINCT
        station_machine_code,
        upper(operator_id) AS operator_id,
        resident_sid,
        enrolment_type,
        stage,
        txn_id
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE event_timestamp >= CURRENT_TIMESTAMP - INTERVAL '1' HOUR
),
tab3 AS (
    SELECT t1.error_type, t2.operator_id, t2.stage, t2.station_machine_code, t2.enrolment_type
    FROM tab2 t2
    LEFT JOIN tab1 t1 ON t2.txn_id = t1.eid
)
SELECT error_type, COUNT(*) AS count, station_machine_code AS entity_id, 'Machine ID' AS entity
FROM tab3
WHERE station_machine_code IS NOT NULL AND station_machine_code != ''
  AND error_type IS NOT NULL AND error_type != ''
GROUP BY error_type, station_machine_code
UNION ALL
SELECT error_type, COUNT(*) AS count, enrolment_type AS entity_id, 'Enrolment Type' AS entity
FROM tab3
WHERE enrolment_type IS NOT NULL AND enrolment_type != ''
  AND error_type IS NOT NULL AND error_type != ''
GROUP BY error_type, enrolment_type
"""


def message_structure(row):
    ist_string = get_ist_now()
    return {
        "aggregationValue": row["count"],
        "windowStartTimestamp": str(datetime.date.today()) + " 00:00:00",
        "aggregationType": "COUNT",
        "windowDuration": "hourly",
        "comments": {},
        "aggregationCount": row["count"],
        "windowEndTimestamp": ist_string,
        "publishedTimestamp": ist_string,
        "entityId": row["entity_id"],
        "aggregationField": "error_type",
        "entity": row["entity"],
        "error_code": row["error_type"],
    }


def key_func(row):
    return f"{str(row['entity']).lower()}:{row['entity_id']}"


def main():
    logger.info("Starting uc_error_analysis (Trino)")

    logger.info("Querying errors by operator and stage")
    rows1 = execute_query(QUERY_OPERATOR_STAGE)
    sent1, err1 = send_to_kafka(rows1, OUTPUT_TOPIC, key_func, message_structure)

    logger.info("Querying errors by machine and enrolment type")
    rows2 = execute_query(QUERY_MACHINE_ENROLMENT)
    sent2, err2 = send_to_kafka(rows2, OUTPUT_TOPIC, key_func, message_structure)

    logger.info(
        "Done: Q1=%d sent/%d errors, Q2=%d sent/%d errors",
        sent1, err1, sent2, err2,
    )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()
