"""
UC per-SID inter-stage duration analysis (Trino-based).

Produces individual transition durations per (operator, resident_sid,
stage_from, stage_to) over a 15-minute window and publishes results
to Kafka topic DE.UC.TXN.SID.ANALYSIS.V1.
"""

import logging
import time
import uuid

from uc_analysis.uc_trino_base import execute_query, send_to_kafka

logger = logging.getLogger(__name__)

OUTPUT_TOPIC = "DE.UC.TXN.SID.ANALYSIS.V1"

# Time window (mirrors the original Spark logic):
#   start_time      = now - 30m
#   end_time        = now - 15m
#   buffer_end_time = now - 10m  (end_time + 5m)

QUERY = """
WITH filtered AS (
    SELECT
        operator_id,
        resident_sid,
        stage,
        event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE event_timestamp >= CURRENT_TIMESTAMP - INTERVAL '30' MINUTE
      AND event_timestamp <  CURRENT_TIMESTAMP - INTERVAL '10' MINUTE
      AND operator_id  IS NOT NULL AND trim(operator_id)  != ''
      AND resident_sid IS NOT NULL AND trim(resident_sid) != ''
),
transitions AS (
    SELECT
        operator_id,
        resident_sid,
        stage            AS stage_from,
        event_timestamp  AS stage_from_time,
        lead(stage)           OVER (PARTITION BY resident_sid ORDER BY event_timestamp) AS stage_to,
        lead(event_timestamp) OVER (PARTITION BY resident_sid ORDER BY event_timestamp) AS stage_to_time
    FROM filtered
),
valid_transitions AS (
    SELECT *
    FROM transitions
    WHERE stage_to IS NOT NULL
      AND stage_from_time >= CURRENT_TIMESTAMP - INTERVAL '30' MINUTE
      AND stage_from_time <  CURRENT_TIMESTAMP - INTERVAL '15' MINUTE
)
SELECT DISTINCT
    operator_id,
    resident_sid,
    stage_from,
    stage_to,
    date_diff('second', stage_from_time, stage_to_time) AS time_difference_seconds
FROM valid_transitions
ORDER BY operator_id, resident_sid, stage_from, stage_to, time_difference_seconds
"""


def message_structure(row):
    current_time_epoch = int(time.time())
    return {
        "eventId": str(uuid.uuid4()),
        "entityId": row["operator_id"],
        "entity": "OPERATOR",
        "analysisType": "INTER_STAGE_DURATION",
        "sid": row["resident_sid"],
        "startFrom": row["stage_from"],
        "startTo": row["stage_to"],
        "value": "Duration (seconds)",
        "attributeValue": row["time_difference_seconds"],
        "analysisWindow": "15min",
        "eventTimestamp": current_time_epoch,
    }


def key_func(row):
    return str(row["operator_id"])


def main():
    logger.info("Starting uc_step_analysis_sid (Trino)")
    rows = execute_query(QUERY)
    logger.info("Fetched %d transition rows from Trino", len(rows))
    sent, errors = send_to_kafka(rows, OUTPUT_TOPIC, key_func, message_structure)
    logger.info("Done: %d sent, %d errors", sent, errors)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()
