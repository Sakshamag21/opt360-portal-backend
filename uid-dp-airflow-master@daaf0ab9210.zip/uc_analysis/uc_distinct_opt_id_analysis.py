"""
UC distinct operator-id count analysis (Trino-based).

Counts distinct operators per Enrolment Agency (EA) and per Registrar
for the current day and publishes results to Kafka topic
DE.UC.ANALYTICS.AGGREGATION.
"""

import logging
import datetime

from uc_analysis.uc_trino_base import execute_query, send_to_kafka, get_ist_now

logger = logging.getLogger(__name__)

OUTPUT_TOPIC = "DE.UC.ANALYTICS.AGGREGATION"

QUERY_BY_EA = """
SELECT count(DISTINCT operator_id) AS opt_count, ea AS entity_id, 'EA' AS entity
FROM flink_stream.stream_enu.enu_uc_opt_action_v2
WHERE CAST(event_timestamp AS date) = current_date
GROUP BY ea
"""

QUERY_BY_REGISTRAR = """
SELECT count(DISTINCT operator_id) AS opt_count, registrar AS entity_id, 'REGISTRAR' AS entity
FROM flink_stream.stream_enu.enu_uc_opt_action_v2
WHERE CAST(event_timestamp AS date) = current_date
GROUP BY registrar
"""


def message_structure(row):
    ist_string = get_ist_now()
    return {
        "aggregationValue": row["opt_count"],
        "windowStartTimestamp": str(datetime.date.today()) + " 00:00:00",
        "aggregationType": "COUNT_DISTINCT",
        "windowDuration": "daily",
        "comments": {},
        "aggregationCount": row["opt_count"],
        "windowEndTimestamp": ist_string,
        "publishedTimestamp": ist_string,
        "entityId": row["entity_id"],
        "aggregationField": "operator_id",
        "entity": row["entity"],
    }


def key_func(row):
    return f"{str(row['entity']).lower()}:{row['entity_id']}"


def main():
    logger.info("Starting uc_distinct_opt_id_analysis (Trino)")

    logger.info("Querying distinct operator count by EA")
    rows_ea = execute_query(QUERY_BY_EA)
    sent_ea, err_ea = send_to_kafka(rows_ea, OUTPUT_TOPIC, key_func, message_structure)

    logger.info("Querying distinct operator count by Registrar")
    rows_reg = execute_query(QUERY_BY_REGISTRAR)
    sent_reg, err_reg = send_to_kafka(rows_reg, OUTPUT_TOPIC, key_func, message_structure)

    logger.info(
        "Done: EA=%d sent/%d errors, Registrar=%d sent/%d errors",
        sent_ea, err_ea, sent_reg, err_reg,
    )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()
