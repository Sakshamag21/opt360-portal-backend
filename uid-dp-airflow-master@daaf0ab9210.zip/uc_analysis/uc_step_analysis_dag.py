"""
Airflow DAG for UC analysis pipeline (Trino-based).

Replaces the previous KubernetesPodOperator + spark-submit approach
with lightweight PythonOperator tasks that query Trino directly and
publish results to Kafka.

Prerequisites on the Airflow worker:
    pip install trino kafka-python

Schedule: every 15 minutes (10,25,40,55 * * * *)
  - uc_step_analysis_sid        → runs every slot
  - uc_distinct_opt_id_count_ea → only at :55 (ShortCircuit gate)
  - uc_step_analysis            → only at :55, after distinct count
  - uc_error_analysis           → only at :55
"""

from datetime import datetime

from airflow import DAG
from airflow.exceptions import AirflowSkipException  # noqa: F401 (kept for compatibility)
from airflow.providers.standard.operators.python import PythonOperator, ShortCircuitOperator
from airflow.providers.smtp.notifications.smtp import SmtpNotifier

# ── DAG metadata ─────────────────────────────────────────────────────
job_name = "uc_aggregation_analysis"
desc = "Publish UC aggregation Kafka messages via Trino"
schedule = "10,25,40,55 * * * *"

# ── Email notifications ──────────────────────────────────────────────
retry_notifier = SmtpNotifier(
    from_email="strot@uidai.net.in",
    to=["techexe16.yp25@uidai.net.in"],
    subject="Airflow Alert: Task {{ ti.task_id }} Failed (Attempt {{ ti.try_number }})",
)

final_failure_notifier = SmtpNotifier(
    from_email="strot@uidai.net.in",
    to=["techexe16.yp25@uidai.net.in"],
    subject="Airflow Alert: Task {{ ti.task_id }} Completely FAILED",
)

default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": datetime(2026, 7, 9),
    "retries": 1,
    "on_retry_callback": [retry_notifier],
    "on_failure_callback": [final_failure_notifier],
}

dag = DAG(
    job_name,
    default_args=default_args,
    description=desc,
    schedule=schedule,
    catchup=False,
    max_active_tasks=3,
    tags=["uc_aggregation_analysis", "kafka", "trino"],
)

# ── Short-circuit: only proceed for :55 slot ─────────────────────────
def check_55_minute_mark(**context):
    execution_minute = context["logical_date"].minute
    return execution_minute in range(50, 60)


check_if_55_min = ShortCircuitOperator(
    task_id="check_if_55_min",
    python_callable=check_55_minute_mark,
    dag=dag,
)

# ── Task callables (imports deferred to parse-time safety) ───────────
def _run_uc_step_analysis():
    from uc_analysis.uc_step_analysis import main
    main()


def _run_uc_distinct_opt_id_analysis():
    from uc_analysis.uc_distinct_opt_id_analysis import main
    main()


def _run_uc_step_analysis_sid():
    from uc_analysis.uc_step_analysis_sid import main
    main()


def _run_uc_error_analysis():
    from uc_analysis.uc_error_analysis import main
    main()


# ── Tasks ────────────────────────────────────────────────────────────
uc_step_analysis = PythonOperator(
    task_id="uc_step_analysis",
    python_callable=_run_uc_step_analysis,
    dag=dag,
)

uc_distinct_optid_count_ea = PythonOperator(
    task_id="uc_distinct_optid_count_ea",
    python_callable=_run_uc_distinct_opt_id_analysis,
    dag=dag,
)

uc_step_analysis_sid = PythonOperator(
    task_id="uc_step_analysis_sid",
    python_callable=_run_uc_step_analysis_sid,
    dag=dag,
)

uc_error_analysis = PythonOperator(
    task_id="uc_error_analysis",
    python_callable=_run_uc_error_analysis,
    dag=dag,
)

# ── Dependencies ─────────────────────────────────────────────────────
# uc_step_analysis_sid runs on every schedule slot (independent).
# The other three only run on the :55 slot, gated by check_if_55_min.

uc_step_analysis_sid  # noqa: standalone task

check_if_55_min >> uc_distinct_optid_count_ea >> uc_step_analysis
check_if_55_min >> uc_error_analysis
