"""
UC inter-step duration analysis (Trino-based).

Computes per-operator, per-stage-transition duration statistics
(min / max / avg / p75 / p90 / p99 / count) over a 1-hour window
and publishes results to Kafka topic DE.OPT360.UC.TXN.ANALYSIS.V1.
"""

import logging
import time
import uuid

from uc_analysis.uc_trino_base import execute_query, send_to_kafka

logger = logging.getLogger(__name__)

OUTPUT_TOPIC = "DE.OPT360.UC.TXN.ANALYSIS.V1"

# Time window (mirrors the original Spark logic):
#   start_time      = now - 1h15m
#   end_time        = now - 15m
#   buffer_end_time = now - 10m  (end_time + 5m, captures trailing edge)
#
# Spark functions → Trino equivalents:
#   F.lead()                         → lead() OVER (...)
#   F.percentile_approx(x, p)        → approx_percentile(x, p)
#   F.first(ignorenulls=True) window → max() in a GROUP BY CTE
#   cast(ts).cast("long") diff       → date_diff('second', from, to)

QUERY = """
WITH filtered AS (
    SELECT
        operator_id,
        resident_sid,
        stage,
        event_timestamp,
        enrolment_type
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE event_timestamp >= CURRENT_TIMESTAMP - INTERVAL '75' MINUTE
      AND event_timestamp <  CURRENT_TIMESTAMP - INTERVAL '10' MINUTE
      AND operator_id  IS NOT NULL AND trim(operator_id)  != ''
      AND resident_sid IS NOT NULL AND trim(resident_sid) != ''
),
sid_enrolment AS (
    SELECT resident_sid, max(enrolment_type) AS enrolment_type
    FROM filtered
    WHERE enrolment_type IS NOT NULL
    GROUP BY resident_sid
),
transitions AS (
    SELECT
        f.operator_id,
        f.resident_sid,
        f.stage            AS stage_from,
        f.event_timestamp  AS stage_from_time,
        lead(f.stage)           OVER (PARTITION BY f.resident_sid ORDER BY f.event_timestamp) AS stage_to,
        lead(f.event_timestamp) OVER (PARTITION BY f.resident_sid ORDER BY f.event_timestamp) AS stage_to_time,
        se.enrolment_type
    FROM filtered f
    LEFT JOIN sid_enrolment se ON f.resident_sid = se.resident_sid
),
valid_transitions AS (
    SELECT *
    FROM transitions
    WHERE stage_to IS NOT NULL
      AND stage_from_time >= CURRENT_TIMESTAMP - INTERVAL '75' MINUTE
      AND stage_from_time <  CURRENT_TIMESTAMP - INTERVAL '15' MINUTE
)
SELECT
    operator_id,
    stage_from,
    stage_to,
    enrolment_type,
    min(date_diff('second', stage_from_time, stage_to_time)) AS min_duration,
    max(date_diff('second', stage_from_time, stage_to_time)) AS max_duration,
    avg(date_diff('second', stage_from_time, stage_to_time)) AS avg_duration,
    approx_percentile(CAST(date_diff('second', stage_from_time, stage_to_time) AS double), 0.75) AS p75_duration,
    approx_percentile(CAST(date_diff('second', stage_from_time, stage_to_time) AS double), 0.90) AS p90_duration,
    approx_percentile(CAST(date_diff('second', stage_from_time, stage_to_time) AS double), 0.99) AS p99_duration,
    count(*) AS total_transition_count
FROM valid_transitions
GROUP BY operator_id, stage_from, stage_to, enrolment_type
"""


def message_structure(row):
    current_time_epoch = int(time.time())
    return {
        "eventId": str(uuid.uuid4()),
        "entityId": row["operator_id"],
        "entity": "OPERATOR",
        "analysisType": "UC_INTER_STEP_ANALYSIS",
        "attributeKey": f"{row['stage_from']} to {row['stage_to']}",
        "value": "Duration (seconds)",
        "min": row["min_duration"],
        "max": row["max_duration"],
        "average": row["avg_duration"],
        "p99": row["p99_duration"],
        "p90": row["p90_duration"],
        "p75": row["p75_duration"],
        "comments": f"Total Transition Count: {row['total_transition_count']}",
        "analysisWindow": "1hr",
        "eventTimestamp": current_time_epoch,
    }


def key_func(row):
    return str(row["operator_id"])


def main():
    logger.info("Starting uc_step_analysis (Trino)")
    rows = execute_query(QUERY)
    logger.info("Fetched %d aggregated rows from Trino", len(rows))
    sent, errors = send_to_kafka(rows, OUTPUT_TOPIC, key_func, message_structure)
    logger.info("Done: %d sent, %d errors", sent, errors)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()
