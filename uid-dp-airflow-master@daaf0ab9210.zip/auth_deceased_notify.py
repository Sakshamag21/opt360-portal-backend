from datetime import datetime, timezone
import json

from airflow import DAG
from airflow.models import Variable
from airflow.providers.standard.operators.python import PythonOperator
from pyspark.sql import SparkSession
from kafka import KafkaProducer
from strot_alert_notification import alert_failure_callback, configure

configure(channel="dataplatformtesting")


JOB_NAME = "auth_deceased_notify_adhoc"
AIRFLOW_AUA_VARIABLE = "auth_deceased_notify_aua"
AIRFLOW_SUBAUA_VARIABLE = "auth_deceased_notify_subaua"
SPARK_CONNECT_URL = "sc://spark-connect-service.strot-spark.svc.cluster.local:15002"
UID_MASTER_TABLE = "strot.mysql_uid_v2.uid_master"
ORIGIN_TRACKER_TABLE = "strot.mysql_uid_v2.uid_origin_tracker"
PAIR_TABLE = "warm_store.refid_store.refid_subaua_store"
KAFKA_TOPIC = "STROT.DECEASED.NOTIFY.V1"
KAFKA_BROKERS = ",".join([
    "10.10.105.225:9092", "10.10.106.171:9092", "10.10.107.110:9092",
    "10.10.105.75:9092", "10.10.105.98:9092", "10.10.105.238:9092",
    "10.10.107.130:9092", "10.10.105.33:9092", "10.10.106.195:9092",
    "10.10.105.227:9092",
])
UID_STATUS_CODES = [99]

default_args = {
    "owner": "harshag.nisg",
    "depends_on_past": False,
    "start_date": datetime(2026, 6, 12),
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "on_failure_callback": alert_failure_callback,
}

dag = DAG(
    JOB_NAME,
    default_args=default_args,
    description="Manual single-AUA deceased Kafka publisher via Spark Connect",
    schedule=None,
    catchup=False,
    tags=["AUTH", "deceased-notify", "kafka", "spark-connect"],
)


def publish_selected_aua_deceased_events():
    selected_aua = Variable.get(AIRFLOW_AUA_VARIABLE).strip()
    selected_subaua = Variable.get(AIRFLOW_SUBAUA_VARIABLE).strip()
    if not selected_aua:
        raise ValueError(f"Airflow Variable {AIRFLOW_AUA_VARIABLE} must contain one AUA code")
    if not selected_aua.isdigit() or len(selected_aua) != 10:
        raise ValueError(f"Airflow Variable {AIRFLOW_AUA_VARIABLE} must be a 10-digit AUA code")
    if not selected_subaua:
        raise ValueError(f"Airflow Variable {AIRFLOW_SUBAUA_VARIABLE} must contain one SubAUA code")

    print(
        f"Selected-AUA deceased publisher: AUA={selected_aua}, "
        f"SubAUA={selected_subaua}"
    )
    spark = SparkSession.builder.remote(SPARK_CONNECT_URL).appName(
        "deceased-selective-aua-kafka-publish"
    ).getOrCreate()

    try:
        records = spark.sql(f"""
            WITH matched_pairs AS (
                SELECT DISTINCT master.uid, CAST(master.res_dod AS STRING) AS res_dod,
                       tracker.refid
                FROM {UID_MASTER_TABLE} master
                JOIN {ORIGIN_TRACKER_TABLE} tracker ON tracker.uid = master.uid AND tracker.enr_status = 'C'
                JOIN {PAIR_TABLE} pairs ON pairs.refid = tracker.refid AND pairs.subaua = '{selected_subaua}'
                WHERE master.uid_status_key IN ({','.join(map(str, UID_STATUS_CODES))})
            )
            SELECT uid, MIN(refid) AS refid, MIN(res_dod) AS res_dod
            FROM matched_pairs
            GROUP BY uid
        """)
        record_count = records.count()
        print(f"Selected-AUA deceased publisher: {record_count} Kafka events to publish")
        if record_count == 0:
            return

        records.createOrReplaceTempView("adhoc_deceased_kafka_records")
        print(f"""
            SELECT
                CONCAT(refid, '{selected_aua}') AS key,
                to_json(named_struct(
                    'eventId', CONCAT(refid, '{selected_aua}'),
                    'eventTimestamp', date_format(current_timestamp(), "yyyy-MM-dd'T'HH:mm:ss'Z'"),
                    'version', '1.0',
                    'category', 'KYC_UPDATE',
                    'data', named_struct(
                        'uid', uid, 'refid', refid, 'uidStatus', 'CANCEL', 'csrTimestamp', res_dod,
                        'auaDetails', array(named_struct('aua_code', '{selected_aua}', 'sub_aua_code', '{selected_subaua}'))
                    )
                )) AS value
            FROM adhoc_deceased_kafka_records
        """)
        spark.sql(f"""
            CREATE OR REPLACE TEMP VIEW adhoc_deceased_kafka_payload AS
            SELECT
                CONCAT(refid, '{selected_aua}') AS key,
                to_json(named_struct(
                    'eventId', CONCAT(refid, '{selected_aua}'),
                    'eventTimestamp', date_format(current_timestamp(), "yyyy-MM-dd'T'HH:mm:ss'Z'"),
                    'version', '1.0',
                    'category', 'KYC_UPDATE',
                    'data', named_struct(
                        'uid', uid, 'refid', refid, 'uidStatus', 'CANCEL', 'csrTimestamp', res_dod,
                        'auaDetails', array(named_struct('aua_code', '{selected_aua}', 'sub_aua_code', '{selected_subaua}'))
                    )
                )) AS value
            FROM adhoc_deceased_kafka_records
        """)

        
        # Publish to Kafka using foreachPartition for scalability
        headers = [
            ("event-source", b"scanner"),
            ("__TypeId__", b"com.uidai.strot.deceased.refid.notifications"),
        ]
        
        def send_partition(partition):
            producer = KafkaProducer(
                bootstrap_servers=KAFKA_BROKERS.split(","),
                key_serializer=lambda value: str(value).encode("utf-8"),
                value_serializer=lambda value: json.dumps(value).encode("utf-8") if isinstance(value, dict) else value,
            )
            try:
                for row in partition:
                    record = row.asDict()
                    producer.send(KAFKA_TOPIC, key=record['key'], value=json.loads(record['value']), headers=headers)
                producer.flush()
            finally:
                producer.close()
        
        spark.table("adhoc_deceased_kafka_payload").foreachPartition(send_partition)
        
        print(
            f"Selected-AUA deceased publisher: published {record_count} Kafka events "
            f"for AUA={selected_aua}, SubAUA={selected_subaua}"
        )
    finally:
        spark.stop()


task = PythonOperator(
    task_id="publish_selected_aua_deceased_events",
    python_callable=publish_selected_aua_deceased_events,
    dag=dag,
)