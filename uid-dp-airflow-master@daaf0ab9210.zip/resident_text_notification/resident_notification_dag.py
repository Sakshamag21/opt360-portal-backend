import json  
import logging  
import os
import sys
from datetime import datetime, date, timedelta
from typing import Dict, Any, Optional  
import pandas as pd  
import mysql.connector  
import grpc  
from kafka import KafkaProducer  
from trino.dbapi import connect  
from airflow import DAG  
from airflow.providers.standard.operators.python import PythonOperator  
from airflow.exceptions import AirflowException  
from google.protobuf.field_mask_pb2 import FieldMask

# ---------------------------------------------------------------------------  
# FINAL FIXES FOR PROTOBUF & GRPC VERSION ERRORS
# ---------------------------------------------------------------------------  
# 1. Add the current folder to Python's path so it can find the pb2 files
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 2. Monkey-patch Protobuf to ignore the strict version mismatch
import google.protobuf.runtime_version
google.protobuf.runtime_version._ReportVersionError = lambda msg: None

# 3. Trick gRPC into thinking version 999.0.0 is installed to bypass the 1.83 vs 1.84 check
grpc.__version__ = "999.0.0"

# 4. Now safely import the pb2 files
import resident_info_pb2  
import resident_info_pb2_grpc  
# ---------------------------------------------------------------------------  

logger = logging.getLogger(__name__)  
logger.setLevel(logging.INFO)  

# ---------------------------------------------------------------------------  
# Configurations
# ---------------------------------------------------------------------------  
trino_host = "10.10.116.75"  
trino_port = 8080  
trino_user = "opt_master_updt"  

# MySQL Configs for refid -> uid lookup
connection_url = "10.10.126.50"  
mysql_port = 3306
admin_user = "data_platform_R"  
admin_password = "Data_p!atform_7634"  
mysql_database = "index_master"  

# gRPC Configs
GRPC_HOST = "10.10.116.204"  
GRPC_PORT = 8085  

# Kafka Configs (Full cluster list)
KAFKA_BOOTSTRAP_SERVERS = [
    "10.10.105.225:9092", "10.10.106.171:9092", "10.10.107.110:9092",
    "10.10.105.75:9092", "10.10.105.98:9092", "10.10.105.238:9092",
    "10.10.107.130:9092", "10.10.105.33:9092", "10.10.106.195:9092",
    "10.10.106.144:9092", "10.10.105.227:9092"
]  

KAFKA_TOPIC = "COMMAND.STROT.RCS.REQUEST"  

# ---------------------------------------------------------------------------  
# Core Pipeline Functions  
# ---------------------------------------------------------------------------  
def trino_query_db(query: str) -> Dict[str, Any]:  
    conn = None
    try:
        conn = connect(host=trino_host, port=trino_port, user=trino_user)  
        cur = conn.cursor()  
        cur.execute(query)  
        body = cur.fetchall()  
        if not body:  
            return {"df": pd.DataFrame()}  
        cols = [i[0] for i in cur.description]  
        return {"df": pd.DataFrame(body, columns=cols)}  
    finally:
        if conn:
            conn.close()

def resolve_uid_from_refid(cursor, ref_id: str) -> Optional[str]:  
    table_suffix = ref_id[:2]  
    table_name = f"ref_index_{table_suffix}"  
    query = f"SELECT uid FROM {table_name} WHERE refid = %s"  
    cursor.execute(query, (ref_id,))  
    result = cursor.fetchone()  
    return result[0] if result else None  

def fetch_resident_info(stub: resident_info_pb2_grpc.ResidentInfoSearchServiceStub, uid: str) -> Dict[str, str]:  
    request = resident_info_pb2.GetResidentInfoRequest(  
        uid=uid,  
        field_mask=FieldMask(paths=["mobile_number", "email_id"])  
    )  
    try:  
        response = stub.GetResidentInfo(request, timeout=5)  
        return {  
            "mobile": getattr(response, "mobile_number", ""),  
            "email": getattr(response, "email_id", "")         
        }  
    except Exception as e:  
        logger.error(f"gRPC error for resolved UID: {e}")  
        return {"mobile": "", "email": ""}  

def format_kafka_payload(uid: str, mobile: str, email: str, event_name: str) -> Dict[str, Any]:  
    masked_uid = f"{'X' * max(0, len(uid) - 4)}{uid[-4:]}" if len(uid) >= 4 else "XXXX"  

    return {  
        "residentId": uid,  
        "appName": "ENROLMENT",  
        "idType": "uid",  
        "event": event_name,  
        "mobile": mobile,  
        "email": email,  
        "channel": [  
            {  
                "channel": "SMS",  
                "language": "english"  
            }  
        ],  
        "additionalInfo": {  
            "maskedUid": masked_uid
        }  
    }  

def get_event_based_on_date(notif_date_val) -> Optional[str]:
    today = date.today()
    if isinstance(notif_date_val, str):
        try:
            notif_date = datetime.strptime(notif_date_val.split(" ")[0], '%Y-%m-%d').date()
        except ValueError:
            return None
    elif isinstance(notif_date_val, date):
        if hasattr(notif_date_val, 'date'):
            notif_date = notif_date_val.date()
        else:
            notif_date = notif_date_val
    else:
        return None

    delta_days = (today - notif_date).days
    if delta_days < 0:
        return None
    if delta_days <= 7:
        return "FINAL_REM_FOR_BIO_UPDATE"
    elif delta_days <= 15:
        return "REM_ONE_FOR_BIO_UPDATE"
    elif delta_days <= 30:
        return "ACTN_REQ_FOR_FACE_AUTH"
    return None

def process_resident_notifications():  
    trino_query = "SELECT enrolment_reference_id, date_for_notification FROM flink_stream.stream_enu.enu_deceased_status_change_notifier_V1"  
    result = trino_query_db(trino_query)  

    if "df" not in result or result["df"].empty:  
        logger.info("No enrolment reference IDs found.")  
        return  

    mysql_conn = mysql.connector.connect(  
        host=connection_url,  
        port=mysql_port,
        user=admin_user,  
        password=admin_password,  
        database=mysql_database  
    )  
    cursor = mysql_conn.cursor()  

    grpc_channel = grpc.insecure_channel(f"{GRPC_HOST}:{GRPC_PORT}")  
    grpc_stub = resident_info_pb2_grpc.ResidentInfoSearchServiceStub(grpc_channel)  

    producer = KafkaProducer(  
        bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,  
        value_serializer=lambda v: json.dumps(v).encode("utf-8")  
    )  

    try:  
        for index, row in result["df"].iterrows():
            ref_id = str(row["enrolment_reference_id"]) if pd.notna(row["enrolment_reference_id"]) else None
            notif_date = row["date_for_notification"]
            
            if not ref_id or len(ref_id) < 2:  
                continue  

            event_name = get_event_based_on_date(notif_date)
            if not event_name:
                logger.info(f"Skipping ref_id {ref_id}: Date {notif_date} is outside the 30-day window.")
                continue

            uid = resolve_uid_from_refid(cursor, ref_id)  
            if not uid:  
                continue  

            resident_data = fetch_resident_info(grpc_stub, uid)  

            if not resident_data["mobile"]:
                logger.warning(f"Skipping ref_id {ref_id}: No mobile number found in gRPC for UID {uid}.")
                continue

            payload = format_kafka_payload(  
                uid=uid,  
                mobile=resident_data["mobile"],  
                email=resident_data["email"],
                event_name=event_name
            )  

            producer.send(KAFKA_TOPIC, value=payload)  
            logger.info(f"Sent Kafka message to topic '{KAFKA_TOPIC}' for ref_id {ref_id} with event {event_name}")

        producer.flush()  
    finally:  
        cursor.close()  
        mysql_conn.close()  
        grpc_channel.close()  
        producer.close()  

# ---------------------------------------------------------------------------  
# Airflow DAG Definition  
# ---------------------------------------------------------------------------  
default_args = {  
    'owner': 'Piyush Singh',  
    'depends_on_past': False,  
    'start_date': datetime(2026, 8, 12),  
    'email': ['techexe11.yp26@uidai.net.in'],  
    'email_on_failure': True,  
    'email_on_retry': True,  
    'retries': 1,  
}  

dag = DAG(  
    'resident_text_notification_dag',  
    default_args=default_args,  
    schedule="0 8 * * *",  # <-- CHANGED: This means run at 8:00 AM every day.
    catchup=False,  
    max_active_tasks=1,  
)  

process_notifications_task = PythonOperator(  
    task_id='process_resident_notifications_task',  
    python_callable=process_resident_notifications,  
    dag=dag,  
)