"""
Upload the operator360/ directory to S3, preserving subdirectory structure.

S3 target: s3://prd-bi-data-platform-uploads/af_dags_hdc/operator360/

Run this from any machine that has boto3 installed:
    python upload_operator360_to_s3.py

Or from the Airflow server / a pod with boto3.
"""
import os
import boto3
from pathlib import Path

# ── Config ──────────────────────────────────────────────────────────────
S3_BUCKET = "prd-bi-data-platform-uploads"
S3_PREFIX = "af_dags_hdc/operator360/"
LOCAL_DIR = os.path.join(os.path.dirname(__file__), "operator360")

CEPH_ENDPOINT = "http://10.10.103.12:425"
AWS_ACCESS_KEY = "9S0KLIQO7T2XCNGH4P4A"
AWS_SECRET_KEY = "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4"
# ────────────────────────────────────────────────────────────────────────

s3 = boto3.client(
    "s3",
    endpoint_url=CEPH_ENDPOINT,
    aws_access_key_id=AWS_ACCESS_KEY,
    aws_secret_access_key=AWS_SECRET_KEY,
)

local_root = Path(LOCAL_DIR)
if not local_root.exists():
    print(f"ERROR: {LOCAL_DIR} does not exist")
    raise SystemExit(1)

uploaded = 0
skipped = 0

for filepath in sorted(local_root.rglob("*.py")):
    # Relative path preserves subdirectory structure on S3
    relative = filepath.relative_to(local_root.parent)
    s3_key = S3_PREFIX + str(relative).replace("\\", "/")

    s3.upload_file(str(filepath), S3_BUCKET, s3_key)
    print(f"  ✓ {relative}  →  s3://{S3_BUCKET}/{s3_key}")
    uploaded += 1

# Also upload the JSON metadata file if it exists
for jsonpath in sorted(local_root.glob("*.json")):
    relative = jsonpath.relative_to(local_root.parent)
    s3_key = S3_PREFIX + str(relative).replace("\\", "/")
    s3.upload_file(str(jsonpath), S3_BUCKET, s3_key)
    print(f"  ✓ {relative}  →  s3://{S3_BUCKET}/{s3_key}")
    uploaded += 1

print(f"\nDone. Uploaded {uploaded} files to s3://{S3_BUCKET}/{S3_PREFIX}")
