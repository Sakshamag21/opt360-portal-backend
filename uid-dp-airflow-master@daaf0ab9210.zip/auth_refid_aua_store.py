from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from pyspark.sql import SparkSession
from strot_alert_notification import alert_failure_callback, configure

configure(channel="dataplatformtesting")

JOB_NAME = "auth_refid_aua_store"
SPARK_CONNECT_URL = "sc://spark-connect-service.strot-spark.svc.cluster.local:15002"
SOURCE_TABLE = "flink_stream.stream_auth.auth_txn_raw_union_v1"
PAIR_TABLE = "warm_store.refid_store.refid_subaua_store"

default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": datetime(2026, 9, 28),
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "on_failure_callback": alert_failure_callback,
}

dag = DAG(
    JOB_NAME,
    default_args=default_args,
    description="Daily incremental refid/sub-AUA pair-table update via Spark Connect",
    schedule="0 6 * * *",
    catchup=False,
    tags=["AUTH", "refid-subaua"],
)


def update_refid_subaua_pairs():
    spark = SparkSession.builder.remote(SPARK_CONNECT_URL).appName(
        "refid-subaua-daily-update"
    ).getOrCreate()

    def validate_table(table_name, required_columns):
        resolved_schema = spark.sql(f"SELECT * FROM {table_name}").schema
        available_columns = {field.name.lower() for field in resolved_schema.fields}
        missing_columns = {
            column_name for column_name in required_columns
            if column_name.lower() not in available_columns
        }
        if missing_columns:
            raise RuntimeError(
                f"Table {table_name} is missing columns: {sorted(missing_columns)}. "
                f"Available columns: {[field.name for field in resolved_schema.fields]}"
            )

    try:
        validate_table(
            SOURCE_TABLE,
            {"enrolmentreferenceid", "sa", "reqdatetime", "event_timestamp", "authresult"},
        )
        validate_table(PAIR_TABLE, {"refid", "subaua", "last_request_time"})

        # Pick last_updated_date from PAIR_TABLE store
        last_updated_date = spark.sql(f"""
            SELECT MAX(last_request_time) AS last_request_time
            FROM {PAIR_TABLE}
        """).first().last_request_time
        if last_updated_date is None:
            raise RuntimeError(
                f"Cannot derive an incremental start date: {PAIR_TABLE} has no last_request_time."
            )

        # Calculate window: from store's last_updated_date till yesterday (exclude today)
        window_start = last_updated_date.date()
        today = datetime.now().date()
        window_end = today - timedelta(days=1)  # Yesterday only, not today
        if window_start > window_end:
            print(
                f"Pair table is current through {window_start}; "
                f"scheduled cutoff is {window_end}. Skipping update."
            )
            return

        print(f"Updating {PAIR_TABLE} through {window_end}")
        spark.sql(f"""
            INSERT INTO {PAIR_TABLE}
            SELECT
                incoming.refid,
                incoming.subaua,
                incoming.first_seen_time AS last_request_time
            FROM (
                SELECT
                    enrolmentreferenceid AS refid,
                    sa AS subaua,
                    MIN(reqdatetime) AS first_seen_time
                FROM {SOURCE_TABLE}
                WHERE authresult = 'y'
                  AND event_timestamp >= DATE '{window_start.isoformat()}' + INTERVAL 1 DAY
                  AND event_timestamp < DATE '{window_end.isoformat()}' + INTERVAL 1 DAY
                  AND enrolmentreferenceid IS NOT NULL
                  AND sa IS NOT NULL
                  AND reqdatetime IS NOT NULL
                GROUP BY enrolmentreferenceid, sa
            ) AS incoming
            LEFT ANTI JOIN {PAIR_TABLE} AS existing
              ON incoming.refid = existing.refid
             AND incoming.subaua = existing.subaua
        """)
        print(f"Completed pair-table update through {window_end}")
    finally:
        spark.stop()


task = PythonOperator(
    task_id="update_refid_subaua_pairs",
    python_callable=update_refid_subaua_pairs,
    dag=dag,
)