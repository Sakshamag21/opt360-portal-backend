import json
from datetime import datetime

from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from pyspark.sql import SparkSession
from kafka import KafkaProducer
from strot_alert_notification import alert_failure_callback, configure

configure(channel="dataplatformtesting")

JOB_NAME = "uid_status_kafka_publish"
SPARK_CONNECT_URL = "sc://spark-connect-service.strot-spark.svc.cluster.local:15002"
STATUS_TABLE = "flink_stream.temp.uid_master_status_key_change_v1"
UID_MASTER_TABLE = "strot.mysql_uid_v2.uid_master"
ORIGIN_TRACKER_TABLE = "strot.mysql_uid_v2.uid_origin_tracker"
PAIR_TABLE = "warm_store.refid_store.refid_subaua_store"
KAFKA_TOPIC = "STROT.DECEASED.NOTIFY.V1"
KAFKA_BROKERS = ",".join([
    "10.10.105.225:9092", "10.10.106.171:9092", "10.10.107.110:9092",
    "10.10.105.75:9092", "10.10.105.98:9092", "10.10.105.238:9092",
    "10.10.107.130:9092", "10.10.105.33:9092", "10.10.106.195:9092",
    "10.10.105.227:9092",
])
UID_STATUS_CODES = [3, 4, 6, 8, 24, 25, 28, 32, 40, 41, 42, 43, 44, 45, 46, 49, 50, 51, 52, 53, 66, 67, 68, 69, 70, 71, 72, 73, 98, 99]
MYSQL_URL = "jdbc:mysql://10.10.126.51:3306/uidmasterv1_1"
MYSQL_USERNAME = "data_platform_R"
MYSQL_PASSWORD = "Data_p!atform_7634"

default_args = {
    "owner": "Goverdhan",
    "depends_on_past": False,
    "start_date": datetime(2026, 9, 1),
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "on_failure_callback": alert_failure_callback,
}

dag = DAG(
    JOB_NAME,
    default_args=default_args,
    description="Daily UID status Kafka publisher via Spark Connect",
    schedule="0 6 * * *",
    catchup=False,
    tags=["UID", "status-change", "kafka", "spark-connect"],
)


def publish_uid_status_changes():
    spark = SparkSession.builder.remote(SPARK_CONNECT_URL).appName(JOB_NAME).getOrCreate()

    def read_mysql(table_name):
        return spark.read.format("jdbc").option("url", MYSQL_URL).option(
            "dbtable", table_name
        ).option("user", MYSQL_USERNAME).option("password", MYSQL_PASSWORD).option(
            "driver", "com.mysql.cj.jdbc.Driver"
        ).load()

    try:
        status_changes = spark.sql(f"""
            SELECT DISTINCT uid, CAST(after_status_key AS STRING) AS code
            FROM {STATUS_TABLE}
            WHERE (is_notified IS NULL OR is_notified = 0)
              AND to_date(event_timestamp) >= DATE '2026-10-01'
              AND (before_status_key IN ({','.join(map(str, UID_STATUS_CODES))})
                   OR after_status_key IN ({','.join(map(str, UID_STATUS_CODES))}))
        """)
        pending_count = status_changes.count()
        print(f"UID status publisher: {pending_count} pending status changes")
        if pending_count == 0:
            return

        organizations = read_mysql("organization")
        subauas = organizations.selectExpr("org_code AS subaua", "org_key AS subaua_org_key")
        associations = read_mysql("org_association").selectExpr("from_org_key", "to_org_key AS aua_org_key")
        auas = organizations.selectExpr("org_key AS aua_org_key", "org_code AS actual_aua")

        status_changes.createOrReplaceTempView("pending_status_changes")
        subauas.createOrReplaceTempView("subaua_organizations")
        associations.createOrReplaceTempView("org_associations")
        auas.createOrReplaceTempView("aua_organizations")
        records = spark.sql(f"""
            WITH matched_pairs AS (
                SELECT DISTINCT changes.uid, changes.code, CAST(master.res_dod AS STRING) AS res_dod,
                       tracker.refid, pairs.subaua
                FROM pending_status_changes changes
                JOIN {UID_MASTER_TABLE} master ON master.uid = changes.uid
                JOIN {ORIGIN_TRACKER_TABLE} tracker ON tracker.uid = changes.uid AND tracker.enr_status = 'C'
                JOIN {PAIR_TABLE} pairs ON pairs.refid = tracker.refid
            ),
            mapped_pairs AS (
                SELECT matched_pairs.*, COALESCE(aua_org.actual_aua, matched_pairs.subaua) AS aua
                FROM matched_pairs
                LEFT JOIN subaua_organizations subaua_org ON subaua_org.subaua = matched_pairs.subaua
                LEFT JOIN org_associations association ON association.from_org_key = subaua_org.subaua_org_key
                LEFT JOIN aua_organizations aua_org ON aua_org.aua_org_key = association.aua_org_key
            ),
            one_refid_per_uid AS (
                SELECT uid, MIN(refid) AS refid FROM mapped_pairs GROUP BY uid
            )
            SELECT DISTINCT mapped_pairs.uid, selected.refid, mapped_pairs.code, mapped_pairs.res_dod,
                            mapped_pairs.aua, mapped_pairs.subaua
            FROM mapped_pairs
            JOIN one_refid_per_uid selected ON selected.uid = mapped_pairs.uid
        """)
        record_count = records.count()
        print(f"UID status publisher: {record_count} Kafka events to publish")
        if record_count == 0:
            return

        records.createOrReplaceTempView("uid_status_kafka_records")
        spark.sql(f"""
            CREATE OR REPLACE TEMP VIEW uid_status_kafka_payload AS
            SELECT
                CONCAT(refid, subaua) AS key,
                to_json(named_struct(
                    'eventId', CONCAT(refid, subaua),
                    'eventTimestamp', date_format(current_timestamp(), "yyyy-MM-dd'T'HH:mm:ss'Z'"),
                    'version', '1.0',
                    'category', 'KYC_UPDATE',
                    'data', named_struct(
                        'uid', uid, 'refid', refid, 'uidStatus', code, 'csrTimestamp', res_dod,
                        'auaDetails', array(named_struct('aua_code', aua, 'sub_aua_code', subaua))
                    )
                )) AS value
            FROM uid_status_kafka_records
        """)
        # Publish to Kafka using foreachPartition for scalability
        headers = [
            ("event-source", b"scanner"),
            ("__TypeId__", b"com.uidai.strot.deceased.refid.notifications"),
        ]
        
        def send_partition(partition):
            producer = KafkaProducer(
                bootstrap_servers=KAFKA_BROKERS.split(","),
                key_serializer=lambda value: str(value).encode("utf-8"),
                value_serializer=lambda value: json.dumps(value).encode("utf-8") if isinstance(value, dict) else value,
            )
            try:
                for row in partition:
                    record = row.asDict()
                    producer.send(KAFKA_TOPIC, key=record['key'], value=json.loads(record['value']), headers=headers)
                producer.flush()
            finally:
                producer.close()
        
        spark.table("uid_status_kafka_payload").foreachPartition(send_partition)
        print(f"UID status publisher: published {record_count} Kafka events")

        spark.sql(f"""
            MERGE INTO {STATUS_TABLE} target
            USING (SELECT DISTINCT uid FROM uid_status_kafka_records) source
            ON target.uid = source.uid AND (target.is_notified IS NULL OR target.is_notified = 0)
            WHEN MATCHED THEN UPDATE SET is_notified = 1
        """)
        print("UID status publisher: marked published UIDs as notified")
    finally:
        spark.stop()


task = PythonOperator(
    task_id="publish_uid_status_changes",
    python_callable=publish_uid_status_changes,
    dag=dag,
)