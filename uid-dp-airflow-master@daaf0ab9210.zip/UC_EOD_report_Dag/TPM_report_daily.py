import datetime
import pendulum
import pandas as pd
import smtplib
from trino.dbapi import connect
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from airflow import DAG
from airflow.operators.python import PythonOperator

# --- Settings ---
TRINO_HOST = "10.10.116.75"
TRINO_PORT = 8080
TRINO_USER = "jupyter_amit"

SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25
SENDER_EMAIL = "airflow@uidai.net.in"

# FOR TESTING: All RO emails will go to this address only
TEST_RECIPIENT_EMAILS = ["data.analyst-tc@uidai.net.in", "devfsd17-tc@uidai.net.in", "hoe.dev-tc@uidai.net.in", "platfm.arch1-tc@uidai.net.in"]

# --- SQL Queries ---
SUMMARY_QUERY = """
WITH active_machines AS (
    SELECT DISTINCT
        rt.machine_code, rt.station_id, rt.registrar_id, rt.agency_code
    FROM strot.mysql_uid_v2.request_tracker rt
    WHERE rt.creation_date >= NOW() - INTERVAL '60' DAY
      AND rt.machine_code IS NOT NULL
      AND rt.source = 'UC'
),
active_deduped AS (
    SELECT machine_code, station_id, registrar_id, agency_code,
        ROW_NUMBER() OVER (PARTITION BY machine_code ORDER BY station_id, registrar_id, agency_code) AS rn
    FROM active_machines
),
active_one_per_machine AS (
    SELECT machine_code, station_id, registrar_id, agency_code
    FROM active_deduped WHERE rn = 1
),
telemetry_aggregated AS (
    SELECT
        pdata_id AS machine_code,
        MAX(CASE WHEN error LIKE '%VERSION_ERROR: no compatible TPM found on this system%' THEN 1 ELSE 0 END) AS has_tpm_error,
        MAX(CASE WHEN error LIKE '%TPM_Version:1%' THEN 1 ELSE 0 END) AS has_tpm_v1
    FROM flink_stream.stream_enu.telemetry_uc
    WHERE ets >= NOW() - INTERVAL '60' DAY
      AND pdata_id IS NOT NULL
    GROUP BY pdata_id
)
SELECT
    CURRENT_DATE AS "Date",
    CONCAT('RO-', CAST(o_ea.ro_key AS varchar), ' / ', ro.ro_name) AS "RO / State Office",
    am.registrar_id AS "Registrar Code",
    o_reg.org_name AS "Registrar Name",
    am.agency_code AS "EA Code",
    o_ea.org_name AS "EA Name",
    COUNT(DISTINCT am.station_id) AS "Station Count",
    COUNT(DISTINCT CASE WHEN srh.attestation_state LIKE '%ATTESTED%' THEN am.station_id END) AS "TPM Attestation Completed (Yes)",
    COUNT(DISTINCT CASE WHEN srh.attestation_state NOT LIKE '%ATTESTED%' OR srh.attestation_state IS NULL THEN am.station_id END) AS "TPM Attestation Completed (NO)",
    COUNT(DISTINCT CASE WHEN srh.attestation_state NOT LIKE '%ATTESTED%' OR srh.attestation_state IS NULL THEN am.station_id END) AS "Attestation Pending Count as on current date",
    CAST(NULL AS varchar) AS "Attestation Pending Count as on previous date",
    COUNT(DISTINCT CASE 
        WHEN (srh.ek_pub_hash IS NULL OR srh.ek_pub_hash = '') 
          AND COALESCE(ta.has_tpm_v1, 0) = 0 
        THEN am.station_id 
    END) AS "TPM Unavailable (Yes)",
    COUNT(DISTINCT CASE 
        WHEN (srh.ek_pub_hash IS NOT NULL AND srh.ek_pub_hash != '') OR ta.has_tpm_v1 = 1 
        THEN am.station_id 
    END) AS "TPM Unavailable (NO)"
FROM active_one_per_machine am
LEFT JOIN mysql_uidmasterv1.uidmasterv1_1.station_reg_helper srh
    ON am.registrar_id = srh.registrar_id
    AND am.agency_code = srh.enrollment_agency_code
    AND am.station_id = srh.station_id
LEFT JOIN mysql_uidmasterv1.uidmasterv1_1.organization o_ea
    ON am.agency_code = o_ea.org_code
LEFT JOIN mysql_uidmasterv1.uidmasterv1_1.organization o_reg
    ON am.registrar_id = o_reg.org_code
LEFT JOIN mysql_uidmasterv1.uidmasterv1_1.regional_office ro
    ON o_ea.ro_key = ro.ro_key
LEFT JOIN telemetry_aggregated ta
    ON am.machine_code = ta.machine_code
GROUP BY
    o_ea.ro_key, ro.ro_name, am.registrar_id, o_reg.org_name, am.agency_code, o_ea.org_name
ORDER BY
    o_ea.ro_key, am.registrar_id, am.agency_code
"""

DETAILED_QUERY = """
WITH active_machines AS (
    SELECT DISTINCT
        rt.machine_code, rt.station_id, rt.registrar_id, rt.agency_code
    FROM strot.mysql_uid_v2.request_tracker rt
    WHERE rt.creation_date >= NOW() - INTERVAL '60' DAY
      AND rt.machine_code IS NOT NULL
      AND rt.source = 'UC'
),
active_deduped AS (
    SELECT machine_code, station_id, registrar_id, agency_code,
        ROW_NUMBER() OVER (PARTITION BY machine_code ORDER BY station_id, registrar_id, agency_code) AS rn
    FROM active_machines
),
active_one_per_machine AS (
    SELECT machine_code, station_id, registrar_id, agency_code
    FROM active_deduped WHERE rn = 1
),
telemetry_aggregated AS (
    SELECT
        pdata_id AS machine_code,
        MAX(CASE WHEN error LIKE '%TPM_Version:1%' THEN 1 ELSE 0 END) AS has_tpm_v1
    FROM flink_stream.stream_enu.telemetry_uc
    WHERE ets >= NOW() - INTERVAL '60' DAY
      AND pdata_id IS NOT NULL
    GROUP BY pdata_id
),
ea_admin_info AS (
    SELECT 
        u.user_org_key, 
        MAX(u.user_name) AS admin_name, 
        MAX(c.phone1) AS admin_phone, 
        MAX(c.email_id1) AS admin_email
    FROM mysql_uidmasterv1.uidmasterv1_1.user u
    LEFT JOIN mysql_uidmasterv1.uidmasterv1_1.contact c ON u.user_contact_key = c.contact_key
    WHERE u.user_type_key = 4 AND u.user_status = '1'
    GROUP BY u.user_org_key
)
SELECT
    CURRENT_DATE AS "Date",
    CONCAT('RO-', CAST(o_ea.ro_key AS varchar), ' / ', ro.ro_name) AS "RO / State Office",
    am.registrar_id AS "Registrar Code",
    o_reg.org_name AS "Registrar Name",
    am.agency_code AS "EA Code",
    o_ea.org_name AS "EA Name",
    am.station_id AS "Station-ID",
    CASE 
        WHEN srh.attestation_state LIKE '%ATTESTED%' THEN 'Y' 
        ELSE 'N' 
    END AS "TPM Attestation Completed (Y/N)",
    CASE 
        WHEN srh.ek_pub_hash IS NOT NULL AND srh.ek_pub_hash != '' THEN 'TPM 2'
        WHEN ta.has_tpm_v1 = 1 THEN 'TPM 1'
        ELSE 'unavailable' 
    END AS "TPM Version",
    am.machine_code AS "Machine-Code",
    ea_admin.admin_name AS "EA Admin Name",
    ea_admin.admin_phone AS "EA Admin Phone",
    ea_admin.admin_email AS "EA Admin Email"
FROM active_one_per_machine am
LEFT JOIN mysql_uidmasterv1.uidmasterv1_1.station_reg_helper srh
    ON am.registrar_id = srh.registrar_id
    AND am.agency_code = srh.enrollment_agency_code
    AND am.station_id = srh.station_id
LEFT JOIN mysql_uidmasterv1.uidmasterv1_1.organization o_ea
    ON am.agency_code = o_ea.org_code
LEFT JOIN mysql_uidmasterv1.uidmasterv1_1.organization o_reg
    ON am.registrar_id = o_reg.org_code
LEFT JOIN mysql_uidmasterv1.uidmasterv1_1.regional_office ro
    ON o_ea.ro_key = ro.ro_key
LEFT JOIN telemetry_aggregated ta
    ON am.machine_code = ta.machine_code
LEFT JOIN ea_admin_info ea_admin
    ON o_ea.org_key = ea_admin.user_org_key
ORDER BY am.registrar_id, am.agency_code, am.station_id
"""

def fetch_tpm_data():
    print("Connecting to Trino and fetching Summary Data...")
    conn = connect(host=TRINO_HOST, port=TRINO_PORT, user=TRINO_USER, catalog=None, schema=None)
    cur = conn.cursor()
    
    # 1. Fetch Summary
    cur.execute(SUMMARY_QUERY)
    summary_body = cur.fetchall()
    summary_cols = [i[0] for i in cur.description]
    df_summary = pd.DataFrame(summary_body, columns=summary_cols)
    
    print("Fetching Detailed Raw Data...")
    # 2. Fetch Detailed
    cur.execute(DETAILED_QUERY)
    detailed_body = cur.fetchall()
    detailed_cols = [i[0] for i in cur.description]
    df_detailed = pd.DataFrame(detailed_body, columns=detailed_cols)
    
    conn.close()

    if df_summary.empty:
        print("No data returned from Trino.")
        return None, None, []

    # Apply Leading Zeros and FORCE as string to prevent Pandas from converting to int
    df_summary['Registrar Code'] = df_summary['Registrar Code'].astype(str).str.split('.').str[0].str.zfill(3)
    df_summary['EA Code'] = df_summary['EA Code'].astype(str).str.split('.').str[0].str.zfill(4)
    
    df_detailed['Registrar Code'] = df_detailed['Registrar Code'].astype(str).str.split('.').str[0].str.zfill(3)
    df_detailed['EA Code'] = df_detailed['EA Code'].astype(str).str.split('.').str[0].str.zfill(4)
    df_detailed['Station-ID'] = df_detailed['Station-ID'].astype(str).str.split('.').str[0].str.zfill(5)

    # Save Global Files to /tmp/
    summary_file = "/tmp/tpm_summary_global.csv"
    detailed_file = "/tmp/tpm_detailed_global.csv"
    df_summary.to_csv(summary_file, index=False)
    df_detailed.to_csv(detailed_file, index=False)
    
    # Get unique list of ROs to send emails to
    unique_ros = df_summary['RO / State Office'].unique().tolist()
    print(f"Found {len(unique_ros)} unique ROs to process.")
    
    return summary_file, detailed_file, unique_ros

def send_ro_emails(**kwargs):
    summary_file, detailed_file, unique_ros = kwargs['ti'].xcom_pull(task_ids='fetch_tpm_data')
    
    if not summary_file:
        print("No data files generated. Skipping emails.")
        return

    # Read the global files, explicitly forcing ID columns to string to preserve leading zeros
    df_summary_global = pd.read_csv(summary_file, dtype={'Registrar Code': str, 'EA Code': str})
    df_detailed_global = pd.read_csv(detailed_file, dtype={'Registrar Code': str, 'EA Code': str, 'Station-ID': str})

    today_str = datetime.datetime.now().strftime('%d_%b_%Y')
    
    for ro_name in unique_ros:
        print(f"--- Processing {ro_name} ---")
        
        # Filter data for this specific RO
        df_summary_ro = df_summary_global[df_summary_global['RO / State Office'] == ro_name].copy()
        df_detailed_ro = df_detailed_global[df_detailed_global['RO / State Office'] == ro_name].copy()
        
        # Create a safe filename for the RO
        safe_ro_name = ro_name.replace(' / ', '_').replace(' ', '_').replace('/', '-')
        csv_filename = f"/tmp/TPM_Detailed_Raw_Data_{safe_ro_name}_{today_str}.csv"
        df_detailed_ro.to_csv(csv_filename, index=False)
        
        # --- CREATE TOTAL ROW FOR SUMMARY ---
        # Identify numeric columns to sum
        numeric_cols = df_summary_ro.select_dtypes(include=['number']).columns
        total_row = pd.DataFrame([{'RO / State Office': 'TOTAL'}])
        
        for col in df_summary_ro.columns:
            if col in numeric_cols:
                total_row[col] = df_summary_ro[col].sum()
            elif col != 'RO / State Office':
                total_row[col] = "" # Leave text columns blank for the total row
                
        # Append total row to the summary dataframe
        df_summary_ro_with_total = pd.concat([df_summary_ro, total_row], ignore_index=True)
        
        # Convert Summary to HTML Table for Email Body
        html_table = df_summary_ro_with_total.to_html(index=False, classes='table table-striped', border=0)
        
        # Construct Email
        msg = MIMEMultipart()
        msg['From'] = SENDER_EMAIL
        msg['To'] = ", ".join(TEST_RECIPIENT_EMAILS) # Using test list for now
        msg['Subject'] = f"TPM Attestation Report - {ro_name} - {today_str}"
        
        body = f"""
        <html>
        <head>
            <style>
                table {{ border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }}
                th, td {{ border: 1px solid #dddddd; text-align: left; padding: 8px; }}
                th {{ background-color: #f2f2f2; }}
                tr:last-child td {{ font-weight: bold; background-color: #e6e6e6; }} <!-- Bold the Total row -->
            </style>
        </head>
        <body>
            <p>Dear Team,</p>
            <p>Please find below the TPM Attestation Summary for <b>{ro_name}</b>.</p>
            <p>Detailed raw data is attached as a CSV file.</p>
            <br>
            {html_table}
            <br>
            <p>Regards,<br>Data Platform Team</p>
        </body>
        </html>
        """
        msg.attach(MIMEText(body, 'html'))
        
        # Attach the CSV
        with open(csv_filename, "rb") as attachment:
            part = MIMEApplication(attachment.read(), Name=csv_filename.split("/")[-1])
        part['Content-Disposition'] = f'attachment; filename="{csv_filename.split("/")[-1]}"'
        msg.attach(part)
        
        # Send Email
        try:
            server = smtplib.SMTP(SMTP_HOST, SMTP_PORT)
            server.sendmail(SENDER_EMAIL, TEST_RECIPIENT_EMAILS, msg.as_string())
            server.quit()
            print(f"✅ Email sent successfully for {ro_name}!")
        except Exception as e:
            print(f"❌ Failed to send email for {ro_name}: {e}")

# ==========================================
# DAG DEFINITION
# ==========================================
ist_tz = pendulum.timezone("Asia/Kolkata")

default_args = {
    'owner': 'Amit Kumar',
    'depends_on_past': False,
    'start_date': datetime.datetime(2024, 10, 14, tzinfo=ist_tz),
    'email': ['data.analyst-tc@uidai.net.in'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': datetime.timedelta(minutes=5)
}

dag = DAG(
    'tpm_attestation_daily_ro_report',
    default_args=default_args,
    description='Fetches TPM Attestation data and sends RO-specific emails daily',
    schedule='0 10 * * *',  # Runs daily at 10:00 AM IST
    catchup=False
)

fetch_data_task = PythonOperator(
    task_id='fetch_tpm_data',
    python_callable=fetch_tpm_data,
    dag=dag,
)

send_emails_task = PythonOperator(
    task_id='send_ro_emails',
    python_callable=send_ro_emails,
    dag=dag,
)

fetch_data_task >> send_emails_task