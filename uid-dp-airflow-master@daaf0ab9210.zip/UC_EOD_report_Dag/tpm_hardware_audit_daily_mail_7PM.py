import datetime
import smtplib
import io
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

import pandas as pd
import pendulum
from trino.dbapi import connect
from airflow import DAG
from airflow.operators.python import PythonOperator

# ==========================================
# CONFIGURATION
# ==========================================

# Trino Configuration
trino_host = "10.10.116.75"
trino_port = 8080
trino_user = "airflow_dag_op"
trino_catalog = "flink_stream"
trino_schema = "stream_enu"

# SMTP Configuration
SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25

# Email Recipients (Testing only)
mail_list = ["data.analyst-tc@uidai.net.in"]
cc_list = []  # Kept empty for testing
bcc_list = []

# ==========================================
# QUERY TEMPLATES  
# ==========================================

# 1. Collision Query (Updated with internal fields)
collision_query = '''
SELECT
    CONCAT(incomingregistrarid, '-', incomingagencycode, '-', incomingstationid) AS station,
    incomingekpubhash,
    correspondingekpubhash,
    CONCAT(correspondingregistrarid, '-', correspondingagencycode, '-', correspondingstationid) AS correspondingstationdetails,
    COUNT(*) as attempts
FROM flink_stream.stream_enu.machine_hardware_trust_audit
WHERE event_type = 'CORE_CONNECT_REG_CALL'
AND milestone = 'TPM_COLLISION_ATTEMPT'
AND CAST(event_timestamp AS DATE) BETWEEN CAST('{start_date}' AS DATE) AND CAST('{end_date}' AS DATE)
GROUP BY 1, 2, 3, 4
HAVING COUNT(*) > 9
ORDER BY 5 DESC
'''

# 2. Spoof Query (Updated with internal fields)
spoof_query = '''
SELECT
    CONCAT(incomingregistrarid, '-', incomingagencycode, '-', incomingstationid) AS station,
    incomingekpubhash,
    correspondingekpubhash,
    COUNT(*) as attempts
FROM flink_stream.stream_enu.machine_hardware_trust_audit
WHERE event_type = 'CORE_CONNECT_REG_CALL'
AND milestone = 'TPM_SPOOF_ATTEMPT'
AND CAST(event_timestamp AS DATE) BETWEEN CAST('{start_date}' AS DATE) AND CAST('{end_date}' AS DATE)
GROUP BY 1, 2, 3
HAVING COUNT(*) > 9
ORDER BY 4 DESC
'''

# 3. Re-Registration Query (Updated with internal fields)
rereg_query = '''
SELECT
    CONCAT(incomingregistrarid, '-', incomingagencycode, '-', incomingstationid) AS station,
    incomingekpubhash,
    CONCAT(correspondingregistrarid, '-', correspondingagencycode, '-', correspondingstationid) AS correspondingstationdetails,
    COUNT(*) as attempts
FROM flink_stream.stream_enu.machine_hardware_trust_audit
WHERE event_type = 'CORE_CONNECT_REG_CALL'
AND milestone = 'TPM_RE_REGISTRATION_ATTEMPT'
AND CAST(event_timestamp AS DATE) BETWEEN CAST('{start_date}' AS DATE) AND CAST('{end_date}' AS DATE)
GROUP BY 1, 2, 3
HAVING COUNT(*) > 9
ORDER BY 4 DESC
'''

# 4. Helper Updates Query (No change requested)
helper_updates_query = '''
SELECT
    milestone,
    COUNT(*) as count
FROM flink_stream.stream_enu.machine_hardware_trust_audit
WHERE event_type = 'CORE_CONNECT_REG_CALL'
AND milestone IN ('TPM_NEW_REGISTRATION', 'TPM_UPDATE_PAYLOAD_KEY', 'TPM_UPDATE_OPAQUE_KEYS', 'TPM_UPDATE_STATION_DETAILS', 'TPM_UPDATE_EK_PUB_HASH', 'TPM_COLLISION_MERGE')
AND CAST(event_timestamp AS DATE) BETWEEN CAST('{start_date}' AS DATE) AND CAST('{end_date}' AS DATE)
GROUP BY 1
ORDER BY 2 DESC
'''

# 5. EMS System Errors Query (No change requested)
ems_errors_query = '''
SELECT
    CASE
        WHEN systemerror LIKE '%query did not return a unique result%' THEN 'Duplicate Entry Error'
        WHEN systemerror LIKE '%Duplicate entry%for key %station_reg_helper.machine_id_%' THEN 'Duplicate Machine ID'
        WHEN systemerror LIKE '%Communications link failure%' THEN 'Communications Link Failure (DB)'
        ELSE 'Other Errors'
    END AS error_type,
    COUNT(*) AS error_count
FROM flink_stream.stream_enu.machine_hardware_trust_audit
WHERE event_type = 'CORE_CONNECT_REG_CALL'
AND milestone = 'TPM_REG_SYSTEM_ERROR'
  AND CAST(event_timestamp AS DATE) BETWEEN CAST('{start_date}' AS DATE) AND CAST('{end_date}' AS DATE)
GROUP BY 1
ORDER BY error_count DESC
'''

# ==========================================
# DAG DEFINITION  
# ==========================================
ist_tz = pendulum.timezone("Asia/Kolkata")

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2024, 5, 1, tzinfo=ist_tz),
    'email': ["data.analyst-tc@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': datetime.timedelta(minutes=2)
}

dag_7pm = DAG(
    'tpm_hardware_audit_daily_mail_7PM',
    default_args=default_args,
    description='7PM DAG - TPM Hardware Audit Report (Excel Attachment + Totals in Body)',
    schedule="0 19 * * *",          # Runs at 7:00 PM IST daily
    catchup=False
)

# ==========================================
# HELPERS
# ==========================================

def trino_fetch(query, catalog=trino_catalog, schema=trino_schema,
                host=trino_host, port=trino_port, user=trino_user):
    """Executes Trino query and returns a pandas DataFrame."""
    try:
        conn = connect(host=host, port=port, user=user, catalog=catalog)
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return pd.DataFrame()
        cols = [i[0] for i in cur.description]
        df = pd.DataFrame(body, columns=cols)
        return df
    except Exception as e:
        print(f"Trino extraction failed: {str(e)}")
        return pd.DataFrame()


def build_totals_html_table(df: pd.DataFrame) -> str:
    """Renders dataframe as a styled HTML table for email body."""
    rows_html = ""
    for _, row in df.iterrows():
        header = row['Report Header']
        total = row['Total Count']
        rows_html += (
            f"<tr style='background-color:#ffffff;'>"
            f"<td style='padding:8px 12px;border:1px solid #ccc;'>{header}</td>"
            f"<td style='padding:8px 12px;border:1px solid #ccc;text-align:right;'>{total:,}</td>"
            f"</tr>"
        )

    html = f"""
    <table style="border-collapse:collapse;font-family:Arial,sans-serif;font-size:13px;width:50%;">
        <thead>
            <tr style="background-color:#4472C4;color:#ffffff;">
                <th style="padding:8px 12px;border:1px solid #ccc;text-align:left;">Report Header</th>
                <th style="padding:8px 12px;border:1px solid #ccc;text-align:right;">Total Count</th>
            </tr>
        </thead>
        <tbody>
            {rows_html}
        </tbody>
    </table>
    """
    return html


def send_email_via_smtp(to_email, cc_emails, bcc_emails, html_body, subject, excel_data, filename):
    sender_email = "airflow@uidai.net.in"

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = to_email
    if cc_emails:
        msg['Cc'] = ", ".join(cc_emails)
    msg['Subject'] = subject

    # Attach HTML body
    msg.attach(MIMEText(html_body, 'html'))

    # Attach Excel file
    part = MIMEBase('application', 'vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    part.set_payload(excel_data)
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', f'attachment; filename="{filename}"')
    msg.attach(part)

    recipients = [to_email]
    if cc_emails:
        recipients.extend(cc_emails)
    if bcc_emails:
        recipients.extend(bcc_emails)

    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(sender_email, recipients, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"❌ SMTP Error: {str(e)}")
        return False


# ==========================================
# MAIN TASK
# ==========================================

def fetch_tpm_reports_and_mail(**kwargs):
    current_time_ist = datetime.datetime.now(ist_tz)
    
    # Calculate yesterday's date for the report
    report_date = current_time_ist.date() - datetime.timedelta(days=1)
    report_date_str = report_date.strftime("%d-%m-%Y")
    date_str = report_date.strftime("%Y-%m-%d")
    
    day = report_date.day
    suffix = 'th' if 11 <= day <= 13 else {1: 'st', 2: 'nd', 3: 'rd'}.get(day % 10, 'th')
    full_date_str = f"{day}{suffix} {report_date.strftime('%B %Y')}"

    # ------------------------------------------
    # 1. Execute All 5 Queries
    # ------------------------------------------
    print(f"Fetching data for date: {date_str}")
    
    df_collision = trino_fetch(collision_query.format(start_date=date_str, end_date=date_str))
    df_spoof = trino_fetch(spoof_query.format(start_date=date_str, end_date=date_str))
    df_rereg = trino_fetch(rereg_query.format(start_date=date_str, end_date=date_str))
    df_helper = trino_fetch(helper_updates_query.format(start_date=date_str, end_date=date_str))
    df_errors = trino_fetch(ems_errors_query.format(start_date=date_str, end_date=date_str))

    # ------------------------------------------
    # 2. Calculate Totals for Email Body
    # ------------------------------------------
    total_collision = int(df_collision['attempts'].sum()) if not df_collision.empty else 0
    total_spoof = int(df_spoof['attempts'].sum()) if not df_spoof.empty else 0
    total_rereg = int(df_rereg['attempts'].sum()) if not df_rereg.empty else 0
    total_helper = int(df_helper['count'].sum()) if not df_helper.empty else 0
    total_errors = int(df_errors['error_count'].sum()) if not df_errors.empty else 0

    totals_data = [
        {"Report Header": "TPM Collision Attempt", "Total Count": total_collision},
        {"Report Header": "TPM Spoof Attempt", "Total Count": total_spoof},
        {"Report Header": "TPM Re-registration Attempt", "Total Count": total_rereg},
        {"Report Header": "Station Reg Helper - Updates", "Total Count": total_helper},
        {"Report Header": "EMS System Errors - Core Connect", "Total Count": total_errors}
    ]
    totals_df = pd.DataFrame(totals_data)

    print("Totals calculated:")
    print(totals_df.to_string(index=False))

    # ------------------------------------------
    # 3. Create Multi-Sheet Excel Attachment
    # ------------------------------------------
    print("Generating Excel attachment...")
    output = io.BytesIO()
    
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        # Write DataFrame to specific sheet. If empty, create empty frame with proper headers
        
        # Collision Sheet
        if not df_collision.empty:
            df_collision.to_excel(writer, sheet_name='TPM Collision Attempt', index=False)
        else:
            pd.DataFrame(columns=['station', 'incomingekpubhash', 'correspondingekpubhash', 'correspondingstationdetails', 'attempts']).to_excel(writer, sheet_name='TPM Collision Attempt', index=False)

        # Spoof Sheet
        if not df_spoof.empty:
            df_spoof.to_excel(writer, sheet_name='TPM Spoof Attempt', index=False)
        else:
            pd.DataFrame(columns=['station', 'incomingekpubhash', 'correspondingekpubhash', 'attempts']).to_excel(writer, sheet_name='TPM Spoof Attempt', index=False)

        # Re-registration Sheet
        if not df_rereg.empty:
            df_rereg.to_excel(writer, sheet_name='TPM Re-registration Attempt', index=False)
        else:
            pd.DataFrame(columns=['station', 'incomingekpubhash', 'correspondingstationdetails', 'attempts']).to_excel(writer, sheet_name='TPM Re-registration Attempt', index=False)

        # Helper Updates Sheet
        if not df_helper.empty:
            df_helper.to_excel(writer, sheet_name='Station Reg Helper Updates', index=False)
        else:
            pd.DataFrame(columns=['milestone', 'count']).to_excel(writer, sheet_name='Station Reg Helper Updates', index=False)

        # EMS Errors Sheet
        if not df_errors.empty:
            df_errors.to_excel(writer, sheet_name='EMS System Errors', index=False)
        else:
            pd.DataFrame(columns=['error_type', 'error_count']).to_excel(writer, sheet_name='EMS System Errors', index=False)

    excel_data = output.getvalue()
    attachment_filename = f"TPM_Hardware_Audit_{report_date_str}.xlsx"

    # ------------------------------------------
    # 4. Build HTML Email Body
    # ------------------------------------------
    totals_html_table = build_totals_html_table(totals_df)

    html_body = f"""
    <html>
        <body style="font-family: Arial, sans-serif; color: #333333; line-height: 1.6;">
            <p>Dear All,</p>
            <p>Please find below the <b>Total Counts</b> for the <b>TPM Hardware Audit Report</b> for
               <b>{full_date_str}</b>.</p>
            <br>
            {totals_html_table}
            <br>
            <p>The detailed report for each category is attached as an Excel file (<b>{attachment_filename}</b>) with multiple sheets.</p>
            <br>
            <p>Regards,<br>
            Data Platform Team</p>
            <br>
            <p style="font-size: 11px; color: #888888; font-style: italic;">
                <b>Note:</b> An automated email generated via Airflow. Please reply to this email in case of any discrepancies.
            </p>
        </body>
    </html>
    """

    subject = f"TPM Hardware Audit Report - {report_date_str}"

    # ------------------------------------------
    # 5. Send Email
    # ------------------------------------------
    failed_emails = []
    for target_email in mail_list:
        try:
            success = send_email_via_smtp(
                to_email=target_email,
                cc_emails=cc_list,
                bcc_emails=bcc_list,
                html_body=html_body,
                subject=subject,
                excel_data=excel_data,
                filename=attachment_filename
            )
            if success:
                print(f"✅ Email sent successfully to: {target_email}")
            else:
                print(f"❌ Failed to send email to: {target_email}")
                failed_emails.append(target_email)
        except Exception as mail_error:
            print(f"Network error while sending to {target_email}: {str(mail_error)}")
            failed_emails.append(target_email)

    if failed_emails:
        raise RuntimeError(
            f"DAG FAILED. Could not send email to: {', '.join(failed_emails)}"
        )

    print("✅ DAG execution completed successfully.")


# ==========================================
# TASK
# ==========================================
task_7pm = PythonOperator(
    task_id='tpm_hardware_audit_7PM_task',
    python_callable=fetch_tpm_reports_and_mail,
    dag=dag_7pm,
)

task_7pm