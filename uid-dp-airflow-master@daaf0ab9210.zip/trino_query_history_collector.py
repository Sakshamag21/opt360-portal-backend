import subprocess
import sys
import importlib
import threading
import traceback
import time
import json
import mysql.connector
from datetime import datetime, timedelta, timezone
from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from strot_alert_notification import (
    alert_failure_callback,
    configure
)
configure(channel="dataplatformtesting")

IST = timezone(timedelta(hours=5, minutes=30))

# Install strot_query if not present
package = "strot_query"
try:
    importlib.import_module(package)
except ImportError:
    subprocess.check_call([
        sys.executable, "-m", "pip", "install",
        '--no-cache-dir',
        '--index-url', 'http://10.10.206.59:8080/repository/pypi-local/simple',
        '--trusted-host', '10.10.206.59',
        package
    ])
    importlib.invalidate_caches()
    globals()[package] = importlib.import_module(package)

import trino
import pandas as pd
import strot_query as sq

# Configuration
DESTINATION_HOST = '10.10.116.75'
DEST_TABLE = 'strot.analytics_services.trino_query_history'

# Metastore Configuration for Lock Clearing
METASTORE_HOST = '10.10.106.159'
METASTORE_DB = 'metastore_iceberg'
METASTORE_USER = 'Data_platform_W'
METASTORE_PASSWORD = 'Dataplat_7634'


def clear_hive_locks_for_table(metastore_host, metastore_db, metastore_user, metastore_password, target_db_name, target_table_name):
    """
    GENERIC FUNCTION: Checks and clears Hive locks for a SPECIFIC table only.
    Anyone can import this function and use it by passing their metastore details and target table.
    """
    print(f"[LockCleaner] Checking for locks on {target_db_name}.{target_table_name} in {metastore_host}/{metastore_db}...")
    try:
        connection = mysql.connector.connect(
            host=metastore_host,
            user=metastore_user,
            password=metastore_password,
            database=metastore_db
        )
        cursor = connection.cursor()
        
        # 1. Check for locks ONLY for this specific table
        check_query = f"SELECT HL_LOCK_EXT_ID, HL_DB, HL_TABLE, HL_LOCK_STATE FROM HIVE_LOCKS WHERE HL_TABLE = '{target_table_name}' AND HL_DB = '{target_db_name}'"
        cursor.execute(check_query)
        locks = cursor.fetchall()
        
        if locks:
            print(f"[LockCleaner] ⚠️ Found {len(locks)} stuck lock(s) for {target_db_name}.{target_table_name}. Clearing them...")
            # 2. Delete ONLY the locks for this specific table
            delete_query = f"DELETE FROM HIVE_LOCKS WHERE HL_TABLE = '{target_table_name}' AND HL_DB = '{target_db_name}'"
            cursor.execute(delete_query)
            connection.commit()
            print(f"[LockCleaner] ✅ Successfully cleared locks for {target_db_name}.{target_table_name}.")
        else:
            print(f"[LockCleaner] ✅ No locks found for {target_db_name}.{target_table_name}.")
            
        connection.close()
        return True
    except Exception as e:
        print(f"[LockCleaner] ❌ Error clearing locks: {e}")
        return False


def log(msg, level="INFO"):
    """Centralized logger with timestamp and thread name."""
    ts = datetime.now(IST).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    thread_name = threading.current_thread().name
    print(f"[{ts}] [{level}] [Thread={thread_name}] {msg}")


def safe_val(v):
    """Convert None to SQL NULL string, otherwise wrap in single quotes with escaping."""
    try:
        if v is None or (isinstance(v, float) and pd.isna(v)):
            return "NULL"
        if isinstance(v, (int, float)):
            return str(v)
        s = str(v).replace("'", "''")
        # Truncate extremely long query strings for safety
        if len(s) > 5000:
            s = s[:5000]
            log(f"Truncated long query value to 5000 chars", "WARN")
        return f"'{s}'"
    except Exception as e:
        log(f"ERROR in safe_val for value {repr(v)}: {e}", "ERROR")
        return "NULL"


def get_last_check_times():
    """Queries the destination server to find the last inserted 'created' time for EACH host."""
    log("=" * 80)
    log("STEP 1: Fetching last check times from destination database")
    log(f"Destination host: {DESTINATION_HOST}")
    log(f"Destination table: {DEST_TABLE}")
    log("=" * 80)

    query = f"""
        SELECT host, max(created) AS last_created
        FROM {DEST_TABLE}
        GROUP BY host
    """
    log(f"Watermark query:\n{query}")

    try:
        t0 = time.time()
        result = sq.query(query, host=DESTINATION_HOST)
        elapsed = time.time() - t0
        log(f"sq.query returned in {elapsed:.2f}s")
        log(f"Result type: {type(result)}")
        log(f"Result keys: {list(result.keys()) if isinstance(result, dict) else 'N/A'}")

        if isinstance(result, dict):
            for k, v in result.items():
                if k == 'df':
                    log(f"  result['df'] shape: {v.shape if hasattr(v, 'shape') else 'N/A'}")
                elif k == 'data':
                    log(f"  result['data'] length: {len(v) if v is not None else 'None'}")
                else:
                    log(f"  result['{k}'] = {repr(v)[:200]}")

        if 'df' in result and not result['df'].empty:
            df_times = result['df']
            log(f"Watermark rows fetched:\n{df_times.to_string()}")
            time_dict = {}
            for _, row in df_times.iterrows():
                host_val = row['host']
                ts = pd.to_datetime(row['last_created'])

                # Convert to IST if it was stored as naive UTC from previous runs
                if ts.tzinfo is None:
                    ts = ts.tz_localize('UTC')
                ts = ts.tz_convert(IST)

                # Format as string without offset to keep Trino 'timestamp' literal happy
                time_dict[host_val] = ts.strftime('%Y-%m-%d %H:%M:%S.%f')
                log(f"  Host={repr(host_val)} -> last_created(IST)={time_dict[host_val]}")

            log(f"Final last_check_times dict: {time_dict}")
            return time_dict
        else:
            log("No existing watermark rows found. First run scenario.", "WARN")
    except Exception as e:
        log(f"EXCEPTION while fetching last check times: {e}", "ERROR")
        log(f"Traceback:\n{traceback.format_exc()}", "ERROR")

    return {}


def process_servers(host_list, last_check_times, target_insert_host):
    """
    Independent worker function. Fetches data and handles batch insertion.
    Returns a dictionary with counts of total_found, total_inserted, and total_failed.
    """
    thread_name = threading.current_thread().name
    log("=" * 80)
    log(f"THREAD STARTED: {thread_name}")
    log(f"  Source hosts: {host_list}")
    log(f"  Target insert host: {target_insert_host}")
    log(f"  Last check times received: {last_check_times}")
    log("=" * 80)

    # Initialize return stats
    stats = {'total_found': 0, 'total_inserted': 0, 'total_failed': 0}

    try:
        now = datetime.now(IST)
        log(f"Current IST time: {now}")
        all_rows_to_insert = []
        columns = [
            'query_id', 'query', 'state', 'user', 'source', 'created', 'end',
            'queued_time_ms', 'analysis_time_ms', 'planning_time_ms',
            'error_type', 'error_code', 'host'
        ]

        # ---------------- FETCH PHASE ----------------
        for src_host in host_list:
            log("-" * 70)
            log(f"FETCH START: source Trino host = {src_host}")
            log(f"  port=8080, user=airflow_collector, catalog=system, schema=runtime")

            last_time = last_check_times.get(src_host)
            if last_time is None:
                last_time_obj = now - timedelta(minutes=30)
                last_time = last_time_obj.strftime('%Y-%m-%d %H:%M:%S.%f')
                log(f"  No previous watermark for {src_host}. Defaulting to 30 mins ago (IST): {last_time}", "WARN")
            else:
                log(f"  Querying {src_host} for queries created after (IST): {last_time}")

            conn = None
            cur = None
            try:
                t_connect_start = time.time()
                conn = trino.dbapi.connect(
                    host=src_host,
                    port=8080,
                    user='airflow_collector',
                    catalog='system',
                    schema='runtime'
                )
                log(f"  Trino connection established in {time.time() - t_connect_start:.2f}s")

                cur = conn.cursor()
                sql_query = f"""
                    SELECT
                        query_id, query, state, "user", source, created, "end",
                        queued_time_ms, analysis_time_ms, planning_time_ms,
                        coalesce(error_type,'') as error_type, coalesce(error_code,'') as error_code
                    FROM system.runtime.queries
                    WHERE created > timestamp '{last_time}'
                      AND state IN ('FINISHED', 'FAILED')
                      AND query NOT LIKE '%{DEST_TABLE}%'
                      AND query NOT LIKE '%system.runtime.queries%'
                    ORDER BY created ASC
                """
                log(f"  Source SQL (truncated to 500 chars):\n{sql_query[:500]}")

                t_exec_start = time.time()
                cur.execute(sql_query)
                rows = cur.fetchall()
                elapsed_exec = time.time() - t_exec_start
                log(f"  Query executed in {elapsed_exec:.2f}s, rows returned: {len(rows)}")

                if rows:
                    log(f"  Sample first row (truncated): {str(rows[0])[:300]}")
                    log(f"  Sample last row (truncated): {str(rows[-1])[:300]}")

                for row in rows:
                    row_list = list(row)
                    row_list.append(src_host)
                    all_rows_to_insert.append(row_list)

                log(f"  Cumulative rows collected so far in thread: {len(all_rows_to_insert)}")

            except Exception as e:
                log(f"  EXCEPTION fetching from {src_host}: {e}", "ERROR")
                log(f"  Traceback:\n{traceback.format_exc()}", "ERROR")
                continue
            finally:
                try:
                    if cur:
                        cur.close()
                        log(f"  Cursor closed for {src_host}")
                    if conn:
                        conn.close()
                        log(f"  Connection closed for {src_host}")
                except Exception as e:
                    log(f"  Error closing connection for {src_host}: {e}", "WARN")

            log(f"FETCH END: source Trino host = {src_host}")

        # ---------------- INSERT PHASE ----------------
        log("=" * 70)
        log(f"INSERT PHASE START: target host = {target_insert_host}")
        log(f"Total rows to insert: {len(all_rows_to_insert)}")

        stats['total_found'] = len(all_rows_to_insert)

        if not all_rows_to_insert:
            log("No new queries found for thread. Skipping insert.", "WARN")
            return stats

        col_names = ", ".join([f'"{col}"' if col in ['user', 'end'] else col for col in columns])
        log(f"Column names for INSERT: {col_names}")

        chunk_size = 50
        total_chunks = (len(all_rows_to_insert) + chunk_size - 1) // chunk_size
        total_inserted = 0
        total_failed = 0

        log(f"Will process {total_chunks} chunks of size {chunk_size}")

        for chunk_idx in range(total_chunks):
            i = chunk_idx * chunk_size
            chunk = all_rows_to_insert[i:i + chunk_size]
            log(f"  -- Chunk {chunk_idx + 1}/{total_chunks}: {len(chunk)} rows --")

            values_sql = []
            skipped = 0
            for r_idx, row in enumerate(chunk):
                if len(row) != 13:
                    log(f"    Skipping row {r_idx}: expected 13 cols, got {len(row)}. Row={str(row)[:200]}", "WARN")
                    skipped += 1
                    continue

                try:
                    v_query_id = safe_val(row[0])
                    v_query = safe_val(row[1])
                    v_state = safe_val(row[2])
                    v_user = safe_val(row[3])
                    v_source = safe_val(row[4])
                    v_created = f"CAST({safe_val(row[5])} AS timestamp(6))"
                    v_end = f"CAST({safe_val(row[6])} AS timestamp(6))"
                    v_queued = f"CAST({safe_val(row[7])} AS bigint)"
                    v_analysis = f"CAST({safe_val(row[8])} AS bigint)"
                    v_planning = f"CAST({safe_val(row[9])} AS bigint)"
                    v_err_type = safe_val(row[10])
                    v_err_code = safe_val(row[11])
                    v_host = safe_val(row[12])

                    vals_str = (f"({v_query_id}, {v_query}, {v_state}, {v_user}, {v_source}, "
                                f"{v_created}, {v_end}, {v_queued}, {v_analysis}, {v_planning}, "
                                f"{v_err_type}, {v_err_code}, {v_host})")
                    values_sql.append(vals_str)
                except Exception as e:
                    log(f"    Error building VALUES for row {r_idx}: {e}", "ERROR")
                    log(f"    Row content: {str(row)[:300]}", "ERROR")
                    skipped += 1
                    continue

            if skipped:
                log(f"    Skipped {skipped} rows in this chunk", "WARN")

            if not values_sql:
                log(f"    No valid values to insert in this chunk. Skipping.", "WARN")
                continue

            batch_insert_sql = f"""
                INSERT INTO {DEST_TABLE} 
                ({col_names})
                VALUES {', '.join(values_sql)}
            """
            sql_preview = batch_insert_sql[:1000]
            log(f"    INSERT SQL preview (first 1000 chars):\n{sql_preview}")
            log(f"    Full SQL length: {len(batch_insert_sql)} chars")

            # --- Insert Retry Logic for Hive Locks ---
            max_retries = 2
            for attempt in range(1, max_retries + 1):
                try:
                    t_insert_start = time.time()
                    log(f"    Executing sq.query() against {target_insert_host}...")
                    query_res = sq.query(batch_insert_sql, host=target_insert_host)
                    elapsed_insert = time.time() - t_insert_start
                    log(f"    sq.query() returned in {elapsed_insert:.2f}s")
                    log(f"    Result type: {type(query_res)}")
                    log(f"    Result keys: {list(query_res.keys()) if isinstance(query_res, dict) else 'N/A'}")

                    # Check for the hidden error in sq.query response
                    is_error = False
                    err_msg = ""
                    if isinstance(query_res, dict):
                        if query_res.get('success') == 0:
                            is_error = True
                            err_msg = str(query_res.get('msg', 'Unknown error'))
                        elif query_res.get('msg') and 'Error' in str(query_res.get('msg')):
                            is_error = True
                            err_msg = str(query_res.get('msg'))

                    if is_error:
                        # IF IT'S A LOCK ISSUE, TRIGGER CLEANUP AND RETRY
                        if 'HIVE_TABLE_LOCK_NOT_ACQUIRED' in err_msg or 'HIVE_METASTORE_LOCK' in err_msg:
                            log(f"    ⚠️ Lock not acquired! Triggering lock cleanup (Attempt {attempt}/{max_retries})...", "WARN")
                            clear_hive_locks_for_table(
                                metastore_host=METASTORE_HOST,
                                metastore_db=METASTORE_DB,
                                metastore_user=METASTORE_USER,
                                metastore_password=METASTORE_PASSWORD,
                                target_db_name='analytics_services',
                                target_table_name='trino_query_history'
                            )
                            if attempt < max_retries:
                                log(f"    Sleeping 10 seconds before retrying insert...", "WARN")
                                time.sleep(10)
                                continue # Retry the loop
                            else:
                                total_failed += len(values_sql)
                                log(f"    ❌ Failed to insert chunk {chunk_idx + 1} after clearing locks.", "ERROR")
                                break # Break retry loop, move to next chunk
                        else:
                            # Other type of error, skip this chunk
                            total_failed += len(values_sql)
                            log(f"    ❌ Failed to insert chunk {chunk_idx + 1}: {err_msg[:300]}", "ERROR")
                            break # Break retry loop, move to next chunk
                    else:
                        # SUCCESS! Log full structure
                        if isinstance(query_res, dict):
                            for k, v in query_res.items():
                                if k == 'df':
                                    try:
                                        log(f"      result['df'] shape: {v.shape}, empty: {v.empty}")
                                        if not v.empty:
                                            log(f"      result['df'] content (first 5 rows):\n{v.head().to_string()}")
                                    except Exception as e:
                                        log(f"      result['df'] (could not inspect): {repr(v)[:200]}")
                                elif k == 'data':
                                    log(f"      result['data'] = {repr(v)[:300]}")
                                else:
                                    log(f"      result['{k}'] = {repr(v)[:300]}")

                        total_inserted += len(values_sql)
                        log(f"    ✅ Chunk {chunk_idx + 1} SUCCESS: inserted {len(values_sql)} rows into {target_insert_host}")
                        log(f"    Running total inserted: {total_inserted}")
                        break # Break retry loop, move to next chunk

                except Exception as e:
                    total_failed += len(values_sql)
                    log(f"    ❌ EXCEPTION inserting chunk {chunk_idx + 1} into {target_insert_host}: {e}", "ERROR")
                    log(f"    Traceback:\n{traceback.format_exc()}", "ERROR")
                    log(f"    Failed SQL chunk snippet (first 2000 chars):\n{batch_insert_sql[:2000]}", "ERROR")
                    break # Break retry loop, move to next chunk

        log("=" * 70)
        log(f"INSERT PHASE END for {target_insert_host}")
        log(f"  Total rows inserted: {total_inserted}")
        log(f"  Total rows failed:   {total_failed}")
        log(f"THREAD COMPLETED: {thread_name}")
        log("=" * 70)

        stats['total_inserted'] = total_inserted
        stats['total_failed'] = total_failed
        
        return stats

    except Exception as e:
        log(f"UNHANDLED EXCEPTION in thread {thread_name}: {e}", "ERROR")
        log(f"Traceback:\n{traceback.format_exc()}", "ERROR")
        raise


def fetch_and_store_trino_queries(**kwargs):
    """Main DAG function."""
    log("#" * 80)
    log("DAG TASK STARTED: fetch_and_store_trino_queries")
    log(f"Airflow run_id: {kwargs.get('run_id')}")
    log(f"Execution date: {kwargs.get('ds')}")
    log("#" * 80)

    try:
        log("Calling get_last_check_times()...")
        last_check_times = get_last_check_times()
        log(f"get_last_check_times() returned: {last_check_times}")

        # Clean up any NaN/NaT keys that might cause issues
        cleaned_times = {}
        for k, v in last_check_times.items():
            if k is None or (isinstance(k, float) and pd.isna(k)):
                log(f"  Skipping NULL/NaT host key in watermarks: {repr(k)} -> {v}", "WARN")
                continue
            cleaned_times[k] = v
        last_check_times = cleaned_times
        log(f"Cleaned last_check_times: {last_check_times}")

        group1_hosts = ['10.10.118.10', '10.10.118.24', '10.10.118.35']
        group1_target = '10.10.118.10'

        group2_hosts = ['10.10.116.39', '10.10.116.75']
        group2_target = '10.10.116.75'

        log("-" * 80)
        log("Starting Sequential Processing (No Threads)")
        log(f"  Group 1: fetch from {group1_hosts} -> insert into {group1_target}")
        log(f"  Group 2: fetch from {group2_hosts} -> insert into {group2_target}")
        log("-" * 80)

        # Running sequentially to avoid Hive table locks
        stats1 = process_servers(group1_hosts, last_check_times, group1_target)
        stats2 = process_servers(group2_hosts, last_check_times, group2_target)

        # --- AGGREGATE STATS FROM BOTH RUNS ---
        grand_total_found = stats1.get('total_found', 0) + stats2.get('total_found', 0)
        grand_total_inserted = stats1.get('total_inserted', 0) + stats2.get('total_inserted', 0)
        grand_total_failed = stats1.get('total_failed', 0) + stats2.get('total_failed', 0)

        log("\n" + "=" * 80)
        log("FINAL AGGREGATED STATS FOR BOTH SEQUENTIAL RUNS")
        log(f"  Total rows found across all targets: {grand_total_found}")
        log(f"  Total rows inserted across all targets: {grand_total_inserted}")
        log(f"  Total rows failed across all targets: {grand_total_failed}")
        log("=" * 80)

        # --- STRICT FAILURE CHECK (NOTIFICATION) ---
        # If we had rows to insert, but 0 went in across BOTH runs, HARD FAIL so Airflow alerts trigger
        if grand_total_found > 0 and grand_total_inserted == 0:
            raise Exception(f"CRITICAL ALERT: Fetched {grand_total_found} rows in total across all servers, but inserted 0 rows. All chunks failed. Check logs for locks or sq.query errors.")
        
        # If some chunks failed but some succeeded, log a warning but DON'T crash the DAG
        if grand_total_failed > 0 and grand_total_inserted > 0:
            log(f"⚠️ WARNING: {grand_total_failed} rows failed to insert in total, but {grand_total_inserted} rows succeeded. DAG will not fail.", "WARN")

        log("#" * 80)
        log("DAG TASK COMPLETE: fetch_and_store_trino_queries")
        log("#" * 80)

    except Exception as e:
        log(f"FATAL EXCEPTION in main task: {e}", "ERROR")
        log(f"Traceback:\n{traceback.format_exc()}", "ERROR")
        raise


# -----------------------------------------
# DAG Definition
# -----------------------------------------
default_args = {
    'owner': 'Goverdhan',
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'on_failure_callback': alert_failure_callback
}

with DAG(
    dag_id='trino_query_history_collector_v2',
    default_args=default_args,
    description='Fetches Trino query history from multiple servers and batch loads it sequentially',
    schedule='*/30 * * * *',
    start_date=datetime(2026, 8, 21, tzinfo=IST),
    catchup=False,
    max_active_runs=1,
    max_active_tasks=1,
    tags=['trino', 'analytics', 'multi-server', 'sequential'],
) as dag:

    fetch_trino_queries_task = PythonOperator(
        task_id='fetch_and_store_trino_queries',
        python_callable=fetch_and_store_trino_queries,
    )

    fetch_trino_queries_task