import os
import time
import redis
import json
from decimal import Decimal
from datetime import datetime, timedelta, date
from trino.dbapi import connect
from typing import Dict, Any
from airflow.sdk import DAG
from airflow.operators.python import PythonOperator
from zoneinfo import ZoneInfo

from strot_alert_notification import (
    alert_failure_callback,
    configure
)

configure(channel="dataplatformtesting")


class OptimizedHourlyStageStatsJob:
    def __init__(self):
        # Trino connection config
        self.trino_host = "10.10.116.75"
        self.trino_port = 8080
        self.trino_user = "tat_redis_cache_updt"
        
        # Redis connection config
        self.redis_host = "10.10.118.29"  # Update with your Redis host
        self.redis_port = 6379
        self.redis_db = 0
        self.redis_password = None
        
        # Current hour calculation
        ist = ZoneInfo("Asia/Kolkata")
        self.current_hour = datetime.now(ist).replace(minute=0, second=0, microsecond=0)
        self.current_date = self.current_hour.date()
        
        # Stage list
        self.stages = ['STRUCTURAL','SUCCESSINTERCEPTOR','DEMOGRAPHIC','QC','FLOWCONTROL',
                      'POSTENROLMENT','REJECTINTERCEPTOR','BIOMETRIC','BIOFRAUD',
                      'ENROLMENT','METADATA','EXTINTSERVICE','STATEPORTAL']
        
        self.redis_client = None
        self.trino_conn = None
        
    def connect_redis(self):
        """Establish Redis connection"""
        try:
            self.redis_client = redis.Redis(
                host=self.redis_host,
                port=self.redis_port,
                db=self.redis_db,
                password=self.redis_password,
                decode_responses=True
            )
            self.redis_client.ping()
            print("Redis connection established")
        except Exception as e:
            print(f"Redis connection failed: {e}")
            raise
            
    def connect_trino(self):
        """Establish Trino connection"""
        try:
            self.trino_conn = connect(
                host=self.trino_host,
                port=self.trino_port,
                user=self.trino_user,
            )
            print("Trino connection established")
        except Exception as e:
            print(f"Trino connection failed: {e}")
            raise
    
    def get_unified_stage_stats(self) -> Dict[str, Any]:
        """Get all stage statistics in a single optimized query"""
        stages_list = "','".join(self.stages)
        
        query = f"""
        WITH 
        -- Base data with efficient filtering
        base_audit AS (
            SELECT
                edata_sid,
                edata_stage,
                ets,
                edata_executionstatus
            FROM flink_stream.stream_enu.enu_globalprocessaudit
            WHERE
                ets >= now() - interval '10' day
                AND edata_stage IN ('{stages_list}')
                AND edata_executionstatus IN ('IN_PROCESS','COMPLETED')
        ),
        
        -- Aggregated stage data per packet
        stage_packets AS (
            SELECT
                edata_sid,
                edata_stage,
                min(ets) as entry_ts,
                max(CASE 
                WHEN LOWER(edata_executionstatus) IN ('completed')
                THEN ets
                END) as exit_ts
            FROM base_audit
            GROUP BY edata_sid, edata_stage
        ),
        
        -- Current hour flow metrics (inflow/outflow)
        current_hour_flows AS (
            SELECT
                edata_stage as stage_name,
                -- Inflow: packets entering in current hour
                count(case when entry_ts >= now() - interval '1' hour then 1 end) as inflow,
                -- Outflow: packets exiting in current hour  
                count(case when exit_ts >= now() - interval '1' hour then 1 end) as outflow,
                -- Duration stats for packets completed in current hour
                approx_percentile(
                    date_diff('second', entry_ts, exit_ts) / 60.0 
                    , 0.5) as p50_duration_minutes,
                approx_percentile(
                    date_diff('second', entry_ts, exit_ts) / 60.0 
                    , 0.9) as p90_duration_minutes,
                approx_percentile(
                    date_diff('second', entry_ts, exit_ts) / 60.0 
                    , 0.99) as p99_duration_minutes
            FROM stage_packets
            WHERE exit_ts >= now() - interval '1' hour
            GROUP BY edata_stage
        ),
        
        -- Pendency metrics (packets pending at current hour)
        current_pendency AS (
            SELECT
                edata_stage as stage_name,
                count(*) as pending_count_total,
                approx_percentile(
                    date_diff('minute', entry_ts, now()), 0.9
                ) as p90_pending_duration_minutes,
                count_if(
                    date_diff('hour', entry_ts, now()) < 24
                ) as pending_count_under_24h,
                approx_percentile(
                    case when date_diff('hour', entry_ts, now()) < 24 
                         then date_diff('minute', entry_ts, now()) 
                    end, 0.9
                ) as p90_pending_duration_under_24h_minutes
            FROM stage_packets
            WHERE exit_ts IS NULL
            GROUP BY edata_stage
        )
        
        -- Final unified result
        SELECT
            coalesce(f.stage_name, p.stage_name) as stage_name,
            -- Flow metrics
            coalesce(f.inflow, 0) as inflow,
            coalesce(f.outflow, 0) as outflow,
            case when coalesce(f.inflow, 0) > 0 
                 then cast(coalesce(f.outflow, 0) as double) / cast(f.inflow as double) 
                 else 0.0 end as inflow_outflow_ratio,
            -- Duration metrics
            coalesce(f.p50_duration_minutes, 0.0) as p50_duration,
            coalesce(f.p90_duration_minutes, 0.0) as p90_duration,
            coalesce(f.p99_duration_minutes, 0.0) as p99_duration,
            coalesce(f.p90_duration_minutes, 0.0) - coalesce(f.p50_duration_minutes, 0.0) as p90_p50_diff,
            coalesce(f.p99_duration_minutes, 0.0) - coalesce(f.p90_duration_minutes, 0.0) as p99_p90_diff,
            -- Pendency metrics
            coalesce(p.pending_count_total, 0) as pending_count_total,
            coalesce(p.p90_pending_duration_minutes, 0.0) as p90_pending_duration_total_minutes,
            coalesce(p.pending_count_under_24h, 0) as pending_count_under_24h,
            coalesce(p.p90_pending_duration_under_24h_minutes, 0.0) as p90_pending_duration_under_24h_minutes
        FROM current_hour_flows f
        FULL OUTER JOIN current_pendency p ON f.stage_name = p.stage_name
        WHERE coalesce(f.stage_name, p.stage_name) IS NOT NULL
        ORDER BY stage_name
        """

        cursor = self.trino_conn.cursor()
        cursor.execute(query)
        results = cursor.fetchall()
        cursor.close()
        
        unified_stats = {}
        for row in results:
            stage_name = row[0]
            unified_stats[stage_name] = {
                # Flow metrics
                'inflow': row[1],
                'outflow': row[2], 
                'inflow_outflow_ratio': round(row[3], 3),
                # Duration metrics
                'p50_duration': round(row[4], 2),
                'p90_duration': round(row[5], 2),
                'p99_duration': round(row[6], 2),
                'p90_50_diff': round(row[7], 2),
                'p99_90_diff': round(row[8], 2),
                # Pendency metrics
                'pending_count_total': row[9],
                'p90_pending_duration_total_minutes': round(row[10], 2),
                'pending_count_under_24h': row[11],
                'p90_pending_duration_under_24h_minutes': round(row[12], 2),
                # Hardcoded pq percentage
                'pq_percentage': 2.0,
                # Metadata
                'timestamp': self.current_hour,
                'date': self.current_date
            }
        
        # Ensure all configured stages are present, even if absent from query results
        for stage_name in self.stages:
            if stage_name not in unified_stats:
                unified_stats[stage_name] = {
                    'inflow': 0,
                    'outflow': 0,
                    'inflow_outflow_ratio': 0.0,
                    'p50_duration': 0.0,
                    'p90_duration': 0.0,
                    'p99_duration': 0.0,
                    'p90_50_diff': 0.0,
                    'p99_90_diff': 0.0,
                    'pending_count_total': 0,
                    'p90_pending_duration_total_minutes': 0.0,
                    'pending_count_under_24h': 0,
                    'p90_pending_duration_under_24h_minutes': 0.0,
                    'pq_percentage': 2.0,
                    'timestamp': self.current_hour,
                    'date': self.current_date
                }
        
        print(f"Retrieved unified stats for {len(unified_stats)} stages")
        return unified_stats
    
    def write_to_redis(self, stage_stats: Dict[str, Any]):
        """Write all statistics to Redis with stage-wise keys"""
        def convert_decimals(obj):
            if isinstance(obj, dict):
                return {k: convert_decimals(v) for k, v in obj. items()}
            elif isinstance(obj, list):
                return [convert_decimals(i) for i in obj]
            elif isinstance(obj, Decimal):
                return float(obj)
            elif isinstance(obj, (datetime, )):
                return obj.isoformat()
            elif isinstance(obj, date):
                return obj.isoformat()
            return obj
        
        try:
            # Set TTL to 25 hours to ensure data persists between runs
            ttl_seconds = 25 * 60 * 60
            redis_operations = 0
            
            for stage_name, metrics in stage_stats.items():
                # Add timestamp and date if missing (defensive programming)
                if 'timestamp' not in metrics:
                    metrics['timestamp'] = self.current_hour
                if 'date' not in metrics:
                    metrics['date'] = self.current_date
                
                # Create the Redis key (just the stage name)
                redis_key = f"stage_{stage_name}"
                
                # Create the value with all metrics and metadata
                redis_value = {
                    'stage': stage_name,
                    'timestamp': metrics. get('timestamp'),
                    'date': metrics.get('date'),
                    'last_updated': datetime.now(ZoneInfo("Asia/Kolkata")).isoformat(),
                    'metrics': {
                        k: v for k, v in metrics.items() 
                        if k not in ['timestamp', 'date']
                    }
                }
                
                # Convert Decimal and datetime objects to JSON-serializable types
                redis_value_serializable = convert_decimals(redis_value)
                
                # Store as JSON
                self.redis_client.setex(
                    redis_key, 
                    ttl_seconds, 
                    json.dumps(redis_value_serializable, default=str)
                )
                redis_operations += 1
                
                print(f"Stored all metrics for stage: {stage_name} (key: {redis_key})")
            
            print(f"Total Redis operations: {redis_operations}")
                
        except Exception as e:
            print(f"Failed to write to Redis: {e}")
            raise
    
    def run(self):
        """Main execution method"""
        start_time = time.time()
        print(f"Starting optimized hourly stage stats job for {self.current_hour}")
        
        try:
            # Establish connections
            self.connect_trino()
            self.connect_redis()
            
            # Get all statistics in single query
            print("Fetching unified stage statistics...")
            unified_stats = self.get_unified_stage_stats()
            
            # Write to Redis
            print("Writing unified stats to Redis...")
            self.write_to_redis(unified_stats)
            
            # Summary
            execution_time = time.time() - start_time
            total_stages = len(unified_stats)
            total_metrics = sum(len([k for k in v.keys() if k not in ['timestamp', 'date']]) 
                              for v in unified_stats.values())
            
            print(f"Job completed successfully in {execution_time:.2f} seconds")
            print(f"Processed {total_stages} stages with {total_metrics} total metrics")
            
            # Log sample of what was stored
            if unified_stats:
                sample_stage = next(iter(unified_stats))
                print(f"Sample metrics for {sample_stage}: {list(unified_stats[sample_stage].keys())}")
            
        except Exception as e:
            print(f"Job failed: {e}")
            raise
        finally:
            # Clean up connections
            if self.trino_conn:
                self.trino_conn.close()
            if self.redis_client:
                self.redis_client.close()

def main():
    job = OptimizedHourlyStageStatsJob()
    job.run()


schedule='0 * * * *'

default_args = {
    "owner": "inzamam.nisg",
    "depends_on_past": False,
    "start_date": datetime(2026, 10, 18),
    "email": [
        "techexe15.yp25@uidai.net.in",
        "techexecutive22-yp23@uidai.net.in",
        "techexecutive14-yp23@uidai.net.in",
    ],
    "email_on_failure": True,
    "email_on_retry": True,
    "retries": 1,
    'on_failure_callback':  alert_failure_callback
}

dag = DAG(
    'TAT_Packet_Stage_Stats',
    default_args=default_args,
    description='DAG To Update Redis Keys Related To Packet TAT Prediction Model',
    schedule=f'{schedule}',
    catchup=False,
    max_active_runs=1,
)

redis_upd = PythonOperator(
                task_id='upd_redis_keys',
                python_callable=main,
                op_kwargs={},
                trigger_rule='all_done',
                dag=dag,
            )

redis_upd