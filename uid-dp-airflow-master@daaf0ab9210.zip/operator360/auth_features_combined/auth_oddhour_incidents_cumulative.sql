INSERT INTO {destination_table}
    WITH tab1 AS (
        SELECT entity_id, feature_value,
               row_number() over(partition by entity_id order by timestamp desc) as rn
        FROM {destination_table}
        WHERE feature_id = '{FEATURE_NAME}_v{FEATURE_VERSION}' AND date(timestamp) < date(CURRENT_TIMESTAMP)
    ),
    tab2 AS (
        SELECT * FROM tab1 WHERE rn = 1
    ),
    tab3 AS (
        SELECT entity_id, feature_value
        FROM {destination_table}
        WHERE feature_id = '{dependent_feature_id}' AND date(timestamp) = date(current_timestamp)
    ),
    tab4 AS (
        SELECT t1.entity_id, t1.feature_value as curr_val, coalesce(t2.feature_value, 0) as cum_val
        FROM tab3 t1 LEFT JOIN tab2 t2 ON t1.entity_id = t2.entity_id
    )
    SELECT
        entity_id AS entity_id,
        '{FEATURE_NAME}_v{FEATURE_VERSION}' AS feature_id,
        '{FEATURE_NAME}' AS feature_name,
        '{FEATURE_VERSION}' AS feature_version,
        curr_val + cum_val AS feature_value,
        current_timestamp AT TIME ZONE 'Asia/Kolkata' AS timestamp,
        '' AS comments
    FROM tab4
