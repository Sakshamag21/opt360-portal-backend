#!/usr/bin/env python3
"""
Scoring dispatcher for operator360 Layer 2/3 — runs on the Airflow worker.

No Kubernetes pod is created. The Airflow worker connects directly to the
remote Spark Connect cluster (sc://spark-connect-service.strot-spark.svc.cluster.local:15002)
and launches all scoring jobs sequentially as subprocesses. The actual Spark
compute (executor pods) is managed by the Spark Connect server on the cluster,
not by Airflow.

The Airflow worker must have PySpark + trino installed. If they're missing,
ensure_dependencies() installs them via the internal PyPI proxy.

Prometheus metrics are pushed to Pushgateway if PUSHGATEWAY_URL is set.

Usage (CLI):
    python3 scoring_dispatcher.py --layer instance
    python3 scoring_dispatcher.py --layer category

Usage (import):
    from scoring_dispatcher import run_dispatcher
    run_dispatcher(layer="instance", features=[...], pipeline_run_id="2026-10-19")
"""
import json
import logging
import os
import subprocess
import sys
import time
from datetime import datetime, timezone

import boto3

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# ── Paths — derive from this file's location so it works on both the
#    Airflow worker (/opt/airflow/dags/operator360/scoring_methods/) and
#    inside a pod (/tmp/operator360/scoring_methods/) if ever needed. ──
SCORING_DIR = os.path.dirname(os.path.abspath(__file__))
UTILS_DIR = os.path.join(SCORING_DIR, "..", "utils")
PYTHONPATH = f"{SCORING_DIR}:{UTILS_DIR}"

# ── S3 config (mirrors utils/s3_audit_logger_test.py) ────────────────────
CEPH_ENDPOINT_URL = "http://10.10.103.12:425"
CEPH_ACCESS_KEY = "9S0KLIQO7T2XCNGH4P4A"
CEPH_SECRET_KEY = "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4"
CEPH_BUCKET_NAME = "prd-bi-data-platform-test"
CEPH_CACHE_PREFIX = "cache/airflow/operator360_v3"

# ── Layer config ─────────────────────────────────────────────────────────
LAYER_CONFIG = {
    "instance": {
        "dag_id": "instance_risk_scoring_v3_test",
        "script": "instances_main.py",
    },
    "category": {
        "dag_id": "combined_risk_scoring_v3_test",
        "script": "category_main.py",
    },
}

# ── PyPI proxy for installing deps if missing ────────────────────────────
PYPI_INDEX = "http://10.10.206.59:8080/repository/pypi-proxy/simple"
PYPI_TRUSTED_HOST = "10.10.206.59"


# ── Dependency check ─────────────────────────────────────────────────────
def ensure_dependencies():
    """Ensure pyspark + trino are installed on the Airflow worker.
    Installs from the internal PyPI proxy if missing."""
    missing = []
    try:
        import pyspark  # noqa: F401
    except ImportError:
        missing.append("pyspark")
    try:
        import trino  # noqa: F401
    except ImportError:
        missing.append("trino")

    if not missing:
        logger.info("All dependencies present (pyspark, trino)")
        return

    logger.info("Installing missing dependencies: %s", missing)
    cmd = [
        sys.executable, "-m", "pip", "install", "--quiet",
        "--index-url", PYPI_INDEX,
        "--trusted-host", PYPI_TRUSTED_HOST,
    ] + missing
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        logger.error("pip install failed: %s", result.stderr[-2000:])
        raise RuntimeError(f"Failed to install {missing}: {result.stderr[-500:]}")
    logger.info("Installed: %s", missing)


# ── S3 status helpers (replicated from pipeline_status_v2_test.py) ───────
def _get_s3_client():
    return boto3.client(
        "s3",
        endpoint_url=CEPH_ENDPOINT_URL,
        aws_access_key_id=CEPH_ACCESS_KEY,
        aws_secret_access_key=CEPH_SECRET_KEY,
    )


def _sanitize_run_id(pipeline_run_id: str) -> str:
    return "".join(c if c.isalnum() or c in "-_" else "_" for c in str(pipeline_run_id))


def _status_key(pipeline_run_id: str, dag_id: str, task_key: str) -> str:
    safe_run_id = _sanitize_run_id(pipeline_run_id)
    return f"{CEPH_CACHE_PREFIX}/manager_status_v3/{safe_run_id}/{dag_id}/{task_key}.json"


def _write_status(pipeline_run_id, dag_id, task_key, category, status,
                  error=None, log_url=None):
    key = _status_key(pipeline_run_id, dag_id, task_key)
    payload = {
        "task_key": task_key,
        "dag_id": dag_id,
        "category": category,
        "status": status,
        "error": error,
        "log_url": log_url,
        "written_at": datetime.now(timezone.utc).isoformat(),
    }
    try:
        s3 = _get_s3_client()
        s3.put_object(
            Bucket=CEPH_BUCKET_NAME,
            Key=key,
            Body=json.dumps(payload).encode("utf-8"),
            ContentType="application/json",
        )
    except Exception as e:
        logger.error("Failed to write status to S3: %s", e)


# ── Prometheus metrics ───────────────────────────────────────────────────
class MetricsSink:
    """Pushes metrics to Prometheus Pushgateway if PUSHGATEWAY_URL is set.
    Otherwise logs them (so they still show up in Airflow task logs)."""

    def __init__(self):
        self.pushgateway_url = os.environ.get("PUSHGATEWAY_URL")
        self.job_name = "operator360_scoring"
        self._registry = None
        self._counters = {}
        self._histograms = {}
        if self.pushgateway_url:
            try:
                from prometheus_client import CollectorRegistry, Counter, Histogram, push_to_gateway
                self._registry = CollectorRegistry()
                self._Counter = Counter
                self._Histogram = Histogram
                self._push_to_gateway = push_to_gateway
                logger.info("Prometheus Pushgateway configured: %s", self.pushgateway_url)
            except ImportError:
                logger.warning("prometheus_client not installed — metrics will be logged only")
                self.pushgateway_url = None

    def record_feature(self, layer, feature_name, status, duration_seconds):
        """Record a single feature's outcome."""
        labels = {"layer": layer, "feature_name": feature_name, "status": status}
        logger.info("METRIC feature: %s", json.dumps(labels | {"duration_s": round(duration_seconds, 2)}))

        if not self._registry:
            return

        key = "opt360_scoring_feature_total"
        if key not in self._counters:
            self._counters[key] = self._Counter(
                key, "Total scoring features processed by outcome",
                ["layer", "feature_name", "status"], registry=self._registry,
            )
        self._counters[key].labels(**labels).inc()

        hkey = "opt360_scoring_feature_duration_seconds"
        if hkey not in self._histograms:
            self._histograms[hkey] = self._Histogram(
                hkey, "Time spent on a single scoring feature",
                ["layer", "feature_name"], registry=self._registry,
            )
        self._histograms[hkey].labels(layer=layer, feature_name=feature_name).observe(duration_seconds)

    def record_run(self, layer, status, total, succeeded, failed, skipped, duration_seconds):
        """Record the overall dispatcher run outcome."""
        labels = {"layer": layer, "status": status}
        summary = {"total": total, "succeeded": succeeded, "failed": failed,
                   "skipped": skipped, "duration_s": round(duration_seconds, 2)}
        logger.info("METRIC run: %s", json.dumps(labels | summary))

        if not self._registry:
            return

        key = "opt360_scoring_run_total"
        if key not in self._counters:
            self._counters[key] = self._Counter(
                key, "Total dispatcher runs by outcome",
                ["layer", "status"], registry=self._registry,
            )
        self._counters[key].labels(**labels).inc()

    def push(self, grouping_key):
        """Push all collected metrics to Pushgateway."""
        if not self._registry or not self.pushgateway_url:
            return
        try:
            self._push_to_gateway(
                self.pushgateway_url, job=self.job_name,
                grouping_key=grouping_key, registry=self._registry,
            )
            logger.info("Pushed metrics to Pushgateway: %s", self.pushgateway_url)
        except Exception as e:
            logger.warning("Failed to push metrics to Pushgateway: %s", e)


# ── Core dispatcher ──────────────────────────────────────────────────────
def _run_scoring_job(script: str, feature_name: str, feature_version) -> int:
    """Run one scoring job as a subprocess. stdout/stderr flow directly to
    the Airflow task logs (no capture — the operator's get_logs equivalent)."""
    script_path = os.path.join(SCORING_DIR, script)
    cmd = [sys.executable, script_path, feature_name, str(feature_version)]
    env = os.environ.copy()
    env["PYTHONPATH"] = PYTHONPATH
    # Make sure the Spark Connect endpoint is visible (get_spark() hardcodes
    # it, but SPARK_REMOTE is a good convention for tools that read it).
    env.setdefault("SPARK_REMOTE", "sc://spark-connect-service.strot-spark.svc.cluster.local:15002")

    logger.info("Running: %s", " ".join(cmd))
    result = subprocess.run(cmd, env=env, cwd=SCORING_DIR)
    return result.returncode


def run_dispatcher(layer, features, pipeline_run_id=None, log_url=None):
    """Run all scoring features for a layer sequentially on the Airflow worker.

    Args:
        layer: "instance" or "category"
        features: list of dicts with keys: key, feature_name, feature_version,
                  feature_id, dependencies, category
        pipeline_run_id: run ID for status tracking (S3 status records)
        log_url: Airflow task log URL

    Returns:
        dict with keys: succeeded, failed, skipped (lists of feature keys)

    Raises:
        RuntimeError if any feature failed (after all features are attempted)
    """
    if layer not in LAYER_CONFIG:
        raise ValueError(f"Unknown layer: {layer}")

    config = LAYER_CONFIG[layer]
    dag_id = config["dag_id"]
    script = config["script"]

    # Ensure pyspark + trino are available before running anything
    ensure_dependencies()

    if not pipeline_run_id:
        pipeline_run_id = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    metrics = MetricsSink()
    run_start = time.time()

    logger.info(
        "Dispatcher started: layer=%s, dag_id=%s, pipeline_run_id=%s, features=%d, "
        "scoring_dir=%s",
        layer, dag_id, pipeline_run_id, len(features), SCORING_DIR,
    )

    succeeded = set()
    failed = {}
    skipped = set()

    # Run features without dependencies first, then features that depend on
    # others (Layer 3's risk_score depends on the 5 category scores).
    no_deps = [f for f in features if not f.get("dependencies")]
    with_deps = [f for f in features if f.get("dependencies")]

    for feature in no_deps + with_deps:
        key = feature["key"]
        feature_name = feature["feature_name"]
        feature_version = feature["feature_version"]
        task_key = f'task-id-{feature_name}-{feature_version}'
        category = feature.get("category")

        # ── Dependency check ──
        deps = feature.get("dependencies", [])
        if deps:
            failed_deps = [d for d in deps if d not in succeeded]
            if failed_deps:
                logger.warning("Skipping %s: dependencies not met: %s", key, failed_deps)
                _write_status(
                    pipeline_run_id, dag_id, task_key, category, "skipped",
                    error=f"Dependencies not met: {failed_deps}", log_url=log_url,
                )
                skipped.add(key)
                metrics.record_feature(layer, feature_name, "skipped", 0.0)
                continue

        # ── Run the Spark Connect scoring job ──
        logger.info("--- Starting %s (%s v%s) ---", key, feature_name, feature_version)
        feat_start = time.time()
        exit_code = _run_scoring_job(script, feature_name, feature_version)
        feat_dur = time.time() - feat_start

        if exit_code == 0:
            logger.info("SUCCESS: %s (%.1fs)", key, feat_dur)
            _write_status(pipeline_run_id, dag_id, task_key, category, "success", log_url=log_url)
            succeeded.add(key)
            metrics.record_feature(layer, feature_name, "success", feat_dur)
        else:
            logger.error("FAILED: %s (exit code %s, %.1fs)", key, exit_code, feat_dur)
            _write_status(
                pipeline_run_id, dag_id, task_key, category, "failed",
                error=f"Exit code {exit_code}", log_url=log_url,
            )
            failed[key] = exit_code
            metrics.record_feature(layer, feature_name, "failed", feat_dur)

    # ── Summary ──
    run_dur = time.time() - run_start
    status = "failed" if failed else "success"
    logger.info("%s", "=" * 60)
    logger.info("DISPATCHER SUMMARY: %s layer", layer)
    logger.info("  Total:   %d", len(features))
    logger.info("  Success: %d", len(succeeded))
    logger.info("  Failed:  %d", len(failed))
    logger.info("  Skipped: %d", len(skipped))
    logger.info("  Duration: %.1fs", run_dur)
    if failed:
        logger.error("  Failed features: %s", list(failed.keys()))
    logger.info("%s", "=" * 60)

    metrics.record_run(layer, status, len(features), len(succeeded), len(failed), len(skipped), run_dur)
    metrics.push(grouping_key={"layer": layer, "pipeline_run_id": pipeline_run_id})

    if failed:
        raise RuntimeError(f"Scoring failed for {len(failed)} features: {list(failed.keys())}")

    return {"succeeded": list(succeeded), "failed": list(failed), "skipped": list(skipped)}


# ── CLI entrypoint ───────────────────────────────────────────────────────
def main():
    import argparse
    parser = argparse.ArgumentParser(description="operator360 scoring dispatcher")
    parser.add_argument("--layer", required=True, choices=["instance", "category"])
    args = parser.parse_args()

    features_json = os.environ.get("SCORING_FEATURES")
    if not features_json:
        logger.error("SCORING_FEATURES env var not set")
        sys.exit(1)
    features = json.loads(features_json)

    pipeline_run_id = os.environ.get("PIPELINE_RUN_ID", datetime.now(timezone.utc).strftime("%Y-%m-%d"))
    log_url = os.environ.get("TASK_LOG_URL")

    try:
        run_dispatcher(args.layer, features, pipeline_run_id, log_url)
    except RuntimeError as e:
        logger.error(str(e))
        sys.exit(1)


if __name__ == "__main__":
    main()
