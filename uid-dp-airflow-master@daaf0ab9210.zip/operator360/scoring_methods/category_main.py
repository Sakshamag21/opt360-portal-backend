import os
os.environ["SPARK_SUBMIT_OPTS"] = "-Dlog4j2.StatusLogger.level=WARN -Dlog4j2.skipUserJars=true"

# NOTE: Do NOT call findspark.init() — it sets SPARK_HOME, which causes the
# JVM to load spark-defaults.conf (containing spark.master=local[*]) from
# the pod image.  That conflicts with .remote() and throws:
#   CANNOT_CONFIGURE_SPARK_CONNECT_MASTER
# The pod image already has PySpark installed as a pip package.

from pyspark.sql import functions as F
import logging
import pandas as pd
import ast
from trino.dbapi import connect
from category_scoring_methods import *

trino_host = "10.10.116.75"
trino_port = 8080
trino_user = "opt360_feature_metadata"
logger = logging.getLogger(__name__)


def trino(query, host=trino_host, port=trino_port, user=trino_user):
    try:
        conn = connect(host=host, port=port, user=user)
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"query": query, "success": 1, "data": body}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}


def _parse_dependent_features(dep_val):
    params = {}

    if isinstance(dep_val, list):
        items = dep_val
    elif isinstance(dep_val, str):
        try:
            parsed = ast.literal_eval(dep_val)
            if isinstance(parsed, list):
                items = parsed
            else:
                items = []
        except (ValueError, SyntaxError):
            s = dep_val.strip().strip("[]")
            items = _smart_split(s)
    else:
        items = []

    for item in items:
        if isinstance(item, str):
            if ":" in item:
                k, v = item.split(":", 1)
                key = k.strip()
                value = v.strip()
                try:
                    if value.startswith("{") and value.endswith("}"):
                        parsed_val = _parse_nested_dict(value)
                        params[key] = parsed_val
                    else:
                        params[key] = int(value)
                except (ValueError, SyntaxError):
                    params[key] = value

    return params


def _smart_split(s):
    """Split by comma but respect nested structures (braces)."""
    items = []
    current = []
    depth = 0

    for char in s:
        if char == "{":
            depth += 1
            current.append(char)
        elif char == "}":
            depth -= 1
            current.append(char)
        elif char == "," and depth == 0:
            item = "".join(current).strip().strip("'").strip('"')
            if item:
                items.append(item)
            current = []
        else:
            current.append(char)

    if current:
        item = "".join(current).strip().strip("'").strip('"')
        if item:
            items.append(item)

    return items


def _parse_nested_dict(dict_str):
    """Parse a dict string like {key1:val1,key2:val2,...}."""
    inner = dict_str.strip()[1:-1]
    result = {}

    items = _smart_split(inner)

    for item in items:
        if ":" in item:
            k, v = item.split(":", 1)
            key = k.strip()
            value = v.strip()
            try:
                result[key] = int(value)
            except ValueError:
                result[key] = value

    return result


def main(
    feature_name: str = "risk_score",
    destination_table: str = "strot.operator360.features_risk_v1"
):
    try:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s: %(message)s')
        logger.info(f"Starting category scoring job: {feature_name}")
        import sys
        feature_version = None
        if len(sys.argv) >= 3:
            feature_name = sys.argv[1]
            feature_version = sys.argv[2]

        spark = get_spark(f"opt360_{feature_name}_automation")

        # Fetch registry metadata
        q = (f'''
            SELECT *
             FROM strot.operator360.opt360_features
             WHERE feature_name = '{feature_name}' and version= '{feature_version}'
        ''')
        reg = trino(q, host='10.10.118.35')
        if 'df' not in reg:
            logger.error(f"Registry query returned no data: {reg}")
            return
        df = reg.get('df')

        for index, row in df.iterrows():
            feature_name = row.get("feature_name")
            feature_version = row.get("version")
            current_destination_table = row.get("destination_table", destination_table)
            current_dependent_features = row.get("dependent_features")

            # v3.1: write category scores to the staging schema so they
            # don't mix with production.  category_scoring_methods.py also
            # reads instance scores from staging when this env var is set.
            if os.environ.get("USE_WAIVER_SCORING") == "true":
                current_destination_table = current_destination_table.replace(
                    "strot.operator360.", "strot.operator360_stagging."
                )
                logger.info(f"WAIVER MODE: destination overridden to {current_destination_table}")

            params = _parse_dependent_features(current_dependent_features)

            logger.info(f"Processing row {index}: feature={feature_name}, table={current_destination_table}, params={params}")

            scoring_function_name = params.pop('scoring_function', '')
            if scoring_function_name == '':
                logger.error(f"For feature={feature_name}, version={feature_version}, no scoring function is defined, dependent_features={params}")
                return

            scoring_func = globals()[scoring_function_name]
            risk_df = scoring_func(spark=spark, **params)

            risk_df = risk_df.select(
                F.col("entity_id"),
                F.lit(f"{feature_name}_v{feature_version}").alias("feature_id"),
                F.lit(feature_name).alias("feature_name"),
                F.lit(feature_version).alias("feature_version"),
                F.round(F.col("risk_value"), 2).cast("double").alias("feature_value"),
                F.from_utc_timestamp(F.current_timestamp(), "Asia/Kolkata").alias("timestamp"),
                F.lit('').alias("comments")
            ).filter(F.col("entity_id").isNotNull())

            logger.info(f"Writing category scores to {current_destination_table}")
            risk_df.writeTo(current_destination_table).append()

    except Exception as e:
        logger.error(f"Exception in category scoring: {e}")
        raise


main()
