from pyspark.sql import functions as F, Window
from pyspark.sql import SparkSession
import logging
logger = logging.getLogger(__name__)

# NOTE: Do NOT call findspark.init() — it sets SPARK_HOME, which causes the
# JVM to load spark-defaults.conf (containing spark.master=local[*]) from
# the pod image.  That conflicts with .remote() and throws:
#   CANNOT_CONFIGURE_SPARK_CONNECT_MASTER
# The pod image already has PySpark installed as a pip package.

def get_spark(job_name: str):
    spark = SparkSession.builder \
        .appName(f"opt360-instance-scoring-{job_name.replace('_','-')}") \
        .remote("sc://spark-connect-service.strot-spark.svc.cluster.local:15002") \
        .config("spark.sql.legacy.mysql.bitArrayMapping.enabled","true") \
        .config("spark.default.parallelism","800") \
        .config("spark.sql.shuffle.partitions", "800") \
        .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
        .config("spark.sql.catalog.strot", "org.apache.iceberg.spark.SparkCatalog") \
        .config("spark.sql.catalog.strot.type", "hive") \
        .config("spark.sql.catalog.strot.uri", "thrift://10.10.116.77:9083") \
        .config("spark.sql.catalog.flink_stream", "org.apache.iceberg.spark.SparkCatalog") \
        .config("spark.sql.catalog.flink_stream.type", "hive") \
        .config("spark.sql.catalog.flink_stream.uri", "thrift://10.10.118.15:9083") \
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
        .config("spark.hadoop.fs.s3a.path.style.access", "true") \
        .config("spark.hadoop.fs.s3a.endpoint", "http://10.10.103.12:425") \
        .config("spark.hadoop.fs.s3a.access.key", "9S0KLIQO7T2XCNGH4P4A") \
        .config("spark.hadoop.fs.s3a.secret.key", "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4") \
        .getOrCreate()
    # Spark Connect tags — visible in the Spark Connect server UI and
    # Prometheus/Grafana dashboards for filtering jobs by pipeline/layer/feature.
    spark.addTag("operator360")
    spark.addTag("layer2-instance-scoring")
    spark.addTag(f"feature-{job_name.replace('_','-')}")
    return spark


# ---------------------------------------------------------------------------
# Core data fetcher: reads the 7-DAY AVERAGE of cumulative values per entity
# per feature.  This stabilises scores against missing DAG runs — if Layer 1
# didn't execute on a given day, the 7-day average still reflects the
# entity's recent risk profile instead of silently using a stale single
# value or returning no data at all.
#
# The only additional aggregation that happens here is inter-feature
# combination (SUM / WEIGHTED_AVERAGE / MAX / MIN / AVERAGE) when multiple
# feature_ids are passed for scores like bio_mfc_fraud_score.
# ---------------------------------------------------------------------------
def multiple_col_to_one(
    spark: SparkSession,
    fraud_table: str,
    feature_id,
    agg_method: str = None,
    weights: map = None,
    **kwargs
):
    """Reads the 7-day average of cumulative values per entity for each
    feature_id, then combines multiple features using the specified
    aggregation method.

    A 7-day rolling average smooths over individual missing days so that a
    single Layer-1 failure doesn't cause a score to drop to zero or swing
    wildly.  Only inter-feature aggregation (combining columns from multiple
    feature_ids) is performed when agg_method is provided.
    """
    # Normalise feature_id to a list
    if isinstance(feature_id, str):
        feature_ids = [feature_id]
    elif isinstance(feature_id, list):
        feature_ids = feature_id
    else:
        raise TypeError("feature_id must be either a string or a list of strings")

    agg_method_upper = agg_method.upper() if agg_method else 'SUM'

    if agg_method_upper == 'WEIGHTED_AVERAGE' and weights is None:
        raise ValueError("Weights mapping must be provided when agg_method is 'weighted_average'")

    # 1. Read the table and filter by feature_ids
    #    Drop rows with NULL entity_id — they cannot be attributed to any
    #    operator and would break writeTo() / downstream joins.
    df_base = spark.table(fraud_table) \
        .withColumn("entity_id", F.col("entity_id").cast("string")) \
        .withColumn("feature_value", F.col("feature_value").cast("double")) \
        .filter(F.col("feature_id").isin(feature_ids)) \
        .filter(F.col("entity_id").isNotNull())

    # 2. Get the 7-DAY AVERAGE value per entity_id per feature_id.
    #    Instead of picking only the latest row (which could be stale if
    #    Layer 1 didn't run today), we average all rows from the last 7
    #    days.  This means:
    #    - If today's data is missing, yesterday's value still contributes
    #    - A single day's outlier is dampened by the surrounding 6 days
    #    - Entities with no data in the last 7 days simply don't appear
    df_7d = df_base.filter(
        F.col("timestamp") >= F.date_sub(F.current_timestamp(), 7)
    )
    df_latest = df_7d.groupBy("entity_id", "feature_id").agg(
        F.avg("feature_value").alias("feature_value")
    )

    # 3. Pivot to create dedicated columns per feature
    df_pivot = df_latest.groupBy("entity_id").pivot("feature_id", feature_ids).agg(
        F.coalesce(F.max("feature_value"), F.lit(0.0))
    )

    # Reference column markers safely
    incident_cols = [F.col(f"`{fid}`") for fid in feature_ids]

    # 4. Cross-Column Consolidation (Inter-Feature Aggregation)
    from functools import reduce

    if len(feature_ids) == 1:
        # Single feature — just return the 7-day averaged value directly
        df_combined = df_pivot.withColumn("final_value",
                                          F.coalesce(incident_cols[0], F.lit(0.0)))
    elif agg_method_upper == 'SUM':
        safe_cols = [F.coalesce(col, F.lit(0.0)) for col in incident_cols]
        df_combined = df_pivot.withColumn("final_value",
                                          reduce(lambda a, b: a + b, safe_cols))
    elif agg_method_upper == 'AVERAGE':
        safe_cols = [F.coalesce(col, F.lit(0.0)) for col in incident_cols]
        total_sum = reduce(lambda a, b: a + b, safe_cols)
        present_counts = [F.when(col.isNotNull(), 1).otherwise(0) for col in incident_cols]
        total_present = reduce(lambda a, b: a + b, present_counts)
        df_combined = df_pivot.withColumn(
            "final_value",
            F.when(total_present > 0, total_sum / total_present).otherwise(F.lit(0.0))
        )
    elif agg_method_upper == 'MAX':
        df_combined = df_pivot.withColumn("final_value", F.greatest(*incident_cols))
    elif agg_method_upper == 'MIN':
        df_combined = df_pivot.withColumn("final_value", F.least(*incident_cols))
    elif agg_method_upper == 'WEIGHTED_AVERAGE':
        weighted_cols = [
            F.coalesce(F.col(f"`{fid}`"), F.lit(0.0)) * F.lit(float(weights.get(fid, 0.0)))
            for fid in feature_ids
        ]
        weighted_sum = reduce(lambda a, b: a + b, weighted_cols)
        weight_total = sum(float(weights.get(fid, 0.0)) for fid in feature_ids)
        if weight_total == 0:
            raise ZeroDivisionError("The total sum of provided weights for the target features cannot be zero.")
        df_combined = df_pivot.withColumn("final_value", weighted_sum / F.lit(weight_total))
    else:
        raise NotImplementedError(f"Unsupported aggregation method: {agg_method}")

    return df_combined.select(['entity_id', 'final_value'])



def rank_scoring(
    spark: SparkSession,
    fraud_table: str,
    feature_id,
    range_start: float = 0.0,
    range_end: float = 1.0,
    is_inverse: bool = False,
    apply_threshold: bool = False,
    threshold: float = None,
    method: str = None,
    weights: map = None,
    **kwargs
):
    """Rank-based scoring on 7-day averaged cumulative feature values.

    Reads the 7-day average of cumulative values per entity via
    multiple_col_to_one, then applies rank-based normalization.
    For multi-feature scores (method='weighted_average'), features are
    combined via multiple_col_to_one's inter-feature aggregation.
    """
    if feature_id is None or fraud_table is None:
        raise RuntimeError('feature_id and fraud_table must be defined')

    # Read 7-day averaged cumulative values
    if method == 'weighted_average' and not isinstance(feature_id, str) and weights is not None:
        df = multiple_col_to_one(spark, fraud_table, feature_id,
                                 agg_method='weighted_average', weights=weights)
        df_latest = df.withColumnRenamed("final_value", "feature_value")
    else:
        df = multiple_col_to_one(spark, fraud_table, feature_id)
        df_latest = df.withColumnRenamed("final_value", "feature_value")

    # Guard: empty data
    if df_latest.isEmpty():
        logger.warning(f"No records found for feature_id: {feature_id}")
        return spark.createDataFrame([], schema="entity_id string, score double")

    # Apply Threshold Logic Safely
    if apply_threshold and threshold is not None:
        if is_inverse:
            df_latest = df_latest.withColumn(
                "adjusted_value",
                F.when(F.col("feature_value") >= threshold, F.lit(threshold))
                 .otherwise(F.col("feature_value"))
            )
        else:
            df_latest = df_latest.withColumn(
                "adjusted_value",
                F.when(F.col("feature_value") <= threshold, F.lit(threshold))
                 .otherwise(F.col("feature_value"))
            )
    else:
        df_latest = df_latest.withColumn("adjusted_value", F.col("feature_value"))

    # Handle Windowing Safely
    total_count = df_latest.count()
    if total_count == 0:
        return df_latest.select('entity_id').withColumn("score", F.lit(range_start))

    if is_inverse:
        w = Window.orderBy(F.col("adjusted_value").asc())
    else:
        w = Window.orderBy(F.col("adjusted_value").desc())

    df_ranked = df_latest.withColumn("rank", F.rank().over(w))

    # Calculate Score safely
    if total_count <= 1:
        df_final = df_ranked.withColumn("score", F.lit(float(range_end)))
    else:
        max_rank = df_ranked.agg(F.max("rank")).collect()[0][0]
        df_final = df_ranked.withColumn(
            "score",
            F.lit(float(range_end)) - ((F.col("rank") - 1) / (max_rank - 1)) * (float(range_end) - float(range_start))
        )

    df_final_capped = df_final.withColumn(
        "score",
        F.greatest(F.lit(range_start), F.least(F.col("score"), F.lit(range_end)))
    )

    return df_final_capped.select('entity_id', 'score')


def winsorized_zscoring(
    spark: SparkSession,
    fraud_table: str,
    feature_id,
    is_multiple_col: bool = False,
    aggregation_method: str = None,
    weights: map = None,
    winsorize_percentile: float = 0.99,
    sigmoid_scale: float = 0.5,
    **kwargs
):
    """Winsorized z-score on 7-day averaged cumulative feature values."""
    value_col = 'final_value'
    df_combined = multiple_col_to_one(
        spark=spark,
        fraud_table=fraud_table,
        feature_id=feature_id,
        agg_method=aggregation_method if is_multiple_col else None,
        weights=weights if is_multiple_col else None
    )

    if df_combined.isEmpty():
        logger.warning("No data found for the given feature constraints.")
        return df_combined.withColumn("score", F.lit(0.0))

    stats = df_combined.select(
        F.mean(value_col).alias("mean_val"),
        F.stddev_pop(value_col).alias("stddev_val"),
        F.min(value_col).alias("min_val"),
        F.max(value_col).alias("max_val"),
        F.expr(f"percentile_approx({value_col}, {winsorize_percentile})").alias("percentile_threshold")
    ).collect()[0]

    mean_val = stats["mean_val"]
    stddev_val = stats["stddev_val"] if stats["stddev_val"] and stats["stddev_val"] > 0 else 1.0
    percentile_threshold = stats["percentile_threshold"]

    df_capped = df_combined.withColumn(
        f"{value_col}_capped",
        F.when(F.col(value_col) > percentile_threshold, percentile_threshold)
         .otherwise(F.col(value_col))
    )

    df_capped = df_capped.withColumn(
        "is_extreme_outlier",
        F.when(F.col(value_col) > percentile_threshold, True).otherwise(False)
    )
    df_with_zscore = df_capped.withColumn(
        "zscore",
        (F.col(f"{value_col}_capped") - F.lit(mean_val)) / F.lit(stddev_val)
    )

    df_normalized = df_with_zscore.withColumn(
        "score_sigmoid",
        F.lit(1.0) / (F.lit(1.0) + F.exp(-F.lit(sigmoid_scale) * F.col("zscore")))
    )

    df_normalized = df_normalized.withColumn(
        "score",
        F.when(F.col("is_extreme_outlier") == True, 0.99)
         .otherwise(F.col("score_sigmoid"))
    )

    df_normalized = df_normalized.drop(f"{value_col}_capped", "score_sigmoid")

    df_normalized = df_normalized.withColumn(
        "score",
        F.when(F.col("score") < 0, 0.0)
         .when(F.col("score") > 1, 1.0)
         .otherwise(F.col("score"))
    )

    return df_normalized



def zscore(
    spark: SparkSession,
    fraud_table: str,
    feature_id,
    is_multiple_col: bool = False,
    aggregation_method: str = None,
    weights: map = None,
    range_start: float = 0.0,
    range_end: float = 1.0,
    **kwargs
):
    """Z-score on 7-day averaged cumulative feature values."""
    value_col = 'final_value'

    # Read 7-day averaged cumulative values
    df_combined = multiple_col_to_one(
        spark=spark,
        fraud_table=fraud_table,
        feature_id=feature_id,
        agg_method=aggregation_method if is_multiple_col else None,
        weights=weights if is_multiple_col else None
    )

    if df_combined.isEmpty():
        logger.warning("No data found for the given feature constraints.")
        return df_combined.withColumn("score", F.lit(range_start))

    # Collect statistical definitions safely
    stats = df_combined.select(
        F.mean(value_col).alias("mean_val"),
        F.stddev_pop(value_col).alias("stddev_val")
    ).collect()[0]

    mean_val = stats["mean_val"] if stats["mean_val"] is not None else 0.0

    stddev_val = stats["stddev_val"]
    if stddev_val is None or stddev_val == 0.0:
        stddev_val = 1.0

    df_with_zscore = df_combined.withColumn(
        "zscore",
        (F.col(value_col) - F.lit(mean_val)) / F.lit(stddev_val)
    )

    df_final = df_with_zscore.withColumn("score", F.col("zscore")).drop("zscore")

    return df_final


def log_based_scoring(
    spark: SparkSession,
    fraud_table: str,
    feature_id: str,
    range_start: float = 0,
    range_end: float = 1,
    threshold: int = 0,
    **kwargs
):
    """Log-based scoring on 7-day averaged cumulative feature values."""
    # Read 7-day averaged cumulative value
    df_combined = multiple_col_to_one(spark, fraud_table, feature_id)
    df_agg = df_combined.withColumnRenamed("final_value", "feature_val")

    df_agg = df_agg.filter(F.col("feature_val") > threshold)

    max_val_row = df_agg.select(F.max("feature_val").alias("max_val")).collect()[0]
    global_max = max_val_row["max_val"] if max_val_row["max_val"] is not None else 1.0

    df_scored = df_agg.withColumn(
        "score",
        F.lit(range_start) + (F.lit(range_end) - F.lit(range_start)) *
        (F.log1p(F.col("feature_val")) / F.log1p(F.lit(global_max)))
    )
    df_final_capped = df_scored.withColumn(
        "score",
        F.greatest(F.lit(range_start), F.least(F.col("score"), F.lit(range_end)))
    )

    return df_final_capped.select('entity_id', 'score')


def wilson_fraud_scoring(
    spark: SparkSession,
    fraud_table: str,
    feature_id_numerator: str,
    feature_id_denominator: str,
    range_start: float = 0,
    range_end: float = 1,
    **kwargs
):
    """Wilson score interval scoring on 7-day averaged cumulative feature values."""
    # Read 7-day averaged cumulative values
    df_num = multiple_col_to_one(spark, fraud_table, feature_id_numerator) \
        .withColumnRenamed("final_value", "ups")

    df_den = multiple_col_to_one(spark, fraud_table, feature_id_denominator) \
        .withColumnRenamed("final_value", "n")

    df_joined = df_num.join(df_den, on="entity_id", how="inner").filter(F.col("n") > 0)
    z = 1.96
    df_scored = df_joined.withColumn("p", F.col("ups") / F.col("n"))

    df_scored = df_scored.withColumn(
        "wilson_lower_bound",
        (F.col("p") + (z**2 / (2 * F.col("n"))) -
         z * F.sqrt((F.col("p") * (1 - F.col("p")) / F.col("n")) + (z**2 / (4 * F.col("n")**2)))) /
        (1 + (z**2 / F.col("n")))
    )

    df_final = df_scored.withColumn(
        "score",
        F.lit(range_start) + (F.lit(range_end) - F.lit(range_start)) * F.col("wilson_lower_bound")
    ).select("entity_id", "ups", "n", "p", "score")

    df_final_capped = df_final.withColumn(
        "score",
        F.greatest(F.lit(range_start), F.least(F.col("score"), F.lit(range_end)))
    )

    return df_final_capped.select('entity_id', 'score')


def exponential_decay_scoring(
    spark: SparkSession,
    fraud_table: str,
    feature_id: str,
    range_start: float = 0,
    range_end: float = 1,
    **kwargs
):
    """Min-max normalized scoring on 7-day averaged cumulative feature values.

    The 7-day average smooths over missing DAG runs.  Applies min-max
    normalization and rank-based scoring directly on the averaged value.
    """
    # Read 7-day averaged cumulative value — no decay, no aggregation
    df_combined = multiple_col_to_one(spark, fraud_table, feature_id)
    df_agg = df_combined.withColumnRenamed("final_value", "raw_risk_score")

    min_max = df_agg.agg(
        F.min('raw_risk_score').alias('min_score'),
        F.max('raw_risk_score').alias('max_score')
    ).collect()[0]

    min_score = min_max['min_score']
    max_score = min_max['max_score']

    if max_score is not None and min_score is not None and max_score > min_score:
        df_agg = df_agg.withColumn(
            'score',
            F.lit(range_start) + ((F.col('raw_risk_score') - F.lit(min_score)) /
             (F.lit(max_score) - F.lit(min_score))) * (F.lit(range_end) - F.lit(range_start))
        )
    else:
        df_agg = df_agg.withColumn('score', F.lit(0.5))

    df_final_capped = df_agg.withColumn(
        "score",
        F.greatest(F.lit(range_start), F.least(F.col("score"), F.lit(range_end)))
    )

    return df_final_capped.select('entity_id', 'score')
