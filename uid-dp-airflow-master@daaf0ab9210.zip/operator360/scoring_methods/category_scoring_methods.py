from pyspark.sql import functions as F
from pyspark.sql import SparkSession
import logging
import os
import datetime as dt

logger = logging.getLogger(__name__)

# NOTE: Do NOT call findspark.init() — it sets SPARK_HOME, which causes the
# JVM to load spark-defaults.conf (containing spark.master=local[*]) from
# the pod image.  That conflicts with .remote() and throws:
#   CANNOT_CONFIGURE_SPARK_CONNECT_MASTER
# The pod image already has PySpark installed as a pip package.

# v3.1: when USE_WAIVER_SCORING=true, instance scores live in the staging
# schema (strot.operator360_stagging.features_risk_v1) instead of production.
# Category scoring reads from staging so it uses waiver-aware scores.
FEATURES_RISK_SCHEMA = (
    "strot.operator360_stagging"
    if os.environ.get("USE_WAIVER_SCORING") == "true"
    else "strot.operator360"
)

RISK_WEIGHTAGE = {
    "sustxn_outstate_pkts_score_v1": 2,
    "work_machine_change_score_v1": 4,
    "bio_mfc_fraud_score_v1": 4,
    "bio_sfc_fraud_score_v1": 1,
    "work_opt_hof_score_v1": 4,
    "work_pob_declared_score_v1": 2,
    "work_opt_machinesync_score_v1": 2,
    "hardware_machine_change_score_v1": 4,
    "sustxn_res_mobilechange_score_v1": 2,
    "sustxn_oddhour_pkts_score_v1": 2,
    "hardware_multiple_biodev_score_v1": 4,
    "sustxn_res_namechange_score_v1": 2,
    "work_multiple_optname_score_v1": 4,
}


def get_spark(job_name: str):
    spark = SparkSession.builder \
        .appName(f"opt360-category-scoring-{job_name.replace('_','-')}") \
        .remote("sc://spark-connect-service.strot-spark.svc.cluster.local:15002") \
        .config("spark.sql.legacy.mysql.bitArrayMapping.enabled", "true") \
        .config("spark.default.parallelism", "800") \
        .config("spark.sql.shuffle.partitions", "800") \
        .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
        .config("spark.sql.catalog.strot", "org.apache.iceberg.spark.SparkCatalog") \
        .config("spark.sql.catalog.strot.type", "hive") \
        .config("spark.sql.catalog.strot.uri", "thrift://10.10.116.77:9083") \
        .config("spark.sql.catalog.flink_stream", "org.apache.iceberg.spark.SparkCatalog") \
        .config("spark.sql.catalog.flink_stream.type", "hive") \
        .config("spark.sql.catalog.flink_stream.uri", "thrift://10.10.118.15:9083") \
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
        .config("spark.hadoop.fs.s3a.path.style.access", "true") \
        .config("spark.hadoop.fs.s3a.endpoint", "http://10.10.103.12:425") \
        .config("spark.hadoop.fs.s3a.access.key", "9S0KLIQO7T2XCNGH4P4A") \
        .config("spark.hadoop.fs.s3a.secret.key", "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4") \
        .getOrCreate()
    # Spark Connect tags — visible in the Spark Connect server UI and
    # Prometheus/Grafana dashboards for filtering jobs by pipeline/layer/feature.
    spark.addTag("operator360")
    spark.addTag("layer3-category-scoring")
    spark.addTag(f"feature-{job_name.replace('_','-')}")
    return spark


def _load_latest_risk_scores(spark, max_date, partition_col="feature_id"):
    """Shared helper: reads the latest instance score per entity per feature_id
    from features_risk_v1 within a 7-day lookback window.

    In v3.1 (waiver) mode, reads from strot.operator360_stagging.features_risk_v1
    so category scoring uses waiver-aware instance scores.
    """
    return spark.sql(f"""
        SELECT * FROM (
            SELECT
                entity_id,
                feature_id,
                feature_name,
                feature_value,
                ROW_NUMBER() OVER (
                    PARTITION BY entity_id, {partition_col}
                    ORDER BY timestamp DESC
                ) AS rn
            FROM {FEATURES_RISK_SCHEMA}.features_risk_v1
            WHERE timestamp <= DATE('{max_date}')
            AND timestamp >= date(date('{max_date}') - interval '7' days)
            AND entity_id IS NOT NULL
        )
        WHERE rn = 1
    """)


def softmax_scoring(
    spark: SparkSession,
    max_date: str = None,
    softmax_weightage: float = 0.9,
    risk_weightage: dict = RISK_WEIGHTAGE,
    K: float = 4.0,
    **kwargs
):
    logger.info(f"Softmax weightage: {softmax_weightage}, K: {K}, features: {len(risk_weightage)}")

    if max_date is None:
        max_date = dt.datetime.now().strftime('%Y-%m-%d')

    if risk_weightage is None or len(risk_weightage) == 0:
        raise ValueError("risk_weightage dictionary cannot be empty")

    if not 0 <= softmax_weightage <= 1:
        raise ValueError("softmax_weightage must be between 0 and 1")

    risk_df = _load_latest_risk_scores(spark, max_date, "feature_id")

    # Filter for feature_ids in risk_weightage
    feature_ids = list(risk_weightage.keys())
    risk_df = risk_df.filter(F.col("feature_id").isin(feature_ids))

    # Normalize weights to sum to 1 (probability simplex)
    total_weight = sum(risk_weightage.values())
    normalized_weights = {k: v / total_weight for k, v in risk_weightage.items()}

    weight_mapping = F.create_map([F.lit(x) for pair in normalized_weights.items() for x in pair])

    risk_df = risk_df.withColumn("norm_weight", weight_mapping[F.col("feature_id")])

    risk_df = risk_df.withColumn("exp_term", F.exp(F.lit(K) * F.col("feature_value"))) \
        .withColumn("w_exp", F.col("norm_weight") * F.col("exp_term")) \
        .withColumn("weighted_exp_feature", F.col("norm_weight") * F.col("feature_value") * F.col("exp_term")) \
        .withColumn("weighted_feature", F.col("norm_weight") * F.col("feature_value"))

    summary_df = risk_df.groupBy("entity_id").agg(
        F.sum("weighted_exp_feature").alias("numerator"),
        F.sum("w_exp").alias("denominator"),
        F.sum("weighted_feature").alias("weighted_mean")
    )
    summary_df = summary_df.withColumn("softmax_avg", F.col("numerator") / F.col("denominator")) \
        .withColumn(
            "risk_value",
            F.lit(softmax_weightage) * F.col("softmax_avg") +
            F.lit(1 - softmax_weightage) * F.col("weighted_mean")
        ) \
        .select("entity_id", "risk_value") \
        .orderBy(F.col("risk_value").desc())

    return summary_df


def weighted_average(
    spark: SparkSession,
    max_date: str = None,
    risk_weightage: dict = None,
    **kwargs
):
    logger.info(f"Risk weightage: {len(risk_weightage) if risk_weightage else 0} features")

    if max_date is None:
        max_date = dt.datetime.now().strftime('%Y-%m-%d')

    if risk_weightage is None or len(risk_weightage) == 0:
        raise ValueError("risk_weightage dictionary cannot be empty")

    risk_df = _load_latest_risk_scores(spark, max_date, "feature_name")

    # Filter for feature_ids in risk_weightage
    feature_ids = list(risk_weightage.keys())
    risk_df = risk_df.filter(F.col("feature_id").isin(feature_ids))

    total_sum = sum(risk_weightage.values())

    weight_mapping = F.create_map([F.lit(x) for pair in risk_weightage.items() for x in pair])

    risk_df = risk_df.withColumn("weight", weight_mapping[F.col("feature_id")]) \
        .withColumn("weighted_risk_value", F.col("feature_value") * F.col("weight")) \
        .withColumn("normalized_risk_value", F.col("weighted_risk_value") / F.lit(total_sum))

    summary_df = risk_df.groupBy("entity_id") \
        .agg(F.sum("normalized_risk_value").alias("risk_value")) \
        .orderBy(F.col("risk_value").desc())

    return summary_df


def max_scoring(
    spark: SparkSession,
    max_date: str = None,
    risk_weightage: dict = None,
    **kwargs
):
    logger.info(f"Risk weightage: {len(risk_weightage) if risk_weightage else 0} features")

    if max_date is None:
        max_date = dt.datetime.now().strftime('%Y-%m-%d')

    if risk_weightage is None or len(risk_weightage) == 0:
        raise ValueError("risk_weightage dictionary cannot be empty")

    risk_df = _load_latest_risk_scores(spark, max_date, "feature_id")

    # Filter for feature_ids in risk_weightage
    feature_ids = list(risk_weightage.keys())
    risk_df = risk_df.filter(F.col("feature_id").isin(feature_ids))

    risk_df = risk_df.groupby("entity_id") \
        .agg(F.max("feature_value").alias("risk_value"))

    return risk_df
