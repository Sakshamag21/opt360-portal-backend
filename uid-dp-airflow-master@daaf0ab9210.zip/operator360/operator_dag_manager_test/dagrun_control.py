"""Direct DagRun manipulation: waiting on a triggered child DagRun and clearing
just its failed task instances for an in-place retry (used by Layer-1 category
retries).

Layer 2/3 cascade logic was removed when those DAGs were decoupled to run on
their own independent 4x-daily schedules.
"""
import logging
import time

from airflow.models import DagBag, DagRun
from airflow.utils.session import create_session
from airflow.utils.state import DagRunState

logger = logging.getLogger(__name__)


def wait_for_dagrun(dag_id: str, run_id: str, timeout_seconds: float, poke_interval: int = 20) -> str:
    deadline = time.time() + timeout_seconds
    with create_session() as session:
        while time.time() < deadline:
            dr = (
                session.query(DagRun)
                .filter(DagRun.dag_id == dag_id, DagRun.run_id == run_id)
                .first()
            )
            if dr is not None and dr.state in ("success", "failed"):
                return dr.state
            time.sleep(poke_interval)
    logger.error("Timed out waiting for %s / %s to finish", dag_id, run_id)
    return "timeout"


def clear_failed_tasks_and_wait(dag_id: str, run_id: str, timeout_seconds: float) -> str:
    """Retries a DagRun by clearing ONLY the failed task instances on it and
    letting the scheduler re-run just those - instead of triggering a whole
    new DagRun. This is what keeps a retry from re-inserting a duplicate row
    for anything that already succeeded, since none of the feature SQL (and
    none of the Layer 2/3 Spark writes) are delete-first/merge."""
    with create_session() as session:
        dr = session.query(DagRun).filter(DagRun.dag_id == dag_id, DagRun.run_id == run_id).first()
        if dr is None:
            logger.error("Retry: could not find original DagRun for %s/%s to clear", dag_id, run_id)
            return "not_found"
        exec_date = dr.execution_date

    dag_bag = DagBag(read_dags_from_db=True)
    target_dag = dag_bag.get_dag(dag_id)
    if target_dag is None:
        logger.error("Retry: could not load DAG definition for %s from DagBag", dag_id)
        return "dag_not_found"

    target_dag.clear(
        start_date=exec_date,
        end_date=exec_date,
        only_failed=True,
        dag_run_state=DagRunState.QUEUED,
    )
    logger.info("Retry: cleared failed task instances on %s/%s (execution_date=%s)", dag_id, run_id, exec_date)

    return wait_for_dagrun(dag_id, run_id, timeout_seconds)
