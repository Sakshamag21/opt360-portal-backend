"""v3 controller: Layer 1 orchestrator with retry-until-midnight for categories
that failed the daily promotion run. Runs every 6 hours.

Layer 2 (instance_risk_scoring_v3_test) and Layer 3 (combined_risk_scoring_v3_test)
have been decoupled from this controller - they now run independently on their
own 4x-daily schedules (2am/8am/2pm/8pm IST for Layer 2, 4am/10am/4pm/10pm IST
for Layer 3), so they are no longer blocked by Layer 1 delays. Their idempotency
gates use a date-based pipeline_run_id so a score that already succeeded today
is skipped on subsequent same-day runs.

Split into a package (topology.py, daily_state.py, dagrun_control.py,
reporting.py, this file) instead of one ~900-line module - this file only
defines the DAG and its task callables; everything else is imported.

This file is entirely standalone from operator_dag_manager.py: separate
dag_ids throughout, so v1 keeps running completely unmodified.
"""
from __future__ import annotations
import logging
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import PythonOperator
from airflow.exceptions import AirflowSkipException

from operator360.utils.pipeline_alerts_test import process_and_send_consolidated_alerts
from operator360.utils.pipeline_status_v2_test import read_layer_status, compute_category_verdicts

from operator360.operator_dag_manager_test.topology import (
    CATEGORY_TO_DAG_ID_V2,
    LAYER1_DAG_IDS_V2,
    LAYER1_MAX_PARALLEL,
    LAYER_WAIT_TIMEOUT,
    DAG_ID_TO_CATEGORY_V2,
)
from operator360.operator_dag_manager_test.daily_state import (
    daily_pipeline_run_id,
    read_pending_state,
    write_pending_state,
)
from operator360.operator_dag_manager_test.dagrun_control import (
    clear_failed_tasks_and_wait,
)
from operator360.operator_dag_manager_test.reporting import (
    log_category_diagnostics,
    generate_daily_report,
    generate_retry_report,
)

logger = logging.getLogger(__name__)

default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": datetime(2026, 8, 18),
    "retries": 2,
    "retry_delay": timedelta(minutes=3),
}

with DAG(
    dag_id="controller_pipeline_v3",
    default_args=default_args,
    description="v3: Layer 1 orchestrator with retry-until-midnight for failures "
                "every 6 hours. Layer 2 (instance scoring) and Layer 3 (category scoring) "
                "now run independently on their own 4x-daily schedules.",
    schedule="0 */6 * * *",
    catchup=False,
    max_active_runs=1,
    max_active_tasks=LAYER1_MAX_PARALLEL,
    tags=["controller", "orchestration", "operator360", "v3"],
) as dag:

    start = EmptyOperator(task_id="start")
    end = EmptyOperator(task_id="end", trigger_rule="all_done")
    fail_handler = EmptyOperator(task_id="fail_handler", trigger_rule="one_failed")

    pipeline_run_id_tpl = "{{ run_id }}"

    def _compute_run_mode(**context):
        logical_dt = context.get("data_interval_start")
        if logical_dt is None:
            raise RuntimeError(f"data_interval_start not found in context. Available keys: {list(context.keys())}")
        try:
            if hasattr(logical_dt, "in_timezone"):
                ist_dt = logical_dt.in_timezone("Asia/Kolkata")
            else:
                ist_dt = logical_dt.astimezone(ZoneInfo("Asia/Kolkata"))
        except Exception as e:
            raise RuntimeError(f"Timezone conversion failed. dt={logical_dt!r}, type={type(logical_dt)}, error={e}") from e

        is_daily_run = True
        date_str = ist_dt.strftime("%Y-%m-%d")
        logger.info("Compute Run Mode (v3): logical_dt=%s, IST_date=%s, is_daily_run=%s", logical_dt, date_str, is_daily_run)
        context["ti"].xcom_push(key="is_daily_run", value=is_daily_run)
        # Layer 2/3's ONLY protection against re-appending an already-scored
        # feature - see daily_state.daily_pipeline_run_id for why this has
        # to be stable across today's ticks, not this tick's own run_id.
        context["ti"].xcom_push(key="daily_pipeline_run_id", value=daily_pipeline_run_id(date_str))
        return is_daily_run

    compute_run_mode = PythonOperator(task_id="compute_run_mode", python_callable=_compute_run_mode)

    # ---------------- Layer 1: feature DAGs ----------------
    layer1_triggers = []
    for child_dag_id in LAYER1_DAG_IDS_V2:
        t = TriggerDagRunOperator(
            task_id=f"trigger_layer1_{child_dag_id}",
            trigger_dag_id=child_dag_id,
            conf={
                "pipeline_run_id": pipeline_run_id_tpl,
                "is_daily_run": (
                    "{{ 'true' if ti.xcom_pull(task_ids='compute_run_mode', key='is_daily_run') else 'false' }}"
                ),
            },
            execution_timeout=LAYER_WAIT_TIMEOUT,
            wait_for_completion=True,
            deferrable=False,
            poke_interval=30,
            reset_dag_run=True,
            allowed_states=["success", "failed"],
            failed_states=[],
        )
        layer1_triggers.append(t)
        compute_run_mode >> t
        t >> fail_handler

    def _gate_promotion(**context):
        is_daily_run = context["ti"].xcom_pull(task_ids="compute_run_mode", key="is_daily_run")
        if not is_daily_run:
            raise AirflowSkipException(
                "Not the daily promotion hour - Layer 1 ran for hourly-cadence features only, "
                "skipping judgement and Layer 2/3 this tick"
            )

    gate_promotion = PythonOperator(task_id="gate_promotion", python_callable=_gate_promotion)
    layer1_triggers >> gate_promotion

    def _judge_layer1(**context):
        ti = context["ti"]
        run_id = context["run_id"]
        logical_dt = context["data_interval_start"]
        date_str = logical_dt.astimezone(ZoneInfo("Asia/Kolkata")).strftime("%Y-%m-%d")

        valid_categories = []
        layer1_results = {}
        child_run_ids = {}

        for child_dag_id in LAYER1_DAG_IDS_V2:
            entries = read_layer_status(run_id, child_dag_id)
            verdicts = compute_category_verdicts(entries)
            category = DAG_ID_TO_CATEGORY_V2[child_dag_id]
            is_valid = bool(verdicts.get(category))
            layer1_results[category] = {"valid": is_valid, "reported_features": len(entries)}

            try:
                child_run_ids[category] = ti.xcom_pull(task_ids=f"trigger_layer1_{child_dag_id}")
            except Exception:
                child_run_ids[category] = None

            if is_valid:
                valid_categories.append(category)
            else:
                logger.error("Judge Layer 1 (v3): Category '%s' -> FAILED. Analyzing failures...", category)
                log_category_diagnostics("Layer1", category, child_dag_id, entries)

        ti.xcom_push(key="valid_categories", value=valid_categories)
        ti.xcom_push(key="layer1_results", value=layer1_results)

        state = read_pending_state(date_str)
        if state.get("original_pipeline_run_id") is None:
            state["original_pipeline_run_id"] = run_id
        for category in valid_categories:
            state["categories"].pop(category, None)
            if category not in state["valid_today"]:
                state["valid_today"].append(category)
        for category in set(DAG_ID_TO_CATEGORY_V2.values()) - set(state["valid_today"]):
            entry = state["categories"].setdefault(category, {"attempts": 0})
            entry["attempts"] = entry.get("attempts", 0) + 1
            entry["last_attempt_at"] = datetime.now(ZoneInfo("Asia/Kolkata")).isoformat()
            entry["last_pipeline_run_id"] = run_id
            if child_run_ids.get(category):
                entry["child_dag_run_id"] = child_run_ids[category]
            elif "child_dag_run_id" not in entry:
                logger.error(
                    "Judge Layer 1 (v3): no child_dag_run_id captured for category='%s' - "
                    "retry_pending_categories won't be able to target a clear for it.", category
                )
        write_pending_state(date_str, state)

        logger.info("Layer1 judgement complete (v3) - valid: %s, pending for retry: %s",
                    valid_categories, list(state["categories"].keys()))
        return valid_categories

    judge_layer1 = PythonOperator(task_id="judge_layer1", python_callable=_judge_layer1)
    gate_promotion >> judge_layer1

    # ---------------- Layer 2/3 now run independently ----------------
    # Layer 2 (instance_risk_scoring_v3_test) and Layer 3 (combined_risk_scoring_v3_test)
    # have been decoupled from this controller. They run on their own 4x-daily
    # schedules (4x at 6-hour gaps) and are no longer triggered/gated here.
    # The idempotency gates in those DAGs (date-based pipeline_run_id) ensure
    # a score that already succeeded today is skipped on subsequent runs.

    # ---------------- Daily Report (promotion tick only) ----------------
    generate_daily_report_task = PythonOperator(
        task_id="generate_daily_report",
        python_callable=generate_daily_report,
        trigger_rule="all_done",
    )

    # ---------------- Retry orchestrator (every tick) ----------------
    def _retry_pending_categories(**context):
        logical_dt = context["data_interval_start"]
        date_str = logical_dt.astimezone(ZoneInfo("Asia/Kolkata")).strftime("%Y-%m-%d")

        state = read_pending_state(date_str)
        pending = state.get("categories", {})
        if not pending:
            logger.info("Retry (v3): nothing pending for %s", date_str)
            return

        original_run_id = state.get("original_pipeline_run_id") or context["run_id"]
        newly_valid = []

        for category in list(pending.keys()):
            child_dag_id = CATEGORY_TO_DAG_ID_V2[category]
            info = pending[category]
            child_dag_run_id = info.get("child_dag_run_id")

            if not child_dag_run_id:
                logger.error(
                    "Retry (v3): no child_dag_run_id recorded for category='%s' (dag=%s) - "
                    "judge_layer1 must not have captured it. Skipping this category this tick; "
                    "it stays pending and will be retried once a run_id is available.",
                    category, child_dag_id,
                )
                continue

            logger.info("Retry (v3): clearing failed tasks on %s/%s (category=%s)",
                        child_dag_id, child_dag_run_id, category)
            clear_failed_tasks_and_wait(child_dag_id, child_dag_run_id, LAYER_WAIT_TIMEOUT.total_seconds())

            entries = read_layer_status(original_run_id, child_dag_id)
            verdicts = compute_category_verdicts(entries)
            is_valid = bool(verdicts.get(category))

            info["attempts"] = info.get("attempts", 0) + 1
            info["last_attempt_at"] = datetime.now(ZoneInfo("Asia/Kolkata")).isoformat()

            if is_valid:
                logger.info("Retry (v3): category '%s' now PASSES.", category)
                newly_valid.append(category)
                pending.pop(category, None)
                if category not in state["valid_today"]:
                    state["valid_today"].append(category)
            else:
                logger.info("Retry (v3): category '%s' still failing, will retry again next tick.", category)
                log_category_diagnostics("Layer1-retry", category, child_dag_id, entries)

        write_pending_state(date_str, state)

        if newly_valid:
            logger.info("Retry (v3): newly valid this tick: %s - Layer 2/3 will pick up on their own 4x-daily schedule", newly_valid)
            generate_retry_report(date_str, state, newly_valid, None)

    retry_pending_categories = PythonOperator(
        task_id="retry_pending_categories",
        python_callable=_retry_pending_categories,
        trigger_rule="all_done",
        execution_timeout=timedelta(hours=2),
    )

    # ---------------- Consolidated Alert Summary ----------------
    # NEW: This task reads the S3 error queue, groups all failures by error type,
    # sends ONE consolidated email & Zoho Cliq alert, and clears the queue.
    send_summary_alert = PythonOperator(
        task_id='send_summary_alert',
        python_callable=process_and_send_consolidated_alerts,
        trigger_rule="all_done"
    )

    # ---------------- Wiring ----------------
    start >> compute_run_mode
    judge_layer1 >> generate_daily_report_task
    fail_handler >> generate_daily_report_task

    # Runs on every tick regardless of promotion-hour outcome
    # (trigger_rule=all_done), independent of whether gate_promotion/
    # judge_layer1/etc. ran, skipped, or failed this tick.
    compute_run_mode >> retry_pending_categories
    generate_daily_report_task >> retry_pending_categories
    
    # NEW: Consolidated alert runs at the absolute end of the pipeline
    retry_pending_categories >> send_summary_alert
    send_summary_alert >> end