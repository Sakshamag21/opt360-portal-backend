# NOTE: Do NOT call findspark.init() — it sets SPARK_HOME, which causes the
# JVM to load spark-defaults.conf (containing spark.master=local[*]) from
# the pod image.  That conflicts with .remote() and throws:
#   CANNOT_CONFIGURE_SPARK_CONNECT_MASTER
# The pod image already has PySpark installed as a pip package.
from trino.dbapi import connect
import pandas as pd
import logging

logger = logging.getLogger(__name__)

TRINO_HOST = "10.10.116.75"
TRINO_PORT = 8080
TRINO_USER = "opt360"

# Waiver-aware scoring is v3.1 and lives in the staging schema for
# testing.  When promoted to production, change this to "strot.operator360".
WAIVER_SCHEMA = "strot.operator360_stagging"
WAIVER_TABLE = f"{WAIVER_SCHEMA}.opt_waiver"

# Module-level cache for waiver data.  A pod run processes multiple
# features sequentially, and wilson_fraud_scoring calls
# multiple_col_to_one twice — without this cache each call would
# trigger a separate Trino round-trip for the same waiver data.
_waiver_cache = None

def fetch_waiver_table():
    """Pulls opt_waiver exemption list from staging via Trino.

    Cached at module level so multiple calls within the same pod run
    (e.g. wilson_fraud_scoring calls multiple_col_to_one twice) don't
    each trigger a separate Trino round-trip.
    """
    global _waiver_cache
    if _waiver_cache is not None:
        logger.info(f"Using cached waiver table ({len(_waiver_cache)} rows).")
        return _waiver_cache

    query = f"""
        SELECT opt_id, feature
        FROM {WAIVER_TABLE}
        WHERE date(timestamp) = current_date
    """
    conn = None
    try:
        conn = connect(host=TRINO_HOST, port=TRINO_PORT, user=TRINO_USER)
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        cols = [d[0] for d in cur.description] if cur.description else []
        pdf = pd.DataFrame(body, columns=cols) if cols else pd.DataFrame()
        _waiver_cache = pdf
        logger.info(f"Fetched {len(pdf)} waiver rows from {WAIVER_TABLE}.")
        return pdf
    except Exception as e:
        logger.error(f"Failed to fetch waiver table from {WAIVER_TABLE}: {e}")
        return pd.DataFrame(columns=["opt_id", "feature"])
    finally:
        if conn:
            conn.close()

def apply_waivers(spark, df, entity_col, feature_col):
    """
    Removes waived operator-feature pairs from the raw data.
    Uses a native Spark Left Anti Join (faster & safer for Spark Connect than UDFs).

    spark — the SparkSession from the calling scoring function (no new session created).
    df    — the already-filtered DataFrame (feature_ids + 7-day window applied).
    """
    waiver_pdf = fetch_waiver_table()

    if waiver_pdf.empty:
        logger.info("No waivers found for today.")
        return df

    waiver_df = spark.createDataFrame(waiver_pdf)

    waiver_df = waiver_df.withColumnRenamed("opt_id", "waiver_ent") \
                         .withColumnRenamed("feature", "waiver_feat")

    clean_df = df.join(
        waiver_df,
        (df[entity_col] == waiver_df["waiver_ent"]) & (df[feature_col] == waiver_df["waiver_feat"]),
        "left_anti"
    )

    logger.info(f"Waivers applied successfully using columns: {entity_col}, {feature_col}")
    return clean_df
