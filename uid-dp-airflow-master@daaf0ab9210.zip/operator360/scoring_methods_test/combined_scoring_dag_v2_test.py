# v3 native-Airflow: Same refactor as instance_scoring_dag_v2_test.py — all
# category scoring runs directly on the Airflow worker via Spark Connect,
# no Kubernetes pod is created. See instance_scoring_dag_v2_test.py for the
# full rationale.
import logging
import traceback
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator

from operator360.utils.pipeline_status_v2_test import infer_category
from operator360.work_category_features.insert_work_features_test import update_last_successful_run
from operator360.clickhouse_serving_layer.opt360_clickhouse_feature_store_test import (
    process_single_feature_to_clickhouse,
)
from operator360.utils.pipeline_alerts_test import notify_failure

logger = logging.getLogger(__name__)

job_name = "combined_risk_scoring_v3_test"
desc = "Run all the combined_risk_score (native Airflow, no K8s pod)"

FEATURES = {
    "work_category_score": {
        "feature_name": "work_category_score",
        "feature_version": 2,
        "feature_id": "work_category_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
    },
    "bio_category_score": {
        "feature_name": "bio_category_score",
        "feature_version": 2,
        "feature_id": "bio_category_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
    },
    "hardware_category_score": {
        "feature_name": "hardware_category_score",
        "feature_version": 2,
        "feature_id": "hardware_category_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
    },
    "sustxn_category_score": {
        "feature_name": "sustxn_category_score",
        "feature_version": 2,
        "feature_id": "sustxn_category_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
    },
    "auth_category_score": {
        "feature_name": "auth_category_score",
        "feature_version": 2,
        "feature_id": "auth_category_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
    },
    "risk_score": {
        "feature_name": "risk_score",
        "feature_version": 3,
        "feature_id": "risk_score_v3",
        # risk_score depends on the 5 category scores above.  The dispatcher
        # runs features without dependencies first, then checks that all
        # dependencies succeeded before running this one.
        "dependencies": [
            "work_category_score",
            "bio_category_score",
            "hardware_category_score",
            "sustxn_category_score",
            "auth_category_score",
        ],
        "signal_exists": False,
        "is_daily": True,
    },
}

_features_list = [
    {
        "key": k,
        "feature_name": cfg["feature_name"],
        "feature_version": cfg["feature_version"],
        "feature_id": cfg["feature_id"],
        "dependencies": cfg.get("dependencies", []),
        "category": infer_category(k),
    }
    for k, cfg in FEATURES.items()
]


def run_all_category_scoring(**context):
    """Run all category scoring features on the Airflow worker via Spark
    Connect. No Kubernetes pod is created."""
    from operator360.scoring_methods.scoring_dispatcher import run_dispatcher

    dag_run = context.get("dag_run")
    conf = (dag_run.conf or {}) if dag_run else {}
    pipeline_run_id = conf.get("pipeline_run_id")
    if not pipeline_run_id:
        data_interval = context.get("data_interval_start")
        if data_interval:
            pipeline_run_id = data_interval.strftime("%Y-%m-%d")

    log_url = context.get("task_instance").log_url if context.get("task_instance") else None

    run_dispatcher(
        layer="category",
        features=_features_list,
        pipeline_run_id=pipeline_run_id,
        log_url=log_url,
    )


def sync_all_features_to_store(**context):
    """Sync all category scores to ClickHouse and update last_successful_run
    in the registry. Runs unconditionally — every feature gets synced on
    every DAG run (no idempotency check)."""
    data_interval = context.get("data_interval_start")
    run_date = (
        data_interval.strftime("%Y-%m-%d")
        if data_interval
        else datetime.now().strftime("%Y-%m-%d")
    )

    failures = []
    synced = 0
    for key, cfg in FEATURES.items():
        try:
            update_last_successful_run(cfg["feature_name"], cfg["feature_version"], run_date)
            process_single_feature_to_clickhouse(
                feature_name=cfg["feature_name"],
                feature_version=cfg["feature_version"],
                run_date=run_date,
            )
            synced += 1
            logger.info("Synced %s to ClickHouse + updated last_successful_run", key)
        except Exception:
            error_msg = (
                f"Score sync failed for {cfg['feature_name']} v{cfg['feature_version']}:\n"
                f"{traceback.format_exc()}"
            )
            logger.error(error_msg)
            notify_failure(cfg["feature_name"], "Score Sync Error", error_msg)
            failures.append(key)

    logger.info("Sync complete: %d synced, %d failed", synced, len(failures))
    if failures:
        raise Exception(f"Sync failed for: {failures}")


default_args = {
    "owner": "Piyush Singh",
    "depends_on_past": False,
    "start_date": datetime(2026, 5, 12),
    "execution_timeout": timedelta(minutes=20),
    "email": ["techexe11.yp26@uidai.net.in"],
    "email_on_failure": True,
    "email_on_retry": True,
    "retries": 1,
}

with DAG(
    dag_id=job_name,
    default_args=default_args,
    description=desc,
    schedule="30 22,4,10,16 * * *",  # 4x daily at 4am, 10am, 4pm, 10pm IST
    catchup=False,
    max_active_runs=1,
    max_active_tasks=1,
    tags=["Operator360", "Category Level Scoring", "v3", "native-airflow", "spark-connect"],
) as dag:

    run_all_scoring = PythonOperator(
        task_id="run_all_category_scoring",
        python_callable=run_all_category_scoring,
        execution_timeout=timedelta(hours=1),
    )

    sync_task = PythonOperator(
        task_id="sync_all_features_to_store",
        python_callable=sync_all_features_to_store,
    )

    run_all_scoring >> sync_task
