"""Test the dispatcher's flow logic without actually running Spark jobs.
Mocks _run_scoring_job and the S3 calls."""
import json
import os
import sys

# Add scoring_methods to path so we can import the dispatcher
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scoring_methods"))

import scoring_dispatcher as disp

# ── Mock the S3 and subprocess functions ──
disp._get_s3_client = lambda: None
disp._already_succeeded = lambda pid, did, tk: False  # nothing succeeded yet
written_statuses = []
def mock_write(pid, did, tk, cat, st, error=None, log_url=None):
    written_statuses.append({"task_key": tk, "category": cat, "status": st, "error": error})
disp._write_status = mock_write

# Mock subprocess: succeed for all except "bio_mfc_fraud_score"
call_log = []
def mock_run(script, name, ver):
    call_log.append((name, ver))
    return 0 if "bio_mfc" not in name else 1
disp._run_scoring_job = mock_run

# ── Set up env vars ──
features = [
    {"key": "sustxn_score", "feature_name": "sustxn_score", "feature_version": 2,
     "feature_id": "sustxn_score_v2", "dependencies": [], "category": "sustxn"},
    {"key": "bio_mfc_fraud_score", "feature_name": "bio_mfc_fraud_score", "feature_version": 2,
     "feature_id": "bio_mfc_fraud_score_v2", "dependencies": [], "category": "bio"},
    {"key": "work_score", "feature_name": "work_score", "feature_version": 2,
     "feature_id": "work_score_v2", "dependencies": [], "category": "work"},
]
os.environ["SCORING_FEATURES"] = json.dumps(features)
os.environ["PIPELINE_RUN_ID"] = "2026-10-19"
os.environ["TASK_LOG_URL"] = "http://test"

# ── Run the dispatcher (patched to not call sys.exit) ──
sys.argv = ["scoring_dispatcher.py", "--layer", "instance"]
disp.sys = sys  # ensure same module

try:
    disp.main()
    exit_code = 0
except SystemExit as e:
    exit_code = e.code

print()
print("=== TEST RESULTS ===")
print("Exit code:", exit_code)
print("Jobs called:", call_log)
print("Statuses written:")
for s in written_statuses:
    print(" ", s)
assert exit_code == 1, "Should exit 1 because bio_mfc_fraud_score failed"
assert len(call_log) == 3, "Should have called all 3 features"
assert ("bio_mfc_fraud_score", 2) in call_log
successes = [s for s in written_statuses if s["status"] == "success"]
failures = [s for s in written_statuses if s["status"] == "failed"]
assert len(successes) == 2, f"Expected 2 successes, got {len(successes)}"
assert len(failures) == 1, f"Expected 1 failure, got {len(failures)}"
print()
print("ALL ASSERTIONS PASSED")

# ── Test 2: idempotency — feature already succeeded should be skipped ──
print()
print("=== TEST 2: Idempotency ===")
call_log.clear()
written_statuses.clear()
disp._already_succeeded = lambda pid, did, tk: True  # everything already succeeded
try:
    disp.main()
    exit_code = 0
except SystemExit as e:
    exit_code = e.code
print("Exit code:", exit_code)
print("Jobs called:", call_log)
assert len(call_log) == 0, "Should not call any jobs (all already succeeded)"
assert exit_code == 0, "Should exit 0 (all skipped = success)"
print("IDEMPOTENCY TEST PASSED")

# ── Test 3: dependency check — risk_score should skip if deps failed ──
print()
print("=== TEST 3: Dependency check ===")
call_log.clear()
written_statuses.clear()
features_with_deps = [
    {"key": "work_category_score", "feature_name": "work_category_score", "feature_version": 2,
     "feature_id": "work_cat_v2", "dependencies": [], "category": "work"},
    {"key": "risk_score", "feature_name": "risk_score", "feature_version": 3,
     "feature_id": "risk_score_v3", "dependencies": ["work_category_score"], "category": None},
]
os.environ["SCORING_FEATURES"] = json.dumps(features_with_deps)
disp._already_succeeded = lambda pid, did, tk: False
def mock_run_fail_first(script, name, ver):
    call_log.append((name, ver))
    return 1 if "work_category" in name else 0
disp._run_scoring_job = mock_run_fail_first
try:
    disp.main()
    exit_code = 0
except SystemExit as e:
    exit_code = e.code
print("Exit code:", exit_code)
print("Jobs called:", call_log)
skipped = [s for s in written_statuses if s["status"] == "skipped"]
print("Skipped:", skipped)
assert ("risk_score", 3) not in call_log, "risk_score should NOT have been called (dep failed)"
assert len(skipped) == 1, "risk_score should be skipped"
assert "not met" in skipped[0]["error"]
print("DEPENDENCY TEST PASSED")
print()
print("ALL TESTS PASSED")
