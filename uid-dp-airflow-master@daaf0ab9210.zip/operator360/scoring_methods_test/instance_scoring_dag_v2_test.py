# v3 native-Airflow: Runs all instance scoring directly on the Airflow worker
# via Spark Connect — NO Kubernetes pod is created. The Airflow worker
# connects to sc://spark-connect-service.strot-spark.svc.cluster.local:15002
# and the Spark Connect server creates executor pods on the cluster as needed.
#
# This eliminates the ResourceQuota exhaustion issue (pods "..." is forbidden:
# exceeded quota mem-cpu-demo) that blocked the KubernetesPodOperator approach.
#
# DAG shape:
#   1. PythonOperator  →  run_all_instance_scoring  (dispatcher, ~2h timeout)
#   2. PythonOperator  →  sync_all_features_to_store
import logging
import traceback
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator

from operator360.utils.pipeline_status_v2_test import infer_category
from operator360.work_category_features.insert_work_features_test import update_last_successful_run
from operator360.clickhouse_serving_layer.opt360_clickhouse_feature_store_test import (
    process_single_feature_to_clickhouse,
)
from operator360.utils.pipeline_alerts_test import notify_failure

logger = logging.getLogger(__name__)

job_name = "instance_risk_scoring_v3_test_1"
desc = "Run all the instance_risk_scoring (native Airflow, no K8s pod)"

FEATURES = {
    "sustxn_res_mobilechange_score": {
        "feature_name": "sustxn_res_mobilechange_score",
        "feature_version": 2,
        "feature_id": "sustxn_res_mobilechange_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_res_mobilechange_instances_count_cumulative_v2",
    },
    "auth_failure_ratio_score": {
        "feature_name": "auth_failure_ratio_score",
        "feature_version": 2,
        "feature_id": "auth_failure_ratio_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "",
    },
    "hardware_machine_signature_change_score": {
        "feature_name": "hardware_machine_signature_change_score",
        "feature_version": 2,
        "feature_id": "hardware_machine_signature_change_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "hardware_machine_change_instances_24h_v2",
    },
    "sustxn_oddhour_pkts_score": {
        "feature_name": "sustxn_oddhour_pkts_score",
        "feature_version": 2,
        "feature_id": "sustxn_oddhour_pkts_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_oddhour_pkts_instances_24h_v2",
    },
    "sustxn_outstate_pkts_score": {
        "feature_name": "sustxn_outstate_pkts_score",
        "feature_version": 2,
        "feature_id": "sustxn_outstate_pkts_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_outstate_pkts_instances_24h_v2",
    },
    "work_opt_hof_score": {
        "feature_name": "work_opt_hof_score",
        "feature_version": 2,
        "feature_id": "work_opt_hof_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "",
    },
    "work_pob_declared_score": {
        "feature_name": "work_pob_declared_score",
        "feature_version": 2,
        "feature_id": "work_pob_declared_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "work_pob_declared_instances_v1",
    },
    "work_machine_change_score": {
        "feature_name": "work_machine_change_score",
        "feature_version": 2,
        "feature_id": "work_machine_change_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "work_machine_change_instances_24h_v1",
    },
    "work_opt_machinesync_score": {
        "feature_name": "work_opt_machinesync_score",
        "feature_version": 2,
        "feature_id": "work_opt_machinesync_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "",
    },
    "hardware_multiple_biodev_score": {
        "feature_name": "hardware_multiple_biodev_score",
        "feature_version": 2,
        "feature_id": "hardware_multiple_biodev_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "hardware_multiple_biodev_instances_24h_v2",
    },
    "auth_oddhour_txn_score": {
        "feature_name": "auth_oddhour_txn_score",
        "feature_version": 2,
        "feature_id": "auth_oddhour_txn_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "auth_oddhour_incidents_24h_v1",
    },
    "sustxn_parallel_enrolment_score": {
        "feature_name": "sustxn_parallel_enrolment_score",
        "feature_version": 2,
        "feature_id": "sustxn_parallel_enrolment_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_parallel_enrolment_instances_7d_v1",
    },
    "sustxn_res_namechange_score": {
        "feature_name": "sustxn_res_namechange_score",
        "feature_version": 2,
        "feature_id": "sustxn_res_namechange_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_res_namechange_instances_count_cumulative_v2",
    },
    "bio_mfc_fraud_score": {
        "feature_name": "bio_mfc_fraud_score",
        "feature_version": 2,
        "feature_id": "bio_mfc_fraud_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "",
    },
    "work_multiple_optname_score": {
        "feature_name": "work_multiple_optname_score",
        "feature_version": 2,
        "feature_id": "work_multiple_optname_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "work_operator_name_unique_count_cumulative_v1",
    },
    "work_multiple_optname_zscore": {
        "feature_name": "work_multiple_optname_zscore",
        "feature_version": 2,
        "feature_id": "work_multiple_optname_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "work_operator_name_unique_count_cumulative_v1",
    },
    "sustxn_oddhour_pkts_zscore": {
        "feature_name": "sustxn_oddhour_pkts_zscore",
        "feature_version": 2,
        "feature_id": "sustxn_oddhour_pkts_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_oddhour_pkts_instances_24h_v2",
    },
    "work_machine_change_zscore": {
        "feature_name": "work_machine_change_zscore",
        "feature_version": 2,
        "feature_id": "work_machine_change_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "work_machine_change_instances_24h_v1",
    },
    "work_opt_machinesync_zscore": {
        "feature_name": "work_opt_machinesync_zscore",
        "feature_version": 2,
        "feature_id": "work_opt_machinesync_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "",
    },
    "hardware_machine_signature_change_zscore": {
        "feature_name": "hardware_machine_signature_change_zscore",
        "feature_version": 2,
        "feature_id": "hardware_machine_signature_change_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "hardware_machine_change_instances_24h_v2",
    },
    "work_pob_declared_zscore": {
        "feature_name": "work_pob_declared_zscore",
        "feature_version": 2,
        "feature_id": "work_pob_declared_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "work_pob_declared_instances_v1",
    },
    "sustxn_outstate_pkts_zscore": {
        "feature_name": "sustxn_outstate_pkts_zscore",
        "feature_version": 2,
        "feature_id": "sustxn_outstate_pkts_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_outstate_pkts_instances_24h_v2",
    },
    "bio_mfc_fraud_zscore": {
        "feature_name": "bio_mfc_fraud_zscore",
        "feature_version": 2,
        "feature_id": "bio_mfc_fraud_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "",
    },
    "bio_sfc_fraud_zscore": {
        "feature_name": "bio_sfc_fraud_zscore",
        "feature_version": 2,
        "feature_id": "bio_sfc_fraud_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "",
    },
    "work_opt_hof_zscore": {
        "feature_name": "work_opt_hof_zscore",
        "feature_version": 2,
        "feature_id": "work_opt_hof_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "",
    },
    "hardware_multiple_biodev_zscore": {
        "feature_name": "hardware_multiple_biodev_zscore",
        "feature_version": 2,
        "feature_id": "hardware_multiple_biodev_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "hardware_multiple_biodev_instances_24h_v2",
    },
    "sustxn_res_namechange_zscore": {
        "feature_name": "sustxn_res_namechange_zscore",
        "feature_version": 2,
        "feature_id": "sustxn_res_namechange_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_res_namechange_instances_count_cumulative_v2",
    },
    "sustxn_res_mobilechange_zscore": {
        "feature_name": "sustxn_res_mobilechange_zscore",
        "feature_version": 2,
        "feature_id": "sustxn_res_mobilechange_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_res_mobilechange_instances_count_cumulative_v2",
    },
    "document_category_score": {
        "feature_name": "document_category_score",
        "feature_version": 2,
        "feature_id": "document_category_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "",
    },
}

# Pre-serialize the feature list once at DAG parse time so the PythonOperator
# receives a plain Python list (no Jinja templating concerns).
_features_list = [
    {
        "key": k,
        "feature_name": cfg["feature_name"],
        "feature_version": cfg["feature_version"],
        "feature_id": cfg["feature_id"],
        "dependencies": cfg.get("dependencies", []),
        "category": infer_category(k),
    }
    for k, cfg in FEATURES.items()
]


def run_all_instance_scoring(**context):
    """Run all instance scoring features on the Airflow worker via Spark
    Connect. No Kubernetes pod is created."""
    from operator360.scoring_methods.scoring_dispatcher import run_dispatcher

    dag_run = context.get("dag_run")
    conf = (dag_run.conf or {}) if dag_run else {}
    pipeline_run_id = conf.get("pipeline_run_id")
    if not pipeline_run_id:
        data_interval = context.get("data_interval_start")
        if data_interval:
            pipeline_run_id = data_interval.strftime("%Y-%m-%d")

    log_url = context.get("task_instance").log_url if context.get("task_instance") else None

    run_dispatcher(
        layer="instance",
        features=_features_list,
        pipeline_run_id=pipeline_run_id,
        log_url=log_url,
    )


def sync_all_features_to_store(**context):
    """Sync all features to ClickHouse and update last_successful_run in
    the registry. Runs unconditionally — every feature gets synced on
    every DAG run (no idempotency check)."""
    data_interval = context.get("data_interval_start")
    run_date = (
        data_interval.strftime("%Y-%m-%d")
        if data_interval
        else datetime.now().strftime("%Y-%m-%d")
    )

    failures = []
    synced = 0
    for key, cfg in FEATURES.items():
        try:
            update_last_successful_run(cfg["feature_name"], cfg["feature_version"], run_date)
            process_single_feature_to_clickhouse(
                feature_name=cfg["feature_name"],
                feature_version=cfg["feature_version"],
                run_date=run_date,
            )
            synced += 1
            logger.info("Synced %s to ClickHouse + updated last_successful_run", key)
        except Exception:
            error_msg = (
                f"Score sync failed for {cfg['feature_name']} v{cfg['feature_version']}:\n"
                f"{traceback.format_exc()}"
            )
            logger.error(error_msg)
            notify_failure(cfg["feature_name"], "Score Sync Error", error_msg)
            failures.append(key)

    logger.info("Sync complete: %d synced, %d failed", synced, len(failures))
    if failures:
        raise Exception(f"Sync failed for: {failures}")


default_args = {
    "owner": "Piyush Singh",
    "depends_on_past": False,
    "start_date": datetime(2026, 5, 12),
    "execution_timeout": timedelta(minutes=20),
    "email": ["techexe11.yp26@uidai.net.in"],
    "email_on_failure": True,
    "email_on_retry": True,
    "retries": 1,
}

with DAG(
    dag_id=job_name,
    default_args=default_args,
    description=desc,
    schedule="30 20,2,8,14 * * *",  # 4x daily at 2am, 8am, 2pm, 8pm IST
    catchup=False,
    max_active_runs=1,
    max_active_tasks=1,
    tags=["Operator360", "Instance Level Scoring", "v3", "native-airflow", "spark-connect"],
) as dag:

    run_all_scoring = PythonOperator(
        task_id="run_all_instance_scoring",
        python_callable=run_all_instance_scoring,
        execution_timeout=timedelta(hours=2),
    )

    sync_task = PythonOperator(
        task_id="sync_all_features_to_store",
        python_callable=sync_all_features_to_store,
    )

    run_all_scoring >> sync_task
