"""Test the refactored run_dispatcher() function — no Spark, no S3, no pip.
Mocks everything and verifies the core flow, idempotency, and dependency
logic still work after the refactor."""
import json
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scoring_methods"))
import scoring_dispatcher as disp

# ── Mock dependencies ──
disp.ensure_dependencies = lambda: None  # skip pip install
disp._get_s3_client = lambda: None
disp._already_succeeded = lambda pid, did, tk: False
written_statuses = []
def mock_write(pid, did, tk, cat, st, error=None, log_url=None):
    written_statuses.append({"task_key": tk, "category": cat, "status": st, "error": error})
disp._write_status = mock_write

call_log = []
def mock_run(script, name, ver):
    call_log.append((name, ver))
    return 0 if "bio_mfc" not in name else 1
disp._run_scoring_job = mock_run

# ── Test 1: basic flow (one feature fails) ──
print("=== TEST 1: Basic flow ===")
features = [
    {"key": "sustxn_score", "feature_name": "sustxn_score", "feature_version": 2,
     "feature_id": "sustxn_score_v2", "dependencies": [], "category": "sustxn"},
    {"key": "bio_mfc_fraud_score", "feature_name": "bio_mfc_fraud_score", "feature_version": 2,
     "feature_id": "bio_mfc_fraud_score_v2", "dependencies": [], "category": "bio"},
    {"key": "work_score", "feature_name": "work_score", "feature_version": 2,
     "feature_id": "work_score_v2", "dependencies": [], "category": "work"},
]
try:
    disp.run_dispatcher("instance", features, "2026-10-19", "http://log")
    print("FAIL: should have raised RuntimeError")
except RuntimeError as e:
    print("OK: raised RuntimeError:", e)

assert len(call_log) == 3
successes = [s for s in written_statuses if s["status"] == "success"]
failures = [s for s in written_statuses if s["status"] == "failed"]
assert len(successes) == 2
assert len(failures) == 1
print("TEST 1 PASSED\n")

# ── Test 2: idempotency ──
print("=== TEST 2: Idempotency ===")
call_log.clear()
written_statuses.clear()
disp._already_succeeded = lambda pid, did, tk: True
result = disp.run_dispatcher("instance", features, "2026-10-19", "http://log")
assert len(call_log) == 0, "Should not call any jobs"
assert len(result["succeeded"]) == 3
assert len(result["skipped"]) == 3
print("TEST 2 PASSED\n")

# ── Test 3: dependency check ──
print("=== TEST 3: Dependency check ===")
call_log.clear()
written_statuses.clear()
disp._already_succeeded = lambda pid, did, tk: False
features_with_deps = [
    {"key": "work_category_score", "feature_name": "work_category_score", "feature_version": 2,
     "feature_id": "work_cat_v2", "dependencies": [], "category": "work"},
    {"key": "risk_score", "feature_name": "risk_score", "feature_version": 3,
     "feature_id": "risk_score_v3", "dependencies": ["work_category_score"], "category": None},
]
def mock_run_fail_first(script, name, ver):
    call_log.append((name, ver))
    return 1 if "work_category" in name else 0
disp._run_scoring_job = mock_run_fail_first
try:
    disp.run_dispatcher("category", features_with_deps, "2026-10-19", "http://log")
    print("FAIL: should have raised")
except RuntimeError:
    pass
assert ("risk_score", 3) not in call_log, "risk_score should NOT have been called"
skipped = [s for s in written_statuses if s["status"] == "skipped"]
assert len(skipped) == 1
assert "not met" in skipped[0]["error"]
print("TEST 3 PASSED\n")

# ── Test 4: MetricsSink works without Pushgateway ──
print("=== TEST 4: MetricsSink (no Pushgateway) ===")
os.environ.pop("PUSHGATEWAY_URL", None)
m = disp.MetricsSink()
assert m.pushgateway_url is None
m.record_feature("instance", "test_feature", "success", 1.5)
m.record_run("instance", "success", 1, 1, 0, 0, 1.5)
m.push(grouping_key={})
print("TEST 4 PASSED (no exceptions, metrics logged)\n")

print("ALL TESTS PASSED")
