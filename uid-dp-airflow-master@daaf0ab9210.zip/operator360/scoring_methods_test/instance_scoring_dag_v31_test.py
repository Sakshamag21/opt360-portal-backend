# v3.1: Waiver-aware instance scoring DAG.
# Same as instance_scoring_dag_v2_test.py (v3) except:
#   - Different dag_id/job_name (instance_risk_scoring_v31_test)
#   - Downloads instance_scoring_methods_test.py + waiver_aware_scoring.py
#     instead of instance_scoring_methods.py
#   - Sets USE_WAIVER_SCORING=true env var so instances_main.py imports
#     the test (waiver-aware) scoring methods
#   - Writes to strot.operator360_stagging (waiver table is there)
#
# The waiver filter removes operator-feature pairs listed in
# strot.operator360_stagging.opt_waiver from the 7-day averaged data
# BEFORE scoring, so waived operators don't get penalized.
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from datetime import datetime, timedelta
import logging
import traceback
from kubernetes.client import models as k8s

from operator360.utils.pipeline_status_v2_test import infer_category, wrap_shell_with_status_report, make_idempotency_gate
from operator360.work_category_features.insert_work_features_test import update_last_successful_run
from operator360.clickhouse_serving_layer.opt360_clickhouse_feature_store_test import process_single_feature_to_clickhouse
from operator360.utils.pipeline_alerts_test import notify_failure

logger = logging.getLogger(__name__)

job_name = "instance_risk_scoring_v31_test"
desc = "Run all the instance_risk_scoring with waiver-aware filtering (v3.1)"

custom_toleration = k8s.V1Toleration(
    key="strot",
    operator='Equal',
    value='true',
    effect='NoSchedule'
)

FEATURES = {
    "sustxn_res_mobilechange_score": {
        "feature_name": "sustxn_res_mobilechange_score",
        "feature_version": 2,
        "feature_id": "sustxn_res_mobilechange_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_res_mobilechange_instances_count_cumulative_v2"
    },
    "auth_failure_ratio_score": {
        "feature_name": "auth_failure_ratio_score",
        "feature_version": 2,
        "feature_id": "auth_failure_ratio_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": ''
    },
    "hardware_machine_signature_change_score": {
        "feature_name": "hardware_machine_signature_change_score",
        "feature_version": 2,
        "feature_id": "hardware_machine_signature_change_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "hardware_machine_change_instances_24h_v2"
    },
    "sustxn_oddhour_pkts_score": {
        "feature_name": "sustxn_oddhour_pkts_score",
        "feature_version": 2,
        "feature_id": "sustxn_oddhour_pkts_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_oddhour_pkts_instances_24h_v2"
    },
    "sustxn_outstate_pkts_score": {
        "feature_name": "sustxn_outstate_pkts_score",
        "feature_version": 2,
        "feature_id": "sustxn_outstate_pkts_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_outstate_pkts_instances_24h_v2"
    },
    "work_opt_hof_score": {
        "feature_name": "work_opt_hof_score",
        "feature_version": 2,
        "feature_id": "work_opt_hof_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": ''
    },
    "work_pob_declared_score": {
        "feature_name": "work_pob_declared_score",
        "feature_version": 2,
        "feature_id": "work_pob_declared_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "work_pob_declared_instances_v1"
    },
    "work_machine_change_score": {
        "feature_name": "work_machine_change_score",
        "feature_version": 2,
        "feature_id": "work_machine_change_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "work_machine_change_instances_24h_v1"
    },
    "work_opt_machinesync_score": {
        "feature_name": "work_opt_machinesync_score",
        "feature_version": 2,
        "feature_id": "work_opt_machinesync_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": ''
    },
    "hardware_multiple_biodev_score": {
        "feature_name": "hardware_multiple_biodev_score",
        "feature_version": 2,
        "feature_id": "hardware_multiple_biodev_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "hardware_multiple_biodev_instances_24h_v2"
    },
    "auth_oddhour_txn_score": {
        "feature_name": "auth_oddhour_txn_score",
        "feature_version": 2,
        "feature_id": "auth_oddhour_txn_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "auth_oddhour_incidents_24h_v1"
    },
    "sustxn_parallel_enrolment_score": {
        "feature_name": "sustxn_parallel_enrolment_score",
        "feature_version": 2,
        "feature_id": "sustxn_parallel_enrolment_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_parallel_enrolment_instances_7d_v1"
    },
    "sustxn_res_namechange_score": {
        "feature_name": "sustxn_res_namechange_score",
        "feature_version": 2,
        "feature_id": "sustxn_res_namechange_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_res_namechange_instances_count_cumulative_v2"
    },
    "bio_mfc_fraud_score": {
        "feature_name": "bio_mfc_fraud_score",
        "feature_version": 2,
        "feature_id": "bio_mfc_fraud_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": ''
    },
    "work_multiple_optname_score": {
        "feature_name": "work_multiple_optname_score",
        "feature_version": 2,
        "feature_id": "work_multiple_optname_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "work_operator_name_unique_count_cumulative_v1"
    },
    "work_multiple_optname_zscore": {
        "feature_name": "work_multiple_optname_zscore",
        "feature_version": 2,
        "feature_id": "work_multiple_optname_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "work_operator_name_unique_count_cumulative_v1"
    },
    "sustxn_oddhour_pkts_zscore": {
        "feature_name": "sustxn_oddhour_pkts_zscore",
        "feature_version": 2,
        "feature_id": "sustxn_oddhour_pkts_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_oddhour_pkts_instances_24h_v2"
    },
    "work_machine_change_zscore": {
        "feature_name": "work_machine_change_zscore",
        "feature_version": 2,
        "feature_id": "work_machine_change_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "work_machine_change_instances_24h_v1"
    },
    "work_opt_machinesync_zscore": {
        "feature_name": "work_opt_machinesync_zscore",
        "feature_version": 2,
        "feature_id": "work_opt_machinesync_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": ''
    },
    "hardware_machine_signature_change_zscore": {
        "feature_name": "hardware_machine_signature_change_zscore",
        "feature_version": 2,
        "feature_id": "hardware_machine_signature_change_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "hardware_machine_change_instances_24h_v2"
    },
    "work_pob_declared_zscore": {
        "feature_name": "work_pob_declared_zscore",
        "feature_version": 2,
        "feature_id": "work_pob_declared_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "work_pob_declared_instances_v1"
    },
    "sustxn_outstate_pkts_zscore": {
        "feature_name": "sustxn_outstate_pkts_zscore",
        "feature_version": 2,
        "feature_id": "sustxn_outstate_pkts_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_outstate_pkts_instances_24h_v2"
    },
    "bio_mfc_fraud_zscore": {
        "feature_name": "bio_mfc_fraud_zscore",
        "feature_version": 2,
        "feature_id": "bio_mfc_fraud_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": ''
    },
    "bio_sfc_fraud_zscore": {
        "feature_name": "bio_sfc_fraud_zscore",
        "feature_version": 2,
        "feature_id": "bio_sfc_fraud_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": ''
    },
    "work_opt_hof_zscore": {
        "feature_name": "work_opt_hof_zscore",
        "feature_version": 2,
        "feature_id": "work_opt_hof_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": ''
    },
    "hardware_multiple_biodev_zscore": {
        "feature_name": "hardware_multiple_biodev_zscore",
        "feature_version": 2,
        "feature_id": "hardware_multiple_biodev_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "hardware_multiple_biodev_instances_24h_v2"
    },
    "sustxn_res_namechange_zscore": {
        "feature_name": "sustxn_res_namechange_zscore",
        "feature_version": 2,
        "feature_id": "sustxn_res_namechange_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_res_namechange_instances_count_cumulative_v2"
    },
    "sustxn_res_mobilechange_zscore": {
        "feature_name": "sustxn_res_mobilechange_zscore",
        "feature_version": 2,
        "feature_id": "sustxn_res_mobilechange_zscore_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": "sustxn_res_mobilechange_instances_count_cumulative_v2"
    },
    "document_category_score": {
        "feature_name": "document_category_score",
        "feature_version": 2,
        "feature_id": "document_category_score_v2",
        "dependencies": [],
        "signal_exists": False,
        "is_daily": True,
        "dependent_feature_id": ''
    }
}


def run_signals(feature_id):
    try:
        from operator360.signal_mechanism.signals_producer import get_signals_info, push_signals_kafka
        res_try = get_signals_info(feature_id)
        for signal_metadata in res_try:
            push_signals_kafka(signal_metadata)
    except Exception as e:
        logger.error(f"Error in generating signal for feature id: {feature_id}, error: {e}")


def sync_feature_to_store(feature_name, feature_version, run_date):
    task_logger = logging.getLogger(f"sync {feature_name}:v{feature_version}")
    try:
        update_last_successful_run(feature_name, feature_version, run_date)
        process_single_feature_to_clickhouse(
            feature_name=feature_name,
            feature_version=feature_version,
            run_date=run_date,
        )
        task_logger.info(
            "Synced %s v%s for %s to ClickHouse and updated last_successful_run",
            feature_name, feature_version, run_date,
        )
    except Exception:
        error_msg = f"Score sync failed for {feature_name} v{feature_version}:\n{traceback.format_exc()}"
        task_logger.error(error_msg)
        notify_failure(feature_name, "Score Sync Error", error_msg)
        raise


default_args = {
    "owner": "Piyush Singh",
    "depends_on_past": False,
    "start_date": datetime(2026, 5, 12),
    "execution_timeout": timedelta(minutes=20),
    "email": ["techexe11.yp26@uidai.net.in"],
    "email_on_failure": True,
    "email_on_retry": True,
    "retries": 1,
}

with DAG(
    dag_id=job_name,
    default_args=default_args,
    description=desc,
    # Offset 1hr after v3 production (30 20,2,8,14) to avoid concurrent
    # Spark Connect / table contention.
    schedule="30 21,3,9,15 * * *",  # 4x daily at 3am, 9am, 3pm, 9pm IST (UTC+5:30)
    catchup=False,
    max_active_runs=3,
    max_active_tasks=1,
    tags=["Operator360", "Instance Level Scoring", "v3.1", "Waiver-Aware"]
) as dag:
    tasks = {}
    idempotency_gates = {}

    for key, cfg in FEATURES.items():
        feature_category = infer_category(key)
        task_id = f'task-id-{cfg["feature_name"]}-{cfg["feature_version"]}'
        # Spark Connect model: sync the entire operator360/ directory from
        # S3 (preserving subdirectory structure), then run instances_main.py
        # from scoring_methods/ with PYTHONPATH set so cross-directory imports
        # (e.g. waiver_aware_scoring from utils/) resolve correctly.
        # The USE_WAIVER_SCORING env var tells instances_main.py to import
        # instance_scoring_methods_test (waiver-aware) instead of
        # instance_scoring_methods (production).
        inner_cmd = f"""pip install --quiet --index-url http://10.10.206.59:8080/repository/pypi-proxy/simple --trusted-host 10.10.206.59 trino 2>/dev/null || true; python3 -c "
import os,boto3
s3=boto3.client('s3',endpoint_url='http://10.10.103.12:425',aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4')
b,p,d='prd-bi-data-platform-uploads','af_dags_hdc/operator360/','/tmp/operator360'
os.makedirs(d,exist_ok=True)
for page in s3.get_paginator('list_objects_v2').paginate(Bucket=b,Prefix=p):
 for o in page.get('Contents',[]):
  k=o['Key']
  if k.endswith('/'):continue
  lp=os.path.join(d,k[len(p):])
  os.makedirs(os.path.dirname(lp),exist_ok=True)
  s3.download_file(b,k,lp)
print('Downloaded operator360 from S3')
" && cd /tmp/operator360/scoring_methods && PYTHONPATH=/tmp/operator360/scoring_methods:/tmp/operator360/utils python3 instances_main.py {cfg["feature_name"]} {cfg["feature_version"]}"""
        task = KubernetesPodOperator(
            namespace='strot-spark',
            service_account_name='strot-service-account',
            image='hbdc-harbor-registry-prod.uidai.net.in/data-platform/pyspark-duckdb-sqlmesh:4.0.2_0.235.4_2',
            config_file='/opt/airflow/dags/gpu_kubeconfig_hdc',
            name=f'zzzz-v31-{cfg["feature_name"]}-{cfg["feature_version"]}',
            task_id=task_id,
            cmds=["bash", "-c"],
            arguments=[
                wrap_shell_with_status_report(inner_cmd, dag_id=job_name, task_key=task_id, category=feature_category)
            ],
            env_vars={
                "PIPELINE_RUN_ID": "{{ dag_run.conf.get('pipeline_run_id') or data_interval_start | ds }}",
                "TASK_LOG_URL": "{{ ti.log_url }}",
                "SPARK_REMOTE": "sc://spark-connect-service.strot-spark.svc.cluster.local:15002",
                "AWS_ACCESS_KEY_ID": "9S0KLIQO7T2XCNGH4P4A",
                "AWS_SECRET_ACCESS_KEY": "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4",
                "USE_WAIVER_SCORING": "true",
            },
            container_resources=k8s.V1ResourceRequirements(
                requests={"cpu": "500m", "memory": "4Gi"},
                limits={"cpu": "500m", "memory": "4Gi"}
            ),
            tolerations=[custom_toleration],
            in_cluster=False,
            get_logs=True,
            log_events_on_failure=True,
            is_delete_operator_pod=True,
        )
        tasks[key] = task

        idempotency_gate = make_idempotency_gate(f"gate_dup_{task_id}", dag_id=job_name, task_key=task_id, feature_id=cfg["feature_id"])
        idempotency_gates[key] = idempotency_gate
        idempotency_gate >> task

        sync_task = PythonOperator(
            task_id=f"sync_{key}",
            python_callable=sync_feature_to_store,
            op_kwargs={
                "feature_name": cfg["feature_name"],
                "feature_version": cfg["feature_version"],
                "run_date": "{{ data_interval_start | ds }}",
            },
        )
        tasks[f"sync_{key}"] = sync_task
        task >> sync_task

        if cfg['signal_exists']:
            signal_task = PythonOperator(
                task_id=f"signal_{key}",
                python_callable=run_signals,
                op_kwargs={
                    "feature_id": cfg["feature_id"]
                },
            )
            tasks[f"signals_{key}"] = signal_task

    for key, cfg in FEATURES.items():
        if "dependencies" in cfg and cfg["dependencies"]:
            for dep in cfg["dependencies"]:
                if dep in tasks:
                    tasks[dep] >> idempotency_gates[key]

        if "signal_exists" in cfg and cfg["signal_exists"]:
            if f"signals_{key}" in tasks:
                tasks[key] >> tasks[f"signals_{key}"]
