package database

import (
	"database/sql"
	"log"
	"time"

	"operator360-api/internal/config"

	_ "github.com/ClickHouse/clickhouse-go/v2"
	_ "github.com/go-sql-driver/mysql"
)

// PoolSize mirrors the Python service's mysql-connector pool_size of 5.
const PoolSize = 5

// DB wraps a pooled MySQL connection (sql.DB) with dictionary-style query helpers,
// exactly mirroring the DB class in database.py.
type DB struct {
	pool     *sql.DB
	poolName string
	poolSize int
}

// Pool exposes the underlying *sql.DB so other packages (like server/risk_tree.go)
// can use standard Go database/sql functions if they need raw access.
func (db *DB) Pool() *sql.DB {
	return db.pool
}

// NewMySQLPool (mirrors DB.open) creates a connection pool for the given configurations.
func NewMySQLPool(cfg *config.Config) (*DB, error) {
	db, err := sql.Open("mysql", cfg.DSN())
	if err != nil {
		log.Printf("Failed to create connection pool: %v", err)
		return nil, err
	}

	// Pool size configurations match MaxOpenConns/MaxIdleConns logic via pool_size.
	db.SetMaxOpenConns(PoolSize)
	db.SetMaxIdleConns(PoolSize)
	db.SetConnMaxLifetime(5 * time.Minute)

	log.Println("Database connection pool created successfully")
	return &DB{
		pool:     db,
		poolName: "operator360_pool",
		poolSize: PoolSize,
	}, nil
}

// NewClickHousePool initializes and returns a ClickHouse connection pool
// (Merged into this file to centralize all database logic).
func NewClickHousePool(cfg *config.Config) (*sql.DB, error) {
	db, err := sql.Open("clickhouse", cfg.ClickHouseDSN())
	if err != nil {
		log.Printf("Failed to create ClickHouse connection pool: %v", err)
		return nil, err
	}

	// ClickHouse usually benefits from a slightly larger pool for concurrent reads
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(5)

	if err := db.Ping(); err != nil {
		log.Printf("Failed to ping ClickHouse: %v", err)
		return nil, err
	}

	log.Println("ClickHouse connection pool created successfully")
	return db, nil
}

// Stats (mirrors db.stats) returns the connection pool's current stats, used to feed the
// db_pool_* Prometheus gauges. Go's sql.DBStats provides much more detail than Python.
func (db *DB) Stats() map[string]interface{} {
	stats := db.pool.Stats()
	return map[string]interface{}{
		"pool_name":        db.poolName,
		"pool_size":        db.poolSize,
		"open_connections": stats.OpenConnections,
		"in_use":           stats.InUse,
		"idle":             stats.Idle,
		"wait_count":       stats.WaitCount,
		"wait_duration":    stats.WaitDuration.String(),
	}
}

// TestConnection (mirrors db.test_connection) pings the database, used by the /api/health endpoint.
func (db *DB) TestConnection() bool {
	err := db.pool.Ping()
	if err != nil {
		log.Printf("Database connection test failed: %v", err)
		return false
	}
	log.Println("Database connection test successful")
	return true
}

// ExecuteQuery (mirrors db.execute_query) runs a SELECT and returns all rows as a slice of
// column-name-to-value dictionaries. Returns an error on failure.
// In Go, we use interface{} to mimic Python's dynamic "any" value types.
func (db *DB) ExecuteQuery(query string, params ...interface{}) ([]map[string]interface{}, error) {
	rows, err := db.pool.Query(query, params...)
	if err != nil {
		log.Printf("Error executing query: %v", err)
		log.Printf("Query: %s", query)
		return nil, err
	}
	defer rows.Close()

	cols, err := rows.Columns()
	if err != nil {
		return nil, err
	}

	var results []map[string]interface{}

	for rows.Next() {
		// Create a slice of interface{} to hold the raw values
		values := make([]interface{}, len(cols))
		valuePtrs := make([]interface{}, len(cols))
		for i := range cols {
			valuePtrs[i] = &values[i]
		}

		if err := rows.Scan(valuePtrs...); err != nil {
			log.Printf("Error scanning row: %v", err)
			return nil, err
		}

		// Map column names to values
		rowMap := make(map[string]interface{})
		for i, col := range cols {
			val := values[i]
			// MySQL driver in Go often returns []byte for strings. We convert to string for compatibility.
			if b, ok := val.([]byte); ok {
				rowMap[col] = string(b)
			} else {
				rowMap[col] = val
			}
		}
		results = append(results, rowMap)
	}

	return results, nil
}

// ExecuteQueryOne (mirrors db.execute_query_one) runs a SELECT and returns only the first row,
// or nil if there are no matching rows.
func (db *DB) ExecuteQueryOne(query string, params ...interface{}) (map[string]interface{}, error) {
	results, err := db.ExecuteQuery(query, params...)
	if err != nil {
		return nil, err
	}
	if len(results) == 0 {
		return nil, nil // No rows found
	}
	return results[0], nil
}

// ExecuteWrite (mirrors db.execute_write) runs an INSERT/UPDATE/DELETE. It returns the last inserted ID
// for INSERT statements, or the affected row count for UPDATE/DELETE.
func (db *DB) ExecuteWrite(query string, params ...interface{}) (int64, error) {
	res, err := db.pool.Exec(query, params...)
	if err != nil {
		log.Printf("Error executing write operation: %v", err)
		log.Printf("Query: %s", query)
		return 0, err
	}

	lastId, err := res.LastInsertId()
	if err == nil && lastId > 0 {
		log.Printf("Write operation successful. Inserted ID: %d", lastId)
		return lastId, nil
	}

	affected, err := res.RowsAffected()
	if err != nil {
		return 0, err
	}
	log.Printf("Write operation successful. Affected rows: %d", affected)
	return affected, nil
}
