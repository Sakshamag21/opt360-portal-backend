package server

import (
	"database/sql"
	// "encoding/json"
	"fmt"
	"math"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"operator360-api/internal/config"
)

// --- Structs for JSON Response ---

type RiskTreeResponse struct {
	OperatorID            string      `json:"operator_id"`
	ROName                string      `json:"ro_name"`
	OverallRiskScore      interface{} `json:"overall_risk_score"`
	LastPacketTimestamp   string      `json:"last_packet_timestamp"`
	RiskAnalysisUpdatedAt string      `json:"risk_analysis_updated_at"`
	Categories            []Category  `json:"categories"`
	Error                 string      `json:"error,omitempty"`
}

type Category struct {
	CategoryName  string      `json:"category_name"`
	CategoryScore interface{} `json:"category_score"`
	Features      []Feature   `json:"features"`
}

type Feature struct {
	FeatureID    string      `json:"feature_id"`
	FeatureValue interface{} `json:"feature_value"`
	Description  string      `json:"description"`
	LastUpdated  time.Time   `json:"last_updated"`
}

// --- Category Mapping Config ---

type categoryConfig struct {
	DBColumn    string
	DisplayName string
	Prefixes    []string
	Groups      []string
	Keywords    []string
}

var categoryMappings = []categoryConfig{
	{"document_category_score", "Document Category", []string{"doc_", "document_"}, []string{"document", "doc"}, []string{"_score", "incident", "24_hr", "24h"}},
	{"work_category_score", "Work Category", []string{"work_"}, []string{"work"}, []string{"_score", "incident", "24_hr", "24h"}},
	{"authentication_category_score", "Authentication Category", []string{"auth_"}, []string{"authentication", "auth"}, []string{"_score", "incident", "24_hr", "24h"}},
	{"suspicious_category_score", "Suspicious Category", []string{"sustxn_", "susp_", "suspicious_"}, []string{"suspicious", "susp", "sus", "sustxn"}, []string{"_score", "instance", "24_hr", "24h"}},
	{"biometrics_category_score", "Biometrics Category", []string{"bio_", "biometric_", "biometrics_"}, []string{"biometrics", "biometric", "bio"}, []string{"_score", "instance", "24_hr", "24h"}},
	{"hardware_category_score", "Hardware Category", []string{"hw_", "hardware_"}, []string{"hardware", "hw"}, []string{"_score", "instance", "24_hr", "24h"}},
}

var excludeKeywords = []string{"monthly", "cumulative"}

// FeatureRow represents a row fetched from ClickHouse feature store
type FeatureRow struct {
	FeatureID    string
	FeatureValue string
	Description  string
	LastUpdated  time.Time
	FeatureGroup string
}

// standardResponse is a helper struct to match the project's {success, message, data} envelope
// type standardResponse struct {
// 	Success bool        `json:"success"`
// 	Message string      `json:"message"`
// 	Data    interface{} `json:"data"`
// }

// func writeJSON(w http.ResponseWriter, statusCode int, message string, data interface{}) {
// 	w.Header().Set("Content-Type", "application/json")
// 	w.WriteHeader(statusCode)
// 	json.NewEncoder(w).Encode(standardResponse{
// 		Success: statusCode >= 200 && statusCode < 300,
// 		Message: message,
// 		Data:    data,
// 	})
// }

// GetRiskTree is the HTTP handler for the risk tree API
func (s *Server) GetRiskTree(cfg *config.Config, mysqlDB, clickhouseDB *sql.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		optID := r.URL.Query().Get("opt_id")
		if optID == "" {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "Operator ID (opt_id) is required"})
			return
		}

		result := RiskTreeResponse{
			OperatorID: optID,
			Categories: []Category{},
		}

		// 1. Fetch from MySQL (opt_master) - Using cfg.OptTable()
		// var riskScore sql.NullString
		// var lastPacketTs sql.NullTime

		riskScore := sql.NullString{String: "", Valid: true}
		lastPacketTs := sql.NullTime{Time: time.Now(), Valid: true}
		
		err := mysqlDB.QueryRow(fmt.Sprintf(`
            SELECT risk_score, last_packet_timestamp 
            FROM %s 
            WHERE id = ? 
            LIMIT 1
        `, cfg.OptTable()), optID).Scan(&riskScore, &lastPacketTs)

		if err == sql.ErrNoRows {
			result.Error = fmt.Sprintf("Operator ID %s — NOT FOUND in %s", optID, cfg.OptTable())
			fmt.Printf("Warning: Operator ID %s NOT FOUND in %s. Using defaults.\n", optID, cfg.OptTable())
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "Operator not found"})
			// return
		} else if err != nil {
			writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "MySQL query failed: "+err.Error()})
			fmt.Printf("Error: MySQL query failed: %v. Using defaults.\n", err)
			// writeJSON(w, http.StatusInternalServerError, "MySQL query failed: "+err.Error(), nil)
			// return
		}

		// Parse risk score
		if riskScore.Valid {
			if f, err := strconv.ParseFloat(riskScore.String, 64); err == nil {
				result.OverallRiskScore = f
			} else {
				result.OverallRiskScore = riskScore.String
			}
		}

		if lastPacketTs.Valid {
			result.LastPacketTimestamp = lastPacketTs.Time.Format("2006-01-02 15:04:05")
		}

		// 2. Fetch from ClickHouse (risk_analysis) - Using cfg.RiskAnalysisTable()
		var roName, updatedStr string
		var docScore, workScore, authScore, suspScore, bioScore, hwScore sql.NullString
		err = clickhouseDB.QueryRow(fmt.Sprintf(`
            SELECT 
				opt_id,
				argMax(ro_name,updated_at) as ro_name, 
                argMax(document_category_score,updated_at) as  document_category_score,
				argMax(work_category_score,updated_at) as work_category_score,
                argMax(authentication_category_score,updated_at) as authentication_category_score,
				argMax(suspicious_category_score,updated_at) as suspicious_category_score,
                argMax(biometrics_category_score,updated_at) as biometrics_category_score, 
				argMax(hardware_category_score,updated_at) as hardware_category_score,
                toString(max(updated_at)) as updated_at_str
            FROM %s
            WHERE opt_id = ?
			group by 1
            LIMIT 1
        `, cfg.RiskAnalysisTable()), optID).Scan(&roName, &optID, &docScore, &workScore, &authScore, &suspScore, &bioScore, &hwScore, &updatedStr)

		if err != nil && err != sql.ErrNoRows {
			// writeJSON(w, http.StatusInternalServerError, "ClickHouse risk_analysis query failed: "+err.Error(), nil)
			writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "ClickHouse risk_analysis query failed: "+err.Error()})

			return
		}

		if err == sql.ErrNoRows {
			result.Error = fmt.Sprintf("No branch data found in %s for opt_id=%s", cfg.RiskAnalysisTable(), optID)
			// writeJSON(w, http.StatusOK, "Success", result)
			writeJSON(w, http.StatusOK, map[string]string{"success": "Success"})
			return
		}

		result.ROName = roName
		result.RiskAnalysisUpdatedAt = updatedStr

		// Map scores for processing
		scoresMap := map[string]sql.NullString{
			"document_category_score":       docScore,
			"work_category_score":           workScore,
			"authentication_category_score": authScore,
			"suspicious_category_score":     suspScore,
			"biometrics_category_score":     bioScore,
			"hardware_category_score":       hwScore,
		}

		// 3. Fetch Feature Store from ClickHouse - Using cfg.FeatureStoreTable()
		rows, err := clickhouseDB.Query(fmt.Sprintf(`
            SELECT feature_id 
			, toString(argMax(feature_value,last_updated_at)) as feature_value, 
			argMax(description, last_updated_at) as description, 
			max(last_updated_at) as max_last_updated_at,
			argMax(feature_group, last_updated_at) as feature_group
            FROM %s
            WHERE entity_id = ?
			group by feature_id
        `, cfg.FeatureStoreTable()), optID)
		if err != nil {
			writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "ClickHouse feature store query failed: "+err.Error()})
			// writeJSON(w, http.StatusInternalServerError, "ClickHouse feature store query failed: "+err.Error(), nil)
			return
		}
		defer rows.Close()

		var allFeatures []FeatureRow
		for rows.Next() {
			var f FeatureRow
			if err := rows.Scan(&f.FeatureID, &f.FeatureValue, &f.Description, &f.LastUpdated, &f.FeatureGroup); err == nil {
				allFeatures = append(allFeatures, f)
			}
		}

		// 4. Process Features (Replicating Pandas logic)
		var scores, nonScores []FeatureRow
		tenDaysAgo := time.Now().AddDate(0, 0, -10)

		for _, f := range allFeatures {
			if strings.Contains(strings.ToLower(f.FeatureID), "_score") {
				scores = append(scores, f)
			} else {
				if !f.LastUpdated.IsZero() && f.LastUpdated.After(tenDaysAgo) {
					nonScores = append(nonScores, f)
				}
			}
		}

		// Sort non-scores by date descending
		sort.Slice(nonScores, func(i, j int) bool {
			return nonScores[i].LastUpdated.After(nonScores[j].LastUpdated)
		})

		// Deduplicate
		seen := make(map[string]bool)
		var finalFeatures []FeatureRow

		// Add non-scores first (they are sorted by date desc, so keep=first means latest)
		for _, f := range nonScores {
			id := strings.ToLower(f.FeatureID)
			if !seen[id] {
				seen[id] = true
				finalFeatures = append(finalFeatures, f)
			}
		}
		// Add scores
		for _, f := range scores {
			id := strings.ToLower(f.FeatureID)
			if !seen[id] {
				seen[id] = true
				finalFeatures = append(finalFeatures, f)
			}
		}

		// 5. Build Categories JSON
		for _, cfgCat := range categoryMappings {
			cat := Category{
				CategoryName:  cfgCat.DisplayName,
				CategoryScore: parseScoreValue(scoresMap[cfgCat.DBColumn]),
				Features:      []Feature{},
			}

			for _, f := range finalFeatures {
				lowerID := strings.ToLower(f.FeatureID)
				lowerGroup := strings.ToLower(f.FeatureGroup)

				matchesGroup := containsAny(lowerGroup, cfgCat.Groups)
				matchesPrefix := hasAnyPrefix(lowerID, cfgCat.Prefixes)

				if matchesGroup || matchesPrefix {
					hasKeyword := containsAny(lowerID, cfgCat.Keywords)
					isExcluded := containsAny(lowerID, excludeKeywords)

					if hasKeyword && !isExcluded {
						cat.Features = append(cat.Features, Feature{
							FeatureID:    f.FeatureID,
							FeatureValue: parseFeatureValue(f.FeatureValue),
							Description:  strings.TrimSpace(f.Description),
							LastUpdated:  f.LastUpdated,
						})
					}
				}
			}
			result.Categories = append(result.Categories, cat)
		}

		// writeJSON(w, http.StatusOK, "Risk tree generated successfully", result)
		writeJSON(w, http.StatusOK, result)
	}
}

// --- Helper Functions ---

func parseScoreValue(val sql.NullString) interface{} {
	if !val.Valid {
		return nil
	}
	if f, err := strconv.ParseFloat(val.String, 64); err == nil {
		return f
	}
	return val.String
}

func parseFeatureValue(val string) interface{} {
	if val == "" {
		return nil
	}
	if f, err := strconv.ParseFloat(val, 64); err == nil {
		if math.IsNaN(f) {
			return nil
		}
		if f == math.Floor(f) && !math.IsInf(f, 0) {
			return int(f) // Return as int if it's a whole number
		}
		return f
	}
	return val
}

func containsAny(s string, substrs []string) bool {
	for _, sub := range substrs {
		if strings.Contains(s, sub) {
			return true
		}
	}
	return false
}

func hasAnyPrefix(s string, prefixes []string) bool {
	for _, p := range prefixes {
		if strings.HasPrefix(s, p) {
			return true
		}
	}
	return false
}
