package server

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestParseRegistryCSVResources(t *testing.T) {
	f, err := os.Open(filepath.Join("..", "..", "resources", "opt360_features.csv"))
	if err != nil {
		t.Skipf("registry export not present: %v", err)
	}
	defer f.Close()
	reg, err := parseRegistryCSV(f)
	if err != nil {
		t.Fatal(err)
	}

	// Every category config is a PROD row.
	for _, def := range riskCategoryDefs {
		if _, ok := reg[def.RegistryID]; !ok {
			t.Errorf("category %s (%s) not loaded", def.ID, def.RegistryID)
		}
	}
	if w := reg["bio_category_score_v2"].Params["risk_weightage"].Map; w["bio_mfc_fraud_score_v2"] != 4 || w["bio_sfc_fraud_score_v2"] != 1 {
		t.Errorf("bio weights = %v", w)
	}

	// Signal rows keep their inputs, including the multi-line mfc list.
	if got := reg["bio_mfc_fraud_score_v2"].inputIDs(); len(got) != 10 || got[0] != "bio_packet_finger_toe_print_count_daily_v1" {
		t.Errorf("mfc inputs = %v", got)
	}
	if got := reg["auth_failure_ratio_score_v2"].inputIDs(); len(got) != 2 {
		t.Errorf("failure ratio inputs = %v", got)
	}
	if d := reg["bio_mfc_fraud_score_v2"].Description; !strings.HasPrefix(d, "Score based on the number of manual fraud cases") {
		t.Errorf("mfc description = %q", d)
	}
}

func TestBuildRiskTreeV2Example(t *testing.T) {
	in := exampleInput(t)
	in.Features = append(in.Features,
		FeatureRow{FeatureID: "bio_mfc_fraud_score_v2", FeatureValue: "0.92", Description: "Manual biometric fraud score", LastUpdated: mustTime(t, "2026-09-02T01:00:00+05:30")},
		FeatureRow{FeatureID: "work_multiple_optname_score_v2", FeatureValue: "0.4", LastUpdated: mustTime(t, "2026-09-22T01:00:00+05:30")},
		// Weighted in hardware but not a PROD row: never shown.
		FeatureRow{FeatureID: "hardware_machine_change_score_v2", FeatureValue: "0.7", LastUpdated: mustTime(t, "2026-09-22T01:00:00+05:30")},
	)
	resp := buildRiskTreeV2(in)

	var order []string
	for _, c := range resp.Categories {
		order = append(order, c.CategoryName)
	}
	want := "Document Category,Work Category,Authentication Category,Suspicious Category,Biometrics Category,Hardware Category"
	if got := strings.Join(order, ","); got != want {
		t.Errorf("category order = %s", got)
	}
	if resp.OverallRiskScore != 0.98 {
		t.Errorf("overall = %v, want 0.98", resp.OverallRiskScore)
	}
	byName := map[string]CategoryV2{}
	for _, c := range resp.Categories {
		byName[c.CategoryName] = c
	}

	// Biometrics: mfc has a score and one served input.
	bio := byName["Biometrics Category"]
	if len(bio.Features) != 1 {
		t.Fatalf("bio features = %+v, want only mfc", bio.Features)
	}
	mfc := bio.Features[0]
	if mfc.FeatureID != "bio_mfc_fraud_score_v2" || mfc.FeatureValue != 0.92 || mfc.Description != "Manual biometric fraud score" {
		t.Errorf("mfc = %+v", mfc)
	}
	if len(mfc.ChildFeatures) != 1 || mfc.ChildFeatures[0].FeatureID != "bio_packet_finger_swap_count_daily_v1" || mfc.ChildFeatures[0].FeatureValue != 10 {
		t.Errorf("mfc children = %+v", mfc.ChildFeatures)
	}

	work := byName["Work Category"]
	if len(work.Features) != 1 || work.Features[0].FeatureID != "work_multiple_optname_score_v2" || len(work.Features[0].ChildFeatures) != 1 {
		t.Errorf("work features = %+v", work.Features)
	}

	// Suspicious inputs are served but no signal score is: nothing is shown.
	// Hardware's only score is for a signal that is not in the registry.
	for _, name := range []string{"Suspicious Category", "Hardware Category", "Document Category", "Authentication Category"} {
		if n := len(byName[name].Features); n != 0 {
			t.Errorf("%s features = %d, want 0", name, n)
		}
	}

	b, err := json.Marshal(resp)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(b), `"features":null`) || strings.Contains(string(b), `"child_features":null`) {
		t.Errorf("null list in response: %s", b)
	}
}

func TestBuildRiskTreeV2OverallScoreText(t *testing.T) {
	in := exampleInput(t)
	empty := ""
	in.OverallRiskScore, in.OverallRiskScoreRaw = nil, &empty
	if got := buildRiskTreeV2(in).OverallRiskScore; got != "" {
		t.Errorf("overall = %#v, want \"\"", got)
	}
	in.OverallRiskScoreRaw = nil
	if got := buildRiskTreeV2(in).OverallRiskScore; got != nil {
		t.Errorf("overall = %#v, want nil", got)
	}
}
