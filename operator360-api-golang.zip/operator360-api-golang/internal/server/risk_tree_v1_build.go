package server

// Pure (DB-free) assembly of the explainable risk tree served by
// GET /api/v1/risk-tree-1. The handler in risk_tree_v1.go loads the inputs;
// everything here is deterministic so it can be unit tested.
//
// Explanation model: the API exposes no intermediate (signal) scores. Each
// category is explained by the signals its registry config combines (with
// their configured weights), the operator's raw evidence for those signals,
// and data-health flags that stop a stale or conflicting score being read as
// fact.

import (
	"fmt"
	"math"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

// --- Response ---

type RiskTreeV1Response struct {
	OperatorID            string           `json:"operator_id"`
	ROName                string           `json:"ro_name"`
	OverallRiskScore      *float64         `json:"overall_risk_score"`
	LastPacketTimestamp   string           `json:"last_packet_timestamp"`
	RiskAnalysisUpdatedAt string           `json:"risk_analysis_updated_at"`
	RiskDriver            RiskDriver       `json:"risk_driver"`
	DataHealth            []DataHealthItem `json:"data_health"`
	Categories            []CategoryV1     `json:"categories"`
}

type RiskDriver struct {
	Rule        string   `json:"rule"`
	CategoryIDs []string `json:"category_ids"`
}

type DataHealthItem struct {
	Type        string   `json:"type"`
	CategoryIDs []string `json:"category_ids"`
	Message     string   `json:"message"`
}

type CategoryV1 struct {
	CategoryID    string         `json:"category_id"`
	CategoryName  string         `json:"category_name"`
	CategoryScore *float64       `json:"category_score"`
	IsDriver      bool           `json:"is_driver"`
	Status        string         `json:"status"`
	MethodText    string         `json:"method_text"`
	Signals       []SignalV1     `json:"signals"`
	OtherActivity []ActivityItem `json:"other_activity"`
}

type SignalV1 struct {
	SignalID      string         `json:"signal_id"`
	Name          string         `json:"name"`
	Checks        string         `json:"checks"`
	Window        string         `json:"window"`
	Weight        float64        `json:"weight"`
	TotalWeight   float64        `json:"total_weight"`
	Influence     string         `json:"influence"`
	InRegistry    bool           `json:"in_registry"`
	Evidence      []EvidenceItem `json:"evidence"`
	MissingInputs []string       `json:"missing_inputs"`
}

type EvidenceItem struct {
	FeatureID            string      `json:"feature_id"`
	Label                string      `json:"label"`
	Value                interface{} `json:"value"`
	LastUpdated          time.Time   `json:"last_updated"`
	DaysBeforeLastPacket int         `json:"days_before_last_packet"`
	Freshness            string      `json:"freshness"`
}

type ActivityItem struct {
	FeatureID   string      `json:"feature_id"`
	Label       string      `json:"label"`
	Value       interface{} `json:"value"`
	LastUpdated time.Time   `json:"last_updated"`
}

// Category status values.
const (
	statusScored     = "scored"
	statusStale      = "stale"
	statusConflict   = "conflict"
	statusNoEvidence = "no_evidence"
	statusNotScored  = "not_scored"
)

// Freshness thresholds, in days before the operator's last packet.
const (
	freshCurrentMaxDays = 2
	freshOlderMaxDays   = 7
)

// overallMismatchTolerance matches TOLERANCE in the Airflow
// risk_categories.py job that populates risk_analysis.
const overallMismatchTolerance = 0.1

// otherActivityMaxAge mirrors the recency cut the original risk-tree applies
// to non-score features.
const otherActivityMaxAge = 60 * 24 * time.Hour

// --- Inputs ---

type riskCategoryDef struct {
	ID          string
	Name        string
	ScoreColumn string // column in risk_analysis
	RegistryID  string // feature_id of the category score in the feature registry
	Prefix      string // feature id prefix used to place non-input features
}

// riskCategoryDefs maps risk_analysis columns to registry category scores,
// matching the column mapping in the Airflow risk_categories.py job.
var riskCategoryDefs = []riskCategoryDef{
	{"biometrics", "Biometrics Category", "biometrics_category_score", "bio_category_score_v2", "bio_"},
	{"work", "Work Category", "work_category_score", "work_category_score_v2", "work_"},
	{"authentication", "Authentication Category", "authentication_category_score", "auth_category_score_v2", "auth_"},
	{"suspicious", "Suspicious Category", "suspicious_category_score", "sustxn_category_score_v2", "sustxn_"},
	{"hardware", "Hardware Category", "hardware_category_score", "hardware_category_score_v2", "hardware_"},
	{"document", "Document Category", "document_category_score", "document_category_score_v2", "doc_"},
}

// registryNode is one PROD row of the feature registry with its parsed
// dependent_features params.
type registryNode struct {
	FeatureID   string
	FeatureName string
	Description string
	Params      map[string]paramValue
}

type riskTreeInput struct {
	OperatorID            string
	ROName                string
	OverallRiskScore      *float64
	OverallRiskScoreRaw   *string   // opt_master.risk_score as stored; nil when NULL
	LastPacket            time.Time // zero when unknown
	RiskAnalysisUpdatedAt string
	CategoryScores        map[string]*float64 // keyed by riskCategoryDef.ID
	Features              []FeatureRow
	Registry              map[string]registryNode
}

// --- dependent_features parser ---

// paramValue is one value of a dependent_features entry: a scalar (Raw), a
// list ([a, b]) or a weight map ({a:1, b:2}).
type paramValue struct {
	Raw  string
	List []string
	Map  map[string]float64
}

// parseDependentFeatures parses the registry's loose param format, e.g.
// "[risk_weightage:{a_v2:4, b_v2:1}, scoring_function:softmax_scoring]" or
// "[scoring_method:rank_scoring, feature_id:[x, y], weights:{x:2, y:2}]".
// Whitespace and newlines anywhere are tolerated.
func parseDependentFeatures(s string) map[string]paramValue {
	out := map[string]paramValue{}
	s = strings.TrimSpace(s)
	s = strings.TrimPrefix(s, "[")
	s = strings.TrimSuffix(s, "]")
	for _, part := range splitTopLevel(s) {
		key, val, ok := strings.Cut(part, ":")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.TrimSpace(val)
		if key == "" {
			continue
		}
		switch {
		case strings.HasPrefix(val, "{") && strings.HasSuffix(val, "}"):
			m := map[string]float64{}
			for _, kv := range splitTopLevel(val[1 : len(val)-1]) {
				k, v, ok := strings.Cut(kv, ":")
				if !ok {
					continue
				}
				if f, err := strconv.ParseFloat(strings.TrimSpace(v), 64); err == nil {
					m[strings.TrimSpace(k)] = f
				}
			}
			out[key] = paramValue{Raw: val, Map: m}
		case strings.HasPrefix(val, "[") && strings.HasSuffix(val, "]"):
			var list []string
			for _, item := range splitTopLevel(val[1 : len(val)-1]) {
				if item = strings.TrimSpace(item); item != "" {
					list = append(list, item)
				}
			}
			out[key] = paramValue{Raw: val, List: list}
		default:
			out[key] = paramValue{Raw: val}
		}
	}
	return out
}

// splitTopLevel splits on commas that are not nested inside {} or [].
func splitTopLevel(s string) []string {
	var parts []string
	depth, start := 0, 0
	for i, r := range s {
		switch r {
		case '{', '[':
			depth++
		case '}', ']':
			depth--
		case ',':
			if depth == 0 {
				parts = append(parts, strings.TrimSpace(s[start:i]))
				start = i + 1
			}
		}
	}
	if last := strings.TrimSpace(s[start:]); last != "" {
		parts = append(parts, last)
	}
	return parts
}

// inputIDs returns a signal node's raw input feature ids, in registry order.
func (n registryNode) inputIDs() []string {
	var ids []string
	for _, key := range []string{"feature_id", "feature_id_numerator", "feature_id_denominator"} {
		v, ok := n.Params[key]
		if !ok {
			continue
		}
		if len(v.List) > 0 {
			ids = append(ids, v.List...)
		} else if v.Raw != "" {
			ids = append(ids, v.Raw)
		}
	}
	return ids
}

// --- Assembly ---

func buildRiskTreeV1(in riskTreeInput, now time.Time) RiskTreeV1Response {
	resp := RiskTreeV1Response{
		OperatorID:            in.OperatorID,
		ROName:                in.ROName,
		OverallRiskScore:      in.OverallRiskScore,
		RiskAnalysisUpdatedAt: in.RiskAnalysisUpdatedAt,
		RiskDriver:            RiskDriver{Rule: "max_category", CategoryIDs: []string{}},
		DataHealth:            []DataHealthItem{},
		Categories:            []CategoryV1{},
	}
	if !in.LastPacket.IsZero() {
		resp.LastPacketTimestamp = in.LastPacket.Format("2006-01-02 15:04:05")
	}
	reference := in.LastPacket
	if reference.IsZero() {
		reference = now
	}

	features := make(map[string]FeatureRow, len(in.Features))
	for _, f := range in.Features {
		features[strings.ToLower(f.FeatureID)] = f
	}

	// Build every category's signals first so the set of all scoring inputs
	// is known before assigning the leftover features to other_activity.
	allInputs := map[string]bool{}
	var unregistered []DataHealthItem
	for _, def := range riskCategoryDefs {
		cat := CategoryV1{
			CategoryID:    def.ID,
			CategoryName:  def.Name,
			CategoryScore: in.CategoryScores[def.ID],
			Signals:       []SignalV1{},
			OtherActivity: []ActivityItem{},
		}
		node, ok := in.Registry[def.RegistryID]
		if !ok {
			cat.MethodText = "Scoring config for this category is not in the feature registry."
			unregistered = append(unregistered, DataHealthItem{
				Type: "category_not_in_registry", CategoryIDs: []string{def.ID},
				Message: fmt.Sprintf("%s has no PROD entry (%s) in the feature registry, so its signals can't be listed.", shortName(def.Name), def.RegistryID),
			})
		} else {
			cat.MethodText, cat.Signals = buildSignals(node, in.Registry, features, reference)
			for _, sig := range cat.Signals {
				if !sig.InRegistry {
					unregistered = append(unregistered, DataHealthItem{
						Type: "signal_not_in_registry", CategoryIDs: []string{def.ID},
						Message: fmt.Sprintf("%s is weighted in %s but has no PROD entry in the feature registry.", sig.SignalID, shortName(def.Name)),
					})
				}
				for _, id := range append(evidenceIDs(sig), sig.MissingInputs...) {
					allInputs[strings.ToLower(id)] = true
				}
			}
		}
		resp.Categories = append(resp.Categories, cat)
	}

	// Leftover, recent, non-score features become context per category.
	for i := range resp.Categories {
		def := riskCategoryDefs[i]
		for _, f := range in.Features {
			id := strings.ToLower(f.FeatureID)
			if allInputs[id] || !strings.HasPrefix(id, def.Prefix) ||
				strings.Contains(id, "_score") || containsAny(id, excludeKeywords) {
				continue
			}
			if f.LastUpdated.IsZero() || now.Sub(f.LastUpdated) > otherActivityMaxAge {
				continue
			}
			resp.Categories[i].OtherActivity = append(resp.Categories[i].OtherActivity, ActivityItem{
				FeatureID: f.FeatureID, Label: featureLabel(f.FeatureID),
				Value: parseFeatureValue(f.FeatureValue), LastUpdated: f.LastUpdated,
			})
		}
		sort.SliceStable(resp.Categories[i].OtherActivity, func(a, b int) bool {
			return resp.Categories[i].OtherActivity[a].LastUpdated.After(resp.Categories[i].OtherActivity[b].LastUpdated)
		})
	}

	// Driver: overall risk_score_v3 is max_scoring over the category scores.
	maxScore, haveMax := 0.0, false
	for _, c := range resp.Categories {
		if c.CategoryScore != nil && (!haveMax || *c.CategoryScore > maxScore) {
			maxScore, haveMax = *c.CategoryScore, true
		}
	}
	for i, c := range resp.Categories {
		if haveMax && maxScore > 0 && c.CategoryScore != nil && math.Abs(*c.CategoryScore-maxScore) < 1e-9 {
			resp.Categories[i].IsDriver = true
			resp.RiskDriver.CategoryIDs = append(resp.RiskDriver.CategoryIDs, c.CategoryID)
		}
	}

	for i := range resp.Categories {
		resp.Categories[i].Status = categoryStatus(resp.Categories[i])
	}
	resp.DataHealth = buildDataHealth(resp, maxScore, haveMax)
	resp.DataHealth = append(resp.DataHealth, unregistered...)

	// Highest score first; unscored categories last.
	sort.SliceStable(resp.Categories, func(a, b int) bool {
		sa, sb := resp.Categories[a].CategoryScore, resp.Categories[b].CategoryScore
		if sa == nil || sb == nil {
			return sa != nil
		}
		return *sa > *sb
	})
	return resp
}

// buildSignals returns the category's method text and signals. A category
// with risk_weightage combines child signals; one without (e.g. document,
// which ranks raw features directly) is presented as a single signal.
func buildSignals(node registryNode, reg map[string]registryNode, features map[string]FeatureRow, reference time.Time) (string, []SignalV1) {
	weights := node.Params["risk_weightage"].Map
	if len(weights) == 0 {
		sig := buildSignal(node.FeatureID, 1, 1, "equal", node, true, features, reference)
		return methodTextForNode(node), []SignalV1{sig}
	}

	ids := make([]string, 0, len(weights))
	total, maxW, allEqual := 0.0, 0.0, true
	for id, w := range weights {
		ids = append(ids, id)
		total += w
		if w > maxW {
			maxW = w
		}
	}
	for _, w := range weights {
		if w != maxW {
			allEqual = false
		}
	}
	sort.Slice(ids, func(a, b int) bool {
		if weights[ids[a]] != weights[ids[b]] {
			return weights[ids[a]] > weights[ids[b]]
		}
		return ids[a] < ids[b]
	})

	signals := make([]SignalV1, 0, len(ids))
	for _, id := range ids {
		child, ok := reg[id]
		if !ok {
			child = registryNode{FeatureID: id}
		}
		signals = append(signals, buildSignal(id, weights[id], total, influenceFor(weights[id], maxW, allEqual), child, ok, features, reference))
	}

	var method string
	switch node.Params["scoring_function"].Raw {
	case "softmax_scoring":
		method = "Weighted blend of the signals below that leans toward the strongest one."
	case "weighted_average":
		method = "Weighted average of the signals below."
	case "max_scoring":
		method = "Highest of the signals below."
	}
	if allEqual {
		method = strings.TrimSpace(method + fmt.Sprintf(" All %d signals count equally.", len(ids)))
	} else {
		method = strings.TrimSpace(method + " Signals with higher influence count more.")
	}
	return method, signals
}

func buildSignal(id string, weight, total float64, influence string, node registryNode, inRegistry bool, features map[string]FeatureRow, reference time.Time) SignalV1 {
	label := signalLabels[id]
	sig := SignalV1{
		SignalID:      id,
		Name:          label.Name,
		Checks:        label.Checks,
		Window:        label.Window,
		Weight:        weight,
		TotalWeight:   total,
		Influence:     influence,
		InRegistry:    inRegistry,
		Evidence:      []EvidenceItem{},
		MissingInputs: []string{},
	}
	if sig.Name == "" {
		name := node.FeatureName
		if name == "" {
			name = id
		}
		sig.Name = humanizeID(strings.TrimSuffix(stripVersion(name), "_score"))
	}
	if sig.Checks == "" {
		sig.Checks = firstSentence(node.Description)
	}
	if sig.Window == "" {
		sig.Window = windowText(node)
	}

	for _, fid := range node.inputIDs() {
		f, ok := features[strings.ToLower(fid)]
		if !ok {
			sig.MissingInputs = append(sig.MissingInputs, fid)
			continue
		}
		days := daysBefore(reference, f.LastUpdated)
		sig.Evidence = append(sig.Evidence, EvidenceItem{
			FeatureID:            f.FeatureID,
			Label:                featureLabel(f.FeatureID),
			Value:                parseFeatureValue(f.FeatureValue),
			LastUpdated:          f.LastUpdated,
			DaysBeforeLastPacket: days,
			Freshness:            freshnessFor(days),
		})
	}
	return sig
}

func influenceFor(w, maxW float64, allEqual bool) string {
	switch {
	case allEqual:
		return "equal"
	case w == maxW:
		return "high"
	case w < maxW/2:
		return "low"
	default:
		return "medium"
	}
}

func methodTextForNode(node registryNode) string {
	switch node.Params["scoring_method"].Raw {
	case "rank_scoring":
		if node.Params["method"].Raw == "weighted_average" {
			return "Weighted average of its inputs, ranked against all operators."
		}
		return "Ranked against all operators."
	case "winsorized_zscoring":
		return "Compared with all operators, with outliers capped."
	}
	return ""
}

func windowText(node registryNode) string {
	var parts []string
	if days := node.Params["period_in_days"].Raw; days != "" {
		parts = append(parts, "Last "+days+" days")
	} else {
		for _, id := range node.inputIDs() {
			if strings.Contains(id, "cumulative") {
				parts = append(parts, "Cumulative")
				break
			}
		}
	}
	switch node.Params["scoring_method"].Raw {
	case "rank_scoring", "winsorized_zscoring":
		parts = append(parts, "compared with all operators")
	}
	w := strings.Join(parts, " · ")
	if w != "" {
		w = strings.ToUpper(w[:1]) + w[1:]
	}
	return w
}

func daysBefore(reference, t time.Time) int {
	if t.IsZero() {
		return 0
	}
	d := int(reference.Sub(t).Hours() / 24)
	if d < 0 {
		return 0
	}
	return d
}

func freshnessFor(days int) string {
	switch {
	case days <= freshCurrentMaxDays:
		return "current"
	case days <= freshOlderMaxDays:
		return "older"
	default:
		return "stale"
	}
}

func categoryStatus(c CategoryV1) string {
	if c.CategoryScore == nil {
		return statusNotScored
	}
	hasEvidence, nonZero := false, false
	freshest := math.MaxInt
	for _, s := range c.Signals {
		for _, e := range s.Evidence {
			hasEvidence = true
			if e.DaysBeforeLastPacket < freshest {
				freshest = e.DaysBeforeLastPacket
			}
			if f, ok := e.Value.(float64); ok && f > 0 {
				nonZero = true
			}
			if n, ok := e.Value.(int); ok && n > 0 {
				nonZero = true
			}
		}
	}
	switch {
	case !hasEvidence:
		return statusNoEvidence
	case *c.CategoryScore == 0 && nonZero:
		return statusConflict
	case freshest > freshOlderMaxDays:
		return statusStale
	default:
		return statusScored
	}
}

func buildDataHealth(resp RiskTreeV1Response, maxScore float64, haveMax bool) []DataHealthItem {
	items := []DataHealthItem{}

	if resp.OverallRiskScore != nil && haveMax && math.Abs(*resp.OverallRiskScore-maxScore) > overallMismatchTolerance {
		items = append(items, DataHealthItem{
			Type: "overall_score_mismatch", CategoryIDs: []string{},
			Message: fmt.Sprintf("Overall risk score %.2f differs from the highest category score %.2f.", *resp.OverallRiskScore, maxScore),
		})
	}

	var noEvidence, notScored []CategoryV1
	for _, c := range resp.Categories {
		switch c.Status {
		case statusStale:
			if c.IsDriver {
				items = append(items, DataHealthItem{
					Type: "stale_driver_evidence", CategoryIDs: []string{c.CategoryID},
					Message: fmt.Sprintf("%s evidence was last recorded %d days before the operator's last packet.", shortName(c.CategoryName), freshestDays(c)),
				})
			}
		case statusConflict:
			var nonZero []string
			for _, s := range c.Signals {
				for _, e := range s.Evidence {
					nonZero = append(nonZero, fmt.Sprintf("%s = %v", e.Label, e.Value))
				}
			}
			items = append(items, DataHealthItem{
				Type: "score_conflicts_with_evidence", CategoryIDs: []string{c.CategoryID},
				Message: fmt.Sprintf("%s shows 0, but its scoring inputs are not zero (%s). Treat the score as unknown, not low.", shortName(c.CategoryName), strings.Join(nonZero, ", ")),
			})
		case statusNoEvidence:
			noEvidence = append(noEvidence, c)
		case statusNotScored:
			notScored = append(notScored, c)
		}
	}
	if len(noEvidence) > 0 {
		ids, names := idsAndNames(noEvidence)
		verb := "has"
		if len(noEvidence) > 1 {
			verb = "have"
		}
		items = append(items, DataHealthItem{
			Type: "no_evidence_served", CategoryIDs: ids,
			Message: fmt.Sprintf("%s %s no scoring inputs in the serving layer, so the score can't be explained.", names, verb),
		})
	}
	if len(notScored) > 0 {
		ids, names := idsAndNames(notScored)
		items = append(items, DataHealthItem{
			Type: "category_not_scored", CategoryIDs: ids,
			Message: fmt.Sprintf("No category score in risk_analysis for %s.", names),
		})
	}
	return items
}

func freshestDays(c CategoryV1) int {
	best := math.MaxInt
	for _, s := range c.Signals {
		for _, e := range s.Evidence {
			if e.DaysBeforeLastPacket < best {
				best = e.DaysBeforeLastPacket
			}
		}
	}
	return best
}

func idsAndNames(cats []CategoryV1) ([]string, string) {
	ids := make([]string, 0, len(cats))
	names := make([]string, 0, len(cats))
	for _, c := range cats {
		ids = append(ids, c.CategoryID)
		names = append(names, shortName(c.CategoryName))
	}
	if len(names) <= 1 {
		return ids, strings.Join(names, "")
	}
	return ids, strings.Join(names[:len(names)-1], ", ") + " and " + names[len(names)-1]
}

func evidenceIDs(s SignalV1) []string {
	ids := make([]string, 0, len(s.Evidence))
	for _, e := range s.Evidence {
		ids = append(ids, e.FeatureID)
	}
	return ids
}

// --- Text helpers ---

var versionSuffixRe = regexp.MustCompile(`_v\d+$`)

func stripVersion(id string) string { return versionSuffixRe.ReplaceAllString(id, "") }

func shortName(categoryName string) string { return strings.TrimSuffix(categoryName, " Category") }

func humanizeID(id string) string {
	s := strings.TrimSpace(strings.ReplaceAll(id, "_", " "))
	if s == "" {
		return s
	}
	return strings.ToUpper(s[:1]) + s[1:]
}

func featureLabel(id string) string {
	if l, ok := featureLabels[id]; ok {
		return l
	}
	return humanizeID(stripVersion(id))
}

// firstSentence returns the registry description up to its first ". ", which
// is the human part before the generated "This is a normalized risk score..."
func firstSentence(desc string) string {
	desc = strings.TrimSpace(desc)
	if i := strings.Index(desc, ". "); i >= 0 {
		return desc[:i+1]
	}
	return desc
}
