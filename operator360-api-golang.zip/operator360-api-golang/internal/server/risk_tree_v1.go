package server

import (
	"context"
	"database/sql"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"strconv"
	"sync"
	"time"
	"os"
	"path/filepath"
	"strings"
)
// import (
// 	"bufio"
// 	"context"
// 	"database/sql"
// 	"encoding/csv"
// 	"fmt"
// 	"log"
// 	"os"
// 	"path/filepath"
// 	"strings"
// )


// import (
// 	"context"
// 	"database/sql"
// 	"encoding/csv"
// 	"fmt"
// 	"log"
// 	"os"
// 	"path/filepath"
// )

// registryTTL bounds how stale the in-process copy of the feature registry
// can get; the registry changes rarely and is read on every request.
const registryTTL = 10 * time.Minute

// ist is the zone opt_master.last_packet_timestamp is written in. The MySQL
// DSN has no loc, so the driver returns that wall clock labelled UTC.
var ist = time.FixedZone("IST", 5*3600+30*60)

// GetRiskTreeV1 handles GET /api/v1/risk-tree-1: the risk tree with
// explanations (driver, signals, evidence, data health). The original
// /api/v1/risk-tree is left unchanged for existing clients.
func (s *Server) GetRiskTreeV1(w http.ResponseWriter, r *http.Request) {
	optID := r.URL.Query().Get("opt_id")
	if optID == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "Operator ID (opt_id) is required"})
		return
	}
	in, status, errMsg := s.loadRiskTreeInput(r.Context(), optID, "risk-tree-1")
	if status != http.StatusOK {
		writeJSON(w, status, map[string]string{"error": errMsg})
		return
	}
	writeJSON(w, http.StatusOK, buildRiskTreeV1(in, time.Now()))
}

// loadRiskTreeInput gathers the inputs shared by /api/v1/risk-tree-1 and
// /api/v1/risk-tree-2. On failure it returns the HTTP status and error text
// to send; otherwise the status is 200.
func (s *Server) loadRiskTreeInput(ctx context.Context, optID, logTag string) (riskTreeInput, int, string) {
	in := riskTreeInput{OperatorID: optID}

	// 1. Overall score and last packet from MySQL opt_master.
	var riskScore sql.NullString
	var lastPacket sql.NullTime

	err := s.DB.Pool().QueryRowContext(ctx, fmt.Sprintf(
		"SELECT risk_score, last_packet_timestamp FROM %s WHERE id = ? LIMIT 1", s.Config.OptTable(),
	), optID).Scan(&riskScore, &lastPacket)

	if errors.Is(err, sql.ErrNoRows) {
		return in, http.StatusNotFound, "Operator not found"
	}

	if err != nil {
		// Log the error but DO NOT return. Fallback to default values.
		log.Printf("[%s] MySQL query/connection failed opt_id=%s: %v. Using defaults.", logTag, optID, err)

		// Assign your specific default values here
		defaultScore := 0.0
		in.OverallRiskScore = &defaultScore
		in.LastPacket = time.Now().In(ist) // Or time.Time{} for a zero-value timestamp
	} else {
		// Only parse MySQL data if the query succeeded without errors
		if riskScore.Valid {
			raw := riskScore.String
			in.OverallRiskScoreRaw = &raw
			if f, err := strconv.ParseFloat(riskScore.String, 64); err == nil {
				in.OverallRiskScore = &f
			}
		}
		if lastPacket.Valid {
			t := lastPacket.Time
			in.LastPacket = time.Date(t.Year(), t.Month(), t.Day(), t.Hour(), t.Minute(), t.Second(), 0, ist)
		}
	}


	// 2. Category scores from ClickHouse risk_analysis. No row is not an
	// error: every category is then reported as not_scored.
	in.CategoryScores, in.ROName, in.RiskAnalysisUpdatedAt, err = s.fetchCategoryScores(ctx, optID)
	if err != nil {
		log.Printf("[%s] risk_analysis query failed opt_id=%s: %v", logTag, optID, err)
		return in, http.StatusInternalServerError, "ClickHouse risk_analysis query failed: " + err.Error()
	}

	// 3. Latest value per feature from the ClickHouse feature store.
	in.Features, err = s.fetchFeatureRows(ctx, optID)
	if err != nil {
		log.Printf("[%s] feature store query failed opt_id=%s: %v", logTag, optID, err)
		return in, http.StatusInternalServerError, "ClickHouse feature store query failed: " + err.Error()
	}

	// 4. Scoring lineage from the feature registry (cached).
	in.Registry, err = s.riskRegistry(ctx)
	if err != nil {
		log.Printf("[%s] feature registry load failed: %v", logTag, err)
		return in, http.StatusInternalServerError, "Feature registry query failed: " + err.Error()
	}
	return in, http.StatusOK, ""
}

func (s *Server) fetchCategoryScores(ctx context.Context, optID string) (map[string]*float64, string, string, error) {
	scores := map[string]*float64{}
	var roName, updatedStr, optIDDb string
	var docScore, workScore, authScore, suspScore, bioScore, hwScore sql.NullString
	err := s.chDB.QueryRowContext(ctx, fmt.Sprintf(`
		SELECT
			argMax(ro_name, updated_at) AS ro_name,
			opt_id,
			argMax(document_category_score, updated_at)       AS document_category_score,
			argMax(work_category_score, updated_at)           AS work_category_score,
			argMax(authentication_category_score, updated_at) AS authentication_category_score,
			argMax(suspicious_category_score, updated_at)     AS suspicious_category_score,
			argMax(biometrics_category_score, updated_at)     AS biometrics_category_score,
			argMax(hardware_category_score, updated_at)       AS hardware_category_score,
			toString(max(updated_at))                         AS updated_at_str
		FROM %s
		WHERE opt_id = ?
		GROUP BY opt_id
		LIMIT 1
	`, s.Config.RiskAnalysisTable()), optID).Scan(&roName, &optIDDb, &docScore, &workScore, &authScore, &suspScore, &bioScore, &hwScore, &updatedStr)
	if errors.Is(err, sql.ErrNoRows) {
		return scores, "", "", nil
	}
	if err != nil {
		return nil, "", "", err
	}

	raw := map[string]sql.NullString{
		"document_category_score":       docScore,
		"work_category_score":           workScore,
		"authentication_category_score": authScore,
		"suspicious_category_score":     suspScore,
		"biometrics_category_score":     bioScore,
		"hardware_category_score":       hwScore,
	}
	for _, def := range riskCategoryDefs {
		if v := raw[def.ScoreColumn]; v.Valid {
			if f, err := strconv.ParseFloat(v.String, 64); err == nil {
				scores[def.ID] = &f
			}
		}
	}
	return scores, roName, updatedStr, nil
}

func (s *Server) fetchFeatureRows(ctx context.Context, optID string) ([]FeatureRow, error) {
	rows, err := s.chDB.QueryContext(ctx, fmt.Sprintf(`
		SELECT feature_id,
			toString(argMax(feature_value, last_updated_at)) AS feature_value,
			argMax(description, last_updated_at)             AS description,
			max(last_updated_at)                             AS max_last_updated_at,
			argMax(feature_group, last_updated_at)           AS feature_group
		FROM %s
		WHERE entity_id = ?
		GROUP BY feature_id
	`, s.Config.FeatureStoreTable()), optID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []FeatureRow
	for rows.Next() {
		var f FeatureRow
		if err := rows.Scan(&f.FeatureID, &f.FeatureValue, &f.Description, &f.LastUpdated, &f.FeatureGroup); err != nil {
			log.Printf("[risk-tree-1] feature row scan failed opt_id=%s: %v", optID, err)
			continue
		}
		out = append(out, f)
	}
	return out, rows.Err()
}

// registryCache holds the parsed PROD rows of the feature registry.
type registryCache struct {
	mu      sync.Mutex
	nodes   map[string]registryNode
	expires time.Time
}

// riskRegistry returns the cached registry, reloading it after registryTTL.
// If a reload fails but an older copy exists, the older copy is served.
func (s *Server) riskRegistry(ctx context.Context) (map[string]registryNode, error) {
	c := s.riskRegCache
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.nodes != nil && time.Now().Before(c.expires) {
		return c.nodes, nil
	}

	nodes, err := s.loadRiskRegistry(ctx)
	if err != nil {
		if c.nodes != nil {
			log.Printf("[risk-tree-1] registry reload failed, serving cached copy: %v", err)
			return c.nodes, nil
		}
		return nil, err
	}
	c.nodes, c.expires = nodes, time.Now().Add(registryTTL)
	return nodes, nil
}

func (s *Server) loadRiskRegistry(ctx context.Context) (map[string]registryNode, error) {
	// Attempt to fetch from MySQL first
	rows, err := s.DB.Pool().QueryContext(ctx, fmt.Sprintf(
		"SELECT feature_id, feature_name, description, dependent_features FROM %s WHERE status = 'PROD'",
		s.Config.FeatureTable(),
	))
	
	if err != nil {
		// Log the DB failure and trigger the CSV fallback mechanism
		log.Printf("[risk-tree-1] MySQL feature registry query failed: %v. Falling back to opt360_features.csv", err)
		return s.loadRiskRegistryFromCSV()
	}
	defer rows.Close()

	nodes := map[string]registryNode{}
	for rows.Next() {
		var id, name, desc, deps sql.NullString
		if err := rows.Scan(&id, &name, &desc, &deps); err != nil {
			log.Printf("[risk-tree-1] Error scanning DB row: %v. Switching to CSV fallback.", err)
			return s.loadRiskRegistryFromCSV()
		}
		if !id.Valid || id.String == "" {
			continue
		}
		nodes[id.String] = registryNode{
			FeatureID:   id.String,
			FeatureName: name.String,
			Description: desc.String,
			Params:      parseDependentFeatures(deps.String),
		}
	}

	if err := rows.Err(); err != nil {
		log.Printf("[risk-tree-1] Error during rows iteration: %v. Switching to CSV fallback.", err)
		return s.loadRiskRegistryFromCSV()
	}

	return nodes, nil
}


// registryCSVPaths are tried in order for the registry export: an explicit
// override, the container's resources directory, then a local checkout.
func registryCSVPaths() []string {
	paths := []string{}
	if p := os.Getenv("RISK_REGISTRY_CSV"); p != "" {
		paths = append(paths, p)
	}
	return append(paths,
		filepath.Join("/", "app", "resources", "opt360_features.csv"),
		filepath.Join("resources", "opt360_features.csv"),
	)
}

// loadRiskRegistryFromCSV loads the PROD rows of the feature registry export
// in resources/opt360_features.csv, used when MySQL is unavailable.
func (s *Server) loadRiskRegistryFromCSV() (map[string]registryNode, error) {
	var lastErr error
	for _, path := range registryCSVPaths() {
		file, err := os.Open(path)
		if err != nil {
			lastErr = err
			continue
		}
		nodes, err := parseRegistryCSV(file)
		file.Close()
		if err != nil {
			return nil, fmt.Errorf("registry CSV %s: %w", path, err)
		}
		log.Printf("[risk-tree] loaded %d PROD features from %s", len(nodes), path)
		return nodes, nil
	}
	return nil, fmt.Errorf("failed to open registry CSV: %w", lastErr)
}

// parseRegistryCSV reads the registry export. Columns are found by header
// name ("Feature ID", "Feature Name", "Description", "Status", "Dependent
// Features"); quoted fields may span lines, as Dependent Features often does.
func parseRegistryCSV(r io.Reader) (map[string]registryNode, error) {
	cr := csv.NewReader(r)
	cr.FieldsPerRecord = -1
	cr.LazyQuotes = true

	header, err := cr.Read()
	if err != nil {
		return nil, fmt.Errorf("reading header: %w", err)
	}
	col := map[string]int{}
	for i, h := range header {
		key := strings.ToLower(strings.TrimSpace(strings.TrimPrefix(h, string(rune(0xFEFF)))))
		col[strings.ReplaceAll(key, " ", "_")] = i
	}
	for _, need := range []string{"feature_id", "status", "dependent_features"} {
		if _, ok := col[need]; !ok {
			return nil, fmt.Errorf("missing column %q", need)
		}
	}
	field := func(rec []string, name string) string {
		if i, ok := col[name]; ok && i < len(rec) {
			return strings.TrimSpace(rec[i])
		}
		return ""
	}

	nodes := map[string]registryNode{}
	for {
		rec, err := cr.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		id := field(rec, "feature_id")
		if id == "" || !strings.EqualFold(field(rec, "status"), "PROD") {
			continue
		}
		nodes[id] = registryNode{
			FeatureID:   id,
			FeatureName: field(rec, "feature_name"),
			Description: field(rec, "description"),
			Params:      parseDependentFeatures(field(rec, "dependent_features")),
		}
	}
	return nodes, nil
}
