package server

// GET /api/v1/risk-tree-2: the original /api/v1/risk-tree shape (categories
// with features) built entirely from the feature registry. Each category's
// features are the signal scores its registry config weights, and each
// signal's child_features are the raw inputs the registry lists for it. A
// signal whose score is not in the feature store is left out together with
// its inputs. Inputs are loaded the same way as /api/v1/risk-tree-1.

import (
	"net/http"
	"sort"
	"strings"
	"time"
)

type RiskTreeV2Response struct {
	OperatorID            string       `json:"operator_id"`
	ROName                string       `json:"ro_name"`
	OverallRiskScore      interface{}  `json:"overall_risk_score"`
	LastPacketTimestamp   string       `json:"last_packet_timestamp"`
	RiskAnalysisUpdatedAt string       `json:"risk_analysis_updated_at"`
	Categories            []CategoryV2 `json:"categories"`
}

type CategoryV2 struct {
	CategoryName  string      `json:"category_name"`
	CategoryScore *float64    `json:"category_score"`
	Features      []FeatureV2 `json:"features"`
}

type FeatureV2 struct {
	FeatureID     string           `json:"feature_id"`
	FeatureValue  interface{}      `json:"feature_value"`
	Description   string           `json:"description"`
	LastUpdated   time.Time        `json:"last_updated"`
	ChildFeatures []ChildFeatureV2 `json:"child_features"`
}

type ChildFeatureV2 struct {
	FeatureID    string      `json:"feature_id"`
	FeatureValue interface{} `json:"feature_value"`
	Description  string      `json:"description"`
	LastUpdated  time.Time   `json:"last_updated"`
}

// riskTreeV2CategoryOrder keeps the category order of /api/v1/risk-tree.
var riskTreeV2CategoryOrder = []string{"document", "work", "authentication", "suspicious", "biometrics", "hardware"}

// GetRiskTreeV2 handles GET /api/v1/risk-tree-2.
func (s *Server) GetRiskTreeV2(w http.ResponseWriter, r *http.Request) {
	optID := r.URL.Query().Get("opt_id")
	if optID == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "Operator ID (opt_id) is required"})
		return
	}
	in, status, errMsg := s.loadRiskTreeInput(r.Context(), optID, "risk-tree-2")
	if status != http.StatusOK {
		writeJSON(w, status, map[string]string{"error": errMsg})
		return
	}
	writeJSON(w, http.StatusOK, buildRiskTreeV2(in))
}

func buildRiskTreeV2(in riskTreeInput) RiskTreeV2Response {
	resp := RiskTreeV2Response{
		OperatorID:            in.OperatorID,
		ROName:                in.ROName,
		RiskAnalysisUpdatedAt: in.RiskAnalysisUpdatedAt,
		Categories:            []CategoryV2{},
	}
	// Like /api/v1/risk-tree: a number when numeric, otherwise the stored text.
	if in.OverallRiskScore != nil {
		resp.OverallRiskScore = *in.OverallRiskScore
	} else if in.OverallRiskScoreRaw != nil {
		resp.OverallRiskScore = *in.OverallRiskScoreRaw
	}
	if !in.LastPacket.IsZero() {
		resp.LastPacketTimestamp = in.LastPacket.Format("2006-01-02 15:04:05")
	}

	features := make(map[string]FeatureRow, len(in.Features))
	for _, f := range in.Features {
		features[strings.ToLower(f.FeatureID)] = f
	}
	defs := make(map[string]riskCategoryDef, len(riskCategoryDefs))
	for _, def := range riskCategoryDefs {
		defs[def.ID] = def
	}

	for _, id := range riskTreeV2CategoryOrder {
		def := defs[id]
		cat := CategoryV2{
			CategoryName:  def.Name,
			CategoryScore: in.CategoryScores[def.ID],
			Features:      []FeatureV2{},
		}
		if node, ok := in.Registry[def.RegistryID]; ok {
			for _, sigID := range registrySignalIDs(node) {
				if f, ok := signalFeatureV2(sigID, in.Registry, features); ok {
					cat.Features = append(cat.Features, f)
				}
			}
		}
		resp.Categories = append(resp.Categories, cat)
	}
	return resp
}

// registrySignalIDs returns the signals a category score combines, highest
// weight first then by id. A category without risk_weightage (e.g. document,
// which ranks raw features directly) is its own single signal.
func registrySignalIDs(node registryNode) []string {
	weights := node.Params["risk_weightage"].Map
	if len(weights) == 0 {
		return []string{node.FeatureID}
	}
	ids := make([]string, 0, len(weights))
	for id := range weights {
		ids = append(ids, id)
	}
	sort.Slice(ids, func(a, b int) bool {
		if weights[ids[a]] != weights[ids[b]] {
			return weights[ids[a]] > weights[ids[b]]
		}
		return ids[a] < ids[b]
	})
	return ids
}

// signalFeatureV2 builds one signal from its registry row and its score in
// the feature store. ok is false when the signal is not a PROD registry row
// or its score is not in the feature store; its inputs are then not shown.
func signalFeatureV2(sigID string, reg map[string]registryNode, features map[string]FeatureRow) (FeatureV2, bool) {
	node, inRegistry := reg[sigID]
	score, hasScore := features[strings.ToLower(sigID)]
	if !inRegistry || !hasScore {
		return FeatureV2{}, false
	}
	out := FeatureV2{
		FeatureID:     score.FeatureID,
		FeatureValue:  parseFeatureValue(score.FeatureValue),
		Description:   featureDescriptionV2(sigID, reg, features),
		LastUpdated:   score.LastUpdated,
		ChildFeatures: []ChildFeatureV2{},
	}
	for _, inputID := range node.inputIDs() {
		f, ok := features[strings.ToLower(inputID)]
		if !ok {
			continue
		}
		out.ChildFeatures = append(out.ChildFeatures, ChildFeatureV2{
			FeatureID:    f.FeatureID,
			FeatureValue: parseFeatureValue(f.FeatureValue),
			Description:  featureDescriptionV2(inputID, reg, features),
			LastUpdated:  f.LastUpdated,
		})
	}
	return out, true
}

// featureDescriptionV2 prefers the feature store's description, then the
// first sentence of the registry's, then a label derived from the id.
func featureDescriptionV2(id string, reg map[string]registryNode, features map[string]FeatureRow) string {
	if f, ok := features[strings.ToLower(id)]; ok {
		if d := strings.TrimSpace(f.Description); d != "" {
			return d
		}
	}
	if n, ok := reg[id]; ok {
		if d := firstSentence(n.Description); d != "" {
			return d
		}
	}
	return featureLabel(id)
}
