package server

// GET /api/v1/risk-tree-2: the original /api/v1/risk-tree shape (categories
// with features) built from a static mapping file, not the feature registry.
// The mapping lists, per category, the signal scores to show and the raw
// child features of each. A signal whose score is not in the feature store
// is left out together with its children. The mapping's order is the
// response's order.
//
// The mapping is resources/risk_tree_2_mapping.json, found at
// $RISK_TREE_2_MAPPING, /app/resources/ or ./resources/, and re-read
// whenever it changes.

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type RiskTreeV2Response struct {
	OperatorID            string       `json:"operator_id"`
	ROName                string       `json:"ro_name"`
	OverallRiskScore      interface{}  `json:"overall_risk_score"`
	LastPacketTimestamp   string       `json:"last_packet_timestamp"`
	RiskAnalysisUpdatedAt string       `json:"risk_analysis_updated_at"`
	Categories            []CategoryV2 `json:"categories"`
}

type CategoryV2 struct {
	CategoryName  string      `json:"category_name"`
	CategoryScore *float64    `json:"category_score"`
	Features      []FeatureV2 `json:"features"`
}

type FeatureV2 struct {
	FeatureID     string           `json:"feature_id"`
	FeatureValue  interface{}      `json:"feature_value"`
	Description   string           `json:"description"`
	LastUpdated   time.Time        `json:"last_updated"`
	ChildFeatures []ChildFeatureV2 `json:"child_features"`
}

type ChildFeatureV2 struct {
	FeatureID    string      `json:"feature_id"`
	FeatureValue interface{} `json:"feature_value"`
	Description  string      `json:"description"`
	LastUpdated  time.Time   `json:"last_updated"`
}

// --- Mapping file ---

type riskTreeMapping struct {
	Categories []mappingCategory `json:"categories"`
}

type mappingCategory struct {
	CategoryID   string           `json:"category_id"` // a riskCategoryDefs ID; selects the risk_analysis score
	CategoryName string           `json:"category_name"`
	Features     []mappingFeature `json:"features"`
}

type mappingFeature struct {
	FeatureID     string         `json:"feature_id"`
	Description   string         `json:"description"`
	ChildFeatures []mappingChild `json:"child_features"`
}

type mappingChild struct {
	FeatureID   string `json:"feature_id"`
	Description string `json:"description"`
}

// parseRiskTreeMapping decodes and validates a mapping: every category_id
// must be a known category, listed once, and every feature_id non-empty.
func parseRiskTreeMapping(b []byte) (riskTreeMapping, error) {
	var m riskTreeMapping
	dec := json.NewDecoder(strings.NewReader(string(b)))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&m); err != nil {
		return m, err
	}
	known := map[string]bool{}
	for _, def := range riskCategoryDefs {
		known[def.ID] = true
	}
	seen := map[string]bool{}
	for _, c := range m.Categories {
		if !known[c.CategoryID] {
			return m, fmt.Errorf("unknown category_id %q", c.CategoryID)
		}
		if seen[c.CategoryID] {
			return m, fmt.Errorf("category_id %q listed twice", c.CategoryID)
		}
		seen[c.CategoryID] = true
		for _, f := range c.Features {
			if f.FeatureID == "" {
				return m, fmt.Errorf("category %q has a feature with no feature_id", c.CategoryID)
			}
			for _, ch := range f.ChildFeatures {
				if ch.FeatureID == "" {
					return m, fmt.Errorf("feature %q has a child with no feature_id", f.FeatureID)
				}
			}
		}
	}
	return m, nil
}

func riskTreeMappingPaths() []string {
	paths := []string{}
	if p := os.Getenv("RISK_TREE_2_MAPPING"); p != "" {
		paths = append(paths, p)
	}
	return append(paths,
		filepath.Join("/", "app", "resources", "risk_tree_2_mapping.json"),
		filepath.Join("resources", "risk_tree_2_mapping.json"),
	)
}

var riskTreeMappingCache struct {
	mu      sync.Mutex
	path    string
	modTime time.Time
	mapping riskTreeMapping
}

// riskTreeMappingFor returns the mapping from the first path that exists,
// re-reading it when its modification time changes.
func riskTreeMappingFor() (riskTreeMapping, error) {
	c := &riskTreeMappingCache
	c.mu.Lock()
	defer c.mu.Unlock()
	for _, path := range riskTreeMappingPaths() {
		st, err := os.Stat(path)
		if err != nil {
			continue
		}
		if path == c.path && st.ModTime().Equal(c.modTime) {
			return c.mapping, nil
		}
		b, err := os.ReadFile(path)
		if err != nil {
			return riskTreeMapping{}, err
		}
		m, err := parseRiskTreeMapping(b)
		if err != nil {
			return riskTreeMapping{}, fmt.Errorf("%s: %w", path, err)
		}
		log.Printf("[risk-tree-2] loaded mapping from %s", path)
		c.path, c.modTime, c.mapping = path, st.ModTime(), m
		return m, nil
	}
	return riskTreeMapping{}, fmt.Errorf("risk_tree_2_mapping.json not found in %v", riskTreeMappingPaths())
}

// --- Handler ---

// GetRiskTreeV2 handles GET /api/v1/risk-tree-2.
func (s *Server) GetRiskTreeV2(w http.ResponseWriter, r *http.Request) {
	optID := r.URL.Query().Get("opt_id")
	if optID == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "Operator ID (opt_id) is required"})
		return
	}
	mapping, err := riskTreeMappingFor()
	if err != nil {
		log.Printf("[risk-tree-2] mapping load failed: %v", err)
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "Risk tree mapping load failed: " + err.Error()})
		return
	}
	in, status, errMsg := s.loadRiskTreeInput(r.Context(), optID, "risk-tree-2", false)
	if status != http.StatusOK {
		writeJSON(w, status, map[string]string{"error": errMsg})
		return
	}
	writeJSON(w, http.StatusOK, buildRiskTreeV2(in, mapping))
}

// --- Assembly ---

func buildRiskTreeV2(in riskTreeInput, mapping riskTreeMapping) RiskTreeV2Response {
	resp := RiskTreeV2Response{
		OperatorID:            in.OperatorID,
		ROName:                in.ROName,
		RiskAnalysisUpdatedAt: in.RiskAnalysisUpdatedAt,
		Categories:            []CategoryV2{},
	}
	// Like /api/v1/risk-tree: a number when numeric, otherwise the stored text.
	if in.OverallRiskScore != nil {
		resp.OverallRiskScore = *in.OverallRiskScore
	} else if in.OverallRiskScoreRaw != nil {
		resp.OverallRiskScore = *in.OverallRiskScoreRaw
	}
	if !in.LastPacket.IsZero() {
		resp.LastPacketTimestamp = in.LastPacket.Format("2006-01-02 15:04:05")
	}

	features := make(map[string]FeatureRow, len(in.Features))
	for _, f := range in.Features {
		features[strings.ToLower(f.FeatureID)] = f
	}

	for _, mc := range mapping.Categories {
		cat := CategoryV2{
			CategoryName:  mc.CategoryName,
			CategoryScore: in.CategoryScores[mc.CategoryID],
			Features:      []FeatureV2{},
		}
		for _, mf := range mc.Features {
			score, ok := features[strings.ToLower(mf.FeatureID)]
			if !ok {
				continue // no score for this operator: the signal and its children are left out
			}
			f := FeatureV2{
				FeatureID:     score.FeatureID,
				FeatureValue:  parseFeatureValue(score.FeatureValue),
				Description:   descriptionV2(score, mf.Description, mf.FeatureID),
				LastUpdated:   score.LastUpdated,
				ChildFeatures: []ChildFeatureV2{},
			}
			for _, ch := range mf.ChildFeatures {
				row, ok := features[strings.ToLower(ch.FeatureID)]
				if !ok {
					continue
				}
				f.ChildFeatures = append(f.ChildFeatures, ChildFeatureV2{
					FeatureID:    row.FeatureID,
					FeatureValue: parseFeatureValue(row.FeatureValue),
					Description:  descriptionV2(row, ch.Description, ch.FeatureID),
					LastUpdated:  row.LastUpdated,
				})
			}
			cat.Features = append(cat.Features, f)
		}
		resp.Categories = append(resp.Categories, cat)
	}
	return resp
}

// descriptionV2 prefers the mapping's description, then the feature store's,
// then a label derived from the id.
func descriptionV2(row FeatureRow, mapped, id string) string {
	if mapped != "" {
		return mapped
	}
	if d := strings.TrimSpace(row.Description); d != "" {
		return d
	}
	return featureLabel(id)
}
