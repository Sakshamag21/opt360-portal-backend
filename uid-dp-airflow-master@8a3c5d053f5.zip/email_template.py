from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from airflow.providers.smtp.notifications.smtp import SmtpNotifier
from datetime import datetime,timedelta
from trino.dbapi import connect
import pandas as pd

trino_host="10.10.116.75"
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="airflow_dag_test"


upd_facerd_raw=f"""
insert into strot.misc_adhoc.sorryfortesting8
select 1,'hello-tester'
"""

retry_notifier = SmtpNotifier(
    from_email="strot@uidai.net.in",
    to=[
        "techexe12.yp24@uidai.net.in",
        "harshitsha23@gmail.com"
    ],
    # {{ ti.try_number }} will tell you exactly which attempt failed
    subject="Airflow Alert: Task {{ ti.task_id }} Failed (Attempt {{ ti.try_number }})"
)

final_failure_notifier = SmtpNotifier(
    from_email="strot@uidai.net.in",
    to=[
        "techexe12.yp24@uidai.net.in",
        "harshitsha23@gmail.com"
    ],
    subject="Airflow Alert: Task {{ ti.task_id }} Completely FAILED"
)
