#!/usr/bin/env python
# coding: utf-8

# In[1]:


import time
import os
import json
import pandas as pd
from trino.dbapi import connect
import mysql.connector
import boto3
from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from datetime import datetime
from zoho_alerts import zoho_failure_callback


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2026, 7, 22),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'on_failure_callback': zoho_failure_callback
}

# Define the DAG
dag = DAG(
    'update_uid_his_address_dag',
    default_args=default_args,
    description='run merge query to update uid_his_address',
    schedule="20 1 * * *",
    catchup=False,
    tags=['uid_master_tables']
)

# In[2]:

session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4')
s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425')

iceberg_table_name='uid_his_address'
mysql_table_to_read='uid_his_address'
iceberg_schema='mysql_uid_v2'
skip_till=19
trino_host="10.10.118.10"
iceberg_incr_key='his_addr_key'
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="af_his_address"
trino_table_name=f'{trino_catalog_iceberg}.{iceberg_schema}.{iceberg_table_name}'
# iceberg_partition_column='shard_hint'
trino_host_mapping={
              "mysql_v2_20_35":(20,35),
              "mysql_v2_36_51":(36,51),
              "mysql_v2_52_67":(52,67),
              "mysql_v2_68_83":(68,83),
              "mysql_v2_84_99":(84,99)
                }



# In[3]:


def run_query(query,host=trino_host,port=trino_port,user=trino_user):
        conn = connect(
            host=f"{host}",
            port=port,
            user=f"{user}",
            )
        cur = conn.cursor()
        cur.execute(f"{query}")
       
        return {"success":1,"msg":""}

def return_max_key(query,host=trino_host,port=trino_port,user=trino_user):
    try:
        conn = connect(
            host=f"{host}",
            port=port,
            user=f"{user}",
            )
        cur = conn.cursor()
        row = cur.execute(f"{query}")
       
        return row.fetchall()
    except Exception as e:
        return str(e)




# s3_client.download_file('prd-bi-data-platform-configs', 'salt/salts.txt', '/opt/airflow/files/salts_from_s3.txt')

def main():
    
        with open('/opt/airflow/dags/files/salts_from_s3.txt', "r") as file:  
            salts = json.load(file)


        max_keys=pd.DataFrame(return_max_key(f"select shard_hint,max({iceberg_incr_key}) from {trino_table_name} group by 1 order by 1"),columns=['shard','max_key'])

        retry_count=0
        output=1
        select_query=""
        for k,v in trino_host_mapping.items():
            mysql_host=k 
            for i in range(v[0],v[1]+1):
                max_i_key=max_keys.loc[max_keys.shard==str(i)]['max_key'].item()
                select_query=select_query+f"""select his_addr_key,to_base64(sha256(to_utf8(concat('{salts[str(i)]}',uid)))) as uid,eid,res_addr_vtc_code,res_addr_vtc_name,res_addr_vtc_name_local,res_addr_district_code,res_addr_district_name,res_addr_district_name_local,
                res_addr_subdistrict_code,res_addr_subdistrict_name,res_addr_subdistrict_name_local,res_addr_state_code ,res_addr_state_name ,res_addr_state_name_local
                ,res_addr_po_name ,res_addr_po_name_local ,res_addr_pincode ,res_f_addr_line1 ,res_f_addr_line1_local,res_f_addr_line2 ,res_f_addr_line2_local
                ,res_f_addr_line3,res_f_addr_line3_local ,res_addr_country_code ,res_addr_country_name ,res_addr_country_name_local ,created_by ,
                creation_date,last_updated_by,last_updated_date,substring(uid,1,2) as shard_hint from {mysql_host}.uidv2_0_{i}.{mysql_table_to_read} where his_addr_key>{max_i_key-1000000} {"union " if i<99 else ""}"""
                # print(i,max_i_key)
                # # res=run_query(insert_query)
                # print(res)
                # max_f_key=return_max_key(max_query)
                # print(f"rows_inserted:{max_f_key-max_i_key}")
            # print(select_query)
        merge_query=f"""MERGE INTO {trino_table_name} as ha USING ({select_query}) as uc
        on ha.shard_hint=uc.shard_hint and ha.his_addr_key=uc.his_addr_key
        WHEN MATCHED THEN UPDATE SET
        uid=uc.uid ,eid=uc.eid ,res_addr_vtc_code=uc.res_addr_vtc_code ,res_addr_vtc_name=uc.res_addr_vtc_name ,res_addr_vtc_name_local=uc.res_addr_vtc_name_local ,res_addr_district_code=uc.res_addr_district_code ,res_addr_district_name=uc.res_addr_district_name ,res_addr_district_name_local=uc.res_addr_district_name_local ,
        res_addr_subdistrict_code=uc.res_addr_subdistrict_code ,res_addr_subdistrict_name=uc.res_addr_subdistrict_name ,res_addr_subdistrict_name_local=uc.res_addr_subdistrict_name_local ,res_addr_state_code =uc.res_addr_state_code ,res_addr_state_name =uc.res_addr_state_name ,res_addr_state_name_local
        =uc.res_addr_state_name_local ,res_addr_po_name =uc.res_addr_po_name ,res_addr_po_name_local =uc.res_addr_po_name_local ,res_addr_pincode =uc.res_addr_pincode ,res_f_addr_line1 =uc.res_f_addr_line1 ,res_f_addr_line1_local=uc.res_f_addr_line1_local ,res_f_addr_line2 =uc.res_f_addr_line2 ,res_f_addr_line2_local
        =uc.res_f_addr_line2_local ,res_f_addr_line3=uc.res_f_addr_line3 ,res_f_addr_line3_local =uc.res_f_addr_line3_local ,res_addr_country_code =uc.res_addr_country_code ,res_addr_country_name =uc.res_addr_country_name ,res_addr_country_name_local =uc.res_addr_country_name_local ,created_by =uc.created_by ,
        creation_date=uc.creation_date ,last_updated_by=uc.last_updated_by ,last_updated_date=uc.last_updated_date
        WHEN NOT MATCHED THEN INSERT 
        (his_addr_key,uid,eid,res_addr_vtc_code,res_addr_vtc_name,res_addr_vtc_name_local,res_addr_district_code,res_addr_district_name,res_addr_district_name_local,
        res_addr_subdistrict_code,res_addr_subdistrict_name,res_addr_subdistrict_name_local,res_addr_state_code ,res_addr_state_name ,res_addr_state_name_local
        ,res_addr_po_name ,res_addr_po_name_local ,res_addr_pincode ,res_f_addr_line1 ,res_f_addr_line1_local,res_f_addr_line2 ,res_f_addr_line2_local
        ,res_f_addr_line3,res_f_addr_line3_local ,res_addr_country_code ,res_addr_country_name ,res_addr_country_name_local ,created_by ,
        creation_date,last_updated_by,last_updated_date,shard_hint) VALUES (uc.his_addr_key,uc.uid,uc.eid,uc.res_addr_vtc_code,uc.res_addr_vtc_name,uc.res_addr_vtc_name_local,uc.res_addr_district_code,uc.res_addr_district_name,uc.res_addr_district_name_local,uc.
        res_addr_subdistrict_code,uc.res_addr_subdistrict_name,uc.res_addr_subdistrict_name_local,uc.res_addr_state_code ,uc.res_addr_state_name ,uc.res_addr_state_name_local
        ,uc.res_addr_po_name ,uc.res_addr_po_name_local ,uc.res_addr_pincode ,uc.res_f_addr_line1 ,uc.res_f_addr_line1_local,uc.res_f_addr_line2 ,uc.res_f_addr_line2_local
        ,uc.res_f_addr_line3,uc.res_f_addr_line3_local ,uc.res_addr_country_code ,uc.res_addr_country_name ,uc.res_addr_country_name_local ,uc.created_by ,uc.
        creation_date,uc.last_updated_by,uc.last_updated_date,uc.shard_hint)"""
        # print(merge_query)
        # print("--------------------------------------------------------")
        output=run_query(merge_query)
        # current_keys=pd.DataFrame(return_max_key(f"select shard_hint,max(uid_his_key) from {trino_table_name} group by 1 order by 1"),columns=['shard','current_max_key'])
        # logging.info(current_keys)
        # os.remove('/opt/airflow/files/salts_from_s3.txt')

        if output['success']==1:
            return "successfully executed"
        else:
            return output['msg']

update_uid_his_address_daily_table = PythonOperator(
                task_id='uid_his_address_merge_query',
                python_callable=main,
                dag=dag,
            )

