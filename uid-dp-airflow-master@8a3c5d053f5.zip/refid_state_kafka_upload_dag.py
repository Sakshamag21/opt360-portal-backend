from datetime import datetime, timedelta
import pandas as pd
import json
from trino.dbapi import connect
from kafka import KafkaProducer
from airflow.decorators import dag, task
from airflow.models import Variable

# Configuration
trino_host = "10.10.118.35"
trino_port = 8080
trino_user = "abis_user.nisg"

kafka_bootstrap_servers = '10.10.105.225:9092'
kafka_topic = 'DE.REFID.STATE.AGE.DETAILS'
kafka_client_id = 'de_state_upload'

# Default variables
default_args = {
    'owner': 'harshag.nisg',
    'depends_on_past': False,
    'start_date': datetime(2026, 7, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1
}


@dag(
    dag_id='refid_state_kafka_upload',
    default_args=default_args,
    schedule=None,  # Runs at 2:00 AM UTC every day
    catchup=False,
    tags=['kafka', 'refid', 'state-data'],
    description='Fetches REFID state metadata from Trino and uploads to Kafka'
)
def refid_state_kafka_upload_dag():

    # Helper function to execute Trino queries
    def execute_trino_query(query, catalog=None, schema=None):
        """
        Execute a Trino query and return results as DataFrame.
        Handles connection, execution, and resource cleanup.
        """
        conn = None
        cur = None
        start_timestamp = datetime.now()
        try:
            print(f"📊 Connecting to Trino: {trino_host}:{trino_port}")
            conn = connect(
                host=trino_host,
                port=trino_port,
                user=trino_user,
                catalog=catalog,
                schema=schema
            )
            cur = conn.cursor()
            print(f"📝 Executing Trino query...")
            cur.execute(query)
            body = cur.fetchall()
            print(f"✅ Rows fetched: {len(body)}")
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return df
        except KeyboardInterrupt:
            if cur:
                print("⚠️ KeyboardInterrupt: Cancelling Trino query...")
                try:
                    cur.cancel()
                except Exception as cancel_exc:
                    print(f"❌ Failed to cancel query: {cancel_exc}")
            raise
        except Exception as e:
            print(f"❌ Trino error: {e}")
            raise
        finally:
            if cur:
                try:
                    cur.close()
                except Exception as close_exc:
                    print(f"⚠️ Cursor close error: {close_exc}")
            if conn:
                try:
                    conn.close()
                except Exception as conn_close_exc:
                    print(f"⚠️ Connection close error: {conn_close_exc}")
            elapsed = datetime.now() - start_timestamp
            print(f"⏱️ Time Elapsed: {elapsed}")

    @task
    def fetch_state_metadata(**kwargs):
        """
        Fetch state-wise REFID metadata from Trino.
        Gets enrollment details, biometric info, and DOB year.
        """
        # Get state name from Airflow Variable or use default
        state_name = Variable.get("refid_state_name", default_var="ASSAM")
        print(f"📍 Processing state: {state_name}")
        
        query = f'''
            with t2 as(
                select t2.uid,t2.res_addr_state_code,res_addr_state_name,res_dob_year,biometric_exception_ind,uid_status_key 
                from 
                (select uid,res_addr_state_code,res_addr_state_name 
                 from strot.mysql_uid_v2.uid_address 
                 where lower(res_addr_state_name) like '%{state_name.lower()}%') t2 
                join (select uid,res_dob_year,biometric_exception_ind,uid_status_key 
                      from strot.mysql_uid_v2.uid_master) t3 
                on t2.uid=t3.uid
            ),
            t1 as (
                select refid,enr_type,enr_status,enr_status_date,uid,year(creation_date) as creation_year 
                from strot.mysql_uid_v2.uid_origin_tracker
                where enr_type in ('N','B','C','E') 
                  and enr_status!='IP' 
                  and ischild='0'
            )
            select t1.refid,t1.enr_type,t1.enr_status_date,t2.res_addr_state_code,t2.res_addr_state_name,
                   t2.biometric_exception_ind,t2.res_dob_year,t1.creation_year
            from t1 join t2 on t1.uid=t2.uid
        '''
        
        state_metadata = execute_trino_query(query)
        print(f"📦 Fetched {len(state_metadata)} records for state: {state_name}")
        
        # Convert to dict for easier processing
        records = state_metadata.to_dict('records')
        print(f"✅ Converted to {len(records)} dictionary records")
        
        return records

    @task
    def upload_to_kafka(records, **kwargs):
        """
        Upload REFID metadata records to Kafka topic.
        Serializes data and sends to Kafka producer.
        """
        if not records:
            print("⚠️ No records to upload")
            return
        
        try:
            print(f"🚀 Initializing Kafka producer...")
            producer = KafkaProducer(
                client_id=kafka_client_id,
                bootstrap_servers=kafka_bootstrap_servers,
                value_serializer=lambda v: json.dumps(v).encode('utf-8')
            )
            
            print(f"📤 Sending {len(records)} records to Kafka topic: {kafka_topic}")
            
            successful_sends = 0
            failed_sends = 0
            
            for idx, record in enumerate(records):
                try:
                    # Convert timestamp to ISO format string
                    if 'enr_status_date' in record and pd.notna(record['enr_status_date']):
                        record['enr_status_date'] = record['enr_status_date'].to_pydatetime().strftime('%Y-%m-%dT%H:%M:%S')
                    
                    # Send to Kafka
                    producer.send(kafka_topic, value=record)
                    successful_sends += 1
                    
                    # Log every 100th record
                    if (idx + 1) % 100 == 0:
                        print(f"  ✓ Sent {idx + 1}/{len(records)} records")
                
                except Exception as e:
                    failed_sends += 1
                    print(f"  ❌ Failed to send record {idx}: {e}")
                    if failed_sends > 10:  # Stop after 10 failures
                        print(f"  ⚠️ Too many failures, stopping upload...")
                        break
            
            # Flush remaining messages
            producer.flush(timeout_ms=5000)
            producer.close()
            
            print(f"📊 Upload summary:")
            print(f"  ✅ Successful: {successful_sends}")
            print(f"  ❌ Failed: {failed_sends}")
            print(f"  📝 Total: {len(records)}")
            
            return {
                'total': len(records),
                'successful': successful_sends,
                'failed': failed_sends
            }
        
        except Exception as e:
            print(f"❌ Kafka producer error: {e}")
            raise

    # Task execution order
    metadata_records = fetch_state_metadata()
    upload_result = upload_to_kafka(metadata_records)


# Instantiate the DAG
dag_instance = refid_state_kafka_upload_dag()
