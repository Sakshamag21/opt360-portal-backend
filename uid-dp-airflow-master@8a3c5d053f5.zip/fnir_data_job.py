from airflow.sdk import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta, timezone
from trino.dbapi import connect
import pandas as pd

trino_host = "10.10.116.75"
trino_port = 8080
trino_user = "fnir_data_job"

def trino(query, host=trino_host, port=trino_port, user=trino_user):
    conn = None
    try:
        conn = connect(
            host=host,
            port=port,
            user=user
        )
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"query": query, "success": 1, "data": body}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}
    finally:
        if conn:
            conn.close()


def backfill_fnir_metrics(start_date, end_date):
    current_date = start_date
    end_date = end_date

    while current_date <= end_date:
        next_day = current_date + timedelta(days=1)
        lookback_date = current_date - timedelta(days=1095)

        print(f"Processing FNIR for date: {current_date}...")

        query = f"""
        MERGE INTO strot.misc_adhoc.fnir_metrics AS target
        USING (
            WITH probesRefCode AS (
                SELECT reference_code
                FROM flink_stream.stream_enu.abis_request_tracker_union_v2
                WHERE creation_date >= CAST('{current_date}' AS TIMESTAMP)
                AND creation_date < CAST('{next_day}' AS TIMESTAMP)
                AND request_type = 'IDENTIFY'
                GROUP BY reference_code
                HAVING COUNT(DISTINCT abis_code) = 3
            ),
            nTypeProbes AS (
                SELECT a.reference_code
                FROM probesRefCode a
                JOIN strot.mysql_uid_v2.request_tracker b
                ON a.reference_code = b.refid
                ---- AND b.sid_date >= CAST('{lookback_date}' AS TIMESTAMP)
                AND b.type = 'N'
            ),
            trueDuplicateRefCodes AS (
                SELECT a.reference_code, count(*) as no_of_duplicates
                FROM nTypeProbes a
                JOIN flink_stream.stream_enu.abis_candidate_match_analysis_v1 b
                ON a.reference_code = b.reference_code AND b.creation_date >= CAST('{current_date}' AS TIMESTAMP)
                JOIN flink_stream.stream_enu.mdd_demo_dedup_cdc_v1 c
                ON b.reference_code = c.res_ref_code AND b.candidate_ref_code = c.candiate_ref_code AND c.creation_date >= CAST('{current_date}' AS TIMESTAMP)
                WHERE b.true_duplicate = 1 AND c.duplicate = 1
                GROUP BY 1
            ),
            tdProbesRefCode AS (
                SELECT a.reference_code, b.abis_code
                FROM trueDuplicateRefCodes a
                JOIN flink_stream.stream_enu.abis_request_tracker_union_v2 b
                ON a.reference_code = b.reference_code
                WHERE b.creation_date >= CAST('{current_date}' AS TIMESTAMP)
                AND b.creation_date < CAST('{next_day}' AS TIMESTAMP)
                AND request_type = 'IDENTIFY' AND status = 'DEDUP_FAILURE'
            ),
            tdAggregation AS (
                SELECT DATE('{current_date}') AS abis_decision_date,
                SUM(CASE WHEN abis_code = 'ABIS1' THEN 1 ELSE 0 END) AS abis1_td_count,
                SUM(CASE WHEN abis_code = 'ABIS2' THEN 1 ELSE 0 END) AS abis2_td_count,
                SUM(CASE WHEN abis_code = 'ABIS3' THEN 1 ELSE 0 END) AS abis3_td_count
                FROM tdProbesRefCode
            ),
            trueDuplicateProbes AS (
                SELECT a.reference_code, b.candidate_ref_code
                FROM nTypeProbes a
                JOIN flink_stream.stream_enu.abis_candidate_match_analysis_v1 b
                ON a.reference_code = b.reference_code AND b.creation_date >= CAST('{current_date}' AS TIMESTAMP)
                JOIN flink_stream.stream_enu.mdd_demo_dedup_cdc_v1 c
                ON b.reference_code = c.res_ref_code AND b.candidate_ref_code = c.candiate_ref_code AND c.creation_date >= CAST('{current_date}' AS TIMESTAMP)
                WHERE b.true_duplicate = 1 AND c.duplicate = 1
            ),
            enrichedProbesWithApplicantIdentifyTS AS (
                SELECT a.reference_code, a.candidate_ref_code, b.abis_code, MIN(b.creation_date) AS res_identify_ts
                FROM trueDuplicateProbes a
                JOIN flink_stream.stream_enu.abis_request_tracker_union_v2 b
                ON a.reference_code = b.reference_code
                WHERE b.creation_date >= CAST('{current_date}' AS TIMESTAMP)
                AND b.creation_date < CAST('{next_day}' AS TIMESTAMP)
                AND b.request_type = 'IDENTIFY'
                GROUP BY 1, 2, 3
            ),
            enrichedProbesWithCandidateInsertTS AS (
                SELECT a.reference_code, a.candidate_ref_code, a.abis_code, a.res_identify_ts, MAX(b.creation_date) AS candidate_insert_ts
                FROM enrichedProbesWithApplicantIdentifyTS a
                LEFT JOIN flink_stream.stream_enu.abis_request_tracker_union_v2 b
                ON a.candidate_ref_code = b.reference_code AND a.abis_code = b.abis_code
                AND b.creation_date >= CAST('{current_date}' AS TIMESTAMP)
                AND b.request_type = 'INSERT'
                GROUP BY 1,2,3,4
            ),
            trueDuplicates AS (
                SELECT reference_code, count(*)
                FROM enrichedProbesWithCandidateInsertTS
                WHERE candidate_insert_ts IS NULL OR res_identify_ts > candidate_insert_ts
                group by 1
            ),
            falseNegatives AS (
                SELECT a.reference_code, b.abis_code
                FROM trueDuplicates a
                JOIN flink_stream.stream_enu.abis_request_tracker_union_v2 b
                ON a.reference_code = b.reference_code
                WHERE b.creation_date >= CAST('{current_date}' AS TIMESTAMP)
                AND b.creation_date < CAST('{next_day}' AS TIMESTAMP)
                AND b.request_type = 'IDENTIFY' AND b.status = 'DEDUP_SUCCESS'
            ),
            fnAggregation AS (
                SELECT DATE('{current_date}') AS abis_decision_date,
                SUM(CASE WHEN abis_code = 'ABIS1' THEN 1 ELSE 0 END) AS abis1_fn_count,
                SUM(CASE WHEN abis_code = 'ABIS2' THEN 1 ELSE 0 END) AS abis2_fn_count,
                SUM(CASE WHEN abis_code = 'ABIS3' THEN 1 ELSE 0 END) AS abis3_fn_count
                FROM falseNegatives
            ),
            finalMetrics AS (
                SELECT
                    COALESCE(t.abis_decision_date, f.abis_decision_date) AS abis_decision_date,
                    COALESCE(t.abis1_td_count, 0) AS abis1_td_count,
                    COALESCE(t.abis2_td_count, 0) AS abis2_td_count,
                    COALESCE(t.abis3_td_count, 0) AS abis3_td_count,
                    COALESCE(f.abis1_fn_count, 0) AS abis1_fn_count,
                    COALESCE(f.abis2_fn_count, 0) AS abis2_fn_count,
                    COALESCE(f.abis3_fn_count, 0) AS abis3_fn_count,

                    CASE
                        WHEN COALESCE(t.abis1_td_count, 0) < 1000 AND COALESCE(f.abis1_fn_count, 0) > 0
                        THEN COALESCE(f.abis1_fn_count, 0) - 1
                        ELSE COALESCE(f.abis1_fn_count, 0)
                    END AS abis1_fn_count_adjusted,

                    CASE
                        WHEN COALESCE(t.abis2_td_count, 0) < 1000 AND COALESCE(f.abis2_fn_count, 0) > 0
                        THEN COALESCE(f.abis2_fn_count, 0) - 1
                        ELSE COALESCE(f.abis2_fn_count, 0)
                    END AS abis2_fn_count_adjusted,

                    CASE
                        WHEN COALESCE(t.abis3_td_count, 0) < 1000 AND COALESCE(f.abis3_fn_count, 0) > 0
                        THEN COALESCE(f.abis3_fn_count, 0) - 1
                        ELSE COALESCE(f.abis3_fn_count, 0)
                    END AS abis3_fn_count_adjusted

                FROM tdAggregation t
                FULL OUTER JOIN fnAggregation f
                    ON t.abis_decision_date = f.abis_decision_date
            ),
            finalMetricsWithPercentage AS (
                SELECT
                    abis_decision_date,
                    abis1_td_count,
                    abis2_td_count,
                    abis3_td_count,
                    abis1_fn_count,
                    abis2_fn_count,
                    abis3_fn_count,
                    CAST(
                        CASE
                            WHEN abis1_td_count > 0
                            THEN ROUND(CAST(abis1_fn_count_adjusted AS DOUBLE) * 100.0 / CAST(abis1_td_count AS DOUBLE), 4)
                            ELSE 0.0000
                        END AS DECIMAL(10, 4)
                    ) AS abis1_fnir,

                    CAST(
                        CASE
                            WHEN abis2_td_count > 0
                            THEN ROUND(CAST(abis2_fn_count_adjusted AS DOUBLE) * 100.0 / CAST(abis2_td_count AS DOUBLE), 4)
                            ELSE 0.0000
                        END AS DECIMAL(10, 4)
                    ) AS abis2_fnir,

                    CAST(
                        CASE
                            WHEN abis3_td_count > 0
                            THEN ROUND(CAST(abis3_fn_count_adjusted AS DOUBLE) * 100.0 / CAST(abis3_td_count AS DOUBLE), 4)
                            ELSE 0.0000
                        END AS DECIMAL(10, 4)
                    ) AS abis3_fnir

                FROM finalMetrics
            )
            SELECT * FROM finalMetricsWithPercentage
        ) AS source
        ON target.abis_decision_date = source.abis_decision_date
        WHEN MATCHED THEN
            UPDATE SET
                abis1_td_count = source.abis1_td_count,
                abis2_td_count = source.abis2_td_count,
                abis3_td_count = source.abis3_td_count,
                abis1_fn_count = source.abis1_fn_count,
                abis2_fn_count = source.abis2_fn_count,
                abis3_fn_count = source.abis3_fn_count,
                abis1_fnir = source.abis1_fnir,
                abis2_fnir = source.abis2_fnir,
                abis3_fnir = source.abis3_fnir
        WHEN NOT MATCHED THEN
            INSERT (
                abis_decision_date,
                abis1_td_count,
                abis2_td_count,
                abis3_td_count,
                abis1_fn_count,
                abis2_fn_count,
                abis3_fn_count,
                abis1_fnir,
                abis2_fnir,
                abis3_fnir
            )
            VALUES (
                source.abis_decision_date,
                source.abis1_td_count,
                source.abis2_td_count,
                source.abis3_td_count,
                source.abis1_fn_count,
                source.abis2_fn_count,
                source.abis3_fn_count,
                source.abis1_fnir,
                source.abis2_fnir,
                source.abis3_fnir
            )
        """
        
        res = trino(query)
        if res["success"] == 1:
            print(f"result: {res['data']}")
            print(f"Successfully processed {current_date}")
        else:
            error_msg = res.get('msg', 'Trino query failed')
            print(f"Insert Data Failed! {error_msg}")
        
        current_date += timedelta(days=1)


def insert_fnir_data():
    ist_tz = timezone(timedelta(hours=5, minutes=30))
    today_ist = datetime.now(ist_tz).date()
    
    end_date = today_ist - timedelta(days=7)
    start_date = today_ist - timedelta(days=12)

    backfill_fnir_metrics(start_date, end_date)

default_args = {
    'owner': 'inzamam.nisg',
    'depends_on_past': False,
    'start_date': datetime(2026, 8, 13),
    'email': ["techexe15.yp25@uidai.net.in", "techexecutive22-yp23@uidai.net.in", "techexecutive14-yp23@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 5
}

dag = DAG(
    'BSPS_FNIR_Metrics',
    default_args=default_args,
    description="Dag to insert fnir metrics into table",
    schedule="0 22 * * *",
    catchup=False,
    tags=["FNIR", "BSP", "ABIS"]
)

task = PythonOperator(
    task_id='insert_fnir_metrics',
    python_callable=insert_fnir_data,
    dag=dag,
)

task