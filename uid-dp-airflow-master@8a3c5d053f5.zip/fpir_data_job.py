from airflow.sdk import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from trino.dbapi import connect
import pandas as pd

trino_host = "10.10.116.75"
trino_port = 8080
trino_user = "fpir_data_job"

query = """
MERGE INTO strot.misc_adhoc.fpir_metrics AS target
USING (
    WITH dedup_success_per_abis AS (
        SELECT
            DATE(creation_date) AS abis_decision_date,
            abis_code,
            COUNT(*) AS ds_count
        FROM flink_stream.stream_enu.abis_request_tracker_union_v2
        WHERE creation_date >= CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP) - INTERVAL '12' DAY
          AND creation_date < CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP) - INTERVAL '7' DAY
          AND request_type = 'IDENTIFY'
          AND status = 'DEDUP_SUCCESS'
        GROUP BY 1, 2
    ),
    dedup_success_counts AS (
        SELECT 
            abis_decision_date,
            SUM(CASE WHEN abis_code = 'ABIS1' THEN ds_count ELSE 0 END) AS abis1_dedup_success_count,
            SUM(CASE WHEN abis_code = 'ABIS2' THEN ds_count ELSE 0 END) AS abis2_dedup_success_count,
            SUM(CASE WHEN abis_code = 'ABIS3' THEN ds_count ELSE 0 END) AS abis3_dedup_success_count
        FROM dedup_success_per_abis
        GROUP BY 1
    ),
    fp_applicants AS (
        SELECT
            DATE(a.creation_date) AS abis_decision_date,
            a.abis_code,
            a.reference_code
        FROM flink_stream.stream_enu.abis_request_tracker_union_v2 a
        INNER JOIN flink_stream.stream_enu.abis_candidate_match_analysis_v1 b
            ON a.reference_code = b.reference_code
        INNER JOIN flink_stream.stream_enu.mdd_demo_dedup_cdc_v1 c
            ON b.reference_code = c.res_ref_code
           AND b.candidate_ref_code = c.candiate_ref_code
        WHERE a.creation_date >=  CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP) - INTERVAL '12' DAY
          AND a.creation_date <   CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP) - INTERVAL '7' DAY
          AND b.creation_date >= CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP) - INTERVAL '12' DAY
          AND c.creation_date >= CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP) - INTERVAL '12' DAY
          AND a.request_type = 'IDENTIFY'
          AND b.false_positive = 1
          AND c.duplicate = 0
        GROUP BY 1, 2, 3
    ),
    fp_agg AS (
        SELECT
            abis_decision_date,
            abis_code,
            COUNT(reference_code) AS fp_count
        FROM fp_applicants
        GROUP BY 1, 2
    ),
    fp_counts AS (
        SELECT 
            abis_decision_date,
            SUM(CASE WHEN abis_code = 'ABIS1' THEN fp_count ELSE 0 END) AS abis1_fp_count,
            SUM(CASE WHEN abis_code = 'ABIS2' THEN fp_count ELSE 0 END) AS abis2_fp_count,
            SUM(CASE WHEN abis_code = 'ABIS3' THEN fp_count ELSE 0 END) AS abis3_fp_count
        FROM fp_agg
        GROUP BY 1
    ),
    final_metrics AS (
        SELECT
            COALESCE(ds.abis_decision_date, fp.abis_decision_date) AS abis_decision_date,
            COALESCE(ds.abis1_dedup_success_count, 0) AS abis1_dedup_success_count,
            COALESCE(ds.abis2_dedup_success_count, 0) AS abis2_dedup_success_count,
            COALESCE(ds.abis3_dedup_success_count, 0) AS abis3_dedup_success_count,
            COALESCE(fp.abis1_fp_count, 0) AS abis1_fp_count,
            COALESCE(fp.abis2_fp_count, 0) AS abis2_fp_count,
            COALESCE(fp.abis3_fp_count, 0) AS abis3_fp_count,
            CAST(
                CASE 
                    WHEN COALESCE(ds.abis1_dedup_success_count, 0) > 0 
                    THEN ROUND(CAST(COALESCE(fp.abis1_fp_count, 0) AS DOUBLE) * 100.0 / CAST(ds.abis1_dedup_success_count AS DOUBLE), 4) 
                    ELSE 0.0000 
                END AS DECIMAL(10, 4)
            ) AS abis1_fpir,
            CAST(
                CASE 
                    WHEN COALESCE(ds.abis2_dedup_success_count, 0) > 0 
                    THEN ROUND(CAST(COALESCE(fp.abis2_fp_count, 0) AS DOUBLE) * 100.0 / CAST(ds.abis2_dedup_success_count AS DOUBLE), 4) 
                    ELSE 0.0000 
                END AS DECIMAL(10, 4)
            ) AS abis2_fpir,
            CAST(
                CASE 
                    WHEN COALESCE(ds.abis3_dedup_success_count, 0) > 0 
                    THEN ROUND(CAST(COALESCE(fp.abis3_fp_count, 0) AS DOUBLE) * 100.0 / CAST(ds.abis3_dedup_success_count AS DOUBLE), 4) 
                    ELSE 0.0000 
                END AS DECIMAL(10, 4)
            ) AS abis3_fpir
        FROM dedup_success_counts ds
        FULL OUTER JOIN fp_counts fp 
            ON ds.abis_decision_date = fp.abis_decision_date
    )
    SELECT * FROM final_metrics
) AS source
ON target.abis_decision_date = source.abis_decision_date
WHEN MATCHED THEN
    UPDATE SET
        abis1_dedup_success_count = source.abis1_dedup_success_count,
        abis2_dedup_success_count = source.abis2_dedup_success_count,
        abis3_dedup_success_count = source.abis3_dedup_success_count,
        abis1_fp_count = source.abis1_fp_count,
        abis2_fp_count = source.abis2_fp_count,
        abis3_fp_count = source.abis3_fp_count,
        abis1_fpir = source.abis1_fpir,
        abis2_fpir = source.abis2_fpir,
        abis3_fpir = source.abis3_fpir
WHEN NOT MATCHED THEN
    INSERT (
        abis_decision_date,
        abis1_dedup_success_count,
        abis2_dedup_success_count,
        abis3_dedup_success_count,
        abis1_fp_count,
        abis2_fp_count,
        abis3_fp_count,
        abis1_fpir,
        abis2_fpir,
        abis3_fpir
    )
    VALUES (
        source.abis_decision_date,
        source.abis1_dedup_success_count,
        source.abis2_dedup_success_count,
        source.abis3_dedup_success_count,
        source.abis1_fp_count,
        source.abis2_fp_count,
        source.abis3_fp_count,
        source.abis1_fpir,
        source.abis2_fpir,
        source.abis3_fpir
    )
"""


def trino(query, host=trino_host, port=trino_port, user=trino_user):
    conn = None
    try:
        conn = connect(
            host=host,
            port=port,
            user=user
        )
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"query": query, "success": 1, "data": body}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}
    finally:
        if conn:
            conn.close()

def insertData(query):
    res = trino(query)
    if res['success'] == 1:
        print(f"Inserted Data: {res['data']}")
    else:
        error_msg = res.get('msg', 'Trino query failed')
        print(f"Insert Data Failed! {error_msg}")
        raise Exception(error_msg)

default_args = {
    'owner': 'inzamam.nisg',
    'depends_on_past': False,
    'start_date': datetime(2026, 8, 13),
    'email': ["techexe15.yp25@uidai.net.in", "techexecutive22-yp23@uidai.net.in", "techexecutive14-yp23@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 5
}

dag = DAG(
    'BSPS_FPIR_Metrics',
    default_args=default_args,
    description="Dag to insert fpir metrics into table",
    schedule="0 22 * * *",
    catchup=False,
    tags=["FPIR", "BSP", "ABIS"]
)

task = PythonOperator(
    task_id='insert_fpir_metrics',
    python_callable=insertData,
    op_kwargs={'query': query},
    dag=dag,
)

task