import os
from datetime import datetime
from airflow.sdk import DAG
from kubernetes.client import models as k8s
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator

job_name = "ICEBERG_V3_COMPACTION"
desc = "Job to compact iceberg v3 tables"
pod_name = "iceberg-comp-v3-mor-watch-pod"
t_id = "v3-mor-comp-task"

bucket = "prd-bi-data-platform-uploads"
key = "sparkjobs/compaction/v3_comp_tables.yaml"
filename = "v3_comp_tables.yaml"

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2026, 6, 19),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1
}

custom_toleration = k8s.V1Toleration(
    key="strot",
    operator='Equal',
    value='true',
    effect='NoSchedule'
)

dag = DAG(
    f'{job_name}',
    default_args=default_args,
    description=f'{desc}',
    schedule="0 6 * * *",
    catchup=False
)


task = KubernetesPodOperator(
    namespace='strot-spark',
    service_account_name='strot-service-account',
    image="harbor-registry-prod.uidai.gov.in/data-platform/pyspark_duckdb:4.0.7", 
    config_file="/opt/airflow/dags/gpu_kubeconfig_hdc", 
    name=f"{pod_name}", task_id=f"{t_id}", 
    tolerations=[custom_toleration],
    cmds=["/bin/bash", "-c"],
    arguments=[
        f"""python3 -c "import boto3;session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4');s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425');s3_client.download_file('prd-bi-data-platform-uploads','sparkjobs/compaction/v3_spark_comp_head.py','/tmp/v3_spark_comp_head.py')" && python3 /tmp/v3_spark_comp_head.py --bucket {bucket} --key {key} --filename {filename}"""
    ],
    container_resources=k8s.V1ResourceRequirements(
        requests={"cpu": "1", "memory": "2Gi"},
        limits={"cpu": "1", "memory": "2Gi"}
    ),
    in_cluster=False, get_logs=True, log_events_on_failure=True, dag=dag,
)

task