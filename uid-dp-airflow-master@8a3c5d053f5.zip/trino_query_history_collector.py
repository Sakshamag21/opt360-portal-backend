import subprocess
import sys
import importlib
import threading
from datetime import datetime, timedelta, timezone
from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator

# Define IST Timezone (UTC + 5:30)
IST = timezone(timedelta(hours=5, minutes=30))

# Install strot_query if not present
package = "strot_query"
try:
    importlib.import_module(package)
except ImportError:
    subprocess.check_call([
        sys.executable, "-m", "pip", "install",
        '--no-cache-dir',
        '--index-url', 'http://10.10.206.59:8080/repository/pypi-local/simple',
        '--trusted-host', '10.10.206.59',
        package
    ])
    importlib.invalidate_caches()
    globals()[package] = importlib.import_module(package)

import trino
import pandas as pd
import strot_query as sq

# Configuration
DESTINATION_HOST = '10.10.116.75'
DEST_TABLE = 'strot.analytics_services.trino_query_history'

def safe_val(v):
    """Convert None to SQL NULL string, otherwise wrap in single quotes with escaping."""
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return "NULL"
    if isinstance(v, (int, float)):
        return str(v)
    s = str(v).replace("'", "''")
    return f"'{s}'"

def get_last_check_times():
    """
    Queries the destination server to find the last inserted 'created' time for EACH host.
    Converts any existing UTC times to IST for accurate comparison.
    """
    print("Fetching last check times from destination database...")
    query = f"""
        SELECT host, max(created) AS last_created
        FROM {DEST_TABLE}
        GROUP BY host
    """
    try:
        result = sq.query(query, host=DESTINATION_HOST)
        if 'df' in result and not result['df'].empty:
            df_times = result['df']
            time_dict = {}
            for _, row in df_times.iterrows():
                ts = pd.to_datetime(row['last_created'])
                
                # Convert to IST if it was stored as naive UTC from previous runs
                if ts.tzinfo is None:
                    ts = ts.tz_localize('UTC')
                ts = ts.tz_convert(IST)
                
                # Format as string without offset to keep Trino 'timestamp' literal happy
                time_dict[row['host']] = ts.strftime('%Y-%m-%d %H:%M:%S.%f')
            print(f"Last check times found (IST): {time_dict}")
            return time_dict
    except Exception as e:
        print(f"Warning: Could not fetch last check times (might be first run). Error: {e}")
    
    return {}

def process_servers(host_list, last_check_times, target_insert_host):
    """
    Independent worker function for a thread. Fetches data for a list of servers
    and handles its own batch insertion into the specified target_insert_host.
    """
    now = datetime.now(IST)  # Changed from utcnow() to IST
    all_rows_to_insert = []
    columns = [
        'query_id', 'query', 'state', 'user', 'source', 'created', 'end',
        'queued_time_ms', 'analysis_time_ms', 'planning_time_ms',
        'error_type', 'error_code', 'host'
    ]
    
    # 1. Fetch data from assigned source servers
    for src_host in host_list:
        print(f"\n--- [Thread] Fetching from source Trino: {src_host} ---")
        
        last_time = last_check_times.get(src_host)
        if last_time is None:
            last_time_obj = now - timedelta(minutes=30)
            # Format to string to avoid Trino syntax errors with timezone offsets
            last_time = last_time_obj.strftime('%Y-%m-%d %H:%M:%S.%f')
            print(f"No previous data for {src_host}. Defaulting to 30 mins ago (IST): {last_time}")
        else:
            print(f"Querying {src_host} for queries created after (IST): {last_time}")

        try:
            conn = trino.dbapi.Connect(
                host=src_host,
                port=8080,
                user='airflow_collector',
                catalog='system',
                schema='runtime'
            )
            cur = conn.cursor()
            
            sql_query = f"""
                SELECT
                    query_id, query, state, "user", source, created, "end",
                    queued_time_ms, analysis_time_ms, planning_time_ms,
                    coalesce(error_type,'') as error_type, coalesce(error_code,'') as error_code
                FROM system.runtime.queries
                WHERE created > timestamp '{last_time}'
                  AND state IN ('FINISHED', 'FAILED')
                  AND query NOT LIKE '%{DEST_TABLE}%'
                  AND query NOT LIKE '%system.runtime.queries%'
                ORDER BY created ASC
            """
            cur.execute(sql_query)
            rows = cur.fetchall()
            cur.close()
            conn.close()
            
            if not rows:
                print(f"No new queries found on {src_host}.")
                continue
                
            print(f"Found {len(rows)} new queries on {src_host}.")
            
            for row in rows:
                row_list = list(row)
                row_list.append(src_host)
                all_rows_to_insert.append(row_list)
                
        except Exception as e:
            print(f"ERROR fetching from {src_host}: {e}")
            continue

    # 2. Batch Insert into the Assigned Target Server
    if not all_rows_to_insert:
        print(f"\nNo new queries found for thread. Exiting.")
        return

    print(f"\nPreparing to batch insert {len(all_rows_to_insert)} rows into {target_insert_host}...")

    col_names = ", ".join([f'"{col}"' if col in ['user', 'end'] else col for col in columns])
    chunk_size = 50
    total_inserted = 0
    
    for i in range(0, len(all_rows_to_insert), chunk_size):
        chunk = all_rows_to_insert[i:i + chunk_size]
        
        values_sql = []
        for row in chunk:
            if len(row) != 13:
                continue
                
            v_query_id = safe_val(row[0])
            v_query = safe_val(row[1])
            v_state = safe_val(row[2])
            v_user = safe_val(row[3])
            v_source = safe_val(row[4])
            v_created = f"CAST({safe_val(row[5])} AS timestamp(6))"
            v_end = f"CAST({safe_val(row[6])} AS timestamp(6))"
            v_queued = f"CAST({safe_val(row[7])} AS bigint)"
            v_analysis = f"CAST({safe_val(row[8])} AS bigint)"
            v_planning = f"CAST({safe_val(row[9])} AS bigint)"
            v_err_type = safe_val(row[10])
            v_err_code = safe_val(row[11])
            v_host = safe_val(row[12])
            
            vals_str = f"({v_query_id}, {v_query}, {v_state}, {v_user}, {v_source}, {v_created}, {v_end}, {v_queued}, {v_analysis}, {v_planning}, {v_err_type}, {v_err_code}, {v_host})"
            values_sql.append(vals_str)

        if not values_sql:
            continue

        batch_insert_sql = f"""
            INSERT INTO {DEST_TABLE} 
            ({col_names})
            VALUES {', '.join(values_sql)}
        """
        
        try:
            # Insert into the specific target host assigned to this thread
            query_res = sq.query(batch_insert_sql, host=target_insert_host)
            if 'data' in query_res and 'df' in query_res:
                total_inserted += len(values_sql)
                print(f"Successfully inserted chunk of {len(values_sql)} rows into {target_insert_host}.")
        except Exception as e:
            print(f"ERROR inserting batch into {target_insert_host}: {e}")
            print(f"Failed SQL chunk snippet: {batch_insert_sql[:500]}...")

    print(f"\nThread complete! Total rows inserted into {target_insert_host}: {total_inserted}")


def fetch_and_store_trino_queries(**kwargs):
    """
    Main DAG function. Fetches watermarks once, then spawns 2 independent threads.
    Thread 1 fetches 118.10 and inserts back into 118.10.
    Thread 2 fetches 39 & 75 and inserts into 75.
    """
    last_check_times = get_last_check_times()
    
    # Group 1: Fetch from 118.10 -> Insert into 118.10
    group1_hosts = ['10.10.118.10']
    group1_target = '10.10.118.10'
    
    # Group 2: Fetch from 39 & 75 -> Insert into 75
    group2_hosts = ['10.10.116.39', '10.10.116.75']
    group2_target = '10.10.116.75'
    
    print("\n--- Starting Parallel Threads ---")
    
    thread1 = threading.Thread(target=process_servers, args=(group1_hosts, last_check_times, group1_target))
    thread2 = threading.Thread(target=process_servers, args=(group2_hosts, last_check_times, group2_target))
    
    thread1.start()
    thread2.start()
    
    thread1.join()
    thread2.join()
    
    print("\n--- All Threads Completed ---")
    print("DAG Run Complete!")

# -----------------------------------------
# DAG Definition
# -----------------------------------------

default_args = {
    'owner': 'Goverdhan',
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id='trino_query_history_collector_v2',
    default_args=default_args,
    description='Fetches Trino query history from multiple servers via parallel threads and batch loads it',
    schedule='*/30 * * * *',
    start_date=datetime(2026, 8, 21, tzinfo=IST),  # Added IST timezone to start_date
    catchup=False,
    max_active_runs=1,
    max_active_tasks=1,
    tags=['trino', 'analytics', 'multi-server', 'threaded'],
) as dag:

    fetch_trino_queries_task = PythonOperator(
        task_id='fetch_and_store_trino_queries',
        python_callable=fetch_and_store_trino_queries,
    )
        
    fetch_trino_queries_task