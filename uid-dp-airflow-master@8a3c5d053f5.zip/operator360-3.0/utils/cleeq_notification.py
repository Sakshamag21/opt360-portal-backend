

def send_cleeq_notification(task_id: str, message:str):
    print("send cleeq notification")
    print(task_id, message)