from airflow.sdk import DAG
from airflow.providers.standard.operators.python import PythonOperator
from airflow.providers.smtp.operators.smtp import EmailOperator

import datetime
import calendar
from trino.dbapi import connect
import pandas as pd
import os
import logging

trino_host="10.10.116.75"
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="airflow_dag_op"

# mail_list = ["dir.eu-hq@uidai.net.in"]
# cc= ["alladgro@uidai.net.in,allddgro@uidai.net.in,allddro.uidai@uidai.net.in,dir.eu2-hq@uidai.net.in,adg.tech-tc@uidai.net.in,ddg.techdev@uidai.net.in,hoe.dev-tc@uidai.net.in,techexecutive22-yp23@uidai.net.in,pmu1.eu1-hq@uidai.net.in,kajal.raina@uidai.net.in,mgrops.eu2-hq@uidai.net.in,techexe15.yp25@uidai.net.in,techexecutive14-yp23@uidai.net.in,bi.dev02@uidai.net.in,sr.mgrops-tc@uidai.net.in,productmgr4-tc@uidai.net.in"]

mail_list = ["techexe15.yp25@uidai.net.in"]
cc = ["inzamam.iit.delhi@gmail.com"]



email_query = '''
WITH mytable AS(
 SELECT opt_id,opt_email,opt_name,error_category,error_count,error_eid,notif_channel,notif_type,error_code,error_description,ea_code,ea_name,reg_code,reg_name
 FROM strot.operator360.operator_error_notif 
 WHERE DATE(last_updated_at)=CURRENT_DATE and notif_sent=True and opt_email is not null
),
tab1 as (
                select upper(operator_id) as operator_id, state,district, pincode, last_updated_date from flink_stream.stream_enu.enu_operator_sync_raw
                union all
                select upper(operator_id) as operator_id, state,district, pincode, last_updated_date from mysql_uid_logs.uidlogs.operator_center_sync
),
tab2 as (
                select 
                    upper(operator_id) as operator_id,state,district, pincode,last_updated_date,
                    row_number() over (partition by upper(operator_id) order by last_updated_date desc) as rn 
                from tab1 where state is not null and state!=''
),
tab3 as(
select * from tab2 where rn=1
),
tab4 AS(
    select operator_id, 
    CASE
        WHEN s.state IN ('Karnataka','Kerala','Lakshadweep','Puducherry','Tamil Nadu') THEN 'Bengaluru'
        WHEN s.state IN ('Chandigarh','Haryana','Himachal Pradesh','Jammu and Kashmir','Ladakh','Punjab') THEN 'Chandigarh'
        WHEN s.state IN ('Delhi','Madhya Pradesh','Rajasthan','Uttarakhand') THEN 'Delhi'
        WHEN s.state IN ('Arunachal Pradesh','Assam','Manipur','Meghalaya','Mizoram','Nagaland','Sikkim','Tripura') THEN 'Guwahati'
        WHEN s.state IN ('Andaman and Nicobar Islands','Andhra Pradesh','Chhattisgarh','Odisha','Telangana') THEN 'Hyderabad'
        WHEN s.state IN ('Uttar Pradesh') THEN 'Lucknow'
        WHEN s.state IN ('Goa','Gujarat','Maharashtra','Dadra and Nagar Haveli','Dadra and Nagar Haveli and Daman and Diu','Daman and Diu') THEN 'Mumbai'
        WHEN s.state IN ('Bihar','Jharkhand','West Bengal') THEN 'Ranchi'
        ELSE 'unknown'
    END AS opt_ro
    FROM tab3 s                     
)
SELECT t.*, s.opt_ro
FROM mytable t JOIN tab4 s ON (UPPER(t.opt_id)=UPPER(s.operator_id))
'''

def trino(query, host=trino_host, port=trino_port, user=trino_user):
    try:
        conn = connect(
            host=host,
            port=port,
            user=user
        )
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"query": query, "success": 1, "data": body, "df": None}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}

def trigger_email(query, email_list, dag_id, **kwargs):
    today_date1 = datetime.datetime.now().strftime("%d_%B_%Y")
    today_date = datetime.datetime.now().strftime("%d %B %Y")
    file_name = f"opt_error_notif_sent_Report_{today_date1}.csv"
    
    # Set file_path as tmp/{dag_id}/file_name
    dir_path = f"tmp/{dag_id}"
    file_path = f"{dir_path}/{file_name}"
    
    html_content1 = f"<p>Please Find Attached the CSV File Regarding Operator QC Error Notification Sent Today.</p>"
    html_content2 = f"<p>There are No Mails Sent to any Operator Today.</p>"

    query_result = trino(query)
    files_to_attach = []
    
    if query_result["success"] == 1 and query_result['df'] is not None and not query_result['df'].empty:
        df = query_result['df']
        print(f"Data fetched successfully. Shape: {df.shape}")
        
        # Create directory if it doesn't exist and save the file locally
        os.makedirs(dir_path, exist_ok=True)
        df.to_csv(file_path, index=False)
        print(f"CSV file saved to: {file_path}")
        
        html_content = html_content1
        files_to_attach = [file_path]
        print("Data query successful")
        
    elif query_result["success"] == 1 and (query_result['df'] is None or query_result['df'].empty):
        print("No Rows Returned by the Query!")
        html_content = html_content2
    else:
        error_msg = query_result.get("msg", "Unknown Trino failure")
        print("Trino query might have failed! Error:", error_msg)
        raise RuntimeError(f"Trino query failed: {error_msg}")

    emailSubject = f"Operator QC Error Notification Report {today_date}"
    
    # Push variables to XCom so EmailOperator can access them at runtime
    ti = kwargs['ti']
    ti.xcom_push(key='subject', value=emailSubject)
    ti.xcom_push(key='html_content', value=html_content)
    ti.xcom_push(key='files', value=files_to_attach)
    ti.xcom_push(key='file_path', value=file_path)


def remove_file(**kwargs):
    ti = kwargs['ti']
    file_path = ti.xcom_pull(task_ids='error_notif_sent_mail_csv', key='file_path')
    
    if file_path and os.path.exists(file_path):
        os.remove(file_path)
        print(f"Successfully removed file: {file_path}")
    else:
        print("No file to remove or file path is empty.")


default_args = {
    'owner': 'inzamam',
    'depends_on_past': False,
    'start_date': datetime.datetime(2025,9,17),
    'email': ["techexe15.yp25@uidai.net.in","techexecutive22-yp23@uidai.net.in","techexecutive14-yp23@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 1
}

dag= DAG(
    'opt_error_notif_sent_report',
    default_args=default_args,
    description="Dag to send emails to the team regarding opt error notif mail with report in csv",
    schedule="30 9 * * *",
    tags=["Reporting","QC"],
    catchup=False,
    render_template_as_native_obj=True
)

opt_error_notif_mail_report = PythonOperator(
    task_id='error_notif_sent_mail_csv',
    python_callable=trigger_email,
    op_kwargs={'query': email_query, 'email_list': mail_list, 'dag_id': 'opt_error_notif_sent_report'},
    dag=dag,
)

send_email_task = EmailOperator(
    task_id='email_sending_task',
    to=mail_list,
    cc=cc,
    subject="{{ ti.xcom_pull(task_ids='error_notif_sent_mail_csv', key='subject') }}",
    html_content="{{ ti.xcom_pull(task_ids='error_notif_sent_mail_csv', key='html_content') }}",
    files="{{ ti.xcom_pull(task_ids='error_notif_sent_mail_csv', key='files') }}",
    conn_id='smtp_default',
    from_email='strot@uidai.net.in',
    dag=dag
)

remove_file_task = PythonOperator(
    task_id='remove_file_task',
    python_callable=remove_file,
    dag=dag
)

# Define Task Flow
opt_error_notif_mail_report >> send_email_task >> remove_file_task