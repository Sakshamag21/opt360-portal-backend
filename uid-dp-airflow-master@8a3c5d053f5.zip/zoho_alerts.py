import requests
import json
import urllib3

# Disable SSL warnings for corporate proxy
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Global configurations
ZOHO_WEBHOOK_URL = "https://chat.uidai.gov.in/api/v2/bots/alertbotdataplatform/incoming?zapikey=1001.5bb881fd0a1f46033f6aeb99efbf9637.824c7b61b06a0b931fbb8df065141209&channel=dataplatformalerts&dc=hdc"
PROXY_URL = "http://10.10.16.28:3128"
PROXIES = {
    "http": PROXY_URL,
    "https": PROXY_URL
}

def send_zoho_alert(context, status):
    """Generic function to send alerts to Zoho Cliq via proxy."""
    ti = context.get('task_instance')
    
    exception = context.get('exception')
    error_message = str(exception) if exception else "No errors. Task completed successfully."
    
    # Truncate error message if it's too long
    if len(error_message) > 1000:
        error_message = error_message[:1000] + "... [truncated]"

    # Strict payload structure
    message_payload = {
        "dag_id": ti.dag_id,
        "task_id": ti.task_id,
        "run_id": context.get('run_id'),
        "execution_date": context.get('ts'),
        "status": status,
        "error_message": error_message,
        "log_url": ti.log_url
    }

    print(f"Sending {status} alert to Zoho Cliq via proxy...")
    try:
        response = requests.post(
            ZOHO_WEBHOOK_URL,
            headers={"Content-Type": "application/json"},
            data=json.dumps(message_payload),
            proxies=PROXIES,
            verify=False  # Bypasses SSL verification for corp proxy
        )
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        
        if response.status_code == 200:
            print("✅ Success! Alert sent to Zoho Cliq channel.")
        else:
            print("❌ Something went wrong sending the alert.")
            
    except Exception as e:
        print(f"❌ An error occurred while sending Zoho alert: {e}")


def zoho_failure_callback(context):
    send_zoho_alert(context, status="failed")