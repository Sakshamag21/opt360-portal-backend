import datetime
import pendulum
import pandas as pd
import smtplib
from trino.dbapi import connect
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from airflow import DAG
from airflow.operators.python import PythonOperator

# --- Settings ---
TRINO_HOST = "10.10.118.35"
TRINO_PORT = 8080
TRINO_USER = "airflow_dag_op"

SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25
SENDER_EMAIL = "airflow@uidai.net.in"

# UPDATE THIS LIST with the actual recipient emails
RECIPIENT_EMAILS = ["data.analyst-tc@uidai.net.in", "hoe.dev-tc@uidai.net.in", "srconstds.prod-tc@uidai.net.in", "devfsd17-tc@uidai.net.in", "platfm.arch1-tc@uidai.net.in", "software.dev3-tc@uidai.net.in", "techexecutive22-yp23@uidai.net.in"]

# --- SQL Query ---
SQL_QUERY = """
WITH step1_sids AS (
    SELECT DISTINCT resident_sid
    FROM flink_stream.stream_enu.Enu_Uc_Opt_Action_V2
    WHERE event_timestamp >= CURRENT_DATE - INTERVAL '1' DAY
      AND event_timestamp < CURRENT_DATE
      AND resident_sid IS NOT NULL
      AND resident_sid <> ''
),
step2_uids AS (
    SELECT DISTINCT
        t1.uid, t1.eid AS sid, t1.ea_code, t1.registrar_code,
        t1.operator_id, t1.source_client_id, t1.source_client_machine_id
    FROM strot.mysql_uid_v2.uid_origin_tracker t1
    WHERE t1.enr_date >= CURRENT_DATE - INTERVAL '1' DAY
      AND t1.enr_date < CURRENT_DATE
      AND t1.eid IN (SELECT resident_sid FROM step1_sids)
      AND t1.uid IS NOT NULL AND t1.uid <> ''
),
step3_refids AS (
    SELECT DISTINCT
        t1.refid, m.sid, m.uid, m.ea_code, m.registrar_code,
        m.operator_id, m.source_client_id, m.source_client_machine_id
    FROM strot.mysql_uid_v2.uid_origin_tracker t1
    INNER JOIN step2_uids m ON t1.uid = m.uid
    WHERE t1.refid IS NOT NULL AND t1.refid <> ''
)
SELECT
    s3.sid AS sid, s3.uid AS uid, s3.ea_code AS ea_code,
    s3.registrar_code AS registrar_code, s3.operator_id AS operator_id,
    s3.source_client_id AS station_id, s3.source_client_machine_id AS source_client_machine_id,
    t3.aua AS aua_code, t3.enrolmentreferenceid AS reference_id,
    t3.residentgender AS gender, t3.authtype AS authtype, 
    t3.authcode AS authcode, t3.txn AS txn
FROM flink_stream.stream_auth.Auth_Txn_Raw_Union_V1 t3
INNER JOIN step3_refids s3 ON t3.enrolmentreferenceid = s3.refid
WHERE t3.event_timestamp >= CURRENT_DATE - INTERVAL '1' DAY  
  AND t3.event_timestamp < CURRENT_DATE                      
  AND (t3.authtype LIKE '%F%' OR t3.authtype LIKE '%I%')
  AND t3.suberrorcode = '300-3'
  AND t3.authresult = 'n'
  AND t3.aua = '0002980000'
"""

def fetch_and_process_data():
    print("Connecting to Trino and executing query...")
    conn = connect(host=TRINO_HOST, port=TRINO_PORT, user=TRINO_USER, catalog=None, schema=None)
    cur = conn.cursor()
    cur.execute(SQL_QUERY)
    body = cur.fetchall()
    cols = [i[0] for i in cur.description]
    df = pd.DataFrame(body, columns=cols)
    conn.close()

    if df.empty:
        print("No data returned from Trino.")
        return None, 0, 0, 0, 0, "", 0, 0

    print("Processing data in Pandas...")
    df_grouped = df.groupby([
        'sid', 'uid', 'ea_code', 'registrar_code', 'operator_id',
        'station_id', 'source_client_machine_id', 'aua_code',
        'reference_id', 'gender', 'authtype'
    ], dropna=False).agg(
        error_code_count=('txn', 'count'),
        txn_list=('txn', list),
        authcode_list=('authcode', list)
    ).reset_index()

    df_grouped = df_grouped.sort_values(by='error_code_count', ascending=False)
    df_final = df_grouped

    # Calculate Unique Counts for Email
    total_uid = df_final['uid'].nunique()
    total_sid = df_final['sid'].nunique()
    total_station_id = df_final['station_id'].nunique()                 # <-- Added station_id count
    total_machine_code = df_final['source_client_machine_id'].nunique() # <-- Added machine_code count
    
    df_gt_5 = df_final[df_final['error_code_count'] > 5]
    total_uid_gt_5 = df_gt_5['uid'].nunique()
    total_sid_gt_5 = df_gt_5['sid'].nunique()

    ist_tz = pendulum.timezone("Asia/Kolkata")
    yesterday_date_obj = datetime.datetime.now(ist_tz) - datetime.timedelta(days=1)
    yesterday_str = yesterday_date_obj.strftime('%d_%b_%Y')
    yesterday_email_str = yesterday_date_obj.strftime('%d/%m/%Y')
    
    # Airflow workers usually write temporary files to /tmp/
    csv_filename = f"/tmp/auth_error_report_with_UID_and_AUA_{yesterday_str}.csv"
    df_final.to_csv(csv_filename, index=False)
    print(f"✅ Data saved to {csv_filename}")

    # Returning all variables to pass to the email task
    return csv_filename, total_uid, total_sid, total_uid_gt_5, total_sid_gt_5, yesterday_email_str, total_station_id, total_machine_code

def send_email_task(**kwargs):
    # Pulling all variables passed from the previous task
    csv_filename, total_uid, total_sid, total_uid_gt_5, total_sid_gt_5, yesterday_email_str, total_station_id, total_machine_code = kwargs['ti'].xcom_pull(task_ids='fetch_data_task')

    if not csv_filename:
        print("No CSV file generated. Skipping email.")
        return

    msg = MIMEMultipart()
    msg['From'] = SENDER_EMAIL
    msg['To'] = ", ".join(RECIPIENT_EMAILS)
    msg['Subject'] = f"Non-live auth (F & I) report of resident_error_code-300-3- {datetime.datetime.now().strftime('%Y-%m-%d')}"

    # Construct the email body with the new unique counts added
    body = f"""
Please find the attached sheet which has SID, UID, ea_code, registrar_code, source_client_machine_id , Aua-code, Refid, Gender, Auth type, error_code_count(300-3), Txn_list, authcode_list

Resident Auth Liveness Failure Attempts identified in UC on date {yesterday_email_str}

Residents(ANH) attempting non-live auth (F & I) : {total_uid}
Transactions with non-live auth for resident (F & I) :  {total_sid}

ANH with >5  non-live auth (F & I)  attempts : {total_uid_gt_5}

Unique Count of Station ID: {total_station_id}
Unique Count of Machine Code: {total_machine_code}
 
Comprehensive transactional data sheet is attached

Regards,
Data Platform Team
"""
    msg.attach(MIMEText(body, 'plain'))

    with open(csv_filename, "rb") as attachment:
        part = MIMEApplication(attachment.read(), Name=csv_filename.split("/")[-1])
    part['Content-Disposition'] = f'attachment; filename="{csv_filename.split("/")[-1]}"'
    msg.attach(part)

    try:
        print("Sending email...")
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT)
        server.sendmail(SENDER_EMAIL, RECIPIENT_EMAILS, msg.as_string())
        server.quit()
        print("✅ Email sent successfully!")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")
        raise

# ==========================================
# DAG DEFINITION
# ==========================================
ist_tz = pendulum.timezone("Asia/Kolkata")

default_args = {
    'owner': 'Amit Kumar',
    'depends_on_past': False,
    'start_date': datetime.datetime(2026, 9, 10, tzinfo=ist_tz),
    'email': ['data.analyst-tc@uidai.net.in'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': datetime.timedelta(minutes=5)
}

dag = DAG(
    'resident_auth_error_300-3_daily',
    default_args=default_args,
    description='Fetches resident auth errors for 300-3 and emails the report daily',
    schedule='0 10 * * *',  # Runs daily at 10:00 AM IST
    catchup=False
)

fetch_data_task = PythonOperator(
    task_id='fetch_data_task',
    python_callable=fetch_and_process_data,
    dag=dag,
)

send_email_task = PythonOperator(
    task_id='send_email_task',
    python_callable=send_email_task,
    dag=dag,
)

fetch_data_task >> send_email_task