import datetime
import smtplib
import csv
from io import StringIO, BytesIO
import zipfile
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

import boto3
import pandas as pd
import pendulum
from trino.dbapi import connect
from airflow import DAG
from airflow.operators.python import PythonOperator

# ==========================================
# CONFIGURATION DETAILS
# ==========================================

# Trino Configuration
trino_host = "10.10.116.75"
trino_catalog_iceberg = 'strot'  
trino_port = 8080
trino_user = "airflow_dag_op"

# 📧 SMTP Configuration
SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25                      

# ☁️ Local S3 Configuration
S3_ENDPOINT_URL = "http://10.10.103.12:425"  
S3_ACCESS_KEY = "9S0KLIQO7T2XCNGH4P4A"         
S3_SECRET_KEY = "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4"         
S3_BUCKET = "prd-bi-data-platform-test"            
S3_PREFIX = "temp"                        
S3_REGION = "us-east-1"                   

# 📨 Email Recipients
mail_list = ["srconstds.prod-tc@uidai.net.in"]

# All previous BCC recipients are now in CC
cc_list = ["data.analyst-tc@uidai.net.in", 
    "techexecutive22-yp23@uidai.net.in", 
    "productmgr4-tc@uidai.net.in",
    "dir.eu-hq@uidai.net.in",
    "dd.eu1-hq@uidai.net.in",
    "pm1.eu1-hq@uidai.net.in",
    "hoe.dev-tc@uidai.net.in",
    "Dd3.romumbai@uidai.net.in",
    "So5-romum@uidai.net.in",
    "Am1.romumbai@uidai.net.in",
    "Am3.romumbai@uidai.net.in",
    "reconcell.romumbai@uidai.net.in",
    "vivek.chand@csc.gov.in",
    "pmu1.eu1-hq@uidai.net.in",
    "alladgro@uidai.net.in",
    "allddro.uidai@uidai.net.in",
    "haridas.bhavani@uidai.net.in",
    "askhyd-rohyd@uidai.net.in",
    "dir3-rornc@uidai.net.in",
    "amka4-roblr@uidai.net.in",
    "amka1-roblr@uidai.net.in",
    "amtech.rodelhi@uidai.net.in",
    "amuk1.rodelhi@uidai.net.in",
    "pmdel.rodelhi@uidai.net.in",
    "amrajjaipur.rodelhi@uidai.net.in",
    "pmuk-rodelhi@uidai.net.in",
    "pm3-rohyd@uidai.net.in",
    "Itsupport.scl-sca@uidai.net.in",
    "allddgro@uidai.net.in",
    "shailendra.singh@uidai.net.in",
    "pm1-rolko@uidai.net.in",
    "dir1-rochd@uidai.net.in",
    "pm-rochd@uidai.net.in",
    "dir-mp.rodelhi@uidai.net.in",
    "ampb3-rochd@uidai.net.in",
    "amjk1-rochd@uidai.net.in",
    "pm.jk-rochd@uidai.net.in",
    "dd1-rochd@uidai.net.in"
]

bcc_list = [] # BCC is now empty!

# ==========================================
# QUERY TEMPLATE
# ==========================================
email_query_template = '''
SELECT
  "stream_enu"."enu_uc_opt_action_v2"."station_id"      AS "Station_ID",
  "stream_enu"."enu_uc_opt_action_v2"."operator_id"    AS "Operator_ID",
  "stream_enu"."enu_uc_opt_action_v2"."resident_sid"   AS "Resident_SID",
  "stream_enu"."enu_uc_opt_action_v2"."enrolment_type"  AS "enrolment_type",
  "stream_enu"."enu_uc_opt_action_v2"."stage"           AS "Stage",
  "stream_enu"."enu_uc_opt_action_v2"."stage_status"    AS "Stage_Status",
  "stream_enu"."enu_uc_opt_action_v2"."event_timestamp" AS "Event_timestamp",
  "stream_enu"."enu_uc_opt_action_v2"."ea"              AS "EA",
  "stream_enu"."enu_uc_opt_action_v2"."registrar"       AS "Registrar",
  "stream_enu"."enu_uc_opt_action_v2"."state"           AS "State",
  "stream_enu"."enu_uc_opt_action_v2"."ro"              AS "RO"
FROM
  "stream_enu"."enu_uc_opt_action_v2"
WHERE
  "stream_enu"."enu_uc_opt_action_v2"."stage" = 'AckSlipUpload'
  AND date("stream_enu"."enu_uc_opt_action_v2"."event_timestamp") = {date_expr}
LIMIT
  1048575
'''

# ==========================================
# DAG DEFINITIONS
# ==========================================
ist_tz = pendulum.timezone("Asia/Kolkata")

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2025, 6, 8, tzinfo=ist_tz),
    'email': ["data.analyst-tc@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': datetime.timedelta(minutes=2)
}

dag_8pm = DAG(
    'uc_report_daily_mail_8PM', 
    default_args=default_args,
    description='8PM DAG - RO wise CSVs bundled in ZIP + Local S3 backup',
    schedule="0 20 * * *",      # Runs at 8:00 PM IST
    catchup=False
)

dag_12am = DAG(
    'uc_report_daily_mail_12AM', 
    default_args=default_args,
    description='12AM DAG - Previous Day Complete RO wise CSVs in ZIP',
    schedule="0 0 * * *",       # Runs at 12:00 AM IST
    catchup=False
)

# ==========================================
# HELPER FUNCTIONS
# ==========================================

def trino_fetch(query, catalog='flink_stream', schema='stream_enu', host=trino_host, port=trino_port, user=trino_user):
    try:
        conn = connect(host=host, port=port, user=user, catalog=catalog)
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"success": 1, "df": pd.DataFrame()}
        cols = [i[0] for i in cur.description]
        df = pd.DataFrame(body, columns=cols)
        return {"success": 1, "df": df}
    except Exception as e:
        return {"success": 0, "msg": str(e)}

def send_email_via_smtp(to_email, cc_emails, bcc_emails, zip_bytes, zip_filename, full_date_str, time_label):
    sender_email = "airflow@uidai.net.in"
    
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = to_email

    if cc_emails:
        msg['Cc'] = ", ".join(cc_emails)
    
    msg['Subject'] = f"UC Consolidated EOD report for {full_date_str} ({time_label})"
    
    html_body = f"""
    <html>
        <body style="font-family: Arial, sans-serif; color: #333333; line-height: 1.6;">
            <p>Dear All,</p>
            <p>Please find attached UC Consolidated EOD report for {full_date_str} ({time_label}).</p>
            <p><b>note:</b>Zip contain RO wise csv file.</p>
            <br>
            <p>Regards,<br>
            Data Platform Team</p>
            <br>
            <p style="font-size: 11px; color: #888888; font-style: italic;">
                <b>Disclaimer:</b> Due to email size limitations, this report is sent in multiple parts. Please ensure you download all parts to access the complete set of RO-wise CSV files.
            </p>
        </body>
    </html>
    """
    msg.attach(MIMEText(html_body, 'html'))
    
    part = MIMEApplication(zip_bytes, Name=zip_filename)
    part['Content-Disposition'] = f'attachment; filename="{zip_filename}"'
    msg.attach(part)
    
    recipients = [to_email]
    if cc_emails:
        recipients.extend(cc_emails)
    if bcc_emails:
        recipients.extend(bcc_emails)
        
    raw_zip_size = len(zip_bytes)
    total_email_size = 0
    
    try:
        email_payload = msg.as_string()
        total_email_size = len(email_payload.encode('utf-8'))
        
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(sender_email, recipients, email_payload)
        server.quit()
        return True
        
    except Exception as e:
        print(f"❌ SMTP Error: {str(e)}")
        print(f"Failed to transmit email to: {to_email}")
        
        print("====== SIZE DIAGNOSTICS ======")
        print(f"Raw ZIP Attachment Size : {raw_zip_size} bytes ({raw_zip_size / (1024 * 1024):.2f} MB)")
        print(f"Total Email Payload Size: {total_email_size} bytes ({total_email_size / (1024 * 1024):.2f} MB)")
        print(f"Number of Recipients    : {len(recipients)} (To: 1, CC: {len(cc_emails)}, BCC: {len(bcc_emails)})")
        print("==============================")
        
        return False

def upload_zip_to_s3(zip_bytes, s3_key):
    s3_client = boto3.client(
        "s3",
        endpoint_url=S3_ENDPOINT_URL,
        aws_access_key_id=S3_ACCESS_KEY,
        aws_secret_access_key=S3_SECRET_KEY,
    )
    s3_client.put_object(Bucket=S3_BUCKET, Key=s3_key, Body=zip_bytes)

# ==========================================
# MAIN PROCESSING FUNCTION (DYNAMIC BATCHING)
# ==========================================

def process_split_save_and_trigger(query_template, email_list, run_mode, **kwargs):
    current_time_ist = datetime.datetime.now(ist_tz)
    
    if run_mode == '12AM':
        report_time = current_time_ist - datetime.timedelta(days=1)
        time_label = "12AM - EOD Complete"
        date_expr = "date(now() - interval '1' day)"
        mode_suffix = "_EOD"
    else:
        report_time = current_time_ist
        time_label = "8PM"
        date_expr = "date(now())"
        mode_suffix = ""
        
    query = query_template.format(date_expr=date_expr)
    
    report_date_str = report_time.strftime("%d-%m-%y")
    
    day = report_time.day
    suffix = 'th' if 11 <= day <= 13 else {1: 'st', 2: 'nd', 3: 'rd'}.get(day % 10, 'th')
    full_date_str = f"{day}{suffix} {report_time.strftime('%B %Y')}"
    
    print(f"Initiating Trino extraction for date logic: {date_expr}")
    result = trino_fetch(query)
    
    if result["success"] == 0:
        print(f"Extraction halted due to query error: {result.get('msg')}")
        raise RuntimeError(f"Trino extraction failed: {result.get('msg')}")

    df = result["df"]
    if df.empty:
        print("No matching data records found for the execution date.")
        return

    print(f"Extracted data profile dimensions: {df.shape}")

    print("Grouping data by Regional Office (RO)...")
    df['RO'] = df['RO'].fillna('Others')
    grouped_by_ro = df.groupby('RO')
    
    # Convert grouped data into a list of tuples (ro_name, ro_df)
    ro_data_list = list(grouped_by_ro)
    
    # DYNAMIC BATCHING: Group ROs based on row count to keep email size under 10MB
    # Roughly 30,000 rows = 1 MB of email payload. We set a safe limit of 200,000 rows per Part.
    MAX_ROWS_PER_PART = 200000
    batches = []
    current_batch = []
    current_rows = 0
    
    # Sort ROs by row count descending so large ROs don't get grouped together at the end
    ro_data_list_sorted = sorted(ro_data_list, key=lambda x: len(x[1]), reverse=True)
    
    for ro_name, ro_df in ro_data_list_sorted:
        # If adding this RO exceeds our limit, start a new batch
        if current_rows + len(ro_df) > MAX_ROWS_PER_PART and current_batch:
            batches.append(current_batch)
            current_batch = []
            current_rows = 0
            
        current_batch.append((ro_name, ro_df))
        current_rows += len(ro_df)
        
    # Append the final batch
    if current_batch:
        batches.append(current_batch)
        
    print(f"Data split into {len(batches)} parts to comply with email size limits.")
    
    failed_emails = []
    
    # Loop through each batch, create a ZIP, and send an email
    for batch_idx, batch in enumerate(batches):
        part_num = batch_idx + 1
        total_parts = len(batches)
        
        zip_file_name = f"enrolment_report_RO_wise_{report_date_str}{mode_suffix}_Part{part_num}.zip"
        s3_key = f"{S3_PREFIX}/{zip_file_name}"
        
        zip_buffer = BytesIO()
        
        # Create the ZIP for this specific part
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as daily_zip:
            for ro_name, ro_df in batch:
                safe_ro_name = str(ro_name).replace(" ", "_").replace("/", "_")
                file_name = f"enrolment_report_{report_date_str}_{safe_ro_name}{mode_suffix}.csv"
                
                csv_buffer = StringIO()
                ro_df.to_csv(csv_buffer, index=False, quoting=csv.QUOTE_MINIMAL)
                csv_content = csv_buffer.getvalue()
                
                daily_zip.writestr(file_name, csv_content)
                print(f"Added {file_name} to ZIP Part {part_num} (Rows: {len(ro_df)})")
        
        zip_buffer.seek(0)
        zip_bytes = zip_buffer.read()
        
        try:
            upload_zip_to_s3(zip_bytes, s3_key)
            print(f"✅ ZIP Part {part_num} uploaded to S3 at {s3_key}")
        except Exception as s3_err:
            print(f"❌ Failed to upload ZIP Part {part_num} to Local S3: {str(s3_err)}")

        print(f"Dispatching email {part_num} of {total_parts} via SMTP...")
        
        # Send email for this part
        for target_email in email_list:
            try:
                success = send_email_via_smtp(
                    target_email, cc_list, bcc_list, zip_bytes, zip_file_name, 
                    full_date_str, f"{time_label} - Part {part_num} of {total_parts}"
                )
                if success:
                    print(f"Successfully transmitted Part {part_num} to: {target_email}")
                else:
                    print(f"Failed to transmit Part {part_num} to {target_email}.")
                    failed_emails.append(target_email)
            except Exception as mail_error:
                print(f"Network error routing Part {part_num} to {target_email}: {str(mail_error)}")
                failed_emails.append(target_email)

    if failed_emails:
        failure_list = ", ".join(failed_emails)
        raise RuntimeError(f"DAG FAILED. Could not send email to the following recipient(s): {failure_list}")
    else:
        print("✅ All emails and parts were transmitted successfully.")

# ==========================================
# TASK DEFINITIONS
# ==========================================

task_8pm = PythonOperator(
    task_id='uc_report_8PM_task',
    python_callable=process_split_save_and_trigger,
    op_kwargs={
        'query_template': email_query_template, 
        'email_list': mail_list, 
        'run_mode': '8PM'
    },
    dag=dag_8pm,
)

task_12am = PythonOperator(
    task_id='uc_report_12AM_task',
    python_callable=process_split_save_and_trigger,
    op_kwargs={
        'query_template': email_query_template, 
        'email_list': mail_list, 
        'run_mode': '12AM'
    },
    dag=dag_12am,
)

task_8pm
task_12am