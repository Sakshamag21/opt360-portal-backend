import base64
import datetime
import json
import os
import smtplib
from io import StringIO, BytesIO
import zipfile
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

import boto3
import pandas as pd
from trino.dbapi import connect
from airflow import DAG
from airflow.operators.python import PythonOperator

# ==========================================
# CONFIGURATION DETAILS
# ==========================================

# Trino Configuration
trino_host = "10.10.116.75"
trino_catalog_iceberg = 'strot'  
trino_port = 8080
trino_user = "airflow_dag_op"

# 📧 SMTP Configuration
SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25                      

# ☁️ Local S3 Configuration
S3_ENDPOINT_URL = "http://10.10.103.12:425"  
S3_ACCESS_KEY = "9S0KLIQO7T2XCNGH4P4A"         
S3_SECRET_KEY = "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4"         
S3_BUCKET = "prd-bi-data-platform-test"            
S3_PREFIX = "temp"                        
S3_REGION = "us-east-1"                   

# 📨 Email Recipients
mail_list = ["data.analyst-tc@uidai.net.in"]
cc = "" 

# ==========================================
# DAG DEFINITION
# ==========================================

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2025, 6, 8),
    'email': ["data.analyst-tc@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': datetime.timedelta(minutes=2)
}

dag = DAG(
    'uc_report_daily_mail_TESTING', 
    default_args=default_args,
    description='TESTING DAG - email attachments + Local S3 /temp zip archive',
    schedule="30 12 * * *",  # Runs daily at 12:30 PM
    catchup=False
)

email_query = '''
SELECT
  "stream_enu"."enu_uc_opt_action_v2"."station_id"      AS "Station_ID",
  "stream_enu"."enu_uc_opt_action_v2"."operator_id"    AS "Operator_ID",
  "stream_enu"."enu_uc_opt_action_v2"."resident_sid"   AS "Resident_SID",
  "stream_enu"."enu_uc_opt_action_v2"."enrolment_type"  AS "enrolment_type",
  "stream_enu"."enu_uc_opt_action_v2"."stage"           AS "Stage",
  "stream_enu"."enu_uc_opt_action_v2"."stage_status"    AS "Stage_Status",
  "stream_enu"."enu_uc_opt_action_v2"."event_timestamp" AS "Event_timestamp",
  "stream_enu"."enu_uc_opt_action_v2"."ea"              AS "EA",
  "stream_enu"."enu_uc_opt_action_v2"."registrar"       AS "Registrar",
  "stream_enu"."enu_uc_opt_action_v2"."state"           AS "State",
  "stream_enu"."enu_uc_opt_action_v2"."ro"              AS "RO"
FROM
  "stream_enu"."enu_uc_opt_action_v2"
WHERE
  "stream_enu"."enu_uc_opt_action_v2"."stage" = 'AckSlipUpload'
  AND date("stream_enu"."enu_uc_opt_action_v2"."event_timestamp") = date(now())
LIMIT
  1048575
'''

# ==========================================
# HELPER FUNCTIONS
# ==========================================

def trino_fetch(query, catalog='flink_stream', schema='stream_enu', host=trino_host, port=trino_port, user=trino_user):
    try:
        conn = connect(host=host, port=port, user=user,catalog=catalog)
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"success": 1, "df": pd.DataFrame()}
        cols = [i[0] for i in cur.description]
        df = pd.DataFrame(body, columns=cols)
        return {"success": 1, "df": df}
    except Exception as e:
        return {"success": 0, "msg": str(e)}

def send_email_via_smtp(to_email, cc_email, zip_bytes, zip_filename, today_date):
    """Constructs and sends an email with the ZIP attachment via SMTP."""
    
    sender_email = "airflow@uidai.net.in"
    
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = to_email
    if cc_email:
        msg['Cc'] = cc_email
    
    msg['Subject'] = f"UC Report Daily Mail - {today_date}"
    
    # HTML Body (Only mentioning the attachment, no S3 link)
    html_body = f"""
    <html>
        <body>
            <p>Hi,</p>
            <p>Please find attached the UC daily enrolment report for <b>{today_date}</b>.</p>
            <p>The report contains the extracted data split into CSV files, compressed into a single ZIP archive.</p>
            <br>
            <p>Regards,<br>Airflow Automation</p>
        </body>
    </html>
    """
    msg.attach(MIMEText(html_body, 'html'))
    
    # Attach the ZIP file using raw bytes
    part = MIMEApplication(zip_bytes, Name=zip_filename)
    part['Content-Disposition'] = f'attachment; filename="{zip_filename}"'
    msg.attach(part)
    
    # Send the email
    recipients = [to_email]
    if cc_email:
        recipients.append(cc_email)
        
    try:
        # Connect to SMTP server (Port 25 does not use SSL or TLS)
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(sender_email, recipients, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"SMTP Error: {str(e)}")
        return False

def upload_zip_to_s3(zip_bytes, s3_key):
    """Uploads raw zip bytes to Local S3 using put_object."""
    s3_client = boto3.client(
        "s3",
        endpoint_url=S3_ENDPOINT_URL,
        aws_access_key_id=S3_ACCESS_KEY,
        aws_secret_access_key=S3_SECRET_KEY,
    )
    # Using put_object avoids stream closing issues
    s3_client.put_object(Bucket=S3_BUCKET, Key=s3_key, Body=zip_bytes)
    return f"{S3_ENDPOINT_URL}/{S3_BUCKET}/{s3_key}"

# ==========================================
# MAIN PROCESSING FUNCTION
# ==========================================

def process_split_save_and_trigger(query, email_list):
    now_time = datetime.datetime.now()
    today_str = now_time.strftime("%d_%B")
    
    zip_file_name = f"enrolment_report_{today_str}.zip"
    s3_key = f"{S3_PREFIX}/{zip_file_name}"
    
    print("Initiating Trino extraction...")
    result = trino_fetch(query)
    
    if result["success"] == 0:
        print(f"Extraction halted due to query error: {result.get('msg')}")
        return

    df = result["df"]
    if df.empty:
        print("No matching data records found for the execution date.")
        return

    total_rows = len(df)
    print(f"Extracted data profile dimensions: {df.shape}")

    chunk_size = 300000 
    
    print(f"Building in-memory zip container for S3 key: {s3_key}")
    zip_buffer = BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as daily_zip:
        
        for i in range(0, total_rows, chunk_size):
            chunk_df = df.iloc[i : i + chunk_size]
            part_number = (i // chunk_size) + 1
            total_parts = (total_rows // chunk_size) + (1 if total_rows % chunk_size != 0 else 0)
            
            dynamic_file_name = f"enrolment_and_update_details_{today_str}_part{part_number}_of_{total_parts}.csv"
            
            csv_buffer = StringIO()
            chunk_df.to_csv(csv_buffer, index=False)
            csv_content = csv_buffer.getvalue()
            
            # Pack CSV component inside the in-memory zip archive
            daily_zip.writestr(dynamic_file_name, csv_content)
            print(f"Packed chunk component '{dynamic_file_name}' inside zip container.")
    
    # ⭐ FIX: Read the zip buffer into pure bytes BEFORE uploading to S3
    # This prevents the "I/O operation on closed file" error when emailing later
    zip_buffer.seek(0)
    zip_bytes = zip_buffer.read()
    
    # Upload the assembled zip to Local S3 (kept as a backup archive)
    try:
        s3_uri = upload_zip_to_s3(zip_bytes, s3_key)
        print(f"✅ Zip archive successfully uploaded to Local S3: {s3_uri}")
    except Exception as s3_err:
        print(f"❌ Failed to upload zip to Local S3: {str(s3_err)}")

    # Dispatch email via SMTP with the ZIP file attached
    print(f"Dispatching email via SMTP with ZIP attachment to recipients...")
    for target_email in email_list:
        try:
            success = send_email_via_smtp(target_email, cc, zip_bytes, zip_file_name, today_str)
            if success:
                print(f"Successfully transmitted report email to: {target_email}")
            else:
                print(f"Failed to transmit email to {target_email}.")
        except Exception as mail_error:
            print(f"Network error routing attachment email to {target_email}: {str(mail_error)}")

# ==========================================
# AIRFLOW TASK
# ==========================================

email_query_task = PythonOperator(
    task_id='uc_report_daily_mail_task',
    python_callable=process_split_save_and_trigger,
    op_kwargs={'query': email_query, 'email_list': mail_list},
    trigger_rule='all_done',
    dag=dag,
)

email_query_task