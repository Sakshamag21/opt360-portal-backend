import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import pendulum
from trino.dbapi import connect
from airflow import DAG
from airflow.operators.python import PythonOperator

# ==========================================
# CONFIGURATION DETAILS
# ==========================================

# Trino Configuration
TRINO_HOST = "10.10.118.35"
TRINO_PORT = 8080
TRINO_USER = "airflow_dag_op"

# 📧 SMTP Configuration
SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25
SENDER_EMAIL = "airflow@uidai.net.in"

# 📨 Email Recipients
mail_list = ["devfsd17-tc@uidai.net.in"]
cc_list = [
    "tech.executive15-tc@uidai.net.in",
    "techexecutive3-yp23@uidai.net.in",
    "tech.executive13-tc@uidai.net.in",
    "platfm.arch1-tc@uidai.net.in",
    "srconstds.prod-tc@uidai.net.in",
    "hoe.dev-tc@uidai.net.in",
    "software.dev3-tc@uidai.net.in",
    "techexecutive22-yp23@uidai.net.in",
    "software.dev5-tc@uidai.net.in",
    "data.analyst-tc@uidai.net.in"
]
bcc_list = [
    "data.analyst-tc@uidai.net.in"
]

# Build Configuration
BUILDS_TO_PROCESS = [
    {
        "name": "v215-3",
        "telemetry_ver": "3.3.4.2.215-3%",
        "seda_ver": "3.3.4.2/215-3"
    },
    {
        "name": "v217-2",
        "telemetry_ver": "3.3.4.2.217-2%",
        "seda_ver": "3.3.4.2/217-2"
    },
    {
        "name": "v218-2",
        "telemetry_ver": "3.3.4.2.218-2%",
        "seda_ver": "3.3.4.2/218-2"
    },
    {
        "name": "v218-6",
        "telemetry_ver": "3.3.4.2.218-6%",
        "seda_ver": "3.3.4.2/218-6"
    }
]

# ==========================================
# TRINO HELPER FUNCTIONS
# ==========================================
def trino_fetch(query, catalog='flink_stream'):
    """Executes a Trino query and returns a set of distinct values."""
    try:
        conn = connect(host=TRINO_HOST, port=TRINO_PORT, user=TRINO_USER, catalog=catalog)
        cur = conn.cursor()
        cur.execute(query)
        results = [row[0] for row in cur.fetchall()]
        return set(results)
    except Exception as e:
        print(f"❌ Trino Query Failed: {str(e)}")
        raise RuntimeError(f"Trino extraction failed: {str(e)}")

def trino_fetch_multi(query, catalog='flink_stream'):
    """Executes a Trino query and returns the raw rows."""
    try:
        conn = connect(host=TRINO_HOST, port=TRINO_PORT, user=TRINO_USER, catalog=catalog)
        cur = conn.cursor()
        cur.execute(query)
        return cur.fetchall()
    except Exception as e:
        print(f"❌ Trino Query Failed: {str(e)}")
        raise RuntimeError(f"Trino extraction failed: {str(e)}")

# ==========================================
# MAIN PROCESSING FUNCTION
# ==========================================
def generate_and_send_dpop_report(**kwargs):
    ist_tz = pendulum.timezone("Asia/Kolkata")
    current_time_ist = datetime.datetime.now(ist_tz)

    stats_as_of = current_time_ist.strftime("%d-%m-%Y %I:%M %p")
    print(f"🚀 Starting DPoP Stats extraction for multiple builds as of {stats_as_of}")

    # ==========================================
    # FETCH TPM AVAILABLE (REGISTERED) MACHINES GLOBALLY
    # ==========================================
    tpm_query = """
    SELECT DISTINCT machine_id
    FROM mysql_uidmasterv1.uidmasterv1_1.station_reg_helper
    WHERE ek_pub_hash IS NOT NULL
    AND machine_id IS NOT NULL
    AND machine_id != ''
    """
    print("Fetching TPM Available (Registered) machines...")
    set_tpm_avail = trino_fetch(tpm_query, catalog='mysql_uidmasterv1')
    print(f"✅ Fetched {len(set_tpm_avail)} machines with TPM available globally")


    html_rows = ""

    for build in BUILDS_TO_PROCESS:
        build_name = build["name"]
        tel_ver = build["telemetry_ver"]
        seda_ver = build["seda_ver"]

        print(f"\n--- Processing Build: {build_name} ---")

        # --- COMBINED QUERY 1 & 3: Telemetry Scan (Optimized to scan table only once) ---
        print("⏳ Fetching Q1 (Build Installed) and Q3 (DPoP Success) in a single query...")
        q13_query = f"""
        SELECT pdata_id, 
               MAX(CASE WHEN message IN (
                   'CORE_CONNECT HTTP call succeeded for endpoint: https://tathya.uidai.gov.in/access-uc/oauth/token',
                   'CORE_CONNECT HTTP call succeeded for endpoint: https://mdctathya.uidai.gov.in/access-uc/oauth/token'
               ) THEN 1 ELSE 0 END) as has_dpop
        FROM flink_stream.stream_enu.telemetry_uc
        WHERE ets >= current_timestamp - interval '30' day
        AND ets <= current_timestamp
        AND pdata_version LIKE '{tel_ver}'
        GROUP BY pdata_id
        """
        q13_rows = trino_fetch_multi(q13_query, catalog='flink_stream')
        
        # Split the single result into Q1 and Q3 sets
        set_q1 = set([row[0] for row in q13_rows])
        set_q3_raw = set([row[0] for row in q13_rows if row[1] == 1])
        
        c1 = len(set_q1)
        print(f"✅ Query 1 (Build Installed): {c1} machines")
        print(f"✅ Query 3 (Telemetry DPoP Success Raw): {len(set_q3_raw)} machines")

        # --- QUERY 2: Machines Doing UC Transactions (SEDA) ---
        q2_query = f"""
        SELECT DISTINCT machine_code
        FROM mysql_uc_uidprocessv2.uidprocessv2_2.request_tracker
        WHERE creation_date >= current_timestamp - interval '30' day
        AND creation_date <= current_timestamp
        AND client_version IN ('{seda_ver}')
        AND machine_code IS NOT NULL
        AND machine_code != ''
        """
        set_q2 = trino_fetch(q2_query, catalog='mysql_uc_uidprocessv2')
        c2 = len(set_q2)
        print(f"✅ Query 2 (UC Transactions): {c2} machines")

        # --- CALCULATIONS ---

        set_q3_final = set_q2.intersection(set_q3_raw)
        c3 = len(set_q3_final)
        print(f"✅ Query 3 Final (Matched with Q2): {c3} machines")

        pct_uc = round((c2 / c1) * 100, 2) if c1 > 0 else 0.0

        set_not_dpop = set_q2 - set_q3_final
        c7 = len(set_not_dpop)

        set_tpm_avail_not_dpop = set_not_dpop.intersection(set_tpm_avail)
        tpm_avail_not_dpop_count = len(set_tpm_avail_not_dpop)

        tpm_unavail_count = c7 - tpm_avail_not_dpop_count

        pct_dpop = round((c3 / c2) * 100, 2) if c2 > 0 else 0.0
        pct_tpm_unavail = round((tpm_unavail_count / c2) * 100, 2) if c2 > 0 else 0.0

        print(f"📊 Calculations complete for {build_name}. Generating HTML row...")

        # Append row to HTML table
        html_rows += f"""
            <tr>
                <td>{build_name}</td>
                <td>{stats_as_of}</td>
                <td>{c1}</td>
                <td>{c2}</td>
                <td>{pct_uc}%</td>
                <td>{c3}</td>
                <td>{c7}</td>
                <td>{tpm_unavail_count}</td>
                <td>{tpm_avail_not_dpop_count}</td>
                <td>{pct_dpop}%</td>
                <td>{pct_tpm_unavail}%</td>
            </tr>
        """

    # --- HTML TABLE GENERATION ---
    html_table = f"""
    <html>
        <body style="font-family: Arial, sans-serif; color: #333333; line-height: 1.6;">
            <p>Dear All,</p>
             <p>Please find the DPoP(Demonstrating Proof-of-Possession) stats report for builds <b>v215-3</b>, <b>v217-2</b>,  <b>v218-2</b>, and <b>v218-6</b> below. Data is pulled from the last 30 days.</p>
            
             <table border="1" style="border-collapse: collapse; text-align: center; width: 100%;">
                <tr style="background-color: #f2f2f2;">
                    <th>Build</th>
                    <th>Stats as of</th>
                    <th>Machines with Build Installed</th>
                    <th>Machines Doing UC Transactions (DPoP + Fallback)</th>
                    <th>% Machines using UC transactions</th>
                    <th>Machines with atleast 1 successful dpop request</th>
                    <th>Machines not doing DPoP transactions</th>
                    <th>TPM Unavailable / Not Registered</th>
                    <th>TPM Available Machines not doing DPoP Transactions</th>
                    <th>% Machines using DPoP</th>
                    <th>TPM Unavailable %</th>
                </tr>
                {html_rows}
            </table>
            <br>
            <p>Regards,<br>Data Platform Team</p>
        </body>
    </html>
    """

    # --- SEND EMAIL ---
    msg = MIMEMultipart()
    msg['From'] = SENDER_EMAIL
    msg['To'] = ", ".join(mail_list)
    msg['Cc'] = ", ".join(cc_list)
    msg['Subject'] = f"DPoP Stats Report - Multiple Builds - {stats_as_of}"

    msg.attach(MIMEText(html_table, 'html'))

    # Combine To, CC, and BCC for the actual SMTP send
    recipients = mail_list + cc_list + bcc_list

    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(SENDER_EMAIL, recipients, msg.as_string())
        server.quit()
        print("✅ DPoP Stats email sent successfully!")
    except Exception as e:
        print(f"❌ SMTP Error: {str(e)}")
        raise RuntimeError(f"Failed to send email: {str(e)}")

# ==========================================
# DAG DEFINITION
# ==========================================
ist_tz = pendulum.timezone("Asia/Kolkata")

default_args = {
    'owner': 'Amit Kumar',
    'depends_on_past': False,
    'start_date': datetime.datetime(2026, 8, 7, tzinfo=ist_tz),
    'email': ["data.analyst-tc@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': datetime.timedelta(minutes=5)
}

dag_dpop = DAG(
    'dpop_stats_report_daily',
    default_args=default_args,
    description='Runs three times daily (7AM, 1PM & 7PM) to generate DPoP stats and email report',
    schedule="0 7,13,19 * * *",  # Runs at 7:00 AM, 1:00 PM, and 7:00 PM IST
    catchup=False
)

# ==========================================
# TASK DEFINITION
# ==========================================
task_generate_report = PythonOperator(
    task_id='generate_and_send_dpop_report_task',
    python_callable=generate_and_send_dpop_report,
    dag=dag_dpop,
)

task_generate_report