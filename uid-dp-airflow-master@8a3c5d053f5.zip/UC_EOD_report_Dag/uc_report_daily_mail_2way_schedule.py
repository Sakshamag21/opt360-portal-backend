import datetime
import smtplib
from io import StringIO, BytesIO
import zipfile
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

import boto3
import pandas as pd
from trino.dbapi import connect
from airflow import DAG
from airflow.operators.python import PythonOperator

# ==========================================
# CONFIGURATION DETAILS
# ==========================================

# Trino Configuration
trino_host = "10.10.116.75"
trino_catalog_iceberg = 'strot'  
trino_port = 8080
trino_user = "airflow_dag_op"

# 📧 SMTP Configuration
SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25                      

# ☁️ Local S3 Configuration
S3_ENDPOINT_URL = "http://10.10.103.12:425"  
S3_ACCESS_KEY = "9S0KLIQO7T2XCNGH4P4A"         
S3_SECRET_KEY = "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4"         
S3_BUCKET = "prd-bi-data-platform-test"            
S3_PREFIX = "temp"                        
S3_REGION = "us-east-1"                   

# 📨 Email Recipients
# 🧪 Testing Mode: Sent strictly to you first
mail_list = ["data.analyst-tc@uidai.net.in"]
bcc_list = []

# ==========================================
# DAG DEFINITION
# ==========================================

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2025, 6, 8),
    'email': ["data.analyst-tc@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': datetime.timedelta(minutes=2)
}

dag = DAG(
    'uc_report_daily_mail_RO_wise_DUAL_SCHEDULE', 
    default_args=default_args,
    description='RO wise CSVs bundled in ZIP + Local S3 backup + 8:00PM and 12:30AM Schedules',
    schedule="30 0,20 * * *",  
    catchup=False
)

# ==========================================
# HELPER FUNCTIONS
# ==========================================

def trino_fetch(query, catalog='flink_stream', schema='stream_enu', host=trino_host, port=trino_port, user=trino_user):
    try:
        conn = connect(host=host, port=port, user=user, catalog=catalog)
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"success": 1, "df": pd.DataFrame()}
        cols = [i[0] for i in cur.description]
        df = pd.DataFrame(body, columns=cols)
        return {"success": 1, "df": df}
    except Exception as e:
        return {"success": 0, "msg": str(e)}

def send_email_via_smtp(to_email, bcc_emails, zip_bytes, zip_filename, full_date_str, run_time_label):
    """Constructs and sends an email with the ZIP attachment via SMTP with hidden BCC recipients."""
    sender_email = "airflow@uidai.net.in"
    
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = to_email
    
    # 🎯 DYNAMIC SUBJECT: Switches automatically between (8PM) and (12:30Am)
    msg['Subject'] = f"UC Consolidated EOD report for {full_date_str} ({run_time_label})"
    
    # 🎯 DYNAMIC BODY: Matches your exact required message layout per time window
    html_body = f"""
    <html>
        <body style="font-family: Arial, sans-serif; color: #333333; line-height: 1.6;">
            <p>Dear All,</p>
            <p>Please find attached UC Consolidated EOD report for {full_date_str} ({run_time_label}).</p>
            <p><b>note:</b>zip contain RO wise csv file. plz download zip folder and see the files inside it</p>
            <br>
            <p>Regards,<br>
            Airflow Automation</p>
        </body>
    </html>
    """
    msg.attach(MIMEText(html_body, 'html'))
    
    part = MIMEApplication(zip_bytes, Name=zip_filename)
    part['Content-Disposition'] = f'attachment; filename="{zip_filename}"'
    msg.attach(part)
    
    recipients = [to_email]
    if bcc_emails:
        recipients.extend(bcc_emails)
        
    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(sender_email, recipients, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"SMTP Error: {str(e)}")
        return False

def upload_zip_to_s3(zip_bytes, s3_key):
    """Uploads raw zip bytes to Local S3."""
    s3_client = boto3.client(
        "s3",
        endpoint_url=S3_ENDPOINT_URL,
        aws_access_key_id=S3_ACCESS_KEY,
        aws_secret_access_key=S3_SECRET_KEY,
    )
    s3_client.put_object(Bucket=S3_BUCKET, Key=s3_key, Body=zip_bytes)

# ==========================================
# MAIN PROCESSING FUNCTION
# ==========================================

def process_split_save_and_trigger(email_list):
    # ⏱️ Smart Time-Window Logic Block
    now_time = datetime.datetime.now()
    
    # Check execution hour to determine date shift and text label parameters
    if now_time.hour == 0:
        print("Executing Midnight run window. Shifting focus to previous day...")
        target_time = now_time - datetime.timedelta(days=1)
        run_time_label = "12:30Am"  # 🎯 Sets your required midnight tag
    else:
        print("Executing Evening run window. Target date locked to current day...")
        target_time = now_time
        run_time_label = "8PM"      # 🎯 Sets your required evening tag
        
    report_date_str = target_time.strftime("%d-%m-%y")  
    
    day = target_time.day
    suffix = 'th' if 11 <= day <= 13 else {1: 'st', 2: 'nd', 3: 'rd'}.get(day % 10, 'th')
    full_date_str = f"{day}{suffix} {target_time.strftime('%B %Y')}" 
    
    zip_file_name = f"enrolment_report_RO_wise_{report_date_str}.zip"
    s3_key = f"{S3_PREFIX}/{zip_file_name}"
    
    dynamic_query = f'''
    SELECT
      "stream_enu"."enu_uc_opt_action_v2"."station_id"      AS "Station_ID",
      "stream_enu"."enu_uc_opt_action_v2"."operator_id"    AS "Operator_ID",
      "stream_enu"."enu_uc_opt_action_v2"."resident_sid"   AS "Resident_SID",
      "stream_enu"."enu_uc_opt_action_v2"."enrolment_type"  AS "enrolment_type",
      "stream_enu"."enu_uc_opt_action_v2"."stage"           AS "Stage",
      "stream_enu"."enu_uc_opt_action_v2"."stage_status"    AS "Stage_Status",
      "stream_enu"."enu_uc_opt_action_v2"."event_timestamp" AS "Event_timestamp",
      "stream_enu"."enu_uc_opt_action_v2"."ea"              AS "EA",
      "stream_enu"."enu_uc_opt_action_v2"."registrar"       AS "Registrar",
      "stream_enu"."enu_uc_opt_action_v2"."state"           AS "State",
      "stream_enu"."enu_uc_opt_action_v2"."ro"              AS "RO"
    FROM
      "stream_enu"."enu_uc_opt_action_v2"
    WHERE
      "stream_enu"."enu_uc_opt_action_v2"."stage" = 'AckSlipUpload'
      AND date("stream_enu"."enu_uc_opt_action_v2"."event_timestamp") = date('{target_time.strftime("%Y-%m-%d")}')
    LIMIT
      1048575
    '''
    
    print(f"Initiating Trino extraction for target partition date: {target_time.strftime('%Y-%m-%d')}...")
    result = trino_fetch(dynamic_query)
    
    if result["success"] == 0:
        print(f"Extraction halted due to query error: {result.get('msg')}")
        return

    df = result["df"]
    if df.empty:
        print("No matching data records found for the execution date.")
        return

    total_rows = len(df)
    print(f"Extracted data profile dimensions: {df.shape}")

    print("Grouping data by Regional Office (RO) and building ZIP...")
    
    df['RO'] = df['RO'].fillna('Others')
    grouped_by_ro = df.groupby('RO')
    
    zip_buffer = BytesIO()
    
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as daily_zip:
        for ro_name, ro_df in grouped_by_ro:
            safe_ro_name = str(ro_name).replace(" ", "_").replace("/", "_")
            file_name = f"enrolment_report_{report_date_str}_{safe_ro_name}.csv"
            
            csv_buffer = StringIO()
            ro_df.to_csv(csv_buffer, index=False)
            csv_content = csv_buffer.getvalue()
            
            daily_zip.writestr(file_name, csv_content)
            print(f"Added {file_name} to ZIP (Rows: {len(ro_df)})")
    
    zip_buffer.seek(0)
    zip_bytes = zip_buffer.read()
    
    try:
        upload_zip_to_s3(zip_bytes, s3_key)
        print(f"✅ ZIP archive successfully uploaded to Local S3.")
    except Exception as s3_err:
        print(f"❌ Failed to upload ZIP to Local S3: {str(s3_err)}")

    print(f"Dispatching email via SMTP with ZIP attachment...")
    for target_email in email_list:
        try:
            success = send_email_via_smtp(target_email, bcc_list, zip_bytes, zip_file_name, full_date_str, run_time_label)
            if success:
                print(f"Successfully transmitted report email to: {target_email}")
            else:
                print(f"Failed to transmit email to {target_email}.")
        except Exception as mail_error:
            print(f"Network error routing attachment payload to {target_email}: {str(mail_error)}")

email_query_task = PythonOperator(
    task_id='uc_report_daily_mail_task',
    python_callable=process_split_save_and_trigger,
    op_kwargs={'email_list': mail_list},
    trigger_rule='all_done',
    dag=dag,
)

email_query_task
