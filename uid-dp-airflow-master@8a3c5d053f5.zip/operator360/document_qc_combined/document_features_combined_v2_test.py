# v2: identical to document_multiple_feature_dag.py except dag_id/job_name,
# so operator_dag_manager_v2.py's retry orchestration can trigger it in
# isolation from the v1 pipeline. See operator_dag_manager_v2.py for the
# retry logic.
import logging
import traceback
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from airflow.sdk import DAG, TriggerRule
from airflow.providers.standard.operators.python import PythonOperator
from airflow.exceptions import AirflowSkipException

# MODIFIED: Imported trino function alongside run_one_feature to reuse existing connection
from operator360.work_category_features.insert_work_features_test import run_one_feature, trino
from operator360.signal_mechanism.signals_producer import get_signals_info, push_signals_kafka
from operator360.utils.raw_table_validation import get_source_tables, get_last_successful_run
from operator360.utils.s3_audit_logger_test import audit_to_s3
from operator360.utils.pipeline_status import report_status, parse_bool
from operator360.utils.pipeline_status_v2 import skip_if_already_succeeded
from operator360.utils.pipeline_alerts_test import notify_failure

job_name = "document_features_combined_v3"
category = "document"
desc = "Run all the  Document Features"
signal_api_base_ip = "10.10.116.60:8000"

FEATURES = {
    "doc_qc_error_al_incidents_count_daily": {
        "feature_name": "doc_qc_error_al_incidents_count_daily",
        "feature_version": 1,
        "feature_id":"doc_qc_error_al_incidents_count_daily_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_daily_feature_query.sql",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "doc_qc_error_doe2_incidents_count_daily": {
        "feature_name": "doc_qc_error_doe2_incidents_count_daily",
        "feature_version": 1,
        "feature_id":"doc_qc_error_doe2_incidents_count_daily_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_daily_feature_query.sql",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "doc_qc_error_hpm_incidents_count_daily": {
        "feature_name": "doc_qc_error_hpm_incidents_count_daily",
        "feature_version": 1,
        "feature_id":"doc_qc_error_hpm_incidents_count_daily_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_daily_feature_query.sql",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "doc_qc_error_doe1_incidents_count_daily": {
        "feature_name": "doc_qc_error_doe1_incidents_count_daily",
        "feature_version": 1,
        "feature_id":"doc_qc_error_doe1_incidents_count_daily_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_daily_feature_query.sql",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "doc_qc_error_be_incidents_count_daily": {
        "feature_name": "doc_qc_error_be_incidents_count_daily",
        "feature_version": 1,
        "feature_id":"doc_qc_error_be_incidents_count_daily_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_daily_feature_query.sql",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "doc_qc_error_pop_incidents_count_daily": {
        "feature_name": "doc_qc_error_pop_incidents_count_daily",
        "feature_version": 1,
        "feature_id":"doc_qc_error_pop_incidents_count_daily_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_daily_feature_query.sql",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "doc_qc_error_de_incidents_count_daily": {
        "feature_name": "doc_qc_error_de_incidents_count_daily",
        "feature_version": 1,
        "feature_id":"doc_qc_error_de_incidents_count_daily_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_daily_feature_query.sql",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "doc_qc_error_incidents_count_daily": {
        "feature_name": "doc_qc_error_incidents_count_daily",
        "feature_version": 1,
        "feature_id":"doc_qc_error_incidents_count_daily_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_total_daily_feature_query.sql",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "doc_qc_error_al_incidents_count_monthly": {
        "feature_name": "doc_qc_error_al_incidents_count_monthly",
        "feature_version": 1,
        "feature_id":"doc_qc_error_al_incidents_count_monthly_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_monthly_feature_query.sql",
        "dependencies":['doc_qc_error_al_incidents_count_daily'],
        "signal_exists":False,
        "is_daily":True
    },
    "doc_qc_error_doe2_incidents_count_monthly": {
        "feature_name": "doc_qc_error_doe2_incidents_count_monthly",
        "feature_version": 1,
        "feature_id":"doc_qc_error_doe2_incidents_count_monthly_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_monthly_feature_query.sql",
        "dependencies":['doc_qc_error_doe2_incidents_count_daily'],
        "signal_exists":True,
        "is_daily":True
    },
    "doc_qc_error_hpm_incidents_count_monthly": {
        "feature_name": "doc_qc_error_hpm_incidents_count_monthly",
        "feature_version": 1,
        "feature_id":"doc_qc_error_hpm_incidents_count_monthly_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_monthly_feature_query.sql",
        "dependencies":['doc_qc_error_hpm_incidents_count_daily'],
        "signal_exists":False,
        "is_daily":True
    },
    "doc_qc_error_doe1_incidents_count_monthly": {
        "feature_name": "doc_qc_error_doe1_incidents_count_monthly",
        "feature_version": 1,
        "feature_id":"doc_qc_error_doe1_incidents_count_monthly_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_monthly_feature_query.sql",
        "dependencies":['doc_qc_error_doe1_incidents_count_daily'],
        "signal_exists":True,
        "is_daily":True
    },
    "doc_qc_error_be_incidents_count_monthly": {
        "feature_name": "doc_qc_error_be_incidents_count_monthly",
        "feature_version": 1,
        "feature_id":"doc_qc_error_be_incidents_count_monthly_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_monthly_feature_query.sql",
        "dependencies":['doc_qc_error_be_incidents_count_daily'],
        "signal_exists":True,
        "is_daily":True
    },
    "doc_qc_error_pop_incidents_count_monthly": {
        "feature_name": "doc_qc_error_pop_incidents_count_monthly",
        "feature_version": 1,
        "feature_id":"doc_qc_error_pop_incidents_count_monthly_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_monthly_feature_query.sql",
        "dependencies":['doc_qc_error_pop_incidents_count_daily'],
        "signal_exists":True,
        "is_daily":True
    },
    "doc_qc_error_de_incidents_count_monthly": {
        "feature_name": "doc_qc_error_de_incidents_count_monthly",
        "feature_version": 1,
        "feature_id":"doc_qc_error_de_incidents_count_monthly_v1",
        "sql_local_path": "/opt/airflow/dags/operator360/document_qc_combined/qc_monthly_feature_query.sql",
        "dependencies":['doc_qc_error_de_incidents_count_daily'],
        "signal_exists":True,
        "is_daily":True
    },
}

# NEW: Helper function to fetch last_successful_run using the imported trino function
# def get_last_successful_run(feature_id):
#     """Fetches the last successful run date for a feature from opt360_features."""
#     query = f"SELECT last_successful_run FROM strot.operator360_stagging.opt360_features WHERE feature_id = '{feature_id}'"
#     try:
#         res = trino(query)
#         df = res.get("df")
#         if df is not None and not df.empty:
#             val = df.iloc[0, 0]
#             if val:
#                 return datetime.strptime(str(val).split(" ")[0], '%Y-%m-%d').date()
#     except Exception as e:
#         logging.error("Failed to fetch last_successful_run for %s: %s", feature_id, e)
#     return None

def run_signals(feature_id):
    try:
        res_try = get_signals_info(feature_id)
        for signal_metadata in res_try:
            push_signals_kafka(signal_metadata)
    except Exception as e:
        print(f"Error in generating signal for feature id : {feature_id}, error: {e}")

@skip_if_already_succeeded(dag_id=job_name)
@audit_to_s3(dag_id=job_name)
@report_status(dag_id=job_name, category=category)
def run_single_features(feature_name, feature_version,feature_id,  sql_file, end_date, is_daily=False, data_interval_start=None, pipeline_run_id=None, is_daily_run=None, log_url=None, try_number=None):
    logger = logging.getLogger(f"running {feature_name}:v{feature_version}")

    source_table = None

    if is_daily:
        if not parse_bool(is_daily_run):
            logger.info("Skipping %s - not the daily promotion run", feature_name)
            raise AirflowSkipException("Skipping - not the daily promotion run")

        # METADATA FETCH INTEGRATION
        logger.info("Fetching source table metadata for feature_id: %s", feature_id)
        if feature_id:
            source_tables_res = get_source_tables(category="doc")
            if not source_tables_res.get('success'):
                logger.error("Failed to fetch source tables metadata. Error: %s", source_tables_res.get('error'))
                raise RuntimeError(f"Metadata DB lookup failed. Error: {source_tables_res.get('error')}")

            mapping = source_tables_res
            source_table = mapping.get(feature_id)

            if not source_table:
                logger.warning("No source_table found in metadata for feature_id=%s. Proceeding with feature run anyway.", feature_id)

    print(f"Executing feature {feature_name}")
    try:
        end_date_dt = datetime.strptime(end_date, '%Y-%m-%d').date()
        last_run = get_last_successful_run(feature_id)

        start_date = None
        if last_run:
            start_date_dt = last_run + timedelta(days=1)
            start_date = start_date_dt.strftime('%Y-%m-%d')

            if start_date_dt > end_date_dt:
                logger.info("Feature %s already up to date (last_run=%s, end_date=%s). Skipping.",
                            feature_name, last_run, end_date)
                raise AirflowSkipException(f"Feature {feature_name} already up to date for {end_date}")
        else:
            start_date = end_date

        logger.info("Running feature %s v%s with sql=%s, start_date=%s, end_date=%s",
                    feature_name, feature_version, sql_file, start_date, end_date)

        run_one_feature(
            feature_name=feature_name,
            feature_version=feature_version,
            sql_file=sql_file,
            start_date=start_date,
            end_date=end_date,
            source_table=source_table
        )
        logger.info("Feature executed successfully %s v%s from %s to %s", feature_name, feature_version, start_date, end_date)

    except AirflowSkipException:
        raise
    except Exception as e:
        # CATCH-ALL: Send an email for ANY unhandled error in the DAG
        error_msg = f"Unhandled DAG Execution Error for {feature_name} v{feature_version}:\n{traceback.format_exc()}"
        logger.error(error_msg)
        notify_failure(feature_name, "DAG Execution Error", error_msg)
        raise

default_args = {
    "owner": "Piyush Singh",
    "depends_on_past": False,
    "start_date": datetime(2026, 4, 13, tzinfo=ZoneInfo("Asia/Kolkata")),
    "execution_timeout": timedelta(minutes=35),
    "email": ["techexe11.yp26@uidai.net.in"],
    "email_on_failure": True,
    "email_on_retry": True,
    "retries": 1,
}

with DAG(
    dag_id=job_name,
    default_args={
        **default_args,
        "start_date": datetime(2025, 1, 1, tzinfo=ZoneInfo("Asia/Kolkata")),  # FIX: past date
    },
    description=desc,
    schedule=None,
    catchup=False,
    max_active_runs=3,
    max_active_tasks=10,  # FIX: increase to allow parallelism
    tags=["Operator360", "Document Category", "v2"],
    params={"business_consumer": "Operator360"},
) as dag:

    tasks = {}

    # --- Create all tasks ---
    for key, cfg in FEATURES.items():
        task = PythonOperator(
            task_id=f"run_{key}",
            python_callable=run_single_features,
            op_kwargs={
                "feature_name": cfg["feature_name"],
                "feature_version": cfg["feature_version"],
                "feature_id": cfg["feature_id"],
                "sql_file": cfg["sql_local_path"],
                "end_date": "{{ data_interval_start | ds }}",
                "is_daily": cfg["is_daily"],
                "data_interval_start": "{{ data_interval_start }}",
                "pipeline_run_id": "{{ dag_run.conf.get('pipeline_run_id') or run_id }}",
                "is_daily_run": "{{ dag_run.conf.get('is_daily_run', 'true') }}",
                "log_url": "{{ ti.log_url }}",
                "try_number": "{{ ti.try_number }}",
            },
        )
        tasks[key] = task

        if cfg["signal_exists"]:
            signal_task = PythonOperator(
                task_id=f"signal_{key}",
                python_callable=run_signals,
                op_kwargs={"feature_id": cfg["feature_id"]},
            )
            tasks[f"signal_{key}"] = signal_task

    # --- Only set REAL dependencies ---
    for key, cfg in FEATURES.items():
        # Feature-to-feature dependencies (e.g., monthly depends on daily)
        for dep in cfg.get("dependencies", []):
            if dep in tasks:
                tasks[dep] >> tasks[key]

        # Feature-to-signal dependencies
        if cfg["signal_exists"] and f"signal_{key}" in tasks:
            tasks[key] >> tasks[f"signal_{key}"]

    # ❌ REMOVED: the sequential chaining loop entirely