from __future__ import annotations
import logging
from datetime import datetime, timedelta
import pandas as pd
import polars as pl
import clickhouse_connect
from trino.dbapi import connect
import mysql.connector

logger = logging.getLogger(__name__)

TRINO_HOST = "10.10.116.39"; TRINO_PORT = 8080; TRINO_USER = "airflow_dag_op"
MYSQL_HOST = "10.10.106.159"; MYSQL_USER = "Data_platform_W"; MYSQL_PASSWORD = "Dataplat_7634"
CH_HOST = '10.10.120.86'; CH_USER = 'default'; CH_PASSWORD = 'qwerty'; CH_DATABASE = 'default'
CH_TABLE = 'opt360_feature_store_test_v2'
TRINO_FETCH_SIZE = 5000          # rows pulled per fetchmany() call from Trino
CH_INSERT_BATCH = 5000           # rows pushed per insert to ClickHouse


def chunked(seq, size):
    for i in range(0, len(seq), size):
        yield seq[i:i + size]


def _fetch_mysql_query(query, host=MYSQL_HOST, user=MYSQL_USER, password=MYSQL_PASSWORD):
    conn = None
    try:
        conn = mysql.connector.connect(host=host, user=user, password=password)
        cursor = conn.cursor()
        cursor.execute(query)
        results = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description] if cursor.description else []
        return (pl.DataFrame([[str(i) if i is not None else None for i in r] for r in results],
                             schema=columns, orient="row") if columns else pl.DataFrame())
    finally:
        if conn:
            conn.close()


def _get_feature_group(feature_id):
    mapping = {'auth': 'Authentication', 'bio': 'Biometrics', 'work': 'Work',
               'harware': 'Hardware', 'sustxn': 'Suspicious Transaction', 'doc': "Document"}
    return mapping.get(feature_id.split('_')[0], feature_id)


def _build_trino_query_for_day(dest_table, entity_ids, run_date: str):
    """
    Build a Trino query that:
      - filters records for the given run_date (the whole day)
      - filters by the entity_ids belonging to a risk bucket
      - keeps only the latest record per entity for that day (ROW_NUMBER)
    """
    entity_ids_str = ', '.join([f"'{e}'" for e in entity_ids])
    next_day = (datetime.strptime(run_date, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")
    return f"""
        SELECT entity_id, feature_value, timestamp
        FROM (
            SELECT entity_id, feature_value, timestamp,
                   ROW_NUMBER() OVER (PARTITION BY entity_id ORDER BY timestamp DESC) AS rn
            FROM {dest_table}
            WHERE entity_id IN ({entity_ids_str})
              AND timestamp >= TIMESTAMP '{run_date} 00:00:00'
              AND timestamp <  TIMESTAMP '{next_day} 00:00:00'
        )
        WHERE rn = 1
    """


def _get_feature_config(feature_name: str, feature_version: int) -> dict:
    resp = _run_trino_query(
        f"SELECT feature_id, destination_table, description "
        f"FROM strot.operator360_stagging.opt360_features "
        f"WHERE feature_name = '{feature_name}' AND version = '{feature_version}' "
        f"AND status = 'PROD' LIMIT 1"
    )
    if not resp.get("success") or resp["df"].empty:
        raise ValueError("Feature config not found")
    return resp["df"].to_dict(orient='records')[0]


def _run_trino_query(query, host=TRINO_HOST, port=TRINO_PORT, user=TRINO_USER):
    """Small helper used only for metadata fetches."""
    conn = None
    try:
        conn = connect(host=host, port=port, user=user)
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        cols = [d[0] for d in cur.description] if cur.description else []
        return {"success": 1, "df": pd.DataFrame(body, columns=cols) if cols else pd.DataFrame()}
    except Exception as e:
        return {"success": 0, "msg": str(e), "df": pd.DataFrame()}
    finally:
        if conn:
            conn.close()


def _decorate_batch(batch_df: pd.DataFrame, feature: dict) -> pd.DataFrame:
    """Attach feature metadata columns to a streamed Trino batch."""
    feature_id = feature['feature_id']
    description = feature['description']

    batch_df = batch_df.copy()
    batch_df['feature_id'] = feature_id
    batch_df['feature_name'] = feature_id.replace('_', ' ')
    batch_df['description'] = '' if pd.isna(description) else description
    batch_df['feature_group'] = _get_feature_group(feature_id)
    batch_df = batch_df.rename(columns={'timestamp': 'last_updated_at'})
    batch_df['last_updated_at'] = pd.to_datetime(batch_df['last_updated_at'], errors='coerce')
    batch_df = batch_df.drop_duplicates(subset=['entity_id', 'feature_id'], keep='last')
    return batch_df[['entity_id', 'feature_id', 'feature_value', 'feature_name',
                     'description', 'last_updated_at', 'feature_group']]


def _stream_trino_to_clickhouse(query, feature: dict, ch_client,
                                fetch_size: int = TRINO_FETCH_SIZE,
                                insert_size: int = CH_INSERT_BATCH):
    """
    Open a Trino cursor, stream rows via fetchmany(), decorate them,
    and push them to ClickHouse in incremental batches — without
    materializing the whole result set in memory.
    """
    conn = None
    total_rows = 0
    try:
        conn = connect(host=TRINO_HOST, port=TRINO_PORT, user=TRINO_USER)
        cur = conn.cursor()
        cur.execute(query)

        cols = [d[0] for d in cur.description] if cur.description else []
        if not cols:
            logger.warning("Trino returned no columns; skipping stream.")
            return 0

        pending = []   # accumulate decorated rows until we reach insert_size

        while True:
            rows = cur.fetchmany(fetch_size)
            if not rows:
                break

            batch_df = pd.DataFrame(rows, columns=cols)
            decorated = _decorate_batch(batch_df, feature)
            if not decorated.empty:
                pending.append(decorated)

            # Flush when accumulated rows cross the insert threshold
            current_pending = sum(len(d) for d in pending)
            if current_pending >= insert_size:
                flush_df = pd.concat(pending, ignore_index=True)
                flush_df = flush_df.drop_duplicates(subset=['entity_id', 'feature_id'], keep='last')
                if not flush_df.empty:
                    ch_client.insert_df(CH_TABLE, flush_df)
                    total_rows += len(flush_df)
                    logger.info(f"Pushed {len(flush_df)} rows to ClickHouse (running total: {total_rows}).")
                pending = []

        # Final flush for whatever remains
        if pending:
            flush_df = pd.concat(pending, ignore_index=True)
            flush_df = flush_df.drop_duplicates(subset=['entity_id', 'feature_id'], keep='last')
            if not flush_df.empty:
                ch_client.insert_df(CH_TABLE, flush_df)
                total_rows += len(flush_df)
                logger.info(f"Pushed final {len(flush_df)} rows to ClickHouse (total: {total_rows}).")

        return total_rows

    except Exception as e:
        logger.error(f"Trino streaming failed: {e}")
        raise
    finally:
        if conn:
            conn.close()


def process_feature_for_bucket(feature: dict, risk_bucket: str, run_date: str,
                               ch_client) -> int:
    feature_id = feature['feature_id']
    dest_table = feature['destination_table']
    if pd.isna(dest_table) or not dest_table:
        return 0

    # Get the entity_ids that belong to this risk bucket
    data_df = _fetch_mysql_query(
        f"SELECT id FROM operator360.opt_master "
        f"WHERE is_active = true AND risk_bucket = '{risk_bucket}'"
    )
    entity_ids = data_df['id'].to_list()
    if not entity_ids:
        logger.info(f"[{feature_id}] No active entities for bucket={risk_bucket}; skipping.")
        return 0

    # Build a single day-scoped query and stream it through the cursor
    query = _build_trino_query_for_day(dest_table, entity_ids, run_date)
    logger.info(f"[{feature_id}] Streaming Trino data for bucket={risk_bucket} run_date={run_date}")

    pushed = _stream_trino_to_clickhouse(
        query=query,
        feature=feature,
        ch_client=ch_client,
    )
    logger.info(f"[{feature_id}] Bucket={risk_bucket}: pushed {pushed} rows to ClickHouse.")
    return pushed


def process_single_feature_to_clickhouse(feature_name: str,
                                         feature_version: int,
                                         run_date: str):
    """
    Process one feature for a given day:
      1. Pull feature config from Trino.
      2. For every risk bucket, fetch its entity_ids from MySQL.
      3. Stream the day's Trino data through a cursor and push
         incremental batches to ClickHouse.
    """
    try:
        feature_config = _get_feature_config(feature_name, feature_version)

        # One ClickHouse client reused across buckets
        ch_client = clickhouse_connect.get_client(
            host=CH_HOST, username=CH_USER, password=CH_PASSWORD, database=CH_DATABASE
        )

        grand_total = 0
        for risk_bucket in ['Critical', 'High', 'Medium', 'Low', 'No']:
            grand_total += process_feature_for_bucket(
                feature=feature_config,
                risk_bucket=risk_bucket,
                run_date=run_date,
                ch_client=ch_client,
            )

        logger.info(f"ClickHouse Ingest: {feature_name} v{feature_version} "
                    f"run_date={run_date} -> total pushed rows = {grand_total}")
        return grand_total

    except Exception as e:
        logger.error(f"ClickHouse Ingest: Failed to process "
                     f"{feature_name} v{feature_version} for {run_date}: {e}")
        raise