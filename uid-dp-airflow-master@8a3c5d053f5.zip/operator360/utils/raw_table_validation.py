import pandas as pd
import boto3
import json
import time
from botocore.exceptions import ClientError
from trino.dbapi import connect
import logging
from datetime import datetime, timedelta, date

logger = logging.getLogger(__name__)

trino_host = "10.10.116.75"
trino_port = 8080
trino_user = "opt360_feature_metadata"

table_timestamp_column_mapping = {
    'flink_stream.stream_enu.ens_packet_enriched': 'event_timestamp',
    'flink_stream.stream_enu.bi_enu_enrlraw_v2': 'processed_timestamp',
    'flink_stream.analytics_enu.machine_hardware_trust_change': 'record_timestamp',
    'flink_stream.operator360.opt_auth_txn_v3': 'event_timestamp',
    'flink_stream.stream_enu.enu_uc_opt_action_v2': 'event_timestamp',
    'flink_stream.stream_enu.enu_operator_sync_raw': 'event_timestamp',
    'strot.operator360.uc_machineip_isp_map': 'uc_event_timestamp',
    'strot.operator360.opt_oddhour_anomalous_ens_eid_daily': 'event_timestamp',
    'strot.operator360.opt_outstate_anomalous_enu_eid_daily': 'event_timestamp',
    'strot.operator360.txn_parallel_enrl_v1': 'timestamp',
    'flink_stream.mysql_uid_v2.uid_origin_tracker_enriched ': 'enr_date',
    'flink_stream.stream_enu.enu_bfc_analytics_raw_v1':'eventtimestamp',
    'strot.operator360.eid_qc_error_report_v2':'last_updated_at',
}

CEPH_ENDPOINT_URL = "http://10.10.103.12:425" 
CEPH_ACCESS_KEY = "9S0KLIQO7T2XCNGH4P4A"
CEPH_SECRET_KEY = "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4"
CEPH_BUCKET_NAME = "prd-bi-data-platform-test"
CEPH_CACHE_PREFIX = "cache/airflow/operator360"
CACHE_TTL_SECONDS = 20 * 60 * 60
_memory_cache = {}

def trino(query, host=trino_host, port=trino_port, user=trino_user):
    try:
        q_lower = query.strip().lower()
        conn = connect(host=host, port=port, user=user)
        cur = conn.cursor()
        cur.execute(query)
        if q_lower.startswith(("select", "with", "show", "describe", "explain")):
            body = cur.fetchall()
            if not body: return {"success": 1, "data": body}
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
        return {"query": query, "success": 1}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}

def _get_s3_client():
    return boto3.client('s3', endpoint_url=CEPH_ENDPOINT_URL, aws_access_key_id=CEPH_ACCESS_KEY, aws_secret_access_key=CEPH_SECRET_KEY)

def _get_s3_key(table_name: str) -> str:
    return f"{CEPH_CACHE_PREFIX}/{table_name.replace('.', '_').strip()}.json"

def _load_from_s3(s3_client, table_name: str) -> dict:
    try:
        response = s3_client.get_object(Bucket=CEPH_BUCKET_NAME, Key=_get_s3_key(table_name))
        return json.loads(response['Body'].read().decode('utf-8'))
    except: return None

def _save_to_s3(s3_client, table_name: str, data: dict):
    try: s3_client.put_object(Bucket=CEPH_BUCKET_NAME, Key=_get_s3_key(table_name), Body=json.dumps(data).encode('utf-8'), ContentType='application/json')
    except: pass

def _is_cache_valid(entry: dict) -> bool:
    return entry and 'timestamp' in entry and (time.time() - entry['timestamp']) < CACHE_TTL_SECONDS

def check_raw_tables(table_name: str, check_date: str = None, use_cache: bool = True) -> bool:
    cache_key_name = f"{table_name}_{check_date}" if check_date else table_name
    if use_cache and cache_key_name in _memory_cache:
        if _is_cache_valid(_memory_cache[cache_key_name]): return _memory_cache[cache_key_name]['result']

    if table_name not in table_timestamp_column_mapping.keys(): return True
    s3_client = _get_s3_client()

    if use_cache:
        entry = _load_from_s3(s3_client, cache_key_name)
        if entry and _is_cache_valid(entry):
            _memory_cache[cache_key_name] = entry
            return entry['result']

    ts_col = table_timestamp_column_mapping[table_name]
    if check_date:
        df_result = trino(f"select count(*) as cnt from {table_name} where date({ts_col}) = date('{check_date}')")
    else:
        df_result = trino(f"select count(*) as cnt from {table_name} where date({ts_col}) = date(current_date - interval '1' day)")

    if 'df' not in df_result.keys(): return False
    row_count = df_result['df']['cnt'][0]
    result = row_count != 0

    cache_entry = {'result': result, 'timestamp': time.time(), 'row_count': int(row_count)}
    _save_to_s3(s3_client, cache_key_name, cache_entry)
    _memory_cache[cache_key_name] = cache_entry
    return result

def get_source_tables(category: str) -> dict:
    df_source_table = None
    for host in ['10.10.116.75','10.10.116.39','10.10.118.35','10.10.118.10']:
        df_source_table = trino(f"select feature_id, source_table from strot.operator360_stagging.opt360_features where status='PROD' and feature_id not like '%score%' and feature_id like '{category}%'", host=host)
        if 'df' in df_source_table.keys(): break

    if not df_source_table or 'df' not in df_source_table: return {'success': False, 'error': 'All Trino hosts failed'}
    mapping = {row['feature_id']: row['source_table'] for _, row in df_source_table['df'].iterrows()}
    return {'success': True, **mapping}

def get_last_successful_run(feature_id):
    """Fetches the last successful run date for a feature from opt360_features."""
    query = f"SELECT coalesce(last_successful_run, current_timestamp - interval '1' day) as last_successful_run  FROM strot.operator360_stagging.opt360_features WHERE feature_id = '{feature_id}'"
    try:
        res = trino(query)
        df = res.get("df")
        if df is not None and not df.empty:
            val = df.iloc[0, 0]
            # NEW REQUIREMENT: Explicitly check for None or blank string
            if val and str(val).strip() != '':
                return datetime.strptime(str(val).split(" ")[0], '%Y-%m-%d').date()
    except Exception as e:
        # Log the error but DO NOT send an email, as per requirement.
        logging.error("Failed to fetch last_successful_run for %s: %s", feature_id, e)
    return None
