import logging
import smtplib
import os
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
import traceback

# Airflow 2.6+ Notifier import (Optional, used if you configure on_failure_callback in DAGs)
try:
    from airflow.notifications.basenotifier import BaseNotifier
except ImportError:
    BaseNotifier = object

logger = logging.getLogger(__name__)

# --- Email Configuration ---
SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25
SENDER_EMAIL = "airflow@uidai.net.in"
ALERT_RECIPIENTS = ["techexe11.yp26@uidai.net.in"]

# --- Zoho Cliq Configuration ---
ZOHO_CLIQ_WEBHOOK_URL = "https://chat.uidai.gov.in/api/v2/bots/optnotifications/incoming?zapikey=1001.cb6c531ed8e5dfa2d79138ea6f227a11.fde5bcd85bf984e4b5c34bd0383106b9&channel=dataplatformtesting&dc=hdc"

# --- Network Proxy Configuration ---
# Added your specific corporate proxy configurations here
PROXY_URL = "http://10.10.16.28:3128"
PROXIES = {
    "http": PROXY_URL,
    "https": PROXY_URL
}


class Operator360SmtpNotifier(BaseNotifier):
    """Airflow Notifier wrapper that reads real-time logs on failure."""

    def __init__(self, logger_instance, subject_prefix: str = "Task Failed"):
        super().__init__()
        self.subject_prefix = subject_prefix
        self.logger = logger_instance

    def notify(self, context):
        """Called automatically by Airflow when a task fails."""
        ti = context["task_instance"]
        
        subject = f"{self.subject_prefix} - DAG: {ti.dag_id} | Task: {ti.task_id}"
        exception = context.get("exception", "No explicit traceback captured.")
        
        try:
            log_messages, _ = self.logger.handlers[0].handler.read(ti, ti.try_number)
            log_lines = log_messages[0].splitlines() if log_messages else []
            tail_logs = "\n".join(log_lines[-30:]) if log_lines else "Log content empty or unreadable."
        except Exception as log_err:
            tail_logs = f"Could not read task logs programmatically: {str(log_err)}"

        email_body = (
            f"--- ERROR EXCEPTION ---\n{exception}\n\n"
            f"--- LAST 30 LOG LINES ---\n{tail_logs}"
        )
        
        send_pipeline_alert(subject=subject, body=email_body)


def send_zoho_cliq_alert(subject: str, body: str):
    """Sends the alert payload to Zoho Cliq Incoming Webhook."""
    
    # We construct an HTML payload because the Deluge script you wrote 
    # is designed to parse HTML and convert it to Cliq Markdown!
    html_body_for_cliq = f"""
    <h2>Pipeline Alert: {subject}</h2>
    <p>An issue was detected in the <strong>Operator360 Feature Pipeline</strong>.</p>
    <hr>
    <pre>{body}</pre>
    <p style="font-size: 12px; color: #888;">This is an automated alert. Please investigate the Airflow logs immediately.</p>
    """
    
    payload = {
        "text": html_body_for_cliq
    }
    
    try:
        logger.info("Sending Zoho Cliq alert: %s", subject)
        # FIX: Added proxies=PROXIES to route the request through your corporate proxy
        response = requests.post(ZOHO_CLIQ_WEBHOOK_URL, data=payload, proxies=PROXIES, timeout=10)
        if response.status_code != 200:
            logger.error("Zoho Cliq alert failed. Status: %s, Response: %s", response.status_code, response.text)
        else:
            logger.info("Zoho Cliq alert sent successfully.")
    except Exception as e:
        logger.error("Failed to send Zoho Cliq alert: %s", e)


def send_pipeline_alert(subject: str, body: str):
    """Sends an HTML formatted alert email to the configured recipients."""
    msg = MIMEMultipart("alternative")
    msg["From"] = SENDER_EMAIL
    msg["To"] = ", ".join(ALERT_RECIPIENTS)
    msg["Subject"] = f"[Operator360 Pipeline Alert] {subject}"
    
    html_content = f"""
    <html>
      <body style="font-family: Arial, sans-serif; color: #333;">
        <h2 style="color: #d9534f;">Pipeline Alert: {subject}</h2>
        <p>An issue was detected in the <strong>Operator360 Feature Pipeline</strong>.</p>
        <hr style="border: 1px solid #ddd;">
        <pre style="background-color: #f9f9f9; padding: 10px; border-radius: 5px; white-space: pre-wrap; word-wrap: break-word;">{body}</pre>
        <p style="font-size: 12px; color: #888;">This is an automated alert. Please investigate the Airflow logs immediately.</p>
      </body>
    </html>
    """
    msg.attach(MIMEText(html_content, "html"))
    
    try:
        logger.info("Sending pipeline alert email: %s", subject)
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(SENDER_EMAIL, ALERT_RECIPIENTS, msg.as_string())
        server.quit()
        logger.info("Alert email sent successfully.")
    except Exception as e:
        logger.error("Failed to send alert email: %s", e)
    
    # Also send the alert to Zoho Cliq
    send_zoho_cliq_alert(subject, body)


def notify_failure(feature_name: str, error_type: str, error_details: str):
    """Maps specific error types to email AND Zoho Cliq alerts."""
    subject = f"{error_type} - Feature: {feature_name}"
    
    if error_type == "Raw Data Missing":
        body = f"Raw data is missing for feature '{feature_name}'.\n\nDetails:\n{error_details}"
    elif error_type == "Query Timeout":
        body = f"Query for feature '{feature_name}' exceeded the 30-minute timeout limit.\n\nDetails:\n{error_details}"
    elif error_type == "Trino Node Failure":
        body = f"Trino connection or execution failed for feature '{feature_name}'.\n\nDetails:\n{error_details}"
    else:
        body = f"An unhandled error occurred for feature '{feature_name}'.\n\nDetails:\n{error_details}"
        
    # Send to BOTH Email and Zoho Cliq
    send_pipeline_alert(subject, body)


def execute_trino_with_timeout(trino_func, query: str, feature_name: str, timeout_seconds: int = 1800):
    """
    Executes a Trino query in a separate thread. If it takes longer than 
    timeout_seconds (default 30 minutes / 1800 seconds), it raises a TimeoutError and sends an alert.
    """
    try:
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(trino_func, query)
            result = future.result(timeout=timeout_seconds)
            
            if isinstance(result, dict) and result.get("success") == 0:
                err_msg = result.get("msg", "Unknown Trino error")
                if "Connection refused" in err_msg or "node" in err_msg.lower() or "memory" in err_msg.lower():
                    notify_failure(feature_name, "Trino Node Failure", err_msg)
                else:
                    notify_failure(feature_name, "Query Execution Error", err_msg)
                raise RuntimeError(f"Trino query failed: {err_msg}")
                    
            return result
            
    except FutureTimeoutError:
        error_msg = f"Query took longer than {timeout_seconds} seconds (30 minutes) and was aborted.\nQuery: {query}"
        notify_failure(feature_name, "Query Timeout", error_msg)
        raise RuntimeError(error_msg)
        
    except Exception as e:
        error_msg = f"Unexpected error during query execution: {str(e)}\n{traceback.format_exc()}"
        notify_failure(feature_name, "Unexpected Error", error_msg)
        raise