from datetime import datetime, timedelta, date
import logging
import traceback
import pandas as pd
from trino.dbapi import connect
import os
import pytz

# NEW: Imported check_raw_tables to perform per-day validation inside the loop
from operator360.utils.raw_table_validation import check_raw_tables
# NEW: Imported the alert and timeout wrapper functions
from operator360.utils.pipeline_alerts_test import execute_trino_with_timeout, notify_failure

# NEW: Imported the ClickHouse ingestion function
from operator360.clickhouse_serving_layer.opt360_clickhouse_feature_store_test import process_single_feature_to_clickhouse

logger = logging.getLogger(__name__)
trino_port = "8080"
trino_user = "opt360job"
trino_host='10.10.116.75'

os.environ.pop("HTTP_PROXY", None)
os.environ.pop("http_proxy", None)
os.environ.pop("HTTPS_PROXY", None)
os.environ.pop("https_proxy", None)
ist = pytz.timezone('Asia/Kolkata')


def trino(query, host=trino_host, port=trino_port, user=trino_user):
    q_lower = query.strip().lower()
    conn = connect(host=host, port=port, user=user)
    cur = conn.cursor()
    cur.execute(query)
    if q_lower.startswith(("select", "with", "show", "describe", "explain")):
        body = cur.fetchall()
        cols = [i[0] for i in cur.description] if cur.description else []
        df = pd.DataFrame(body, columns=cols) if cols else pd.DataFrame(body)
        return {"query": query, "success": 1, "data": (cols, body), "df": df}
    return {"query": query, "success": 1}

def load_sql_file(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def _parse_dependent_features(dep_val):
    params = {}
    if isinstance(dep_val, list):
        items = dep_val
    elif isinstance(dep_val, str):
        s = dep_val.strip().strip("[]")
        items = [i.strip().strip("'").strip('"') for i in s.split(",") if i.strip()]
    else:
        items = []
    for item in items:
        if isinstance(item, str) and ":" in item:
            k, v = item.split(":", 1)
            params[k.strip()] = v.strip()
    return params

# NEW: Helper function to update last_successful_run in Trino
def update_last_successful_run(feature_name, feature_version, run_date):
    """Updates the last_successful_run timestamp for a specific feature."""
    query = (
        f"UPDATE strot.operator360_stagging.opt360_features "
        f"SET last_successful_run = timestamp '{run_date} 00:00:00' "
        f"WHERE feature_name = '{feature_name}' AND version = '{feature_version}'"
    )
    res = trino(query)
    print(query)
    if not res.get("success"):
        raise RuntimeError(f"Failed to update last_successful_run: {res}")

# MODIFIED: Added source_table parameter to accept it from the DAG
def run_one_feature(feature_name: str, feature_version: int, sql_file: str, end_date: str = None, start_date: str = None, source_table: str = None):
    q = (
        "SELECT destination_table, dependent_features, update_window "
        "FROM strot.operator360_stagging.opt360_features "
        f"WHERE feature_name = '{feature_name}' AND version = '{feature_version}'"
    )
    print(q)
    reg = trino(q)
    if 'df' not in reg:
        print(reg)
        raise ValueError(f"trino query failed, returned no df: {reg}")

    df = reg.get("df")
    if df is None or df.empty:
        raise ValueError(f"Feature not found in registry: {feature_name} v{feature_version}")

    row = df.iloc[0]
    destination_table = row.get("destination_table")

    # Safely parse the end_date passed from Airflow, fallback to today IST
    if end_date:
        try:
            current_end_date = datetime.strptime(str(end_date).split(" ")[0], '%Y-%m-%d').date()
        except ValueError:
            current_end_date = datetime.now(ist).date()
    else:
        current_end_date = datetime.now(ist).date()

    # Determine start_date for the loop
    period_days = 1
    if start_date:
        try:
            current_start_date = datetime.strptime(str(start_date).split(" ")[0], '%Y-%m-%d').date()
        except ValueError:
            current_start_date = current_end_date
    else:
        params = _parse_dependent_features(row.get("dependent_features"))
        if params.get("min_pkt_date"):
            current_start_date = datetime.strptime(str(params.get("min_pkt_date")).split(" ")[0], '%Y-%m-%d').date()
        elif params.get("period_in_days"):
            raw = str(params["period_in_days"]).strip()
            digits = "".join([ch for ch in raw if ch.isdigit()])
            if not digits:
                raise ValueError(f"{feature_name}: invalid period_in_days='{params['period_in_days']}'")
            period_days = int(digits)
            current_start_date = current_end_date - timedelta(days=period_days)
        else:
            current_start_date = current_end_date

    sql_template = load_sql_file(sql_file)

    # Day-by-day for loop
    delta = current_end_date - current_start_date
    num_days = delta.days + 1  # +1 to include the end_date itself

    for i in range(num_days):
        processing_date_start = current_start_date + timedelta(days=i)
        processing_date_end = current_start_date + timedelta(days=i+period_days)
        processing_date_start_str = processing_date_start.strftime('%Y-%m-%d')
        processing_date_end_str = processing_date_end.strftime('%Y-%m-%d')

        logger.info("Processing %s v%s for date: %s", feature_name, feature_version, processing_date_end_str)

        # Raw Data check INSIDE the loop for the specific processing date
        if source_table:
            logger.info("Verifying raw data for %s on date %s", source_table, processing_date_start_str)
            has_raw_data = check_raw_tables(source_table, check_date=processing_date_start_str) 
            if not has_raw_data:
                error_msg = f"Raw data is missing for {source_table} on {processing_date_start_str}. Cannot proceed."
                logger.error(error_msg)
                notify_failure(feature_name, "Raw Data Missing", error_msg)
                raise RuntimeError(error_msg)

        # Format SQL with the same date for min and max (single day execution)
        insert_sql = sql_template.format(
            destination_table=destination_table,
            FEATURE_NAME=feature_name,
            FEATURE_VERSION=feature_version,
            min_pkt_date=processing_date_start_str,
            max_pkt_date=processing_date_end_str,
        )
        print(insert_sql)
        
        # Use the 30-minute timeout wrapper instead of calling trino() directly
        res = execute_trino_with_timeout(trino, insert_sql, feature_name, timeout_seconds=1800)
        
        if not res.get("success"):
            print(res)
            raise RuntimeError(f"SQL failed for date {processing_date_end_str}: {res}")

        # Update last_successful_run in DB immediately after a successful day
        try:
            update_last_successful_run(feature_name, feature_version, processing_date_end_str)
        except Exception as db_err:
            error_msg = f"Failed to update last_successful_run for {feature_name} v{feature_version}: {str(db_err)}\n{traceback.format_exc()}"
            logger.error(error_msg)
            notify_failure(feature_name, "Database Update Error", error_msg)
            raise

        # Push the latest data for this feature to ClickHouse immediately
        try:
            logger.info("Pushing feature %s v%s to ClickHouse for date %s...", feature_name, feature_version, processing_date_end_str)
            process_single_feature_to_clickhouse(
                feature_name=feature_name,
                feature_version=feature_version,
                run_date=processing_date_end_str
            )
        except Exception as ch_err:
            error_msg = f"ClickHouse ingestion failed for {feature_name} v{feature_version}: {str(ch_err)}\n{traceback.format_exc()}"
            logger.error(error_msg)
            notify_failure(feature_name, "ClickHouse Ingestion Error", error_msg)
            raise ch_err

    return {"success": 1, "message": f"Processed from {current_start_date} to {current_end_date} successfully."}
