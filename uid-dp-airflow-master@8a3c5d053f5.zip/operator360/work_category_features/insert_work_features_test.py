from datetime import datetime, timedelta, date
import logging
import traceback
import pandas as pd
from trino.dbapi import connect
import os
import pytz

from operator360.utils.raw_table_validation import check_raw_tables, get_last_successful_run
# NEW: Imported the alert and timeout wrapper functions
from operator360.utils.pipeline_alerts_test import execute_trino_with_timeout, notify_failure

# NEW: Imported the ClickHouse ingestion function
from operator360.clickhouse_serving_layer.opt360_clickhouse_feature_store_test import process_single_feature_to_clickhouse

logger = logging.getLogger(__name__)
trino_port = "8080"
trino_user = "opt360job"
trino_host='10.10.116.75'

os.environ.pop("HTTP_PROXY", None)
os.environ.pop("http_proxy", None)
os.environ.pop("HTTPS_PROXY", None)
os.environ.pop("https_proxy", None)
ist = pytz.timezone('Asia/Kolkata')

def trino(query, host=trino_host, port=trino_port, user=trino_user):
    q_lower = query.strip().lower()
    conn = connect(host=host, port=port, user=user)
    cur = conn.cursor()
    cur.execute(query)
    if q_lower.startswith(("select", "with", "show", "describe", "explain")):
        body = cur.fetchall()
        cols = [i[0] for i in cur.description] if cur.description else []
        df = pd.DataFrame(body, columns=cols) if cols else pd.DataFrame(body)
        return {"query": query, "success": 1, "data": (cols, body), "df": df}
    return {"query": query, "success": 1}

def load_sql_file(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f: return f.read()

def _parse_dependent_features(dep_val):
    params = {}
    if isinstance(dep_val, list): items = dep_val
    elif isinstance(dep_val, str): items = [i.strip().strip("'").strip('"') for i in dep_val.strip().strip("[]").split(",") if i.strip()]
    else: items = []
    for item in items:
        if isinstance(item, str) and ":" in item: k, v = item.split(":", 1); params[k.strip()] = v.strip()
    return params

# def get_last_successful_run(feature_id):
#     """Fetches the last successful run date for a feature from opt360_features."""
#     query = f"SELECT last_successful_run FROM strot.operator360_stagging.opt360_features WHERE feature_id = '{feature_id}'"
#     try:
#         res = trino(query)
#         df = res.get("df")
#         if df is not None and not df.empty:
#             val = df.iloc[0, 0]
#             # NEW REQUIREMENT: Explicitly check for None or blank string
#             if val and str(val).strip() != '':
#                 return datetime.strptime(str(val).split(" ")[0], '%Y-%m-%d').date()
#     except Exception as e:
#         # Log the error but DO NOT send an email, as per requirement.
#         logging.error("Failed to fetch last_successful_run for %s: %s", feature_id, e)
#     return None

def update_last_successful_run(feature_name, feature_version, run_date):
    """Updates the last_successful_run timestamp for a specific feature."""
    query = (
        f"UPDATE strot.operator360_stagging.opt360_features "
        f"SET last_successful_run = timestamp '{run_date} 00:00:00' "
        f"WHERE feature_name = '{feature_name}' AND version = '{feature_version}'"
    )
    res = trino(query)
    if not res.get("success"): raise RuntimeError(f"Failed to update last_successful_run: {res}")

def run_one_feature(feature_name: str, feature_version: int, sql_file: str, end_date: str = None, start_date: str = None, source_table: str = None, feature_id: str = None):
    q = f"SELECT destination_table, dependent_features, update_window FROM strot.operator360_stagging.opt360_features WHERE feature_name = '{feature_name}' AND version = '{feature_version}'"
    reg = trino(q)
    if 'df' not in reg: raise ValueError(f"trino query failed, returned no df: {reg}")
    df = reg.get("df")
    if df is None or df.empty: raise ValueError(f"Feature not found in registry: {feature_name} v{feature_version}")

    row = df.iloc[0]
    destination_table = row.get("destination_table")
    params = _parse_dependent_features(row.get("dependent_features"))

    if end_date:
        try: current_end_date = datetime.strptime(str(end_date).split(" ")[0], '%Y-%m-%d').date()
        except ValueError: current_end_date = datetime.now(ist).date()
    else: current_end_date = datetime.now(ist).date()

    period_days = 1
    
    if not start_date and feature_id:
        last_run = get_last_successful_run(feature_id)
        if last_run:
            start_date = (last_run + timedelta(days=1)).strftime('%Y-%m-%d')
            if (last_run + timedelta(days=1)) > current_end_date:
                logger.info("Feature %s already up to date (last_run=%s, end_date=%s). Skipping.", feature_name, last_run, current_end_date)
                return {"success": 1, "message": "Feature already up to date. Skipped."}
        else:
            logger.info("last_successful_run is null/blank for %s. Defaulting start_date to end_date (%s). No alert sent.", feature_name, current_end_date)
            start_date = current_end_date.strftime('%Y-%m-%d')

    if start_date:
        try: current_start_date = datetime.strptime(str(start_date).split(" ")[0], '%Y-%m-%d').date()
        except ValueError: current_start_date = current_end_date
    else:
        if params.get("min_pkt_date"):
            current_start_date = datetime.strptime(str(params.get("min_pkt_date")).split(" ")[0], '%Y-%m-%d').date()
        elif params.get("period_in_days"):
            period_map = {"daily": 1, "weekly": 7, "monthly": 30}
            period_raw = str(params["period_in_days"]).strip().lower()
            if period_raw in period_map:
                period_days = period_map[period_raw]
            else:
                digits = "".join([ch for ch in period_raw if ch.isdigit()])
                if not digits: raise ValueError(f"invalid period_in_days")
                period_days = int(digits)
            current_start_date = current_end_date - timedelta(days=period_days)
        else: current_start_date = current_end_date

    sql_template = load_sql_file(sql_file)
    delta = current_end_date - current_start_date
    num_days = delta.days + 1

    for i in range(num_days):
        processing_date_start = current_start_date + timedelta(days=i)
        processing_date_end = current_start_date + timedelta(days=i+period_days)
        processing_date_start_str = processing_date_start.strftime('%Y-%m-%d')
        processing_date_end_str = processing_date_end.strftime('%Y-%m-%d')

        logger.info("Processing %s v%s for date range:%s - %s", feature_name, feature_version, processing_date_start_str,processing_date_end_str)

        if source_table:
            has_raw_data = check_raw_tables(source_table, check_date=processing_date_start_str) 
            if not has_raw_data:
                error_msg = f"Raw data is missing for {source_table} on {processing_date_start_str}. Cannot proceed."
                logger.error(error_msg)
                notify_failure(feature_name, "Raw Data Missing", error_msg)
                raise RuntimeError(error_msg)

        # --- MERGED BIO/DOC LOGIC: UNIVERSAL SQL FORMATTING ---
        filter_condition = params.get("filter_condition", "")
        filter_clause = f"AND {filter_condition}" if str(filter_condition).strip() else ""
        
        is_cumulative = 'cumulative' in feature_name
        is_monthly = 'monthly' in feature_name
        eid_collection = params.get("eid_collection", "False")
        dependent_feature_id = params.get("dependent_feature_id", None)
        
        if (is_cumulative or is_monthly) and not dependent_feature_id:
            raise ValueError(f"{feature_name} missing the dependent_feature_id as it is a cumulative/monthly feature")
            
        if is_monthly:
            if eid_collection == "True":
                eids_required = ''',
                    concat('eids:[', array_join(
                        array_agg(
                            distinct regexp_extract(comments, '\[([^\]]+)\]', 1)
                        ),
                        ','
                    ), ']') as merged_eids
                '''
                req_comments = "merged_eids  AS comments "
            else:
                eids_required = ''
                req_comments = " ''  AS comments "
        elif is_cumulative:
            eids_required = ''
            req_comments = " ''  AS comments "
        else:
            if eid_collection == "True":
                eids_required = ", array_distinct(array_agg(packeteid)) as eids"
                req_comments = "'eids: [' || CAST(array_join(eids, ',') AS VARCHAR)  || ']'  AS comments "
            else:
                eids_required = ""
                req_comments = " ''  AS comments "

        insert_sql = sql_template.format(
            destination_table=destination_table,
            FEATURE_NAME=feature_name,
            FEATURE_VERSION=feature_version,
            min_pkt_date=processing_date_start_str,
            max_pkt_date=processing_date_end_str,
            filter_condition=filter_clause,
            eids_required=eids_required,
            req_comments=req_comments,
            dependent_feature_id=dependent_feature_id if dependent_feature_id else ""
        )
        
        print(insert_sql)
        # -------------------------------------------------------

        res = execute_trino_with_timeout(trino, insert_sql, feature_name, timeout_seconds=1800)
        if not res.get("success"): raise RuntimeError(f"SQL failed for date {processing_date_start_str}: {res}")

        try:
            update_last_successful_run(feature_name, feature_version, processing_date_start_str)
        except Exception as db_err:
            error_msg = f"Failed to update last_successful_run for {feature_name} v{feature_version}: {str(db_err)}\n{traceback.format_exc()}"
            logger.error(error_msg)
            notify_failure(feature_name, "Database Update Error", error_msg)
            raise

        try:
            logger.info("Pushing feature %s v%s to ClickHouse for date %s...", feature_name, feature_version, processing_date_end_str)
            process_single_feature_to_clickhouse(feature_name=feature_name, feature_version=feature_version, run_date=processing_date_start_str)
        except Exception as ch_err:
            error_msg = f"ClickHouse ingestion failed for {feature_name} v{feature_version}: {str(ch_err)}\n{traceback.format_exc()}"
            logger.error(error_msg)
            notify_failure(feature_name, "ClickHouse Ingestion Error", error_msg)
            raise ch_err

    return {"success": 1, "message": f"Processed from {current_start_date} to {current_end_date} successfully."}