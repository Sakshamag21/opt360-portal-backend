insert into {destination_table}
with tab1 as(
    select 
        upper(operator_id) as entity_id,
        count(1) as adult_enrolment_count_cumulative
    from strot.mysql_uid_v2.request_tracker
    where type = 'N'
      and is_child = 'N'
      and date(upload_time) >= date('2026-01-01')
      and date(upload_time) < date('{max_pkt_date}')
    group by 1
)
SELECT
  entity_id,
  '{FEATURE_NAME}_v{FEATURE_VERSION}' AS feature_id,
  '{FEATURE_NAME}' AS feature_name,
  '{FEATURE_VERSION}' AS feature_version,
  cast(adult_enrolment_count_cumulative as DOUBLE) AS feature_value,
  current_timestamp AT TIME ZONE 'Asia/Kolkata' AS "timestamp",
  'Cumulative total count of adult enrolments from 2026-01-01 up to {max_pkt_date}' AS comments
from tab1
