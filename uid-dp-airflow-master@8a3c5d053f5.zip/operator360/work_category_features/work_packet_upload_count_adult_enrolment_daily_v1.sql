insert into {destination_table}
with tab1 as(
    select 
        upper(operator_id) as entity_id,
        sum(case when is_child = 'N' then 1 else 0 end) as adult_enrolment_count
    from strot.mysql_uid_v2.request_tracker
    where type = 'N'
      and is_child = 'N'
      and date(upload_time) >= date('{min_pkt_date}')
      and date(upload_time) < date('{max_pkt_date}')
    group by 1
)
SELECT
  entity_id,
  '{FEATURE_NAME}_v{FEATURE_VERSION}' AS feature_id,
  '{FEATURE_NAME}' AS feature_name,
  '{FEATURE_VERSION}' AS feature_version,
  cast(adult_enrolment_count as DOUBLE) AS feature_value,
  current_timestamp AT TIME ZONE 'Asia/Kolkata' AS "timestamp",
  'Daily count of adult enrolments between {min_pkt_date} and {max_pkt_date}' AS comments
from tab1