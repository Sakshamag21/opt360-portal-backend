from datetime import datetime

from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from airflow.providers.smtp.notifications.smtp import SmtpNotifier
from zoho_alerts import zoho_failure_callback
from kubernetes.client import models as k8s


NAMESPACE = "strot-spark"
SERVICE_ACCOUNT = "strot-service-account"
STORAGE_CLASS = "ceph-xfs"
JOB_FILE = "deceased_historical_kafka_publish"

# Email notifiers for failure alerts
retry_notifier = SmtpNotifier(
    from_email="strot@uidai.net.in",
    to=[
        "techexecutive14-yp23@uidai.net.in"
    ],
    subject="Airflow Alert: Task {{ ti.task_id }} Failed (Attempt {{ ti.try_number }})"
)

default_args = {
    "owner": "harshag.nisg",
    "depends_on_past": False,
    "start_date": datetime(2026, 9, 3),
    "retries": 1,
    "on_retry_callback": [retry_notifier],
    "on_failure_callback": zoho_failure_callback,
}

dag = DAG(
    "deceased_historical_kafka_publish",
    default_args=default_args,
    description="One-time historical deceased UID Kafka publisher",
    schedule_interval=None,
    catchup=False,
    tags=["deceased", "kafka", "historical"],
)

toleration = k8s.V1Toleration(
    key="strot", operator="Equal", value="true", effect="NoSchedule"
)

publish = KubernetesPodOperator(
    task_id="publish_deceased_uid_subaua_pairs",
    name="deceased-historical-kafka-publisher",
    namespace=NAMESPACE,
    service_account_name=SERVICE_ACCOUNT,
    image="hbdc-harbor-registry-prod.uidai.net.in/data-platform/pyspark:3.4.2_3",
    container_resources=k8s.V1ResourceRequirements(
        requests={"cpu": "1", "memory": "2Gi"},
        limits={"cpu": "1", "memory": "2Gi"},
    ),
    config_file="/opt/airflow/dags/gpu_kubeconfig_hdc",
    tolerations=[toleration],
    cmds=["/bin/bash", "-c"],
    arguments=[f"""/opt/spark/bin/spark-submit \
--master k8s://https://10.10.102.220:443 \
--deploy-mode cluster \
--name z-deceased-historical-kafka-publish-driver \
--conf spark.kubernetes.container.image=hbdc-harbor-registry-prod.uidai.net.in/data-platform/pyspark:3.4.2_3 \
--conf spark.kubernetes.namespace={NAMESPACE} \
--conf spark.driver.cores=4 \
--conf spark.executor.cores=8 \
--conf spark.executor.instances=8 \
--conf spark.driver.memory=120g \
--conf spark.executor.memory=256g \
--conf spark.driver.memoryOverhead=16g \
--conf spark.executor.memoryOverhead=48g \
--conf spark.kubernetes.driver.limit.cores=4 \
--conf spark.kubernetes.executor.limit.cores=8 \
--conf spark.kubernetes.driver.request.cores=4 \
--conf spark.kubernetes.executor.request.cores=8 \
--conf spark.kubernetes.driver.ownPersistentVolumeClaim=true \
--conf spark.kubernetes.driver.reusePersistentVolumeClaim=true \
--conf spark.kubernetes.local.dirs.tmpfs=true \
--conf spark.shuffle.sort.io.plugin.class=org.apache.spark.shuffle.KubernetesLocalDiskShuffleDataIO \
--conf spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.options.claimName=OnDemand \
--conf spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.options.storageClass={STORAGE_CLASS} \
--conf spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.options.sizeLimit=400Gi \
--conf spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.mount.path=/data \
--conf spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.mount.readOnly=false \
--conf spark.local.dir=/data/temp \
--conf spark.sql.warehouse.dir=/data/sqlwarehouse \
--conf hadoop.tmp.dir=/data/hadoop_temp \
--conf spark.hadoop.fs.s3a.impl=org.apache.hadoop.fs.s3a.S3AFileSystem \
--conf spark.hadoop.fs.s3a.path.style.access=true \
--conf spark.hadoop.fs.s3a.secret.key=XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4 \
--conf spark.hadoop.fs.s3a.access.key=9S0KLIQO7T2XCNGH4P4A \
--conf spark.hadoop.fs.s3a.endpoint=http://10.10.103.12:425 \
--conf spark.hadoop.fs.s3a.bucket.prd-bi-data-platform-test.secret.key=1NsEKbrullapyCrWZw4mbOnAG6yCyXrPK5M7KLEO \
--conf spark.hadoop.fs.s3a.bucket.prd-bi-data-platform-test.access.key=FY9PRV9EN12ACC5VZWBX \
--conf spark.hadoop.fs.s3a.bucket.prd-bi-data-platform-test.endpoint=http://10.10.103.253:80 \
--conf spark.hadoop.fs.s3a.bucket.prd-bi-data-platform-lake-refid-subaua-store-00.secret.key=1NsEKbrullapyCrWZw4mbOnAG6yCyXrPK5M7KLEO \
--conf spark.hadoop.fs.s3a.bucket.prd-bi-data-platform-lake-refid-subaua-store-00.access.key=FY9PRV9EN12ACC5VZWBX \
--conf spark.hadoop.fs.s3a.bucket.prd-bi-data-platform-lake-refid-subaua-store-00.endpoint=http://10.10.103.253:80 \
--conf spark.sql.extensions=org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions \
--conf spark.sql.catalog.strot=org.apache.iceberg.spark.SparkCatalog \
--conf spark.sql.catalog.strot.type=hive \
--conf spark.sql.catalog.strot.uri=thrift://10.10.116.77:9083 \
--conf spark.sql.catalog.flink_stream=org.apache.iceberg.spark.SparkCatalog \
--conf spark.sql.catalog.flink_stream.type=hive \
--conf spark.sql.catalog.flink_stream.uri=thrift://10.10.118.50:9083 \
--conf spark.sql.catalog.warm_store=org.apache.iceberg.spark.SparkCatalog \
--conf spark.sql.catalog.warm_store.type=hive \
--conf spark.sql.catalog.warm_store.uri=thrift://10.10.118.2:9083 \
--conf spark.kubernetes.authenticate.driver.serviceAccountName={SERVICE_ACCOUNT} \
--jars local:///opt/spark/jars/hadoop-aws-3.3.4.jar,local:///opt/spark/jars/iceberg-spark-runtime-3.4_2.12-1.5.2.jar,local:///opt/spark/jars/mysql-connector-java-8.0.30.jar \
s3a://prd-bi-data-platform-uploads/sparkjobs/{JOB_FILE}.py"""],
    in_cluster=False,
    get_logs=True,
    log_events_on_failure=True,
    dag=dag,
)