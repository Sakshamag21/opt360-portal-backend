import os
import gc
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, when, coalesce
import concurrent.futures

# Configuration
MYSQL_USER = "data_platform_R"
MYSQL_PASS = "Data_p!atform_7634"
ICEBERG_TABLE = "strot.mysql_uid_v2.uid_master_address"
CUTOFF_DATE = "2026-07-01 00:00:00"

spark = SparkSession.builder.appName("uid_master_address_backfill") \
    .config("spark.driver.extraJavaOptions", "-XX:+UseG1GC -XX:G1HeapRegionSize=32m -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError='echo \"OutOfMemoryError occurred\"'") \
    .config("spark.executor.extraJavaOptions", "-XX:+UseG1GC -XX:G1HeapRegionSize=32m -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError='echo \"OutOfMemoryError occurred\"'") \
    .config("spark.decommission.enabled", "true") \
    .config("spark.storage.decommission.shuffleBlocks.enabled", "true") \
    .config("spark.sql.broadcastTimeout", "6000") \
    .config("spark.default.parallelism","800") \
    .config("spark.sql.shuffle.partitions", "800") \
    .config("spark.network.timeout", "8000s") \
    .config("spark.executor.heartbeatInterval", "2000s") \
    .config("spark.sql.files.maxPartitionBytes","128m") \
    .config("spark.sql.adaptive.enabled", "true") \
    .config("spark.sql.legacy.mysql.bitArrayMapping.enabled","true") \
    .config("spark.sql.optimizer.disabledRules", "org.apache.spark.sql.catalyst.optimizer.SimplifyCasts") \
    .getOrCreate()

# Simplified host-to-shard mapping
HOST_MAPPINGS = [
    ("10.10.108.231", 20, 35),
    ("10.10.108.232", 36, 51),
    ("10.10.108.233", 52, 67),
    ("10.10.108.234", 68, 83),
    ("10.10.108.235", 84, 99)
]

def read_shard_to_df(host, shard):
    try:
        db_name = f"uidv2_0_{shard:02d}"
        shard_str = f"{shard:02d}"
        print(f"--> [Thread] Starting shard {shard} on {host}...")
        
        # Shared SELECT clause for both halves of the FULL OUTER JOIN emulation
        select_cols = f"""
            m.uid_master_key,
            a.addr_key,
            COALESCE(m.uid, a.uid) AS uid,
            m.uid_status_key,
            m.res_dob_year,
            m.res_guardian_uid,
            m.res_guardian_eid,
            m.res_mobile_num_hash,
            m.res_email_id_hash,
            m.bnk_shre_cnsnt,
            m.info_shre_cnsnt,
            m.verification_type,
            m.Poi AS poi,
            m.Poa AS poa,
            m.Pob AS pob,
            m.hof_proof,
            m.other_proof,
            m.res_lang_code,
            m.biometric_flag,
            CAST(m.biometric_exception_ind AS CHAR) AS biometric_exception_ind,
            m.isNRI AS isnri,
            m.isForeigner AS isforeigner,
            m.nationality_code,
            m.res_dod,
            m.issue_date,
            m.uid_expiry_date,
            m.created_by AS master_created_by,
            m.creation_date AS master_creation_date,
            m.last_updated_by AS master_last_updated_by,
            m.last_updated_date AS master_last_updated_date,
            a.res_addr_vtc_code,
            a.res_addr_vtc_name,
            a.res_addr_vtc_name_local,
            a.res_addr_district_code,
            a.res_addr_district_name,
            a.res_addr_district_name_local,
            a.res_addr_subdistrict_code,
            a.res_addr_subdistrict_name,
            a.res_addr_subdistrict_name_local,
            a.res_addr_state_code,
            a.res_addr_state_name,
            a.res_addr_state_name_local,
            a.res_addr_po_name,
            a.res_addr_po_name_local,
            a.res_addr_pincode,
            a.res_f_addr_line1,
            a.res_f_addr_line1_local,
            a.res_f_addr_line2,
            a.res_f_addr_line2_local,
            a.res_f_addr_line3,
            a.res_f_addr_line3_local,
            a.res_addr_country_code,
            a.res_addr_country_name,
            a.res_addr_country_name_local,
            a.created_by AS addr_created_by,
            a.creation_date AS addr_creation_date,
            a.last_updated_by AS addr_last_updated_by,
            a.last_updated_date AS addr_last_updated_date,
            GREATEST(
                IFNULL(m.last_updated_date, CAST('1970-01-01 00:00:00' AS DATETIME)),  -- <--- FIXED HERE
                IFNULL(a.last_updated_date, CAST('1970-01-01 00:00:00' AS DATETIME))   -- <--- FIXED HERE
            ) AS last_updated_date,
            NOW() AS pipeline_insert_ts,
            {shard} AS shard_hint
        """

        # MySQL FULL OUTER JOIN emulation (LEFT JOIN UNION ALL RIGHT JOIN anti-join)
        # Includes Safety Filter: LEFT(uid, 2) matches shard hint
        # Includes Cutoff Filter: GREATEST last_updated_date <= '2026-07-01'
        mysql_query = f"""
            SELECT {select_cols}
            FROM uid_master m
            LEFT JOIN uid_address a ON m.uid = a.uid
            WHERE LEFT(m.uid, 2) = '{shard_str}'
              AND GREATEST(
                  IFNULL(m.last_updated_date, CAST('1970-01-01 00:00:00' AS DATETIME)),  -- <--- FIXED HERE
                  IFNULL(a.last_updated_date, CAST('1970-01-01 00:00:00' AS DATETIME))   -- <--- FIXED HERE
              ) <= '{CUTOFF_DATE}'
            
            UNION ALL
            
            SELECT {select_cols}
            FROM uid_address a
            LEFT JOIN uid_master m ON m.uid = a.uid
            WHERE m.uid IS NULL 
              AND LEFT(a.uid, 2) = '{shard_str}'
              AND GREATEST(
                  IFNULL(m.last_updated_date, CAST('1970-01-01 00:00:00' AS DATETIME)),
                  IFNULL(a.last_updated_date, CAST('1970-01-01 00:00:00' AS DATETIME))
              ) <= '{CUTOFF_DATE}'
        """

        joined_df = spark.read.format("jdbc") \
            .option("url", f"jdbc:mysql://{host}:3306/{db_name}?zeroDateTimeBehavior=convertToNull&connectTimeout=300000&socketTimeout=900000") \
            .option("dbtable", f"({mysql_query}) as t") \
            .option("user", MYSQL_USER) \
            .option("password", MYSQL_PASS) \
            .option("driver", "com.mysql.cj.jdbc.Driver") \
            .option("fetchsize", 20000) \
            .load()

        # Select columns in exact order matching Iceberg table to ensure clean MERGE
        cols_in_order = [
            "uid_master_key", "addr_key", "uid", "uid_status_key", "res_dob_year",
            "res_guardian_uid", "res_guardian_eid", "res_mobile_num_hash", "res_email_id_hash",
            "bnk_shre_cnsnt", "info_shre_cnsnt", "verification_type", "poi", "poa", "pob",
            "hof_proof", "other_proof", "res_lang_code", "biometric_flag", "biometric_exception_ind",
            "isnri", "isforeigner", "nationality_code", "res_dod", "issue_date", "uid_expiry_date",
            "master_created_by", "master_creation_date", "master_last_updated_by", "master_last_updated_date",
            "res_addr_vtc_code", "res_addr_vtc_name", "res_addr_vtc_name_local", "res_addr_district_code",
            "res_addr_district_name", "res_addr_district_name_local", "res_addr_subdistrict_code",
            "res_addr_subdistrict_name", "res_addr_subdistrict_name_local", "res_addr_state_code",
            "res_addr_state_name", "res_addr_state_name_local", "res_addr_po_name", "res_addr_po_name_local",
            "res_addr_pincode", "res_f_addr_line1", "res_f_addr_line1_local", "res_f_addr_line2",
            "res_f_addr_line2_local", "res_f_addr_line3", "res_f_addr_line3_local", "res_addr_country_code",
            "res_addr_country_name", "res_addr_country_name_local", "addr_created_by", "addr_creation_date",
            "addr_last_updated_by", "addr_last_updated_date", "last_updated_date", "pipeline_insert_ts", "shard_hint"
        ]
        # joined_df.show(truncate=False)
        result_df = joined_df.select(*[col(c) for c in cols_in_order]).repartition(100)
        return result_df

    except Exception as e:
        print(f"!!! [Thread] Error processing shard {shard}: {str(e)}")
        return None

def main():
    try:
        # Process 1 shard at a time sequentially
        for host, min_shard, max_shard in HOST_MAPPINGS:
            for shard in range(min_shard, max_shard + 1):
                
                df = read_shard_to_df(host, shard)
                
                if df is None:
                    print(f"=== Shard {shard} skipped due to previous error ===")
                    continue

                print(f"=== Merging shard {shard} to Iceberg ===")
                
                # Create Temp View for MERGE
                df.createOrReplaceTempView("temp_merge_source")
                
                # Execute Iceberg MERGE using null-safe equality (<=>)
                spark.sql(f"""
                    MERGE INTO {ICEBERG_TABLE} t
                    USING temp_merge_source s
                    ON t.shard_hint = s.shard_hint and t.uid <=> s.uid 
                       AND t.uid_master_key <=> s.uid_master_key 
                       AND t.addr_key <=> s.addr_key
                    WHEN MATCHED THEN UPDATE SET *
                    WHEN NOT MATCHED THEN INSERT *
                """)

                print(f"=== Shard {shard} completed ===")
                
                # Cleanup
                spark.catalog.dropTempView("temp_merge_source")
                del df
                gc.collect()

    finally:
        print("All processing finished.")

main()
spark.stop()