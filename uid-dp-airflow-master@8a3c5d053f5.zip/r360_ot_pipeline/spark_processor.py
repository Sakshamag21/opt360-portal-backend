#spark_processor.py
from pyspark.sql import SparkSession


class SparkProcessor:

    def __init__(self, task_name : str, shared_layer_path: str, earliest_eid_ts):
        spark = SparkSession.builder \
        .remote("sc://spark-connect-service.data-platform.svc.cluster.local:15002") \
        .appName("task_name") \
        .config("spark.sql.session.timeZone", "Asia/Kolkata") \
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
        .config("spark.sql.adaptive.enabled", "true") \
        .config("spark.sql.shuffle.partitions", "128") \
        .config("spark.sql.files.maxPartitionBytes", "256m") \
        .config("spark.rpc.message.maxSize", "512") \
        .config("spark.sql.session.timeZone", "Asia/Kolkata") \
        .getOrCreate()
        spark_df = spark.read.parquet(shared_layer_path)
        view_name = f"view_{task_name}"
        spark_df.createOrReplaceTempView(view_name)
        self.spark = spark
        self.view_name = view_name
        self.eid_ts = earliest_eid_ts

    def execute_sql_file(self,sql):
        sql = sql.format(shared_layer_view=self.view_name, eid_ts = self.eid_ts)
        self.spark.sql(sql)
   
    def close(self):
        if self.spark:
            self.spark.catalog.dropTempView(self.view_name)
            self.spark.catalog.clearCache()
            self.spark.stop()
        

    