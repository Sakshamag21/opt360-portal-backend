import sys

from datetime import datetime
from pytz import timezone
import logging

from checkpoint_manager import CheckpointManager
from spark_processor import SparkProcessor
from duckdb_processor import DuckDBProcessor

IST = timezone("Asia/Kolkata")

logger = logging.getLogger("orchestrator")
logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
handler.setFormatter(formatter)
if not logger.handlers:
    logger.addHandler(handler)

sources = ["origin_tracker", "uid_his_master", "uid_his_address"]

CHECKPOINT_BUCKET = "prd-bi-data-platform-feature-resident360-00"
SOURCE_BUCKET = "prd-bi-data-platform-feature-resident360-00"
SHARED_LAYER_BUCKET = "prd-bi-data-platform-feature-resident360-00"
BUCKET = "prd-bi-data-platform-feature-resident360-00"

CHECKPOINT_PREFIX_BASE = "checkpoint/uid_origin_tracker_address_master_pipeline_resident360/"
SOURCE_PREFIX_BASE = "cdc-raw/{source}/"
SHARED_LAYER_PREFIX_BASE = "duckdb-produced/uid_origin_tracker_address_master_pipeline_resident360/{source}/"

DUCKDB_SQL_MAP = {
    "origin_tracker": "sql/uid_origin_tracker_address_master_pipeline_resident360/ot_duckdb_query.sql",
    "uid_his_master": "sql/uid_origin_tracker_address_master_pipeline_resident360/hm_duckdb_query.sql",
    "uid_his_address": "sql/uid_origin_tracker_address_master_pipeline_resident360/ha_duckdb_query.sql",
}

SPARK_SQL_MAP = {
    "origin_tracker": "sql/uid_origin_tracker_address_master_pipeline_resident360/ot_spark_query.sql",
    "uid_his_master": "sql/uid_origin_tracker_address_master_pipeline_resident360/hm_spark_query.sql",
    "uid_his_address": "sql/uid_origin_tracker_address_master_pipeline_resident360/ha_spark_query.sql",
}


def runTask(table_name):
    sourcePrefix = SOURCE_PREFIX_BASE.format(source=table_name)
    checkpointPrefix = CHECKPOINT_PREFIX_BASE + table_name + "/"
    sharedLayerPrefix = SHARED_LAYER_PREFIX_BASE.format(source=table_name)

    try:
        cp_mgr = CheckpointManager(
            checkPointBucket=CHECKPOINT_BUCKET,
            checkPointPrefix=checkpointPrefix,
            sourceBucket=SOURCE_BUCKET,
            sourcePrefix=sourcePrefix,
        )
        files = cp_mgr.list_new_files()
    except Exception as ex:
        logger.error(f"unable to list files from s3: {ex}", exc_info=True)
        raise

    if not files:
        logger.info(f"No new files to process for {table_name}")
        return

    batch_id = datetime.now(IST).strftime("%Y-%m-%dT%H:%M:%S")
    output_path = f"s3a://{SHARED_LAYER_BUCKET}/{sharedLayerPrefix}{batch_id}/"

    duckdbProcessor = DuckDBProcessor()
    processor = None

    try:
        # DuckDB step
        duckdbProcessor.process_files(
            sql=cp_mgr.load_sql(BUCKET, DUCKDB_SQL_MAP[table_name]),
            shared_layer_path=output_path,
            s3_path=", ".join([f"'{p}'" for p in files]),
        )
        logger.info("Successfully Written Data in S3.")
        # Spark step only if parquet files exist
        if cp_mgr.has_parquet_files(SHARED_LAYER_BUCKET, f"{sharedLayerPrefix}{batch_id}/"):
            query = f"""
            SELECT MIN(STRPTIME(RIGHT(s.eid, 14), '%Y%m%d%H%M%S')) AS earliest_eid_ts
            FROM read_parquet('{output_path}*/*.parquet') AS s
            """
            df = duckdbProcessor.run_query(query)
            default_eid_ts = datetime(2026, 1, 1, 0, 0, 0)
            earliest_eid_ts = df.iloc[0]["earliest_eid_ts"] if not df.empty else default_eid_ts
            eid_ts_str = earliest_eid_ts.strftime("%Y-%m-%d %H:%M:%S")
            logger.info(f"Earliest eid Timestamp in the Current Data: {eid_ts_str}")

            processor = SparkProcessor(
                task_name=table_name + "_merge",
                shared_layer_path=output_path,
                earliest_eid_ts=eid_ts_str,
            )
            processor.execute_sql_file(
                sql=cp_mgr.load_sql(BUCKET, SPARK_SQL_MAP[table_name])
            )
        else:
            logger.info(f"No data files produced by duckdb for {table_name}.")
            logger.info("Skipping spark step.")

        # Update checkpoint only after successful DuckDB + Spark
        last_processed_file = files[-1]
        cp_mgr.set_last_processed(
            last_processed_file.replace(f"s3://{SOURCE_BUCKET}/", ""),
            len(files),
        )

    except Exception as ex:
        logger.error(f"Processing Error for {table_name}: {ex}", exc_info=True)
        raise

    finally:
        if processor is not None:
            processor.close()
        duckdbProcessor.close()
        cp_mgr.deleteFilesInS3(
            SHARED_LAYER_BUCKET,
            f"{sharedLayerPrefix}{batch_id}/"
        )


def run_all_tasks():
    for source in sources:
        logger.info(f"Starting task for source: {source}")
        try:
            runTask(source)
        except Exception as ex:
            logger.error(f"Error during {source} processing.")
        logger.info(f"Completed task for source: {source}")


if __name__ == "__main__":
    # Check if a source name was passed as an argument
    if len(sys.argv) > 1:
        source_to_run = sys.argv[1]
        if source_to_run in sources:
            logger.info(f"Starting task for source: {source_to_run}")
            runTask(source_to_run)
        else:
            logger.error(f"Unknown source: {source_to_run}")
    else:
        logger.info("No source provided.")