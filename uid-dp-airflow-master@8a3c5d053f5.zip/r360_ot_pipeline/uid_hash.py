import json
import base64
import hashlib
import boto3
# import os


def load_salt():
    try:
        session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4')
        s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425')
        s3_client.download_file('prd-bi-data-platform-configs', 'salt/salts.txt', '/tmp/salts.txt')
        with open("/tmp/salts.txt", "r") as file:
            salt_map = json.load(file)
            print("Salt mapping loaded successfully")
            return salt_map
    except Exception as e:
        print("Unable to load salts.txt:", e)
        raise RuntimeError(f"Unable to load salts.txt: {e}") from e

salts = load_salt()

def hashedUID(uid):
    if not uid:
        return None
    salt=salts[uid[:2]]
    hasher=hashlib.sha256()
    hasher.update((salt+uid).encode())
    hashed_value = hasher.digest()
    b64_hash=base64.b64encode(hashed_value).decode('utf-8')
    return b64_hash
