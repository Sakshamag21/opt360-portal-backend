#duckdb_processor.py
import duckdb
import os
import json
from pathlib import Path

from uid_hash import hashedUID

class DuckDBProcessor:
    def __init__(self):
        self.con = duckdb.connect(database=":memory:")
        self._setup()


    def _setup(self):
        self.con.execute("SET extension_directory='/opt/duckdb/extensions';")
        self.con.execute("LOAD httpfs; LOAD json;")
        self.con.execute("SET s3_endpoint = '10.10.103.12:425';")
        self.con.execute("SET s3_access_key_id = '9S0KLIQO7T2XCNGH4P4A';")
        self.con.execute("SET s3_secret_access_key = 'XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4';")
        self.con.execute("SET s3_use_ssl = false;")
        self.con.execute("SET s3_url_style = 'path';")
        self.con.execute("PRAGMA threads=8; PRAGMA memory_limit='16GB';")
        self.con.execute("PRAGMA temp_directory='/tmp/duckdb_spill';")
        self.con.execute("SET TimeZone = 'Asia/Kolkata';")
        self.con.create_function("python_hashed_uid", hashedUID, ["VARCHAR"], "VARCHAR")
    

    def process_files(self, sql, shared_layer_path, s3_path):
        sql = sql.format(shared_layer_path=shared_layer_path, s3_path=s3_path)
        self.con.execute(sql)

    def run_query(self, query):
        """
        Execute an arbitrary DuckDB query and return the result as a DataFrame.
        """
        return self.con.execute(query).df()

    def close(self):
        if self.con:
            self.con.close()