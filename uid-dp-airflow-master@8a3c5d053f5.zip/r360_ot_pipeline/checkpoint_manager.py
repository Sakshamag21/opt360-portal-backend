#checkpoint_manager.py
import boto3
import json
from datetime import datetime, timedelta
from pytz import timezone
import time
import logging

IST = timezone("Asia/Kolkata")

def ist_now_str():
    """Return current time as string in IST timezone."""
    return datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S")

logger = logging.getLogger("CheckpointManager")
logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)


class CheckpointManager:
    def __init__(self, checkPointBucket: str, checkPointPrefix: str, sourceBucket: str, sourcePrefix: str, max_retries: int = 3, retry_wait: int = 2):
        session = boto3.session.Session(
            aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',
            aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4'
        )
        self.s3 = session.client('s3', endpoint_url='http://10.10.103.12:425')
        self.checkPointBucket = checkPointBucket
        self.key = f"{checkPointPrefix}last_processed.json"
        self.sourceBucket = sourceBucket
        self.sourcePrefix = sourcePrefix
        self.max_retries = max_retries
        self.retry_wait = retry_wait
        self.history_size = 100

    def get_last_processed(self) -> dict:
        attempts = 0
        last_error = None
        while attempts < self.max_retries:
            try:
                obj = self.s3.get_object(Bucket=self.checkPointBucket, Key=self.key)
                logger.info(f"Checkpoint found: {self.key}")
                return json.loads(obj["Body"].read())
            except self.s3.exceptions.NoSuchKey:
                logger.warning(f"KEY: {self.key} NOT FOUND.")
                return {"last_key": ''}
            except Exception as ex:
                attempts += 1
                last_error = ex
                logger.error(f"[Attempt {attempts}/{self.max_retries}] Failed to get {self.key} from S3: {ex}")
                if attempts < self.max_retries:
                    time.sleep(self.retry_wait)
        logger.critical(f"Failed to fetch checkpoint after {self.max_retries} attempts, aborting.")
        raise RuntimeError(f"Failed to fetch checkpoint after {self.max_retries} attempts") from last_error

    # def set_last_processed(self, last_key: str, file_count: int):
    #     payload = {
    #         "last_key": last_key,
    #         "processed_at": datetime.now(IST).isoformat(),
    #         "file_count": file_count
    #     }
    #     data = json.dumps(payload)
    #     attempts = 0
    #     last_error = None
    #     while attempts < self.max_retries:
    #         try:
    #             self.s3.put_object(
    #                 Bucket=self.checkPointBucket,
    #                 Key=self.key,
    #                 Body=data
    #             )
    #             logger.info(f"Checkpoint updated: {self.key}")
    #             return
    #         except Exception as ex:
    #             attempts += 1
    #             last_error = ex
    #             logger.error(f"[Attempt {attempts}/{self.max_retries}] Failed to put checkpoint {self.key} to S3: {ex}")
    #             if attempts < self.max_retries:
    #                 time.sleep(self.retry_wait)
    #     logger.critical(f"Failed to set checkpoint after {self.max_retries} attempts, aborting.")
    #     raise RuntimeError(f"Failed to set checkpoint after {self.max_retries} attempts") from last_error
    
    def set_last_processed(self, last_key: str, file_count: int):
        # Fetch existing checkpoint to preserve current history
        existing_history = []
        try:
            obj = self.s3.get_object(Bucket=self.checkPointBucket, Key=self.key)
            existing_data = json.loads(obj["Body"].read())
            existing_history = existing_data.get("history", [])
        except self.s3.exceptions.NoSuchKey:
            logger.warning(f"KEY: {self.key} NOT FOUND. Starting with empty history.")
            existing_history = []
        except Exception as ex:
            logger.warning(f"Could not fetch existing checkpoint for history (continuing with empty history): {ex}")
            existing_history = []

        # Prepend the current key to history (latest at the start) and cap at history_size
        updated_history = ([last_key] + existing_history)[:self.history_size]

        payload = {
            "last_key": last_key,
            "processed_at": datetime.now(IST).isoformat(),
            "file_count": file_count,
            "history": updated_history
        }
        data = json.dumps(payload)
        attempts = 0
        last_error = None
        while attempts < self.max_retries:
            try:
                self.s3.put_object(
                    Bucket=self.checkPointBucket,
                    Key=self.key,
                    Body=data
                )
                logger.info(f"Checkpoint updated: {self.key}")
                return
            except Exception as ex:
                attempts += 1
                last_error = ex
                logger.error(f"[Attempt {attempts}/{self.max_retries}] Failed to put checkpoint {self.key} to S3: {ex}")
                if attempts < self.max_retries:
                    time.sleep(self.retry_wait)
        logger.critical(f"Failed to set checkpoint after {self.max_retries} attempts, aborting.")
        raise RuntimeError(f"Failed to set checkpoint after {self.max_retries} attempts") from last_error

    def list_new_files(self, limit: int = 2000) -> list[str]:
        cp = self.get_last_processed()
        start_after = cp.get("last_key", "")
        logger.info(f"Listing new files from {self.sourceBucket}/{self.sourcePrefix}, start after key: {start_after}")

        cutoff = datetime.now(IST) - timedelta(minutes=5)

        paginator = self.s3.get_paginator("list_objects_v2")
        pages = paginator.paginate(Bucket=self.sourceBucket, Prefix=self.sourcePrefix, StartAfter=start_after)

        files = [
            f"s3://{self.sourceBucket}/{obj['Key']}"
            for page in pages
            for obj in page.get("Contents", [])
            if obj['Key'].endswith('.parquet') and obj['LastModified'].astimezone(IST) < cutoff
        ]
        logger.info(f"Found {len(files)} new files.")
        limit = min(len(files), limit)
        files = files[:limit]
        logger.info(f"Processing {len(files)}.")
        return files

    def deleteFilesInS3(self, filesBucket, filesPrefix: str) -> bool:
        """
        Delete all files under the given S3 prefix (e.g., 'duckdb-processed/uid_his_address/').
        Returns True if deletion is fully successful; False otherwise.
        """
        try:
            paginator = self.s3.get_paginator("list_objects_v2")
            to_delete = []
            for page in paginator.paginate(Bucket=filesBucket, Prefix=filesPrefix):
                for obj in page.get("Contents", []):
                    to_delete.append({'Key': obj['Key']})
            if not to_delete:
                logger.info(f"No files to delete in s3://{filesBucket}/{filesPrefix}")
                return True
            for i in range(0, len(to_delete), 1000):
                response = self.s3.delete_objects(
                    Bucket=filesBucket,
                    Delete={'Objects': to_delete[i:i+1000]}
                )
                if "Errors" in response and response["Errors"]:
                    logger.error(f"Errors while deleting: {response['Errors']}")
                    return False
            logger.info(f"Deleted all files in s3://{filesBucket}/{filesPrefix}")
            return True
        except Exception as ex:
            logger.error(f"Exception deleting files in s3://{filesBucket}/{filesPrefix}: {ex}")
            return False

    def close(self):
        if self.s3:
            self.s3.close()

    def has_parquet_files(self, filesBucket, filesPrefix: str):
        paginator = self.s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=filesBucket, Prefix=filesPrefix):
            for obj in page.get("Contents", []):
                if obj["Key"].endswith(".parquet"):
                    return True
        return False
    
    def load_sql(self, bucket, key):
        local_sql_path = '/tmp/r360_sql.sql'
        self.s3.download_file(bucket,key,local_sql_path)
        with open(local_sql_path) as f:
            sql = f.read()
        return sql