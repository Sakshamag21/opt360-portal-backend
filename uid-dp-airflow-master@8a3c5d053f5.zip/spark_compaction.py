import os
import tempfile
from datetime import datetime, timedelta

import boto3
import yaml
from pyspark.sql import SparkSession

from airflow.sdk import DAG
from airflow.operators.python import PythonOperator


S3_BUCKET = "prd-bi-data-platform-uploads"
S3_KEY = "sparkjobs/compaction/compaction_tables.yaml"
S3_URI = f"s3://{S3_BUCKET}/{S3_KEY}"

SPARK_CONNECT_URL = "sc://spark-connect-service.data-platform.svc.cluster.local:15002"


def load_tables_from_s3():
    """
    Download compaction_tables.yaml from S3 and flatten it into
    a list of (catalog, schema, table) tuples.
    """
    session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4')
    s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425')

    with tempfile.NamedTemporaryFile(suffix=".yaml", delete=False) as tmp:
        local_path = tmp.name

    try:
        s3_client.download_file(S3_BUCKET, S3_KEY, local_path)

        with open(local_path, "r") as f:
            data = yaml.safe_load(f)

        tables = []
        for catalog, schemas_dict in data.items():
            for schema, tables_list in schemas_dict.items():
                for table in tables_list:
                    tables.append((catalog, schema, table))

        return tables
    finally:
        try:
            os.remove(local_path)
        except OSError:
            pass


def compact_table(catalog_name, schema_name, table_name):
    """
    Run Iceberg maintenance queries for one table.
    """
    spark = (
        SparkSession.builder.remote(SPARK_CONNECT_URL)
        .appName(f"spark-comp-{catalog_name}-{schema_name}-{table_name}")
        .getOrCreate()
    )

    try:
        t7 = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")
        t1 = (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d %H:%M:%S")
        full_table_name = f"{catalog_name}.{schema_name}.{table_name}"

        print("=" * 80)
        print(f"Starting compaction for table: {full_table_name}")
        print("=" * 80)

        print("Step 1: Rewriting data files (compaction)...")
        try:
            target_file_size = 512 * 1024**2
            min_file_size = int(target_file_size * 0.75)
            if table_name == "uid_master_address" :
                target_file_size = 64 * 1024**2
                min_file_size = int(target_file_size * 0.75)

            res_rewrite = spark.sql(f"""
                CALL {catalog_name}.system.rewrite_data_files(
                    table => '{schema_name}.{table_name}',
                    strategy => 'binpack',
                    options => map(
                        'target-file-size-bytes', '{target_file_size}',
                        'min-file-size-bytes', '{min_file_size}',
                        'rewrite-job-order', 'bytes-asc',
                        'partial-progress.enabled', 'true',
                        'partial-progress.max-commits', '100',
                        'delete-file-threshold', '1',
                        'remove-dangling-deletes', 'true'
                    )
                )
            """)
            res_rewrite.show(truncate=False)
            print("Data file compaction completed successfully.")
        except Exception as e:
            print(f"Error during rewrite_data_files: {e}")

        # print("Step 1b: Rewriting position delete files...")
        # try:
        #     res_delete = spark.sql(f"""
        #         CALL {catalog_name}.system.rewrite_position_delete_files(
        #             table => '{schema_name}.{table_name}',
        #             options => map(
        #                 'min-input-files', '2'
        #             )
        #         )
        #     """)
        #     res_delete.show(truncate=False)
        # except Exception as e:
        #     print(f"Error during rewrite_position_delete_files: {e}")

        print("Step 1b: Rewriting manifests...")
        try:
            res_rewrite_manifest = spark.sql(f"""
                CALL {catalog_name}.system.rewrite_manifests(
                    table => '{schema_name}.{table_name}'
                )
            """)
            res_rewrite_manifest.show(truncate=False)
        except Exception as e:
            print(f"Error during rewrite_manifests: {e}")

        print("Step 2: Expiring old snapshots...")
        try:
            if catalog_name == "flink_stream" and schema_name == "stream_auth":
                older_than = t7
            else:
                older_than = t1

            res_expire = spark.sql(f"""
                CALL {catalog_name}.system.expire_snapshots(
                    table => '{catalog_name}.{schema_name}.{table_name}',
                    older_than => TIMESTAMP '{older_than}'
                )
            """)
            res_expire.show(truncate=False)
            print("Snapshot expiration completed successfully.")
        except Exception as e:
            print(f"Error during expire_snapshots: {e}")

        print("Step 3: Removing orphan files...")
        try:
            if catalog_name == "flink_stream" and schema_name == "stream_auth":
                older_than = t7
            else:
                older_than = t1

            res_orphan = spark.sql(f"""
                CALL {catalog_name}.system.remove_orphan_files(
                    table => '{schema_name}.{table_name}',
                    older_than => TIMESTAMP '{older_than}'
                )
            """)
            res_orphan.show(truncate=False)
            print("Orphan file cleanup completed successfully.")
        except Exception as e:
            print(f"Error during remove_orphan_files: {e}")

        print("=" * 80)
        print(f"Compaction workflow completed for table: {full_table_name}")
        print("=" * 80)

    finally:
        spark.stop()


def run_compaction():
    tables = load_tables_from_s3()
    for catalog_name, schema_name, table_name in tables:
        compact_table(catalog_name, schema_name, table_name)


default_args = {
    "owner": "inzamam.nisg",
    "depends_on_past": False,
    "start_date": datetime(2026, 8, 6),
    "email": [
        "techexe15.yp25@uidai.net.in",
        "techexecutive22-yp23@uidai.net.in",
        "techexecutive14-yp23@uidai.net.in",
    ],
    "email_on_failure": True,
    "email_on_retry": True,
    "retries": 1,
}

dag = DAG(
    "SPARK_COMPACTION",
    default_args=default_args,
    description="Dag to Compact All Major Tables",
    schedule="0 2 * * *",
    catchup=False,
    tags=["COMPACTION", "SPARK"],
)

task = PythonOperator(
    task_id="iceberg_compaction_runner",
    python_callable=run_compaction,
    dag=dag,
)