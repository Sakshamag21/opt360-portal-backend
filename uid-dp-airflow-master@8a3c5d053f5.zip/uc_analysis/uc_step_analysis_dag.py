from airflow import DAG
from datetime import datetime
from airflow.settings import AIRFLOW_HOME
from airflow.exceptions import AirflowSkipException
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from airflow.providers.standard.operators.python import ShortCircuitOperator
from airflow.providers.smtp.notifications.smtp import SmtpNotifier

from kubernetes.client import models as k8s
import sys

job_name = "uc_aggregation_analysiss"
desc = "Job to publishing uc aggregation kafka messages"

schedule = "10,25,40,55 * * * *"
current_datetime = datetime.now()


retry_notifier = SmtpNotifier(
    from_email="strot@uidai.net.in",
    to=[
        "techexe16.yp25@uidai.net.in"
    ],
    # {{ ti.try_number }} will tell you exactly which attempt failed
    subject="Airflow Alert: Task {{ ti.task_id }} Failed (Attempt {{ ti.try_number }})"
)

final_failure_notifier = SmtpNotifier(
    from_email="strot@uidai.net.in",
    to=[
        "techexe16.yp25@uidai.net.in"
    ],
    subject="Airflow Alert: Task {{ ti.task_id }} Completely FAILED"
)

custom_toleration = k8s.V1Toleration(
    key="strot",
    operator='Equal',
    value='true',
    effect='NoSchedule'
)


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2026, 7, 9),
    'retries': 1,
    'on_retry_callback': [retry_notifier],      
    'on_failure_callback': [final_failure_notifier],
}

dag = DAG(
    f'{job_name}',
    default_args=default_args,
    description=f'{desc}',
    schedule=f'{schedule}',
    catchup=False,
    max_active_tasks=3,
    tags=['uc_aggregation_analysis','kafka']
)

def check_55_minute_mark(**context):
    # Airflow 2 uses logical_date instead of execution_date
    execution_minute = context['logical_date'].minute
    return execution_minute in range(50,60)

check_if_55_min = ShortCircuitOperator(
    task_id="check_if_55_min",
    python_callable=check_55_minute_mark,
    dag=dag,
)

uc_step_analysis = KubernetesPodOperator(
    namespace='strot-spark',
    service_account_name='strot-service-account',
    image="harbor-registry-prod.uidai.gov.in/data-platform/pyspark_duckdb:4.0.7", 
    config_file="/opt/airflow/dags/gpu_kubeconfig_hdc", 
    name=f"uc_step_analysis", task_id=f"uc_step_analysis", 
    cmds=["/bin/bash", "-c"],
    arguments=[
        f"""python3 -c "import boto3;session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4');s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425');s3_client.download_file('prd-bi-data-platform-uploads','sparkjobs/operator360/uc_step_data_production/head_uc_step_analysis.py','/tmp/head_uc_step_analysis.py')" && python3 /tmp/head_uc_step_analysis.py uc_step_analysis"""
    ],
    container_resources=k8s.V1ResourceRequirements(
        requests={"cpu": "2", "memory": "4Gi"},
        limits={"cpu": "2", "memory": "4Gi"}
    ),
    tolerations=[custom_toleration],
    in_cluster=False,
    get_logs=True, 
    log_events_on_failure=True, 
    dag=dag,
)

uc_distinct_optid_count_ea = KubernetesPodOperator(
    namespace='strot-spark',
    service_account_name='strot-service-account',
    image="harbor-registry-prod.uidai.gov.in/data-platform/pyspark_duckdb:4.0.7", 
    config_file="/opt/airflow/dags/gpu_kubeconfig_hdc", 
    name=f"uc_distinct_optid_count_ea", task_id=f"uc_distinct_optid_count_ea", 
    cmds=["/bin/bash", "-c"],
    arguments=[
        f"""python3 -c "import boto3;session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4');s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425');s3_client.download_file('prd-bi-data-platform-uploads','sparkjobs/operator360/uc_step_data_production/head_uc_step_analysis.py','/tmp/head_uc_step_analysis.py')" && python3 /tmp/head_uc_step_analysis.py uc_distinct_opt_id_analysis"""
    ],
    container_resources=k8s.V1ResourceRequirements(
        requests={"cpu": "2", "memory": "4Gi"},
        limits={"cpu": "2", "memory": "4Gi"}
    ),
    tolerations=[custom_toleration],
    in_cluster=False,
    get_logs=True, 
    log_events_on_failure=True, 
    dag=dag,
)


uc_step_analysis_sid = KubernetesPodOperator(
    namespace='strot-spark',
    service_account_name='strot-service-account',
    image="harbor-registry-prod.uidai.gov.in/data-platform/pyspark_duckdb:4.0.7", 
    config_file="/opt/airflow/dags/gpu_kubeconfig_hdc", 
    name=f"uc_step_analysis_sid", task_id=f"uc_step_analysis_sid", 
    cmds=["/bin/bash", "-c"],
    arguments=[
        f"""python3 -c "import boto3;session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4');s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425');s3_client.download_file('prd-bi-data-platform-uploads','sparkjobs/operator360/uc_step_data_production/head_uc_step_analysis.py','/tmp/head_uc_step_analysis.py')" && python3 /tmp/head_uc_step_analysis.py uc_step_analysis_sid"""
    ],
    container_resources=k8s.V1ResourceRequirements(
        requests={"cpu": "2", "memory": "4Gi"},
        limits={"cpu": "2", "memory": "4Gi"}
    ),
    tolerations=[custom_toleration],
    in_cluster=False,
    get_logs=True, 
    log_events_on_failure=True, 
    dag=dag,
)

uc_error_analysis = KubernetesPodOperator(
    namespace='strot-spark',
    service_account_name='strot-service-account',
    image="harbor-registry-prod.uidai.gov.in/data-platform/pyspark_duckdb:4.0.7", 
    config_file="/opt/airflow/dags/gpu_kubeconfig_hdc", 
    name=f"uc_error_analysis", task_id=f"uc_error_analysis", 
    cmds=["/bin/bash", "-c"],
    arguments=[
        f"""python3 -c "import boto3;session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4');s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425');s3_client.download_file('prd-bi-data-platform-uploads','sparkjobs/operator360/uc_step_data_production/head_uc_step_analysis.py','/tmp/head_uc_step_analysis.py')" && python3 /tmp/head_uc_step_analysis.py uc_error_analysis"""
    ],
    container_resources=k8s.V1ResourceRequirements(
        requests={"cpu": "2", "memory": "4Gi"},
        limits={"cpu": "2", "memory": "4Gi"}
    ),
    tolerations=[custom_toleration],
    in_cluster=False,
    get_logs=True, 
    log_events_on_failure=True, 
    dag=dag,
)



uc_step_analysis_sid

check_if_55_min>>uc_distinct_optid_count_ea>>uc_step_analysis

check_if_55_min>>uc_error_analysis