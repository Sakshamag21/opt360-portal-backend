import findspark
findspark.init()
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
import os
import time
from pyspark.sql.functions import col, row_number, date_format,when,struct
from pyspark.sql.window import Window
from pyspark.sql.functions import col, hex, unhex
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
from pyspark.sql.types import IntegerType
from kafka import KafkaProducer, KafkaConsumer
import uuid
import json

producer_brokers=['10.10.105.225:9092',
                  '10.10.106.171:9092',
                  '10.10.107.110:9092',
                  '10.10.105.75:9092']
output_topic = 'DE.OPT360.UC.TXN.ANALYSIS.V1'


def get_spark(job_name: str):
    spark = SparkSession.builder \
        .appName(f"uc-{job_name}") \
        .remote("sc://spark-connect-service.strot-spark.svc.cluster.local:15002") \
        .config("spark.sql.legacy.mysql.bitArrayMapping.enabled","true") \
        .config("spark.default.parallelism","800") \
        .config("spark.sql.shuffle.partitions", '800') \
        .getOrCreate()
    
    return spark

def message_structure(data):
    # Current system time in epoch seconds
    current_time_epoch = int(time.time())
    return {
        "eventId":str(uuid.uuid4()),
        "entityId":data.operator_id,
        "entity":"OPERATOR",
        "analysisType":"UC_INTER_STEP_ANALYSIS",
        "attributeKey":F"{data.stage_from} to {data.stage_to}",
        "value":"Duration (seconds)",
        "min":data.min_duration,
        "max":data.max_duration,
        "average":data.avg_duration,
        "p99":data.p99_duration,
        "p90":data.p90_duration,
        "p75":data.p75_duration,
        "comments":f"Total Transition Count: {data.total_transition_count}",
        "analysisWindow":"1hr",
        "eventTimestamp": current_time_epoch,
    }



def send_partition_to_kafka(partition ,producer_brokers= producer_brokers):
    producer = KafkaProducer(bootstrap_servers=producer_brokers, acks=1, retries=2)
    for row in partition:
        output_message= message_structure(row)
        try:
            kafka_key= str(row.operator_id).encode('utf-8')
            producer.send(topic=output_topic, 
                          key= kafka_key,
                          value=json.dumps(output_message).encode('utf-8'))
        except Exception as e:
            print(e)
        # break
        


def main():
    
    spark = get_spark('us_step_analysis')
    now = F.current_timestamp()
    start_time = now - F.expr("INTERVAL 1 HOUR 15 MINUTES")
    end_time = now - F.expr("INTERVAL 15 MINUTES")
    buffer_end_time = end_time + F.expr("INTERVAL 5 MINUTES")

    filtered_df = spark.table("flink_stream.stream_enu.enu_uc_opt_action_v2") \
        .filter(
            (F.col("event_timestamp") >= start_time) & 
            (F.col("event_timestamp") < buffer_end_time) & 
            (F.col("operator_id").isNotNull()) & (F.trim(F.col("operator_id")) != "") &
            (F.col("resident_sid").isNotNull()) & (F.trim(F.col("resident_sid")) != "")
        )

    # 4. Generate Consecutive Stages
    sid_window = Window.partitionBy("resident_sid").orderBy("event_timestamp")
    
    # Window to look across ALL rows for a resident_sid
    sid_all_rows_window = Window.partitionBy("resident_sid").rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)

    transitions_base_df = filtered_df \
        .withColumn(
            "enrolment_type", 
            # Grab the single enrolment_type value for this SID, regardless of which row it sits on
            F.first("enrolment_type", ignorenulls=True).over(sid_all_rows_window)
        ) \
        .withColumn("stage_from", F.col("stage")) \
        .withColumn("stage_from_time", F.col("event_timestamp")) \
        .withColumn("stage_to", F.lead("stage", 1).over(sid_window)) \
        .withColumn("stage_to_time", F.lead("event_timestamp", 1).over(sid_window)) \
        .filter(F.col("stage_to").isNotNull())

    # 5. Guardrail: Drop new transactions born in the buffer zone
    valid_transitions_df = transitions_base_df.filter(
        (F.col("stage_from_time") >= start_time) & 
        (F.col("stage_from_time") < end_time)
    )

    # 6. Process Metrics Window
    # Added "enrolment_type" to the partitionBy so metrics are calculated per enrolment_type
    operator_transition_window = Window.partitionBy(
        "operator_id", "stage_from", "stage_to", "enrolment_type"
    )

    final_analysis_df = valid_transitions_df.withColumn(
        "time_difference_seconds", 
        F.col("stage_to_time").cast("timestamp").cast("long") - F.col("stage_from_time").cast("timestamp").cast("long")
    ).withColumn(
        "timeperiod", 
        F.concat(F.date_format(start_time, "yyyy-MM-dd HH:mm"), F.lit(" to "), F.date_format(end_time, "yyyy-MM-dd HH:mm"))
    ).withColumn(
        "min_duration", F.min("time_difference_seconds").over(operator_transition_window)
    ).withColumn(
        "max_duration", F.max("time_difference_seconds").over(operator_transition_window)
    ).withColumn(
        "avg_duration", F.avg("time_difference_seconds").over(operator_transition_window)
    ).withColumn(
        "p90_duration", F.percentile_approx("time_difference_seconds", 0.90).over(operator_transition_window)
    ).withColumn(
        "p99_duration", F.percentile_approx("time_difference_seconds", 0.99).over(operator_transition_window)
    ).withColumn(
        "p75_duration", F.percentile_approx("time_difference_seconds", 0.75).over(operator_transition_window)
    ).withColumn(
        "total_transition_count", F.count("*").over(operator_transition_window)
    ).select(
        "operator_id", "stage_from", "stage_to", 
        "enrolment_type", # Include in final output
        "min_duration", "max_duration", "avg_duration", 
        "p99_duration", "p90_duration", "p75_duration", 
        "total_transition_count"
    )
    
    print(final_analysis_df.show(2))
    print("jskdvjsdvkds")
    
    final_analysis_df = final_analysis_df.dropDuplicates([
        "operator_id", "stage_from", "stage_to", "enrolment_type", 
        "min_duration", "max_duration", "avg_duration", 
        "p99_duration", "p90_duration", "p75_duration", "total_transition_count"
    ])
    
    print(final_analysis_df.show(10))
    final_analysis_df.foreachPartition(send_partition_to_kafka)
        
main()