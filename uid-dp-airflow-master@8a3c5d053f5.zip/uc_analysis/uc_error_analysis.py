import findspark
findspark.init()
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
import os
import time
from pyspark.sql.functions import col, row_number, date_format,when,struct
from pyspark.sql.window import Window
from pyspark.sql.functions import col, hex, unhex
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
from pyspark.sql.types import IntegerType
from kafka import KafkaProducer, KafkaConsumer
import uuid
import json
import datetime
import pytz

producer_brokers=['10.10.105.225:9092',
                  '10.10.106.171:9092',
                  '10.10.107.110:9092',
                  '10.10.105.75:9092']
output_topic = 'DE.UC.ERROR.ANALYTICS.AGGREGATION'
# output_topic='testing'

def get_spark(job_name: str):
    spark = SparkSession.builder \
    .master("local[*]") \
    .appName(f"{job_name}") \
    .config("spark.hadoop.fs.s3a.aws.credentials.provider", "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider") \
    .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
    .config("spark.hadoop.fs.s3a.path.style.access", "true") \
    .config("spark.hadoop.fs.s3a.secret.key", "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4") \
    .config("spark.hadoop.fs.s3a.access.key", "9S0KLIQO7T2XCNGH4P4A") \
    .config("spark.hadoop.fs.s3a.endpoint", "http://10.10.103.12:425") \
    .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
    .config("spark.sql.catalog.flink_stream", "org.apache.iceberg.spark.SparkCatalog") \
    .config("spark.sql.catalog.flink_stream.type", "hive") \
    .config("spark.sql.catalog.flink_stream.uri","thrift://10.10.112.24:32613") \
    .config("spark.sql.sources.partitionOverwriteMode", "dynamic") \
    .config("spark.driver.memory",'12g') \
    .config("spark.executor.memory",'60g') \
    .config("spark.executor.memoryOverhead",'20g') \
    .config("spark.memory.fraction", "0.9") \
    .config("spark.dynamicAllocation.enabled", "true") \
    .config("spark.dynamicAllocation.minExecutors", '1') \
    .config("spark.dynamicAllocation.maxExecutors", '12') \
    .config("spark.shuffle.service.enabled", "true") \
    .config("spark.dynamicAllocation.shuffleTracking.enabled", "true") \
    .config("spark.decommission.enabled", "true") \
    .config("spark.storage.decommission.shuffleBlocks.enabled", "true") \
    .config("spark.sql.broadcastTimeout", "600") \
    .config("spark.default.parallelism","200") \
    .config("spark.sql.shuffle.partitions", '200') \
    .config("spark.network.timeout", "800s") \
    .config("spark.executor.heartbeatInterval", "200s") \
    .config("spark.sql.files.maxPartitionBytes","528m") \
    .config("spark.sql.adaptive.enabled", "true") \
    .getOrCreate()
    
    return spark

def message_structure(data):
    ist_tz = pytz.timezone("Asia/Kolkata")
    ist_time = datetime.datetime.now(ist_tz)
    ist_string = ist_time.strftime("%Y-%m-%d %H:%M:%S")
    return {
        "aggregationValue": data['count'],
        "windowStartTimestamp": str(datetime.date.today()) + " 00:00:00",
        "aggregationType": "COUNT",
        "windowDuration": "hourly",
        "comments": {},
        "aggregationCount": data['count'],
        "windowEndTimestamp": ist_string,
        "publishedTimestamp": ist_string,
        "entityId": data.entity_id,
        "aggregationField": "error_type",
        "entity": data.entity,
        "error_code":data.error_type
    }
    



def send_partition_to_kafka(partition ,producer_brokers= producer_brokers):
    producer = KafkaProducer(bootstrap_servers=producer_brokers, acks=1, retries=2)
    for row in partition:
        output_message= message_structure(row)
        try:
            kafka_key= f"{(row.entity).lower()}:{row.entity_id}".encode('utf-8')
            producer.send(topic=output_topic, 
                          key= kafka_key,
                          value=json.dumps(output_message).encode('utf-8'))
        except Exception as e:
            print(e)
        # break
        


def main():
    spark= get_spark('uc_error_code_analysis')
    error_code_analysis_df=spark.sql('''
        WITH tab1 AS (
            SELECT DISTINCT eid, sid, error_type 
            FROM flink_stream.stream_enu.telemetry_uc 
            WHERE ets >= CURRENT_TIMESTAMP() - INTERVAL 1 HOUR
        ),
    
        tab2 AS (
            SELECT DISTINCT station_machine_code, upper(operator_id) as operator_id, resident_sid, enrolment_type, stage, txn_id 
            FROM flink_stream.stream_enu.enu_uc_opt_action_v2 
            WHERE event_timestamp >= CURRENT_TIMESTAMP() - INTERVAL 1 HOUR
        ),
    
        tab3 AS (
            SELECT t1.error_type, t2.operator_id, t2.stage, t2.station_machine_code, t2.enrolment_type
            FROM tab2 t2 
            LEFT JOIN tab1 t1 ON t2.txn_id = t1.eid 
        )
    
        SELECT error_type, COUNT(*) AS count, operator_id AS entity_id, "Operator" AS entity
        FROM tab3 
        WHERE operator_id IS NOT NULL AND operator_id != '' and error_type is not Null and error_type!=''
        GROUP BY error_type, operator_id 
    
        UNION ALL
    
        SELECT error_type, COUNT(*) AS count, stage AS entity_id, "Stage" AS entity
        FROM tab3 
        WHERE stage IS NOT NULL AND stage != '' and error_type is not Null and error_type!=''
        GROUP BY error_type, stage 
    ''')
    
    error_code_analysis_df.foreachPartition(send_partition_to_kafka)


    error_code_analysis_df=spark.sql('''
        WITH tab1 AS (
            SELECT DISTINCT eid, sid, error_type 
            FROM flink_stream.stream_enu.telemetry_uc 
            WHERE ets >= CURRENT_TIMESTAMP() - INTERVAL 1 HOUR
        ),
    
        tab2 AS (
            SELECT DISTINCT station_machine_code, upper(operator_id) as operator_id, resident_sid, enrolment_type, stage, txn_id 
            FROM flink_stream.stream_enu.enu_uc_opt_action_v2 
            WHERE event_timestamp >= CURRENT_TIMESTAMP() - INTERVAL 1 HOUR
        ),
    
        tab3 AS (
            SELECT t1.error_type, t2.operator_id, t2.stage, t2.station_machine_code, t2.enrolment_type
            FROM tab2 t2 
            LEFT JOIN tab1 t1 ON t2.txn_id = t1.eid 
        )
    
        SELECT error_type, COUNT(*) AS count, station_machine_code AS entity_id, "Machine ID" AS entity
        FROM tab3 
        WHERE station_machine_code IS NOT NULL AND station_machine_code != '' and error_type is not Null and error_type!=''
        GROUP BY error_type, station_machine_code 
    
        UNION ALL
    
        SELECT error_type, COUNT(*) AS count, enrolment_type AS entity_id, "Enrolment Type" AS entity
        FROM tab3 
        WHERE enrolment_type IS NOT NULL AND enrolment_type != '' and error_type is not Null and error_type!=''
        GROUP BY error_type, enrolment_type
    ''')
    
    error_code_analysis_df.foreachPartition(send_partition_to_kafka)

start_time=time.time()        
main() 
end_time=time.time()
print(end_time-start_time)
