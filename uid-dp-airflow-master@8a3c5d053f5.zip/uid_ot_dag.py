#!/usr/bin/env python
# coding: utf-8

# In[1]:


import time
import os
import json
import pandas as pd
from trino.dbapi import connect
import mysql.connector
import boto3
from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from datetime import datetime
from zoho_alerts import zoho_failure_callback


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2026, 7, 21),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'on_failure_callback': zoho_failure_callback
}

# Define the DAG
dag = DAG(
    'update_uid_ot_dag',
    default_args=default_args,
    description='run merge query to update uid_ot',
    schedule="0 3 * * *",
    catchup=False,
    tags=['uid_master_tables']
)

# In[2]:

session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4')
s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425')

mysql_table_to_read="uid_origin_tracker"
iceberg_table_name='uid_origin_tracker'
iceberg_schema='mysql_uid_v2'
lookback_days=30
skip_till=19
trino_host="10.10.118.10"
iceberg_incr_key='enr_status_date'
# iceberg_partition_column='month(enr_date)'
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="af_ot"
trino_table_name=f'{trino_catalog_iceberg}.{iceberg_schema}.{iceberg_table_name}'
# iceberg_partition_column='shard_hint'
trino_host_mapping={
              "mysql_v2_20_35":(20,35),
              "mysql_v2_36_51":(36,51),
              "mysql_v2_52_67":(52,67),
              "mysql_v2_68_83":(68,83),
              "mysql_v2_84_99":(84,99)
                }

update_tracker_update="""
MERGE INTO strot.reporting_data.enu_eid_update_tracker_v1 t
USING (
    WITH otb AS (
        SELECT eid, uid, enr_type, enr_date, enr_status 
        FROM strot.mysql_uid_v2.uid_origin_tracker 
        WHERE enr_status != 'IP'
          AND enr_status_date >= NOW() - INTERVAL '7' DAY
    ),
    hm AS (
        SELECT eid, res_dob_year, poi, poa, pob, hof_proof 
        FROM strot.mysql_uid_v2.uid_his_master 
        WHERE (poi IS NOT NULL 
           OR poa IS NOT NULL 
           OR pob IS NOT NULL 
           OR hof_proof IS NOT NULL) and last_updated_date >= now() - INTERVAL '1' month
    ),
    ha AS (
        SELECT eid, res_addr_vtc_name, res_addr_district_name, res_addr_subdistrict_name,
               res_addr_state_code, res_addr_state_name, res_addr_pincode, res_addr_country_name
        FROM strot.mysql_uid_v2.uid_his_address
        WHERE (res_addr_vtc_name IS NOT NULL
           OR res_addr_district_name IS NOT NULL
           OR res_addr_subdistrict_name IS NOT NULL
           OR res_addr_state_code IS NOT NULL
           OR res_addr_state_name IS NOT NULL
           OR res_addr_pincode IS NOT NULL
           OR res_addr_country_name IS NOT NULL) and last_updated_date >= now() - INTERVAL '1' month
    )
    SELECT otb.eid,otb.uid, enr_date, enr_type, enr_status, res_dob_year, poi, poa, pob, hof_proof,
           res_addr_vtc_name, res_addr_district_name, res_addr_subdistrict_name,
           res_addr_state_code, res_addr_state_name, res_addr_pincode, res_addr_country_name 
    FROM otb 
    LEFT JOIN hm ON otb.eid = hm.eid
    LEFT JOIN ha ON otb.eid = ha.eid
) AS source
ON t.eid = source.eid
WHEN MATCHED THEN
    UPDATE SET
        uid = source.uid,
        enr_date = source.enr_date,
        enr_type = source.enr_type,
        enr_status = source.enr_status,
        res_dob_year = source.res_dob_year,
        poi = source.poi,
        poa = source.poa,
        pob = source.pob,
        hof_proof = source.hof_proof,
        res_addr_vtc_name = source.res_addr_vtc_name,
        res_addr_district_name = source. res_addr_district_name,
        res_addr_subdistrict_name = source.res_addr_subdistrict_name,
        res_addr_state_code = source.res_addr_state_code,
        res_addr_state_name = source.res_addr_state_name,
        res_addr_pincode = source.res_addr_pincode,
        res_addr_country_name = source. res_addr_country_name
WHEN NOT MATCHED THEN
    INSERT (eid, uid, enr_date, enr_type, enr_status, res_dob_year, poi, poa, pob, hof_proof,
            res_addr_vtc_name, res_addr_district_name, res_addr_subdistrict_name,
            res_addr_state_code, res_addr_state_name, res_addr_pincode, res_addr_country_name)
    VALUES (source.eid, source.uid, source.enr_date, source.enr_type, source.enr_status, 
            source.res_dob_year, source.poi, source.poa, source.pob, source.hof_proof,
            source.res_addr_vtc_name, source.res_addr_district_name, source.res_addr_subdistrict_name,
            source.res_addr_state_code, source.res_addr_state_name, source.res_addr_pincode, 
            source.res_addr_country_name)
"""

# In[3]:


def run_query(query,host=trino_host,port=trino_port,user=trino_user):
        conn = connect(
            host=f"{host}",
            port=port,
            user=f"{user}",
            )
        cur = conn.cursor()
        cur.execute(f"{query}")
       
        return {"success":1,"msg":""}

def return_max_key(query,host=trino_host,port=trino_port,user=trino_user):
    try:
        conn = connect(
            host=f"{host}",
            port=port,
            user=f"{user}",
            )
        cur = conn.cursor()
        row = cur.execute(f"{query}")
       
        return row.fetchall()
    except Exception as e:
        return str(e)


ts = ['0205-04-01 00:00:00','2025-06-01 00:00:00','2025-11-01 00:00:00']

# s3_client.download_file('prd-bi-data-platform-configs', 'salt/salts.txt', '/opt/airflow/files/salts_from_s3.txt')

def main():
    
        with open('/opt/airflow/dags/files/salts_from_s3.txt', "r") as file:  
            salts = json.load(file)

        # os.remove('/opt/airflow/files/salts_from_s3.txt')
        
        retry_count=0
        output=1
        select_query=""
        for k,v in trino_host_mapping.items():
            mysql_host=k
            print(mysql_host)
            for i in range(v[0],v[1]+1):
                select_query=select_query+f"""select tracker_key,
                                    to_base64(sha256(to_utf8(concat('{salts[str(i)]}',uid)))) as uid,
                                    refid,
                                    eid,
                                    enr_date,
                                    enr_num,
                                    enr_type,
                                    enr_mode,
                                    enr_status,
                                    enr_status_date,
                                    available_in_abis,
                                    app_num,
                                    registrar_code,
                                    ea_code,
                                    operator_id,
                                    supervisor_id,
                                    upload_time,
                                    update_ind,
                                    reject_ind,
                                    auth_extraction_status,
                                    auth_extraction_status_date,
                                    IsChild,
                                    linkedEnrolment_eid,
                                    cast(bestPhotoCbeffMatchIdx as int) as  bestPhotoCbeffMatchIdx,
                                    cast(bestLeftSlabCbeffMatchIdx as int) as  bestLeftSlabCbeffMatchIdx,
                                    cast(bestRightSlabCbeffMatchIdx as int) as  bestRightSlabCbeffMatchIdx,
                                    cast(bestThumbsSlabCbeffMatchIdx as int) as  bestThumbsSlabCbeffMatchIdx,
                                    cast(bestLeftIrisCbeffMatchIdx as int) as  bestLeftIrisCbeffMatchIdx,
                                    cast(bestRightIrisCbeffMatchIdx as int) as  bestRightIrisCbeffMatchIdx,
                                    packet_version,
                                    source,
                                    source_request_id,
                                    source_client_id,
                                    source_client_machine_id,
                                    source_client_version,
                                    created_by,
                                    creation_date,
                                    last_updated_by,
                                    last_updated_date,
                                    substring(uid,1,2) as shard_hint,row_number() over (partition by tracker_key order by eid desc) as rn
                from {mysql_host}.uidv2_0_{i}.{mysql_table_to_read} WHERE date({iceberg_incr_key})>=now() - interval '10' day {"union " if i<99 else ""}"""
    
        merge_query=f"""MERGE INTO {trino_table_name} as hm USING ({select_query}) as uc
        on hm.shard_hint=uc.shard_hint and hm.tracker_key=uc.tracker_key
        WHEN MATCHED THEN UPDATE SET
            uid=uc.uid ,
            refid=uc.refid ,
            eid=uc.eid ,
            enr_date=uc.enr_date ,
            enr_num=uc.enr_num ,
            enr_type=uc.enr_type ,
            enr_mode=uc.enr_mode ,
            enr_status=uc.enr_status ,
            enr_status_date=uc.enr_status_date ,
            available_in_abis=uc.available_in_abis ,
            app_num=uc.app_num ,
            registrar_code=uc.registrar_code ,
            ea_code=uc.ea_code ,
            operator_id=uc.operator_id ,
            supervisor_id=uc.supervisor_id ,
            upload_time=uc.upload_time ,
            update_ind=uc.update_ind ,
            reject_ind=uc.reject_ind ,
            auth_extraction_status=uc.auth_extraction_status ,
            auth_extraction_status_date=uc.auth_extraction_status_date ,
            IsChild=uc.IsChild ,
            linkedEnrolment_eid=uc.linkedEnrolment_eid ,
            bestPhotoCbeffMatchIdx=uc.bestPhotoCbeffMatchIdx ,
            bestLeftSlabCbeffMatchIdx=uc.bestLeftSlabCbeffMatchIdx ,
            bestRightSlabCbeffMatchIdx=uc.bestRightSlabCbeffMatchIdx ,
            bestThumbsSlabCbeffMatchIdx=uc.bestThumbsSlabCbeffMatchIdx ,
            bestLeftIrisCbeffMatchIdx=uc.bestLeftIrisCbeffMatchIdx,
            bestRightIrisCbeffMatchIdx=uc.bestRightIrisCbeffMatchIdx ,
            packet_version=uc.packet_version ,
            source=uc.source ,
            source_request_id=uc.source_request_id ,
            source_client_id=uc.source_client_id ,
            source_client_machine_id=uc.source_client_machine_id ,
            source_client_version=uc.source_client_version ,
            created_by=uc.created_by ,
            creation_date=uc.creation_date,
            last_updated_by=uc.last_updated_by ,
            last_updated_date=uc.last_updated_date 
        WHEN NOT MATCHED THEN INSERT 
            (tracker_key,
            uid,
            refid,
            eid,
            enr_date,
            enr_num,
            enr_type,
            enr_mode,
            enr_status,
            enr_status_date,
            available_in_abis,
            app_num,
            registrar_code,
            ea_code,
            operator_id,
            supervisor_id,
            upload_time,
            update_ind,
            reject_ind,
            auth_extraction_status,
            auth_extraction_status_date,
            IsChild,
            linkedEnrolment_eid,
            bestPhotoCbeffMatchIdx,
            bestLeftSlabCbeffMatchIdx,
            bestRightSlabCbeffMatchIdx,
            bestThumbsSlabCbeffMatchIdx,
            bestLeftIrisCbeffMatchIdx,
            bestRightIrisCbeffMatchIdx,
            packet_version,
            source,
            source_request_id,
            source_client_id,
            source_client_machine_id,
            source_client_version,
            created_by,
            creation_date,
            last_updated_by,
            last_updated_date,
            shard_hint) VALUES 
                (uc.tracker_key,
                uc.uid,
                uc.refid,
                uc.eid,
                uc.enr_date,
                uc.enr_num,
                uc.enr_type,
                uc.enr_mode,
                uc.enr_status,
                uc.enr_status_date,
                uc.available_in_abis,
                uc.app_num,
                uc.registrar_code,
                uc.ea_code,
                uc.operator_id,
                uc.supervisor_id,
                uc.upload_time,
                uc.update_ind,
                uc.reject_ind,
                uc.auth_extraction_status,
                uc.auth_extraction_status_date,
                uc.IsChild,
                uc.linkedEnrolment_eid,
                uc.bestPhotoCbeffMatchIdx,
                uc.bestLeftSlabCbeffMatchIdx,
                uc.bestRightSlabCbeffMatchIdx,
                uc.bestThumbsSlabCbeffMatchIdx,
                uc.bestLeftIrisCbeffMatchIdx,
                uc.bestRightIrisCbeffMatchIdx,
                uc.packet_version,
                uc.source,
                uc.source_request_id,
                uc.source_client_id,
                uc.source_client_machine_id,
                uc.source_client_version,
                uc.created_by,
                uc.creation_date,
                uc.last_updated_by,
                uc.last_updated_date,
                uc.shard_hint)"""
        # print(merge_query)
        # print("--------------------------------------------------------")
        output=run_query(merge_query)
        
        return output



update_uid_ot_daily_table = PythonOperator(
                task_id='uid_ot_merge_query',
                python_callable=main,
                dag=dag,
            )

# eid_update_tracker_merge_query_daily_table = PythonOperator(
#                 task_id='eid_update_tracker_merge_query',
#                 python_callable=run_query,
#                 op_kwargs={'query':update_tracker_update},
#                 dag=dag,
#             )


update_uid_ot_daily_table
