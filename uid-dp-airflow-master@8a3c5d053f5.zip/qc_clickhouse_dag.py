"""
DAG: qc_operator_disposition_load_hourly
Load QC operator disposition records into ClickHouse distributed table.
Airflow 3.0+ compatible. Runs hourly.
"""
from __future__ import annotations

import math
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
import clickhouse_connect
# import strot_query as sq
# --- Airflow 3.0 SDK Imports ---
from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from trino.dbapi import connect

trino_host="10.10.116.39"
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="airflow_dag_op"

def run_query(query, host=trino_host, port=trino_port, user=trino_user):
    try:
        conn = connect(
            host=host,
            port=port,
            user=user
        )
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"query": query, "success": 1, "data": body}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body),'df':df}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}


# ----------------
# ---------
# -----------------------------------------
# Import your 'sq' utility here
# ------------------------------------------------------------------
# from your_company_utils import sq  
# (Uncomment and replace the above line with the actual import for your 'sq' object)

# ------------------------------------------------------------------
# Config
# ------------------------------------------------------------------
client = clickhouse_connect.get_client(
    host="10.10.120.86",
    port=8123,
    username="default",
    password="qwerty"
)
CH_TABLE          = "analytics_qc.qc_operator_disposition_v2_dist"
BATCH_SIZE        = 50_000

# Exact columns in the exact order of the ClickHouse schema
CH_COLUMNS = [
    "packetRefId",
    "userId",
    "vendorId",
    "operatorTimeTakenForDispositionInMilliSeconds",
    "disposedAt",
    "dispositionType",
    "packetLanguage",
    "packetType",
    "dispositionRole",
    "allocatedLevel",
    "event_timestamp",
]

STRING_COLS = [
    "packetRefId", "userId", "vendorId", "dispositionType",
    "packetLanguage", "packetType", "dispositionRole", "allocatedLevel",
]
# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def fetch_source_df() -> pd.DataFrame:
    query = '''
    select packetrefid, userid,vendorid, operatortimetakenfordispositioninmilliseconds,
    disposedat AT TIME ZONE 'Asia/Kolkata' AS disposedat,
        dispositiontype, packetlanguage,
        packettype,dispositionrole,allocatedlevel, 
        event_timestamp AT TIME ZONE 'Asia/Kolkata' AS event_timestamp   
    from flink_stream.stream_qc.qc_operator_disposition 
    where disposedat >= now() - interval '1' hour
    '''
    
    # Execute query using your provided syntax
    result = run_query(query)
    if 'df' not in result:
        print(result)
        return pd.DataFrame()
    
    df = result['df']
    
    # Rename columns to match ClickHouse exactly (based on select order)
    df.columns = CH_COLUMNS
    return df


def transform_df(df: pd.DataFrame) -> pd.DataFrame:
    """Apply exact dtype/null-handling rules required by ClickHouse."""
    
    # Convert datetimes to proper datetime objects
    df['disposedAt'] = pd.to_datetime(df['disposedAt'], errors='coerce')
    df['event_timestamp'] = pd.to_datetime(df['event_timestamp'], errors='coerce')
    
    # Convert integer column
    df['operatorTimeTakenForDispositionInMilliSeconds'] = pd.to_numeric(
        df['operatorTimeTakenForDispositionInMilliSeconds'], errors='coerce'
    ).fillna(0).astype('int32')
    
    # Handle Nulls for Strings (ClickHouse String type cannot accept pandas NaN)
    for col in STRING_COLS:
        df[col] = df[col].astype(str).replace({'nan': '', 'None': '', 'NaT': ''})
        
    return df[CH_COLUMNS]


def load_to_clickhouse(df: pd.DataFrame) -> None:
    """Batched insert into the ClickHouse distributed table."""
    total_rows = len(df)
    n_batches  = max(1, math.ceil(total_rows / BATCH_SIZE))

    for i, chunk in enumerate(np.array_split(df, n_batches)):
        chunk = chunk[CH_COLUMNS]
        client.insert_df(CH_TABLE, chunk)
        print(f'Inserted batch {i + 1}/{n_batches}: {len(chunk)} rows')

    print(f"Successfully inserted {total_rows} rows into {CH_TABLE}.")


# ------------------------------------------------------------------
# Main task
# ------------------------------------------------------------------
def etl_run(**context) -> int:
    """End-to-end: fetch -> transform -> load."""
    df = fetch_source_df()
    print(df.head())
    
    if df.empty:
        print("No source rows found. Exiting gracefully.")
        return 0

    df = transform_df(df)
    load_to_clickhouse(df)
    return len(df)


# ------------------------------------------------------------------
# DAG Definition
# ------------------------------------------------------------------


DEFAULT_ARGS = {
    "owner": "Saksham Agarwal",
    "retries": 2,
    "retry_delay": timedelta(minutes=2),
    "start_date": datetime(2026, 8, 12),
    "depends_on_past": False,
}


with DAG(
    dag_id="qc_operator_disposition_load_hourly",
    description="Load QC operator disposition data into ClickHouse hourly",
    default_args=DEFAULT_ARGS,
    schedule="0 * * * *",          # Runs at minute 0 of every hour
    catchup=False,
    max_active_runs=2,            # Prevent overlapping hourly runs
    max_active_tasks=1,
    tags=["clickhouse", "qc", "analytics"],
    doc_md=__doc__,
) as dag:

    load_task = PythonOperator(
        task_id="load_qc_dispositions_hourly",
        python_callable=etl_run,
    )

    load_task