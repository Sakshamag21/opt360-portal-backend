# dags/enr_feature_table_backfill.py
import yaml
from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.spark_kubernetes import SparkKubernetesOperator
from airflow.providers.cncf.kubernetes.sensors.spark_kubernetes import SparkKubernetesSensor
from datetime import datetime, timedelta
from spark_base_spec import make_spark_spec 

default_args = {
    'owner': 'data-platform',
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id='enr_feature_table_backfill',
    default_args=default_args,
    schedule='@daily',
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=['spark', 'iceberg', 'migration'],
) as dag:

    job_name = "enr-feature-table-backfill-{{ ds_nodash }}"

    # 1. Generate the spec dictionary
    spark_app_spec_dict = make_spark_spec(
        job_name=job_name,
        script_path="s3a://prd-bi-data-platform-uploads/af_dags_hdc/enr_feature_table_backfill.py"
    )

    # 2. Convert the dictionary to a YAML string so the operator can read it
    spark_app_yaml = yaml.dump(spark_app_spec_dict)

    submit_spark_job = SparkKubernetesOperator(
        task_id='submit_spark_job',
        namespace='strot-spark',
        application_file=spark_app_yaml,
        do_xcom_push=True
    )

    wait_for_spark_job = SparkKubernetesSensor(
        task_id='wait_for_spark_job',
        namespace='strot-spark',
        application_name=job_name,
        poke_interval=30  # <--- Fixed parameter name
    )

    submit_spark_job >> wait_for_spark_job