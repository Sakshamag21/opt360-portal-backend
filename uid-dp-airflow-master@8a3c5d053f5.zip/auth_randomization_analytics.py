from airflow.sdk import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from trino.dbapi import connect
import pandas as pd

trino_host = "10.10.116.75"
trino_port = 8080
trino_user = "auth_randomization_analytics"

query = """
MERGE INTO strot.operator360.auth_randomization_analytics t
USING (
    WITH sourceData AS (
        SELECT
            xsessionid AS session_id,
            operatorid AS operator_id,
            submodality,
            CAST(reqdatetime AS DATE) AS transactions_date
        FROM flink_stream.stream_enu.auth_randomization_logs
        WHERE processed_timestamp >= CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP) - INTERVAL '1' DAY
          AND processed_timestamp <= CAST(CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata' AS TIMESTAMP) - INTERVAL '20' MINUTE
    ),
    enrichedData AS (
        SELECT
            a.session_id,
            a.operator_id,
            a.submodality,
            a.transactions_date,
            b.stage_status
        FROM sourceData a
        JOIN (
            SELECT operator_id, session_id, stage_status
            FROM flink_stream.stream_enu.enu_uc_opt_action_v2
            WHERE event_timestamp >= CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP) - INTERVAL '2' DAY
              AND stage = 'OPERATOR_AUTH'
        ) b
          ON a.session_id = b.session_id
         AND a.operator_id = b.operator_id
    ),
    session_status AS (
        SELECT
            operator_id,
            session_id,
            submodality,
            transactions_date,
            MAX(CASE WHEN stage_status = 'INITIATED' THEN 1 ELSE 0 END) AS has_initiated,
            MAX(CASE WHEN stage_status = 'COMPLETED' THEN 1 ELSE 0 END) AS has_completed,
            MAX(CASE
                    WHEN stage_status IS NOT NULL
                     AND stage_status NOT IN ('INITIATED', 'COMPLETED')
                    THEN 1 ELSE 0
                END) AS has_failed
        FROM enrichedData
        GROUP BY operator_id, session_id, submodality, transactions_date
    ),
    classified AS (
        SELECT
            operator_id,
            submodality,
            transactions_date,
            CASE
                WHEN has_initiated = 1 AND has_completed = 1 THEN 'SUCCESS'
                WHEN has_initiated = 1 AND has_failed = 1 THEN 'FAILED'
                WHEN has_initiated = 1 AND has_completed = 0 AND has_failed = 0 THEN 'SKIPPED'
                WHEN has_initiated = 0 AND has_completed = 1 THEN 'SUCCESS'
                WHEN has_initiated = 0 AND has_failed = 1 THEN 'FAILED'
                ELSE NULL
            END AS auth_result
        FROM session_status
    ),
    aggregated AS (
        SELECT
            operator_id,
            transactions_date,
            COUNT(*) AS auth_attempt_count,
            SUM(CASE WHEN auth_result = 'SKIPPED' THEN 1 ELSE 0 END) AS auth_skipped_count,
            SUM(CASE WHEN auth_result = 'FAILED' THEN 1 ELSE 0 END) AS auth_failed_count,
            SUM(CASE WHEN auth_result = 'SUCCESS' THEN 1 ELSE 0 END) AS auth_success_count,
            SUM(CASE WHEN submodality = 'RIGHT_THUMB'  THEN 1 ELSE 0 END) AS right_thumb_attempt,
            SUM(CASE WHEN submodality = 'RIGHT_THUMB'  AND auth_result = 'SKIPPED' THEN 1 ELSE 0 END) AS right_thumb_skipped,
            SUM(CASE WHEN submodality = 'RIGHT_THUMB'  AND auth_result = 'FAILED'  THEN 1 ELSE 0 END) AS right_thumb_failed,
            SUM(CASE WHEN submodality = 'RIGHT_THUMB'  AND auth_result = 'SUCCESS' THEN 1 ELSE 0 END) AS right_thumb_success,
            SUM(CASE WHEN submodality = 'RIGHT_INDEX'  THEN 1 ELSE 0 END) AS right_index_attempt,
            SUM(CASE WHEN submodality = 'RIGHT_INDEX'  AND auth_result = 'SKIPPED' THEN 1 ELSE 0 END) AS right_index_skipped,
            SUM(CASE WHEN submodality = 'RIGHT_INDEX'  AND auth_result = 'FAILED'  THEN 1 ELSE 0 END) AS right_index_failed,
            SUM(CASE WHEN submodality = 'RIGHT_INDEX'  AND auth_result = 'SUCCESS' THEN 1 ELSE 0 END) AS right_index_success,
            SUM(CASE WHEN submodality = 'RIGHT_MIDDLE' THEN 1 ELSE 0 END) AS right_middle_attempt,
            SUM(CASE WHEN submodality = 'RIGHT_MIDDLE' AND auth_result = 'SKIPPED' THEN 1 ELSE 0 END) AS right_middle_skipped,
            SUM(CASE WHEN submodality = 'RIGHT_MIDDLE' AND auth_result = 'FAILED'  THEN 1 ELSE 0 END) AS right_middle_failed,
            SUM(CASE WHEN submodality = 'RIGHT_MIDDLE' AND auth_result = 'SUCCESS' THEN 1 ELSE 0 END) AS right_middle_success,
            SUM(CASE WHEN submodality = 'RIGHT_RING'   THEN 1 ELSE 0 END) AS right_ring_attempt,
            SUM(CASE WHEN submodality = 'RIGHT_RING'   AND auth_result = 'SKIPPED' THEN 1 ELSE 0 END) AS right_ring_skipped,
            SUM(CASE WHEN submodality = 'RIGHT_RING'   AND auth_result = 'FAILED'  THEN 1 ELSE 0 END) AS right_ring_failed,
            SUM(CASE WHEN submodality = 'RIGHT_RING'   AND auth_result = 'SUCCESS' THEN 1 ELSE 0 END) AS right_ring_success,
            SUM(CASE WHEN submodality = 'LEFT_THUMB'   THEN 1 ELSE 0 END) AS left_thumb_attempt,
            SUM(CASE WHEN submodality = 'LEFT_THUMB'   AND auth_result = 'SKIPPED' THEN 1 ELSE 0 END) AS left_thumb_skipped,
            SUM(CASE WHEN submodality = 'LEFT_THUMB'   AND auth_result = 'FAILED'  THEN 1 ELSE 0 END) AS left_thumb_failed,
            SUM(CASE WHEN submodality = 'LEFT_THUMB'   AND auth_result = 'SUCCESS' THEN 1 ELSE 0 END) AS left_thumb_success,
            SUM(CASE WHEN submodality = 'LEFT_INDEX'   THEN 1 ELSE 0 END) AS left_index_attempt,
            SUM(CASE WHEN submodality = 'LEFT_INDEX'   AND auth_result = 'SKIPPED' THEN 1 ELSE 0 END) AS left_index_skipped,
            SUM(CASE WHEN submodality = 'LEFT_INDEX'   AND auth_result = 'FAILED'  THEN 1 ELSE 0 END) AS left_index_failed,
            SUM(CASE WHEN submodality = 'LEFT_INDEX'   AND auth_result = 'SUCCESS' THEN 1 ELSE 0 END) AS left_index_success,
            SUM(CASE WHEN submodality = 'LEFT_MIDDLE'  THEN 1 ELSE 0 END) AS left_middle_attempt,
            SUM(CASE WHEN submodality = 'LEFT_MIDDLE'  AND auth_result = 'SKIPPED' THEN 1 ELSE 0 END) AS left_middle_skipped,
            SUM(CASE WHEN submodality = 'LEFT_MIDDLE'  AND auth_result = 'FAILED'  THEN 1 ELSE 0 END) AS left_middle_failed,
            SUM(CASE WHEN submodality = 'LEFT_MIDDLE'  AND auth_result = 'SUCCESS' THEN 1 ELSE 0 END) AS left_middle_success,
            SUM(CASE WHEN submodality = 'LEFT_RING'    THEN 1 ELSE 0 END) AS left_ring_attempt,
            SUM(CASE WHEN submodality = 'LEFT_RING'    AND auth_result = 'SKIPPED' THEN 1 ELSE 0 END) AS left_ring_skipped,
            SUM(CASE WHEN submodality = 'LEFT_RING'    AND auth_result = 'FAILED'  THEN 1 ELSE 0 END) AS left_ring_failed,
            SUM(CASE WHEN submodality = 'LEFT_RING'    AND auth_result = 'SUCCESS' THEN 1 ELSE 0 END) AS left_ring_success,
            SUM(CASE WHEN submodality = 'LEFT_IRIS'    THEN 1 ELSE 0 END) AS left_iris_attempt,
            SUM(CASE WHEN submodality = 'LEFT_IRIS'    AND auth_result = 'SKIPPED' THEN 1 ELSE 0 END) AS left_iris_skipped,
            SUM(CASE WHEN submodality = 'LEFT_IRIS'    AND auth_result = 'FAILED'  THEN 1 ELSE 0 END) AS left_iris_failed,
            SUM(CASE WHEN submodality = 'LEFT_IRIS'    AND auth_result = 'SUCCESS' THEN 1 ELSE 0 END) AS left_iris_success,
            SUM(CASE WHEN submodality = 'RIGHT_IRIS'   THEN 1 ELSE 0 END) AS right_iris_attempt,
            SUM(CASE WHEN submodality = 'RIGHT_IRIS'   AND auth_result = 'SKIPPED' THEN 1 ELSE 0 END) AS right_iris_skipped,
            SUM(CASE WHEN submodality = 'RIGHT_IRIS'   AND auth_result = 'FAILED'  THEN 1 ELSE 0 END) AS right_iris_failed,
            SUM(CASE WHEN submodality = 'RIGHT_IRIS'   AND auth_result = 'SUCCESS' THEN 1 ELSE 0 END) AS right_iris_success,
            SUM(CASE WHEN submodality = 'FACE'         THEN 1 ELSE 0 END) AS face_attempt,
            SUM(CASE WHEN submodality = 'FACE'         AND auth_result = 'SKIPPED' THEN 1 ELSE 0 END) AS face_skipped,
            SUM(CASE WHEN submodality = 'FACE'         AND auth_result = 'FAILED'  THEN 1 ELSE 0 END) AS face_failed,
            SUM(CASE WHEN submodality = 'FACE'         AND auth_result = 'SUCCESS' THEN 1 ELSE 0 END) AS face_success
        FROM classified
        GROUP BY operator_id, transactions_date
    )
    SELECT 
        operator_id,
        transactions_date,
        CAST(current_timestamp AT TIME ZONE 'Asia/Kolkata' AS TIMESTAMP) AS insert_ts,
        auth_attempt_count,
        auth_skipped_count,
        auth_failed_count,
        auth_success_count,
        right_thumb_attempt, right_thumb_skipped, right_thumb_failed, right_thumb_success,
        right_index_attempt, right_index_skipped, right_index_failed, right_index_success,
        right_middle_attempt, right_middle_skipped, right_middle_failed, right_middle_success,
        right_ring_attempt, right_ring_skipped, right_ring_failed, right_ring_success,
        left_thumb_attempt, left_thumb_skipped, left_thumb_failed, left_thumb_success,
        left_index_attempt, left_index_skipped, left_index_failed, left_index_success,
        left_middle_attempt, left_middle_skipped, left_middle_failed, left_middle_success,
        left_ring_attempt, left_ring_skipped, left_ring_failed, left_ring_success,
        left_iris_attempt, left_iris_skipped, left_iris_failed, left_iris_success,
        right_iris_attempt, right_iris_skipped, right_iris_failed, right_iris_success,
        face_attempt, face_skipped, face_failed, face_success
    FROM aggregated
) s
ON t.operator_id = s.operator_id
AND t.transactions_date = s.transactions_date
WHEN MATCHED THEN UPDATE SET
    insert_ts = s.insert_ts,
    auth_attempt_count = s.auth_attempt_count,
    auth_skipped_count =  s.auth_skipped_count,
    auth_failed_count =  s.auth_failed_count,
    auth_success_count = s.auth_success_count,
    right_thumb_attempt = s.right_thumb_attempt,
    right_thumb_skipped = s.right_thumb_skipped,
    right_thumb_failed = s.right_thumb_failed,
    right_thumb_success = s.right_thumb_success,
    right_index_attempt = s.right_index_attempt,
    right_index_skipped = s.right_index_skipped,
    right_index_failed = s.right_index_failed,
    right_index_success = s.right_index_success,
    right_middle_attempt = s.right_middle_attempt,
    right_middle_skipped = s.right_middle_skipped,
    right_middle_failed = s.right_middle_failed,
    right_middle_success = s.right_middle_success,
    right_ring_attempt = s.right_ring_attempt,
    right_ring_skipped = s.right_ring_skipped,
    right_ring_failed = s.right_ring_failed,
    right_ring_success = s.right_ring_success,
    left_thumb_attempt = s.left_thumb_attempt,
    left_thumb_skipped = s.left_thumb_skipped,
    left_thumb_failed = s.left_thumb_failed,
    left_thumb_success = s.left_thumb_success,
    left_index_attempt = s.left_index_attempt,
    left_index_skipped = s.left_index_skipped,
    left_index_failed = s.left_index_failed,
    left_index_success = s.left_index_success,
    left_middle_attempt = s.left_middle_attempt,
    left_middle_skipped = s.left_middle_skipped,
    left_middle_failed = s.left_middle_failed,
    left_middle_success = s.left_middle_success,
    left_ring_attempt = s.left_ring_attempt,
    left_ring_skipped = s.left_ring_skipped,
    left_ring_failed = s.left_ring_failed,
    left_ring_success = s.left_ring_success,
    left_iris_attempt = s.left_iris_attempt,
    left_iris_skipped = s.left_iris_skipped,
    left_iris_failed = s.left_iris_failed,
    left_iris_success = s.left_iris_success,
    right_iris_attempt = s.right_iris_attempt,
    right_iris_skipped = s.right_iris_skipped,
    right_iris_failed = s.right_iris_failed,
    right_iris_success = s.right_iris_success,
    face_attempt = s.face_attempt,
    face_skipped = s.face_skipped,
    face_failed = s.face_failed,
    face_success = s.face_success
WHEN NOT MATCHED THEN INSERT (
    operator_id,
    transactions_date,
    insert_ts,
    auth_attempt_count,
    auth_skipped_count,
    auth_failed_count,
    auth_success_count,
    right_thumb_attempt,
    right_thumb_skipped,
    right_thumb_failed,
    right_thumb_success,
    right_index_attempt,
    right_index_skipped,
    right_index_failed,
    right_index_success,
    right_middle_attempt,
    right_middle_skipped,
    right_middle_failed,
    right_middle_success,
    right_ring_attempt,
    right_ring_skipped,
    right_ring_failed,
    right_ring_success,
    left_thumb_attempt,
    left_thumb_skipped,
    left_thumb_failed,
    left_thumb_success,
    left_index_attempt,
    left_index_skipped,
    left_index_failed,
    left_index_success,
    left_middle_attempt,
    left_middle_skipped,
    left_middle_failed,
    left_middle_success,
    left_ring_attempt,
    left_ring_skipped,
    left_ring_failed,
    left_ring_success,
    left_iris_attempt,
    left_iris_skipped,
    left_iris_failed,
    left_iris_success,
    right_iris_attempt,
    right_iris_skipped,
    right_iris_failed,
    right_iris_success,
    face_attempt,
    face_skipped,
    face_failed,
    face_success
) VALUES (
    s.operator_id,
    s.transactions_date,
    s.insert_ts,
    s.auth_attempt_count,
    s.auth_skipped_count,
    s.auth_failed_count,
    s.auth_success_count,
    s.right_thumb_attempt,
    s.right_thumb_skipped,
    s.right_thumb_failed,
    s.right_thumb_success,
    s.right_index_attempt,
    s.right_index_skipped,
    s.right_index_failed,
    s.right_index_success,
    s.right_middle_attempt,
    s.right_middle_skipped,
    s.right_middle_failed,
    s.right_middle_success,
    s.right_ring_attempt,
    s.right_ring_skipped,
    s.right_ring_failed,
    s.right_ring_success,
    s.left_thumb_attempt,
    s.left_thumb_skipped,
    s.left_thumb_failed,
    s.left_thumb_success,
    s.left_index_attempt,
    s.left_index_skipped,
    s.left_index_failed,
    s.left_index_success,
    s.left_middle_attempt,
    s.left_middle_skipped,
    s.left_middle_failed,
    s.left_middle_success,
    s.left_ring_attempt,
    s.left_ring_skipped,
    s.left_ring_failed,
    s.left_ring_success,
    s.left_iris_attempt,
    s.left_iris_skipped,
    s.left_iris_failed,
    s.left_iris_success,
    s.right_iris_attempt,
    s.right_iris_skipped,
    s.right_iris_failed,
    s.right_iris_success,
    s.face_attempt,
    s.face_skipped,
    s.face_failed,
    s.face_success
)
"""


def trino(query, host=trino_host, port=trino_port, user=trino_user):
    conn = None
    try:
        conn = connect(
            host=host,
            port=port,
            user=user
        )
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"query": query, "success": 1, "data": body}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}
    finally:
        if conn:
            conn.close()

def insertData(query):
    res = trino(query)
    if res['success'] == 1:
        print(f"Inserted Data: {res['data']}")
    else:
        error_msg = res.get('msg', 'Trino query failed')
        print(f"Insert Data Failed! {error_msg}")
        raise Exception(error_msg)

default_args = {
    'owner': 'inzamam.nisg',
    'depends_on_past': False,
    'start_date': datetime(2026, 8, 6),
    'email': ["techexe15.yp25@uidai.net.in", "techexecutive22-yp23@uidai.net.in", "techexecutive14-yp23@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 1
}

dag = DAG(
    'AUTH_RANDOMIZATION_ANALYTICS',
    default_args=default_args,
    description="Dag to update auth randomization statistics hourly",
    schedule="20 * * * *",
    catchup=False,
    tags=["AUTH", "RANDOMIZATION", "ANALYTICS"]
)

task = PythonOperator(
    task_id='insert_uc_opt_auth_txns',
    python_callable=insertData,
    op_kwargs={'query': query},
    dag=dag,
)

task