from airflow.sdk import DAG
from airflow.operators.python import PythonOperator



import datetime
import calendar
from trino.dbapi import connect
import base64
import json
import requests
from io import StringIO
import pandas as pd
import boto3
import logging

trino_host="10.10.116.75"
trino_port=8080
trino_user="admin_reporting_af_fn_details"

from kafka import KafkaProducer
topic = "COMMAND.STROT.RCS.REQUEST"
bootstrap_servers = "10.10.105.225:9092,10.10.106.171:9092,10.10.107.110:9092,10.10.105.75:9092,10.10.105.98:9092,10.10.105.238:9092,10.10.107.130:9092,10.10.105.33:9092,10.10.106.195:9092,10.10.106.144:9092,10.10.105.227:9092"


rcs_host = '10.81.116.128'
rcs_port = '9090'

mail_list= ["director-techdev2@uidai.net.in"]
cc= "tobio.tc@uidai.net.in,nec.support@uidai.net.in,app.developer-tc@uidai.net.in,nare.saraswathi@uidai.net.in,app.tester1-tc@uidai.net.in,pm2-tc@uidai.net.in,prod.mgr1-tc@uidai.net.in,project.incharge-tc@uidai.net.in,bio.specialist-tc@uidai.net.in,surajmukare.tcs@uidai.net.in,prod.mgr2-tc@uidai.net.in,suvvalas.nec@uidai.net.in,swastikchandra.nec@uidai.net.in,hoe.dev-tc@uidai.net.in,techexe15.yp25@uidai.net.in,techexecutive14-yp23@uidai.net.in,techexecutive22-yp23@uidai.net.in,productmgr4-tc@uidai.net.in"

# cc="techexe15.yp25@uidai.net.in"

# We have removed scaled score threshold criteria, as asked by biometrics team


# fn_fnir = """
#         WITH mytable AS(
#             SELECT t.reference_code as ref_code, t.candidate_ref_code as cand_ref_code, s.scaled_score as scaled_score,
#             t.creation_date as mdd_check_date
#             FROM flink_stream.stream_enu.abis_candidate_match_analysis_v1 t 
#             JOIN flink_stream.stream_enu.enu_globalprocessaudit v ON t.reference_code=v.edata_refid
#             JOIN flink_stream.stream_enu.abis_candidate_match_raw_v1 s ON t.candidate_ref_code=s.candidates_ref_code
#             WHERE MONTH(DATE_TRUNC('month', CURRENT_DATE) - INTERVAL '1' DAY) = MONTH(t.creation_date)
#             AND YEAR(DATE_TRUNC('month', CURRENT_DATE) - INTERVAL '1' DAY) = YEAR(t.creation_date)
#             AND t.true_duplicate=1  AND v.enrolmenttype='N'
#         ),
#         mytable2 AS (
#             SELECT ref_code, cand_ref_code, scaled_score, mdd_check_date
#             FROM (
#                 SELECT ref_code,cand_ref_code,scaled_score,mdd_check_date,
#                 ROW_NUMBER() OVER (PARTITION BY ref_code, cand_ref_code ORDER BY scaled_score DESC) AS rn
#                 FROM mytable
#             ) sub
#             WHERE rn = 1
#         ),
#         mytable3 AS(
#             SELECT t.ref_code as ref_code, t.cand_ref_code as cand_ref_code, t.scaled_score as scaled_score, s.abis_code as abis_code, s.status as status,
#             t.mdd_check_date as mdd_check_date, MAX(s.last_updated_date) as applicant_identify_last_updated_date
#             FROM mytable2 t JOIN flink_stream.stream_enu.abis_request_tracker_union_v1 s ON t.ref_code=s.reference_code
#             WHERE s.request_type='IDENTIFY' AND s.status='DEDUP_SUCCESS'
#             GROUP BY 1,2,3,4,5,6
#         ),
#         mytable4 AS(
#             SELECT t.ref_code as ref_code, t.cand_ref_code as cand_ref_code, t.scaled_score as scaled_score, t.abis_code as abis_code, t.status as status,
#             t.applicant_identify_last_updated_date as applicant_identify_last_updated_date, t.mdd_check_date as mdd_check_date,
#             MIN(s.last_updated_date) as cand_insert_last_updated_date
#             FROM mytable3 t JOIN flink_stream.stream_enu.abis_request_tracker_union_v1 s ON t.cand_ref_code=s.reference_code AND t.abis_code=s.abis_code
#             WHERE s.request_type='INSERT' AND s.status='INSERT_SUCCESS'
#             GROUP BY 1,2,3,4,5,6,7
#         )

#             SELECT ref_code,cand_ref_code,scaled_score,abis_code,status,applicant_identify_last_updated_date,cand_insert_last_updated_date,mdd_check_date
#             FROM (
#                 SELECT ref_code, cand_ref_code, scaled_score, abis_code, status,
#                     applicant_identify_last_updated_date, cand_insert_last_updated_date, mdd_check_date,
#                     ROW_NUMBER() OVER (
#                         PARTITION BY ref_code, abis_code
#                         ORDER BY cand_insert_last_updated_date
#                     ) AS rn
#                 FROM mytable4
#                 WHERE applicant_identify_last_updated_date > cand_insert_last_updated_date
#             ) sub
#             WHERE rn = 1

#     """



fn_fnir = """
        WITH mytable AS(
            SELECT reference_code as ref_code, candidate_ref_code as cand_ref_code,
            creation_date as mdd_check_date
            FROM flink_stream.stream_enu.abis_candidate_match_analysis_v1 
            WHERE MONTH(t.creation_date) = MONTH(DATE_TRUNC('month', CURRENT_DATE) - INTERVAL '1' DAY)
            AND YEAR(t.creation_date) = YEAR(DATE_TRUNC('month', CURRENT_DATE) - INTERVAL '1' DAY)
            AND true_duplicate=1 
        ),
        mytable1 AS(
        select distinct edata_refid
        from flink_stream.stream_enu.enu_globalprocessaudit
        where enrolmenttype = 'N' and date(ets) >= date_add('month', -6, date_trunc('month', current_date))
        ),
        mytable2 AS(
            SELECT t.ref_code as ref_code, t.cand_ref_code as cand_ref_code,
            t.mdd_check_date as mdd_check_date
            FROM mytable t 
            JOIN mytable1 v ON t.ref_code=v.edata_refid
        ),
        mytable3 AS(
            SELECT t.ref_code as ref_code, t.cand_ref_code as cand_ref_code, s.abis_code as abis_code, s.status as status,
            t.mdd_check_date as mdd_check_date, MAX(s.last_updated_date) as applicant_identify_last_updated_date
            FROM mytable2 t JOIN flink_stream.stream_enu.abis_request_tracker_union_v1 s ON t.ref_code=s.reference_code
            WHERE s.request_type='IDENTIFY' AND s.status='DEDUP_SUCCESS'
            GROUP BY 1,2,3,4,5
        ),
        mytable4 AS(
            SELECT t.ref_code as ref_code, t.cand_ref_code as cand_ref_code, t.abis_code as abis_code, t.status as status,
            t.applicant_identify_last_updated_date as applicant_identify_last_updated_date, t.mdd_check_date as mdd_check_date,
            MIN(s.last_updated_date) as cand_insert_last_updated_date
            FROM mytable3 t JOIN flink_stream.stream_enu.abis_request_tracker_union_v1 s ON t.cand_ref_code=s.reference_code AND t.abis_code=s.abis_code
            WHERE s.request_type='INSERT' AND s.status='INSERT_SUCCESS'
            GROUP BY 1,2,3,4,5,6
        )

            SELECT ref_code,cand_ref_code,abis_code,status,applicant_identify_last_updated_date,cand_insert_last_updated_date,mdd_check_date
            FROM (
                SELECT ref_code, cand_ref_code, abis_code, status,
                    applicant_identify_last_updated_date, cand_insert_last_updated_date, mdd_check_date,
                    ROW_NUMBER() OVER (
                        PARTITION BY ref_code, abis_code
                        ORDER BY cand_insert_last_updated_date
                    ) AS rn
                FROM mytable4
                WHERE applicant_identify_last_updated_date > cand_insert_last_updated_date
            ) sub
            WHERE rn = 1

    """



def previous_month():
    today = datetime.date.today()
    first_day_this_month = today.replace(day=1)
    last_day_prev_month = first_day_this_month - datetime.timedelta(days=1)
    return last_day_prev_month.strftime("%B_%Y"), last_day_prev_month.strftime("%B %Y")


def trino(query, host=trino_host, port=trino_port, user=trino_user):
    try:
        conn = connect(
            host=host,
            port=port,
            user=user
        )
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"query": query, "success": 1, "data": body}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}


def query_to_base64(query):
    query_result = trino(query)
    if query_result["success"]==1 and len(query_result['data'])!=0:
        df = query_result['df']
        print(df.shape)
        csv_buffer = StringIO()
        df.to_csv(csv_buffer, index=False)
        encoded_csv = base64.b64encode(csv_buffer.getvalue().encode()).decode('utf-8')
        return encoded_csv
    elif query_result["success"]==1 and len(query_result['data'])==0:
        print("No Rows Returned by the Query!")
        return 1
    else:
        error_msg = query_result.get("msg", "Unknown Trino failure")
        print("Trino query might have failed! Error:", error_msg)
        raise RuntimeError(f"Trino query failed: {error_msg}")


def send_email_team(email, additional_info):
    url = f'http://{rcs_host}:{rcs_port}/messageReceiver/v1'
    
    payload = json.dumps({

    "residentId": "720447260190",
    "appName": "STROT",
    "idType": "uid",
    "event": "STROT_REPORT",
    "mobile": "8540864693",
    "email": email,
    "channel": [
        {
            "language": "23",
            "channel": "EMAIL"
        }

    ],
    "additionalInfo": additional_info
    })

    headers = {'content-type': 'application/json', 'Accept-Charset': 'UTF-8'}
    response = requests.post(url, data=payload, headers=headers)
    return response,email


def send_kafka_message(email, additional_info):
    try:
        message = {
            "residentId": "720447260190",
            "appName": "STROT",
            "idType": "uid",
            "event": "STROT_REPORT",
            "mobile": "8540864693",
            "email": email,
            "channel": [
                {
                    "language": "23",
                    "channel": "EMAIL"
                }
            ],
            "additionalInfo": additional_info
        }

        producer = KafkaProducer(
            bootstrap_servers=bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode("utf-8")
        )
        producer.send(topic, message)
        producer.flush()
        logging.info(f"Sent Kafka message to topic '{topic}' : {message}")
        producer.close()
    except Exception as e:
        logging.error(f"Error sending Kafka message: {e}", exc_info=True)
        raise


def trigger_email(query, email_list):
   
    encoded_csv = query_to_base64(query)
    date1, date2 = previous_month()
    html_content1 = f"<p>Please find attached the CSV file detailing False Negative instances for the month of {date2}, across all Biometric Service Providers (BSPs).</p>"
    file_name = f"fn_details_{date1}.csv"
    emailSubject= f"FNIR: BSPs FN Details Report For {date2}"
    if encoded_csv != 1:
        additional_info = {
                "HTML_CONTENT": html_content1,
                "TITLE":" ",
                "RECEIVER": "Team",
                "emailSubject": emailSubject,
                "cc": cc,
            }
        if encoded_csv and isinstance(encoded_csv, str) and encoded_csv != 0:
            additional_info["attachment"] = encoded_csv
            additional_info["fileName"] = file_name
            for email in email_list:
                send_kafka_message(email, additional_info)
                print(f"Email sent to {email}")
                print(f"CC: {cc}")
                # response, email = send_email_team(email, additional_info)
                # if(response.status_code==200):
                #     print(f"Email sent to {email}: {response.status_code}, {response}")
                #     print(f"cc : {cc}")
                # else:
                #     print(email,response.status_code)
        else:
            print("Query failed — Trino query did not return data or failed to execute.")
            raise RuntimeError("Trino query failed — encoded_csv is 0. DAG will now fail to trigger alert.")
    else:
        print("No Data in the Table or No FNs Found!")


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2025,10,3),
    'email': ["techexe15.yp25@uidai.net.in","techexecutive22-yp23@uidai.net.in","techexecutive14-yp23@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 1
}

dag= DAG(
    'reporting_fn_details_monthly',
    default_args=default_args,
    description="Dag to Send FN Details to the Team",
    schedule="0 7 7 * *",
    catchup=False,
    tags=["Reporting","FN","FNIR"]
)

task_fnir_fn_monthly=PythonOperator(
    task_id='fetch_fn_monthly_report',
    python_callable=trigger_email,
    op_kwargs={'query': fn_fnir,'email_list': mail_list},
    trigger_rule='all_done',
    dag=dag,
)

task_fnir_fn_monthly
