from airflow.sdk import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from trino.dbapi import connect
import pandas as pd

trino_host = "10.10.116.75"
trino_port = 8080
trino_user = "fpfn_report"

query = """
MERGE INTO strot.misc_adhoc.bsp_decision_metrics AS target
USING (
    WITH sourceData AS (
        SELECT
            reference_code AS ref_code,
            creation_date AS mdd_check_date,
            true_duplicate
        FROM flink_stream.stream_enu.abis_candidate_match_analysis_v1
        WHERE creation_date >= CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP) - INTERVAL '1' DAY
          AND creation_date <  CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP)
    ),
    request_filtered AS (
        SELECT
            reference_code,
            abis_code,
            status
        FROM flink_stream.stream_enu.abis_request_tracker_union_v2
        WHERE creation_date >= CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP) - INTERVAL '30' DAY
          AND creation_date <  CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP)
          AND request_type = 'IDENTIFY'
          AND status IN ('DEDUP_FAILURE', 'DEDUP_SUCCESS')
    ),
    td_joined AS (
        SELECT
            d.ref_code,
            r.abis_code,
            d.mdd_check_date
        FROM sourceData d
        JOIN request_filtered r
          ON d.ref_code = r.reference_code
         AND d.true_duplicate = 1
         AND r.status = 'DEDUP_FAILURE'
    ),
    fn_joined AS (
        SELECT
            f.ref_code,
            r.abis_code,
            f.mdd_check_date
        FROM sourceData f
        JOIN request_filtered r
          ON f.ref_code = r.reference_code
         AND f.true_duplicate = 1
         AND r.status = 'DEDUP_SUCCESS'
        JOIN strot.mysql_uid_v2.request_tracker rt
          ON f.ref_code = rt.refid
         AND rt.type = 'N'
         AND rt.sid_date >= CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP) - INTERVAL '60' DAY
    ),
    tn_joined AS (
        SELECT
            d.ref_code,
            r.abis_code,
            d.mdd_check_date
        FROM sourceData d
        JOIN request_filtered r
          ON d.ref_code = r.reference_code
         AND d.true_duplicate = 0
         AND r.status = 'DEDUP_SUCCESS'
    ),
    fp_joined AS (
        SELECT
            f.ref_code,
            r.abis_code,
            f.mdd_check_date
        FROM sourceData f
        JOIN request_filtered r
          ON f.ref_code = r.reference_code
         AND f.true_duplicate = 0
         AND r.status = 'DEDUP_FAILURE'
        JOIN strot.mysql_uid_v2.request_tracker rt
          ON f.ref_code = rt.refid
         AND rt.type = 'N'
         AND rt.sid_date >= CAST(date_trunc('day', CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata') AS TIMESTAMP) - INTERVAL '60' DAY
    ),
    td_deduped AS (
        SELECT ref_code, abis_code, MAX(mdd_check_date) AS mdd_check_date
        FROM td_joined
        GROUP BY 1, 2
    ),
    fn_deduped AS (
        SELECT ref_code, abis_code, MAX(mdd_check_date) AS mdd_check_date
        FROM fn_joined
        GROUP BY 1, 2
    ),
    tn_deduped AS (
        SELECT ref_code, abis_code, MAX(mdd_check_date) AS mdd_check_date
        FROM tn_joined
        GROUP BY 1, 2
    ),
    fp_deduped AS (
        SELECT ref_code, abis_code, MAX(mdd_check_date) AS mdd_check_date
        FROM fp_joined
        GROUP BY 1, 2
    ),
    td_agg AS (
        SELECT
            DATE(mdd_check_date) AS mdd_decision_date,
            COUNT_IF(abis_code = 'ABIS1') AS td_abis1_count,
            COUNT_IF(abis_code = 'ABIS2') AS td_abis2_count,
            COUNT_IF(abis_code = 'ABIS3') AS td_abis3_count
        FROM td_deduped
        GROUP BY 1
    ),
    fn_agg AS (
        SELECT
            DATE(mdd_check_date) AS mdd_decision_date,
            COUNT_IF(abis_code = 'ABIS1') AS fn_abis1_count,
            COUNT_IF(abis_code = 'ABIS2') AS fn_abis2_count,
            COUNT_IF(abis_code = 'ABIS3') AS fn_abis3_count
        FROM fn_deduped
        GROUP BY 1
    ),
    tn_agg AS (
        SELECT
            DATE(mdd_check_date) AS mdd_decision_date,
            COUNT_IF(abis_code = 'ABIS1') AS tn_abis1_count,
            COUNT_IF(abis_code = 'ABIS2') AS tn_abis2_count,
            COUNT_IF(abis_code = 'ABIS3') AS tn_abis3_count
        FROM tn_deduped
        GROUP BY 1
    ),
    fp_agg AS (
        SELECT
            DATE(mdd_check_date) AS mdd_decision_date,
            COUNT_IF(abis_code = 'ABIS1') AS fp_abis1_count,
            COUNT_IF(abis_code = 'ABIS2') AS fp_abis2_count,
            COUNT_IF(abis_code = 'ABIS3') AS fp_abis3_count
        FROM fp_deduped
        GROUP BY 1
    )
    SELECT
        COALESCE(t.mdd_decision_date, f.mdd_decision_date, n.mdd_decision_date, p.mdd_decision_date) AS mdd_decision_date,
        COALESCE(t.td_abis1_count, 0) AS td_abis1_count,
        COALESCE(t.td_abis2_count, 0) AS td_abis2_count,
        COALESCE(t.td_abis3_count, 0) AS td_abis3_count,
        COALESCE(f.fn_abis1_count, 0) AS fn_abis1_count,
        COALESCE(f.fn_abis2_count, 0) AS fn_abis2_count,
        COALESCE(f.fn_abis3_count, 0) AS fn_abis3_count,
        COALESCE(n.tn_abis1_count, 0) AS tn_abis1_count,
        COALESCE(n.tn_abis2_count, 0) AS tn_abis2_count,
        COALESCE(n.tn_abis3_count, 0) AS tn_abis3_count,
        COALESCE(p.fp_abis1_count, 0) AS fp_abis1_count,
        COALESCE(p.fp_abis2_count, 0) AS fp_abis2_count,
        COALESCE(p.fp_abis3_count, 0) AS fp_abis3_count
    FROM td_agg t
    FULL OUTER JOIN fn_agg f
      ON t.mdd_decision_date = f.mdd_decision_date
    FULL OUTER JOIN tn_agg n
      ON COALESCE(t.mdd_decision_date, f.mdd_decision_date) = n.mdd_decision_date
    FULL OUTER JOIN fp_agg p
      ON COALESCE(t.mdd_decision_date, f.mdd_decision_date, n.mdd_decision_date) = p.mdd_decision_date
) AS source
ON target.mdd_decision_date = source.mdd_decision_date
WHEN MATCHED THEN
    UPDATE SET
        td_abis1_count = source.td_abis1_count,
        td_abis2_count = source.td_abis2_count,
        td_abis3_count = source.td_abis3_count,
        fn_abis1_count = source.fn_abis1_count,
        fn_abis2_count = source.fn_abis2_count,
        fn_abis3_count = source.fn_abis3_count,
        tn_abis1_count = source.tn_abis1_count,
        tn_abis2_count = source.tn_abis2_count,
        tn_abis3_count = source.tn_abis3_count,
        fp_abis1_count = source.fp_abis1_count,
        fp_abis2_count = source.fp_abis2_count,
        fp_abis3_count = source.fp_abis3_count
WHEN NOT MATCHED THEN
    INSERT (
        mdd_decision_date,
        td_abis1_count,
        td_abis2_count,
        td_abis3_count,
        fn_abis1_count,
        fn_abis2_count,
        fn_abis3_count,
        tn_abis1_count,
        tn_abis2_count,
        tn_abis3_count,
        fp_abis1_count,
        fp_abis2_count,
        fp_abis3_count
    )
    VALUES (
        source.mdd_decision_date,
        source.td_abis1_count,
        source.td_abis2_count,
        source.td_abis3_count,
        source.fn_abis1_count,
        source.fn_abis2_count,
        source.fn_abis3_count,
        source.tn_abis1_count,
        source.tn_abis2_count,
        source.tn_abis3_count,
        source.fp_abis1_count,
        source.fp_abis2_count,
        source.fp_abis3_count
    )
"""


def trino(query, host=trino_host, port=trino_port, user=trino_user):
    conn = None
    try:
        conn = connect(
            host=host,
            port=port,
            user=user
        )
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"query": query, "success": 1, "data": body}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}
    finally:
        if conn:
            conn.close()

def insertData(query):
    res = trino(query)
    if res['success'] == 1:
        print(f"Inserted Data: {res['data']}")
    else:
        error_msg = res.get('msg', 'Trino query failed')
        print(f"Insert Data Failed! {error_msg}")
        raise Exception(error_msg)

default_args = {
    'owner': 'inzamam.nisg',
    'depends_on_past': False,
    'start_date': datetime(2026, 8, 13),
    'email': ["techexe15.yp25@uidai.net.in", "techexecutive22-yp23@uidai.net.in", "techexecutive14-yp23@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 1
}

dag = DAG(
    'BSPS_FPFN_Metrics',
    default_args=default_args,
    description="Dag to insert bsps metrics into table",
    schedule="0 22 * * *",
    catchup=False,
    tags=["FPFN", "BSP", "ABIS"]
)

task = PythonOperator(
    task_id='insert_bsps_metrics',
    python_callable=insertData,
    op_kwargs={'query': query},
    dag=dag,
)

task