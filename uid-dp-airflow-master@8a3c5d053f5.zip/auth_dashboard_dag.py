from datetime import datetime, timedelta
import pandas as pd
import trino
import clickhouse_connect
from airflow.decorators import dag, task
from airflow.models import Variable
from airflow.hooks.base import BaseHook
from zoho_alerts import zoho_failure_callback


trino_host = "10.10.116.75"
trino_port = 8080
trino_user = "auth_db_user"

CLICKHOUSE_HOST = '10.10.120.95'
CLICKHOUSE_PORT = 8123
CLICKHOUSE_USER = 'default'
CLICKHOUSE_PASSWORD = 'qwerty'

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'on_failure_callback': zoho_failure_callback
}
# Define the DAG
@dag(
    dag_id='daily_trino_to_clickhouse_load',
    schedule='0 1 * * *',  # Runs at 1:00 AM UTC every day
    start_date=datetime(2026, 7, 25),
    catchup=False,
    tags=['trino', 'clickhouse', 'iceberg'],
    description='Loads daily peaks and model summaries from Trino to ClickHouse'
)
def trino_to_clickhouse_dag():

    # Helper function to get clients using Airflow Connections
    def get_clients():
        trino_client = trino.dbapi.connect(
            host=trino_host,
            port=trino_port,
            user=trino_user,
            catalog='flink_stream',
            schema='stream_auth'
        )

        ch_client = clickhouse_connect.get_client(
            host=CLICKHOUSE_HOST,
            port=CLICKHOUSE_PORT,
            username=CLICKHOUSE_USER,
            password=CLICKHOUSE_PASSWORD
        )
        return trino_client, ch_client

    # ==========================================================
    # TASK 1: Daily Overall Peaks
    # ==========================================================
    @task
    def load_daily_peaks(**kwargs):
        today = datetime.now()
    
    # 2. Calculate yesterday
        yesterday = today - timedelta(days=1)
        
        # 3. Format the 24-hour window
        # start_str = yesterday at 00:00:00
        start_str = yesterday.strftime('%Y-%m-%d 00:00:00')
        # end_str = today at 00:00:00
        end_str = today.strftime('%Y-%m-%d 00:00:00')
        query = f"""
        WITH per_timestamp_counts AS (
            SELECT
                CAST(event_timestamp AS DATE) AS txn_date,
                reqdatetime,
                COUNT(authresult) AS tps_count
            FROM flink_stream.stream_auth.auth_txn_raw_union_v1
            WHERE event_timestamp >= TIMESTAMP '{start_str}'
              AND event_timestamp <  TIMESTAMP '{end_str}'
            GROUP BY 1, 2
        ),
        ranked_peaks AS (
            SELECT
                txn_date,
                reqdatetime,
                tps_count,
                ROW_NUMBER() OVER (
                    PARTITION BY txn_date
                    ORDER BY tps_count DESC, reqdatetime DESC
                ) AS rn
            FROM per_timestamp_counts
        )
        SELECT
            txn_date,
            reqdatetime AS peak_timestamp,
            tps_count AS peak_tps
        FROM ranked_peaks
        WHERE rn = 1
        """
        
        trino_client, ch_client = get_clients()
        cursor = trino_client.cursor()
        cursor.execute(query)
        
        columns = [desc[0] for desc in cursor.description]
        df = pd.DataFrame(cursor.fetchall(), columns=columns)
        
        if not df.empty:
            df['txn_date'] = pd.to_datetime(df['txn_date']).dt.date
            ch_client.insert_df('auth_analytics.raw_peaktps_txn_daily', df)
            print(f"✅ Inserted {len(df)} rows into auth_analytics.raw_peaktps_txn_daily")
        else:
            print("⚠️ No data for auth_analytics.raw_peaktps_txn_daily")

    # ==========================================================
    # TASK 2: Daily Authtype Peaks (O, P, I, F, D)
    # ==========================================================
    @task
    def load_authtype_peaks(**kwargs):
        today = datetime.now()
    
    # 2. Calculate yesterday
        yesterday = today - timedelta(days=1)
        
        # 3. Format the 24-hour window
        # start_str = yesterday at 00:00:00
        start_str = yesterday.strftime('%Y-%m-%d 00:00:00')
        # end_str = today at 00:00:00
        end_str = today.strftime('%Y-%m-%d 00:00:00')

        query = f"""
        WITH per_timestamp_counts AS (
            SELECT
                CAST(event_timestamp AS DATE) AS txn_date,
                reqdatetime,
                COUNT(CASE WHEN authtype LIKE '%O%' THEN authresult END) AS tps_O,
                COUNT(CASE WHEN authtype LIKE '%P%' THEN authresult END) AS tps_P,
                COUNT(CASE WHEN authtype LIKE '%I%' THEN authresult END) AS tps_I,
                COUNT(CASE WHEN authtype LIKE '%F%' THEN authresult END) AS tps_F,
                COUNT(CASE WHEN authtype LIKE '%D%' THEN authresult END) AS tps_D
            FROM flink_stream.stream_auth.auth_txn_raw_union_v1
            WHERE event_timestamp >= TIMESTAMP '{start_str}'
              AND event_timestamp <  TIMESTAMP '{end_str}'
              AND (authtype LIKE '%O%' OR authtype LIKE '%P%' OR authtype LIKE '%I%' OR authtype LIKE '%F%' OR authtype LIKE '%D%')
            GROUP BY 1, 2
        ),
        unpivoted AS (
            SELECT txn_date, reqdatetime, 'O' AS auth_letter, tps_O AS tps_count FROM per_timestamp_counts WHERE tps_O > 0
            UNION ALL
            SELECT txn_date, reqdatetime, 'P' AS auth_letter, tps_P AS tps_count FROM per_timestamp_counts WHERE tps_P > 0
            UNION ALL
            SELECT txn_date, reqdatetime, 'I' AS auth_letter, tps_I AS tps_count FROM per_timestamp_counts WHERE tps_I > 0
            UNION ALL
            SELECT txn_date, reqdatetime, 'F' AS auth_letter, tps_F AS tps_count FROM per_timestamp_counts WHERE tps_F > 0
            UNION ALL
            SELECT txn_date, reqdatetime, 'D' AS auth_letter, tps_D AS tps_count FROM per_timestamp_counts WHERE tps_D > 0
        ),
        ranked_peaks AS (
            SELECT
                txn_date,
                auth_letter,
                reqdatetime,
                tps_count,
                ROW_NUMBER() OVER (
                    PARTITION BY txn_date, auth_letter
                    ORDER BY tps_count DESC, reqdatetime DESC
                ) AS rn
            FROM unpivoted
        )
        SELECT
            txn_date,
            auth_letter AS authtype,
            reqdatetime AS peak_timestamp,
            tps_count AS peak_tps
        FROM ranked_peaks
        WHERE rn = 1
        """
        
        trino_client, ch_client = get_clients()
        cursor = trino_client.cursor()
        cursor.execute(query)
        
        columns = [desc[0] for desc in cursor.description]
        df = pd.DataFrame(cursor.fetchall(), columns=columns)
        
        if not df.empty:
            df['txn_date'] = pd.to_datetime(df['txn_date']).dt.date
            ch_client.insert_df('auth_analytics.raw_truetps_txn_daily', df)
            print(f"✅ Inserted {len(df)} rows into auth_analytics.raw_truetps_txn_daily")
        else:
            print("⚠️ No data for auth_analytics.raw_truetps_txn_daily")

    # ==========================================================
    # TASK 3: Daily Model ID Summary
    # ==========================================================
    @task
    def load_modelid_summary(**kwargs):
        today = datetime.now()
    
    # 2. Calculate yesterday
        yesterday = today - timedelta(days=1)
        
        # 3. Format the 24-hour window
        # start_str = yesterday at 00:00:00
        start_str = yesterday.strftime('%Y-%m-%d 00:00:00')
        # end_str = today at 00:00:00
        end_str = today.strftime('%Y-%m-%d 00:00:00')
        
        query = f"""
        WITH base_data AS (
            SELECT
                date(reqdatetime) AS txn_date,
                sa AS requesting_entity_code,
                modelid,
                authresult AS status,
                errorcode,
                authtype AS modality,
                authcode
            FROM flink_stream.stream_auth.auth_txn_raw_union_v1
            WHERE event_timestamp >= TIMESTAMP '{start_str}'
              AND event_timestamp <  TIMESTAMP '{end_str}'
              AND modelid IS NOT NULL
              AND modelid <> ''
              AND TRY_CAST(devicecode AS UUID) IS NOT NULL
        )
        SELECT
            txn_date,
            requesting_entity_code,
            CASE
                WHEN modelid LIKE '%FM220U%' THEN 'FM220U'
                WHEN modelid LIKE '%MK2120U%' THEN 'MK2120UL'
                WHEN LENGTH(modelid) > 100 AND modelid NOT LIKE '% %' THEN 'Misc_Error'
                WHEN LENGTH(TRIM(modelid)) < 3 THEN 'Misc'
                ELSE SUBSTRING(REPLACE(modelid, ',', ''), 1, 100)
            END AS modelid,
            status,
            errorcode,
            modality,
            COUNT(authcode) AS total_txn
        FROM base_data
        GROUP BY 1, 2, 3, 4, 5, 6
        """
        
        trino_client, ch_client = get_clients()
        cursor = trino_client.cursor()
        cursor.execute(query)
        
        columns = [desc[0] for desc in cursor.description]
        df = pd.DataFrame(cursor.fetchall(), columns=columns)
        
        if not df.empty:
            df['txn_date'] = pd.to_datetime(df['txn_date']).dt.date
            # Cast string columns explicitly to avoid object dtype issues
            for col in ['requesting_entity_code', 'modelid', 'status', 'errorcode', 'modality']:
                df[col] = df[col].astype(str)
            
            ch_client.insert_df('auth_analytics.raw_modelid_re_txn_daily', df)
            print(f"✅ Inserted {len(df)} rows into auth_analytics.raw_modelid_re_txn_daily")
        else:
            print("⚠️ No data for auth_analytics.raw_modelid_re_txn_daily")

    # ==========================================================
    # TASK 4: Daily OTP Latency Percentiles (15-min windows)
    # ==========================================================
    @task
    def load_otp_latency_percentiles(**kwargs):
        query = """
        WITH aggregated_data AS (
            SELECT
                date_add('minute', (minute(event_timestamp) / 15) * 15, date_trunc('hour', event_timestamp)) AS window_start,
                COUNT(otp_result) AS total_count,
                approx_percentile(CAST(otp_duration AS BIGINT), ARRAY[0.80, 0.85, 0.90, 0.95, 0.98, 0.99]) AS percentiles
            FROM
                flink_stream.stream_auth.auth_otp_raw_union_v1
            WHERE
                event_timestamp >= CAST(current_date - INTERVAL '1' DAY AS TIMESTAMP)
                AND event_timestamp < CAST(current_date AS TIMESTAMP)
                AND aua_code != '0000340000'
                AND regexp_like(otp_duration, '^[0-9]+$')
            GROUP BY
                1
        )
        SELECT
            window_start,
            total_count,
            percentiles[1] AS p80_latency,
            percentiles[2] AS p85_latency,
            percentiles[3] AS p90_latency,
            percentiles[4] AS p95_latency,
            percentiles[5] AS p98_latency,
            percentiles[6] AS p99_latency
        FROM
            aggregated_data
        ORDER BY
            window_start
        """
        
        trino_client, ch_client = get_clients()
        cursor = trino_client.cursor()
        cursor.execute(query)
        
        columns = [desc[0] for desc in cursor.description]
        df = pd.DataFrame(cursor.fetchall(), columns=columns)
        
        if not df.empty:
            # window_start is already a TIMESTAMP, pandas converts it to datetime64[ns]
            ch_client.insert_df('auth_analytics.auth_otp_txn_latency_agg', df)
            print(f"✅ Inserted {len(df)} rows into auth_analytics.auth_otp_txn_latency_agg")
        else:
            print("⚠️ No data for auth_analytics.auth_otp_txn_latency_agg")

    # ==========================================================
    # TASK 5: Daily AUTH TXN Latency Percentiles (15-min windows)
    # ==========================================================
    @task
    def load_auth_txn_latency_percentiles(**kwargs):
        query = """
        WITH aggregated_data AS (
            SELECT 
                date_add('minute', (minute(event_timestamp) / 15) * 15, date_trunc('hour', event_timestamp)) AS window_start,
                COUNT(authresult) AS total_count,
                approx_percentile(authDuration, ARRAY[0.80, 0.85, 0.90, 0.95, 0.98, 0.99]) AS percentiles
            FROM 
                flink_stream.stream_auth.auth_txn_raw_union_v1
            WHERE 
                event_timestamp >= CAST(current_date - INTERVAL '1' DAY AS TIMESTAMP)
                AND event_timestamp < CAST(current_date AS TIMESTAMP)
                AND aua != '0000340000'
            GROUP BY 
                1 
        )
        SELECT 
            window_start,
            total_count,
            percentiles[6] AS p99_latency,
            percentiles[5] AS p98_latency,
            percentiles[4] AS p95_latency,
            percentiles[3] AS p90_latency,
            percentiles[2] AS p85_latency,
            percentiles[1] AS p80_latency
        FROM 
            aggregated_data
        ORDER BY 
            window_start
        """
        
        trino_client, ch_client = get_clients()
        cursor = trino_client.cursor()
        cursor.execute(query)
        
        columns = [desc[0] for desc in cursor.description]
        df = pd.DataFrame(cursor.fetchall(), columns=columns)
        
        if not df.empty:
            ch_client.insert_df('auth_analytics.auth_txn_latency_agg', df)
            print(f"✅ Inserted {len(df)} rows into auth_analytics.auth_txn_latency_agg")
        else:
            print("⚠️ No data for auth_analytics.auth_txn_latency_agg")

    # ==========================================================
    # TASK 6: Daily KYC Latency Percentiles (15-min windows)
    # ==========================================================
    @task
    def load_kyc_latency_percentiles(**kwargs):
        query = """
        WITH aggregated_data AS (
            SELECT 
                date_add('minute', (minute(event_timestamp) / 15) * 15, date_trunc('hour', event_timestamp)) AS window_start,
                COUNT(version) AS total_count,
                approx_percentile(kyc_duration, ARRAY[0.80, 0.85, 0.90, 0.95, 0.98, 0.99]) AS percentiles
            FROM 
                flink_stream.stream_auth.auth_kyc_raw_union_v1
            WHERE 
                event_timestamp >= CAST(current_date - INTERVAL '1' DAY AS TIMESTAMP)
                AND event_timestamp < CAST(current_date AS TIMESTAMP)
                AND kua != '0000340000'
            GROUP BY 
                1 
        )
        SELECT 
            window_start,
            total_count,
            percentiles[6] AS p99_latency,
            percentiles[5] AS p98_latency,
            percentiles[4] AS p95_latency,
            percentiles[3] AS p90_latency,
            percentiles[2] AS p85_latency,
            percentiles[1] AS p80_latency
        FROM 
            aggregated_data
        ORDER BY 
            window_start
        """
        
        trino_client, ch_client = get_clients()
        cursor = trino_client.cursor()
        cursor.execute(query)
        
        columns = [desc[0] for desc in cursor.description]
        df = pd.DataFrame(cursor.fetchall(), columns=columns)
        
        if not df.empty:
            ch_client.insert_df('auth_analytics.auth_kyc_txn_latency_agg', df)
            print(f"✅ Inserted {len(df)} rows into auth_analytics.auth_kyc_txn_latency_agg")
        else:
            print("⚠️ No data for auth_analytics.auth_kyc_txn_latency_agg")

    # Call tasks in series
    load_daily_peaks() >> load_authtype_peaks() >> load_modelid_summary() >> load_otp_latency_percentiles() >> load_auth_txn_latency_percentiles() >> load_kyc_latency_percentiles()

# Instantiate the DAG
dag_instance = trino_to_clickhouse_dag()


# ==========================================================
# MONTHLY AGGREGATION DAG
# ==========================================================
from dateutil.relativedelta import relativedelta


@dag(
    dag_id='monthly_auth_txn_aggregation_load',
    schedule='0 1 1 * *',  # Runs at 1:00 AM UTC on the 1st of every month
    start_date=datetime(2026, 10, 1),
    catchup=False,
    tags=['trino', 'clickhouse', 'monthly_aggregation'],
    description='Loads monthly aggregated auth transaction data from Trino to ClickHouse'
)
def monthly_auth_aggregation_dag():

    # Helper function to get clients
    def get_clients():
        trino_client = trino.dbapi.connect(
            host=trino_host,
            port=trino_port,
            user=trino_user,
            catalog='flink_stream',
            schema='stream_auth'
        )

        ch_client = clickhouse_connect.get_client(
            host=CLICKHOUSE_HOST,
            port=CLICKHOUSE_PORT,
            username=CLICKHOUSE_USER,
            password=CLICKHOUSE_PASSWORD
        )
        return trino_client, ch_client

    @task
    def load_monthly_auth_aggregation(**kwargs):
        """
        Load monthly aggregated auth transaction data for the previous month
        and insert into auth_analytics.auth_txn_aggr_monthly_v6_dist
        """
        # Get execution date
        execution_date = kwargs['execution_date']
        
        # Calculate previous month's date range
        month_start = execution_date.replace(day=1) - relativedelta(months=1)
        month_end = execution_date.replace(day=1)
        
        start_date = month_start
        end_date = month_end - relativedelta(days=1)
        
        print(f"Processing data for period: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
        
        df = pd.DataFrame()
        
        # Generate queries for the previous month
        current = start_date
        while current <= end_date:
            next_month = current + relativedelta(months=1)
            month_str = current.strftime("%Y-%m")
            
            start_timestamp = current.strftime("%Y-%m-%d 00:00:00")
            end_timestamp = next_month.strftime("%Y-%m-%d 00:00:00")

            print(f"# Month: {month_str}")
            
            query = trino(f"""
select 
CAST(date_trunc('month', t.reqdatetime) AS DATE) AS txn_month,
cast(t.asa as varchar) as asa_code,
t.aua as aua_code,
t.sa as subaua_code,
t.authtype as modality_code,
cast(t.errorcode as varchar) as errorcode,
t.authresult as status,
count(t.authcode) as total_txn
from flink_stream.stream_auth.auth_txn_raw_union_v1 t
WHERE t.reqdatetime >= TIMESTAMP '{start_timestamp}' 
  AND t.reqdatetime <  TIMESTAMP '{end_timestamp}' 
  AND t.event_timestamp >= TIMESTAMP '{start_timestamp}' - interval '1' day
  AND t.event_timestamp <  TIMESTAMP '{end_timestamp}' + interval '1' day
group by 1,2,3,4,5,6,7
""")['df']

            df = pd.concat([df, query], ignore_index=True)
            print(f"# Month: {month_str} - Shape: {df.shape}")
            
            current = next_month
        
        # Date conversion
        df['txn_month'] = pd.to_datetime(df['txn_month']).dt.date

        # String columns with NULL check
        string_columns = ['asa_code', 'aua_code', 'subaua_code', 'modality_code', 'errorcode', 'status']
        total_nulls = 0

        for col in string_columns:
            null_count = df[col].isnull().sum()
            if null_count > 0:
                total_nulls += null_count
                df[col] = df[col].fillna('')
            df[col] = df[col].astype(str)

        if total_nulls > 0:
            print(f"  ⚠ Found {total_nulls} NULLs - filled with empty strings")
        else:
            print(f"  ✓ No NULLs found - everything's good")

        # Numeric conversion
        df['total_txn'] = df['total_txn'].fillna(0).astype('int64')

        # Calculate financial year based on current date
        financial_year = f"{execution_date.year}-{execution_date.year + 1}"
        df.insert(0, column='financial_year', value=financial_year)
        
        print(f"  ✓ Transformations complete - Total rows: {len(df)}")
        
        # Insert into ClickHouse
        trino_client, ch_client = get_clients()
        result = ch_client.insert_df('auth_analytics.auth_txn_aggr_monthly_v6_dist', df)
        print(f"✅ Inserted {result.written_rows} rows into auth_analytics.auth_txn_aggr_monthly_v6_dist")

    load_monthly_auth_aggregation()


# Instantiate the monthly DAG
monthly_dag_instance = monthly_auth_aggregation_dag()