import pandas as pd
import json
import ast
import os
from trino.dbapi import connect
from datetime import datetime, timedelta
from airflow import DAG
from airflow.exceptions import AirflowSkipException
from airflow.operators.python import PythonOperator
from airflow.operators.email import EmailOperator

TRINO_HOST = "10.10.118.35"
TRINO_PORT = 8080
TRINO_USER = "sai.nisg"

def trino(query, catalog='flink_stream', schema='stream_enu', host=TRINO_HOST, port=TRINO_PORT, user=TRINO_USER):
    conn = None
    cur = None
    try:
        conn = connect(
            host=host,
            port=port,
            user=user,
            catalog=catalog,
            schema=schema
        )
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()

        if not body:
            return {"query": query, "success": 1, "data": body, "df": pd.DataFrame()}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}

    except Exception as e:
        error_msg = f"Trino Query Failed: {str(e)}\nQuery: {query}"
        print(error_msg)
        raise Exception(error_msg)

    finally:
        try:
            if cur is not None:
                cur.close()
        except Exception:
            pass
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass

default_args = {
    'owner': 'Jithendra Sai T',
    'depends_on_past': False,
    'email_on_failure': True,
    'email_on_retry': True,
    "email": ["junior.devfsd6-tc@uidai.net.in"],
    'retries': 10,
    'retry_delay': timedelta(minutes=2),
}

with DAG(
    dag_id='boi_ind_face_match_extract',
    default_args=default_args,
    description='Extracts face match data weekly from Sunday to Saturday',
    schedule='0 6 * * 1',
    start_date=datetime(2026, 7, 31),
    catchup=False,
    tags=['boi', 'face_match', 'weekly'],
) as dag:

    def process_face_match_data(**context):
        run_date = context['ds']
        prev_day = context['macros'].ds_add(run_date, -1)
        prev_sunday = context['macros'].ds_add(run_date, -7)

        query1 = f"""
        SELECT
            *
        FROM
            strot.mysql_uid_v2.request_tracker
        WHERE stage_reject_reason_code = 'RESIDENT_FACE_MATCH_FOUND'
          AND stage = 'PostEnrolment'
          AND stage_status = 'Completed'
          AND last_updated_date >= DATE '{prev_sunday}'
          AND last_updated_date < DATE '{run_date}'
        """

        print("Executing Query 1:")
        print(query1)

        df_tracker = trino(query1)['df']

        if df_tracker is None or df_tracker.empty:
            msg = (f"[SKIP] No rows returned from request_tracker for "
                   f"window {prev_sunday} -> {prev_day}. "
                   f"Nothing to process; email will NOT be sent.")
            print(msg)
            raise AirflowSkipException(msg)

        if 'refid' not in df_tracker.columns or 'sid' not in df_tracker.columns:
            msg = (f"[SKIP] Columns 'refid'/'sid' not found in request_tracker "
                   f"result. Columns returned: {list(df_tracker.columns)}")
            print(msg)
            raise AirflowSkipException(msg)

        refid_sid_map = (
            df_tracker[['refid', 'sid']]
            .dropna()
            .drop_duplicates()
            .reset_index(drop=True)
        )

        ref_ids = refid_sid_map['refid'].dropna().unique().tolist()
        if not ref_ids:
            msg = "[SKIP] No valid refids after cleaning. Nothing to process."
            print(msg)
            raise AirflowSkipException(msg)

        ref_ids_formatted = ", ".join(
            ["'" + str(rid).replace("'", "''") + "'" for rid in ref_ids]
        )

        query2 = f"""
        SELECT
            ref_id,
            matched_fileno
        FROM
            flink_stream.stream_enu.extint_facededup_v1
        WHERE
            ref_id IN ({ref_ids_formatted})
        """

        print("Executing Query 2:")
        print(query2)

        result_df = trino(query2)['df']

        if result_df is None or result_df.empty:
            msg = (f"[SKIP] No rows returned from extint_facededup_v1 "
                   f"for the given ref_ids. Nothing to process; "
                   f"email will NOT be sent.")
            print(msg)
            raise AirflowSkipException(msg)

        df = result_df.dropna(subset=['matched_fileno']).copy()
        df = df[~df['matched_fileno']
                   .astype(str).str.strip()
                   .isin(['[]', 'null', 'None', ''])]

        def parse_list(val):
                try:
                    parsed = ast.literal_eval(val)
                    if isinstance(parsed, list):
                        return [str(item) for item in parsed]
                    return []
                except Exception:
                    return []

        df['parsed_list'] = df['matched_fileno'].apply(parse_list)
        df = df[df['parsed_list'].apply(len) > 0]

        if df.empty:
            msg = ("[SKIP] All probable_duplicate_list values were empty "
                   "or unparseable. Nothing to process; "
                   "email will NOT be sent.")
            print(msg)
            raise AirflowSkipException(msg)

        df_exploded = df.explode('parsed_list')
        df_exploded['fileNo'] = df_exploded['parsed_list']

        final_df = df_exploded.merge(
            refid_sid_map, left_on='ref_id', right_on='refid', how='inner'
        )
        final_df = final_df[['sid', 'ref_id', 'fileNo']].dropna(subset=['fileNo'])

        final_df = final_df['fileNo']

        if final_df.empty:
            print("No rows found!")
        else:
            print(final_df)

        if final_df.empty:
            msg = ("[SKIP] After merge, no rows with valid fileNo. "
                   "Email will NOT be sent.")
            print(msg)
            raise AirflowSkipException(msg)

        output_filename = f"/tmp/FileNos_{prev_sunday}_to_{prev_day}.csv"
        final_df.to_csv(output_filename, index=False)

        print(f"Successfully processed. Saved {len(final_df)} rows "
              f"to {output_filename}")

    def cleanup_temp_files(**context):
        run_date = context['ds']
        prev_day = context['macros'].ds_add(run_date, -1)
        prev_sunday = context['macros'].ds_add(run_date, -7)

        files_to_delete = [
            f"/tmp/FileNos_{prev_sunday}_to_{prev_day}.csv"
        ]

        deleted_any = False
        for file_path in files_to_delete:
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
                    print(f"Successfully deleted: {file_path}")
                    deleted_any = True
            except Exception as e:
                print(f"Warning: Could not delete {file_path}. Error: {str(e)}")

        if not deleted_any:
            print("No temporary files found to delete.")

    run_extract_task = PythonOperator(
        task_id='run_face_match_extract',
        python_callable=process_face_match_data
    )

    send_email_task = EmailOperator(
        task_id='send_email_consolidated',
        to=['dir.enf-hq@uidai.net.in','hoe.dev-tc@uidai.net.in'],
        cc=['productmgr4-tc@uidai.net.in','junior.devfsd6-tc@uidai.net.in'],
        subject="Weekly Data Extract: File Numbers for BOI Face Match",
        html_content=("Dear Team,<br><br>"
                      "Please find attached the CSV file containing the file numbers of BOI face match with rejection code "
                      "<b>RESIDENT_FACE_MATCH_FOUND</b> for the period {{ macros.ds_add(ds, -7) }} to {{ macros.ds_add(ds, -1) }}."),
        files=['/tmp/FileNos_{{ macros.ds_add(ds, -7) }}_to_{{ macros.ds_add(ds, -1) }}.csv'],
        conn_id='smtp_default',
        from_email='strot@uidai.net.in'
    )

    cleanup_task = PythonOperator(
        task_id='cleanup_temp_files',
        python_callable=cleanup_temp_files,
        trigger_rule='all_done'
    )

    run_extract_task >> send_email_task >> cleanup_task