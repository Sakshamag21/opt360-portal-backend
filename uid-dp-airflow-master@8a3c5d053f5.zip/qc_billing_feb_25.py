from airflow.sdk import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from trino.dbapi import connect


trino_host="10.10.116.75"
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="airflow_dag_op"

insert_into_qc_report_p1='''
MERGE INTO strot.operator360.eid_qc_error_report_v2 as t
USING (select * from (
with
tabT as (
    select packeteid, dmsdispositiondetails, allocatedlevel,errorcode,dispositionstatus ,isfinal from flink_stream.stream_qc.qc_operator_disposition WHERE 
    vendorid != '45168a64-4564-47c0-a8cb-d5e35ec03126' AND 
    ((isfinal= false and (allocatedlevel='L1' or allocatedlevel='L2')) or (isfinal=true and dispositionstatus='Rejected')) AND
    packetstage = 'QC' AND 
    packeteid not like '000000%'
),

tabT_l3 as (
select * from tabT where allocatedlevel='L3'
),

tabT_l1_l2 as (
select * from tabT where packeteid not in (select packeteid from tabT_l3)
),

tabT_comb as (
select * from tabT_l3
union all
select * from tabT_l1_l2
),

tab1_2 as(
    select t.packeteid, t.allocatedlevel, t.dmsdispositiondetails, t.dispositionstatus,t.isfinal,
    array_except(array_union(
    ARRAY_DISTINCT(
     ARRAY_EXCEPT(
      FLATTEN(
       TRANSFORM(
         ARRAY_AGG(t.errorcode), x ->
          CASE
             WHEN STRPOS(x, '|') > 0 THEN SPLIT(x, '|')
             ELSE ARRAY[x]
          END
        )
       ) , ARRAY['', NULL]
      )
     ),
     ARRAY_DISTINCT(
      ARRAY_EXCEPT(
       FLATTEN(
         TRANSFORM(
          ARRAY_AGG(c.errorcode), x ->
            CASE
             WHEN STRPOS(x, '|') > 0 THEN SPLIT(x, '|')
             ELSE ARRAY[x]
            END
          )
        ), ARRAY['', NULL]
      )
     )), ARRAY[NULL]) as error_codes

     from tabT_comb t left join unnest(dmsdispositiondetails) as c on true
      group by 1,2,3,4,5
),
tab1_1 as (
 select distinct packeteid, actionedat
 from flink_stream.stream_qc.qc_vendor_completion
 where date(actionedat) =date(date_add('day', -1, now()))
 and actiontaken = 'Vendor WF Completed'
 and packeteid not like '000000%'
 ),
 tab2_1 as (
 select * from (
 select t.packeteid, max(t.allocatedlevel) as allocatedlevel, arbitrary(t.dmsdispositiondetails) as dmsdispositiondetails,max(t.dispositionstatus) as dispositionstatus, bool_or(t.isfinal) as isfinal,flatten(array_agg(t.error_codes)) as error_codes, max(a.actionedat) as actionedat from tab1_2 t 
 join tab1_1 a on a.packeteid=t.packeteid
 where t.dispositionstatus='Rejected'
 and t.dmsdispositiondetails is not null 
  group by t.packeteid) where isfinal=true
 ),
tab1_3 AS (
 SELECT packeteid, allocatedlevel, actionedat, error_codes, e
 FROM (
 SELECT packeteid, allocatedlevel, actionedat,
 error_codes,
 CASE
 WHEN STRPOS(x,'|') > 0 THEN SPLIT(x,'|')
 ELSE ARRAY[x]
 END AS ec
 FROM tab2_1, UNNEST(error_codes) AS err(x)
 ), UNNEST(ec) AS ec(e)
 )
 ,
 tab2_3 AS (
 SELECT t1.packeteid, t1.allocatedlevel, t1.actionedat,
 t1.error_codes,t2.error_category
 FROM tab1_3 t1
 JOIN strot.misc_adhoc.qc_error_mapping t2 ON t1.e = t2.error_code
 ),
 tab3_3 AS (
 SELECT packeteid, allocatedlevel, actionedat,
 error_codes,
 ARRAY_DISTINCT(ARRAY_AGG(error_category)) AS error_categories
 FROM tab2_3
 GROUP BY 1, 2, 3, 4
 ),
 
 tab4_3 AS (
 SELECT packeteid, allocatedlevel, actionedat,error_codes,
 error_categories,error_category,priority,
 ROW_NUMBER() OVER(PARTITION BY packeteid ORDER BY priority) AS rn
 FROM (
 SELECT * FROM tab3_3,
 UNNEST(error_categories) AS err_cat(err)
 ) AS s
 JOIN (SELECT * FROM strot.misc_adhoc.qc_error_mapping) AS m ON s.err = m.error_category
 ),
 tab5_3 AS (
 SELECT packeteid, allocatedlevel, actionedat,
 error_codes,error_categories,error_category,
 priority
 FROM tab4_3 WHERE rn = 1
 ),
 tab1_4_1 AS (
 SELECT t1.*, t2.operator_id AS session_operatorid
 FROM tab5_3 t1
 LEFT JOIN strot.mysql_uid_v2.request_tracker t2 ON t1.packeteid = t2.sid
 where date(t2.last_updated_date)>=date(current_date - interval '90' day)
 ),

 tab2_4 AS (
 SELECT t1.user_code,t1.user_name,CAST(t1.user_uid AS VARCHAR) AS user_uid,t1.user_email_id,
 t2.org_code AS ea_code,t2.org_name AS ea_name,
 t3.org_code AS reg_code,t3.org_name AS reg_name
 FROM mysql_uidmasterv1.uidmasterv1_1.user t1
 JOIN mysql_uidmasterv1.uidmasterv1_1.organization t2 ON t1.user_org_key = t2.org_key
 JOIN mysql_uidmasterv1.uidmasterv1_1.organization t3 ON t1.user_reg_org_key = t3.org_key
 ),
 tab3_4 as (
 select *,row_number() over(partition by packeteid order by allocatedlevel desc) as rn
 from tab1_4_1 t1
 left join tab2_4 t2 on upper(t1.session_operatorid)=upper(t2.user_code)
 ),
 tab1_5 as(
 select packeteid, DATE_PARSE(SUBSTRING(packeteid, 15, 8), '%Y%m%d') as packet_Date, actionedat as
check_date,
 case
 when allocatedlevel='L1' or allocatedlevel='L2' then 'QCOperator'
 else 'QCReviewer'
 end as dispositionrole,
 error_codes,error_categories,error_category,priority,session_operatorid as operator_id,user_name,user_uid,
user_email_id,ea_code,ea_name,reg_code,reg_name from tab3_4 where rn = 1
 ),
 tab2_5 as (
 SELECT s.*, m.description,
 ROW_NUMBER() OVER(PARTITION BY packeteid) AS rn
 FROM (
 SELECT * FROM tab1_5,
 UNNEST(error_codes) AS err_cat(error_code)
 ) AS s
 JOIN strot.misc_adhoc.qc_Error_mapping AS m
 ON s.error_category = m.error_category and s.error_code = m.error_code and s.error_code is NOT NULL
 ),
 tab3_5 as (
 select * from tab2_5 where rn=1
 )


select *, current_timestamp as last_updated_at, case when 1=1 then false else true end as is_audit_rejected, case when 1=1 then false else true end as is_audited from tab3_5
 
)) as s
ON t.packeteid = s.packeteid
WHEN NOT MATCHED
    THEN INSERT(packeteid, packet_date, check_date, dispositionrole, error_codes, error_categories, error_category, priority, 
    operator_id, user_name, user_uid, user_email_id, ea_code, ea_name, reg_code, reg_name, error_code, description, is_audit_rejected, is_audited, rn, last_updated_at)
    
    VALUES(s.packeteid, s.packet_date, s.check_date, s.dispositionrole, s.error_codes, s.error_categories, s.error_category, s.priority, s.operator_id, 
    s.user_name, s.user_uid, s.user_email_id, s.ea_code, s.ea_name, s.reg_code, s.reg_name, s.error_code, s.description, s.is_audit_rejected, s.is_audited, s.rn, s.last_updated_at)
  
'''

insert_into_qc_report_p2='''
MERGE INTO strot.operator360.eid_qc_error_report_v2 as t
USING (select * from (
 with
tabT as (
    select packeteid, dmsdispositiondetails, allocatedlevel,errorcode,dispositionstatus ,isfinal from flink_stream.stream_qc.qc_operator_disposition WHERE 
    vendorid = '45168a64-4564-47c0-a8cb-d5e35ec03126' AND 
    ((isfinal= false and (allocatedlevel='L1' or allocatedlevel='L2')) or (isfinal=true and dispositionstatus='Rejected')) AND 
    packeteid not like '000000%'
),

tabT_l3 as (
select * from tabT where allocatedlevel='L3'
),

tabT_l1_l2 as (
select * from tabT where packeteid not in (select packeteid from tabT_l3)
),

tabT_comb as (
select * from tabT_l3
union all
select * from tabT_l1_l2
),

tab1_2 as(
    select t.packeteid, t.allocatedlevel, t.dmsdispositiondetails, t.dispositionstatus,t.isfinal,
    array_except(array_union(
    ARRAY_DISTINCT(
     ARRAY_EXCEPT(
      FLATTEN(
       TRANSFORM(
         ARRAY_AGG(t.errorcode), x ->
          CASE
             WHEN STRPOS(x, '|') > 0 THEN SPLIT(x, '|')
             ELSE ARRAY[x]
          END
        )
       ) , ARRAY['', NULL]
      )
     ),
     ARRAY_DISTINCT(
      ARRAY_EXCEPT(
       FLATTEN(
         TRANSFORM(
          ARRAY_AGG(c.errorcode), x ->
            CASE
             WHEN STRPOS(x, '|') > 0 THEN SPLIT(x, '|')
             ELSE ARRAY[x]
            END
          )
        ), ARRAY['', NULL]
      )
     )), ARRAY[NULL]) as error_codes

     from tabT_comb t left join unnest(dmsdispositiondetails) as c on true
      group by 1,2,3,4,5
),
tab1_1 as (
 select distinct packeteid, actionedat
 from flink_stream.stream_qc.qc_vendor_completion_audit
 where date(actionedat) =date(date_add('day', -1, now()))
 and actiontaken = 'Vendor WF Completed'
 and packeteid not like '000000%'
 and recipiententityvendorid = '45168a64-4564-47c0-a8cb-d5e35ec03126'
 ),
 tab2_1 as (
 select * from (
 select t.packeteid, max(t.allocatedlevel) as allocatedlevel, arbitrary(t.dmsdispositiondetails) as dmsdispositiondetails,max(t.dispositionstatus) as dispositionstatus, bool_or(t.isfinal) as isfinal,flatten(array_agg(t.error_codes)) as error_codes, max(a.actionedat) as actionedat from tab1_2 t 
 join tab1_1 a on a.packeteid=t.packeteid
 where t.dispositionstatus='Rejected'
 and t.dmsdispositiondetails is not null 
  group by t.packeteid) where isfinal=true
 ),
tab1_3 AS (
 SELECT packeteid, allocatedlevel, actionedat, error_codes, e
 FROM (
 SELECT packeteid, allocatedlevel, actionedat,
 error_codes,
 CASE
 WHEN STRPOS(x,'|') > 0 THEN SPLIT(x,'|')
 ELSE ARRAY[x]
 END AS ec
 FROM tab2_1, UNNEST(error_codes) AS err(x)
 ), UNNEST(ec) AS ec(e)
 )
 ,
 tab2_3 AS (
 SELECT t1.packeteid, t1.allocatedlevel, t1.actionedat,
 t1.error_codes,t2.error_category
 FROM tab1_3 t1
 JOIN strot.misc_adhoc.qc_error_mapping t2 ON t1.e = t2.error_code
 ),
 tab3_3 AS (
 SELECT packeteid, allocatedlevel, actionedat,
 error_codes,
 ARRAY_DISTINCT(ARRAY_AGG(error_category)) AS error_categories
 FROM tab2_3
 GROUP BY 1, 2, 3, 4
 ),
 
 tab4_3 AS (
 SELECT packeteid, allocatedlevel, actionedat,error_codes,
 error_categories,error_category,priority,
 ROW_NUMBER() OVER(PARTITION BY packeteid ORDER BY priority) AS rn
 FROM (
 SELECT * FROM tab3_3,
 UNNEST(error_categories) AS err_cat(err)
 ) AS s
 JOIN (SELECT * FROM strot.misc_adhoc.qc_error_mapping) AS m ON s.err = m.error_category
 ),
 tab5_3 AS (
 SELECT packeteid, allocatedlevel, actionedat,
 error_codes,error_categories,error_category,
 priority
 FROM tab4_3 WHERE rn = 1
 ),
 tab1_4_1 AS (
 SELECT t1.*, t2.operator_id AS session_operatorid
 FROM tab5_3 t1
 LEFT JOIN strot.mysql_uid_v2.request_tracker t2 ON t1.packeteid = t2.sid
 where date(t2.last_updated_date)>=date(current_date - interval '90' day)
 ),

 tab2_4 AS (
 SELECT t1.user_code,t1.user_name,CAST(t1.user_uid AS VARCHAR) AS user_uid,t1.user_email_id,
 t2.org_code AS ea_code,t2.org_name AS ea_name,
 t3.org_code AS reg_code,t3.org_name AS reg_name
 FROM mysql_uidmasterv1.uidmasterv1_1.user t1
 JOIN mysql_uidmasterv1.uidmasterv1_1.organization t2 ON t1.user_org_key = t2.org_key
 JOIN mysql_uidmasterv1.uidmasterv1_1.organization t3 ON t1.user_reg_org_key = t3.org_key
 ),
 tab3_4 as (
 select *,row_number() over(partition by packeteid order by allocatedlevel desc) as rn
 from tab1_4_1 t1
 left join tab2_4 t2 on upper(t1.session_operatorid)=upper(t2.user_code)
 ),


 
 tab1_5 as(
 select packeteid, DATE_PARSE(SUBSTRING(packeteid, 15, 8), '%Y%m%d') as packet_Date, actionedat as
check_date,
 case
 when allocatedlevel='L1' or allocatedlevel='L2' then 'AuditOperator'
 else 'AuditReviewer'
 end as dispositionrole,
 error_codes,error_categories,error_category,priority,session_operatorid as operator_id,user_name,user_uid,
user_email_id,ea_code,ea_name,reg_code,reg_name from tab3_4 where rn = 1
 ),
 tab2_5 as (
 SELECT s.*, m.description,
 ROW_NUMBER() OVER(PARTITION BY packeteid) AS rn
 FROM (
 SELECT * FROM tab1_5,
 UNNEST(error_codes) AS err_cat(error_code)
 ) AS s
 JOIN strot.misc_adhoc.qc_Error_mapping AS m
 ON s.error_category = m.error_category and s.error_code = m.error_code and s.error_code is NOT NULL
 ),
 tab3_5 as (
 select * from tab2_5 where rn=1
 )

 select *, current_timestamp as last_updated_at, case when priority!='3' then true else false end as
is_audit_rejected,case when 1=1 then true else false end as is_audited from tab3_5

)) as s
ON t.packeteid = s.packeteid
WHEN MATCHED
    THEN UPDATE SET check_date = s.check_date, dispositionrole = s.dispositionrole, error_codes = s.error_codes, error_categories = s.error_categories, error_category = s.error_category,
    error_code = s.error_code, description = s.description, last_updated_at = s.last_updated_at, is_audit_rejected = s.is_audit_rejected, priority = s.priority, is_audited = s.is_audited
  
'''

opt_error="""
MERGE INTO strot.operator360.operator_error_notif as target
    USING (
      SELECT operator_id, user_email_id, cast(user_uid as varchar) as userid, user_name, error_category, error_code, error_description, 
      ea_code, ea_name, reg_code, reg_name, cast(rn as integer) as count, packeteid as error_eid, 
      'EMAIL' as notif_channel, False as notif_sent, NULL as rcs_txn_id, cast(NOW() as timestamp(6)) as created_at,
      cast(NOW() as timestamp(6)) as modified_at,
      (
        CASE 
            WHEN error_category ='DOE 1' THEN 
                (CASE WHEN rn % 3 = 0 THEN 'SUSPENSION' ELSE 'WARNING' END )
            WHEN error_category ='DOE 2' THEN 
                (CASE WHEN rn % 30 = 0 THEN 'SUSPENSION' ELSE 'WARNING' END )
            WHEN error_category = 'POP' THEN 'SUSPENSION' 
        END
      ) as notif_type FROM (
           SELECT * FROM (
              SELECT operator_id, packeteid, check_date, error_category, error_code, user_name, user_uid, user_email_id, description as error_description, 
              ea_code, ea_name, reg_code, reg_name, ROW_NUMBER() OVER (PARTITION BY operator_id,error_category ORDER BY check_date) AS rn
               
              FROM strot.operator360.eid_qc_error_report_v2
              where error_category IS NOT NULL and Month(last_updated_at)=Month(now())
            )
            where (error_category='DOE 1' and rn <4) or (error_category='DOE 2' and rn in (10,20,25,30)) or (error_category='POP' and rn <2)
        )
    ) as s
    on target.error_eid = s.error_eid
            
    WHEN NOT MATCHED
        THEN INSERT (
          opt_id, opt_email, opt_uid, opt_name, error_category, error_count, error_eid, notif_channel, ea_code, ea_name, reg_code, reg_name, 
          notif_sent, rcs_transaction_id, created_at, last_updated_at, notif_type, error_code, error_description
        )
        VALUES(
          s.operator_id, s.user_email_id, s.userid, s.user_name, s.error_category, s.count, s.error_eid, s.notif_channel, s.ea_code, s.ea_name, s.reg_code, s.reg_name,
          s.notif_sent, s.rcs_txn_id, s.created_at, s.modified_at, s.notif_type, s.error_code, s.error_description
        )
"""

default_args = {
    'owner': 'harsha',
    'depends_on_past': False,
    'start_date': datetime(2025, 6, 16),
    'email': ['techexecutive14-yp23@uidai.net.in'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 1
}

dag = DAG(
    'qc_billing_error_report_feb25',
    default_args=default_args,
    description='DAG to insert error eids into qc error report according feb 2025',
    schedule="0 6 * * *",
    catchup=False
)

def run_query(query,host=trino_host,port=trino_port,user=trino_user):
    conn = connect(
        host=host,
        port=port,
        user=user,
        )
    cur = conn.cursor()
    cur.execute(query)
    return {"success": 1}



qc_billing_task = PythonOperator(
                task_id='insert_into_qc_report_p1',
                python_callable=run_query,
                op_kwargs={'query': insert_into_qc_report_p1},
                trigger_rule='all_done',
                dag=dag,
            )

opt_error_task = PythonOperator(
                task_id='insert_into_qc_report_p2',
                python_callable=run_query,
                op_kwargs={'query': insert_into_qc_report_p2},
                trigger_rule='all_done',
                dag=dag,
            )

opt_error_notif_task = PythonOperator(
                task_id='trigger_opt_mail',
                python_callable=run_query,
                op_kwargs={'query': opt_error},
                trigger_rule='all_done',
                dag=dag,
            )

qc_billing_task>>opt_error_task>>opt_error_notif_task