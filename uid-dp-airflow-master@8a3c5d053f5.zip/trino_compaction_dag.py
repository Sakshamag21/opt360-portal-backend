from airflow.sdk import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from trino.dbapi import connect
import boto3
import yaml
import pandas as pd 

trino_host="10.10.116.75"
trino_port=8080
trino_user="compaction_dag"


def trino(query, host=trino_host, port=trino_port, user=trino_user):
    conn = None
    try:
        conn = connect(
            host=host,
            port=port,
            user=user
        )
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"query": query, "success": 1, "data": body}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}
    finally:
        if conn:
            conn.close()


def load_tables_from_s3():
    try:
        local_yaml_path = '/tmp/comp_tables.yaml'

        session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4')
        s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425')
        s3_client.download_file('prd-bi-data-platform-uploads', 'sparkjobs/compaction/comp_tables_trino.yaml', '/tmp/comp_tables.yaml')

        with open(local_yaml_path) as f:
            data = yaml.safe_load(f)

        catalogs = []
        schemas = []
        tables = []

        for catalog, schemas_dict in data.items():
            for schema, tables_list in schemas_dict.items():
                for table in tables_list:
                    catalogs.append(catalog)
                    schemas.append(schema)
                    tables.append(table)

        return catalogs, schemas, tables
    except Exception as e:
        print(f"Error loading tables from S3: {e}")
        raise



def compaction():
    catalogs, schemas, tables = load_tables_from_s3()
    
    for catalog, schema, table in zip(catalogs, schemas, tables):
        table_name = f"{catalog}.{schema}.{table}"
        
        print("=" * 80) 
        print(f"Running Compaction Query For {table_name}:") 
        
        query1 = f"ALTER TABLE {table_name} EXECUTE optimize(file_size_threshold => '512MB')"
        result = trino(query1)
        print(result)
        
        query2 = f"ALTER TABLE {table_name} EXECUTE expire_snapshots(retention_threshold => '60m')"
        result = trino(query2)
        print(result)
        
        query3 = f"ALTER TABLE {table_name} EXECUTE remove_orphan_files(retention_threshold => '10m')"
        result = trino(query3)
        print(result)



default_args = {
    'owner': 'inzamam',
    'depends_on_past': False,
    'start_date': datetime(2026, 3, 16),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1
}

dag = DAG(
    'compaction_with_trino',
    default_args=default_args,
    description='DAG to compact less memory intensive tables using trino',
    schedule="0 20 * * *",
    tags = ["TRINO", 'COMPACTION'],
    catchup=False
)

task = PythonOperator(
    task_id = 'compact',
    python_callable=compaction,
    trigger_rule='all_done',
    dag=dag,
)

task
