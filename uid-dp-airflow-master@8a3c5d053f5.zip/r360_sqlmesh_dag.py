from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from datetime import datetime
import textwrap
from kubernetes.client import models as k8s

# This is the bash script that will run inside the unmodifiable Pod.
# It uses Python to download files from S3, then runs sqlmesh.
BASH_COMMAND = textwrap.dedent("""
    set -e  # Exit immediately if a command fails
    export PIP_TARGET="/tmp/pip_libs"
    export PYTHONPATH="$PIP_TARGET:$PYTHONPATH"
    mkdir -p $PIP_TARGET
    
    # 2. Install packages using --target to avoid /home/spark permission errors
    echo "Installing required packages..."
    pip install --target=$PIP_TARGET --index-url http://10.10.206.59:8080/repository/pypi-proxy/simple --trusted-host 10.10.206.59 apache-airflow-providers-postgres cachetools typer==0.27.0 uvicorn==0.52.0 cryptography==46.0.6 psycopg2-binary
    echo "Starting S3 sync process..."
    python3 -c "
    import os
    import boto3

    s3_bucket = os.environ.get('S3_BUCKET')
    s3_prefix = os.environ.get('S3_PREFIX', 'sqlmesh-project/') # e.g., 'my-folder/sqlmesh/'
    local_dir = '/tmp/sqlmesh_project'

    os.makedirs(local_dir, exist_ok=True)

    s3 = boto3.client(
                  's3',
                  endpoint_url='http://10.10.103.12:425',
                  aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',
                  aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4'
              )
    paginator = s3.get_paginator('list_objects_v2')
    
    print(f'Downloading from s3://{s3_bucket}/{s3_prefix} to {local_dir}')
    
    for page in paginator.paginate(Bucket=s3_bucket, Prefix=s3_prefix):
        for obj in page.get('Contents', []):
            key = obj['Key']
            # Skip folder placeholders
            if key.endswith('/'):
                continue
                
            # Calculate local file path
            relative_path = key[len(s3_prefix):]
            local_file_path = os.path.join(local_dir, relative_path)
            
            # Create subdirectories if they don't exist
            os.makedirs(os.path.dirname(local_file_path), exist_ok=True)
            
            print(f'Downloading {key}...')
            s3.download_file(s3_bucket, key, local_file_path)
            
    print('S3 sync complete.')
    "
    
    echo "Navigating to SQLMesh project directory..."
    cd /tmp/sqlmesh_project
    
    # Tell SQLMesh to use /tmp for its local state/cache directory
    export SQLMESH_HOME="/tmp/.sqlmesh"
    mkdir -p $SQLMESH_HOME

    echo "Initializing SQLMesh run..."
    # Runs the data loads. SQLMesh will connect to Postgres state and Spark using env vars.
    sqlmesh run
    
    echo "SQLMesh run completed successfully!"
""")

with DAG(
    dag_id="sqlmesh_s3_k8s_run",
    schedule="0 2 * * *",  # Runs daily at 2 AM
    start_date=datetime(2023, 1, 1),
    catchup=False,
    tags=["sqlmesh", "spark", "s3"],
) as dag:

    run_sqlmesh_from_s3 = KubernetesPodOperator(
        task_id="run_sqlmesh_from_s3",
        image="hbdc-harbor-registry-prod.uidai.net.in/data-platform/pyspark-duckdb-sqlmesh:4.0.2_0.235.4_2",
        cmds=["bash", "-c"],
        arguments=[BASH_COMMAND],
        namespace="strot-spark",
        get_logs=True,
        env_vars={
            "S3_BUCKET": "prd-bi-data-platform-feature-resident360-00",
            "S3_PREFIX": "sqlmesh_models/sqlmesh/",
            "SQLMESH_POSTGRES_HOST": "10.10.108.139",
            "SQLMESH_POSTGRES_PORT": "5432",
            "SQLMESH_POSTGRES_USER": "dp_postgres",
            "SQLMESH_POSTGRES_PASSWORD": "Pldapostw5875",
            "SQLMESH_POSTGRES_DB": "strot_sqlmesh",
            
            # Spark Connect Config
            "SPARK_REMOTE": "sc://spark-connect-service.strot-spark.svc.cluster.local:15002"
        },
        container_resources=k8s.V1ResourceRequirements(
            requests={"cpu": "4000m", "memory": "8Gi"},
            limits={"cpu": "4000m", "memory": "8Gi"},
        ),
        service_account_name='strot-service-account',
        config_file="/opt/airflow/dags/gpu_kubeconfig_hdc", 
        in_cluster=False,
        log_events_on_failure=True
    )