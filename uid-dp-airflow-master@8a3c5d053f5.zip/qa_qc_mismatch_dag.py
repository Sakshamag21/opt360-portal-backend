from airflow.sdk import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from trino.dbapi import connect
from datetime import timedelta

trino_host="10.10.116.75"
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="airflow_dag_op"

qa_qc_mismatch_query='''
merge into strot.operator360.qc_error_audit_mismatch_report_v1 as t
using (select * from (
with
tabT as (
    select packeteid, dmsdispositiondetails, allocatedlevel,errorcode,dispositionstatus ,isfinal,vendorid from flink_stream.stream_qc.qc_operator_disposition WHERE 
    vendorid != '45168a64-4564-47c0-a8cb-d5e35ec03126' AND 
    ((isfinal= false and (allocatedlevel='L1' or allocatedlevel='L2')) or (isfinal=true and dispositionstatus='Rejected')) AND
    packetstage = 'QC' AND 
    packeteid in  (

select 
    distinct packeteid
FROM strot.operator360.eid_qc_error_report_v2
WHERE priority in ('1','2') and is_audited=true
and date(check_date) >= date(date_add('day', -1, now()))
and date(packet_date)>=date('2025-01-01')

) 
),

tabT_l3 as (
select * from tabT where allocatedlevel='L3'
),

tabT_l1_l2 as (
select * from tabT where packeteid not in (select packeteid from tabT_l3)
),

tabT_comb as (
select * from tabT_l3
union all
select * from tabT_l1_l2
),

tab1_2 as(
    select t.packeteid, t.allocatedlevel, t.dmsdispositiondetails, t.dispositionstatus,t.isfinal,t.vendorid,
    array_except(array_union(
    ARRAY_DISTINCT(
     ARRAY_EXCEPT(
      FLATTEN(
       TRANSFORM(
         ARRAY_AGG(t.errorcode), x ->
          CASE
             WHEN STRPOS(x, '|') > 0 THEN SPLIT(x, '|')
             ELSE ARRAY[x]
          END
        )
       ) , ARRAY['', NULL]
      )
     ),
     ARRAY_DISTINCT(
      ARRAY_EXCEPT(
       FLATTEN(
         TRANSFORM(
          ARRAY_AGG(c.errorcode), x ->
            CASE
             WHEN STRPOS(x, '|') > 0 THEN SPLIT(x, '|')
             ELSE ARRAY[x]
            END
          )
        ), ARRAY['', NULL]
      )
     )), ARRAY[NULL]) as error_codes

     from tabT_comb t left join unnest(dmsdispositiondetails) as c on true
      group by 1,2,3,4,5,6
),
tab1_1 as (
 select distinct packeteid, actionedat
 from flink_stream.stream_qc.qc_vendor_completion
 where date(actionedat) >=date(date_add('day', -1, now()))
 and actiontaken = 'Vendor WF Completed'
 and packeteid not like '000000%'
 ),
 tab2_1 as (
 select * from (
 select t.packeteid, max(t.allocatedlevel) as allocatedlevel, arbitrary(t.dmsdispositiondetails) as dmsdispositiondetails,max(t.dispositionstatus) as dispositionstatus, bool_or(t.isfinal) as isfinal,flatten(array_agg(t.error_codes)) as error_codes, max(a.actionedat) as actionedat, max(t.vendorid) as vendorid from tab1_2 t 
 join tab1_1 a on a.packeteid=t.packeteid
 where t.dispositionstatus='Rejected'
 and t.dmsdispositiondetails is not null 
  group by t.packeteid) where isfinal=true
 ),
tab1_3 AS (
 SELECT packeteid, allocatedlevel, actionedat, error_codes,vendorid, e
 FROM (
 SELECT packeteid, allocatedlevel, actionedat,vendorid,
 error_codes,
 CASE
 WHEN STRPOS(x,'|') > 0 THEN SPLIT(x,'|')
 ELSE ARRAY[x]
 END AS ec
 FROM tab2_1, UNNEST(error_codes) AS err(x)
 ), UNNEST(ec) AS ec(e)
 )
 ,
 tab2_3 AS (
 SELECT t1.packeteid, t1.allocatedlevel, t1.actionedat,t1.vendorid,
 t1.error_codes,t2.error_category
 FROM tab1_3 t1
 JOIN flink_stream.stream_qc.qc_error_mapping t2 ON t1.e = t2.error_code
 ),
 tab3_3 AS (
 SELECT packeteid, allocatedlevel, actionedat,vendorid,
 error_codes,
 ARRAY_DISTINCT(ARRAY_AGG(error_category)) AS error_categories
 FROM tab2_3
 GROUP BY 1, 2, 3, 4,5
 ),
 
 tab4_3 AS (
 SELECT packeteid, allocatedlevel, actionedat,error_codes,vendorid,
 error_categories,error_category,priority,
 ROW_NUMBER() OVER(PARTITION BY packeteid ORDER BY priority) AS rn
 FROM (
 SELECT * FROM tab3_3,
 UNNEST(error_categories) AS err_cat(err)
 ) AS s
 JOIN (SELECT * FROM flink_stream.stream_qc.qc_error_mapping) AS m ON s.err = m.error_category
 ),
 tab5_3 AS (
 SELECT packeteid, allocatedlevel, actionedat,
 error_codes,error_categories,error_category,vendorid,
 priority
 FROM tab4_3 WHERE rn = 1
 ),
 tab1_4_1 AS (
 SELECT t1.*, t2.session_operatorid AS session_operatorid
 FROM tab5_3 t1
 LEFT JOIN flink_stream.stream_enu.bi_enrlenspackets_upload_updt t2 ON t1.packeteid = t2.enrolment_eid
 ),

 tab2_4 AS (
 SELECT t1.user_code,t1.user_name,CAST(t1.user_uid AS VARCHAR) AS user_uid,t1.user_email_id,
 t2.org_code AS ea_code,t2.org_name AS ea_name,
 t3.org_code AS reg_code,t3.org_name AS reg_name
 FROM mysql_uidmasterv1.uidmasterv1_1.user t1
 JOIN mysql_uidmasterv1.uidmasterv1_1.organization t2 ON t1.user_org_key = t2.org_key
 JOIN mysql_uidmasterv1.uidmasterv1_1.organization t3 ON t1.user_reg_org_key = t3.org_key
 ),
 tab3_4 as (
 select *,row_number() over(partition by packeteid order by allocatedlevel desc) as rn
 from tab1_4_1 t1
 left join tab2_4 t2 on upper(t1.session_operatorid)=upper(t2.user_code)
 ),
 tab1_5 as(
 select packeteid, DATE_PARSE(SUBSTRING(packeteid, 15, 8), '%Y%m%d') as packet_Date, actionedat as
check_date,
 case
 when allocatedlevel='L1' or allocatedlevel='L2' then 'QCOperator'
 else 'QCReviewer'
 end as dispositionrole,
 error_codes,error_categories,error_category,priority,session_operatorid as operator_id,user_name,user_uid,vendorid,
user_email_id,ea_code,ea_name,reg_code,reg_name from tab3_4 where rn = 1
 ),
 tab2_5 as (
 SELECT s.*, m.description,
 ROW_NUMBER() OVER(PARTITION BY packeteid) AS rn
 FROM (
 SELECT * FROM tab1_5,
 UNNEST(error_codes) AS err_cat(error_code)
 ) AS s
 JOIN flink_stream.stream_qc.qc_error_mapping AS m
 ON s.error_category = m.error_category and s.error_code = m.error_code and s.error_code is NOT NULL
 ),
 tab3_5 as (
 select * from tab2_5 where rn=1
 ),

 tab4_6 as (
    select *, current_timestamp as last_updated_at, case when 1=1 then false else true end as is_audit_rejected, case when 1=1 then false else true end as is_audited from tab3_5
),
tab_2 as (select 
    distinct packeteid,
    vendorid,
    error_code,
    error_category
from tab4_6 where priority='1'
),
tab_7 as (select 
    distinct packeteid,
    error_code,
    error_category,
    description,
    date(check_date) as check_date
FROM strot.operator360.eid_qc_error_report_v2
WHERE priority in ('1','2') and is_audited=true
and date(check_date)>=date(date_add('day', -1, now()))
and date(packet_date)>=date('2025-01-01') ),

tab_8 as (select 
qc.packeteid	as packeteid,
'45168a64-4564-47c0-a8cb-d5e35ec03126' as qa_vendorid,	
qa.error_code as qa_error_code,	
qa.error_category as qa_error_category,	
qc.vendorid as qc_vendorid,	
qc.error_code as qc_errorCode,	
qc.error_category as qc_error_category,	
qa.check_date as check_date,	
case 
when qa.error_category != qc.error_category then false
else true
end as qc_error_cat_matching_qa_error_cat from

tab_7 qa join tab_2 qc on qa.packeteid=qc.packeteid and qa.error_category != qc.error_category)

select * from tab_8
)) as s
on t.packeteid=s.packeteid 
when not matched 
then insert (
    packeteid,
    qa_vendorid,
    qa_error_code,
    qa_error_category,
    qc_vendorid,
    qc_errorCode,
    qc_error_category,
    check_date,
    qc_error_cat_matching_qa_error_cat) 
    
    values (
    s.packeteid,
    s.qa_vendorid,
    s.qa_error_code,
    s.qa_error_category,
    s.qc_vendorid,
    s.qc_errorCode,
    s.qc_error_category,
    s.check_date,
    s.qc_error_cat_matching_qa_error_cat
    )
'''

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2025, 9, 11),
    'email': ['techexecutive14-yp23@uidai.net.in','techexe15.yp25@uidai.net.in'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 1
}

dag = DAG(
    'qa_qc_mismatch_report_generation',
    default_args=default_args,
    description='DAG upserts qc grave error mismatch reports',
    schedule='0 7 * * *',
    catchup=False
)

def run_query(query,host=trino_host,port=trino_port,user=trino_user):
    conn = connect(
        host=host,
        port=port,
        user=user,
        )
    cur = conn.cursor()
    cur.execute(query)
    return {"success": 1}


qa_qc_mismatch_report = PythonOperator(
                task_id='qa_qc_mismatch',
                python_callable=run_query,
                op_kwargs={'query':qa_qc_mismatch_query},
                trigger_rule='all_done',
                dag=dag,
                )
            

qa_qc_mismatch_report
