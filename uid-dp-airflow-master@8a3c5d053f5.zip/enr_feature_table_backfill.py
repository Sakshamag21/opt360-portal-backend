import os
import findspark
findspark.init()
import gc
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, when, coalesce
import concurrent.futures

# Configuration
MYSQL_USER = "data_platform_R"
MYSQL_PASS = "Data_p!atform_7634"
ICEBERG_TABLE = "strot.resident360.enrl_feature_table"
ENR_DATE_CUTOFF = "2026-07-05"

spark = SparkSession.builder.appName("enr_backfill_job") \
    .config("spark.driver.extraJavaOptions", "-XX:+UseG1GC -XX:G1HeapRegionSize=32m -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError='echo \"OutOfMemoryError occurred\"'") \
    .config("spark.executor.extraJavaOptions", "-XX:+UseG1GC -XX:G1HeapRegionSize=32m -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark -XX:InitiatingHeapOccupancyPercent=35 -XX:OnOutOfMemoryError='echo \"OutOfMemoryError occurred\"'") \
    .config("spark.memory.fraction", "0.95") \
    .config("spark.decommission.enabled", "true") \
    .config("spark.storage.decommission.shuffleBlocks.enabled", "true") \
    .config("spark.sql.broadcastTimeout", "6000") \
    .config("spark.default.parallelism","200") \
    .config("spark.sql.shuffle.partitions", '200') \
    .config("spark.network.timeout", "8000s") \
    .config("spark.executor.heartbeatInterval", "2000s") \
    .config("spark.sql.files.maxPartitionBytes","128m") \
    .config("spark.sql.adaptive.enabled", "true") \
    .config("spark.sql.legacy.mysql.bitArrayMapping.enabled","true") \
    .config("spark.sql.optimizer.disabledRules", "org.apache.spark.sql.catalyst.optimizer.SimplifyCasts") \
    .getOrCreate()

# Simplified host-to-shard mapping
HOST_MAPPINGS = [
    ("10.10.108.231", 20, 35),
    ("10.10.108.232", 36, 51),
    ("10.10.108.233", 52, 67),
    ("10.10.108.234", 68, 83),
    ("10.10.108.235", 84, 99)
]

def read_shard_to_df(host, shard):
    global spark

    try:
        db_name = f"uidv2_0_{shard:02d}"
        print(f"--> [Thread] Starting shard {shard} on {host}...")
                
        # All casts and bitwise logic are now natively in MySQL to avoid Spark Catalyst bugs
        mysql_query = f"""
            WITH min_tracker AS (
                SELECT t.*,
                       ROW_NUMBER() OVER (PARTITION BY t.uid ORDER BY t.tracker_key ASC) as rn
                FROM uid_origin_tracker t
                WHERE t.enr_date IS NULL OR t.enr_date < '{ENR_DATE_CUTOFF}'
            ),
            min_master AS (
                SELECT m.*,
                       ROW_NUMBER() OVER (PARTITION BY m.uid ORDER BY m.uid_his_key ASC) as rn
                FROM uid_his_master m
                INNER JOIN (SELECT DISTINCT uid FROM min_tracker) mt ON m.uid = mt.uid
            ),
            min_address AS (
                SELECT a.*,
                       ROW_NUMBER() OVER (PARTITION BY a.uid ORDER BY a.his_addr_key ASC) as rn
                FROM uid_his_address a
                INNER JOIN (SELECT DISTINCT uid FROM min_tracker) mt ON a.uid = mt.uid
            )
            SELECT
                t.uid,
                COALESCE(m.issue_date, fm.issue_date) AS issue_date,
                COALESCE(m.res_dob_year, fm.res_dob_year) AS res_dob_year,
                COALESCE(m.res_dob_type, fm.res_dob_type) AS res_dob_type,
                COALESCE(m.res_gender, fm.res_gender) AS res_gender,
                COALESCE(m.res_guardian_uid, fm.res_guardian_uid) AS res_guardian_uid,
                COALESCE(m.verification_type, fm.verification_type) AS verification_type,
                COALESCE(m.Poi, fm.Poi) AS Poi,
                COALESCE(m.Pob, fm.Pob) AS Pob,
                COALESCE(m.Poa, fm.Poa) AS Poa,
                COALESCE(m.hof_proof, fm.hof_proof) AS hof_proof,
                COALESCE(m.other_proof, fm.other_proof) AS other_proof,
                COALESCE(m.res_lang_code, fm.res_lang_code) AS res_lang_code,
                COALESCE(m.isNRI, fm.isNRI) AS isNRI,
                COALESCE(m.isForeigner, fm.isForeigner) AS isForeigner,
                COALESCE(m.nationality_code, fm.nationality_code) AS nationality_code,
                COALESCE(m.uid_expiry_date, fm.uid_expiry_date) AS uid_expiry_date,
                COALESCE(m.creation_date, fm.creation_date) AS creation_date,
                COALESCE(m.biometric_flag, fm.biometric_flag) AS biometric_flag,
                COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind) AS biometric_exception_ind,
                m.eid AS eid,
            
                t.refid, t.source_client_id, t.source_client_machine_id, t.source_client_version,
                t.operator_id, 
                CAST(t.isChild AS CHAR) AS isChild, 
                t.enr_date, 
                CAST(t.update_ind AS CHAR) AS update_ind, 
                CAST(t.reject_ind AS CHAR) AS reject_ind,
            
                COALESCE(a.res_addr_state_name, fa.res_addr_state_name) AS res_addr_state_name,
                COALESCE(a.res_addr_state_code, fa.res_addr_state_code) AS res_addr_state_code,
                COALESCE(a.res_addr_district_name, fa.res_addr_district_name) AS res_addr_district_name,
                COALESCE(a.res_addr_district_code, fa.res_addr_district_code) AS res_addr_district_code,
                COALESCE(a.res_addr_pincode, fa.res_addr_pincode) AS res_addr_pincode,

                -- Native MySQL Base64 decode + Bitwise operations returning raw integers
                ASCII(SUBSTRING(FROM_BASE64(COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind)), 1, 1)) & 128 AS left_thumb_exception,
                ASCII(SUBSTRING(FROM_BASE64(COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind)), 1, 1)) & 64 AS left_index_exception,
                ASCII(SUBSTRING(FROM_BASE64(COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind)), 1, 1)) & 32 AS left_middle_exception,
                ASCII(SUBSTRING(FROM_BASE64(COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind)), 1, 1)) & 16 AS left_ring_exception,
                ASCII(SUBSTRING(FROM_BASE64(COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind)), 1, 1)) & 8 AS left_small_exception,
                ASCII(SUBSTRING(FROM_BASE64(COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind)), 1, 1)) & 4 AS right_thumb_exception,
                ASCII(SUBSTRING(FROM_BASE64(COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind)), 1, 1)) & 2 AS right_index_exception,
                ASCII(SUBSTRING(FROM_BASE64(COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind)), 1, 1)) & 1 AS right_middle_exception,
                
                ASCII(SUBSTRING(FROM_BASE64(COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind)), 2, 1)) & 128 AS right_ring_exception,
                ASCII(SUBSTRING(FROM_BASE64(COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind)), 2, 1)) & 64 AS right_small_exception,
                ASCII(SUBSTRING(FROM_BASE64(COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind)), 2, 1)) & 32 AS left_iris_exception,
                ASCII(SUBSTRING(FROM_BASE64(COALESCE(m.biometric_exception_ind, fm.biometric_exception_ind)), 2, 1)) & 16 AS right_iris_exception

            FROM min_tracker t
            LEFT JOIN min_master m  ON t.uid = m.uid AND m.rn = 1
            LEFT JOIN uid_master fm ON t.uid = fm.uid AND m.uid IS NULL
            LEFT JOIN min_address a ON t.uid = a.uid AND a.rn = 1
            LEFT JOIN uid_address fa ON t.uid = fa.uid AND a.uid IS NULL
        """

        joined_df = spark.read.format("jdbc") \
            .option("url", f"jdbc:mysql://{host}:3306/{db_name}?zeroDateTimeBehavior=convertToNull&connectTimeout=300000&socketTimeout=900000") \
            .option("dbtable", f"({mysql_query}) as t") \
            .option("user", MYSQL_USER) \
            .option("password", MYSQL_PASS) \
            .option("driver", "com.mysql.cj.jdbc.Driver") \
            .option("numPartitions", 8) \
            .option("fetchsize", 200000) \
            .load()

        # ZERO .cast() calls in PySpark! This prevents the SimplifyCasts bug.
        result_df = joined_df.select(
            col("uid"),
            lit(int(shard)).alias("shard_hint"),
            col("issue_date").alias("uid_issue_date"),
            col("res_dob_year").alias("dob_yr"),
            col("res_dob_type").alias("dob_type"),
            col("res_gender").alias("gender"),
            col("res_guardian_uid").alias("hof_uid"),
            col("verification_type"),
            col("Poi").alias("poi"),
            col("Pob").alias("pob"),
            col("Poa").alias("poa"),
            col("hof_proof"),
            col("other_proof"),
            col("res_lang_code").alias("lang_code"),
            when(col("isNRI") == "Y", "Y").otherwise("N").alias("is_nri"),
            col("isForeigner").alias("is_foreigner"),
            col("nationality_code"),
            col("uid_expiry_date").alias("expiry_date"),
            col("creation_date").alias("date_of_enrl"),
            (col("biometric_flag") == "1").alias("bio_present"),
            when(
                col("biometric_exception_ind").isNotNull() &
                (col("biometric_exception_ind") != ""),
                lit(True)
            ).otherwise(lit(False)).alias("bio_exception"),
            col("refid").alias("refid"),
            col("eid").alias("eid"),
            lit("backfill").alias("source"),
            col("source_client_id"),
            col("source_client_machine_id").alias("source_client_mach_id"),
            col("source_client_version"),
            col("operator_id").alias("opt_id"),
            col("isChild").alias("is_child"),
            col("res_addr_state_name").alias("state_name"),
            col("res_addr_state_code").alias("state_code"),
            col("res_addr_district_name").alias("district_name"),
            col("res_addr_district_code").alias("district_code"),
            col("res_addr_pincode").alias("pincode"),
            col("creation_date").alias("hof_enrl_date"),
            
            # Pure boolean comparison, no casts
            coalesce((col("left_thumb_exception") > 0), lit(False)).alias("left_thumb_exception"),
            coalesce((col("left_index_exception") > 0), lit(False)).alias("left_index_exception"),
            coalesce((col("left_middle_exception") > 0), lit(False)).alias("left_middle_exception"),
            coalesce((col("left_ring_exception") > 0), lit(False)).alias("left_ring_exception"),
            coalesce((col("left_small_exception") > 0), lit(False)).alias("left_small_exception"),
            coalesce((col("right_thumb_exception") > 0), lit(False)).alias("right_thumb_exception"),
            coalesce((col("right_index_exception") > 0), lit(False)).alias("right_index_exception"),
            coalesce((col("right_middle_exception") > 0), lit(False)).alias("right_middle_exception"),
            coalesce((col("right_ring_exception") > 0), lit(False)).alias("right_ring_exception"),
            coalesce((col("right_small_exception") > 0), lit(False)).alias("right_small_exception"),
            coalesce((col("left_iris_exception") > 0), lit(False)).alias("left_iris_exception"),
            coalesce((col("right_iris_exception") > 0), lit(False)).alias("right_iris_exception"),
            
            col("update_ind"),
            col("reject_ind"),
            col("biometric_exception_ind").alias("biometric_exception_ind")
        )
        return result_df

    except Exception as e:
        print(f"!!! [Thread] Error processing shard {shard}: {str(e)}")
        return None

def main():
    global spark
    
    try:
        shard_lists = [list(range(min_shard, max_shard + 1)) for _, min_shard, max_shard in HOST_MAPPINGS]
        task_batches = zip(*shard_lists)

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            for batch in task_batches:
                futures = []
                dfs_to_union = []

                for i, shard in enumerate(batch):
                    host = HOST_MAPPINGS[i][0]
                    futures.append(executor.submit(read_shard_to_df, host, shard))

                for future in concurrent.futures.as_completed(futures):
                    df = future.result()
                    if df is not None:
                        dfs_to_union.append(df)

                if not dfs_to_union:
                    print(f"=== Batch skipped: shards {batch} failed to load ===")
                    continue

                print(f"=== Unioning batch: shards {batch} ===")
                combined_df = dfs_to_union[0]
                for df in dfs_to_union[1:]:
                    combined_df = combined_df.unionByName(df)

                print(f"=== Writing batch to Iceberg: shards {batch} ===")
                combined_df.writeTo(ICEBERG_TABLE).append()

                print(f"=== Batch completed: shards {batch} ===")
                
                del combined_df
                del dfs_to_union
                gc.collect()

    finally:
        print("All processing finished.")

main()