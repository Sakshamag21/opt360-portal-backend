#!/usr/bin/env python
# coding: utf-8

# In[1]:


import time
import os
import json
import pandas as pd
from trino.dbapi import connect
import mysql.connector
import boto3
from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from datetime import datetime
from zoho_alerts import zoho_failure_callback


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2026, 7, 22),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'on_failure_callback': zoho_failure_callback
}

# Define the DAG
dag = DAG(
    'update_uid_master_dag',
    default_args=default_args,
    description='run merge query to update uid_master',
    schedule="10 2 * * *",
    catchup=False,
    tags=['uid_master_tables']
)

# In[2]:

session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4')
s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425')

iceberg_table_name='uid_master'
iceberg_schema='mysql_uid_v2'
skip_till=19
trino_host="10.10.118.10"
iceberg_incr_key='last_updated_date'
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="af_uid_master"
trino_table_name=f'{trino_catalog_iceberg}.{iceberg_schema}.{iceberg_table_name}'
# iceberg_partition_column='shard_hint'
trino_host_mapping={
              "mysql_v2_20_35":(20,35),
              "mysql_v2_36_51":(36,51),
              "mysql_v2_52_67":(52,67),
              "mysql_v2_68_83":(68,83),
              "mysql_v2_84_99":(84,99)
                }



# In[3]:


def run_query(query,host=trino_host,port=trino_port,user=trino_user):
        conn = connect(
            host=f"{host}",
            port=port,
            user=f"{user}",
            )
        cur = conn.cursor()
        cur.execute(f"{query}")
       
        return {"success":1,"msg":""}

def return_max_key(query,host=trino_host,port=trino_port,user=trino_user):
    try:
        conn = connect(
            host=f"{host}",
            port=port,
            user=f"{user}",
            )
        cur = conn.cursor()
        row = cur.execute(f"{query}")
       
        return row.fetchall()
    except Exception as e:
        return str(e)




# s3_client.download_file('prd-bi-data-platform-configs', 'salt/salts.txt', '/opt/airflow/files/salts_from_s3.txt')

def main():
    
        with open('/opt/airflow/dags/files/salts_from_s3.txt', "r") as file:  
            salts = json.load(file)
        
        max_keys=pd.DataFrame(return_max_key(f"select shard_hint,max({iceberg_incr_key}) from {trino_table_name} group by 1 order by 1"),columns=['shard','max_key'])

        retry_count=0
        output=1
        select_query=""
        for k,v in trino_host_mapping.items():
            mysql_host=k
            print(mysql_host)
            
            for i in range(v[0],v[1]+1):
                if (i>skip_till):
                    # uid_master_keys=keys_to_update.loc[keys_to_update.shard==str(i)]['keys'].head(1000).astype(str).to_list()
                    # uid_master_keys=",".join(uid_master_keys)
                    max_i_key=max_keys.loc[max_keys.shard==str(i)]['max_key'].item()
                    select_query=select_query+f"""select uid_master_key,to_base64(sha256(to_utf8(concat('{salts[str(i)]}',uid)))) as uid,
                    uid_status_key,res_dob_year,res_guardian_uid,res_guardian_eid ,res_mobile_num_hash,res_email_id_hash,bnk_shre_cnsnt,info_shre_cnsnt, 
                    verification_type,poi,poa,pob,hof_proof,other_proof,res_lang_code,biometric_flag,biometric_exception_ind,isnri,try_cast(res_dod as timestamp) as res_dod,issue_date,created_by,
                    creation_date,last_updated_by,last_updated_date,substring(uid,1,2) as shard_hint,isforeigner,nationality_code,uid_expiry_date
                    from {mysql_host}.uidv2_0_{i}.uid_master where {iceberg_incr_key}>cast('{str(max_i_key)}' as timestamp) - interval '7' day {"union " if i<99 else ""}"""
                
            
        merge_query=f"""MERGE INTO {trino_table_name} as m USING ({select_query}) as uc
        on m.shard_hint=uc.shard_hint and m.uid_master_key=uc.uid_master_key
        WHEN MATCHED THEN UPDATE SET
        uid_master_key=uc.uid_master_key,uid_status_key=uc.uid_status_key,res_dob_year=uc.res_dob_year,res_guardian_uid=uc.res_guardian_uid,
        res_guardian_eid=uc.res_guardian_eid ,res_mobile_num_hash=uc.res_mobile_num_hash,res_email_id_hash=uc.res_email_id_hash,
        bnk_shre_cnsnt=uc.bnk_shre_cnsnt,info_shre_cnsnt=uc.info_shre_cnsnt, verification_type=uc.verification_type,poi=uc.poi,poa=uc.poa
        ,pob=uc.pob,hof_proof=uc.hof_proof,other_proof=uc.other_proof,res_lang_code=uc.res_lang_code,biometric_flag=uc.biometric_flag,
        biometric_exception_ind=uc.biometric_exception_ind,isnri=uc.isnri,res_dod=uc.res_dod,issue_date=uc.issue_date,created_by=uc.created_by, 
        creation_date=uc.creation_date,last_updated_by=uc.last_updated_by,last_updated_date=uc.last_updated_date,
        isforeigner=uc.isforeigner,nationality_code=uc.nationality_code,uid_expiry_date=uc.uid_expiry_date
        WHEN NOT MATCHED THEN INSERT 
        (uid_master_key,uid,uid_status_key,res_dob_year,res_guardian_uid,res_guardian_eid ,res_mobile_num_hash,res_email_id_hash,bnk_shre_cnsnt,
        info_shre_cnsnt, verification_type,poi,poa,pob,hof_proof,res_lang_code,biometric_flag,biometric_exception_ind,isnri,res_dod,issue_date,
        created_by, creation_date,last_updated_by,last_updated_date,shard_hint,isforeigner,nationality_code,uid_expiry_date) 
        VALUES (uc.uid_master_key,uc.uid,uc.uid_status_key,uc.res_dob_year,
        uc.res_guardian_uid,uc.res_guardian_eid ,uc.res_mobile_num_hash,uc.res_email_id_hash,uc.bnk_shre_cnsnt,uc.info_shre_cnsnt, uc.verification_type,
        uc.poi,uc.poa,uc.pob,uc.hof_proof,uc.res_lang_code,uc.biometric_flag,uc.biometric_exception_ind,uc.isnri,uc.res_dod,uc.issue_date,
        uc.created_by, uc.creation_date,uc.last_updated_by,uc.last_updated_date,uc.shard_hint,uc.isforeigner,uc.nationality_code,uc.uid_expiry_date)"""
        # print(merge_query)
        # print("--------------------------------------------------------")
        output=run_query(merge_query)

        # os.remove('/opt/airflow/files/salts_from_s3.txt')
        
        if output['success']==1:
            return "successfully executed"
        else:
            return output['msg']


update_uid_master_daily_table = PythonOperator(
                task_id='uid_master_merge_query',
                python_callable=main,
                dag=dag,
            )

