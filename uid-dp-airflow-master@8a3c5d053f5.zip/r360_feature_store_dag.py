from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from datetime import datetime
import textwrap
from kubernetes.client import models as k8s

# This is the bash script that will run inside the Pod.
# It downloads the python files from S3, then executes feature_refresh_pipeline.py
BASH_COMMAND = textwrap.dedent("""
    set -e  # Exit immediately if a command fails
    # export PIP_TARGET="/tmp/pip_libs"
    # export PYTHONPATH="$PIP_TARGET:$PYTHONPATH"
    # mkdir -p $PIP_TARGET
    
    # # Install required packages (boto3, pytz, pyyaml)
    # echo "Installing required packages..."
    # pip install --target=$PIP_TARGET --index-url http://10.10.206.59:8080/repository/pypi-proxy/simple --trusted-host 10.10.206.59 boto3==1.34.41 pytz==2026.2 pyyaml==6.0.1
    
    echo "Starting S3 sync process..."
    python3 -c "
    import os
    import boto3

    s3_bucket = os.environ.get('S3_BUCKET')
    s3_prefix = os.environ.get('S3_PREFIX', 'feature_store/')
    local_dir = '/tmp/r360_feature_store_project'

    os.makedirs(local_dir, exist_ok=True)

    s3 = boto3.client(
                  's3',
                  endpoint_url='http://10.10.103.12:425',
                  aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',
                  aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4'
              )
    paginator = s3.get_paginator('list_objects_v2')
    
    print(f'Downloading from s3://{s3_bucket}/{s3_prefix} to {local_dir}')
    
    for page in paginator.paginate(Bucket=s3_bucket, Prefix=s3_prefix):
        for obj in page.get('Contents', []):
            key = obj['Key']
            # Skip folder placeholders
            if key.endswith('/'):
                continue
                
            # Calculate local file path
            relative_path = key[len(s3_prefix):]
            local_file_path = os.path.join(local_dir, relative_path)
            
            # Create subdirectories if they don't exist (e.g., for the sql/ folder)
            os.makedirs(os.path.dirname(local_file_path), exist_ok=True)
            
            print(f'Downloading {key}...')
            s3.download_file(s3_bucket, key, local_file_path)
            
    print('S3 sync complete.')
    "
    
    echo "Navigating to R360 Feature Store project directory..."
    cd /tmp/r360_feature_store_project
    
    echo "Running feature_refresh_pipeline.py in incremental mode..."
    # Airflow will run this daily. The script defaults to yesterday's date.
    # It loops through all sources in feature_sources.yaml sequentially.
    python3 feature_refresh_pipeline.py --mode incremental
    
    echo "Feature Store pipeline run completed!"
""")

custom_toleration = k8s.V1Toleration(
    key="strot",
    operator='Equal',
    value='true',
    effect='NoSchedule'
)

with DAG(
    dag_id="Resident360_Feature_Store_Pipeline",
    schedule="0 9 * * *", 
    start_date=datetime(2026, 8, 24),
    catchup=False,
    max_active_runs=1,
    tags=["Resident360", "FEATURE_STORE", "ICEBERG"],
) as dag:

    run_r360_feature_store_from_s3 = KubernetesPodOperator(
        task_id="r360_feature_store_merge_from_s3",
        image="hbdc-harbor-registry-prod.uidai.net.in/data-platform/pyspark-duckdb-sqlmesh:4.0.2_0.235.4_2",
        cmds=["bash", "-c"],
        arguments=[BASH_COMMAND],
        namespace="strot-spark",
        tolerations=[custom_toleration],
        get_logs=True,
        env_vars={
            "S3_BUCKET": "prd-bi-data-platform-feature-resident360-00",
            "S3_PREFIX": "feature_store/",
            "SPARK_REMOTE": "sc://spark-connect-service.strot-spark.svc.cluster.local:15002"
        },
        container_resources=k8s.V1ResourceRequirements(
            requests={"cpu": "16000m", "memory": "64Gi"},
            limits={"cpu": "16000m", "memory": "64Gi"},
        ),
        service_account_name='strot-service-account',
        config_file="/opt/airflow/dags/gpu_kubeconfig_hdc", 
        in_cluster=False,
        log_events_on_failure=True,
        is_delete_operator_pod=False,
    )