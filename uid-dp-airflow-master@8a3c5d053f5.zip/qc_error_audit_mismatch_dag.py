from airflow.sdk import DAG
from airflow.operators.python import PythonOperator
import datetime
import calendar
from trino.dbapi import connect
import pandas as pd
import os
import logging
import base64
import json
from io import StringIO
from kafka import KafkaProducer

trino_host = "10.10.116.75"
trino_port = 8080
trino_user = "airflow_dag_op"

topic = "COMMAND.STROT.RCS.REQUEST"
bootstrap_servers = "10.10.105.225:9092,10.10.106.171:9092,10.10.107.110:9092,10.10.105.75:9092,10.10.105.98:9092,10.10.105.238:9092,10.10.107.130:9092,10.10.105.33:9092,10.10.106.195:9092,10.10.106.144:9092,10.10.105.227:9092"

mail_list = ["mgrops.eu2-hq@uidai.net.in"]
cc = "dir.eu2-hq@uidai.net.in,dir.eu-hq@uidai.net.in,pmu1.eu1-hq@uidai.net.in,bi.dev02@uidai.net.in,techexecutive22-yp23@uidai.net.in,adg.tech-tc@uidai.net.in,hoe.dev-tc@uidai.net.in,ddg.techdev@uidai.net.in,techexe15.yp25@uidai.net.in,pmu1.eu2-hq@uidai.net.in,sr.mgrops-tc@uidai.net.in,techexecutive14-yp23@uidai.net.in,mis.manager1-tc@uidai.net.in,techexe16.yp25@uidai.net.in,productmgr4-tc@uidai.net.in"

def get_reporting_window():
    today = datetime.date.today()
    day = today.day
    month = today.month
    year = today.year

    if day >= 16:
        return datetime.date(year, month, 1), datetime.date(year, month, 15)
    else:
        if month == 1:
            prev_month = 12
            prev_year = year - 1
        else:
            prev_month = month - 1
            prev_year = year
        last_day = calendar.monthrange(prev_year, prev_month)[1]
        return datetime.date(prev_year, prev_month, 16), datetime.date(prev_year, prev_month, last_day)

qa_qc_mismatch = '''
SELECT 
packeteid, qa_vendorid, qa_error_code, qa_error_category, 
qc_vendorid, qc_errorcode, qc_error_category, check_date
FROM strot.operator360.qc_error_audit_mismatch_report_v1
WHERE (
    day(current_date) >= 16 AND 
    check_date >= date_trunc('month', current_date) AND 
    check_date <= date_add('day', 14, date_trunc('month', current_date))
    )
    OR (
        day(current_date) <= 15 AND 
        check_date >= date_add('day', 15, date_trunc('month', current_date - interval '1' month)) AND 
        check_date < date_trunc('month', current_date))
'''

def trino(query, host=trino_host, port=trino_port, user=trino_user):
    try:
        conn = connect(host=host, port=port, user=user)
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"query": query, "success": 1, "data": body, "df": None}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}

def df_to_base64(df):
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False)
    encoded_csv = base64.b64encode(csv_buffer.getvalue().encode()).decode("utf-8")
    return encoded_csv

def send_kafka_message(email, additional_info):
    try:
        message = {
            "residentId": "720447260190",
            "appName": "STROT",
            "idType": "uid",
            "event": "STROT_REPORT",
            "mobile": "8540864693",
            "email": email,
            "channel": [
                {
                    "language": "23",
                    "channel": "EMAIL"
                }
            ],
            "additionalInfo": additional_info
        }

        producer = KafkaProducer(
            bootstrap_servers=bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode("utf-8")
        )
        producer.send(topic, message)
        producer.flush()
        logging.info(f"Sent Kafka message to topic '{topic}' : {message}")
        producer.close()
    except Exception as e:
        logging.error(f"Error sending Kafka message: {e}", exc_info=True)
        raise

def trigger_email(query, email_list, dag_id, **kwargs):
    today_date1 = datetime.datetime.now().strftime("%d_%B_%Y")
    today_date = datetime.datetime.now().strftime("%d %B %Y")
    file_name = f"QC_Error_Audit_Mismatch_Report_{today_date1}.csv"

    start_date, end_date = get_reporting_window()
    formatted_start = start_date.strftime("%d-%m-%Y")
    formatted_end = end_date.strftime("%d-%m-%Y")

    html_content1 = f"<p>Please Find Attached the QA and QC Decision Respect to Grave Errors From {formatted_start} To {formatted_end}.</p>"
    html_content2 = f"<p>There are no QA and QC Decision Respect to Grave Errors From {formatted_start} To {formatted_end}.</p>"

    query_result = trino(query)

    if query_result["success"] == 1 and query_result["df"] is not None and not query_result["df"].empty:
        df = query_result["df"]
        print(f"Data fetched successfully. Shape: {df.shape}")

        html_content = html_content1
        encoded_csv = df_to_base64(df)
        attachment = encoded_csv
        final_file_name = file_name

    elif query_result["success"] == 1 and (query_result["df"] is None or query_result["df"].empty):
        print("No Rows Returned by the Query!")
        html_content = html_content2

    else:
        error_msg = query_result.get("msg", "Unknown Trino failure")
        print("Trino query might have failed! Error:", error_msg)
        raise RuntimeError(f"Trino query failed: {error_msg}")

    emailSubject = f"QC Grave Error Audit Mismatch Report {today_date}"

    additional_info = {
        "HTML_CONTENT": html_content,
        "TITLE": " ",
        "RECEIVER": "Team",
        "emailSubject": emailSubject,
        "cc": cc
    }

    if attachment:
        additional_info["attachment"] = attachment
        additional_info["fileName"] = final_file_name

    for email in email_list:
        send_kafka_message(email, additional_info)
        print(f"Email sent to {email}")
        print(f"CC: {cc}")

default_args = {
    'owner': 'inzamam',
    'depends_on_past': False,
    'start_date': datetime.datetime(2026, 6, 29),
    'email': ["techexe15.yp25@uidai.net.in", "techexecutive22-yp23@uidai.net.in", "techexecutive14-yp23@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 1
}

dag = DAG(
    'reporting_qa_qc_mismatch',
    default_args=default_args,
    description="Dag to send emails to the team regarding qc error audit mismatch with report in csv",
    schedule="0 8 1,16 * *",
    catchup=False,
    tags=["Grave", "Audit", "Mismatch", "Reporting"],
    render_template_as_native_obj=True
)

qc_error_audit_mismatch_report_email = PythonOperator(
    task_id='qc_error_audit_mismatch',
    python_callable=trigger_email,
    op_kwargs={'query': qa_qc_mismatch, 'email_list': mail_list, 'dag_id': 'reporting_qa_qc_mismatch'},
    dag=dag,
)

qc_error_audit_mismatch_report_email