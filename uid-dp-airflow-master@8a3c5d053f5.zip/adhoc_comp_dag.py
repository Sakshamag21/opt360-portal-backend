from airflow.sdk import DAG
from datetime import datetime
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from kubernetes.client import models as k8s

job_name = "ADHOC_ICEBERG_COMPACTION"
desc = "Job to compact iceberg tables"
pod_name = "adhoc-iceberg-comp-watch-pod"
t_id = "adhoc-comp-task"
schedule = "* * * * *"

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2026, 6, 4),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1
}

custom_toleration = k8s.V1Toleration(
    key="strot",
    operator='Equal',
    value='true',
    effect='NoSchedule'
)

dag = DAG(
    f'{job_name}',
    default_args=default_args,
    description=f'{desc}',
    schedule=None,
    catchup=False
)


task = KubernetesPodOperator(
    namespace='strot-spark',
    service_account_name='strot-service-account',
    image="harbor-registry-prod.uidai.gov.in/data-platform/pyspark_duckdb:4.0.7", 
    config_file="/opt/airflow/kubeconfig/gpu_kubeconfig_hdc", 
    name=f"{pod_name}", task_id=f"{t_id}", 
    tolerations=[custom_toleration],
    cmds=["/bin/bash", "-c"],
    arguments=[
        """python3 -c "import boto3;session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4');s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425');s3_client.download_file('prd-bi-data-platform-uploads','sparkjobs/compaction/adhoc_comp_spark_job_driver_head.py','/tmp/adhoc_comp_spark_job_driver_head.py')" && python3 /tmp/adhoc_comp_spark_job_driver_head.py """
    ],
    container_resources=k8s.V1ResourceRequirements(
        requests={"cpu": "1", "memory": "2Gi"},
        limits={"cpu": "1", "memory": "2Gi"}
    ),
    in_cluster=False, get_logs=True, log_events_on_failure=True, dag=dag,
)

task