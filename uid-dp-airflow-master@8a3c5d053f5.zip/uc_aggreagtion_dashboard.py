from __future__ import annotations

import logging
from datetime import datetime, timedelta

import pandas as pd
from trino.dbapi import connect
from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from airflow.providers.standard.operators.empty import EmptyOperator
import uuid
import json
import time
from kafka import KafkaProducer
KAFKA_BROKER = ['10.10.105.225:9092','10.10.106.171:9092','10.10.107.110:9092','10.10.105.75:9092']
KAFKA_TOPIC = 'DE.UC.AGGREGATION.DASHBOARD.V1' 
log = logging.getLogger(__name__)

TRINO_HOST = "10.10.116.75"
TRINO_PORT = 8080
TRINO_USER = "airflow_dag_op"
TRINO_CATALOG_ICEBERG = "strot"


# ---------------- Trino helper ----------------
def trino_execute(query, host=TRINO_HOST, port=TRINO_PORT, user=TRINO_USER):
    """Execute a query on Trino and return a result dict."""
    try:
        q_lower = query.strip().lower()
        conn = connect(host=host, port=port, user=user)
        cur = conn.cursor()
        cur.execute(query)

        if q_lower.startswith(("select", "with", "show", "describe", "explain")):
            body = cur.fetchall()
            if not body:
                return {"query": query, "success": 1, "data": body}
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
        # DML/DDL
        return {"query": query, "success": 1}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}



def main():
    producer = KafkaProducer(
        bootstrap_servers=KAFKA_BROKER,
        # Serialize the message dictionary to a JSON formatted string, then to bytes
        value_serializer=lambda v: json.dumps(v).encode('utf-8'),
        # Serialize the string key to bytes
        key_serializer=lambda k: k.encode('utf-8'),
        # Acknowledgment from leader and followers (safest)
        acks='all'
    )

    # 1. Execute the original query
    results = trino_execute('''
    select
        count(distinct resident_sid) as total_sid_count,
        count(distinct if(enrolment_type = 'N', resident_sid)) as n_sid_count,
        count(distinct resident_sid) - count(distinct if(enrolment_type = 'N', resident_sid)) as u_sid_count,
        ro
    from flink_stream.stream_enu.enu_uc_opt_action_v2
    where event_timestamp >= current_timestamp - interval '20' minute
    and event_timestamp < current_timestamp - interval '10' minute and stage='AckSlipUpload' and stage_status='Completed'
    group by ro
    ''')
    
    if 'df' not in results:
        log.error(f"Encountered an error while running it, please check, {results}")
        return
    
    results=results['df']
    

    # 2. Define timestamps
    end_ts = int(time.time()) - (10 * 60)
    start_ts = end_ts - (20 * 60) # 10 minutes ago

    # 3. Iterate through results and build Kafka messages
    for _,row in results.iterrows():
        ro = row['ro']
        metrics = [
            {"count": row['total_sid_count'], "enrolmentType": "Total", "metric_name": "ack_slip_upload_total_completed_count"},
            {"count": row['u_sid_count'], "enrolmentType": "U", "metric_name": "ack_slip_upload_update_completed_count"},
            {"count": row['n_sid_count'], "enrolmentType": "N", "metric_name": "ack_slip_upload_new_completed_count"}
        ]

        for metric in metrics:
            message_key = f"{metric['metric_name']}_{end_ts}_{ro}"
            message = {
                "eventId": str(uuid.uuid4()),
                "metric": metric['metric_name'],
                "ro": ro,
                "count": metric["count"],
                "enrolmentType": metric["enrolmentType"],
                "window": "10m",
                "startTimestamp": start_ts,
                "endTimestamp": end_ts,
                "eventTimestamp": end_ts
            }

            # Print for logging/debugging
            print(f"KEY: {message_key}")
            print(f"VALUE: {json.dumps(message)}\n")

            # 4. Send the message to Kafka
            try:
                # Asynchronous send
                producer.send(KAFKA_TOPIC, key=message_key, value=message)
            except Exception as e:
                print(f"Failed to send message to Kafka. Error: {e}")

    # 5. Block until all async messages are sent and flush the producer
    print("Flushing messages to Kafka...")
    producer.flush()
    producer.close()
    print("All messages published successfully.")
    
    
default_args = {
    "owner": "Saksham Agarwal and Amit",
    "depends_on_past": False,
    "start_date": datetime(2026, 8, 21),
    "email": ["techexe16.yp25@uidai.net.in"],
    "email_on_failure": True,
    "email_on_retry": True,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}


with DAG(
    dag_id="uc_aggregation_dahsboard_kafka_push",
    default_args=default_args,
    schedule="*/10 * * * *",
    catchup=False,
    max_active_runs=1,            
    max_active_tasks=1,
    tags=["trino", "uc"],
) as dag:


    fill_data = PythonOperator(
        task_id="10min_data_kafka_push",
        python_callable=main,
    )
    
    fill_data

