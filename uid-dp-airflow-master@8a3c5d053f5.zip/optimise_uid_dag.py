from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from datetime import datetime
from trino.dbapi import connect

trino_host="10.10.116.75"
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="airflow_dag_op"

ot1="ALTER TABLE strot.mysql_uid_v2.uid_origin_tracker EXECUTE expire_snapshots(retention_threshold => '7d')"

ot2="ALTER TABLE strot.mysql_uid_v2.uid_origin_tracker EXECUTE remove_orphan_files(retention_threshold => '7d')"

ot3 = "ALTER TABLE strot.mysql_uid_v2.uid_origin_tracker EXECUTE optimize(file_size_threshold => '128MB')"

hm1 = "ALTER TABLE strot.mysql_uid_v2.uid_his_master EXECUTE expire_snapshots(retention_threshold => '7d')"

hm2 = "ALTER TABLE strot.mysql_uid_v2.uid_his_master EXECUTE remove_orphan_files(retention_threshold => '7d')"

hm3 = "ALTER TABLE strot.mysql_uid_v2.uid_his_master EXECUTE optimize(file_size_threshold => '128MB')"

ha1 = "ALTER TABLE strot.mysql_uid_v2.uid_his_address EXECUTE expire_snapshots(retention_threshold => '7d')"

ha2 = "ALTER TABLE strot.mysql_uid_v2.uid_his_address EXECUTE remove_orphan_files(retention_threshold => '7d')"

ha3 = "ALTER TABLE strot.mysql_uid_v2.uid_his_address EXECUTE optimize(file_size_threshold => '128MB')"

m1 = "ALTER TABLE strot.mysql_uid_v2.uid_master EXECUTE expire_snapshots(retention_threshold => '7d')"

m2 = "ALTER TABLE strot.mysql_uid_v2.uid_master EXECUTE remove_orphan_files(retention_threshold => '7d')"

m3 = "ALTER TABLE strot.mysql_uid_v2.uid_master EXECUTE optimize(file_size_threshold => '128MB')"

a1 = "ALTER TABLE strot.mysql_uid_v2.uid_address EXECUTE expire_snapshots(retention_threshold => '7d')"

a2 = "ALTER TABLE strot.mysql_uid_v2.uid_address EXECUTE remove_orphan_files(retention_threshold => '7d')"

a3 = "ALTER TABLE strot.mysql_uid_v2.uid_address EXECUTE optimize(file_size_threshold => '128MB')"

rt1 = "ALTER TABLE strot.mysql_uid_v2.request_tracker EXECUTE expire_snapshots(retention_threshold => '7d')"

rt2 = "ALTER TABLE strot.mysql_uid_v2.request_tracker EXECUTE remove_orphan_files(retention_threshold => '7d')"

rt3 = "ALTER TABLE strot.mysql_uid_v2.request_tracker EXECUTE optimize(file_size_threshold => '128MB')"

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2026, 7, 22),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1
}

dag = DAG(
    'uid_tables_optimise_dag',
    default_args=default_args,
    description='DAG to optimise uid tables weekly',
    schedule="10 7 * * 0",
    catchup=False
)

def run_query(query,host=trino_host,port=trino_port,user=trino_user):
    conn = connect(
        host=host,
        port=port,
        user=user,
        )
    cur = conn.cursor()
    cur.execute(query)
    return {"success":1,"msg":"table optimised"}



ot1_expire = PythonOperator(
                task_id='expire_ot',
                python_callable=run_query,
                op_kwargs={'query': ot1},
                trigger_rule='all_done',
                dag=dag,
            )

ot2_orphan = PythonOperator(
                task_id='orphan_ot',
                python_callable=run_query,
                op_kwargs={'query': ot2},
                trigger_rule='all_done',
                dag=dag,
            )

ot3_optimise = PythonOperator(
                task_id='optimise_ot',
                python_callable=run_query,
                op_kwargs={'query': ot3},
                trigger_rule='all_done',
                dag=dag,
            )

hm1_expire = PythonOperator(
                task_id='expire_hm',
                python_callable=run_query,
                op_kwargs={'query': hm1},
                trigger_rule='all_done',
                dag=dag,
            )
hm2_orphan = PythonOperator(
                task_id='orphan_hm',
                python_callable=run_query,
                op_kwargs={'query': hm2},
                trigger_rule='all_done',
                dag=dag,
            )
hm3_optimise = PythonOperator(
                task_id='optimise_hm',
                python_callable=run_query,
                op_kwargs={'query': hm3},
                trigger_rule='all_done',
                dag=dag,
)

ha1_expire = PythonOperator(
                task_id='expire_ha',
                python_callable=run_query,
                op_kwargs={'query': ha1},
                trigger_rule='all_done',
                dag=dag,
            )

ha2_orphan = PythonOperator(
                task_id='orphan_ha',
                python_callable=run_query,
                op_kwargs={'query': ha2},
                trigger_rule='all_done',
                dag=dag,
            )

ha3_optimise = PythonOperator(
                task_id='optimise_ha',
                python_callable=run_query,
                op_kwargs={'query': ha3},
                trigger_rule='all_done',
                dag=dag,
            )

a1_expire = PythonOperator(
                task_id='expire_a',
                python_callable=run_query,
                op_kwargs={'query': a1},
                trigger_rule='all_done',
                dag=dag,
            )
                        
a2_orphan = PythonOperator(
                task_id='orphan_a',
                python_callable=run_query,
                op_kwargs={'query': a2},
                trigger_rule='all_done',
                dag=dag,
            )
                        
a3_optimise = PythonOperator(
                task_id='optimise_a',
                python_callable=run_query,
                op_kwargs={'query': a3},
                trigger_rule='all_done',
                dag=dag,
            )

m1_expire = PythonOperator(
                task_id='expire_m',
                python_callable=run_query,
                op_kwargs={'query': m1},
                trigger_rule='all_done',
                dag=dag,
            )
                        
m2_orphan = PythonOperator(
                task_id='orphan_m',
                python_callable=run_query,
                op_kwargs={'query': m2},
                trigger_rule='all_done',
                dag=dag,
            )
                        
m3_optimise = PythonOperator(
                task_id='optimise_m',
                python_callable=run_query,
                op_kwargs={'query': m3},
                trigger_rule='all_done',
                dag=dag,
            )


rt1_expire = PythonOperator(
                task_id='expire_rt',
                python_callable=run_query,
                op_kwargs={'query': rt1},
                trigger_rule='all_done',
                dag=dag,
            )
                        
rt2_orphan = PythonOperator(
                task_id='orphan_rt',
                python_callable=run_query,
                op_kwargs={'query': rt2},
                trigger_rule='all_done',
                dag=dag,
            )
                        
rt3_optimise = PythonOperator(
                task_id='optimise_rt',
                python_callable=run_query,
                op_kwargs={'query': rt3},
                trigger_rule='all_done',
                dag=dag,
            )



rt3_optimise>>ot3_optimise>>hm3_optimise>>ha3_optimise>>a3_optimise>>m3_optimise>>rt1_expire>>ot1_expire>>hm1_expire>>ha1_expire>>a1_expire>>m1_expire>>rt2_orphan>>ot2_orphan>>hm2_orphan>>ha2_orphan>>a2_orphan>>m2_orphan