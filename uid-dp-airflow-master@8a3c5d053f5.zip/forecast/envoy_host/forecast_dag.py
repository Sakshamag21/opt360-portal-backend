import os
import sys
import io
import boto3
import pandas as pd
from datetime import datetime, timedelta, timezone
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.smtp.operators.smtp import EmailOperator
from airflow.models import Variable
from botocore.exceptions import ClientError
import forecast.envoy_host.forecast as fn

S3_BUCKET     = "prd-bi-data-platform-uploads"
S3_PREFIX     = "envoy_host_forecast"
HISTORY_DAYS  = 30

DAG_DIR = os.path.dirname(os.path.abspath(__file__))
if DAG_DIR not in sys.path:
    sys.path.append(DAG_DIR)

IST = timezone(timedelta(hours=5, minutes=30))

def execute_forecast_task(work_dir, f_args, **context):
    original_dir = os.getcwd()
    try:
        os.chdir(work_dir)
        print(f"Executing forecast in {work_dir}...")
        return fn.run_forecast(**f_args)
    finally:
        os.chdir(original_dir)

QUERIES = [
    {
        "id": "network_receive_forecast",
        "name": "Network Receive",
        "query": 'sum(rate(node_network_receive_bytes_total{job="node-exporter"}[1h]))',
#         "email_to": ["junior.devfsd6-tc@uidai.net.in"],
#         "cc": "",
        "email_to": ["hoe.dev-tc@uidai.net.in","platfm.arch1-tc@uidai.net.in","security-arch.msip@uidai.net.in","securityhead.msip@uidai.net.in","techanalyst.is-hq@uidai.net.in","ad.is-mdc@uidai.net.in","srmgrsecops.is-hq@uidai.net.in"],
        "cc": ["ks.krishnamurthy@uidai.net.in","techexecutive3-yp23@uidai.net.in","tech.executive13-tc@uidai.net.in","tech.executive15-tc@uidai.net.in","devfsd17-tc@uidai.net.in","junior.devfsd6-tc@uidai.net.in"],
        "forecast_args": {
            'CSV_FILE': 'data.csv',
            'TIME_COL': 'Time',
            'TARGET_COL': 'Network Receive ({TO_UNIT})',
            'FORECAST_PERIODS': None,
            'FORECAST_START_HOUR': 9,
            'FORECAST_END_HOUR': 17,
            'OUTPUT_FILE': '{TARGET_COL}_forecast.csv',
            'OUTPUT_PLOT': '{TARGET_COL}_forecast_plot.png',
            'FREQ': 'h',
            'FROM_UNIT': 'Bytes/s',
            'TO_UNIT': 'MB/s',
            'UNIT_CATEGORY': 'bandwidth',
            'PRED_HISTORY_FILE': 'pred_history.csv'
        }
    },
    {
        "id": "network_transmit_forecast",
        "name": "Network Transmit",
        "query": 'sum(rate(node_network_transmit_bytes_total{job="node-exporter"}[1h]))',
#         "email_to": ["junior.devfsd6-tc@uidai.net.in"],
#         "cc": "",
        "email_to": ["hoe.dev-tc@uidai.net.in","platfm.arch1-tc@uidai.net.in","security-arch.msip@uidai.net.in","securityhead.msip@uidai.net.in","techanalyst.is-hq@uidai.net.in","ad.is-mdc@uidai.net.in","srmgrsecops.is-hq@uidai.net.in"],
        "cc": ["ks.krishnamurthy@uidai.net.in","techexecutive3-yp23@uidai.net.in","tech.executive13-tc@uidai.net.in","tech.executive15-tc@uidai.net.in","devfsd17-tc@uidai.net.in","junior.devfsd6-tc@uidai.net.in"],
        "forecast_args": {
            'CSV_FILE': 'data.csv',
            'TIME_COL': 'Time',
            'TARGET_COL': 'Network Transmit ({TO_UNIT})',
            'FORECAST_PERIODS': None,
            'FORECAST_START_HOUR': 9,
            'FORECAST_END_HOUR': 17,
            'OUTPUT_FILE': '{TARGET_COL}_forecast.csv',
            'OUTPUT_PLOT': '{TARGET_COL}_forecast_plot.png',
            'FREQ': 'h',
            'FROM_UNIT': 'Bytes/s',
            'TO_UNIT': 'MB/s',
            'UNIT_CATEGORY': 'bandwidth',
            'PRED_HISTORY_FILE': 'pred_history.csv'
        }
    }
]


for q in QUERIES:
    f_args = q["forecast_args"]

    target_col = f_args['TARGET_COL'].format(TO_UNIT=f_args['TO_UNIT'])
    f_args['TARGET_COL'] = target_col

    safe_target = target_col.replace(" ", "_").replace("(", "").replace(")", "").replace("/", "p")

    f_args['OUTPUT_FILE'] = f_args['OUTPUT_FILE'].format(TARGET_COL=safe_target)
    f_args['OUTPUT_PLOT'] = f_args['OUTPUT_PLOT'].format(TARGET_COL=safe_target)


def _s3_key(task_id_safe: str) -> str:
    return f"{S3_PREFIX}/{task_id_safe}/data.csv"

def _s3_hist_key(task_id_safe: str) -> str:
    return f"{S3_PREFIX}/{task_id_safe}/pred_history.csv"


def fetch_and_update_data(query, work_dir, time_col, target_col, task_id_safe, **context):
    from prometheus_api_client import PrometheusConnect

    os.makedirs(work_dir, exist_ok=True)
    local_csv = os.path.join(work_dir, "data.csv")
    local_hist_csv = os.path.join(work_dir, "pred_history.csv")

    s3_key    = _s3_key(task_id_safe)
    s3_hist_key = _s3_hist_key(task_id_safe)

    session=boto3.session.Session(aws_access_key_id=Variable.get("aws_access_key_id"),aws_secret_access_key=Variable.get("aws_secret_access_key"))
    s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425')

    existing_df = pd.DataFrame(columns=[time_col, target_col])

    try:
        print(f"Checking for existing CSV at s3://{S3_BUCKET}/{s3_key}")
        s3_client.head_object(Bucket=S3_BUCKET, Key=s3_key)

        print("Found existing CSV. Downloading...")
        response = s3_client.get_object(Bucket=S3_BUCKET, Key=s3_key)
        body = response['Body'].read()

        with io.BytesIO(body) as buf:
            buf.seek(0)
            existing_df = pd.read_csv(buf)

        existing_df[time_col] = pd.to_datetime(existing_df[time_col], errors='coerce')
        if target_col in existing_df.columns:
            existing_df[target_col] = pd.to_numeric(existing_df[target_col], errors='coerce')
        else:
            existing_df = pd.DataFrame(columns=[time_col, target_col])

        existing_df = (
            existing_df.dropna(subset=[time_col])
                      .sort_values(time_col)
                      .reset_index(drop=True)
        )
        print(f"Existing rows loaded: {len(existing_df)}")

    except ClientError as e:
        if e.response['Error']['Code'] == '404':
            print(f"No existing CSV at s3://{S3_BUCKET}/{s3_key}; fetching {HISTORY_DAYS} days of history.")
        else:
            raise

    try:
        print(f"Checking for existing pred_history CSV at s3://{S3_BUCKET}/{s3_hist_key}")
        s3_client.head_object(Bucket=S3_BUCKET, Key=s3_hist_key)
        print("Found existing pred_history CSV. Downloading...")
        response = s3_client.get_object(Bucket=S3_BUCKET, Key=s3_hist_key)
        body = response['Body'].read()
        with open(local_hist_csv, 'wb') as f:
            f.write(body)
        print(f"Local pred_history.csv saved at {local_hist_csv}")
    except ClientError as e:
        if e.response['Error']['Code'] == '404':
            print(f"No existing pred_history CSV at s3://{S3_BUCKET}/{s3_hist_key}")
        else:
            raise

    now      = datetime.now(IST)
    end_time = now.replace(minute=0, second=0, microsecond=0)

    if not existing_df.empty:
        last_ts = existing_df[time_col].iloc[-1].to_pydatetime()
        if last_ts.tzinfo is None:
            last_ts = last_ts.replace(tzinfo=IST)
        start_time = last_ts + timedelta(hours=1)
    else:
        start_time = (end_time - timedelta(days=HISTORY_DAYS)) \
                        .replace(hour=0, minute=0, second=0, microsecond=0)

    new_rows = []
    if start_time < end_time:
        print(f"Fetching from Thanos: {start_time} -> {end_time} for query: {query}")
        prom = PrometheusConnect(
            url="https://10.81.116.2",
            headers={"Host": "msap-thanos-query.dc2.cidr.gov.in"},
            disable_ssl=True
        )
        results = prom.custom_query_range(
            query=query,
            start_time=start_time,
            end_time=end_time,
            step="1h"
        )
        for series in results:
            for unix_ts, value in series['values']:
                ist_time = datetime.fromtimestamp(float(unix_ts), IST).replace(tzinfo=None)
                try:
                    val = float(value)
                except (TypeError, ValueError):
                    val = None
                new_rows.append({time_col: ist_time, target_col: val})
        print(f"Fetched {len(new_rows)} new rows from Thanos.")
    else:
        print("No new data to fetch (start_time >= end_time).")

    new_df = pd.DataFrame(new_rows, columns=[time_col, target_col])
    if not new_df.empty:
        new_df[time_col] = pd.to_datetime(new_df[time_col])

    combined = pd.concat([existing_df, new_df], ignore_index=True)
    combined = combined.drop_duplicates(subset=[time_col], keep='last')
    combined[time_col] = pd.to_datetime(combined[time_col])
    combined = combined.sort_values(time_col).reset_index(drop=True)

    cutoff = end_time - timedelta(days=HISTORY_DAYS)
    ts_cmp = combined[time_col].apply(
        lambda x: x.replace(tzinfo=IST) if x.tzinfo is None else x
    )
    combined = combined[ts_cmp >= cutoff].reset_index(drop=True)

    print(f"Final dataset rows: {len(combined)} (window: {cutoff} -> {end_time})")

    combined[time_col] = combined[time_col].dt.strftime('%Y-%m-%d %H:%M:%S')
    combined.to_csv(local_csv, index=False)
    print(f"Local CSV saved at {local_csv}")

    s3_client.upload_file(Filename=local_csv, Bucket=S3_BUCKET, Key=s3_key)
    print(f"Uploaded updated CSV to s3://{S3_BUCKET}/{s3_key}")


def upload_pred_history(work_dir, task_id_safe, **context):
    local_hist_csv = os.path.join(work_dir, "pred_history.csv")
    s3_hist_key = _s3_hist_key(task_id_safe)

    session=boto3.session.Session(aws_access_key_id=Variable.get("aws_access_key_id"),aws_secret_access_key=Variable.get("aws_secret_access_key"))
    s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425')

    if os.path.exists(local_hist_csv):
        s3_client.upload_file(Filename=local_hist_csv, Bucket=S3_BUCKET, Key=s3_hist_key)
        print(f"Uploaded updated pred_history.csv to s3://{S3_BUCKET}/{s3_hist_key}")
    else:
        print(f"No local pred_history.csv found at {local_hist_csv} to upload.")


def generate_email_html(work_dir, output_file, query_name, **context):
    forecast_file_path = os.path.join(work_dir, output_file)

    if not os.path.exists(forecast_file_path):
        raise FileNotFoundError(f"{output_file} not found in {work_dir}.")

    df = pd.read_csv(forecast_file_path)

    for col in df.columns:
        if col != df.columns[0]:
            df[col] = df[col].round(2)

    html_table = df.to_html(index=False, border=0, classes='forecast-table')
    html_content = f"""
    <h3 style="color:#2c3e50;">{query_name}</h3>
    {html_table}
    <p><i>Please see the attached PNG file for the graphical forecast plot of {query_name}.</i></p>
    <hr>
    """
    context['ti'].xcom_push(key='email_html', value=html_content)


def combine_email_html(query_specs, **context):
    ti = context['ti']
    sections = []
    for spec in query_specs:
        html = ti.xcom_pull(
            task_ids=f'generate_html_{spec["id"]}',
            key='email_html'
        )
        if html:
            sections.append(html)
        else:
            sections.append(f"<p><b>{spec['name']}</b>: no forecast HTML available.</p>")

    combined_sections = "\n".join(sections)
    html_content = f"""
    <html>
    <head>
    <style>
      body {{ font-family: Arial, sans-serif; color: #333; }}
      h2 {{ color: #2c3e50; }}
      .forecast-table {{
          border-collapse: collapse;
          width: 100%;
          max-width: 800px;
          margin-top: 10px;
          font-size: 13px;
      }}
      .forecast-table th, .forecast-table td {{
          border: 1px solid #ddd;
          padding: 6px 10px;
          text-align: center;
          white-space: nowrap;
      }}
      .forecast-table th {{
          background-color: #f2f2f2;
          color: #333;
      }}
      .forecast-table tr:nth-child(even) {{
          background-color: #f9f9f9;
      }}
    </style>
    </head>
    <body>
      <p>Dear Team,</p>
      <p>Please find the consolidated forecast report below:</p>
      <br>
      {combined_sections}
      <br>
    </body>
    </html>
    """
    ti.xcom_push(key='combined_email_html', value=html_content)


default_args = {
    'owner': 'Jithendra Sai T',
    'depends_on_past': False,
    'email_on_failure': True,
    'email_on_retry': True,
    "email": ["junior.devfsd6-tc@uidai.net.in"],
    'retries': 10,
    'retry_delay': timedelta(minutes=1),
}

with DAG(
        dag_id='envoy_host_forecast',
        default_args=default_args,
        description='Fetch metrics from Thanos, run forecast, and email via SMTP',
        schedule='10 17 * * *',
        start_date=datetime(2026, 7, 22),
        catchup=False,
        tags=['thanos', 'forecast', 'smtp-email'],
) as dag:

    generate_html_tasks = []
    all_plot_files = []

    for q in QUERIES:
        task_id_safe = q["id"]
        work_dir = f"/tmp/forecast_{task_id_safe}"
        f_args = q["forecast_args"]
        plot_file_path = os.path.join(work_dir, f_args['OUTPUT_PLOT'])
        all_plot_files.append(plot_file_path)

        fetch_task = PythonOperator(
            task_id=f'fetch_data_{task_id_safe}',
            python_callable=fetch_and_update_data,
            op_kwargs={
                'query':         q['query'],
                'work_dir':      work_dir,
                'time_col':      f_args['TIME_COL'],
                'target_col':    f_args['TARGET_COL'],
                'task_id_safe':  task_id_safe,
            }
        )

        run_forecast_task = PythonOperator(
            task_id=f'run_forecast_{task_id_safe}',
            python_callable=execute_forecast_task,
            op_kwargs={
                'work_dir': work_dir,
                'f_args': f_args
            }
        )

        upload_history_task = PythonOperator(
            task_id=f'upload_history_{task_id_safe}',
            python_callable=upload_pred_history,
            op_kwargs={
                'work_dir': work_dir,
                'task_id_safe': task_id_safe,
            }
        )

        generate_html_task = PythonOperator(
            task_id=f'generate_html_{task_id_safe}',
            python_callable=generate_email_html,
            op_kwargs={
                'work_dir': work_dir,
                'output_file': f_args['OUTPUT_FILE'],
                'query_name': q['name'],
            }
        )

        fetch_task >> run_forecast_task >> upload_history_task >> generate_html_task
        generate_html_tasks.append(generate_html_task)

    combine_html_task = PythonOperator(
        task_id='combine_html_all',
        python_callable=combine_email_html,
        op_kwargs={'query_specs': [{'id': q['id'], 'name': q['name']} for q in QUERIES]},
    )

    send_email_task = EmailOperator(
        task_id='send_email_consolidated',
        to=QUERIES[0]['email_to'],
        cc=QUERIES[0]['cc'] if QUERIES[0]['cc'] else None,
        subject="Consolidated Forecast Report: UC Envoy Host Network Metrics",
        html_content="{{ ti.xcom_pull(task_ids='combine_html_all', key='combined_email_html') }}",
        files=all_plot_files,
        conn_id='smtp_default',
        from_email='strot@uidai.net.in'
    )

    generate_html_tasks >> combine_html_task >> send_email_task
