import warnings
warnings.filterwarnings('ignore')
import logging
logging.getLogger("cmdstanpy").setLevel(logging.WARNING)
logging.getLogger("prophet").setLevel(logging.WARNING)

def run_forecast(
    CSV_FILE,
    TIME_COL,
    TARGET_COL,
    FORECAST_PERIODS,
    FORECAST_START_HOUR,
    FORECAST_END_HOUR,
    OUTPUT_FILE,
    OUTPUT_PLOT,
    FREQ,
    FROM_UNIT,
    TO_UNIT,
    UNIT_CATEGORY,
    PRED_HISTORY_FILE,
):
    import os
    import pandas as pd
    import numpy as np
    from prophet import Prophet
    from datetime import timedelta
    import itertools
    from scipy.stats import boxcox_normmax
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates

    UNIT_FACTORS = {
        "data_size": {
            ("B",  "KB"): 1 / 1024,
            ("B",  "MB"): 1 / (1024 ** 2),
            ("B",  "GB"): 1 / (1024 ** 3),

            ("Bytes",  "KB"): 1 / 1024,
            ("Bytes",  "MB"): 1 / (1024 ** 2),
            ("Bytes",  "GB"): 1 / (1024 ** 3),

            ("B_dec", "KB_dec"): 1 / 1000,
            ("B_dec", "MB_dec"): 1 / (1000 ** 2),
            ("B_dec", "GB_dec"): 1 / (1000 ** 3),
        },
        "bandwidth": {
            ("Bytes/s", "KB/s"): 1 / 1024,
            ("Bytes/s", "MB/s"): 1 / (1024 ** 2),
            ("Bytes/s", "GB/s"): 1 / (1024 ** 3),

            ("B/s", "KB/s"): 1 / 1024,
            ("B/s", "MB/s"): 1 / (1024 ** 2),
            ("B/s", "GB/s"): 1 / (1024 ** 3),

            ("bps", "Kbps"): 1 / 1000,
            ("bps", "Mbps"): 1 / (1000 ** 2),
            ("bps", "Gbps"): 1 / (1000 ** 3),
        },
        "time": {
            ("ms", "s"): 1 / 1000,
            ("s",  "ms"): 1000,
            ("s",  "min"): 1 / 60,
            ("min", "s"): 60,
            ("min", "h"): 1 / 60,
            ("h", "min"): 60,
        },
        "rate": {
            ("fraction", "%"): 100,
            ("%", "fraction"): 1 / 100,
        },
    }
    def convert_values(series: pd.Series, from_unit: str, to_unit: str, decimals: int = 2, category: str | None = None) -> pd.Series:
        key = (from_unit, to_unit)
        if category:
            if category not in UNIT_FACTORS: raise ValueError(f"Unknown unit category: {category}")
            factors = UNIT_FACTORS[category]
            if key not in factors: raise ValueError(f"No conversion defined from {from_unit} to {to_unit} in category '{category}'")
            factor = factors[key]
        else:
            factor = None
            for cat_name, factors in UNIT_FACTORS.items():
                if key in factors:
                    factor = factors[key]
                    break
            if factor is None: raise ValueError(f"No conversion defined from {from_unit} to {to_unit}")
        converted = series.astype(float) * factor
        return converted.round(decimals)

    def convert_value(value: float, from_unit: str, to_unit: str, decimals: int = 2, category: str | None = None) -> float:
        key = (from_unit, to_unit)
        if category:
            if category not in UNIT_FACTORS: raise ValueError(f"Unknown unit category: {category}")
            factors = UNIT_FACTORS[category]
            if key not in factors: raise ValueError(f"No conversion defined from {from_unit} to {to_unit} in category '{category}'")
            factor = factors[key]
        else:
            factor = None
            for _, factors in UNIT_FACTORS.items():
                if key in factors:
                    factor = factors[key]
                    break
            if factor is None: raise ValueError(f"No conversion defined from {from_unit} to {to_unit}")
        converted = float(value) * factor
        return round(converted, decimals)

    def get_optimal_fourier_order(df_subset, time_col, target_col, max_order=15, variance_threshold=0.95):
        import numpy as np

        df_temp = df_subset.copy()
        df_temp[time_col] = pd.to_datetime(df_temp[time_col])
        df_temp['hour'] = df_temp[time_col].dt.hour

        hourly_median = df_temp.groupby('hour')[target_col].median()

        hourly_median = hourly_median.reindex(range(24)).interpolate().fillna(0)

        signal = hourly_median.values.astype(float)
        signal = signal - np.mean(signal)

        fft_vals = np.abs(np.fft.fft(signal))

        fft_vals = fft_vals[1:12]

        total_power = np.sum(fft_vals)
        if total_power == 0:
            return 3

        cumulative_power = np.cumsum(fft_vals) / total_power

        num_freqs = np.argmax(cumulative_power >= variance_threshold) + 1

        return int(np.clip(num_freqs, 2, max_order))

    def smooth_outages(dataframe, time_col, target_col, threshold=0.1):

        df_smooth = dataframe.copy()

        df_smooth[time_col] = pd.to_datetime(df_smooth[time_col])

        df_smooth['dayofweek'] = df_smooth[time_col].dt.dayofweek
        df_smooth['hour'] = df_smooth[time_col].dt.hour

        df_smooth['day_hour_median'] = df_smooth.groupby(['dayofweek', 'hour'])[target_col].transform('median')

        is_outage = df_smooth[target_col] < (df_smooth['day_hour_median'] * threshold)

        outage_count = is_outage.sum()
        if outage_count > 0:
            print(f"      -> Detected {outage_count} outage/anomaly points. Smoothing them out.")
            df_smooth.loc[is_outage, target_col] = df_smooth.loc[is_outage, 'day_hour_median']

        df_smooth = df_smooth.drop(columns=['dayofweek', 'hour', 'day_hour_median'])
        return df_smooth

    print("\n[1/4] Loading and preprocessing data...")

    df = pd.read_csv(CSV_FILE)
    df[TIME_COL] = pd.to_datetime(df[TIME_COL])
    df = df.sort_values(TIME_COL).reset_index(drop=True)

    print(f"      Loaded {len(df):,} rows | "
          f"Range: {df[TIME_COL].min().strftime('%Y-%m-%d %H:%M')} "
          f"-> {df[TIME_COL].max().strftime('%Y-%m-%d %H:%M')}")

    df = smooth_outages(df, TIME_COL, TARGET_COL)

    data_series = df[TARGET_COL].dropna() + 1

    if data_series.std() < 1e-5:
        print("      -> VERDICT: Data is constant. Skipping log transformation.")
        use_log = False
    else:
        try:
            optimal_lambda = boxcox_normmax(data_series, method='mle')
            print(f"      Box-Cox Lambda: {optimal_lambda:.4f}")
            if optimal_lambda < 0.5:
                print("      -> VERDICT: USE LOG TRANSFORMATION (multiplicative variance detected).")
                use_log = True
            else:
                print("      -> VERDICT: NO LOG TRANSFORMATION needed (variance is stable).")
                use_log = False
        except Exception as e:
            print(f"      -> VERDICT: Box-Cox failed ({type(e).__name__}). Defaulting to NO transformation.")
            use_log = False

    def _select_heuristic_params(series: pd.Series):
        mean_val = series.mean()
        if mean_val <= 1e-5:
            return 0.05, 10.0, "Constant data, using defaults."

        std_val = series.std()
        cv = std_val / mean_val

        try:
            autocorr = series.autocorr(lag=1)
        except Exception:
            autocorr = 0.5

        if autocorr < 0.3:
            cps = 0.05
            sps = 1.0
            verdict = f"Noisy data (Autocorr: {autocorr:.2f}). Conservative cps=0.01, sps=1.0"
        elif cv > 1.5 and autocorr >= 0.3:
            cps = 0.1
            sps = 10.0
            verdict = f"Volatile data (CV: {cv:.2f}). Moderate cps=0.05, sps=5.0"
        else:
            cps = 0.1
            sps = 10.0
            verdict = f"Stable data (Autocorr: {autocorr:.2f}, CV: {cv:.2f}). Default cps=0.05, sps=10.0"

        return cps, sps, verdict

    raw_series = df[TARGET_COL].dropna()
    best_cps, best_sps, param_verdict = _select_heuristic_params(raw_series)

    print(f"      -> PARAM VERDICT: {param_verdict}")
    df['_dt'] = pd.to_datetime(df[TIME_COL])
    weekday_df = df[df['_dt'].dt.dayofweek.isin([0, 1, 2, 3, 4])]
    weekend_df = df[df['_dt'].dt.dayofweek.isin([5, 6])]

    weekday_f_order = get_optimal_fourier_order(weekday_df, TIME_COL, TARGET_COL)
    weekend_f_order = get_optimal_fourier_order(weekend_df, TIME_COL, TARGET_COL)

    print(f"      -> Extracted Fourier Orders: Weekday={weekday_f_order}, Weekend={weekend_f_order}")
    prophet_df = df[[TIME_COL, TARGET_COL]].rename(columns={
        TIME_COL:   'ds',
        TARGET_COL: 'y'
    })

    if use_log:
        prophet_df['y'] = np.log1p(prophet_df['y'])

    prophet_df['on_weekday'] = prophet_df['ds'].dt.dayofweek.isin([0, 1, 2, 3, 4]).astype(float)
    prophet_df['on_weekend'] = prophet_df['ds'].dt.dayofweek.isin([5, 6]).astype(float)

    end_time       = prophet_df['ds'].max()
    val_start_time = end_time.replace(hour=0, minute=0, second=0, microsecond=0)

    train_full = prophet_df[prophet_df['ds'] < val_start_time].copy()
    val_set    = prophet_df[prophet_df['ds'] >= val_start_time].copy()

    if use_log:
        val_set['actual_y'] = np.expm1(val_set['y'])
    else:
        val_set['actual_y'] = val_set['y']

    def _add_conditions(df_):
        df_['on_weekday'] = df_['ds'].dt.dayofweek.isin([0, 1, 2, 3, 4]).astype(float)
        df_['on_weekend'] = df_['ds'].dt.dayofweek.isin([5, 6]).astype(float)
        return df_

    def _build_model(cps=0.05, sps=1.0, use_mcmc=False, weekday_order=10, weekend_order=3):
        m = Prophet(
            changepoint_prior_scale=cps,
            seasonality_prior_scale=sps,
            interval_width=0.90,
            changepoint_range=0.95,
            yearly_seasonality=False,
            weekly_seasonality=False,
            daily_seasonality=False,
            seasonality_mode='additive',
            mcmc_samples=300 if use_mcmc else 0
        )
        m.add_seasonality(name='daily_weekday', period=1, fourier_order=weekday_order, condition_name='on_weekday')
        m.add_seasonality(name='daily_weekend', period=1, fourier_order=weekend_order, condition_name='on_weekend')
        m.add_seasonality(name='weekly',        period=7, fourier_order=5, condition_name=None)
        return m

    print("\n[2/4] Selecting optimal training window...")

    target_windows   = [7, 10, 14, 21]
#     target_windows   = [7, 10, 14, 21, 28]
    window_results   = []
    evaluated_starts = set()

    for target in target_windows:
        ideal_start  = val_start_time - timedelta(days=target)
        shift_days   = ideal_start.dayofweek

        actual_start = (ideal_start - timedelta(days=shift_days)).replace(
            hour=0, minute=0, second=0, microsecond=0
        )

        actual_days  = (val_start_time - actual_start).days

        if actual_start in evaluated_starts:
            print(f"Target {target}d -> aligned start {actual_start.strftime('%Y-%m-%d')} already tested, skipping.")
            continue

        evaluated_starts.add(actual_start)

        train_subset = train_full[train_full['ds'] >= actual_start]

        subset_start = train_subset['ds'].min()
        subset_end   = train_subset['ds'].max()
        subset_rows  = len(train_subset)

        print(f"\n      Testing {actual_days}-day window (Target start: {actual_start.strftime('%A %Y-%m-%d')})")
        print(f"      -> Actual Data Used: {subset_start.strftime('%Y-%m-%d %H:%M')} to {subset_end.strftime('%Y-%m-%d %H:%M')} ({subset_rows} rows)")

        model = _build_model()
        model.fit(train_subset)

        future = model.make_future_dataframe(periods=len(val_set), freq=FREQ, include_history=False)
        future = _add_conditions(future)

        forecast   = model.predict(future)
        comparison = pd.merge(val_set[['ds', 'actual_y']], forecast[['ds', 'yhat']], on='ds')

        pred_y         = np.expm1(comparison['yhat']) if use_log else comparison['yhat']
        mae_score      = np.mean(np.abs(comparison['actual_y'] - pred_y))
        normalized_mae = mae_score / (comparison['actual_y'].mean() + 1e-5)
        print(f"      Mean Absolute Error (MAE): {(mae_score):,.2f}")
        print(f"      Normalized MAE: {normalized_mae * 100:.2f}%")

        window_results.append({
            'Actual_Window_Days': actual_days,
            'Start_Time':         actual_start,
            'Mean Absolute Error (MAE)': mae_score,
            'Normalized_MAE':     normalized_mae
        })

    window_df     = pd.DataFrame(window_results).sort_values('Normalized_MAE')
    best_window   = window_df.iloc[0]
    optimal_start = best_window['Start_Time']

    print(f"\n      => WINNER: {best_window['Actual_Window_Days']}-day window "
          f"(Mean Absolute Error (MAE): {best_window['Mean Absolute Error (MAE)']:,.2f}%)"
          f"(Normalized MAE: {best_window['Normalized_MAE'] * 100:.2f}%)")

    print(f"\n[3/4] Applying heuristic parameters to optimal window ...")

    optimal_train_df = train_full[train_full['ds'] >= optimal_start]

    best_params = {
        'changepoint_prior_scale': best_cps,
        'seasonality_prior_scale': best_sps
    }

    print("\n      --- SELECTED CONFIGURATION ---")
    print(f"      Training window   : {best_window['Actual_Window_Days']} days "
          f"(from {optimal_start.strftime('%Y-%m-%d')})")
    print(f"      changepoint_prior : {best_params['changepoint_prior_scale']}")
    print(f"      seasonality_prior : {best_params['seasonality_prior_scale']}")

    val_model = _build_model(
        cps=best_params['changepoint_prior_scale'],
        sps=best_params['seasonality_prior_scale']
    )
    val_model.fit(optimal_train_df)

    future_val = val_model.make_future_dataframe(periods=len(val_set), freq=FREQ, include_history=False)
    future_val = _add_conditions(future_val)
    val_forecast = val_model.predict(future_val)

    comparison = pd.merge(val_set[['ds', 'actual_y']], val_forecast[['ds', 'yhat']], on='ds')
    pred_y = np.expm1(comparison['yhat']) if use_log else comparison['yhat']
    best_params['MAE'] = np.mean(np.abs(comparison['actual_y'] - pred_y))
    best_params["NMAE"] =  best_params['MAE'] / (comparison['actual_y'].mean() + 1e-5)

    print(f"      Validation MAE    : "
          f"{convert_value(best_params['MAE'], FROM_UNIT, TO_UNIT, decimals=2, category=UNIT_CATEGORY):,.2f} {TO_UNIT}")
    print(f"      Validation NMAE   : {best_params['NMAE'] * 100:.2f}%")

#     if use_log:
#         val_forecast['val_pred_y'] = np.expm1(val_forecast['yhat'])
#     else:
#         val_forecast['val_pred_y'] = val_forecast['yhat']
#
#     val_forecast['val_pred_y'] = convert_values(
#         val_forecast['val_pred_y'], FROM_UNIT, TO_UNIT, decimals=2, category=UNIT_CATEGORY
#     )

    print(f"\n[4/4] Training final model and forecasting...")

    full_train_df = prophet_df[prophet_df['ds'] >= optimal_start].copy()

    final_model = _build_model(
        cps=best_params['changepoint_prior_scale'],
        sps=best_params['seasonality_prior_scale'],
        use_mcmc=False,
        weekday_order=weekday_f_order,
        weekend_order=weekend_f_order
    )
    final_model.fit(full_train_df)

    last_date = full_train_df['ds'].max()

    if FORECAST_START_HOUR is not None and FORECAST_END_HOUR is not None:
        target_date = (last_date + timedelta(days=1)).date()
        periods_needed = 1 * 24 + 24
        future = final_model.make_future_dataframe(periods=periods_needed, freq=FREQ, include_history=False)

        future = future[
            (future['ds'].dt.date == target_date) &
            (future['ds'].dt.hour >= FORECAST_START_HOUR) &
            (future['ds'].dt.hour <= FORECAST_END_HOUR)
        ]

        if future.empty:
            raise ValueError("No future dates found for the specified forecast window.")

        future = future.reset_index(drop=True)
        forecast_title_suffix = f"({FORECAST_START_HOUR}:00 - {FORECAST_END_HOUR}:00 on {target_date})"
        forecast_label = f"Forecast ({FORECAST_START_HOUR}:00-{FORECAST_END_HOUR}:00)"
    elif FORECAST_PERIODS is not None:
        future = final_model.make_future_dataframe(periods=FORECAST_PERIODS, freq=FREQ, include_history=False)
        forecast_title_suffix = f"(+{FORECAST_PERIODS}h from {future['ds'].min().strftime('%Y-%m-%d %H:%M')})"
        forecast_label = f'Forecast ({FORECAST_PERIODS}h)'
    else:
        raise ValueError("Must provide either FORECAST_PERIODS or both FORECAST_START_HOUR and FORECAST_END_HOUR")

    future = _add_conditions(future)

    forecast = final_model.predict(future)

    if use_log:
        forecast['pred_y']       = np.expm1(forecast['yhat'])
        forecast['pred_y_lower'] = np.expm1(forecast['yhat_lower'])
        forecast['pred_y_upper'] = np.expm1(forecast['yhat_upper'])
    else:
        forecast['pred_y']       = forecast['yhat']
        forecast['pred_y_lower'] = forecast['yhat_lower']
        forecast['pred_y_upper'] = forecast['yhat_upper']

    forecast["pred_y"]       = convert_values(forecast["pred_y"], FROM_UNIT, TO_UNIT, decimals=2, category=UNIT_CATEGORY )
    forecast["pred_y_lower"] = convert_values(forecast["pred_y_lower"], FROM_UNIT, TO_UNIT, decimals=2, category=UNIT_CATEGORY)
    forecast["pred_y_upper"] = convert_values(forecast["pred_y_upper"], FROM_UNIT, TO_UNIT, decimals=2, category=UNIT_CATEGORY)

    output_df = forecast[['ds', 'pred_y', 'pred_y_lower', 'pred_y_upper']].copy()
    output_df.columns = [
        TIME_COL,
        TARGET_COL,
        f"{TARGET_COL} lower 90",
        f"{TARGET_COL} upper 90"
    ]
    output_df.to_csv(OUTPUT_FILE, index=False)

    hist_pred_df = pd.DataFrame(columns=['ds', 'pred_y'])
    if os.path.exists(PRED_HISTORY_FILE):
        try:
            hist_pred_df = pd.read_csv(PRED_HISTORY_FILE)
            hist_pred_df['ds'] = pd.to_datetime(hist_pred_df['ds'])
        except Exception as e:
            print(f"      -> Error reading {PRED_HISTORY_FILE}: {e}")

    new_preds = forecast[['ds', 'pred_y']].copy()
    new_preds['ds'] = pd.to_datetime(new_preds['ds'])

    combined_hist = pd.concat([hist_pred_df, new_preds], ignore_index=True)
    combined_hist = combined_hist.drop_duplicates(subset=['ds'], keep='last')
    combined_hist = combined_hist.sort_values('ds').reset_index(drop=True)

    combined_hist.to_csv(PRED_HISTORY_FILE, index=False)
    print(f"      -> Updated prediction history saved to {PRED_HISTORY_FILE}")

    plot_history_start = full_train_df['ds'].max() - timedelta(days=10)
    history_plot = full_train_df[full_train_df['ds'] >= plot_history_start].copy()

    if use_log:
        history_plot['y_orig'] = np.expm1(history_plot['y'])
    else:
        history_plot['y_orig'] = history_plot['y']

    history_plot["y_orig"] = convert_values(
        history_plot["y_orig"], FROM_UNIT, TO_UNIT, decimals=2, category=UNIT_CATEGORY
    )

    future_start = forecast['ds'].min()
    hist_plot_df = combined_hist[(combined_hist['ds'] >= plot_history_start) & (combined_hist['ds'] < future_start)].copy()


    def _reindex_with_nans(df, ds_col, freq):
        if df.empty:
            return df
        min_t = df[ds_col].min()
        max_t = df[ds_col].max()
        full_range = pd.date_range(start=min_t, end=max_t, freq=freq)
        df = df.set_index(ds_col).reindex(full_range).reset_index(names=[ds_col])
        return df

    history_plot = _reindex_with_nans(history_plot, 'ds', FREQ)
    hist_plot_df = _reindex_with_nans(hist_plot_df, 'ds', FREQ)
    forecast = _reindex_with_nans(forecast, 'ds', FREQ)

#     val_forecast = _reindex_with_nans(val_forecast, 'ds', FREQ)

    try:
        import seaborn as sns
        plt.style.use('seaborn-v0_8-whitegrid')
    except:
        try:
            plt.style.use('seaborn-whitegrid')
        except:
            pass

    fig, ax = plt.subplots(figsize=(14, 6), dpi=120)
    fig.patch.set_facecolor('#ffffff')
    ax.set_facecolor('#ffffff')

    # Historical Data
    ax.plot(
        history_plot['ds'],
        history_plot['y_orig'],
        color='#2A56C6',
        linewidth=2.2,
        alpha=0.9,
        label='Historical (Last 10 Days)',
        zorder=2
    )

    # Historical Predictions (Over last 10 days)
    if not hist_plot_df.empty:
        ax.plot(
            hist_plot_df['ds'],
            hist_plot_df['pred_y'],
            color='#0F9D58',
            linewidth=2.0,
            linestyle='--',
            marker='o',
            markersize=4,
            label='Historical Forecast',
            zorder=3
        )

#     if not val_forecast.empty:
#          ax.plot(
#              val_forecast['ds'],
#              val_forecast['val_pred_y'],
#              color='#9C27B0',  # Purple
#              linewidth=2.0,
#              linestyle='--',
#              marker='s',
#              markersize=5,
#              label="Today's Backtest (Pred vs Actual)",
#              zorder=3
#          )

    # Future Forecast
    ax.plot(
        forecast['ds'],
        forecast['pred_y'],
        color='#DB4437',
        linewidth=2.5,
        linestyle='-',
        marker='o',
        markersize=4,
        label=forecast_label,
        zorder=4
    )

    # Confidence band
    ax.fill_between(
        forecast['ds'],
        forecast['pred_y_lower'],
        forecast['pred_y_upper'],
        color='#DB4437',
        alpha=0.15,
        linewidth=0,
        label='90% Confidence Interval',
        zorder=1
    )

    # Forecast start marker
    forecast_start = forecast['ds'].min()
    ax.axvline(x=forecast_start, color='#5f6368', linestyle=':', linewidth=2,
               label='Forecast Start', zorder=1)

    # Premium Styling
    ax.grid(True, linestyle='-', alpha=0.4, color='#e0e0e0')
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H:%M'))
    plt.xticks(rotation=0, color='#3c4043', fontsize=10)
    plt.yticks(color='#3c4043', fontsize=10)

    # Clean borders
    for spine in ['top', 'right']:
        ax.spines[spine].set_visible(False)
    for spine in ['left', 'bottom']:
        ax.spines[spine].set_color('#dadce0')
        ax.spines[spine].set_linewidth(1.2)

    # Titles and Labels
    ax.set_title(
        f'Forecast: {TARGET_COL}',
        color='#202124', fontsize=16, fontweight='bold', loc='left', pad=15
    )
    ax.set_title(
        forecast_title_suffix,
        color='#5f6368', fontsize=12, loc='right', pad=15
    )

    ax.set_xlabel('Time', color='#5f6368', fontsize=12, fontweight='medium', labelpad=10)
    ax.set_ylabel(f"{TARGET_COL} ({TO_UNIT})", color='#5f6368', fontsize=12, fontweight='medium', labelpad=10)

    # Elegant Legend
    ax.legend(
        fontsize=11,
        loc='upper left',
        frameon=True,
        facecolor='#ffffff',
        edgecolor='#e0e0e0',
        framealpha=0.9,
        borderpad=0.8,
        labelcolor='#3c4043'
    )

    plt.tight_layout()
    plt.savefig(OUTPUT_PLOT, dpi=200, facecolor=fig.get_facecolor(), bbox_inches='tight')
    plt.close()
    print(f"Plot saved to {OUTPUT_PLOT}")