from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python import PythonOperator
import sys
import os

sys.path.append(os.path.dirname(__file__))
from niyantranforecast import run_daily_forecast

job_name = "seda_niyantran_forecast"
desc = "Job to forecast seda metrics"
pod_name = "z-seda-niyantran-forecast"
t_id = "forecast"
schedule = "30 0 * * *"

default_args = {
    'owner': 'Jithendra Sai T',
    'depends_on_past': False,
    'email_on_failure': True,
    'email_on_retry': True,
    "email": ["junior.devfsd6-tc@uidai.net.in"],
    'retries': 10,
    'retry_delay': timedelta(minutes=1),
}

dag = DAG(
    f'{job_name}',
    default_args=default_args,
    description=f'{desc}',
    schedule=f'{schedule}',
    start_date=datetime(2026, 8, 17),
    catchup=False,
    tags=['forecast', 'niyantran']
)

def run_forecast_callable():
    run_daily_forecast()

task = PythonOperator(
    task_id=f"{t_id}",
    python_callable=run_forecast_callable,
    dag=dag,
)

task