import pandas as pd
from prophet import Prophet
import redis
import json
from datetime import datetime, timedelta
import logging
from enum import Enum
from trino.dbapi import connect
import pytz

trino_host="10.10.118.35"
trino_port=8080
trino_user="sai.nisg"

IST = pytz.timezone('Asia/Kolkata')

def trino(query, host=trino_host, port=trino_port, user=trino_user):
    try:
        conn = connect(
            host=host,
            port=port,
            user=user
        )
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"query": query, "success": 1, "data": body}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Redis connection
redis_client = redis.Redis(host='10.10.118.52', port=6379, decode_responses=True)

# Configuration
FORECAST_HOURS = 24
MIN_DATAPOINTS = 48
DAYS_LOOKBACK = 60
REDIS_KEY_TTL = 86400 * 2

EXCLUDED_DATES = [
    '2026-01-02','2026-01-03','2026-01-04','2026-01-05','2026-01-06','2026-01-07',
    '2026-01-08','2026-01-09','2026-01-10','2026-01-11','2026-01-12','2026-05-13',
    '2026-05-14','2026-05-15','2026-05-16','2026-05-17'
]

EXCLUDED_DATE_RANGES = [

]

KNOWN_HOLIDAYS = [
    '2026-01-14', '2026-01-26', '2026-03-19', '2026-03-21', '2026-03-31',
    '2026-04-03', '2026-05-01', '2026-05-27', '2026-06-26', '2026-08-15',
    '2026-08-26', '2026-09-14', '2026-10-02', '2026-10-20', '2026-11-08',
    '2026-11-24', '2026-12-25'
]
def add_day_features(df, ds_col='ds'):
    df = df.copy()
    df['is_weekend'] = df[ds_col].dt.dayofweek.isin([5, 6]).astype(int)
    df['is_holiday'] = df[ds_col].dt.date.isin(
        [pd.to_datetime(d).date() for d in KNOWN_HOLIDAYS]
    ).astype(int)
    df['is_offday'] = ((df['is_weekend'] == 1) | (df['is_holiday'] == 1)).astype(int)
    return df

def filter_excluded_dates(df, date_column='window'):
    if df is None or df.empty:
        return df

    df[date_column] = pd.to_datetime(df[date_column])

    if EXCLUDED_DATES:
        excluded_dates_dt = pd.to_datetime(EXCLUDED_DATES)
        df = df[~df[date_column].dt.date.isin([d.date() for d in excluded_dates_dt])]

    for start_date, end_date in EXCLUDED_DATE_RANGES:
        start_dt = pd.to_datetime(start_date)
        end_dt = pd.to_datetime(end_date)

        has_start_time = start_dt.time() != pd.Timestamp('00:00:00').time()
        has_end_time = end_dt.time() != pd.Timestamp('00:00:00').time()

        if has_start_time or has_end_time:
            df = df[~((df[date_column] >= start_dt) & (df[date_column] <= end_dt))]
        else:
            df = df[~((df[date_column].dt.date >= start_dt.date()) &
                      (df[date_column].dt.date <= end_dt.date()))]

    return df

def get_training_data():
    cutoff_date = (datetime.now(pytz.utc).astimezone(IST) - timedelta(days=DAYS_LOOKBACK)).strftime('%Y-%m-%d')

    def checked(query, label):
        result = trino(query)
        if result.get('success', 0) == 0:
            logger.error(f"Trino query failed for {label}: {result.get('msg')} | Query: {query}")
            raise RuntimeError(f"Trino query failed for {label}: {result.get('msg')}")
        return result['df']

    df_rejected = checked(
        f"""
        SELECT *
        FROM flink_stream.analytics_seda.seda_stage_rejection_hourly_aggr_v1
        WHERE window >= TIMESTAMP '{cutoff_date}'
        """, "rejected")
    df_rejected = filter_excluded_dates(df_rejected)

    df_inflow = checked(
        f"""
        SELECT *
        FROM flink_stream.analytics_seda.seda_stage_inflow_hourly_aggr_v1
        WHERE window >= TIMESTAMP '{cutoff_date}'
        """, "inflow")
    df_inflow = filter_excluded_dates(df_inflow)

    df_outflow = checked(
        f"""
        SELECT *
        FROM flink_stream.analytics_seda.seda_stage_outflow_hourly_aggr_v1
        WHERE window >= TIMESTAMP '{cutoff_date}'
        """, "outflow")
    df_outflow = filter_excluded_dates(df_outflow)

    df_stage_errors = checked(
        f"""
        SELECT *
        FROM flink_stream.analytics_seda.seda_stage_exception_hourly_aggr_v1
        WHERE window >= TIMESTAMP '{cutoff_date}'
        """, "stage_errors")
    df_stage_errors = filter_excluded_dates(df_stage_errors)
    df_stage_errors = df_stage_errors[~df_stage_errors["error_code"].str.startswith(("Connection refused executing GET", "Connect timed out executing GET", "Read timed out executing GET"), na=False)]

    return df_rejected, df_inflow, df_outflow, df_stage_errors

def train_and_forecast(df, ds_col, y_col, group_key):
    df = df.set_index(ds_col).sort_index()

    if len(df) < MIN_DATAPOINTS:
        logger.warning(f"Skipping {group_key}:  Insufficient data ({len(df)} rows)")
        return None, None

    df_prophet = pd.DataFrame({
        'ds': df.index,
        'y': df[y_col].values
    })


    df_prophet = df_prophet.replace([float('inf'), float('-inf')], float('nan')).dropna()

    if len(df_prophet) < MIN_DATAPOINTS:
        logger.warning(f"Skipping {group_key}:  Insufficient clean data")
        return None, None

    df_prophet = add_day_features(df_prophet, 'ds')

    mean_value = df_prophet['y'].mean()
    std_value = df_prophet['y'].std()
    cv = std_value / mean_value if mean_value > 0 else 1

    interval_width = min(0.97, 0.95 + (cv * 0.05))

    model = Prophet(
        yearly_seasonality=False,
        weekly_seasonality=True,
        daily_seasonality=False,
        seasonality_mode='additive',
        interval_width=interval_width,
        changepoint_prior_scale=0.05,
        seasonality_prior_scale=10,
        uncertainty_samples=1000
    )

    model.add_regressor('is_offday', mode='additive')

    df_prophet['on_weekday'] = (~df_prophet['ds'].dt.dayofweek.isin([5, 6])).astype(int)
    df_prophet['on_weekend'] = df_prophet['ds'].dt.dayofweek.isin([5, 6]).astype(int)

    model.add_seasonality(
        name='daily_weekday',
        period=1,
        fourier_order=8,
        condition_name='on_weekday'
    )
    model.add_seasonality(
        name='daily_weekend',
        period=1,
        fourier_order=4,
        condition_name='on_weekend'
    )

    model.fit(df_prophet)

    ist_now = datetime.now(pytz.utc).astimezone(IST)
    today_start = ist_now.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=None)
    future_df = pd.DataFrame({'ds': pd.date_range(start=today_start, periods=24, freq='h')})
    future_df = add_day_features(future_df, 'ds')
    future_df['on_weekday'] = (~future_df['ds'].dt.dayofweek.isin([5, 6])).astype(int)
    future_df['on_weekend'] = future_df['ds'].dt.dayofweek.isin([5, 6]).astype(int)

    forecast = model.predict(future_df)

    for col in ["yhat", "yhat_lower", "yhat_upper"]:
        forecast[col] = forecast[col].clip(lower=0)

    return forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']],interval_width


def store_forecast_to_redis(forecast_df, redis_key_prefix, interval_width):
    """
    Store hourly yhat_upper values in Redis
    Key format: prophet:{type}:{stage}:{hour}
    Value: JSON with yhat, yhat_upper, yhat_lower
    """
    if forecast_df is None:
        return

    for _, row in forecast_df.iterrows():
        hour = row['ds'].hour
        redis_key = f"{redis_key_prefix}:{hour: 02d}"

        ist_now = datetime.now(pytz.utc).astimezone(IST)

        value = {
            'yhat':  round(row['yhat'], 2),
            'yhat_lower': round(row['yhat_lower'], 2),
            'yhat_upper': round(row['yhat_upper'], 2),
            'interval_width': interval_width,
            'forecast_datetime': row['ds'].strftime('%Y-%m-%d %H:%M:%S'),
            'generated_at': ist_now.isoformat()
        }

        redis_client.setex(redis_key, REDIS_KEY_TTL, json.dumps(value))
        logger.debug(f"Stored {redis_key}: {value}")


def run_daily_forecast():
    """Main job:  Train models and store forecasts in Redis"""
    logger.info("Starting daily Prophet forecast job...")

    df_rejected, df_inflow, df_outflow, df_stage_errors = get_training_data()

    # =========================================================
    # 1.REJECTION FORECASTS (by stage)
    # =========================================================
    logger.info("Processing rejection forecasts...")
    for stage in df_rejected['stage'].dropna().unique():
        df_stage = df_rejected[df_rejected['stage'] == stage].copy()
        forecast,interval_width = train_and_forecast(df_stage, 'window', 'count', f"rejected:{stage}")

        if forecast is not None:
            redis_key_prefix = f"prophet:rejected:{stage}"
            store_forecast_to_redis(forecast, redis_key_prefix, interval_width)
            logger.info(f"  ✓ Stored forecast for rejected:{stage}")

    # =========================================================
    # 2.INFLOW FORECASTS (inflow by stage)
    # =========================================================
    logger.info("Processing flow forecasts...")
    for stage in df_inflow['stage'].dropna().unique():
        df_stage = df_inflow[df_inflow['stage'] == stage].copy()

        # Inflow
        forecast_inflow,interval_width = train_and_forecast(df_stage, 'window', 'count', f"inflow:{stage}")
        if forecast_inflow is not None:
            store_forecast_to_redis(forecast_inflow, f"prophet:inflow:{stage}", interval_width)
            logger.info(f"  ✓ Stored forecast for inflow:{stage}")

    # =========================================================
    # 3.OUTFLOW FORECASTS (outflow by stage)
    # =========================================================
    logger.info("Processing flow forecasts...")
    for stage in df_outflow['stage'].dropna().unique():
        df_stage = df_outflow[df_outflow['stage'] == stage].copy()

        # Outflow
        forecast_outflow,interval_width = train_and_forecast(df_stage, 'window', 'count', f"outflow:{stage}")
        if forecast_outflow is not None:
            store_forecast_to_redis(forecast_outflow, f"prophet:outflow:{stage}", interval_width)
            logger.info(f"  ✓ Stored forecast for outflow:{stage}")

    # =========================================================
    # 4.STAGE ERROR FORECASTS (by aggregationtype + stage + errortype + reasoncode)
    # =========================================================
    logger.info("Processing error forecasts...")

    # Group by unique combination
    stage_error_groups = df_stage_errors.groupby(['aggregation_type', 'stage', 'error_type', 'error_code'],dropna=False)

    for (agg_type, stage, error_type, error_code), df_group in stage_error_groups:

        group_key = f"error:{agg_type}:{stage}:{error_type}:{error_code}"

        forecast,interval_width = train_and_forecast(df_group.copy(), 'window', 'count', group_key)

        if forecast is not None:
            redis_key_prefix = f"prophet:{group_key}"
            store_forecast_to_redis(forecast, redis_key_prefix, interval_width)
            logger.info(f"  ✓ Stored forecast for {group_key}")

    logger.info("Daily Prophet forecast job completed!")


if __name__ == "__main__":
    try:
        run_daily_forecast()
    except Exception as e:
        logger.exception("Forecast job failed")