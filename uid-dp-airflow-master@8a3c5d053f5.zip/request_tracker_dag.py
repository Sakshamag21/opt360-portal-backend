from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator

from datetime import datetime
from trino.dbapi import connect

trino_host="10.10.118.10"
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="airflow_dag_op"

req_track_merge="""
MERGE INTO strot.mysql_uid_v2.request_tracker AS target
USING (
    SELECT
    tracker_key,
    refid,
    sid,
    sid_date,
    srn_num,
    grievance_id,
    priority,
    type,
    sub_type,
    mode,
    stage,
    stage_status,
    stage_status_date,
    stage_reason_code,
    stage_reject_reason_code,
    submission_count,
    operator_id,
    supervisor_id,
    upload_time,
    update_ind,
    reject_ind,
    auth_extraction_status,
    auth_extraction_status_date,
    is_child,
    source,
    created_by,
    creation_date,
    last_updated_by,
    last_updated_date,
    enrolment_centre,
    is_resumable,
    can_cancel,
    color_code,
    consent_reference_id,
    gps_longitude,
    gps_latitude,
    machine_code,
    station_id,
    agency_code,
    registrar_id,
    client_version,
    hof_status,
    date_of_approval_introducer,
    date_of_approval_hof,
    disposal_date_of_hof,
    disposal_date_of_introducer,
    hof_relation_type,
    is_hof,
    is_introducer,
    is_assisted
FROM new_seda_r.uidprocessv2_2.request_tracker where last_updated_date> current_timestamp - interval '2' day
) AS source
ON target.tracker_key = source.tracker_key
WHEN MATCHED THEN UPDATE SET
    refid = source.refid,
    sid = source.sid,
    sid_date = source.sid_date,
    srn_num = source.srn_num,
    grievance_id = source.grievance_id,
    priority = source.priority,
    type = source.type,
    sub_type = source.sub_type,
    mode = source.mode,
    stage = source.stage,
    stage_status = source.stage_status,
    stage_status_date = source.stage_status_date,
    stage_reason_code = source.stage_reason_code,
    stage_reject_reason_code = source.stage_reject_reason_code,
    submission_count = source.submission_count,
    operator_id = source.operator_id,
    supervisor_id = source.supervisor_id,
    upload_time = source.upload_time,
    update_ind = source.update_ind,
    reject_ind = source.reject_ind,
    is_child = source.is_child,
    source = source.source,
    created_by = source.created_by,
    creation_date = source.creation_date,
    last_updated_by = source.last_updated_by,
    last_updated_date = source.last_updated_date,
    enrolment_centre = source.enrolment_centre,
    is_resumable = source.is_resumable,
    can_cancel = source.can_cancel,
    color_code = source.color_code,
    consent_reference_id = source.consent_reference_id,
    gps_longitude = source.gps_longitude,
    gps_latitude = source.gps_latitude,
    machine_code = source.machine_code,
    station_id = source.station_id,
    agency_code = source.agency_code,
    registrar_id = source.registrar_id,
    client_version = source.client_version,
    hof_status = source.hof_status,
    hof_relation_type = source.hof_relation_type,
    is_hof = source.is_hof,
    is_introducer = source.is_introducer,
    is_assisted = source.is_assisted
WHEN NOT MATCHED THEN INSERT (
    tracker_key, refid, sid, sid_date, srn_num, grievance_id, priority, type, sub_type, mode,
    stage, stage_status, stage_status_date, stage_reason_code, stage_reject_reason_code,
    submission_count, operator_id, supervisor_id, upload_time, update_ind, reject_ind, is_child, source, created_by,
    creation_date, last_updated_by, last_updated_date, enrolment_centre, is_resumable,
    can_cancel, color_code, consent_reference_id, gps_longitude, gps_latitude, machine_code,
    station_id, agency_code, registrar_id, client_version, hof_status, hof_relation_type, is_hof, is_introducer, is_assisted
) VALUES (
    source.tracker_key, source.refid, source.sid, source.sid_date, source.srn_num, source.grievance_id,
    source.priority, source.type, source.sub_type, source.mode, source.stage, source.stage_status,
    source.stage_status_date, source.stage_reason_code, source.stage_reject_reason_code,
    source.submission_count, source.operator_id, source.supervisor_id, source.upload_time,
    source.update_ind, source.reject_ind,
    source.is_child, source.source, source.created_by, source.creation_date, source.last_updated_by,
    source.last_updated_date, source.enrolment_centre, source.is_resumable, source.can_cancel,
    source.color_code, source.consent_reference_id, source.gps_longitude, source.gps_latitude,
    source.machine_code, source.station_id, source.agency_code, source.registrar_id,
    source.client_version, source.hof_status,
    source.hof_relation_type, source.is_hof, source.is_introducer, source.is_assisted
)
"""

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2026,8,28),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1
}

dag = DAG(
    'request_tracker_update_hourly_v1',
    default_args=default_args,
    description='DAG to update request tracker hourly',
    schedule="30 */6 * * *",
    catchup=False
)

def run_query(query,host=trino_host,port=trino_port,user=trino_user):
    conn = connect(
        host=host,
        port=port,
        user=user,
        )
    cur = conn.cursor()
    cur.execute(query)
    return {"success": 1}



req_tracker_upd = PythonOperator(
                task_id='merge_into_rt_v1',
                python_callable=run_query,
                op_kwargs={'query': req_track_merge},
                trigger_rule='all_done',
                dag=dag,
            )



req_tracker_upd
