from airflow import DAG
from datetime import datetime
from airflow.settings import AIRFLOW_HOME
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from zoho_alerts import zoho_failure_callback
from airflow.providers.smtp.notifications.smtp import SmtpNotifier
from kubernetes.client import models as k8s

job_name = "ot_enriched_update_daily"
desc = "OT Enriched update"
pod_name = "ot-enriched-update-pod"
t_id = "ot-enriched-update"
driver_pod_name = "zz-ot-enriched-merge-daily"
file_name = "origin_tracker_merge_daily"

retry_notifier = SmtpNotifier(
    from_email="strot@uidai.net.in",
    to=[
        "techexecutive14-yp23@uidai.net.in"
    ],
    subject="Airflow Alert: Task {{ ti.task_id }} Failed (Attempt {{ ti.try_number }})"
)

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2026, 7, 20),
    'retries': 1,
    'on_failure_callback': zoho_failure_callback,
    "on_retry_callback": retry_notifier
}



custom_toleration = k8s.V1Toleration(
    key="strot",
    operator='Equal',
    value='true',
    effect='NoSchedule'
)

dag = DAG(
    f'{job_name}',
    default_args=default_args,
    description=f'{desc}',
    schedule="30 2 * * *",
    catchup=False,
    tags=['uid_master_tables']
)


task = KubernetesPodOperator(
    namespace='strot-spark',
    service_account_name='strot-service-account',
    image="hbdc-harbor-registry-prod.uidai.net.in/data-platform/pyspark:3.4.2_3", 
    config_file="/opt/airflow/dags/gpu_kubeconfig_hdc", 
    name=f"{pod_name}", task_id=f"{t_id}", 
    tolerations=[custom_toleration],
    cmds=["/bin/bash", "-c"],
    arguments=[f"""/opt/spark/bin/spark-submit \
                --master k8s://https://10.10.102.220:443 \
                --deploy-mode cluster \
                --name {driver_pod_name} \
                --class org.apache.spark.deploy.SparkSubmit \
                --conf spark.kubernetes.container.image=hbdc-harbor-registry-prod.uidai.net.in/data-platform/pyspark:3.4.2_3 \
                --conf spark.kubernetes.namespace=strot-spark \
                --conf spark.serializer=org.apache.spark.serializer.KryoSerializer \
                --conf spark.driver.cores=8 \
                --conf spark.executor.cores=8 \
                --conf spark.executor.instances=5 \
                --conf spark.driver.memory=64g \
                --conf spark.executor.memory=256g \
                --conf spark.driver.maxResultSize=16g \
                --conf spark.kubernetes.driver.limit.cores=8 \
                --conf spark.kubernetes.executor.limit.cores=8 \
                --conf spark.kubernetes.driver.request.cores=8 \
                --conf spark.kubernetes.executor.request.cores=8 \
                --conf spark.driver.memoryOverhead=32g \
                --conf spark.executor.memoryOverhead=128g \
                --conf spark.executor.extraJavaOptions=-XX:+UseG1GC \
                --conf spark.hadoop.fs.s3a.aws.credentials.provider=org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider \
                --conf spark.hadoop.fs.s3a.impl=org.apache.hadoop.fs.s3a.S3AFileSystem \
                --conf spark.hadoop.fs.s3a.path.style.access=true \
                --conf spark.hadoop.fs.s3a.secret.key=XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4 \
                --conf spark.hadoop.fs.s3a.access.key=9S0KLIQO7T2XCNGH4P4A \
                --conf spark.hadoop.fs.s3a.endpoint=http://10.10.103.12:425 \
                --conf spark.sql.extensions=org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions \
                --conf spark.sql.catalog.strot=org.apache.iceberg.spark.SparkCatalog \
                --conf spark.sql.catalog.strot.type=hive \
                --conf spark.sql.catalog.strot.uri=thrift://10.10.118.49:9083 \
                --conf spark.sql.catalog.flink_stream=org.apache.iceberg.spark.SparkCatalog \
                --conf spark.sql.catalog.flink_stream.type=hive \
                --conf spark.sql.catalog.flink_stream.uri=thrift://10.10.118.50:9083 \
                --conf spark.kubernetes.authenticate.driver.serviceAccountName=strot-service-account \
                --jars local:///opt/spark/jars/hadoop-aws-3.3.4.jar,local:///opt/spark/jars/iceberg-spark-runtime-3.4_2.12-1.5.2.jar,local:///opt/spark/jars/mysql-connector-java-8.0.30.jar \
                s3a://prd-bi-data-platform-uploads/sparkjobs/{file_name}.py"""], 
    in_cluster=False, get_logs=True, log_events_on_failure=True, dag=dag,
    container_resources=k8s.V1ResourceRequirements(
        requests={"cpu": "1", "memory": "2Gi"},
        limits={"cpu": "1", "memory": "2Gi"}
    ),
)

task
