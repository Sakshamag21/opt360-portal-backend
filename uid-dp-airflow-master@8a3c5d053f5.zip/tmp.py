import clickhouse_connect
import pandas as pd

def export_clickhouse_to_csv():
    # 1. Create a ClickHouse client connection
    client = clickhouse_connect.get_client(
        host='10.10.120.86',          # Replace with your ClickHouse host
        port=8123,                 # Default HTTP port
        username='default',        # Replace with your username
        password='qwerty',  # Replace with your password
        database='operator360'         # Replace with your database name
    )

    # 2. Write your SQL query
    query = """SELECT * FROM "operator360"."risk_analysis" where date(updated_at)=date('2026-09-05') """

    try:
        # 3. Execute query and fetch data directly into a Pandas DataFrame
        print("Fetching data from ClickHouse...")
        df = client.query_df(query)

        # 4. Save the DataFrame to a CSV file
        csv_filename = 'risk_analysis.csv'
        df.to_csv(csv_filename, index=False) # index=False prevents writing row numbers
        
        print(f"Successfully saved {len(df)} rows to {csv_filename}")

    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        # 5. Close the connection
        client.close()

if __name__ == "__main__":
    export_clickhouse_to_csv()