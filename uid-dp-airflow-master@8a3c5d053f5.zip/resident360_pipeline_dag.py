#resident360_pipeline_dag.py
from airflow.sdk import DAG
from datetime import datetime
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from kubernetes.client import models as k8s
import yaml
import boto3


config_bucket ="prd-bi-data-platform-feature-resident360-00"
config_key = "configs/pipeline_config.yaml"

session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4')
s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425') 
local_yaml_path = '/tmp/r360_pipeline_config.yaml'
s3_client.download_file(config_bucket, config_key, local_yaml_path)

with open(local_yaml_path) as f:
    data = yaml.safe_load(f)

pipeline_names = list(data["pipelines"].keys())

count = len(pipeline_names)

job_name = "RESIDENT360_PIPELINES_DAG"
desc = "Dag To Run Pipelines Of Resident360"
schedule = "0 * * * *"

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2026, 6, 18),
    'email_on_failure': True,
    'email':["techexe15.yp25@uidai.net.in","techexe12.yp24@uidai.net.in"],
    'email_on_retry': True,
    'retries': 1
}

dag = DAG(
    f'{job_name}',
    default_args=default_args,
    description=f'{desc}',
    schedule=f'{schedule}',
    tags=["RESIDENT360", "PIPELINES"],
    catchup=False,
    max_active_runs = 1,
    max_active_tasks = count
)

# pod_affinity = {
#     "nodeAffinity": {
#         "requiredDuringSchedulingIgnoredDuringExecution": {
#             "nodeSelectorTerms": [
#                 {
#                     "matchExpressions": [
#                         {
#                             "key": "env",
#                             "operator": "In",
#                             "values": ["strot"]
#                         }
#                     ]
#                 }
#             ]
#         }
#     }
# }

custom_toleration = k8s.V1Toleration(
    key="strot",
    operator='Equal',
    value='true',
    effect='NoSchedule'
)


for pipeline in pipeline_names:
    pod_name = f"resident360-{pipeline}-airflow"
    task_id = f"resident360-{pipeline}-task"

    task = KubernetesPodOperator(
        namespace='strot-spark',
        service_account_name='strot-service-account',
        image="hbdc-harbor-registry-prod.uidai.net.in/data-platform/pyspark-duckdb-sqlmesh:4.0.2_0.235.4_2", 
        config_file="/opt/airflow/dags/gpu_kubeconfig_hdc", 
        name=f"{pod_name}", 
        task_id=f"{task_id}", 
        tolerations=[custom_toleration],
        cmds=["/bin/bash", "-c"],
        env_vars={
            "KUBERNETES_SERVICE_HOST": "10.10.102.220",
            "KUBERNETES_SERVICE_PORT": "443"
        },
        arguments=[
            f"""python3 -c "import boto3;session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4');s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425');s3_client.download_file('prd-bi-data-platform-feature-resident360-00','pipeline/job_head.py','/tmp/r360_job_head.py')" &&  python3 /tmp/r360_job_head.py --pipeline {pipeline} --config_bucket {config_bucket} --config_key {config_key} """
        ],
        container_resources=k8s.V1ResourceRequirements(
            requests={"cpu": "1", "memory": "2Gi"},
            limits={"cpu": "1", "memory": "2Gi"}
        ),
        in_cluster=False, 
        get_logs=True, 
        log_events_on_failure=True, 
        is_delete_operator_pod = False,
        dag=dag,
    )

