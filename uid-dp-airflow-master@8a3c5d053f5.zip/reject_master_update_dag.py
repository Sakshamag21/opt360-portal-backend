from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
import pandas as pd
from datetime import datetime
from trino.dbapi import connect

trino_host="10.10.116.75"
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="airflow_dag_reject_master_upd"
trino_table_name = 'strot.mysql_uid_v2.eid_reject_master'
iceberg_incr_key='eid_reject_key'

default_args = {
    'owner': 'harshag.nisg',
    'depends_on_past': False,
    'start_date': datetime(2026,8,29),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1
}

dag = DAG(
    'reject_master_daily_update',
    default_args=default_args,
    description='DAG to update reject master daily',
    schedule="5 */6 * * *",
    catchup=False
)

def run_query(query,host=trino_host,port=trino_port,user=trino_user):
        conn = connect(
            host=f"{host}",
            port=port,
            user=f"{user}",
            )
        cur = conn.cursor()
        cur.execute(f"{query}")
       
        return {"success":1,"msg":""}

def return_max_key(query,host=trino_host,port=trino_port,user=trino_user):
    try:
        conn = connect(
            host=f"{host}",
            port=port,
            user=f"{user}",
            )
        cur = conn.cursor()
        row = cur.execute(f"{query}")
       
        return row.fetchall()
    except Exception as e:
        return str(e)

trino_dbs = ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f']

def main():
    max_keys=pd.DataFrame(return_max_key(f"select shard_hint,max({iceberg_incr_key}) from {trino_table_name}  group by 1 order by 1"),columns=['shard','max_key'])
    output=1
    select_query=""
    for db in trino_dbs:
        mysql_host=f'eid_reject_masterv2_0_{db}'
        print(mysql_host)
        max_i_key=max_keys.loc[max_keys.shard==str(db)]['max_key'].item()
        select_query=select_query+f"""select cast({iceberg_incr_key} as bigint) as eid_reject_key,eid,
    refid,
    CAST(eid_status_key AS INT) AS eid_status_key,
    res_dob_year,
    res_guardian_uid,
    res_guardian_eid,
    res_mobile_num_hash,
    res_email_id_hash,
    bnk_shre_cnsnt,
    info_shre_cnsnt,
    verification_type,
    poi,
    poa,
    pob,
    hof_proof,
    other_proof,
    res_lang_code,
    biometric_flag,
    biometric_exception,
    isnri,
    res_dod,
    CAST(reject_date AS TIMESTAMP) AS reject_date,
    created_by,
    CAST(creation_date AS TIMESTAMP) AS creation_date,
    last_updated_by,
    CAST(last_updated_date AS TIMESTAMP) AS last_updated_date,
    isforeigner,
    nationality_code,
    CAST(uid_expiry_date AS TIMESTAMP) AS uid_expiry_date,mobile_num_owner_uid,'{db}' as shard_hint
        from mysql_reject_master.{mysql_host}.eid_reject_master where {iceberg_incr_key}>{max_i_key} {"union " if db<'f' else ""}"""
    
            # print(i,max_i_key)
            # # res=run_query(insert_query)
            # print(res)
            # max_query=f"select max({iceberg_incr_key}) from {trino_table_name} where shard_hint='{i}'"
            # max_f_key=return_max_key(max_query)
            # print(f"rows_inserted:{max_f_key-max_i_key}")
        # print(select_query)
    merge_query=f"""MERGE INTO {trino_table_name} as hm USING ({select_query}) as uc
    on hm.shard_hint=uc.shard_hint and hm.eid_reject_key=uc.eid_reject_key
    WHEN MATCHED THEN UPDATE SET
    eid=uc.eid,refid=uc.refid,eid_status_key=uc.eid_status_key,res_dob_year=uc.res_dob_year,res_guardian_uid=uc.res_guardian_uid,
    res_guardian_eid=uc.res_guardian_eid ,res_mobile_num_hash=uc.res_mobile_num_hash,res_email_id_hash=uc.res_email_id_hash,
    bnk_shre_cnsnt=uc.bnk_shre_cnsnt,info_shre_cnsnt=uc.info_shre_cnsnt, verification_type=uc.verification_type,poi=uc.poi,poa=uc.poa
    ,pob=uc.pob,hof_proof=uc.hof_proof,other_proof=uc.other_proof,res_lang_code=uc.res_lang_code,biometric_flag=uc.biometric_flag,
    biometric_exception=uc.biometric_exception,isnri=uc.isnri,res_dod=uc.res_dod,reject_date=uc.reject_date,created_by=uc.created_by, 
    creation_date=uc.creation_date,last_updated_by=uc.last_updated_by,last_updated_date=uc.last_updated_date,isforeigner=uc.isforeigner,
    nationality_code=uc.nationality_code,uid_expiry_date=uc.uid_expiry_date,mobile_num_owner_uid=uc.mobile_num_owner_uid
    WHEN NOT MATCHED THEN INSERT 
(
    eid_reject_key, eid, refid, eid_status_key, res_dob_year, res_guardian_uid, res_guardian_eid, 
    res_mobile_num_hash, res_email_id_hash, bnk_shre_cnsnt, info_shre_cnsnt, verification_type, 
    poi, poa, pob, hof_proof, other_proof, res_lang_code, biometric_flag, biometric_exception, 
    isnri, res_dod, reject_date, created_by, creation_date, last_updated_by, last_updated_date, 
    isforeigner, nationality_code, uid_expiry_date, mobile_num_owner_uid, shard_hint
) 
VALUES
(
    uc.eid_reject_key, uc.eid, uc.refid, uc.eid_status_key, uc.res_dob_year, uc.res_guardian_uid, 
    uc.res_guardian_eid, uc.res_mobile_num_hash, uc.res_email_id_hash, uc.bnk_shre_cnsnt, 
    uc.info_shre_cnsnt, uc.verification_type, uc.poi, uc.poa, uc.pob, uc.hof_proof, uc.other_proof, 
    uc.res_lang_code, uc.biometric_flag, uc.biometric_exception, uc.isnri, uc.res_dod, uc.reject_date, 
    uc.created_by, uc.creation_date, uc.last_updated_by, uc.last_updated_date, uc.isforeigner, 
    uc.nationality_code, uc.uid_expiry_date, uc.mobile_num_owner_uid, uc.shard_hint
)"""
    print(merge_query)
    # print("--------------------------------------------------------")
    output=run_query(merge_query)
    # current_keys=pd.DataFrame(return_max_key(f"select shard_hint,max(uid_his_key) from {trino_table_name} group by 1 order by 1"),columns=['shard','current_max_key'])
    # logging.info(current_keys)
    if output['success']==1:
        return "successfully executed"
    else:
        return output['msg']


reject_master_upd = PythonOperator(
                task_id='merge_into_rm',
                python_callable=main,
                dag=dag,
            )



reject_master_upd
