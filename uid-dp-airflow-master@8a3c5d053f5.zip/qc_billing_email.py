import datetime
from trino.dbapi import connect
import subprocess
import sys
import json
import requests
import pandas as pd
import pytz
from airflow.sdk import DAG
from airflow.operators.python import PythonOperator


trino_host="10.10.116.75"
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="airflow_dag_op_email"
current_time=datetime.datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%d-%H-%M-%S')
rcs_host = '10.81.116.128'
rcs_port = '9090'

def number_to_ordinal(n):
    try:
        """Convert an integer to its ordinal representation (1st, 2nd, 3rd, etc.)."""
        if 11 <= (n % 100) <= 13:
            suffix = "th"
        else:
            suffixes = {1: "st", 2: "nd", 3: "rd"}
            suffix = suffixes.get(n % 10, "th")
        
        return f"{n}{suffix}"
    except Exception as e: 
        return n

    

def return_trino_res(query,host=trino_host,port=trino_port,user=trino_user):
    try:
        conn = connect(
            host=f"{host}",
            port=port,
            user=f"{user}",
            )
        cur = conn.cursor()
        row = cur.execute(f"{query}")

        return [i.name for i in cur.description], row.fetchall()
        # return row.fetchall()
    except Exception as e:
        return str(e)


def get_subject(error_code,error_number):
    # f = open("email_text/email_opt_warning_subject.txt","r")
    email_subject = "Aadhaar Enrolment/Update Operator Error/Violation - Case {error_code} {error_number}"
    email_subject = email_subject.replace("{error_code}",error_code)
    email_subject = email_subject.replace("{error_number}",error_number)
    # f.close()
    return email_subject



def send_email_warn(uid,opt_name,email,error_category,error_number,error_description,error_eid):
    email_subject = get_subject(error_category,number_to_ordinal(error_number))
    url = f'http://{rcs_host}:{rcs_port}/messageReceiver/v1'

    payload = json.dumps({
    "appName": "STROT",
    "idType": "uid",
    "residentId":uid,
    "email": email,
    "event": "STROT_OPT_ERROR_WARN",
    "channels": [
        {
            "channel": "EMAIL",
            "language": "english"
        }
    ],
     "additionalInfo": {
        "emailSubject": email_subject,
        "opt_ea_registrar_name": opt_name,
        "error_category": error_category,
        "error_description": error_description,
        "error_number": number_to_ordinal(error_number),
        "error_eid": error_eid
    }
    })
    headers = {'content-type': 'application/json', 'Accept-Charset': 'UTF-8'}
    r = requests.post(url, data=payload, headers=headers)
    return r,error_eid



def send_email_susp(uid,opt_name,email,error_category,error_number,error_description,error_eid):
    email_subject = get_subject(error_category,number_to_ordinal(error_number))
    url = f'http://{rcs_host}:{rcs_port}/messageReceiver/v1'

    payload = json.dumps({
    "appName": "STROT",
    "idType": "uid",
    "residentId":uid,
    "email": email,
    "event": "STROT_OPT_ERROR_SUSP",
    "channels": [
        {
            "channel": "EMAIL",
            "language": "english"
        }
    ],
     "additionalInfo": {
        "emailSubject": email_subject,
        "opt_ea_registrar_name": opt_name,
        "error_category": error_category,
        "error_description": error_description,
        "error_number": number_to_ordinal(error_number),
        "error_eid": error_eid
    }
    })
    headers = {'content-type': 'application/json', 'Accept-Charset': 'UTF-8'}
    r = requests.post(url, data=payload, headers=headers)
    return r,error_eid



def send_email(uid,opt_name,email,error_category,error_number,error_description,error_eid,notif_type):
    if(notif_type=='WARNING'):
        return send_email_warn(uid,opt_name,email,error_category,error_number,error_description,error_eid)
    elif(notif_type=='SUSPENSION'):
        return send_email_susp(uid,opt_name,email,error_category,error_number,error_description,error_eid)


def main():
    try:
        mails=0
        col,data = return_trino_res('''select * from strot.operator360.operator_error_notif where notif_sent = false and date(last_updated_at)=date(now()) limit 1000''')
        while data is not None:
            df = pd.DataFrame(data,columns=col)
            email_resp ={}
    
            for index,rows in df.iterrows() :
                res,eid = send_email(rows['opt_uid'],rows['opt_name'],rows['opt_email'],rows['error_category'],str(rows['error_count']),rows['error_description'],rows['error_eid'],rows['notif_type'])  
                if(res.status_code==200):
                    email_resp[eid] =res
                    print(eid,res.text)
                    mails+=1
                else:
                    print(eid,res.status_code)
            eids = list(email_resp.keys())
            str_eids = str(eids)
            update_db = f'update strot.operator360.operator_error_notif set notif_sent = true,last_updated_at = NOW() where error_eid in ({str_eids[1:-1]})'
            col,result = return_trino_res(update_db)
            col,data = return_trino_res('''select * from strot.operator360.operator_error_notif where notif_sent = false and month(created_at)=month(now()) limit 1000''')
    except Exception as e: 
        return f'{mails} mails sent'

default_args = {
    'owner': 'harsha',
    'depends_on_past': False,
    'start_date': datetime.datetime(2025, 6, 17),
    'email': ['techexecutive14-yp23@uidai.net.in'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 1
}

dag = DAG(
    'opt_error_notif_mail',
    default_args=default_args,
    description='DAG to send mails to operator',
    schedule="10 9 * * *",
    catchup=False
)


opt_error_notif_task = PythonOperator(
                task_id='trigger_mail',
                python_callable=main,
                trigger_rule='all_done',
                op_kwargs={},
                dag=dag,
            )

opt_error_notif_task
