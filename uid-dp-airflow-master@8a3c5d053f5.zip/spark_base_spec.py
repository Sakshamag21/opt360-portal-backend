# dags/spark_base_spec.py
# Reusable base spec — import this in all your DAGs

BASE_SPARK_SPEC = {
    "apiVersion": "sparkoperator.k8s.io/v1beta2",
    "kind": "SparkApplication",
    "metadata": {
        "namespace": "strot-spark",
    },
    "spec": {
        "type": "Python",
        "pythonVersion": "3",
        "mode": "cluster",
        # Kept the image as requested
        "image": "harbor-registry-prod.uidai.gov.in/data-platform/pyspark-duckdb-sqlmesh:4.0.2_0.235.4",
        "imagePullPolicy": "IfNotPresent",
        "sparkVersion": "4.0.2",
        "restartPolicy": {"type": "Never"},

        "deps": {
            "jars": [
                "local:///opt/spark/jars/hadoop-aws-3.4.1.jar",
                "local:///opt/spark/jars/iceberg-spark-runtime-4.0_2.13-1.10.1.jar",
                "s3a://prd-bi-data-platform-uploads/sparkjobs/mysql-connector-java-8.0.30.jar"
            ]
        },

        "hadoopConf": {
            "fs.s3a.endpoint": "http://10.10.103.12:425",
            "fs.s3a.access.key": "9S0KLIQO7T2XCNGH4P4A",
            "fs.s3a.secret.key": "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4",
            "fs.s3a.path.style.access": "true",
            "fs.s3a.connection.ssl.enabled": "false",
            "fs.s3a.impl": "org.apache.hadoop.fs.s3a.S3AFileSystem",
            "fs.s3a.aws.credentials.provider": "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider",
            "hadoop.security.authentication": "simple",
            "hadoop.security.authorization": "false",
        },

        "sparkConf": {
            "spark.serializer": "org.apache.spark.serializer.KryoSerializer",
            "spark.jars.ivy": "/tmp/.ivy2",
            # Exact extraClassPath from your working config
            "spark.driver.extraClassPath": "/opt/spark/jars/hadoop-aws-3.4.1.jar:/opt/spark/jars/iceberg-spark-runtime-4.0_2.13-1.10.1.jar",
            "spark.executor.extraClassPath": "/opt/spark/jars/hadoop-aws-3.4.1.jar:/opt/spark/jars/iceberg-spark-runtime-4.0_2.13-1.10.1.jar",
            "spark.jars": "local:///opt/spark/jars/hadoop-aws-3.4.1.jar,local:///opt/spark/jars/iceberg-spark-runtime-4.0_2.13-1.10.1.jar,s3a://prd-bi-data-platform-uploads/sparkjobs/mysql-connector-java-8.0.30.jar",
            
            "spark.driver.maxResultSize": "32g",
            "spark.kubernetes.driver.ownPersistentVolumeClaim": "true",
            "spark.kubernetes.driver.reusePersistentVolumeClaim": "true",
            "spark.kubernetes.local.dirs.tmpfs": "true",
            "spark.local.dir": "/data/temp",
            "spark.sql.warehouse.dir": "/data/sqlwarehouse",
            # CRITICAL: Shuffle and Ceph PVC configs from your working command
            "spark.shuffle.sort.io.plugin.class": "org.apache.spark.shuffle.KubernetesLocalDiskShuffleDataIO",
            "spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.options.claimName": "OnDemand",
            "spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.options.storageClass": "ceph-xfs",
            "spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.options.sizeLimit": "100Gi",
            "spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.mount.path": "/data",
            "spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.mount.readOnly": "false",
            # Iceberg
            "spark.sql.extensions": "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
            # Catalogs
            "spark.sql.catalog.strot": "org.apache.iceberg.spark.SparkCatalog",
            "spark.sql.catalog.strot.type": "hive",
            "spark.sql.catalog.strot.uri": "thrift://10.10.116.77:9083",
            "spark.sql.catalog.test_iceberg": "org.apache.iceberg.spark.SparkCatalog",
            "spark.sql.catalog.test_iceberg.type": "hive",
            "spark.sql.catalog.test_iceberg.uri": "thrift://10.10.112.24:32601",
            "spark.sql.catalog.flink_stream": "org.apache.iceberg.spark.SparkCatalog",
            "spark.sql.catalog.flink_stream.type": "hive",
            "spark.sql.catalog.flink_stream.uri": "thrift://10.10.112.24:32613",
            # Security
            "spark.hadoop.hadoop.security.authentication": "simple",
            "spark.hadoop.hadoop.security.authorization": "false",
        },

        "volumes": [
            {
                "name": "kubeconfig-volume",
                "configMap": {"name": "kubeconfig-hdc-dp"}
            }
        ],

        "driver": {
            "cores": 8,               # Updated from 2 to 8
            "coreLimit": "8",         # Updated from 2 to 8
            "memory": "32g",          # Updated from 4g to 32g
            "memoryOverhead": "32g",  # Added
            "serviceAccount": "strot-service-account",
            "tolerations": [
                {"key": "strot", "operator": "Equal", "value": "true", "effect": "NoSchedule"}
            ],
            "javaOptions": "-XX:+UseG1GC",
            "volumeMounts": [
                {
                    "name": "kubeconfig-volume",
                    "mountPath": "/opt/spark/conf/kubeconfig-hdc-dp",
                    "subPath": "kubeconfig-hdc-dp"
                }
            ],
            "env": [
                {"name": "KUBECONFIG", "value": "/opt/spark/conf/kubeconfig-hdc-dp"},
                {"name": "HOME", "value": "/opt/spark/work-dir"},
                # Added from your raw config
                {"name": "KUBERNETES_SERVICE_HOST", "value": "10.10.102.220"},
                {"name": "KUBERNETES_SERVICE_PORT", "value": "443"},
                {"name": "SPARK_LOCAL_DIRS", "value": "/tmp"}
            ],
        },

        "executor": {
            "cores": 16,              # Updated from 4 to 16
            "coreLimit": "16",        # Updated from 4 to 16
            "memory": "128g",         # Updated from 8g to 128g
            "memoryOverhead": "128g", # Added
            "instances": 8,           # Set default instances to 8 based on raw config
            "tolerations": [
                {"key": "strot", "operator": "Equal", "value": "true", "effect": "NoSchedule"}
            ],
            "javaOptions": "-XX:+UseG1GC",
            "volumeMounts": [
                {
                    "name": "kubeconfig-volume",
                    "mountPath": "/opt/spark/conf/kubeconfig-hdc-dp",
                    "subPath": "kubeconfig-hdc-dp"
                }
            ],
            "env": [
                {"name": "HOME", "value": "/opt/spark/work-dir"},
                # Added from your raw config
                {"name": "KUBERNETES_SERVICE_HOST", "value": "10.10.102.220"},
                {"name": "KUBERNETES_SERVICE_PORT", "value": "443"},
                {"name": "SPARK_LOCAL_DIRS", "value": "/tmp"}
            ],
        },
    },
}


def make_spark_spec(
    job_name: str,
    script_path: str,
    driver_cores: int = 8,
    driver_memory: str = "32g",
    executor_cores: int = 16,
    executor_memory: str = "128g",
    executor_instances: int = 8,
    max_executors: int = None,
    dynamic_allocation: bool = False,
    extra_spark_conf: dict = None,
    arguments: list = None,
) -> dict:
    """
    Build a per-job SparkApplication spec from the base template.
    Override any resource/config per job. Defaults updated to match heavy migration job.
    """
    import copy
    spec = copy.deepcopy(BASE_SPARK_SPEC)

    spec["metadata"]["name"] = job_name
    spec["spec"]["mainApplicationFile"] = script_path

    # Driver overrides
    spec["spec"]["driver"]["cores"] = driver_cores
    spec["spec"]["driver"]["coreLimit"] = str(driver_cores)
    spec["spec"]["driver"]["memory"] = driver_memory

    # Executor overrides
    spec["spec"]["executor"]["cores"] = executor_cores
    spec["spec"]["executor"]["coreLimit"] = str(executor_cores)
    spec["spec"]["executor"]["memory"] = executor_memory

    if dynamic_allocation:
        spec["spec"]["sparkConf"]["spark.dynamicAllocation.enabled"] = "true"
        spec["spec"]["sparkConf"]["spark.dynamicAllocation.minExecutors"] = "1"
        spec["spec"]["sparkConf"]["spark.dynamicAllocation.maxExecutors"] = str(max_executors or 10)
        spec["spec"]["sparkConf"]["spark.dynamicAllocation.shuffleTracking.enabled"] = "true"
        # Remove static instances if dynamic allocation is used
        spec["spec"]["executor"].pop("instances", None)
    else:
        spec["spec"]["executor"]["instances"] = executor_instances

    # Any extra spark confs per job
    if extra_spark_conf:
        spec["spec"]["sparkConf"].update(extra_spark_conf)

    if arguments:
        spec["spec"]["arguments"] = arguments

    return spec