from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from datetime import datetime
import textwrap
from kubernetes.client import models as k8s

# This is the bash script that will run inside the Pod.
# It downloads the python files from S3, then executes main.py
BASH_COMMAND = textwrap.dedent("""
    set -e  # Exit immediately if a command fails
    # export PIP_TARGET="/tmp/pip_libs"
    # export PYTHONPATH="$PIP_TARGET:$PYTHONPATH"
    # mkdir -p $PIP_TARGET
    
    # # Install required packages (boto3, pytz, etc.) if they aren't already in the image
    # echo "Installing required packages..."
    # pip install --target=$PIP_TARGET --index-url http://10.10.206.59:8080/repository/pypi-proxy/simple --trusted-host 10.10.206.59 boto3==1.34.41 pytz==2026.2
    
    echo "Starting S3 sync process..."
    python3 -c "
    import os
    import boto3

    s3_bucket = os.environ.get('S3_BUCKET')
    s3_prefix = os.environ.get('S3_PREFIX', 'r360_ot_pipeline/')
    local_dir = '/tmp/r360_ot_project'

    os.makedirs(local_dir, exist_ok=True)

    s3 = boto3.client(
                  's3',
                  endpoint_url='http://10.10.103.12:425',
                  aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',
                  aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4'
              )
    paginator = s3.get_paginator('list_objects_v2')
    
    print(f'Downloading from s3://{s3_bucket}/{s3_prefix} to {local_dir}')
    
    for page in paginator.paginate(Bucket=s3_bucket, Prefix=s3_prefix):
        for obj in page.get('Contents', []):
            key = obj['Key']
            # Skip folder placeholders
            if key.endswith('/'):
                continue
                
            # Calculate local file path
            relative_path = key[len(s3_prefix):]
            local_file_path = os.path.join(local_dir, relative_path)
            
            # Create subdirectories if they don't exist
            os.makedirs(os.path.dirname(local_file_path), exist_ok=True)
            
            print(f'Downloading {key}...')
            s3.download_file(s3_bucket, key, local_file_path)
            
    print('S3 sync complete.')
    "
    
    echo "Navigating to R360 project directory..."
    cd /tmp/r360_ot_project
    
    echo "Running main.py..."
    # main.py's run_all_tasks() function will automatically loop through 
    # the 3 sources sequentially and continue even if one fails.
    python3 main.py
    
    echo "R360 pipeline run completed!"
""")

custom_toleration = k8s.V1Toleration(
    key="strot",
    operator='Equal',
    value='true',
    effect='NoSchedule'
)

with DAG(
    dag_id="Resident360_Origin_Tracker_Pipeline",
    schedule="0 */3 * * *",
    start_date=datetime(2026, 8, 24),
    catchup=False,
    max_active_runs=1,
    tags=["Resident360", "Origin_Tracker"],
) as dag:

    run_r360_from_s3 = KubernetesPodOperator(
        task_id="run_r360_ot_merge_from_s3",
        image="hbdc-harbor-registry-prod.uidai.net.in/data-platform/pyspark-duckdb-sqlmesh:4.0.2_0.235.4_2",
        cmds=["bash", "-c"],
        arguments=[BASH_COMMAND],
        namespace="strot-spark",
        get_logs=True,
        tolerations=[custom_toleration],
        env_vars={
            "S3_BUCKET": "prd-bi-data-platform-feature-resident360-00",
            "S3_PREFIX": "r360_ot_pipeline/",
            "SPARK_REMOTE": "sc://spark-connect-service.data-platform.svc.cluster.local:15002"
        },
        container_resources=k8s.V1ResourceRequirements(
            requests={"cpu": "16000m", "memory": "64Gi"},
            limits={"cpu": "16000m", "memory": "64Gi"},
        ),
        service_account_name='strot-service-account',
        config_file="/opt/airflow/dags/gpu_kubeconfig_hdc", 
        in_cluster=False,
        log_events_on_failure=True,
        is_delete_operator_pod = False,
    )