from __future__ import annotations
import heapq
import polars as pl
import pandas as pd
import numpy as np
import strot_query as sq
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import to_rgb
import os
import zipfile
import logging
import openpyxl
from openpyxl.drawing.image import Image as OpenpyxlImage
from openpyxl.styles import Font, Alignment
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from airflow import DAG
from airflow.operators.python import PythonOperator

# Set styling for charts
sns.set_theme(style="whitegrid")

# --------------------------------------------------------------------------
# SMTP EMAIL CONFIGURATION
# --------------------------------------------------------------------------
SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25
SENDER_EMAIL = "airflow@uidai.net.in"

def send_email_via_smtp(to_email, cc_emails, subject, html_body, zip_bytes=None, zip_filename=None):
    """Constructs and sends an email with an optional ZIP attachment via SMTP."""
    msg = MIMEMultipart()
    msg['From'] = SENDER_EMAIL
    msg['To'] = to_email
    
    if cc_emails:
        msg['Cc'] = cc_emails
        
    msg['Subject'] = subject
    msg.attach(MIMEText(html_body, 'html'))
    
    if zip_bytes and zip_filename:
        part = MIMEApplication(zip_bytes, Name=zip_filename)
        part['Content-Disposition'] = f'attachment; filename="{zip_filename}"'
        msg.attach(part)
        
    recipients = [to_email]
    if cc_emails:
        recipients.extend([e.strip() for e in cc_emails.split(',') if e.strip()])
        
    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(SENDER_EMAIL, recipients, msg.as_string())
        server.quit()
        print(f"✅ Email successfully sent to {to_email} via SMTP!")
    except Exception as e:
        print(f"❌ SMTP Error sending to {to_email}: {str(e)}")

# --------------------------------------------------------------------------
# 1. Extract Data (Optimized SQL to prevent Trino timeouts)
# --------------------------------------------------------------------------
EXTRACT_SQL = """
WITH valid_events AS (
    SELECT
        machine_code, sid, operator_id, stage, stage_status_date
    FROM flink_stream.stream_uc.request_tracker_cdc_v1
    WHERE last_updated_date >= TIMESTAMP '{start}'
      AND last_updated_date < TIMESTAMP '{end}'
      AND sid IS NOT NULL
      AND machine_code IS NOT NULL
      AND stage_status_date IS NOT NULL
      AND stage NOT IN ('EnS', 'UPC_PUBLISHED', 'Payment')
),
sid_ips AS (
    SELECT
        resident_sid,
        MAX(machine_ip_address) AS ip_address
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE event_timestamp >= TIMESTAMP '{start}'
      AND event_timestamp < TIMESTAMP '{end}'
      AND resident_sid IS NOT NULL
      AND machine_ip_address IS NOT NULL
      AND machine_ip_address != ''
    GROUP BY resident_sid
)
SELECT
    v.machine_code,
    v.sid,
    MAX(v.operator_id) AS operator_id,
    MIN(CASE WHEN v.stage = 'SRNGeneration' THEN v.stage_status_date END) AS start_ts,
    MAX(CASE WHEN v.stage IN ('ACKSLIP_UPLOAD') THEN v.stage_status_date END) AS end_ts,
    MAX_BY(v.stage, v.stage_status_date) AS last_stage,
    MAX(s.ip_address) AS ip_address
FROM valid_events v
LEFT JOIN sid_ips s ON v.sid = s.resident_sid
GROUP BY v.machine_code, v.sid
HAVING MIN(CASE WHEN v.stage = 'SRNGeneration' THEN v.stage_status_date END) IS NOT NULL
   AND MAX(CASE WHEN v.stage IN ('ACKSLIP_UPLOAD') THEN v.stage_status_date END) IS NOT NULL
"""

def load(start: str, end: str) -> pl.DataFrame:
    pdf = sq.query(EXTRACT_SQL.format(start=start, end=end))
    if 'df' not in pdf or pdf.get('success') == 0:
        error_msg = pdf.get('msg', 'Unknown Trino error')
        print(f"❌ Trino Query Failed! Error: {error_msg}")
        raise RuntimeError("Failed to fetch data from Trino.")
    pdf = pdf['df']
    df = pl.from_pandas(pdf)
    df = df.with_columns([
        pl.col("start_ts").cast(pl.Datetime("us")),
        pl.col("end_ts").cast(pl.Datetime("us"))
    ])
    df = df.filter(pl.col("start_ts") <= pl.col("end_ts"))
    return df

# --------------------------------------------------------------------------
# 2. Optimized Two-Pass Engine + Decision Tree
# --------------------------------------------------------------------------
def find_grouped_overlaps(df: pl.DataFrame, group_col: str) -> pl.DataFrame:
    df_sorted = df.sort([group_col, "start_ts"])
    cols = ["machine_code", "sid", "operator_id", "start_ts", "end_ts", "ip_address"]
    if group_col not in cols:
        cols.append(group_col)
    group_idx = cols.index(group_col)
    rows = df_sorted.select(cols).iter_rows()
    out = []
    active = []
    current_group = None
    for row in rows:
        machine = row[0]
        sid = row[1]
        op_id = row[2]
        start = row[3]
        end = row[4]
        ip = row[5]
        group_val = row[group_idx]
        if group_val != current_group:
            active.clear()
            current_group = group_val
        while active and active[0][0] < start:
            heapq.heappop(active)
        for a_end, a_sid, a_op, a_start, a_machine, a_ip in active:
            out.append((
                a_sid, a_op, a_machine, a_ip, a_start, a_end,
                sid, op_id, machine, ip, start, end
            ))
        heapq.heappush(active, (end, sid, op_id, start, machine, ip))
    return pl.DataFrame(out, schema={
        "sid_1": pl.Utf8, "op_1": pl.Utf8, "machine_1": pl.Utf8, "ip_1": pl.Utf8,
        "start_1": pl.Datetime("us"), "end_1": pl.Datetime("us"),
        "sid_2": pl.Utf8, "op_2": pl.Utf8, "machine_2": pl.Utf8, "ip_2": pl.Utf8,
        "start_2": pl.Datetime("us"), "end_2": pl.Datetime("us")
    }, orient="row")

# Helper function for Pseudo-3D Bars
def plot_3d_bars(ax, labels, values, highlight_max=False, rainbow=False):
    x = np.arange(len(labels))
    if rainbow:
        colors = plt.cm.viridis(np.linspace(0, 1, len(labels)))
    else:
        colors = ['#003366'] * len(labels)
    max_val = max(values) if len(values) > 0 else 0
    for i in range(len(labels)):
        c = colors[i]
        if highlight_max and values[i] == max_val and not rainbow:
            c = 'red'
        ax.bar(x[i], values[i], color=c, width=0.6, zorder=2)
        depth_x = 0.2
        depth_y = max_val * 0.02 if max_val > 0 else 1
        top_x = [x[i]-0.3, x[i]-0.3+depth_x, x[i]+0.3+depth_x, x[i]+0.3]
        top_y = [values[i], values[i]+depth_y, values[i]+depth_y, values[i]]
        ax.fill(top_x, top_y, color=c, zorder=3)
        side_x = [x[i]+0.3, x[i]+0.3+depth_x, x[i]+0.3+depth_x, x[i]+0.3]
        side_y = [0, depth_y, values[i]+depth_y, values[i]]
        rgb = to_rgb(c)
        dark_c = (rgb[0]*0.6, rgb[1]*0.6, rgb[2]*0.6)
        ax.fill(side_x, side_y, color=dark_c, zorder=1)
        offset = max_val * 0.05 if max_val > 0 else 1
        if highlight_max and values[i] == max_val and not rainbow:
            ax.annotate(f'{int(values[i])}', xy=(x[i]+depth_x/2, values[i]+depth_y), xytext=(x[i]+depth_x/2, values[i]+depth_y+offset*2),
                        ha='center', fontsize=9, color='red', fontweight='bold',
                        bbox=dict(boxstyle='round,pad=0.3', fc='white', ec='red'))
        else:
            ax.text(x[i]+depth_x/2, values[i]+depth_y+offset, str(int(values[i])),
                    ha='center', va='bottom', fontsize=9,
                    bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='gray', alpha=0.9))

# --------------------------------------------------------------------------
# 3. Main Airflow Callable
# --------------------------------------------------------------------------
def execute_overlap_analysis(**kwargs):
    pl.Config.set_fmt_str_lengths(300)
    pl.Config.set_tbl_cols(20)
    pl.Config.set_tbl_width_chars(400)

    today = datetime.now()
    yesterday = today - timedelta(days=1)
    start_str = yesterday.strftime("%Y-%m-%d 00:00:00")
    end_str = yesterday.strftime("%Y-%m-%d 23:59:00")
    date_suffix = yesterday.strftime("%d/%m/%y")
    file_suffix = yesterday.strftime("%d_%m_%y")

    # Airflow workers restrict folder creation, so we save to /tmp/
    output_dir = "/tmp"
    print(f"All reports and charts will be saved locally to: {output_dir}")

    print(f"Querying data from {start_str} to {end_str}...")
    intervals = load(start_str, end_str)
    print(f"{intervals.height:,} true intervals loaded (Exact timestamps, no buffer)\n")

    print("Running Optimized Two-Pass Engine...")
    print("Pass 1: Checking Same Operator...")
    op_overlaps = find_grouped_overlaps(intervals, "operator_id")
    print("Pass 2: Checking Same Machine...")
    mach_overlaps = find_grouped_overlaps(intervals, "machine_code")

    print("Combining results and applying logic...\n")
    pairs = pl.concat([op_overlaps, mach_overlaps]).unique()
    pairs = pairs.with_columns([
        pl.col("sid_1").cast(pl.Utf8),
        pl.col("sid_2").cast(pl.Utf8)
    ])
    pairs = pairs.with_columns([
        pl.when((pl.col("op_1") == pl.col("op_2")) & (pl.col("machine_1") == pl.col("machine_2")))
        .then(pl.lit("Fraud (Same Op, Same Machine)"))
        .when((pl.col("op_1") == pl.col("op_2")) & (pl.col("machine_1") != pl.col("machine_2")))
        .then(pl.lit("Fraud (Same Op, Diff Machine)"))
        .when((pl.col("op_1") != pl.col("op_2")) & (pl.col("machine_1") == pl.col("machine_2")))
        .then(pl.lit("Fraud (Diff Op, Same Machine)"))
        .otherwise(pl.lit("Not Fraud (Diff Op, Diff Machine)"))
        .alias("fraud_status"),
        pl.when(pl.col("ip_1") == pl.col("ip_2"))
        .then(pl.lit("Same IP"))
        .otherwise(pl.lit("Diff IP"))
        .alias("ip_status")
    ])
    pairs = pairs.with_columns(
        (pl.col("fraud_status") + " | " + pl.col("ip_status")).alias("Fraud_Analysis")
    )
    pairs = pairs.rename({
        "machine_1": "machine_code", "op_1": "operator_id_1",
        "start_1": "sid_1_start", "end_1": "sid_1_end",
        "machine_2": "machine_code_2", "op_2": "operator_id_2",
        "start_2": "sid_2_start", "end_2": "sid_2_end"
    })
    pairs = pairs.with_columns([
        pl.max_horizontal(["sid_1_start", "sid_2_start"]).alias("overlap_start"),
        pl.min_horizontal(["sid_1_end", "sid_2_end"]).alias("overlap_end")
    ])
    last_stages = intervals.select(["sid", "last_stage"]).rename({"sid": "sid_1", "last_stage": "last_stage_1"})
    pairs = pairs.join(last_stages, on="sid_1", how="left")
    last_stages = last_stages.rename({"sid_1": "sid_2", "last_stage_1": "last_stage_2"})
    pairs = pairs.join(last_stages, on="sid_2", how="left")

    mail_list = ["hoe.dev-tc@uidai.net.in"]
    cc = "techexe1.yp26@uidai.net.in,techexecutive22-yp23@uidai.net.in,srconstds.prod-tc@uidai.net.in,data.analyst-tc@uidai.net.in,platfm.arch1-tc@uidai.net.in,productmgr4-tc@uidai.net.in"
    
    if pairs.height == 0:
        print("No overlapping pairs found. System is perfectly healthy!")
        healthy_html = f"""
        <p>This is to inform you that <b>no parallel session overlaps were found</b> in the UC Parallel Session Overlap Analysis for <b>{date_suffix}</b>.</p>
        <p>Total enrolment intervals analyzed: {intervals.height:,}<br>
        Overlapping pairs detected: 0</p>
        <p>No further action is required.</p>
        """
        for email in mail_list:
            send_email_via_smtp(
                to_email=email,
                cc_emails=cc,
                subject=f"Parallel Session Overlap Analysis Report - {date_suffix}",
                html_body=healthy_html
            )
    else:
        print(f"{pairs.height:,} total overlapping pairs found.\n")

        # ==================================================================
        # FETCH RAW EVENTS FOR OVERLAPPING SIDS (For Sheet 2 & Stage Check)
        # ==================================================================
        print("Fetching raw events for overlapping SIDs to determine exact stages...")
        all_sids_1 = pairs.select(pl.col("sid_1")).unique().to_series().to_list()
        all_sids_2 = pairs.select(pl.col("sid_2")).unique().to_series().to_list()
        all_unique_sids = list(set(all_sids_1 + all_sids_2))
        sids_sql_list = ", ".join([f"'{s}'" for s in all_unique_sids])
        sessions_sql = f"""
        SELECT
            sid, mode, stage, stage_status_date, operator_id, machine_code, station_id, agency_code, registrar_id
        FROM flink_stream.stream_uc.request_tracker_cdc_v1
        WHERE sid IN ({sids_sql_list})
          AND stage_status_date IS NOT NULL
        ORDER BY sid, stage_status_date ASC
        """
        sessions_result = sq.query(sessions_sql)
        raw_sessions_df = pl.from_pandas(sessions_result['df']) if 'df' in sessions_result and not sessions_result['df'].empty else pl.DataFrame()

        raw_sessions_df = raw_sessions_df.with_columns(
            pl.col("stage_status_date").cast(pl.Datetime("us"))
        )

        # ==================================================================
        # ASOF JOIN: FIND EXACT STAGE AT OVERLAP START
        # ==================================================================
        if not raw_sessions_df.is_empty():
            raw_stages_1 = raw_sessions_df.select([
                pl.col("sid").alias("sid_1"),
                pl.col("stage_status_date").alias("event_ts_1"),
                pl.col("stage").alias("stage_at_overlap_1")
            ]).sort("event_ts_1")

            pairs = pairs.sort("overlap_start").join_asof(
                raw_stages_1,
                left_on="overlap_start",
                right_on="event_ts_1",
                by="sid_1",
                strategy="backward"
            )

            raw_stages_2 = raw_sessions_df.select([
                pl.col("sid").alias("sid_2"),
                pl.col("stage_status_date").alias("event_ts_2"),
                pl.col("stage").alias("stage_at_overlap_2")
            ]).sort("event_ts_2")

            pairs = pairs.sort("overlap_start").join_asof(
                raw_stages_2,
                left_on="overlap_start",
                right_on="event_ts_2",
                by="sid_2",
                strategy="backward"
            )
        else:
            pairs = pairs.with_columns([
                pl.lit(None).alias("stage_at_overlap_1"),
                pl.lit(None).alias("stage_at_overlap_2")
            ])

        # ==================================================================
        # TOP LEVEL METRICS
        # ==================================================================
        unique_overlap_sids = pl.concat([
            pairs.select(pl.col("sid_1").alias("sid")),
            pairs.select(pl.col("sid_2").alias("sid"))
        ]).n_unique()
        total_intervals = intervals.height
        total_pairs = pairs.height
        sid_overlap_pct = (unique_overlap_sids / total_intervals) * 100
        pairs_pct = (total_pairs / total_intervals) * 100
        print(f"Total Unique SIDs involved in overlaps: {unique_overlap_sids:,} ({sid_overlap_pct:.2f}% of total intervals)")
        print(f"Percentage of overlapping pairs vs total intervals: {pairs_pct:.2f}%\n")

        # ==================================================================
        # ENRICH DATA
        # ==================================================================
        enriched_pairs = pairs.with_columns([
            pl.col("overlap_start").dt.date().alias("overlap_date"),
            (pl.col("overlap_end") - pl.col("overlap_start")).dt.total_seconds().alias("overlap_duration_secs"),
            (pl.col("sid_1_end") - pl.col("sid_1_start")).dt.total_seconds().alias("sid_1_total_duration_secs"),
            (pl.col("sid_2_end") - pl.col("sid_2_start")).dt.total_seconds().alias("sid_2_total_duration_secs")
        ])
        enriched_pairs = enriched_pairs.with_columns(
            pl.when((pl.col("last_stage_1") == "ACKSLIP_UPLOAD") & (pl.col("last_stage_2") == "ACKSLIP_UPLOAD"))
            .then(pl.lit("Both ACKSLIP (Fraud)"))
            .when((pl.col("last_stage_1") == "ACKSLIP_UPLOAD") | (pl.col("last_stage_2") == "ACKSLIP_UPLOAD"))
            .then(pl.lit("One ACKSLIP"))
            .otherwise(pl.lit("Other Stages"))
            .alias("fraud_category")
        )

        # ==================================================================
        # REPORT 2: DETAILED MASTER TABLE
        # ==================================================================
        print("========================================")
        print("         2. DETAILED OVERLAPS")
        print("========================================")
        detailed_view = enriched_pairs.select([
            "overlap_date", "machine_code", "machine_code_2",
            "operator_id_1", "sid_1", "sid_1_start", "sid_1_end", "last_stage_1", "stage_at_overlap_1", "ip_1", "sid_1_total_duration_secs",
            "operator_id_2", "sid_2", "sid_2_start", "sid_2_end", "last_stage_2", "stage_at_overlap_2", "ip_2", "sid_2_total_duration_secs",
            "overlap_start", "overlap_end", "overlap_duration_secs", "fraud_category", "Fraud_Analysis"
        ]).sort("overlap_duration_secs", descending=True)
        print(detailed_view.head(20).to_pandas().to_string())

        # ==================================================================
        # REPORT 4: MACHINE DETAILS WITH OVERLAPS & COUNTS
        # ==================================================================
        print("\n========================================")
        print("    4. MACHINE DETAILS WITH OVERLAPS & COUNTS")
        print("========================================")
        machine_overlap_counts = enriched_pairs.group_by("machine_code").agg(
            pl.col("sid_1").count().alias("total_overlapping_sessions")
        ).sort("total_overlapping_sessions", descending=True)
        unique_machines = machine_overlap_counts["machine_code"].to_list()
        if len(unique_machines) > 0:
            machines_sql_list = ", ".join([f"'{m}'" for m in unique_machines])
            machine_details_sql = f"""
            SELECT
                r.machine_code, MAX(r.station_id) AS station_id, MAX(r.agency_code) AS agency_code, MAX(r.registrar_id) AS registrar_id,
                MAX(e.pincode) AS pin_number, MAX(e.state) AS state, MAX(e.ro) AS ro
            FROM flink_stream.stream_uc.request_tracker_cdc_v1 r
            LEFT JOIN (
                SELECT DISTINCT station_machine_code, pincode, state, ro
                FROM flink_stream.stream_enu.enu_uc_opt_action_v2
                WHERE station_machine_code IS NOT NULL AND pincode IS NOT NULL
            ) e ON r.machine_code = e.station_machine_code
            WHERE r.machine_code IN ({machines_sql_list})
              AND r.last_updated_date >= TIMESTAMP '{start_str}'
              AND r.last_updated_date < TIMESTAMP '{end_str}'
            GROUP BY r.machine_code
            """
            print("Fetching machine details from Trino...")
            details_result = sq.query(machine_details_sql)
            if 'df' in details_result:
                machine_details_df = pl.from_pandas(details_result['df'])
                final_machines_df = machine_overlap_counts.join(machine_details_df, on="machine_code", how="left")
                final_machines_df = final_machines_df.select([
                    "machine_code", "station_id", "agency_code", "registrar_id",
                    "pin_number", "state", "ro", "total_overlapping_sessions"
                ])
                print(final_machines_df.head(20).to_pandas().to_string())
            else:
                print("Error fetching machine details:", details_result)
                final_machines_df = machine_overlap_counts
        else:
            print("No machines with overlaps found.")
            final_machines_df = machine_overlap_counts

        # ==================================================================
        # VISUALIZATIONS & EXCEL EXPORT (CHARTS)
        # ==================================================================
        print("\n========================================")
        print("          GENERATING CHARTS & EXCEL REPORT")
        print("========================================")
        durations_pd = enriched_pairs.select("overlap_duration_secs").to_pandas()
        if "ro" not in final_machines_df.columns:
            final_machines_df = final_machines_df.with_columns([
                pl.lit(None).alias("ro"),
                pl.lit(None).alias("state")
            ])
        ro_data = final_machines_df.filter(pl.col("ro").is_not_null()).group_by("ro").agg(
            pl.col("total_overlapping_sessions").sum().alias("total_overlaps")
        ).sort("total_overlaps", descending=False).to_pandas()
        time_trend = enriched_pairs.group_by("overlap_date").agg(
            pl.col("sid_1").count().alias("overlaps_per_day")
        ).sort("overlap_date").to_pandas()
        time_trend['overlap_date'] = pd.to_datetime(time_trend['overlap_date'])
        full_dates = pd.date_range(start=start_str.split()[0], end=end_str.split()[0], freq='D')
        time_trend = time_trend.set_index('overlap_date').reindex(full_dates, fill_value=0).reset_index()
        time_trend.columns = ['overlap_date', 'overlaps_per_day']
        state_data = final_machines_df.filter(pl.col("state").is_not_null()).group_by("state").agg(
            pl.col("total_overlapping_sessions").sum().alias("total_overlaps")
        ).sort("total_overlaps", descending=False).to_pandas()
        ops_1_df = enriched_pairs.select(["operator_id_1", "sid_1"]).rename({"operator_id_1": "operator_id", "sid_1": "sid"})
        ops_2_df = enriched_pairs.select(["operator_id_2", "sid_2"]).rename({"operator_id_2": "operator_id", "sid_2": "sid"})
        top_operators = pl.concat([ops_1_df, ops_2_df]).group_by("operator_id").agg(
            pl.col("sid").count().alias("total_overlaps")
        ).sort("total_overlaps", descending=True).head(15).to_pandas()
        top_machines = machine_overlap_counts.head(15).to_pandas()

        # --- CHART 1: Duration Histogram ---
        fig, ax = plt.subplots(figsize=(10, 5))
        ax.set_facecolor('#f0f0f0')
        fig.patch.set_facecolor('#f0f0f0')
        ax.hist(durations_pd['overlap_duration_secs'], bins=30, color='#DDA0DD', edgecolor='black')
        sns.kdeplot(data=durations_pd, x='overlap_duration_secs', color='darkviolet', linewidth=3, ax=ax)
        ax.set_title('Distribution of Overlap Durations (in seconds)', fontsize=14)
        ax.set_xlabel('Overlap Duration (Seconds)', fontsize=12)
        ax.set_ylabel('Frequency', fontsize=12)
        ax.set_ylim(bottom=0)
        plt.tight_layout()
        c1_name = f"{output_dir}/1_duration_distribution_{file_suffix}.png"
        plt.savefig(c1_name, dpi=150, facecolor=fig.get_facecolor())
        plt.close()
        print(f"✅ Saved: {c1_name}")

        # --- CHART 2: RO wise Overlap Session ---
        fig, ax = plt.subplots(figsize=(12, 6))
        ax.set_facecolor('#f0f0f0')
        fig.patch.set_facecolor('#f0f0f0')
        plot_3d_bars(ax, ro_data['ro'].tolist(), ro_data['total_overlaps'].tolist(), highlight_max=True)
        ax.set_title('RO wise overlap session', fontsize=14)
        ax.set_xlabel('RO', fontsize=12)
        ax.set_ylabel('Total_overlap', fontsize=12)
        ax.set_xticks(np.arange(len(ro_data)))
        ax.set_xticklabels(ro_data['ro'], rotation=45, ha='right')
        ax.set_ylim(0, max(ro_data['total_overlaps']) * 1.2 if not ro_data.empty else 10)
        plt.tight_layout()
        c2_name = f"{output_dir}/2_ro_wise_{file_suffix}.png"
        plt.savefig(c2_name, dpi=150, facecolor=fig.get_facecolor())
        plt.close()
        print(f"✅ Saved: {c2_name}")

        # --- CHART 3: Overlaps Trend Over Time ---
        fig, ax = plt.subplots(figsize=(12, 6))
        fig.patch.set_facecolor('darkblue')
        ax.set_facecolor('darkblue')
        ax.plot(time_trend['overlap_date'], time_trend['overlaps_per_day'], color='white', linewidth=3, marker='o')
        max_y = time_trend['overlaps_per_day'].max() if not time_trend.empty else 10
        for x, y in zip(time_trend['overlap_date'], time_trend['overlaps_per_day']):
            ax.vlines(x, 0, y, color='white', linestyle='--', alpha=0.5)
            callout_color = 'red' if y == max_y else 'white'
            text_color = 'black' if y == max_y else 'black'
            ax.text(x, y + max_y*0.05, str(y), color=text_color, ha='center', fontsize=9,
                    bbox=dict(boxstyle='round,pad=0.3', fc=callout_color, ec='none'))
        ax.tick_params(colors='white')
        for spine in ax.spines.values():
            spine.set_color('white')
        ax.set_title('OVERLAPS_TRENDS OVER TIME', color='white', fontsize=14)
        ax.set_xlabel('Overlap_Date', color='white', fontsize=12)
        ax.set_ylabel('Total_overlaps', color='white', fontsize=12)
        ax.set_ylim(0, max_y * 1.2 if not time_trend.empty else 10)
        plt.xticks(rotation=45)
        plt.tight_layout()
        c3_name = f"{output_dir}/3_trend_over_time_{file_suffix}.png"
        plt.savefig(c3_name, dpi=150, facecolor=fig.get_facecolor())
        plt.close()
        print(f"✅ Saved: {c3_name}")

        # --- CHART 4: State wise Overlap Session ---
        fig, ax = plt.subplots(figsize=(14, 6))
        ax.set_facecolor('#f0f0f0')
        fig.patch.set_facecolor('#f0f0f0')
        plot_3d_bars(ax, state_data['state'].tolist(), state_data['total_overlaps'].tolist(), highlight_max=True)
        ax.set_title('State wise overlap seesion', fontsize=14)
        ax.set_xlabel('State', fontsize=12)
        ax.set_ylabel('Total_overlap', fontsize=12)
        ax.set_xticks(np.arange(len(state_data)))
        ax.set_xticklabels(state_data['state'], rotation=45, ha='right')
        ax.set_ylim(0, max(state_data['total_overlaps']) * 1.2 if not state_data.empty else 10)
        plt.tight_layout()
        c4_name = f"{output_dir}/4_state_wise_{file_suffix}.png"
        plt.savefig(c4_name, dpi=150, facecolor=fig.get_facecolor())
        plt.close()
        print(f"✅ Saved: {c4_name}")

        # --- CHART 5: Operators Rainbow Staircase ---
        fig, ax = plt.subplots(figsize=(14, 6))
        fig.patch.set_facecolor('#333333')
        ax.set_facecolor('#333333')
        plot_3d_bars(ax, top_operators['operator_id'].tolist(), top_operators['total_overlaps'].tolist(), rainbow=True)
        ax.set_title('OPERATORS WITH TOTAL_OVERLAPPING_SESSIONS', color='white', fontsize=14)
        ax.set_xlabel('Operator_ID', color='white', fontsize=12)
        ax.set_ylabel('Total_overlap', color='white', fontsize=12)
        ax.set_xticks(np.arange(len(top_operators)))
        ax.set_xticklabels(top_operators['operator_id'], rotation=45, ha='right', color='white')
        ax.tick_params(colors='white')
        for spine in ax.spines.values():
            spine.set_color('white')
        ax.set_ylim(0, max(top_operators['total_overlaps']) * 1.2 if not top_operators.empty else 10)
        plt.tight_layout()
        c5_name = f"{output_dir}/5_operators_{file_suffix}.png"
        plt.savefig(c5_name, dpi=150, facecolor=fig.get_facecolor())
        plt.close()
        print(f"✅ Saved: {c5_name}")

        # --- CHART 6: Machines with Overlaps ---
        fig, ax = plt.subplots(figsize=(14, 6))
        ax.set_facecolor('#f0f0f0')
        fig.patch.set_facecolor('#f0f0f0')
        plot_3d_bars(ax, top_machines['machine_code'].tolist(), top_machines['total_overlapping_sessions'].tolist(), highlight_max=True)
        ax.set_title('Machines with total_overlapping_sessions', fontsize=14)
        ax.set_xlabel('Machine_code', fontsize=12)
        ax.set_ylabel('Total_overlap', fontsize=12)
        ax.set_xticks(np.arange(len(top_machines)))
        ax.set_xticklabels(top_machines['machine_code'], rotation=45, ha='right')
        ax.set_ylim(0, max(top_machines['total_overlapping_sessions']) * 1.2 if not top_machines.empty else 10)
        plt.tight_layout()
        c6_name = f"{output_dir}/6_machines_{file_suffix}.png"
        plt.savefig(c6_name, dpi=150, facecolor=fig.get_facecolor())
        plt.close()
        print(f"✅ Saved: {c6_name}")

        # ==================================================================
        # EXCEL EXPORT (3 SHEETS)
        # ==================================================================
        excel_filename = f"{output_dir}/detailed_overlap_analysis_{file_suffix}.xlsx"
        with pd.ExcelWriter(excel_filename, engine='openpyxl') as writer:
            detailed_view.to_pandas().to_excel(writer, sheet_name='Detailed_Overlaps', index=False)
            worksheet = writer.sheets['Detailed_Overlaps']
            worksheet.column_dimensions['A'].width = 20

            if not raw_sessions_df.is_empty():
                raw_sessions_df.to_pandas().to_excel(writer, sheet_name='Detailed_Sessions', index=False)
            else:
                pd.DataFrame({"Message": ["No raw session data found for overlapping pairs"]}).to_excel(writer, sheet_name='Detailed_Sessions', index=False)

            viz_sheet = writer.book.create_sheet('Visualizations')
            def add_img(ws, cell, img_path):
                img = OpenpyxlImage(img_path)
                img.width = int(img.width * 0.4)
                img.height = int(img.height * 0.4)
                ws.add_image(img, cell)

            add_img(viz_sheet, 'A1', c1_name)
            add_img(viz_sheet, 'N1', c2_name)
            add_img(viz_sheet, 'A35', c3_name)
            add_img(viz_sheet, 'N35', c4_name)
            add_img(viz_sheet, 'A70', c5_name)
            add_img(viz_sheet, 'N70', c6_name)

        print(f"\n✅ Successfully generated and saved Excel Report: '{excel_filename}'")
        print("   Sheet 1: Detailed Overlaps (Now includes 'stage_at_overlap_1' & 'stage_at_overlap_2')")
        print("   Sheet 2: Detailed Sessions (Raw events of ALL Overlapping Pairs)")
        print("   Sheet 3: Visualizations (3x2 Grid)")

        # ==================================================================
        # ZIP CREATION & EMAIL NOTIFICATION (SMTP)
        # ==================================================================
        print("\n========================================")
        print("          SENDING EMAIL NOTIFICATION VIA SMTP")
        print("========================================")
        zip_filename = f"{output_dir}/Overlap_Analysis_Report_{file_suffix}.zip"
        
        # Only zip the Excel file to keep attachment size small. 
        # The charts are already embedded inside the Excel file!
        with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            zipf.write(excel_filename, arcname=os.path.basename(excel_filename))
            
        # Read ZIP file as raw bytes
        with open(zip_filename, "rb") as f:
            zip_bytes = f.read()
            
        html_content = f"""
        <p>Please find attached the UC Parallel Session Overlap Analysis Report for <b>{date_suffix}</b>.</p>
        <p>The attachment contains the Detailed Excel Report (3 Sheets: Detailed Overlaps, Detailed Sessions, and Visualizations).</p>
        """
        
        for email in mail_list:
            send_email_via_smtp(
                to_email=email,
                cc_emails=cc,
                subject=f"Parallel Session Overlap Analysis Report - {date_suffix}",
                html_body=html_content,
                zip_bytes=zip_bytes,
                zip_filename=os.path.basename(zip_filename)
            )

        print(f"\n🎉 Process Complete! All files are saved locally in the '{output_dir}' folder and the email has been sent.")


# =====================================================================
# DAG DEFINITION
# =====================================================================
default_args = {
    'owner': 'Goverdhan',
    'depends_on_past': False,
    # Set start_date to today so it is eligible to run at 12 PM today
    'start_date': datetime(2026, 9, 3), 
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'daily_overlap_analysis_report',
    default_args=default_args,
    description='Executes the daily STROT overlap analysis script and sends email reports',
    schedule='0 1 * * *',  # Runs at 12:00 PM every day
    catchup=False,
    tags=["Reporting", "Analysis", "PARALLEL", "UC", "ENROLMENT"],
)

task_generate_report = PythonOperator(
    task_id='execute_overlap_analysis_task',
    python_callable=execute_overlap_analysis,
    dag=dag,
)

task_generate_report 