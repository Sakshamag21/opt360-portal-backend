from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from airflow.providers.smtp.notifications.smtp import SmtpNotifier
from datetime import datetime,timedelta
from trino.dbapi import connect
import pandas as pd

trino_host="10.10.116.75"
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="airflow_dag_test"


upd_facerd_raw=f"""
insert into strot.misc_adhoc.sorryfortesting8
select 1,'hello-tester'
"""

retry_notifier = SmtpNotifier(
    from_email="strot@uidai.net.in",
    to=[
        "techexe12.yp24@uidai.net.in",
        "harshitsha23@gmail.com"
    ],
    # {{ ti.try_number }} will tell you exactly which attempt failed
    subject="Airflow Alert: Task {{ ti.task_id }} Failed (Attempt {{ ti.try_number }})"
)

final_failure_notifier = SmtpNotifier(
    from_email="strot@uidai.net.in",
    to=[
        "techexe12.yp24@uidai.net.in",
        "harshitsha23@gmail.com"
    ],
    subject="Airflow Alert: Task {{ ti.task_id }} Completely FAILED"
)

# 2. Update your default_args
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2025, 8, 25),
    'retries': 1,
    'retry_delay': 30, # (Highly recommended) Wait 30 seconds before retrying
    'on_retry_callback': [retry_notifier],         # Triggers on EVERY failed attempt before a retry
    'on_failure_callback': [final_failure_notifier], # Triggers only after all retries are exhausted
}

# 3. Instantiate the DAG
dag = DAG(
    'tester_dag',
    default_args=default_args,
    description='DAG to insert random data to misc_adhoc.sorryfortesting',
    schedule="*/10 * * * *",
    catchup=False,
    tags=['trino', 'write', 'misc_adhoc', 'test']
)

def trino(query, catalog='flink_stream', schema='stream_enu', host=trino_host, port=trino_port, user=trino_user):
    # try:
    conn = connect(
        host=host,
        port=port,
        user=user,
        catalog=catalog,
        schema=schema
    )
    print("hello world!")
    cur = conn.cursor()
    cur.execute(query)
    body = cur.fetchall()
    if not body:
        return {"query": query, "success": 1, "data": body}
    else:
        cols = [i[0] for i in cur.description]
        df = pd.DataFrame(body, columns=cols)
        return {"query": query, "success": 1, "data": (cols, body), "df": df}
    # except Exception as e:
        # return {"query": query, "success": 0, "msg": str(e)}



upd_task = PythonOperator(
                task_id='insertion',
                python_callable=trino,
                op_kwargs={'query': upd_facerd_raw},
                trigger_rule='all_done',
                dag=dag,
            )

upd_task