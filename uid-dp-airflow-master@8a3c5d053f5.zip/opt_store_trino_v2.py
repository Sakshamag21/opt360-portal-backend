from __future__ import annotations
from datetime import datetime, timezone, timedelta
from airflow.models.dag import DAG
from airflow.operators.python import PythonOperator
from airflow.decorators import task
from trino.dbapi import connect
from airflow.operators.empty import EmptyOperator
import time

IST_OFFSET = timedelta(hours=5, minutes=30)
IST = timezone(IST_OFFSET)

trino_host="10.10.116.75"
trino_catalog_iceberg='strot'
trino_port=8080
trino_user="airflow_dag_opt_store"

def run_query(query,host=trino_host,port=trino_port,user=trino_user,retry=0):
    try:
        conn = connect(
            host=host,
            port=port,
            user=user
        )
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            print("query: ", query, "\nsuccess: ", 1, "\ndata: ", body)
        else:
            cols = [i[0] for i in cur.description]
            print("query: ", query, "\nsuccess: ", 1, "\ndata: ", (cols, body))
    except Exception as e:
        time.sleep(300)
        print("query: ", query, "\nsuccess: ", 0, "\nmsg: ", str(e))
        print("running again one more time")
        if retry==0:
            run_query(query,retry=1)
    return


def run_hourly_pkt_matrix():
    run_query("""
        merge into strot.operator360.opt_store t
        USING(
            SELECT 
            UPPER(session_operatorid) as opt_id,
            COUNT(*) as no_of_packets_today,
            COUNT_IF(enrolment_type = 'NEW' OR enrolment_type = 'N') AS no_of_enrl_packets_today,
            COUNT_IF(enrolment_type = 'U') AS no_of_update_packets_today
            FROM flink_stream.stream_enu.ens_packet_enriched
            WHERE DATE(event_timestamp)=DATE(CURRENT_DATE) AND DATE(DATE_PARSE(SUBSTRING(enrolment_eid, 15), '%Y%m%d%H%i%s')) = DATE(CURRENT_DATE)
            GROUP BY 1
        ) s
        ON upper(t.opt_id)=upper(s.opt_id)
        when matched then
        update set
            pkt_create_count_today=s.no_of_packets_today,
            pkt_create_count_enrl_today=s.no_of_enrl_packets_today,
            pkt_create_count_updt_today=s.no_of_update_packets_today
        when not matched then
            insert(opt_id,pkt_create_count_today,pkt_create_count_enrl_today,pkt_create_count_updt_today)
            values(s.opt_id,s.no_of_packets_today,s.no_of_enrl_packets_today,s.no_of_update_packets_today)
    """)

    run_query("""
        merge into strot.operator360.opt_store t
        USING(
            SELECT 
                UPPER(session_operatorid) as opt_id,
                COUNT(*) as no_of_mou_packets_today
            FROM flink_stream.stream_enu.ens_packet_enriched
            WHERE
                DATE(event_timestamp)=DATE(CURRENT_DATE) AND 
                DATE(DATE_PARSE(SUBSTRING(enrolment_eid, 15), '%Y%m%d%H%i%s')) = DATE(CURRENT_DATE)
                AND enrolment_eid LIKE 'S24%'
            GROUP BY 1
        ) s
        ON upper(t.opt_id)=upper(s.opt_id)
        when matched then
        update set
            pkt_create_count_mou_today=s.no_of_mou_packets_today
        when not matched then
            insert(opt_id,pkt_create_count_mou_today)
            values(s.opt_id,s.no_of_mou_packets_today)
    
    """)

def run_daily_pkt_matrix():
    run_query("""
        merge into strot.operator360.opt_store t
        using (
            WITH tab1 AS (
                SELECT 
                    UPPER(session_operatorid) AS opt_id,
                    DATE(DATE_PARSE(SUBSTRING(enrolment_eid, 15), '%Y%m%d%H%i%s')) AS pkt_date,
                    COUNT(*) AS pkt_daily,
                    COUNT_IF(enrolment_type = 'NEW' OR enrolment_type = 'N') AS pkt_daily_enrl,
                    COUNT_IF(enrolment_type = 'U') AS pkt_daily_updt
                FROM flink_stream.stream_enu.ens_packet_enriched
                WHERE DATE(event_timestamp) >= DATE(CURRENT_DATE - INTERVAL '45' DAY)
                GROUP BY 1, 2
            ),

            ranked_tab AS (
                SELECT *,
                    RANK() OVER (PARTITION BY opt_id ORDER BY pkt_date DESC) AS working_day
                FROM tab1
            ),

            filtered_tab AS (
                SELECT *
                FROM ranked_tab
                WHERE working_day <= 30
            )

            SELECT 
                opt_id, 
                AVG(pkt_daily) AS pkt_daily_avg, 
                AVG(pkt_daily_enrl) AS pkt_daily_enrl_avg, 
                AVG(pkt_daily_updt) AS pkt_daily_updt_avg
            FROM filtered_tab
            GROUP BY opt_id
        ) s
        on 
            upper(t.opt_id)=upper(s.opt_id)
        when matched then
            update set 
                pkt_create_daily_avg=s.pkt_daily_avg,
                pkt_create_daily_enrl_avg=s.pkt_daily_enrl_avg,
                pkt_create_daily_updt_avg=s.pkt_daily_updt_avg
        when not matched then
            insert (opt_id,pkt_create_daily_avg,pkt_create_daily_enrl_avg,pkt_create_daily_updt_avg)
            values (s.opt_id,s.pkt_daily_avg,s.pkt_daily_enrl_avg,s.pkt_daily_updt_avg)
    """)
    # run_query("""
    #     merge into strot.operator360.opt_store t
    #     using (
    #         WITH tab1 AS (
    #             SELECT 
    #                 UPPER(session_operatorid) AS opt_id,
    #                 DATE(DATE_PARSE(SUBSTRING(enrolment_eid, 15), '%Y%m%d%H%i%s')) AS pkt_date,
    #                 COUNT(*) AS pkt_daily
    #             FROM flink_stream.stream_enu.ens_packet_enriched
    #             WHERE DATE(DATE_PARSE(SUBSTRING(enrolment_eid, 15), '%Y%m%d%H%i%s')) >= DATE(CURRENT_DATE - INTERVAL '45' DAY)
    #                     AND enrolment_eid LIKE 'S24%'
    #             GROUP BY 1, 2
    #         ),
    #         ranked_tab AS (
    #             SELECT *,
    #                 RANK() OVER (PARTITION BY opt_id ORDER BY pkt_date DESC) AS working_day
    #             FROM tab1
    #         ),

    #         filtered_tab AS (
    #             SELECT *
    #             FROM ranked_tab
    #             WHERE working_day <= 30
    #         )

    #         SELECT 
    #             opt_id, 
    #             AVG(pkt_daily) AS pkt_daily_avg
    #         FROM filtered_tab
    #         GROUP BY opt_id
    #     ) s
    #     on 
    #         upper(t.opt_id)=upper(s.opt_id)
    #     when matched then
    #         update set 
    #             pkt_create_mou_daily_avg=s.pkt_daily_avg
    #     when not matched then
    #         insert (opt_id,pkt_create_mou_daily_avg)
    #         values (s.opt_id,s.pkt_daily_avg)
    # """)
    run_query("""
        merge into strot.operator360.opt_store t
        USING(
            WITH tab1 AS (
                SELECT 
                    UPPER(operator_id) AS opt_id,
                    DATE(DATE_PARSE(SUBSTRING(eid, 15), '%Y%m%d%H%i%s')) AS pkt_date,
                    COUNT_IF(enr_status = 'C') AS no_of_pkt_completed,
                    COUNT_IF(enr_status = 'R') AS no_of_pkt_rejected
                FROM strot.mysql_uid_v2.uid_origin_tracker
                WHERE DATE(enr_date) >= DATE(CURRENT_DATE - INTERVAL '45' DAY)
                GROUP BY 1, 2
            ),

            ranked_tab AS (
                SELECT *,
                    RANK() OVER (PARTITION BY opt_id ORDER BY pkt_date DESC) AS working_day
                FROM tab1
            ),

            filtered_tab AS (
                SELECT *
                FROM ranked_tab
                WHERE working_day <= 30
            )
                SELECT
                opt_id,
                CASE 
                    WHEN (SUM(no_of_pkt_rejected) + SUM(no_of_pkt_completed)) = 0 THEN 0
                    ELSE (SUM(no_of_pkt_rejected) * 100.0) / (SUM(no_of_pkt_rejected) + SUM(no_of_pkt_completed))
                END AS rejection_rate
                from filtered_tab
                group by opt_id
            ) s
            ON UPPER(t.opt_id)=UPPER(s.opt_id)
            when matched then
                update set
                    pkt_updt_rejection_rate=s.rejection_rate
            when not matched 
                then
                    insert(opt_id,pkt_updt_rejection_rate)
                    values(s.opt_id,s.rejection_rate)
    """)
    run_query("""
        merge into strot.operator360.opt_store t
        using (
            SELECT 
                UPPER(session_operatorid) AS opt_id, 
                COUNT(*) AS no_of_packets 
            FROM flink_stream.stream_enu.ens_packet_enriched 
            WHERE date(event_timestamp)>= CURRENT_DATE -INTERVAL '2' DAY AND
                date_parse(substring(enrolment_eid,15),'%Y%m%d%H%i%s') BETWEEN 
                    cast(CURRENT_DATE as TIMESTAMP) - INTERVAL '1' day + INTERVAL '21' hour AND 
                    cast(CURRENT_DATE as TIMESTAMP) + INTERVAL '8' hour
                AND session_operatorid IS NOT NULL 
                AND session_operatorid NOT IN ('ssup_operator', 'mou_operator') 
            GROUP BY UPPER(session_operatorid) 
        ) s
        on t.opt_id=s.opt_id
        when matched then
        update set
            pkt_create_odd_hour_count_yesterday = s.no_of_packets
    """)
    run_query("""
        merge into strot.operator360.opt_store t
        using (
            with tab1 as (
                SELECT 
                    UPPER(session_operatorid) AS session_operatorid,
                    CAST(date_parse(substring(enrolment_eid,15),'%Y%m%d%H%i%s') AS DATE) AS packet_date,
                    COUNT(*) AS daily_count
                FROM flink_stream.stream_enu.ens_packet_enriched
                WHERE 
                    date_parse(substring(enrolment_eid,15),'%Y%m%d%H%i%s') >= CURRENT_DATE - INTERVAL '30' day
                    AND (
                        HOUR(date_parse(substring(enrolment_eid,15),'%Y%m%d%H%i%s')) < 8 OR 
                        HOUR(date_parse(substring(enrolment_eid,15),'%Y%m%d%H%i%s')) >= 21
                    )
                    AND session_operatorid IS NOT NULL
                    AND session_operatorid NOT IN ('ssup_operator', 'mou_operator')
                GROUP BY 
                    UPPER(session_operatorid),
                    CAST(date_parse(substring(enrolment_eid,15),'%Y%m%d%H%i%s') AS DATE)
            )
            SELECT 
                UPPER(session_operatorid) AS opt_id, 
                avg(daily_count) AS no_of_packets 
            FROM tab1 
            GROUP BY UPPER(session_operatorid) 
        ) s
        on t.opt_id=s.opt_id
        when matched then
        update set
            pkt_create_odd_hour_avg = s.no_of_packets
    """)
    
    run_query("""
        merge into strot.operator360.opt_store fs
        using (
            with tab1_1 as (
                select upper(operator_id) as operator_id, event_timestamp,last_updated_date, 
                lag(last_updated_date) over(partition by upper(operator_id) order by last_updated_date asc) as just_before_update_date
                from flink_stream.stream_enu.enu_operator_sync_raw
                order by operator_id, event_timestamp desc
            ),

            tab1_2 as (
                select *,
                date_diff('minute',just_before_update_date, last_updated_date) as diff
                from tab1_1 
                where date(last_updated_date) >= date(current_date-interval '45' day)
            ),

            tab2_1 as (
                select operator_id, avg(diff) as avg_sync_time
                from tab1_2
                group by operator_id
            )

            select * from tab2_1 
        )avg_sync
            on upper(fs.opt_id) = operator_id
            when matched then 
            update set
            machine_avg_sync_duration = round(avg_sync.avg_sync_time/60,2)
    """)

    run_query("""
        merge into strot.operator360.opt_store t
        using (
        with tab1 as (
            select 
                UPPER(session_operatorid) as opt_id, 
                enrolment_eid,
                machine_pincode,
                DATE(DATE_PARSE(SUBSTRING(enrolment_eid, 15), '%Y%m%d%H%i%s')) as packet_date
                from 
                    flink_stream.stream_enu.ens_packet_enriched
                where 
                    machine_pincode is not null 
                    and DATE(DATE_PARSE(SUBSTRING(enrolment_eid, 15), '%Y%m%d%H%i%s')) >= DATE(CURRENT_DATE - INTERVAL '30' DAY)
        ),
        tab2 as (
            select opt_id,enrolment_eid,packet_date,machine_pincode,t2.district as machine_district, t2.state as machine_state
            from tab1 t1 join strot.misc_adhoc.pincode_ro_mapping t2 on t1.machine_pincode=cast(t2.pin_code as varchar)
        ),
        tab3 as (
            select 
                t1.*,t2.uid
            from 
                tab2 t1 join strot.mysql_uid_v2.uid_origin_tracker_enriched t2
            on t1.enrolment_eid=t2.eid
            where date(t2.enr_date) >= DATE(CURRENT_DATE - INTERVAL '40' DAY)
        ),
        tab4 as (
            select 
                t1.*,t2.res_addr_pincode as res_pincode
            from 
                tab3 t1 join strot.mysql_uid_v2.uid_address t2
            on t1.uid=t2.uid
            
        ),
        tab5 as (
            select 
                t1.*, t2.district as res_district, t2.state as res_state
            from tab4 t1 join strot.misc_adhoc.pincode_ro_mapping t2 on t1.res_pincode=cast(t2.pin_code as varchar)
        ),
        tab6 as (
            select 
                opt_id,
                packet_date,
                count_if(machine_pincode!=res_pincode and machine_district=res_district and machine_state=res_state) as outpincode_count, 
                count_if(machine_district!=res_district and machine_state=res_state) as outdistrict_count,
                count_if(machine_state!=res_state) as outstate_count       
            from tab5 
            group by 1,2
        )
            select 
                opt_id,
                avg(outpincode_count) as pkt_outpincode_daily_avg,
                avg(outdistrict_count) as pkt_outdistrict_daily_avg,
                avg(outstate_count) as pkt_outstate_daily_avg
            from tab6
            group by 1
        ) s
        on upper(t.opt_id) = upper(s.opt_id)
        when matched then
        update set
            pkt_outpincode_daily_avg = s.pkt_outpincode_daily_avg,
            pkt_outdistrict_daily_avg = s.pkt_outdistrict_daily_avg,
            pkt_outstate_daily_avg=s.pkt_outstate_daily_avg
    """)

def run_daily_opt_properties():
    run_query("""
        merge into strot.operator360.opt_store t
        using (
            select 
                upper(user_code) as opt_id,
                user_name, 
                cast(user_uid as varchar) as uid, 
                user_email_id, 
                cast(user_org_key as varchar) as user_org_key, 
                cast(user_reg_org_key as varchar) as user_reg_org_key,
                case when user_status!='1' then 0 else 1 end as is_active
            from mysql_uidmasterv1.uidmasterv1_1.user where upper(user_code) in (select opt_id from strot.operator360.opt_store)
        ) s
        on upper(t.opt_id)=upper(s.opt_id)
        when matched then
        update set
            opt_name = s.user_name,
            opt_uid = s.uid,
            opt_email = s.user_email_id,
            is_active = s.is_active
    """)
    run_query("""
    merge into strot.operator360.opt_store t
    using (
    with tab1 as (
        select upper(user_code) as opt_id, user_org_key, user_reg_org_key from mysql_uidmasterv1.uidmasterv1_1.user
    ),
    tab2 as (
        select 
            t1.opt_id as opt_id,t2.org_code as opt_ea_code,
            t2.org_name as opt_ea,t3.org_code as opt_reg_code,
            t3.org_name as opt_reg from tab1 t1
        join mysql_uidmasterv1.uidmasterv1_1.organization t2 on t1.user_org_key=t2.org_key
        join mysql_uidmasterv1.uidmasterv1_1.organization t3 on t1.user_reg_org_key=t3.org_key
    )
    select * from tab2
    ) s
    on upper(t.opt_id)=upper(s.opt_id)
    when matched then
        update set 
            opt_ea=s.opt_ea ,
            opt_reg=s.opt_reg ,
            opt_ea_code=s.opt_ea_code,
            opt_reg_code=s.opt_reg_code
    """)
    run_query("""
        merge into strot.operator360.opt_store t
        using (
            with tab1 as (
                select upper(operator_id) as operator_id, state,district, pincode, last_updated_date from flink_stream.stream_enu.enu_operator_sync_raw
                union all
                select upper(operator_id) as operator_id, state,district, pincode, last_updated_date from mysql_uid_logs_mirror.uidlogs.operator_center_sync
            ),
            tab2 as (
                select 
                    upper(operator_id) as operator_id,state,district, pincode,last_updated_date,
                    row_number() over (partition by upper(operator_id) order by last_updated_date desc) as rn 
                from tab1 where state is not null and state!=''
            )
                select * from tab2 where rn=1
        ) s
        on upper(t.opt_id)=upper(s.operator_id)
        when matched then
        update set
            opt_state = s.state,
            opt_district = s.district,
            opt_pincode = s.pincode,
            opt_ro = CASE
                        WHEN s.state IN ('Karnataka','Kerala','Lakshadweep','Puducherry','Tamil Nadu') THEN 'Bengaluru'
                        WHEN s.state IN ('Chandigarh','Haryana','Himachal Pradesh','Jammu and Kashmir','Ladakh','Punjab') THEN 'Chandigarh'
                        WHEN s.state IN ('Delhi','Madhya Pradesh','Rajasthan','Uttarakhand') THEN 'Delhi'
                        WHEN s.state IN ('Arunachal Pradesh','Assam','Manipur','Meghalaya','Mizoram','Nagaland','Sikkim','Tripura') THEN 'Guwahati'
                        WHEN s.state IN ('Andaman and Nicobar Islands','Andhra Pradesh','Chhattisgarh','Odisha','Telangana') THEN 'Hyderabad'
                        WHEN s.state IN ('Uttar Pradesh') THEN 'Lucknow'
                        WHEN s.state IN ('Goa','Gujarat','Maharashtra','Dadra and Nagar Haveli','Dadra and Nagar Haveli and Daman and Diu','Daman and Diu') THEN 'Mumbai'
                        WHEN s.state IN ('Bihar','Jharkhand','West Bengal') THEN 'Ranchi'
                        ELSE 'unknown'
                    END,
            machine_last_sync_time = s.last_updated_date                     
    """)
    run_query("""
        merge into strot.operator360.opt_store t
        using (
            select upper(session_operatorid) as opt_id, count(distinct station_machine_code) as machine_count from flink_stream.stream_enu.ens_packet_enriched 
            where date_parse(substring(enrolment_eid,15),'%Y%m%d%H%i%s')>=CURRENT_DATE - INTERVAL '30' day and upper(session_operatorid) != 'SELECT' and session_operatorid is not null
            group by 1
        ) s
        on t.opt_id=s.opt_id
        when matched then
        update set
            machine_count = s.machine_count
    """)


def sarvam_feedback():
    run_query("""
        merge into strot.operator360.opt_store t
        using (
            with tab1 as(
                SELECT *,
                case when (amount IS NOT NULL AND TRY_CAST(amount AS INTEGER) > 150) then 1
                else 0 end as false_amount_instance,
                case when (different_location is not null and different_location ='true') then 1
                else 0 end as false_address_instance
                FROM flink_stream.stream_enu.bi_ens_sarvam_bot_feedback_v1
                WHERE( 
                (amount IS NOT NULL AND TRY_CAST(amount AS INTEGER) > 150) or 
                (different_location is not null and different_location ='true') 
                ) and operator_id is not null and operator_id !=''
            ),
            
            tab2 as (
                select upper(operator_id) as opt_id, sum(false_amount_instance) as fedb_overcharge , sum(false_address_instance) as fedb_station_location
                from tab1 group by operator_id
            )
            
            select * from tab2
        ) s on upper(t.opt_id)=upper(s.opt_id)
        when matched then update set
            fedb_overcharge= s.fedb_overcharge,
            fedb_station_location= s.fedb_station_location
        when not matched then
            insert(opt_id,fedb_overcharge, fedb_station_location)
            values(s.opt_id, s.fedb_overcharge, s.fedb_station_location)

    """)

def run_daily_qc_stats():
    run_query("""
        merge into strot.operator360.opt_store t
        using (
            select 
                opt_id 
            from strot.operator360.opt_store
            where upper(opt_id) not in (
                SELECT distinct upper(operator_id)
                FROM strot.operator360.eid_qc_error_report_v2 
                WHERE date_trunc('month', check_date) = date_trunc('month', now())
                and operator_id IS NOT NULL
            )
        ) s
        on t.opt_id=s.opt_id
        when matched then update set
            qc_error_count       = 0,
            qc_doe1_count        = 0,
            qc_doe2_count        = 0,
            qc_de_count          = 0,
            qc_be_count          = 0,
            qc_grave_error_count = 0
    """)
    run_query("""
        merge into strot.operator360.opt_store fs
        using (
            select
                upper(operator_id) as id,
                count(*) as total ,
                count_if(error_category='DOE 1') as doe1,
                count_if(error_category='DOE 2') as doe2,
                count_if(error_category='DE') as de,
                count_if(error_category LIKE 'BE%') as be,
                count_if(priority = '1' and is_audited=true) as grave
            from 
                strot.operator360.eid_qc_error_report_v2
            where 
                date_trunc('month', check_date) = DATE_TRUNC('month', CURRENT_DATE) 
            group by 1
        ) s
        on upper(fs.opt_id) = id
        when matched then 
        update set
            qc_error_count = s.total,
            qc_doe1_count = s.doe1,
            qc_doe2_count = s.doe2,
            qc_de_count = s.de,
            qc_be_count = s.be,
            qc_grave_error_count = s.grave
    """)

    run_query("""
        merge into strot.operator360.opt_store t
        using (
            with tab1_1 as (
                select 
                    distinct packeteid as packeteid from flink_stream.stream_qc.qc_vendor_completion 
                where 
                    DATE_TRUNC('month',actionedat) = DATE_TRUNC('month', CURRENT_DATE)
            ),
            tab1_2 as (
                select 
                    distinct packeteid as packeteid from flink_stream.stream_qc.qc_vendor_completion_audit 
                where 
                    DATE_TRUNC('month',actionedat) = DATE_TRUNC('month', CURRENT_DATE)
            ),
            tab1_3 as (
                select * from tab1_1
                union all
                select * from tab1_2
            ),
            tab1 as (
                select distinct packeteid from tab1_3
            ),
            tab2 as (
                select t1.packeteid, t4.session_operatorid AS opt_id 
                FROM tab1 t1
                JOIN flink_stream.stream_enu.bi_enrlenspackets_upload_updt t4 on t1.packeteid = t4.enrolment_eid
            )
            select upper(opt_id) as opt_id,count(*) as cnt
            from tab2
            group by 1
        ) s
        on upper(t.opt_id)=upper(s.opt_id)
        when matched then
        update set
            qc_disp_count = s.cnt,
            qc_error_rate_current_month = CASE 
                                WHEN s.cnt = 0 THEN 0 
                                ELSE ((CAST(t.qc_error_count AS DECIMAL) * 100)/ CAST(s.cnt AS DECIMAL))
                            END ,
            qc_grave_error_rate_current_month = CASE 
                                WHEN s.cnt = 0 THEN 0 
                                ELSE ((CAST(t.qc_grave_error_count AS DECIMAL) * 100)/ CAST(s.cnt AS DECIMAL))
                            END
    """)

def run_weekly_pkt_matrix():
    run_query("""
        merge into strot.operator360.opt_store fs
        using (
            with tab1_1 as (
                select
                    upper(enrl_oper_code) as id,
                    date_diff('minute',enrl_start_date,enrl_end_date) as diff,
                    row_number() over(partition by upper(enrl_oper_code) order by event_timestamp desc) as row
                from (
                    select 
                        enrl_oper_code, from_iso8601_timestamp(enrl_start_date) as enrl_start_date, from_iso8601_timestamp(enrl_end_date) as enrl_end_date ,event_timestamp
                    from flink_stream.stream_enu.bi_enu_enrlraw 
                    where enrl_mode !='UPDATE' and date(event_timestamp) >= date(CURRENT_DATE - INTERVAL '3' month) 
                    union all
                    select
                        enrl_oper_code, enrl_start_date, enrl_end_date ,event_timestamp
                    from flink_stream.stream_enu.bi_enu_enrlraw_v2 
                    where enrl_mode !='UPDATE' and date(event_timestamp) >= date(CURRENT_DATE - INTERVAL '3' month) 
                )
            )
            select id, round(avg(diff),0) as avg_duration_min from tab1_1 where row<=100
            group by id 
        ) avg_dur
        on upper(fs.opt_id) = avg_dur.id
        when matched then 
        update set
            pkt_creation_enrl_duration_avg = avg_dur.avg_duration_min
    """)
    run_query("""
    merge into strot.operator360.opt_store fs
    using (
        with tab1_1 as (
            select
                upper(enrl_oper_code) as id,
                date_diff('minute',enrl_start_date,enrl_end_date) as diff,
                row_number() over(partition by upper(enrl_oper_code) order by event_timestamp desc) as row
            from (
                select enrl_oper_code, from_iso8601_timestamp(enrl_start_date) as enrl_start_date, from_iso8601_timestamp(enrl_end_date) as enrl_end_date ,event_timestamp
                from flink_stream.stream_enu.bi_enu_enrlraw 
                where enrl_mode ='UPDATE' and date(event_timestamp) >= date(CURRENT_DATE - INTERVAL '3' month) 
                union all
                select enrl_oper_code, enrl_start_date, enrl_end_date ,event_timestamp
                from flink_stream.stream_enu.bi_enu_enrlraw_v2 
                where enrl_mode ='UPDATE' and date(event_timestamp) >= date(CURRENT_DATE - INTERVAL '3' month) 
            )
        )

        select id, round(avg(diff),0) as avg_duration_min from tab1_1 where row<=100
        group by id
    ) avg_dur
        on upper(fs.opt_id) = avg_dur.id
        when matched then 
        update set
            pkt_creation_updt_duration_avg = avg_dur.avg_duration_min
    """)
    run_query("""
    merge into strot.operator360.opt_store fs
    using (
        with tab1_1 as (
            select
                upper(enrl_oper_code) as id,
                date_diff('minute',enrl_start_date,enrl_end_date) as diff,
                row_number() over(partition by upper(enrl_oper_code) order by event_timestamp desc) as row
            from (
                select enrl_oper_code, from_iso8601_timestamp(enrl_start_date) as enrl_start_date, from_iso8601_timestamp(enrl_end_date) as enrl_end_date ,event_timestamp
                from flink_stream.stream_enu.bi_enu_enrlraw 
                where date(event_timestamp) >= date(CURRENT_DATE - INTERVAL '3' month) 
                union all
                select enrl_oper_code, enrl_start_date, enrl_end_date ,event_timestamp
                from flink_stream.stream_enu.bi_enu_enrlraw_v2 
                where date(event_timestamp) >= date(CURRENT_DATE - INTERVAL '3' month) 
            )
        )
        select id, round(avg(diff),0) as avg_duration_min from tab1_1 where row<=100
        group by id
    ) avg_dur
        on upper(fs.opt_id) = avg_dur.id
        when matched then 
        update set
            pkt_creation_duration_avg = avg_dur.avg_duration_min 
    """)

def run_monthly_qc_stats():
    run_query("""
        merge into strot.operator360.opt_store t
        using (
            with tab0_1 as (
                select
                    upper(t2.session_operatorid) as id,
                    count(*) as total ,
                    count_if(priority = '1' and is_audited=true) as grave
                from 
                    strot.operator360.eid_qc_error_report_v2 t1
                join flink_stream.stream_enu.bi_enrlenspackets_upload_updt t2
                    on t1.packeteid = t2.enrolment_eid
                where 
                    year(check_date) = year(DATE_TRUNC('month', CURRENT_DATE - INTERVAL '1' month)) 
                    AND month(check_date) = month(DATE_TRUNC('month', CURRENT_DATE - INTERVAL '1' month))
                group by 1
            ),
            tab1_1 as (
                select 
                    distinct packeteid as packeteid from flink_stream.stream_qc.qc_vendor_completion 
                where 
                    DATE_TRUNC('month',actionedat) = DATE_TRUNC('month', CURRENT_DATE - INTERVAL '1' month)
            ),
            tab1_2 as (
                select 
                    distinct packeteid as packeteid from flink_stream.stream_qc.qc_vendor_completion_audit 
                where 
                    DATE_TRUNC('month',actionedat) = DATE_TRUNC('month', CURRENT_DATE - INTERVAL '1' month)
            ),
            tab1_3 as (
                select * from tab1_1
                union all
                select * from tab1_2
            ),
            tab1 as (
                select distinct packeteid from tab1_3
            ),
            tab2 as (
                select t1.packeteid, t4.session_operatorid AS opt_id 
                FROM tab1 t1
                JOIN flink_stream.stream_enu.bi_enrlenspackets_upload_updt t4 on t1.packeteid = t4.enrolment_eid
            ),
            tab2_1 as (
                select upper(opt_id) as opt_id,count() as cnt
                from tab2
                group by 1
            )

            select 
            tb21.opt_id as opt_id,
            case when tb21.cnt=0 then 0 else ((CAST(tb01.total AS DECIMAL) * 100)/ CAST(tb21.cnt AS DECIMAL)) end as qc_error_rate_prev_month,
            case when tb21.cnt=0 then 0 else ((CAST(tb01.grave AS DECIMAL) * 100)/ CAST(tb21.cnt AS DECIMAL)) end as qc_grave_error_rate_prev_month
            from tab0_1 tb01 join tab2_1 tb21
            on upper(tb01.id)=upper(tb21.opt_id)

        ) s
        on upper(t.opt_id)=upper(s.opt_id)
        when matched then
        update set
            qc_error_rate_prev_month = s.qc_error_rate_prev_month,
            qc_grave_rate_prev_month = s.qc_grave_error_rate_prev_month
    """)

def run_materialized_view_update():
    run_query("""
        DELETE FROM strot.operator360.opt_store WHERE opt_id IS NULL or opt_id like '%SSUP%'
    """)
    run_query("""
        REFRESH MATERIALIZED VIEW strot.operator360.operator_feature_store
    """)

with DAG(
    dag_id="opt_store_update_dag_all_frequencies",
    start_date=datetime(2025, 12, 16),
    schedule="@hourly",
    catchup=False,
    tags=["trino", "monolithic"],
    doc_md="A single DAG to handle hourly, daily, weekly and monthly tasks using conditional logic and the standard datetime library."
) as dag:


    hourly_task = PythonOperator(
        task_id="run_hourly_packet_matrix",
        python_callable=run_hourly_pkt_matrix,
    )

    @task.short_circuit
    def check_if_eod(logical_date: datetime):
        print(f"Checking if {logical_date} is the end of the day run...")
        logical_date_ist = datetime.now(tz=IST)
        if logical_date_ist.hour == 23:
            print("It is the end of the day. Proceeding with daily tasks.")
            return True
        else:
            print(f"Not the end of the day (hour {logical_date_ist.hour}). Skipping daily tasks.")
            return False

    daily_gate = check_if_eod()

    eod_packet_matrix = PythonOperator(
        task_id="eod_packet_matrix",
        python_callable=run_daily_pkt_matrix,
    )

    opt_properties = PythonOperator(
        task_id="opt_properties",
        python_callable=run_daily_opt_properties,
    )

    qc_checks = PythonOperator(
        task_id="qc_checks",
        python_callable=run_daily_qc_stats,
    )

    # Chain them sequentially
    # parallel_daily_tasks = 

    @task.short_circuit
    def check_if_sat(logical_date: datetime):
        print(f"Checking if {logical_date.date()} is a Saturday...")
        if logical_date.weekday() == 5 and ((logical_date.hour == 1) or (logical_date.hour == 2) or (logical_date.hour == 5)):
            print("It is Saturday. Proceeding with weekly tasks.")
            return True
        else:
            print(f"Not Saturday (weekday={logical_date.weekday()}). Skipping weekly tasks.")
            return False
            
    weekly_gate = check_if_sat()
    
    weekly_task = PythonOperator(
        task_id="run_weekly_aggregation",
        python_callable=run_weekly_pkt_matrix,
    )

    sarvam_update= PythonOperator(
        task_id="sarvam_feedback",
        python_callable=sarvam_feedback
    )


    @task.short_circuit
    def check_if_first_day_of_month(logical_date: datetime):
        print(f"Checking if {logical_date.strftime('%Y-%m-%d')} is the first day of the month...")
        prev_day = logical_date - timedelta(days=1)        
        is_first_day = ((logical_date.day == 1) and ((logical_date.hour == 1) or (logical_date.hour == 2) or (logical_date.hour == 5)))
        if is_first_day:
            print("It is the first day of the month. Proceeding with monthly task.")
            return True
        else:
            print("Not the first day of the month. Skipping monthly task.")
            return False
            
    monthly_gate = check_if_first_day_of_month()

    monthly_task = PythonOperator(
        task_id="run_monthly_aggregation",
        python_callable=run_monthly_qc_stats,
    )


    start = EmptyOperator(task_id="start")

    end_task = PythonOperator(
        task_id="refresh_materialized_view",
        python_callable=run_materialized_view_update,
    )

    # Hourly Branch (always runs)
    start >> hourly_task >> end_task

    # Daily Branch
    start >> daily_gate >> eod_packet_matrix >> opt_properties >> qc_checks

    # Weekly Branch
    start >> weekly_gate >> weekly_task >> sarvam_update

    # Monthly Branch
    start >> monthly_gate >> monthly_task

    # hourly_task >> daily_gate
    # daily_gate >> parallel_daily_tasks
    # parallel_daily_tasks >> weekly_gate
    # weekly_gate >> weekly_task
    # parallel_daily_tasks >> monthly_gate
    
    # monthly_gate >> monthly_task