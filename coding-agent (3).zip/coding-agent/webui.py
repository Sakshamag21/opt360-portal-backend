"""Web UI for the coding agent.

Run:  python webui.py
Then: open http://127.0.0.1:8765 in your browser

Architecture:
  - stdlib http.server (no Flask/FastAPI — no PyPI access needed)
  - Agent runs in a background thread (so the HTTP server stays responsive)
  - Approval prompts use threading.Event: the agent thread blocks until the
    browser sends a decision via POST /api/approve
  - Frontend polls /api/state every 500ms for real-time updates
  - Everything (HTML/CSS/JS) is embedded — no external files, no CDN

The UI shows:
  - Conversation history (goals, tool calls, results, agent responses)
  - Tool calls as colored cards (green=read-only, orange=mutating, red=shell)
  - Approval modal when the agent wants to edit/write/shell
  - Step counter and permission stats
"""
from __future__ import annotations

import json
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from agent import Agent
from model import ModelClient
from permissions import PermissionSystem


# =============================================================================
#  The WebAgent: wraps the Agent with threading for the web UI
# =============================================================================
class WebAgent:
    """Manages the agent lifecycle for the web UI.

    The agent runs in a background thread. The UI polls for state.
    Approval prompts block the agent thread until the UI responds.
    """

    def __init__(self):
        self.events: list[dict] = []
        self.pending_approval: dict | None = None
        self.running = False
        self.agent: Agent | None = None
        self._lock = threading.Lock()

    def start_goal(self, goal: str) -> dict:
        """Start a new goal in a background thread."""
        with self._lock:
            if self.running:
                return {"error": "Agent is already running. Wait for it to finish."}
            self.running = True
            self.events = []
            self.pending_approval = None

        # The approval prompt function. Called from the agent thread.
        # Blocks (waits on Event) until the browser sends a decision.
        def prompt_fn(tool_name, args, formatted_action):
            event = threading.Event()
            result = [None]
            with self._lock:
                self.pending_approval = {
                    "tool": tool_name,
                    "formatted": formatted_action,
                    "event": event,
                    "result": result,
                }
            # Block here until the UI responds (or 5-minute timeout)
            event.wait(timeout=300)
            with self._lock:
                self.pending_approval = None
            return result[0] or "deny"

        perms = PermissionSystem(prompt_fn=prompt_fn)

        def on_event(ev):
            with self._lock:
                self.events.append(ev)

        self.agent = Agent(ModelClient(), permissions=perms, on_event=on_event)

        def run_thread():
            try:
                self.agent.run(goal)
            except Exception as e:
                with self._lock:
                    self.events.append({"type": "error", "message": f"{type(e).__name__}: {e}"})
            finally:
                with self._lock:
                    self.running = False

        threading.Thread(target=run_thread, daemon=True).start()
        return {"status": "started"}

    def respond_approval(self, decision: str) -> dict:
        """Respond to a pending approval prompt (called from the HTTP handler)."""
        with self._lock:
            if not self.pending_approval:
                return {"error": "No pending approval"}
            self.pending_approval["result"][0] = decision
            self.pending_approval["event"].set()
            return {"status": "ok"}

    def get_state(self) -> dict:
        """Return the current state for the UI to render."""
        with self._lock:
            stats = None
            if self.agent and self.agent.permissions:
                stats = {
                    "approved": self.agent.permissions.approved_count,
                    "denied": self.agent.permissions.denied_count,
                    "always_allowed": list(self.agent.permissions._always_allowed),
                }
            return {
                "running": self.running,
                "events": list(self.events),
                "pending_approval": {
                    "tool": self.pending_approval["tool"],
                    "formatted": self.pending_approval["formatted"],
                } if self.pending_approval else None,
                "stats": stats,
            }


# =============================================================================
#  HTTP Server
# =============================================================================
class Handler(BaseHTTPRequestHandler):
    web_agent = WebAgent()

    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self._serve(200, "text/html", HTML_PAGE)
        elif self.path == "/api/state":
            self._serve_json(self.web_agent.get_state())
        else:
            self._serve(404, "text/plain", "not found")

    def do_POST(self):
        body = self._read_body()
        if self.path == "/api/goal":
            result = self.web_agent.start_goal(body.get("goal", ""))
            self._serve_json(result)
        elif self.path == "/api/approve":
            result = self.web_agent.respond_approval(body.get("decision", "deny"))
            self._serve_json(result)
        else:
            self._serve(404, "text/plain", "not found")

    def _serve(self, code, content_type, text):
        data = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", len(data))
        self.end_headers()
        self.wfile.write(data)

    def _serve_json(self, obj):
        self._serve(200, "application/json", json.dumps(obj))

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        if length:
            try:
                return json.loads(self.rfile.read(length))
            except json.JSONDecodeError:
                return {}
        return {}

    def log_message(self, *args):
        pass  # silence default request logging


# =============================================================================
#  The Frontend (HTML + CSS + JS, embedded as a string)
# =============================================================================
HTML_PAGE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>coding-agent</title>
<style>
  :root {
    --bg: #1e1e1e;
    --bg-card: #252526;
    --bg-input: #2d2d2d;
    --border: #3c3c3c;
    --text: #d4d4d4;
    --text-dim: #888;
    --accent: #007acc;
    --accent-hover: #1a8ad4;
    --green: #4ec9b0;
    --orange: #dcdcaa;
    --red: #f44747;
    --blue: #569cd6;
    --purple: #c586c0;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'Segoe UI', 'SF Pro Display', sans-serif;
    background: var(--bg);
    color: var(--text);
    height: 100vh;
    display: flex;
    flex-direction: column;
  }

  /* Header */
  header {
    background: var(--bg-card);
    border-bottom: 1px solid var(--border);
    padding: 10px 20px;
    display: flex;
    align-items: center;
    gap: 16px;
  }
  header h1 {
    font-size: 16px;
    font-weight: 600;
    color: var(--accent);
  }
  #status {
    font-size: 12px;
    color: var(--text-dim);
    padding: 2px 10px;
    border-radius: 10px;
    background: var(--bg-input);
  }
  #status.running { color: var(--green); }
  #stats {
    margin-left: auto;
    font-size: 11px;
    color: var(--text-dim);
    font-family: monospace;
  }

  /* Conversation */
  #conversation {
    flex: 1;
    overflow-y: auto;
    padding: 20px;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .msg { max-width: 85%; word-wrap: break-word; }
  .msg-user {
    align-self: flex-end;
    background: var(--accent);
    color: white;
    padding: 10px 14px;
    border-radius: 12px 12px 2px 12px;
  }
  .msg-agent {
    align-self: flex-start;
    background: var(--bg-card);
    padding: 10px 14px;
    border-radius: 12px 12px 12px 2px;
    border: 1px solid var(--border);
  }
  .msg-thinking {
    align-self: flex-start;
    color: var(--text-dim);
    font-style: italic;
    font-size: 13px;
    padding: 4px 10px;
  }
  .msg-error {
    align-self: center;
    background: rgba(244,71,71,0.15);
    border: 1px solid var(--red);
    color: var(--red);
    padding: 8px 14px;
    border-radius: 8px;
    font-size: 13px;
  }

  /* Step indicator */
  .step-indicator {
    align-self: center;
    font-size: 11px;
    color: var(--text-dim);
    padding: 2px 12px;
    border-radius: 10px;
    background: var(--bg-card);
    border: 1px solid var(--border);
  }

  /* Tool call card */
  .tool-card {
    align-self: flex-start;
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: 8px;
    overflow: hidden;
    max-width: 85%;
    width: 100%;
  }
  .tool-header {
    padding: 8px 12px;
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    user-select: none;
  }
  .tool-badge {
    font-size: 11px;
    font-weight: 600;
    padding: 2px 8px;
    border-radius: 4px;
    font-family: monospace;
  }
  .badge-read { background: rgba(78,201,176,0.2); color: var(--green); }
  .badge-struct { background: rgba(86,156,214,0.2); color: var(--blue); }
  .badge-edit { background: rgba(220,220,170,0.2); color: var(--orange); }
  .badge-shell { background: rgba(244,71,71,0.2); color: var(--red); }
  .badge-denied { background: rgba(244,71,71,0.3); color: var(--red); }
  .tool-name { font-family: monospace; font-size: 13px; }
  .tool-args { font-family: monospace; font-size: 12px; color: var(--text-dim); }
  .tool-result {
    padding: 8px 12px;
    font-family: monospace;
    font-size: 12px;
    white-space: pre-wrap;
    word-break: break-all;
    background: var(--bg);
    border-top: 1px solid var(--border);
    max-height: 300px;
    overflow-y: auto;
  }
  .tool-result.collapsed { display: none; }
  .tool-status { margin-left: auto; font-size: 11px; color: var(--text-dim); }

  /* Approval modal */
  #approval-modal {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 100;
  }
  #approval-modal.show { display: flex; }
  .approval-box {
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 24px;
    max-width: 600px;
    width: 90%;
  }
  .approval-box h2 {
    font-size: 16px;
    color: var(--orange);
    margin-bottom: 12px;
  }
  .approval-action {
    font-family: monospace;
    font-size: 13px;
    background: var(--bg);
    padding: 12px;
    border-radius: 8px;
    border: 1px solid var(--border);
    white-space: pre-wrap;
    word-break: break-all;
    margin-bottom: 16px;
    max-height: 200px;
    overflow-y: auto;
  }
  .approval-buttons {
    display: flex;
    gap: 8px;
  }
  .approval-buttons button {
    flex: 1;
    padding: 10px;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    cursor: pointer;
    font-weight: 600;
  }
  #btn-approve { background: var(--green); color: var(--bg); }
  #btn-always { background: var(--accent); color: white; }
  #btn-deny { background: var(--red); color: white; }
  .approval-buttons button:hover { opacity: 0.85; }

  /* Input area */
  #input-area {
    background: var(--bg-card);
    border-top: 1px solid var(--border);
    padding: 12px 20px;
    display: flex;
    gap: 8px;
  }
  #goal-input {
    flex: 1;
    background: var(--bg-input);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 10px 14px;
    color: var(--text);
    font-size: 14px;
    font-family: inherit;
    resize: none;
    height: 44px;
    max-height: 120px;
  }
  #goal-input:focus { outline: none; border-color: var(--accent); }
  #goal-input:disabled { opacity: 0.5; }
  #send-btn {
    background: var(--accent);
    color: white;
    border: none;
    border-radius: 8px;
    padding: 0 20px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
  }
  #send-btn:hover { background: var(--accent-hover); }
  #send-btn:disabled { opacity: 0.4; cursor: not-allowed; }

  /* Scrollbar */
  ::-webkit-scrollbar { width: 8px; }
  ::-webkit-scrollbar-track { background: var(--bg); }
  ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }
</style>
</head>
<body>

<header>
  <h1>coding-agent</h1>
  <span id="status">idle</span>
  <span id="stats"></span>
</header>

<div id="conversation"></div>

<div id="approval-modal">
  <div class="approval-box">
    <h2>⚠ Approval Needed</h2>
    <div class="approval-action" id="approval-action"></div>
    <div class="approval-buttons">
      <button id="btn-approve">Approve Once</button>
      <button id="btn-always">Always (this session)</button>
      <button id="btn-deny">Deny</button>
    </div>
  </div>
</div>

<div id="input-area">
  <textarea id="goal-input" placeholder="Type a coding task..." rows="1"></textarea>
  <button id="send-btn">Send</button>
</div>

<script>
// --- State ---
let lastEventCount = 0;
let isRunning = false;

// --- Tool classification (for colored badges) ---
const READ_TOOLS = ['read', 'grep', 'glob'];
const STRUCT_TOOLS = ['index_code', 'graph_overview', 'list_symbols', 'get_symbol', 'find_callers', 'find_callees', 'summarize_symbol'];

function toolCategory(name) {
  if (READ_TOOLS.includes(name)) return 'read';
  if (STRUCT_TOOLS.includes(name)) return 'struct';
  if (name === 'shell') return 'shell';
  if (name === 'edit' || name === 'write') return 'edit';
  return 'read';
}

// --- Rendering ---
const conv = document.getElementById('conversation');

function renderEvent(ev) {
  switch (ev.type) {
    case 'goal':
      addMsg('msg-user', ev.text);
      break;
    case 'step':
      const step = document.createElement('div');
      step.className = 'step-indicator';
      step.textContent = `Step ${ev.number}`;
      conv.appendChild(step);
      break;
    case 'thinking':
      addMsg('msg-thinking', ev.text);
      break;
    case 'tool_call':
      renderToolCard(ev.name, ev.args);
      break;
    case 'tool_result':
      fillToolResult(ev.name, ev.result, ev.denied);
      break;
    case 'denial':
      // Already shown via tool_result denied=true
      break;
    case 'done':
      addMsg('msg-agent', ev.answer);
      break;
    case 'error':
      addMsg('msg-error', ev.message);
      break;
  }
  conv.scrollTop = conv.scrollHeight;
}

function addMsg(cls, text) {
  const div = document.createElement('div');
  div.className = `msg ${cls}`;
  div.textContent = text;
  conv.appendChild(div);
}

function renderToolCard(name, args) {
  const cat = toolCategory(name);
  const card = document.createElement('div');
  card.className = 'tool-card';
  card.id = `tool-${name}-${lastEventCount}`;

  const header = document.createElement('div');
  header.className = 'tool-header';

  const badge = document.createElement('span');
  badge.className = `tool-badge badge-${cat}`;
  badge.textContent = name;

  const nameSpan = document.createElement('span');
  nameSpan.className = 'tool-name';
  nameSpan.textContent = `(${JSON.stringify(args).slice(0, 100)})`;

  const status = document.createElement('span');
  status.className = 'tool-status';
  status.textContent = 'running...';

  header.appendChild(badge);
  header.appendChild(nameSpan);
  header.appendChild(status);

  // Click to toggle result
  header.onclick = function() {
    const result = card.querySelector('.tool-result');
    if (result) result.classList.toggle('collapsed');
  };

  card.appendChild(header);
  conv.appendChild(card);

  // Store reference for the result fill
  card.dataset.callId = lastEventCount;
}

function fillToolResult(name, result, denied) {
  // Find the last tool-card for this tool name
  const cards = conv.querySelectorAll('.tool-card');
  const card = cards[cards.length - 1];
  if (!card) return;

  const status = card.querySelector('.tool-status');
  if (status) status.textContent = denied ? 'DENIED' : 'done';

  if (denied) {
    const badge = card.querySelector('.tool-badge');
    if (badge) {
      badge.className = 'tool-badge badge-denied';
      badge.textContent = 'DENIED';
    }
  }

  const resultDiv = document.createElement('div');
  resultDiv.className = 'tool-result collapsed';
  resultDiv.textContent = result;
  card.appendChild(resultDiv);
}

// --- Polling ---
async function poll() {
  try {
    const resp = await fetch('/api/state');
    const state = await resp.json();

    // Update status
    const statusEl = document.getElementById('status');
    const statsEl = document.getElementById('stats');
    const input = document.getElementById('goal-input');
    const sendBtn = document.getElementById('send-btn');

    if (state.running !== isRunning) {
      isRunning = state.running;
      statusEl.textContent = isRunning ? 'running' : 'idle';
      statusEl.className = isRunning ? 'running' : '';
      input.disabled = isRunning;
      sendBtn.disabled = isRunning;
    }

    if (state.stats) {
      statsEl.textContent = `approved: ${state.stats.approved} | denied: ${state.stats.denied}` +
        (state.stats.always_allowed.length ? ` | always: ${state.stats.always_allowed.join(',')}` : '');
    }

    // Render new events
    if (state.events.length > lastEventCount) {
      for (let i = lastEventCount; i < state.events.length; i++) {
        renderEvent(state.events[i]);
      }
      lastEventCount = state.events.length;
    }

    // Show/hide approval modal
    const modal = document.getElementById('approval-modal');
    if (state.pending_approval) {
      modal.classList.add('show');
      document.getElementById('approval-action').textContent = state.pending_approval.formatted;
    } else {
      modal.classList.remove('show');
    }
  } catch (e) {
    // Server might be restarting; ignore
  }
}

setInterval(poll, 500);

// --- Input ---
const input = document.getElementById('goal-input');
const sendBtn = document.getElementById('send-btn');

async function sendGoal() {
  const goal = input.value.trim();
  if (!goal || isRunning) return;

  input.value = '';
  input.style.height = '44px';

  await fetch('/api/goal', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({goal: goal})
  });
}

sendBtn.onclick = sendGoal;
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendGoal();
  }
});

// Auto-resize textarea
input.addEventListener('input', () => {
  input.style.height = '44px';
  input.style.height = Math.min(input.scrollHeight, 120) + 'px';
});

// --- Approval buttons ---
document.getElementById('btn-approve').onclick = () => respondApproval('once');
document.getElementById('btn-always').onclick = () => respondApproval('always');
document.getElementById('btn-deny').onclick = () => respondApproval('deny');

async function respondApproval(decision) {
  await fetch('/api/approve', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({decision: decision})
  });
}

// Initial poll
poll();
</script>
</body>
</html>
"""


# =============================================================================
#  Entry point
# =============================================================================
def main():
    port = 8765
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    url = f"http://127.0.0.1:{port}"
    print(f"{'=' * 50}")
    print(f"  coding-agent UI")
    print(f"  Open: {url}")
    print(f"  Press Ctrl+C to stop")
    print(f"{'=' * 50}")
    try:
        webbrowser.open(url)
    except Exception:
        pass  # if browser auto-open fails, user can open manually
    server.serve_forever()


if __name__ == "__main__":
    main()
