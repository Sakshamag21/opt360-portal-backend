"""Connectivity check for the GLM 5.2 endpoint.

Run:  python test_api.py

If this fails with a connection timeout, the endpoint is not reachable from
this Python process (likely a process-based firewall rule — OpenCode's service
reaches it, but direct python.exe calls may not). See README.md > Troubleshooting.
"""
import json
import urllib.request

BASE = "http://10.10.109.101:8080/glm52/v1"
MODEL = "glm-5.2-fp8"


def call(path, payload=None):
    url = f"{BASE}{path}"
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(url, data=data)
    if payload is not None:
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.status, r.read().decode()


if __name__ == "__main__":
    print("endpoint:", BASE)
    print("model:   ", MODEL)

    # 1. List models
    try:
        st, body = call("/models")
        print(f"\n[GET /models] status={st}")
        print(body[:400])
    except Exception as e:
        print(f"\n[GET /models] FAILED: {e!r}")

    # 2. Tiny chat completion
    try:
        st, body = call("/chat/completions", payload={
            "model": MODEL,
            "messages": [
                {"role": "system", "content": "Reply with one short sentence."},
                {"role": "user", "content": "Reply with exactly: API_OK"},
            ],
            "temperature": 0,
            "max_tokens": 50,
        })
        print(f"\n[POST /chat/completions] status={st}")
        print(body[:600])
    except Exception as e:
        print(f"\n[POST /chat/completions] FAILED: {e!r}")
