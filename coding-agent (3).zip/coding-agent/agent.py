"""THE AGENT LOOP — the heart of how a coding agent works.

Read this file top-to-bottom; it's the whole point. Everything else
(model.py, tools.py) is plumbing. THE LOOP is the idea.

THE PATTERN (ReAct — Reason + Act):

    user gives a GOAL
    ┌─────────────────────────────────────────────────┐
    │ 1. THINK:    model proposes the next action     │  <- model.chat()
    │ 2. ACT:      agent runs the tool the model      │  <- _dispatch()
    │              asked for (read/edit/shell/...)     │
    │ 3. OBSERVE:  result goes back into `messages`   │  <- role=tool message
    │ 4. LOOP:     model thinks again WITH the new    │
    │              observation in context              │
    │ 5. STOP:     when the model replies with NO     │  <- response.is_final
    │              tool calls -> done, show the answer │
    └─────────────────────────────────────────────────┘

THREE THINGS TO NOTICE:
  (a) The model never executes anything. It only emits INTENTS (tool calls).
      The agent loop is the only thing that touches the filesystem / shell.
  (b) The model has no memory. The `messages` list IS its memory — it grows
      each turn and is re-sent in full on every model call.
  (c) Observation changes reasoning. When a tool returns an error, the model
      sees it and adjusts. That feedback is what makes the loop CONVERGE on a
      correct result instead of guessing once and being wrong.
"""
from __future__ import annotations

import json

from config import MAX_ITERATIONS, SYSTEM_PROMPT
from model import ModelClient, Response
from tools import TOOL_REGISTRY, TOOL_SPECS
from codegraph import CodeGraph
from permissions import PermissionSystem


class Agent:
    def __init__(self, model: ModelClient | None = None, permissions: PermissionSystem | None = None, on_event=None):
        self.model = model or ModelClient()
        # messages = the running conversation, including tool calls + results.
        # This is the agent's MEMORY. Seeded with the system prompt.
        self.messages: list[dict] = [{"role": "system", "content": SYSTEM_PROMPT}]

        # The permission system — the safety gate before destructive tools.
        # If None, _dispatch skips permission checks (backwards-compatible,
        # but NOT safe for real use). Always pass one in production.
        self.permissions = permissions

        # Event callback for UI streaming. When set, the agent emits structured
        # events at each step (step_start, tool_call, tool_result, done, etc.)
        # so a UI can render the loop in real-time. When None, the CLI prints
        # handle it. This is how the web UI watches the loop without modifying it.
        self.on_event = on_event

        # Inject model + code graph into the tools module's namespace so the
        # structural+summary tools can use them. This is the wiring step:
        # without it, tools.py's `model` and `graph` globals stay None and
        # those tools return "not initialized" errors.
        import tools as _tools
        _tools.model = self.model
        if _tools.graph is None:
            _tools.graph = CodeGraph(".")

        # EAGER INJECTION: build the map once at startup and inject it into the
        # system prompt. Why: the model is stateless and would otherwise waste
        # its first turn calling index_code + graph_overview on every task.
        # Since we KNOW it needs the map for any multi-file work, give it up
        # front. The graph is disk-cached (cheap to reload) and we track edits
        # to re-inject a fresh map if code changes during the session.
        self._inject_map()

        # Track whether code was modified this session, so we know to refresh
        # the injected map before the next goal (prevents staleness).
        self._code_changed = False

    def run(self, goal: str) -> str:
        """Run the full think-act-observe loop for a user goal. Returns the final answer."""
        # If code changed during a previous goal, refresh the injected map so
        # the model doesn't trust stale line numbers / call graphs. This is the
        # staleness fix: edits invalidate, next goal re-injects.
        if self._code_changed:
            self._refresh_map()
            self._code_changed = False

        # Seed the conversation with the user's goal.
        self.messages.append({"role": "user", "content": goal})
        self._emit({"type": "goal", "text": goal})

        for step in range(1, MAX_ITERATIONS + 1):
            print(f"\n— step {step} —")
            self._emit({"type": "step", "number": step})

            # 1. THINK: ask the model what to do next, given the WHOLE history
            #    and the catalog of tools it's allowed to call.
            try:
                response = self.model.chat(self.messages, TOOL_SPECS)
            except Exception as e:
                # Model call failed (network, API error, etc.). Feed the error
                # back as a tool-like observation so the model can adapt, rather
                # than crashing the whole run.
                error_msg = f"ERROR: model call failed: {type(e).__name__}: {e}"
                print(f"  [model error: {e}]")
                self.messages.append({"role": "assistant", "content": error_msg})
                self._emit({"type": "error", "message": str(e)})
                continue

            # Record the assistant's turn in memory (future turns will see it).
            self.messages.append(self._assistant_message(response))

            # If the model emitted text alongside tool calls, show it.
            if response.content:
                self._emit({"type": "thinking", "text": response.content})

            # 2. DECIDE: is the model done, or does it want to call a tool?
            if response.is_final:
                # No tool calls -> the model is handing back a final answer.
                answer = response.content or "(no response)"
                self._emit({"type": "done", "answer": answer})
                return answer

            # 3. ACT + OBSERVE: run each requested tool, feed results back.
            for call in response.tool_calls:
                print(f"  -> {call.name}({json.dumps(call.arguments)[:120]})")
                self._emit({"type": "tool_call", "name": call.name, "args": call.arguments})
                result = self._dispatch(call.name, call.arguments)
                # Truncate huge results so one tool doesn't blow up context.
                preview = result if len(result) <= 6000 else result[:6000] + "\n... (truncated)"
                self._emit({"type": "tool_result", "name": call.name, "result": preview, "denied": result.startswith("PERMISSION DENIED")})
                # 4. OBSERVE: the tool result becomes a message the model sees next turn.
                self.messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": preview,
                })
            # 5. LOOP: back to step 1. The model now thinks again WITH the new
            #    tool results in context.

        self._emit({"type": "done", "answer": "WARNING: hit MAX_ITERATIONS without the model finishing."})
        return "WARNING: hit MAX_ITERATIONS without the model finishing."

    def _emit(self, event: dict):
        """Send an event to the UI callback (if one is set).

        This is the ONLY connection between the agent loop and the UI. The loop
        doesn't know if it's talking to a CLI, a web UI, or nothing at all.
        Clean separation: the loop runs; the callback observes.
        """
        if self.on_event:
            try:
                self.on_event(event)
            except Exception:
                pass  # UI errors must never crash the agent loop

    # --- dispatch -------------------------------------------------------------
    def _dispatch(self, name: str, args: dict) -> str:
        """Look up a tool by name and run it. This is the ONLY execution path.

        Everything the agent does to the outside world funnels through here.
        That centralization is what makes tools auditable + safe to gate later.

        PERMISSION GATE: before running destructive tools (edit/write/shell),
        we ask the human for approval. Read-only tools run without asking.
        If denied, the model gets a message explaining why — denial is
        feedback, not a crash. The model adapts.
        """
        fn = TOOL_REGISTRY.get(name)
        if fn is None:
            return f"ERROR: unknown tool '{name}'. Available: {list(TOOL_REGISTRY)}"

        # --- THE SAFETY GATE ---
        if self.permissions is not None:
            allowed, denial_message = self.permissions.check(name, args)
            if not allowed:
                # Denied. Return the explanation as the tool result so the
                # model sees it in messages and can adapt its approach.
                print(f"  [DENIED] {name}")
                self._emit({"type": "denial", "tool": name, "message": denial_message})
                return denial_message
            # Approved (once, always, or auto). Proceed to run.

        try:
            result = fn(**args)
            # Track code mutations so the injected map can be refreshed before
            # the next goal. read/grep/find_callers don't change anything;
            # edit/write/shell (if it touches files) do. We're conservative
            # here: shell could run `git checkout` etc., so flag it too.
            if name in ("edit", "write", "shell"):
                self._code_changed = True
            return result
        except TypeError as e:
            return f"ERROR: bad arguments for '{name}': {e}"
        except Exception as e:
            return f"ERROR: {type(e).__name__}: {e}"

    # --- map injection --------------------------------------------------------
    def _inject_map(self):
        """Inject the TIER 0 file index into the system prompt at startup.

        We inject ONLY the file index (names + counts), NOT the full symbol
        detail. Why: the model is stateless and needs SOME starting context
        (what files exist), but dumping all 68 symbols' line ranges + calls
        would waste context on tasks that never touch most files.

        Tiered model:
          Tier 0 (here, always): file index — ~13 lines, always in context.
          Tier 1 (on demand):    list_symbols(path) — per-file detail, ~10 lines,
                                 one round-trip. Paid only for files touched.
          Tier 2 (on demand):    get_symbol(path, name) — one function's source.
          Tier 3 (on demand):    find_callers(name) — cross-file call graph.

        For trivial tasks ("read line 5 of main.py") the model uses Tier 0 to
        confirm the file exists, then calls `read` directly — zero symbol
        detail needed. For multi-file work it pulls Tier 1/2/3 as needed.
        Scales to large codebases (full overview injection would not).
        """
        import tools as _tools
        if _tools.graph is None:
            return
        _tools.graph.index(".")  # idempotent; skips unchanged files
        index = _tools.graph.file_index()
        self.messages[0] = {
            "role": "system",
            "content": f"{SYSTEM_PROMPT}\n\n=== CODEBASE FILES (auto-injected) ===\n{index}",
        }

    def _refresh_map(self):
        """Re-inject the file index after code was modified during the session."""
        import tools as _tools
        if _tools.graph is None:
            return
        _tools.graph.index(".")
        index = _tools.graph.file_index()
        self.messages.append({
            "role": "system",
            "content": f"=== CODEBASE FILES (refreshed after your edits) ===\n{index}",
        })

    # --- message shaping ------------------------------------------------------
    @staticmethod
    def _assistant_message(response: Response) -> dict:
        """Rebuild the assistant message in OpenAI shape, including tool_calls.

        The model's tool-call intents must be echoed back into context verbatim
        (with matching ids) so the next turn's tool results can be correlated.
        """
        msg: dict = {"role": "assistant", "content": response.content}
        if response.tool_calls:
            msg["tool_calls"] = [
                {
                    "id": c.id,
                    "type": "function",
                    "function": {
                        "name": c.name,
                        "arguments": json.dumps(c.arguments),
                    },
                }
                for c in response.tool_calls
            ]
        return msg
