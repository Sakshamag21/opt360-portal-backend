"""The ModelClient: how the agent talks to the LLM (the "brain").

This file is intentionally tiny and isolated. The agent loop (agent.py) calls
`ModelClient.chat(...)` and gets back a normalized Response. It does not care
about HTTP, JSON, or OpenAI-specific shapes — that's all hidden here.

KEY FLOW IDEA: the model is STATELESS. Each `chat()` call sends the ENTIRE
conversation history (`messages`) plus the tool catalog (`tools`). The model
has no memory between calls — the `messages` array IS its memory. The agent
loop is what grows that array turn by turn.
"""
from __future__ import annotations

import json
import urllib.request
from dataclasses import dataclass, field

from config import API_KEY, BASE_URL, MODEL_ID


@dataclass
class ToolCall:
    """A single tool-call INTENT emitted by the model.

    The model does NOT run this tool — it only expresses the intent to.
    The agent loop is responsible for actually executing it (see agent.py).
    """
    id: str          # correlation id; must be echoed back in the tool result
    name: str        # which tool, e.g. "read"
    arguments: dict  # parsed args, e.g. {"path": "foo.py"}


@dataclass
class Response:
    """Normalized model response: a text reply, a set of tool calls, or both."""
    content: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)

    @property
    def wants_to_use_tools(self) -> bool:
        return bool(self.tool_calls)

    @property
    def is_final(self) -> bool:
        """The loop ENDS when the model replies with NO tool calls."""
        return not self.wants_to_use_tools


class ModelClient:
    """Thin OpenAI-compatible chat-completions client for GLM 5.2."""

    def __init__(self, base_url: str = BASE_URL, model: str = MODEL_ID, api_key: str = API_KEY):
        self.base_url = base_url
        self.model = model
        self.api_key = api_key

    def chat(self, messages: list[dict], tools: list[dict]) -> Response:
        """Send the conversation + tool catalog to the model, get back a Response.

        `messages` = full history (system, user, assistant, tool results).
        `tools`    = schema of available tools (see tools.py).
        """
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": 0,  # deterministic-ish; coding wants precision
        }
        # vLLM (and OpenAI) reject an empty tools array. Only include the field
        # if there's at least one tool.
        if tools:
            payload["tools"] = tools
        body = self._post("/chat/completions", payload)

        choice = body["choices"][0]
        msg = choice["message"]

        # Parse tool-call intents. NOTE: `arguments` comes back as a JSON
        # *string* in the OpenAI format, so we parse it to a dict here so the
        # agent loop can work with it cleanly.
        tool_calls = []
        for tc in msg.get("tool_calls") or []:
            try:
                args = json.loads(tc["function"]["arguments"])
            except (json.JSONDecodeError, KeyError):
                args = {}
            tool_calls.append(ToolCall(
                id=tc["id"],
                name=tc["function"]["name"],
                arguments=args,
            ))

        return Response(content=msg.get("content"), tool_calls=tool_calls)

    def _post(self, path: str, payload: dict) -> dict:
        url = f"{self.base_url}{path}"
        data = json.dumps(payload).encode()
        req = urllib.request.Request(url, data=data)
        req.add_header("Content-Type", "application/json")
        if self.api_key and self.api_key != "not-required":
            req.add_header("Authorization", f"Bearer {self.api_key}")
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            # Read the error body — vLLM returns helpful details on 400s
            error_body = e.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"HTTP {e.code} from {url}:\n{error_body[:500]}") from e


# =============================================================================
#  OpenCodeModelClient — the fallback when direct HTTP is firewalled
# =============================================================================
# On this machine, python.exe can't reach 10.10.109.101:8080 (firewall) and
# can't resolve any hostname (no DNS). But OpenCode's background service CAN
# reach GLM-5.2 (it's what's running this very session).
#
# So this client routes model calls THROUGH OpenCode's API:
#   Python → opencode.cmd → POST /api/session/{active}/generate → GLM-5.2 → text
#
# THE CATCH: OpenCode's generate endpoint is text-in/text-out. It takes a single
# `prompt` string and returns text. No `messages` array, no `tools` parameter,
# no native tool-calling. So this client implements a TEXT-BASED TOOL PROTOCOL:
#
#   1. Flatten the messages array + tool catalog into one text prompt
#   2. Instruct the model to respond with JSON when it wants to call a tool
#   3. Parse the text response back into a Response object (tool_calls or content)
#
# This is how ALL agents worked before OpenAI introduced function calling in
# June 2023. It's less reliable than native tool-calling (the model might
# produce malformed JSON) but it works and is well-understood. The agent loop
# in agent.py doesn't know or care — it still calls model.chat() and gets a
# Response. The text-based protocol is fully hidden inside this class.
# =============================================================================
import os
import re
import subprocess


class OpenCodeModelClient:
    """Model client that routes through OpenCode's session API via subprocess.

    Use this when direct HTTP to the GLM endpoint is blocked. It calls
    `opencode api post /api/session/{id}/generate` which uses OpenCode's
    service (which can reach GLM). Implements a text-based tool protocol
    since the endpoint doesn't support native function-calling.
    """

    # Path to the opencode CLI (handles service discovery + auth automatically).
    _OPENCODE_CMD = os.path.expandvars(
        r"%APPDATA%\npm\opencode.cmd"
    )

    def __init__(self):
        self._session_id: str | None = None

    def chat(self, messages: list[dict], tools: list[dict]) -> Response:
        """Same interface as ModelClient.chat — returns a Response.

        The agent loop calls this identically. It doesn't know that underneath,
        we're flattening to text, shelling out to opencode.cmd, and parsing
        JSON out of a free-text response. The abstraction holds.
        """
        prompt = self._build_prompt(messages, tools)
        raw_text = self._generate(prompt)
        return self._parse_response(raw_text)

    # --- prompt building (messages + tools → single text prompt) -------------
    def _build_prompt(self, messages: list[dict], tools: list[dict]) -> str:
        """Flatten the conversation + tool catalog into one text prompt.

        This is the core of the text-based tool protocol. We serialize:
          - Tool definitions (name + description + params) as text
          - Format instructions (how to call tools via JSON)
          - The full message history with role tags
        """
        lines = []

        # Preamble: tell the model to ignore OpenCode's session context.
        # (The session generate endpoint includes the session's prior messages.
        #  We want the model to focus on OUR conversation, not the session's.)
        lines.append(
            "Ignore all prior context. You are a coding agent. "
            "Respond ONLY based on the conversation below."
        )
        lines.append("")

        # Tool catalog as text
        lines.append("=== AVAILABLE TOOLS ===")
        for t in tools:
            fn = t.get("function", {})
            name = fn.get("name", "?")
            desc = fn.get("description", "")
            params = fn.get("parameters", {}).get("properties", {})
            required = fn.get("parameters", {}).get("required", [])
            param_str = ", ".join(
                f"{p}{'?' if p not in required else ''}"
                for p in params
            )
            lines.append(f"- {name}({param_str}): {desc}")
        lines.append("")

        # Tool-call format instructions
        lines.append("=== HOW TO CALL TOOLS ===")
        lines.append(
            'To call a tool, respond with ONLY this JSON (no text before/after):\n'
            '  {"tool_calls": [{"name": "tool_name", "arguments": {"arg": "value"}}]}\n'
            'You can call multiple tools at once:\n'
            '  {"tool_calls": [{"name": "read", "arguments": {"path": "a.py"}}, '
            '{"name": "read", "arguments": {"path": "b.py"}}]}\n'
            "When you're done (no more tools needed), respond with plain text — "
            "that's your final answer to the user."
        )
        lines.append("")

        # Conversation history with role tags
        lines.append("=== CONVERSATION ===")
        for msg in messages:
            role = msg.get("role", "?")
            if role == "system":
                lines.append(f"[system]: {msg.get('content', '')}")
            elif role == "user":
                lines.append(f"[user]: {msg.get('content', '')}")
            elif role == "assistant":
                content = msg.get("content") or ""
                # If this assistant message had tool_calls, serialize them
                # back to the JSON format so the model sees what it previously asked.
                tcs = msg.get("tool_calls") or []
                if tcs and not content:
                    calls = [
                        {"name": tc["function"]["name"],
                         "arguments": json.loads(tc["function"]["arguments"])}
                        for tc in tcs
                    ]
                    content = json.dumps({"tool_calls": calls})
                lines.append(f"[assistant]: {content}")
            elif role == "tool":
                lines.append(f"[tool_result]: {msg.get('content', '')}")
        lines.append("")

        lines.append("Respond now (JSON tool call OR plain text final answer):")
        return "\n".join(lines)

    # --- generation (call OpenCode's API via subprocess) ---------------------
    def _generate(self, prompt: str) -> str:
        """Call opencode api to generate text via the active session.

        Retries up to 3 times on failure (the session API can be flaky on
        longer prompts). Raises RuntimeError if all retries fail.
        """
        sid = self._get_session_id()
        body = json.dumps({"prompt": prompt})

        last_error = ""
        for attempt in range(3):
            try:
                result = subprocess.run(
                    [self._OPENCODE_CMD, "api", "post",
                     f"/api/session/{sid}/generate", "-d", body],
                    capture_output=True, text=True, timeout=180
                )
                # Check for subprocess-level failure
                if result.returncode != 0:
                    last_error = f"exit {result.returncode}: {result.stderr.strip()[:200]}"
                    if attempt < 2:
                        import time; time.sleep(2)
                        continue
                    raise RuntimeError(f"opencode api failed: {last_error}")

                stdout = result.stdout.strip()
                if not stdout:
                    last_error = "empty response from opencode api"
                    if attempt < 2:
                        import time; time.sleep(2)
                        continue
                    raise RuntimeError(last_error)

                # Parse the JSON response: {"data":{"text":"..."}}
                resp = json.loads(stdout)
                text = resp.get("data", {}).get("text", "")
                if not text:
                    # The API might return an error object instead
                    if "_tag" in resp or "message" in resp:
                        raise RuntimeError(f"API error: {resp}")
                    last_error = f"no text in response: {stdout[:200]}"
                    if attempt < 2:
                        import time; time.sleep(2)
                        continue
                return text

            except json.JSONDecodeError:
                last_error = f"non-JSON stdout: {stdout[:200]}"
                if attempt < 2:
                    import time; time.sleep(2)
                    continue
                raise RuntimeError(f"opencode api returned non-JSON: {last_error}")

        raise RuntimeError(f"opencode api failed after 3 retries: {last_error}")

    def _get_session_id(self) -> str:
        """Get (and cache) the active OpenCode session ID.

        The active session has GLM-5.2 connected and working. New sessions
        can't use GLM (it's 'unavailable' through the API), so we MUST reuse
        the active one.
        """
        if self._session_id:
            return self._session_id

        result = subprocess.run(
            [self._OPENCODE_CMD, "api", "get", "/api/session/active"],
            capture_output=True, text=True, timeout=15
        )
        if result.returncode != 0:
            raise RuntimeError(f"can't find active session: {result.stderr[:200]}")

        resp = json.loads(result.stdout)
        sessions = resp.get("data", {})
        if not sessions:
            raise RuntimeError("no active OpenCode session found")

        # The response is {data: {ses_xxx: {type: "running"}}}
        self._session_id = list(sessions.keys())[0]
        return self._session_id

    # --- response parsing (text → Response with tool_calls or content) -------
    def _parse_response(self, text: str) -> Response:
        """Extract tool calls from the model's text response.

        The model was instructed to respond with JSON for tool calls. But it's
        a text model — it might add prose, forget closing brackets, or just
        return plain text. We handle all cases:

          1. Clean JSON:  {"tool_calls": [...]}
          2. JSON + prose: "Let me read that.\n{"tool_calls": [...]}"
          3. Plain text:   "Fixed the bugs. Here's what I changed..."
          4. Malformed:    {"tool_calls": [{"name": "read", "arguments": ...

        Strategy: try to find and parse a JSON object containing "tool_calls".
        If we can't, treat the whole text as a final answer.
        """
        # Strategy 1: the entire text is valid JSON
        try:
            obj = json.loads(text.strip())
            if isinstance(obj, dict) and "tool_calls" in obj:
                return self._build_response(obj["tool_calls"])
        except json.JSONDecodeError:
            pass

        # Strategy 2: find a {"tool_calls": ...} JSON block embedded in text
        # Look for the pattern and try to parse from there to the matching close.
        match = re.search(r'\{"tool_calls"\s*:', text)
        if match:
            # Try to extract the JSON starting from the match position.
            # We use a brace-matching scan to find the closing brace.
            start = match.start()
            depth = 0
            for i in range(start, len(text)):
                if text[i] == '{':
                    depth += 1
                elif text[i] == '}':
                    depth -= 1
                    if depth == 0:
                        try:
                            obj = json.loads(text[start:i + 1])
                            if "tool_calls" in obj:
                                return self._build_response(obj["tool_calls"])
                        except json.JSONDecodeError:
                            pass
                        break

        # Strategy 3: no tool calls found — this is a final text answer
        return Response(content=text.strip())

    def _build_response(self, raw_calls: list) -> Response:
        """Convert parsed JSON tool-call dicts into ToolCall objects."""
        tool_calls = []
        for i, c in enumerate(raw_calls):
            if not isinstance(c, dict):
                continue
            name = c.get("name", "")
            args = c.get("arguments", {})
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {}
            tool_calls.append(ToolCall(
                id=f"call_{i}",   # synthetic ID (no real one from the API)
                name=name,
                arguments=args if isinstance(args, dict) else {},
            ))
        return Response(content=None, tool_calls=tool_calls)
