"""The permission system: the safety layer between the model's intents and real execution.

WHY THIS EXISTS:
The model emits tool-call INTENTS. The agent's _dispatch() runs them. But some
tools are destructive (edit, write, shell) — once run, they can't be undone.
A model that's confused or hallucinating could delete files, run harmful
commands, or break working code.

The permission system sits between _dispatch and the actual tool execution.
For dangerous tools, it pauses and asks the human: "is this OK?" The human is
the final governor — the live oversight that prevents bad actions from
becoming real damage.

DESIGN:
- Read-only tools (read, grep, list_symbols, etc.) NEVER need approval.
- Mutating tools (edit, write, shell) ALWAYS need approval (by default).
- The human can: approve once, approve-always (for this tool this session),
  or deny.
- Denied actions return a tool result explaining the denial — the model sees
  it and adapts (asks why, tries a different approach, etc.).
- An --auto flag bypasses all prompts (for scripting/CI, like OpenCode's --auto).

THE GOVERNANCE LAYER:
This is the "harness" layer from our earlier conversation about who governs
the model's reasoning. Training/system-prompt/skills shape the model's
THOUGHTS. The permission system shapes its ACTIONS. Even if the model reasons
its way to "delete everything," this gate stops it from actually doing so.
Reasoning is free; action is gated.
"""
from __future__ import annotations

import shlex
from config import PERMISSION_REQUIRED


# Commands/patterns that get an EXTRA warning in the shell approval prompt.
# These are the "are you SURE?" cases — irreversible or far-reaching actions.
DANGEROUS_PATTERNS = [
    ("del ", "deletes files"),
    ("rm ", "deletes files (unix)"),
    ("rmdir ", "removes directories"),
    ("format ", "formats a disk"),
    ("shutdown", "shuts down the machine"),
    ("git push", "pushes to remote (hard to undo)"),
    ("git reset --hard", "discards uncommitted changes"),
    ("git clean", "deletes untracked files"),
    (">", "redirects/overwrites a file"),
    ("|", "pipes output (chains commands)"),
    ("&", "runs multiple commands"),
]


class PermissionSystem:
    """The gate between tool-call intents and real execution.

    Usage from agent.py:
        if self.permissions:
            allowed, message = self.permissions.check(name, args)
            if not allowed:
                return message   # model sees the denial, adapts
        # ... proceed to run the tool
    """

    def __init__(self, prompt_fn=None, auto_approve: bool = False):
        """
        prompt_fn: a callable(tool_name, args, formatted_action) -> str
                   returning "once", "always", or "deny".
                   In the REPL this reads from stdin. In a GUI it'd show a dialog.
                   If None, all approvals auto-deny (safest default).
        auto_approve: if True, bypass all prompts (CI/scripting mode).
                      Equivalent to OpenCode's --auto flag.
        """
        self.prompt_fn = prompt_fn
        self.auto_approve = auto_approve
        # Tools the user said "always" for, this session. Stored as a set of
        # tool names. Once added, that tool won't prompt again until restart.
        self._always_allowed: set[str] = set()
        # Track denials for stats/debugging.
        self.denied_count = 0
        self.approved_count = 0

    def check(self, tool_name: str, args: dict) -> tuple[bool, str]:
        """Decide whether a tool call may proceed.

        Returns (allowed, message):
          - (True, "")              → run the tool
          - (False, denial_message) → return the message as the tool result
                                      so the model sees WHY it was denied
        """
        # Read-only tools: always allowed, no prompt.
        if tool_name not in PERMISSION_REQUIRED:
            return True, ""

        # Auto-approve mode (CI/scripting): skip all prompts.
        if self.auto_approve:
            self.approved_count += 1
            return True, ""

        # Session-level "always allowed": user previously said "always" for
        # this tool. Skip the prompt but still let it through.
        if tool_name in self._always_allowed:
            self.approved_count += 1
            return True, ""

        # No prompt function configured: safest default is to deny.
        # (This shouldn't happen in the REPL, but prevents silent execution
        # if the permission system is misconfigured.)
        if self.prompt_fn is None:
            self.denied_count += 1
            return False, (f"PERMISSION DENIED: no approval mechanism configured "
                           f"for '{tool_name}'. Cannot run without human approval.")

        # Format the action for the human to review.
        formatted = self._format_action(tool_name, args)

        # Ask the human.
        decision = self.prompt_fn(tool_name, args, formatted)

        if decision == "always":
            self._always_allowed.add(tool_name)
            self.approved_count += 1
            return True, ""
        elif decision == "once":
            self.approved_count += 1
            return True, ""
        else:  # "deny" or anything else
            self.denied_count += 1
            return False, self._denial_message(tool_name, args)

    def _format_action(self, tool_name: str, args: dict) -> str:
        """Produce a human-readable summary of what the tool is about to do.

        Tool-specific formatting makes the approval prompt readable:
          edit  → show what's being replaced (truncated)
          write → show path + content size
          shell → show the command + danger warnings
        """
        if tool_name == "edit":
            path = args.get("path", "?")
            old = args.get("old_string", "")
            new = args.get("new_string", "")
            return (f"edit {path}\n"
                    f"  find:    {self._truncate(old, 100)}\n"
                    f"  replace: {self._truncate(new, 100)}")

        elif tool_name == "write":
            path = args.get("path", "?")
            content = args.get("content", "")
            return f"write {path} ({len(content)} chars)"

        elif tool_name == "shell":
            cmd = args.get("command", "")
            warnings = self._shell_warnings(cmd)
            base = f"shell: {cmd}"
            if warnings:
                base += "\n  [!] " + "; ".join(warnings)
            return base

        else:
            # Generic fallback: show args as truncated JSON-ish.
            return f"{tool_name}({args})"

    def _shell_warnings(self, cmd: str) -> list[str]:
        """Flag shell commands that are especially dangerous.

        This is a heuristic — it can't catch every dangerous command, but it
        draws attention to the obviously risky ones (deletions, pushes, etc.).
        The human still makes the final call.
        """
        warnings = []
        for pattern, risk in DANGEROUS_PATTERNS:
            if pattern in cmd:
                warnings.append(f"{risk}")
        return warnings

    def _denial_message(self, tool_name: str, args: dict) -> str:
        """The message the model sees when an action is denied.

        This is important: denial isn't a crash. The model gets a clear
        explanation and can adapt — ask the user why, try a different
        approach, or abandon the task. The feedback loop stays intact.
        """
        path = args.get("path", args.get("command", ""))
        return (f"PERMISSION DENIED: The user declined to run `{tool_name}`"
                f"{f' on {path}' if path else ''}. "
                f"You can ask the user why, or try a different approach.")

    @staticmethod
    def _truncate(s: str, n: int) -> str:
        """Truncate a string to n chars, with ellipsis."""
        s = s.replace("\n", "\\n")
        return s if len(s) <= n else s[:n] + "..."

    def stats(self) -> str:
        """Session stats for debugging/transparency."""
        return (f"permissions: {self.approved_count} approved, "
                f"{self.denied_count} denied, "
                f"{len(self._always_allowed)} always-allowed: "
                f"{sorted(self._always_allowed)}")
