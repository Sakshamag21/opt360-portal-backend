"""Entry point: an interactive REPL.

Usage:
  python main.py            # interactive mode, asks before destructive actions
  python main.py --auto     # auto-approve everything (for scripting/CI)
  python main.py --no-perms # skip permission checks entirely (UNSAFE)

Then type coding tasks. The agent runs the loop and replies. Type 'exit' to quit.
"""
import sys

from agent import Agent
from permissions import PermissionSystem

# Try direct HTTP first (works if network is available). Fall back to routing
# through OpenCode's session API (works when the GLM endpoint is firewalled).
try:
    from model import ModelClient, OpenCodeModelClient
    # Quick connectivity check: can we reach the GLM endpoint directly?
    import urllib.request
    import config
    try:
        urllib.request.urlopen(
            f"{config.BASE_URL}/models", timeout=3
        )
        _client = ModelClient()       # direct HTTP works
        print("[model] direct HTTP to GLM-5.2")
    except Exception:
        _client = OpenCodeModelClient()  # fall back to OpenCode session API
        print("[model] routing through OpenCode session API (GLM-5.2)")
except Exception as e:
    print(f"[model] failed to initialize: {e}")
    raise


def prompt_for_approval(tool_name: str, args: dict, formatted_action: str) -> str:
    """The REPL's approval prompt. Asks the human before destructive actions.

    This is the function the PermissionSystem calls when it needs a decision.
    In the REPL we read from stdin. A GUI version would show a dialog instead.
    Returns: "once", "always", or "deny".
    """
    print(f"\n  +-- APPROVAL NEEDED -------------------------")
    for line in formatted_action.splitlines():
        print(f"  | {line}")
    print(f"  +---------------------------------------------")
    print(f"     [y]es once  [a]lways (skip for {tool_name})  [n]o (deny)")
    while True:
        try:
            choice = input("  > ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return "deny"
        if choice in ("y", "yes"):
            return "once"
        if choice in ("a", "always"):
            return "always"
        if choice in ("n", "no"):
            return "deny"
        print("     enter y / a / n")


def main():
    # Parse flags
    auto = "--auto" in sys.argv
    no_perms = "--no-perms" in sys.argv

    print("=" * 60)
    print("  coding-agent  -  powered by GLM-5.2")
    if auto:
        print("  mode: AUTO-APPROVE (all actions run without asking)")
    elif no_perms:
        print("  mode: NO PERMISSIONS (unsafe — for testing only)")
    else:
        print("  mode: interactive (asks before edit/write/shell)")
    print("  type a coding task, or 'exit' to quit")
    print("=" * 60)

    # Build the permission system
    if no_perms:
        perms = None
    else:
        perms = PermissionSystem(
            prompt_fn=prompt_for_approval if not auto else None,
            auto_approve=auto,
        )

    agent = Agent(_client, permissions=perms)

    while True:
        try:
            goal = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not goal:
            continue
        if goal.lower() in {"exit", "quit"}:
            break

        try:
            answer = agent.run(goal)
            # Windows console uses cp1252; safely print Unicode.
            print("\n[DONE]")
            print(answer.encode("cp1252", errors="replace").decode("cp1252"))
            if perms:
                print(f"[stats] {perms.stats()}")
        except Exception as e:
            print(f"\n[ERROR] agent error: {type(e).__name__}: {e}")


if __name__ == "__main__":
    main()
