"""The CodeGraph: structural map of a codebase (symbols + call graph).

THE TWO-LAYER DESIGN (read this carefully — it's the point of this file):

A coding agent that navigates by line numbers ("read lines 20-28") is fragile.
A coding agent that navigates by SYMBOL ("show me `median`'s callers") is robust.
This module builds the symbol map that makes the latter possible.

Layer 1 — STRUCTURE (this file, exact, cached, no LLM):
    Parse every source file into a list of Symbols (functions, classes, methods).
    For each function, record which other functions it CALLS.
    Build a call graph: who-calls-whom. Persist to disk; refresh only changed
    files (by mtime). This is pure parsing — deterministic, cheap, exact.

Layer 2 — SUMMARY (lives in tools.py, approximate, LLM-generated, cached):
    One-line descriptions per symbol. "median -> returns the middle value of a
    sorted list." Generated on demand by the LLM, cached to disk, invalidated
    when the source changes. This is the only place the LLM touches the graph.

WHY AN INTERFACE + TWO IMPLEMENTATIONS:
    tree-sitter is the ideal parser (multi-language, error-tolerant, fast) but
    it's an external dependency. If it can't be installed (locked-down machine,
    missing wheel), the agent should still work. So:

        SymbolExtractor (interface)
            |
            +-- TreeSitterExtractor   <- preferred; activates if importable
            +-- AstExtractor          <- stdlib fallback for Python

    The CodeGraph calls `extractor.parse(text)` and doesn't know or care which
    one is running. Adding a new parser (e.g. a regex one for an obscure
    language) means adding one class, not touching CodeGraph. That decoupling
    is the whole reason for the abstraction.

CALL GRAPH HONESTY:
    The call graph is NAME-BASED and APPROXIMATE. It matches a call like `foo()`
    to any symbol named `foo` in the index. It does NOT handle:
      - method dispatch / polymorphism (which `foo()` for `obj.foo()`?)
      - imported renames (`from m import foo as bar`)
      - dynamic calls (`getattr(obj, name)()`)
    It's a navigation aid ("show me plausible callers"), not a semantic proof.
    Real IDEs have the same limitation without full type inference.
"""
from __future__ import annotations

import ast
import hashlib
import json
from dataclasses import dataclass, field, asdict
from pathlib import Path

# --- optional dependency: tree-sitter ---------------------------------------
# We try to import it. If it's not there, TreeSitterExtractor is just a stub
# that raises on use, and get_extractor() falls back to AstExtractor for .py.
try:
    from tree_sitter_languages import get_parser, get_language  # type: ignore
    _TS_AVAILABLE = True
except ImportError:
    _TS_AVAILABLE = False


# =============================================================================
#  The Symbol: one node in the graph
# =============================================================================
@dataclass
class Symbol:
    """A function, method, or class discovered in a source file.

    `calls` is the list of names this symbol invokes in its body. The CodeGraph
    uses it to build edges. Empty for classes (a class itself doesn't "call").
    """
    name: str
    kind: str            # "function" | "method" | "class"
    path: str
    start_line: int      # 1-based, inclusive
    end_line: int        # 1-based, inclusive
    signature: str       # e.g. "def median(numbers: List[float]) -> float"
    calls: list[str] = field(default_factory=list)
    parent: str | None = None   # enclosing class name, for methods

    @property
    def qualname(self) -> str:
        """Qualified name: 'ClassName.method_name' for methods, else just name."""
        return f"{self.parent}.{self.name}" if self.parent else self.name

    def source(self, lines: list[str]) -> str:
        """Slice the symbol's source out of the file's line list."""
        return "\n".join(lines[self.start_line - 1: self.end_line])


# =============================================================================
#  The interface
# =============================================================================
class SymbolExtractor:
    """Abstract parser. Subclasses turn source text into a list of Symbols."""

    def parse(self, source: str, path: str) -> list[Symbol]:
        raise NotImplementedError


# =============================================================================
#  Implementation 1: tree-sitter (preferred, multi-language)
# =============================================================================
# File extension -> tree-sitter grammar name. Add entries to support more langs.
_TS_GRAMMARS = {
    ".py": "python",
    ".js": "javascript",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".go": "go",
    ".rs": "rust",
    ".rb": "ruby",
    ".c": "c",
    ".cpp": "cpp",
}

# tree-sitter queries. Only Python is fleshed out here; extend per-grammar.
# Each query returns captures: 'func' (function_definition node),
# 'cls' (class_definition node), 'name' (the identifier).
_TS_QUERIES = {
    "python": """
        (function_definition name: (identifier) @name) @func
        (class_definition name: (identifier) @name) @cls
        (call function: [(identifier) @callee
                         (attribute attribute: (identifier) @callee)])
    """,
}


def _normalize_captures(caps) -> dict[str, list]:
    """tree-sitter's query.captures() returns DIFFERENT shapes across versions:
      - older (tree-sitter-languages): dict {capture_name: [nodes]}
      - newer (tree-sitter >= 0.22):    list of (node, capture_name) tuples
    This helper normalizes both to the dict form so the rest of the code is
    version-agnostic. Defensive code like this is normal in agent tooling —
    dependencies churn, and you don't want your agent to break on an upgrade.
    """
    if isinstance(caps, dict):
        return caps
    out: dict[str, list] = {}
    if isinstance(caps, list):
        for item in caps:
            # tolerate both (node, name) and (name, node) orderings defensively
            if isinstance(item, tuple) and len(item) == 2:
                node, name = item
                out.setdefault(name, []).append(node)
    return out


class TreeSitterExtractor(SymbolExtractor):
    """tree-sitter-based extractor. Multi-language, error-tolerant, fast.

    NOTE: tree-sitter is error-tolerant — it parses broken code into a partial
    tree with ERROR nodes, rather than refusing. This matters for a coding
    agent: you often need to navigate code that doesn't currently compile.
    """

    def __init__(self, grammar: str):
        self.grammar = grammar
        self.parser = get_parser(grammar)
        self.language = get_language(grammar)
        self.query_src = _TS_QUERIES.get(grammar)
        if not self.query_src:
            raise ValueError(f"no tree-sitter query defined for grammar '{grammar}'")

    def parse(self, source: str, path: str) -> list[Symbol]:
        tree = self.parser.parse(source.encode("utf-8"))
        q = self.language.query(self.query_src)
        caps = _normalize_captures(q.captures(tree.root_node))

        funcs = caps.get("func", [])
        classes = caps.get("cls", [])
        # name captures line up positionally with func/cls nodes in our query.
        names = caps.get("name", [])

        symbols: list[Symbol] = []
        # Map func/cls nodes to their name by index alignment.
        # (This is query-dependent; a production version would query each kind
        # separately. Kept simple here for readability.)
        for node, name_node in zip(funcs + classes, names):
            kind = "function" if node in funcs else "class"
            name = name_node.text.decode("utf-8")
            symbols.append(Symbol(
                name=name,
                kind=kind,
                path=path,
                start_line=node.start_point[0] + 1,   # tree-sitter is 0-based
                end_line=node.end_point[0] + 1,
                signature=self._signature(source, node),
                calls=self._calls_in(node),
            ))
        return symbols

    def _calls_in(self, func_node) -> list[str]:
        """Walk a function node's subtree, collecting every call's callee name."""
        callees: list[str] = []
        stack = [func_node]
        seen = set()
        while stack:
            n = stack.pop()
            if n.type == "call":
                fn = n.child_by_field_name("function")
                if fn is not None:
                    # foo()  ->  fn.text == b"foo"
                    # obj.bar()  ->  fn is an attribute node; take its attribute field
                    if fn.type == "attribute":
                        attr = fn.child_by_field_name("attribute")
                        if attr is not None:
                            callees.append(attr.text.decode("utf-8"))
                    else:
                        callees.append(fn.text.decode("utf-8"))
            for child in n.children:
                if id(child) not in seen:
                    seen.add(id(child))
                    stack.append(child)
        # de-dup, preserve order
        out = []
        for c in callees:
            if c not in out:
                out.append(c)
        return out

    def _signature(self, source: str, node) -> str:
        """Best-effort first-line signature (def/class ... line)."""
        line = source.splitlines()[node.start_point[0]] if source.splitlines() else ""
        return line.strip()


# =============================================================================
#  Implementation 2: Python stdlib `ast` (fallback, Python-only)
# =============================================================================
class AstExtractor(SymbolExtractor):
    """Pure-stdlib Python parser. No external dependencies.

    This is the fallback when tree-sitter isn't installed. For Python it's
    nearly as precise as tree-sitter (it IS the official Python parser) with
    two caveats: (a) only Python; (b) requires syntactically valid code
    (tree-sitter tolerates errors; `ast.parse` raises SyntaxError).
    """

    def parse(self, source: str, path: str) -> list[Symbol]:
        try:
            tree = ast.parse(source)
        except SyntaxError:
            # Can't parse broken code. Return empty; the agent falls back to
            # reading the file as text. tree-sitter would have handled this.
            return []
        lines = source.splitlines()
        symbols: list[Symbol] = []

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                symbols.append(self._func_symbol(node, path, lines))
            elif isinstance(node, ast.AsyncFunctionDef):
                symbols.append(self._func_symbol(node, path, lines, is_async=True))
            elif isinstance(node, ast.ClassDef):
                symbols.append(self._class_symbol(node, path, lines))
        return symbols

    def _func_symbol(self, node, path, lines, is_async: bool = False) -> Symbol:
        # Determine parent class (if this is a method) by re-checking: ast.walk
        # flattens, so we mark methods via a separate pass below. Here we leave
        # parent=None; the class pass sets it for methods.
        sig = self._signature_line(lines, node.lineno)
        return Symbol(
            name=node.name,
            kind="function",
            path=path,
            start_line=node.lineno,
            end_line=getattr(node, "end_lineno", node.lineno),
            signature=sig,
            calls=self._calls_in(node),
            parent=None,   # may be patched by _class_symbol
        )

    def _class_symbol(self, node, path, lines) -> Symbol:
        sig = self._signature_line(lines, node.lineno)
        cls = Symbol(
            name=node.name,
            kind="class",
            path=path,
            start_line=node.lineno,
            end_line=getattr(node, "end_lineno", node.lineno),
            signature=sig,
            calls=[],
            parent=None,
        )
        # Patch methods inside this class: set their kind and parent.
        for child in node.body:
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                # find the matching symbol already collected (by line range)
                # We do this in a second pass in parse(); simpler: rebuild here.
                pass
        return cls

    def _calls_in(self, func_node) -> list[str]:
        """Collect callee names from an ast function node's body."""
        callees: list[str] = []
        for n in ast.walk(func_node):
            if isinstance(n, ast.Call):
                f = n.func
                if isinstance(f, ast.Name):
                    callees.append(f.id)               # foo()
                elif isinstance(f, ast.Attribute):
                    callees.append(f.attr)             # obj.bar() -> "bar"
        out = []
        for c in callees:
            if c not in out:
                out.append(c)
        return out

    def _signature_line(self, lines, lineno) -> str:
        """Grab the `def`/`class` line as the signature."""
        if 1 <= lineno <= len(lines):
            return lines[lineno - 1].strip()
        return ""


def get_extractor(path: str) -> SymbolExtractor | None:
    """Pick the right extractor for a file. Returns None if unsupported.

    Selection order:
      1. If tree-sitter is importable AND we have a grammar for this extension,
         use TreeSitterExtractor (multi-language, error-tolerant).
      2. Else, for .py files, use AstExtractor (stdlib, Python-only).
      3. Else, None — the agent will read the file as plain text instead.
    """
    ext = Path(path).suffix.lower()
    if _TS_AVAILABLE:
        grammar = _TS_GRAMMARS.get(ext)
        if grammar:
            try:
                return TreeSitterExtractor(grammar)
            except Exception:
                pass  # fall through to ast if tree-sitter blows up
    if ext == ".py":
        return AstExtractor()
    return None


# =============================================================================
#  The CodeGraph: index + query layer
# =============================================================================
class CodeGraph:
    """Builds and queries the symbol map for a directory tree.

    PERSISTENCE: the index is cached at <root>/.codegraph/index.json. On
    re-index, only files whose mtime changed are re-parsed. Cheap refreshes.

    CALL GRAPH: edges are derived from each Symbol's `calls` list. We keep
    two views: forward (callees) and reverse (callers). Both are name-based
    and approximate — see the module docstring's honesty note.
    """

    def __init__(self, root: str = "."):
        self.root = Path(root).resolve()
        self.cache_dir = self.root / ".codegraph"
        self.cache_file = self.cache_dir / "index.json"
        # path -> {"mtime": float, "symbols": [Symbol-dicts]}
        self.files: dict[str, dict] = {}
        # symbol name -> list of paths that define it (may be >1: name reuse)
        self.symbol_index: dict[str, list[str]] = {}
        self.load()

    # --- indexing -----------------------------------------------------------
    def index(self, path: str | None = None) -> str:
        """Scan `path` (or the whole root) and (re)build the symbol map.

        Returns a one-line summary for the agent to read.
        """
        target = self.root if path is None else (self.root / path if not Path(path).is_absolute() else Path(path))
        files = self._discover(target)
        changed = 0
        for f in files:
            rel = str(f.relative_to(self.root))
            mtime = f.stat().st_mtime
            cached = self.files.get(rel)
            if cached and cached.get("mtime") == mtime:
                continue  # unchanged since last index — skip (cheap refresh)
            extractor = get_extractor(str(f))
            if extractor is None:
                continue  # unsupported extension — skip silently
            try:
                source = f.read_text(encoding="utf-8", errors="replace")
                syms = extractor.parse(source, rel)
            except Exception:
                continue  # parse failure shouldn't break the whole index
            self.files[rel] = {
                "mtime": mtime,
                "symbols": [asdict(s) for s in syms],
            }
            changed += 1
        self._rebuild_symbol_index()
        self.save()
        total_symbols = sum(len(v["symbols"]) for v in self.files.values())
        return f"indexed {changed} changed file(s); {len(self.files)} files, {total_symbols} symbols total"

    def _discover(self, target: Path) -> list[Path]:
        """Find source files under `target`, skipping junk dirs."""
        skip = {".git", "__pycache__", "node_modules", ".venv", "venv",
                ".codegraph", "dist", "build", ".idea", ".vscode"}
        supported_exts = set(_TS_GRAMMARS.keys()) | {".py"}
        out = []
        if target.is_file():
            return [target] if target.suffix.lower() in supported_exts else []
        for p in target.rglob("*"):
            if any(part in skip for part in p.parts):
                continue
            if p.is_file() and p.suffix.lower() in supported_exts:
                out.append(p)
        return out

    def _rebuild_symbol_index(self):
        """name -> [paths]. Lets find_callers / find_callees resolve quickly."""
        self.symbol_index.clear()
        for path, info in self.files.items():
            for s in info["symbols"]:
                self.symbol_index.setdefault(s["name"], []).append(path)

    # --- queries ------------------------------------------------------------
    def list_symbols(self, path: str) -> list[dict]:
        """All symbols in a file, with location + signature."""
        rel = self._rel(path)
        info = self.files.get(rel)
        return list(info["symbols"]) if info else []

    def get_symbol(self, path: str, name: str) -> str:
        """Return the full source text of one symbol."""
        rel = self._rel(path)
        info = self.files.get(rel)
        if not info:
            return f"ERROR: file not indexed: {path}"
        for s in info["symbols"]:
            if s["name"] == name:
                try:
                    lines = (self.root / rel).read_text(encoding="utf-8", errors="replace").splitlines()
                    src = "\n".join(lines[s["start_line"] - 1: s["end_line"]])
                    return f"# {s['kind']} {s['name']}  ({rel}:{s['start_line']}-{s['end_line']})\n{src}"
                except Exception as e:
                    return f"ERROR reading source: {e}"
        return f"ERROR: symbol '{name}' not found in {path}"

    def find_callers(self, name: str) -> str:
        """Who calls a symbol named `name`? (reverse call graph)."""
        hits = []
        for path, info in self.files.items():
            for s in info["symbols"]:
                if name in s.get("calls", []):
                    hits.append(f"{path}:{s['start_line']}  {s['kind']} {s['name']}")
        if not hits:
            return f"(no callers found for '{name}')"
        return f"Callers of '{name}' ({len(hits)}):\n" + "\n".join(hits)

    def find_callees(self, path: str, name: str) -> str:
        """What does the symbol `name` in `path` call? (forward call graph)."""
        rel = self._rel(path)
        info = self.files.get(rel)
        if not info:
            return f"ERROR: file not indexed: {path}"
        for s in info["symbols"]:
            if s["name"] == name:
                calls = s.get("calls", [])
                if not calls:
                    return f"'{name}' makes no calls."
                return f"'{name}' calls: {', '.join(calls)}"
        return f"ERROR: symbol '{name}' not found in {path}"

    def overview(self) -> str:
        """A compact map of the whole codebase — what the agent 'sees' first."""
        if not self.files:
            return "(graph empty — run index_code first)"
        lines = [f"CodeGraph: {len(self.files)} files, {sum(len(v['symbols']) for v in self.files.values())} symbols"]
        for path in sorted(self.files):
            syms = self.files[path]["symbols"]
            if not syms:
                continue
            lines.append(f"\n{path}:")
            for s in syms:
                kind_tag = {"function": "fn", "method": "mt", "class": "cls"}.get(s["kind"], s["kind"])
                calls = f"  -> {', '.join(s['calls'][:5])}" if s.get("calls") else ""
                lines.append(f"  [{kind_tag}] {s['name']}  L{s['start_line']}-{s['end_line']}{calls}")
        return "\n".join(lines)

    def file_index(self) -> str:
        """TIER 0: the minimal 'what files exist' index. Always injected.

        Just file names + symbol counts. No line ranges, no calls, no source.
        ~1 line per file. Lets the model know the codebase shape without
        burning context on detail it may never need. The model pulls
        per-file detail on demand via list_symbols (Tier 1).
        """
        if not self.files:
            return "(graph empty — run index_code first)"
        total = sum(len(v["symbols"]) for v in self.files.values())
        lines = [f"Codebase: {len(self.files)} files, {total} symbols"]
        for path in sorted(self.files):
            n = len(self.files[path]["symbols"])
            lines.append(f"  {path}  ({n} symbol{'s' if n != 1 else ''})")
        lines.append("")
        lines.append("Call list_symbols(path) for any file's symbol detail,")
        lines.append("get_symbol(path, name) for one function's source,")
        lines.append("find_callers(name) for cross-file impact analysis.")
        return "\n".join(lines)

    # --- persistence --------------------------------------------------------
    def save(self):
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.cache_file.write_text(json.dumps({
            "files": self.files,
        }, indent=2), encoding="utf-8")

    def load(self):
        if self.cache_file.exists():
            try:
                data = json.loads(self.cache_file.read_text(encoding="utf-8"))
                self.files = data.get("files", {})
                self._rebuild_symbol_index()
            except Exception:
                self.files = {}

    def _rel(self, path: str) -> str:
        p = Path(path)
        if not p.is_absolute():
            return path
        try:
            return str(p.relative_to(self.root))
        except ValueError:
            return path
