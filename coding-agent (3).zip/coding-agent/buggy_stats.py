"""A calculator for basic statistics on a list of numbers.

NOTE: This script has SEVERAL BUGS on purpose. Feed it to the coding agent and
watch the think-act-observe loop find and fix them one by one.

Run (when fixed):  python buggy_stats.py
"""
from typing import List


def mean(numbers: List[float]) -> float:
    """Return the average of a list of numbers."""
    if not numbers:
        raise ValueError("mean of an empty list is undefined")
    return sum(numbers) / len(numbers)


def median(numbers: List[float]) -> float:
    """Return the median value."""
    if not numbers:
        raise ValueError("median of an empty list is undefined")
    sorted_numbers = sorted(numbers)
    n = len(sorted_numbers)
    mid = n // 2
    if n % 2 == 1:
        return float(sorted_numbers[mid])
    return (sorted_numbers[mid - 1] + sorted_numbers[mid]) / 2


def mode(numbers: List[float]) -> float:
    """Return the most common value."""
    if not numbers:
        raise ValueError("mode of an empty list is undefined")
    counts = {}
    for num in numbers:
        counts[num] = counts.get(num, 0) + 1
    return max(counts, key=counts.get)


def variance(numbers: List[float]) -> float:
    """Return the population variance."""
    if not numbers:
        raise ValueError("variance of an empty list is undefined")
    n = len(numbers)
    m = mean(numbers)
    return sum((x - m) ** 2 for x in numbers) / n


def summarize(numbers: List[float]) -> dict:
    """Return a summary dict of all stats."""
    return {
        "mean": mean(numbers),
        "median": median(numbers),
        "mode": mode(numbers),
        "variance": variance(numbers),
    }


def main():
    # BUG 6: the input list is not sorted before being passed to median(),
    #        which combines with BUG 2 to produce a wrong median.
    data = [4, 1, 7, 3, 9, 2, 8, 5, 6]

    print("=== Statistics Summary ===")
    print(f"Data:      {data}")
    print(f"Count:     {len(data)}")
    print(f"Mean:      {mean(data)}")
    print(f"Median:    {median(data)}")
    print(f"Mode:      {mode(data)}")
    print(f"Variance:  {variance(data)}")
    print(f"Summary:   {summarize(data)}")

    # Bonus: empty input is now a handled error rather than a crash
    try:
        print("Empty mean:", mean([]))
    except ValueError as exc:
        print("Empty mean:", exc)


if __name__ == "__main__":
    main()
