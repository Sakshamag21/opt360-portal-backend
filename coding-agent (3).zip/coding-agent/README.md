# coding-agent

A minimal coding agent wrapped around the **GLM-5.2** model (the same endpoint
OpenCode uses). Built to be *read*, not just run — the goal is to make the
mechanics of a coding agent obvious from the code.

---

## Read the code in this order

This is the reading path that teaches you how an agent actually works.

### 1. `config.py` — the inputs
Two things live here: **where the model is** (endpoint + model id) and **who
the agent is** (the system prompt). The system prompt is the agent's job
description — it tells the model to work step-by-step, make minimal edits,
and verify before claiming done. The model re-reads this prompt on *every*
turn (it's the first message in context).

### 2. `model.py` — the brain (stateless!)
`ModelClient.chat(messages, tools)` sends the **entire conversation history**
plus the **tool catalog** to GLM-5.2 and returns a `Response`.

The crucial idea: **the model has no memory between calls.** The `messages`
list IS its memory. Each `chat()` call re-sends all of it. This is why the
agent loop (not the model) is responsible for growing that list turn by turn.

A `Response` is either:
- a final text answer (`is_final == True`), or
- a set of **tool-call intents** — the model *wants* to call tools but does
  not run them. It just says "I'd like to call `read` with `{"path":"foo.py"}`".

### 3. `tools.py` — the hands and eyes
Thirteen plain Python functions grouped into two tiers:

**File tools** (raw I/O): `read`, `write`, `edit`, `shell`, `grep`, `glob`.
Each is registered with a **JSON schema** (`TOOL_SPECS`) describing its name,
what it does, and what arguments it takes. The model reads those descriptions
to decide which tool fits its current need.

Notice: **tools return strings.** That return value goes back to the model as
a `role=tool` message — that's how the model "sees" what happened. The model
cannot touch the filesystem or shell directly; only these functions can, and
only the agent loop calls them.

The `edit` tool is worth a close look: it **fails loudly** if the search text
isn't found or isn't unique. Those failures are *free correction signals* —
the model re-reads the file and retries. This is how an imprecise model lands
on precise edits.

**Structural tools** (symbol navigation, powered by `codegraph.py`):
`index_code`, `graph_overview`, `list_symbols`, `get_symbol`, `find_callers`,
`find_callees`, `summarize_symbol`. These let the agent navigate by **symbol**
("show me `median`'s callers") instead of by line number. See `codegraph.py`
for how the symbol map is built. The `summarize_symbol` tool is the only one
that calls the LLM — it's the "summary layer" on top of the "structure layer."

### 3b. `codegraph.py` — the structural map (two-layer design)
THE TWO-LAYER DESIGN — the key idea in this file:

- **Structure layer** (this file, exact, cached, no LLM): parse every source
  file into Symbols (functions, classes, methods) with line ranges + a call
  graph. Pure parsing — deterministic, cheap, persisted to `.codegraph/`.
- **Summary layer** (in `tools.py::summarize_symbol`, LLM, lazy, cached):
  one-line plain-English descriptions per symbol, generated on demand and
  cached by source hash.

WHY AN INTERFACE + TWO IMPLEMENTATIONS:
tree-sitter is the ideal parser (multi-language, error-tolerant) but it's an
external dependency. If it can't be installed, the agent should still work:

```
SymbolExtractor (interface)
    |
    +-- TreeSitterExtractor   <- preferred; activates if importable
    +-- AstExtractor          <- stdlib fallback for Python
```

`CodeGraph` calls `extractor.parse(...)` and doesn't know which is running.
On this machine tree-sitter isn't installed (no PyPI access), so the `ast`
fallback handles all `.py` files — and it's nearly as precise, since `ast`
IS the official Python parser. Install tree-sitter later and it auto-activates
for Python *and* adds JS/TS/Go/Rust/C/C++ support — nothing else changes.

CALL GRAPH HONESTY: the call graph is **name-based and approximate**. A call
like `foo()` matches any symbol named `foo`. It does NOT resolve method
dispatch, imported renames, or dynamic calls. It's a navigation aid, not a
semantic proof — same limitation real IDEs have without full type inference.

### 4. `agent.py` — THE LOOP (the centerpiece)
This is the whole point. Read the file header first — it diagrams the ReAct
pattern. Then read `Agent.run()`:

```
seed messages with the user goal
for each step (up to MAX_ITERATIONS):
    1. THINK    -> response = model.chat(messages, tools)
    2. DECIDE   -> if response.is_final: return the answer
    3. ACT      -> for each tool call: result = _dispatch(name, args)
    4. OBSERVE  -> append {"role":"tool", "content": result} to messages
    5. LOOP     -> back to 1, with the new observations in context
```

Three things to internalize:

- **(a) The model never executes anything.** It emits intents; `_dispatch()` is
  the *only* execution path. Centralizing it here is what makes tools auditable
  and (in a real agent) easy to gate behind permission prompts.
- **(b) The model is stateless; `messages` is the memory.** Every tool result
  appended in step 4 is what the model "remembers" next turn.
- **(c) Observation changes reasoning.** When a tool returns an error, the
  model sees it and adjusts. This feedback is what makes the loop **converge**
  on a correct result instead of guessing once and being wrong.

### 5. `main.py` — the REPL
Trivial on purpose. Reads a goal, calls `agent.run(goal)`, prints the answer.
All the interesting behavior is in `agent.py`.

---

## How the pieces fit (one diagram)

```
        ┌───────────────────────────────────────────────────────┐
        │  main.py  (REPL: read goal, print answer)             │
        │         │                                             │
        │         ▼                                             │
        │     agent.py  ───── THE LOOP ─────                    │
        │     ┌─────────────────────────────────┐               │
        │     │ 1. THINK:  model.chat(...)      │               │
        │     │ 2. DECIDE: final? -> return     │               │
        │     │ 3. ACT:    _dispatch(name,args) │──▶ tools.py   │
        │     │ 4. OBSERVE: append tool result  │   (file tools │
        │     │ 5. LOOP                        │    + struct.  │
        │     └─────────────────────────────────┘    tools)    │
        │         │ calls                          ▲           │
        │         ▼                                 │          │
        │     model.py  (ModelClient -> GLM-5.2)    │          │
        │                                          │          │
        │     codegraph.py ◀─── struct. tools ─────┘          │
        │       (SymbolExtractor: tree-sitter OR ast)          │
        │         │                                             │
        │         ▼                                             │
        │     config.py  (endpoint + system prompt)             │
        └───────────────────────────────────────────────────────┘
```

---

## Run it

```sh
cd C:\coding-agent
python test_api.py     # first: confirm the endpoint is reachable
python main.py         # then: the REPL
```

Then try a task like:
```
> list the files in this directory and tell me what each does
> create a file hello.py that prints "hello world", then run it
```

You'll see `— step 1 —`, `— step 2 —`, ... print as the loop turns, plus a
`-> toolname(args)` line for each tool call. That visible stepping IS the
agent loop — watch the model think, act, observe, repeat.

---

## Troubleshooting

**`python test_api.py` times out** — the GLM endpoint (`10.10.109.101:8080`)
is reachable from OpenCode's background service but may be firewalled against
direct `python.exe` connections on this machine. Two fixes:
1. Add a firewall exception for python.exe (needs admin), or
2. Switch `model.py` to call GLM *through* OpenCode's HTTP API instead of
   directly (OpenCode acts as the model gateway). This is a small change to
   `ModelClient._post` only — the rest of the agent is untouched, because the
   model access is fully isolated behind that one class.

**Structural tools work but report "ast (stdlib fallback)"** — tree-sitter
isn't installed (PyPI was unreachable on this machine). The agent fully
functions using Python's built-in `ast` module for `.py` files. To enable
tree-sitter (multi-language + error-tolerant parsing), install on a machine
with PyPI access:
```sh
pip install tree-sitter tree-sitter-languages
```
It auto-activates on next run — `codegraph._TS_AVAILABLE` flips to `True` and
`get_extractor()` prefers `TreeSitterExtractor` for `.py`, `.js`, `.ts`, `.go`,
`.rs`, `.rb`, `.c`, `.cpp`. No code changes needed.

**The model calls a tool with wrong arguments** — `_dispatch` catches the
`TypeError` and returns an error string. The model sees it and retries with
correct args. That's the feedback loop doing its job; no crash.

**The loop runs forever** — `MAX_ITERATIONS` (in `config.py`) caps it at 25
steps. Bump it for big tasks, lower it for safety.

---

## What's deliberately NOT here (next steps)

This is an MVP. A production agent adds:
- **Permission prompts** before destructive tools (`write`, `edit`, `shell`).
- **Context trimming** — `messages` grows unbounded here; real agents summarize
  or drop old turns to fit the model's context window.
- **Subagents** — spawn a child loop with fresh context for exploration.
- **Diff review** — re-read the edited region and self-check before declaring done.
- **Streaming** — show the model's text token-by-token instead of all at once.

Each of those is an additive change to one file; the core loop in `agent.py`
stays the same. That's the point of the clean separation.
