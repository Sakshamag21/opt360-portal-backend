"""A simple calculator module with bugs. Feed to the coding agent to fix.

Run:  python calc.py
"""
from typing import List


def add(a: float, b: float) -> float:
    """Return a + b."""
    # BUG 1: subtraction instead of addition
    return a - b


def multiply(a: float, b: float) -> float:
    """Return a * b."""
    # BUG 2: addition instead of multiplication
    return a + b


def max_of(numbers: List[float]) -> float:
    """Return the maximum value in a list."""
    # BUG 3: returns minimum instead of maximum
    result = numbers[0]
    for n in numbers:
        if n < result:
            result = n
    return result


def average(numbers: List[float]) -> float:
    """Return the average."""
    # BUG 4: crashes on empty list (no guard)
    return sum(numbers) / len(numbers)


def is_even(n: int) -> bool:
    """Return True if n is even."""
    # BUG 5: checks for odd instead of even
    return n % 2 == 1


def main():
    data = [3, 1, 4, 1, 5, 9, 2, 6]
    print("=== Calculator ===")
    print(f"add(2, 3)      = {add(2, 3)}        (should be 5)")
    print(f"multiply(2, 3) = {multiply(2, 3)}        (should be 6)")
    print(f"max_of(data)   = {max_of(data)}          (should be 9)")
    print(f"average(data)  = {average(data)}       (should be 3.875)")
    print(f"is_even(4)     = {is_even(4)}       (should be True)")
    print(f"average([])    = {average([])}  (should not crash)")


if __name__ == "__main__":
    main()
