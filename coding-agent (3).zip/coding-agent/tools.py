"""The agent's tools — its "hands and eyes".

FLOW PERSPECTIVE: every tool here is a plain Python function. The model cannot
call them directly. Instead:
  1. The model emits a tool-call intent (name + arguments).
  2. The agent loop (agent.py) looks up the function by name and runs it.
  3. The return value (always a STRING) is fed back to the model as a
     `role=tool` message. That's how the model "sees" what happened.

Each tool is described to the model by a JSON schema (TOOL_SPECS). The model
reads those descriptions to decide WHICH tool fits its current need. Good
descriptions = good tool use; vague ones = the model misuses tools.
"""
from __future__ import annotations

import fnmatch
import hashlib
import json
import re
import subprocess
from pathlib import Path

from codegraph import CodeGraph

# Each entry is the OpenAI function-tool shape: name, description, JSON schema.
TOOL_SPECS: list[dict] = []
TOOL_REGISTRY: dict[str, callable] = {}

# --- shared context (set by Agent.__init__) ----------------------------------
# The graph and model are injected here so the structural+summary tools below
# can use them. Keeping them as module globals (rather than passing through
# every call) keeps the tool signatures clean: the model sees simple args.
graph: CodeGraph | None = None
model = None  # ModelClient, set by Agent


def _tool(name: str, description: str, params: dict):
    """Decorator: register a function as an agent tool + record its schema."""
    def deco(fn):
        TOOL_REGISTRY[name] = fn
        TOOL_SPECS.append({
            "type": "function",
            "function": {
                "name": name,
                "description": description,
                "parameters": params,
            },
        })
        return fn
    return deco


# --- read ---------------------------------------------------------------------
_read_params = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "description": "Path to the file or directory to read."},
        "offset": {"type": "integer", "description": "1-based line to start at (optional)."},
        "limit": {"type": "integer", "description": "Max lines to read (optional)."},
    },
    "required": ["path"],
}


@_tool("read", "Read a file's contents (with line numbers) or list a directory.", _read_params)
def read(path: str, offset: int = 1, limit: int = 2000) -> str:
    p = Path(path)
    if not p.exists():
        return f"ERROR: path does not exist: {path}"
    if p.is_dir():
        entries = sorted(p.iterdir(), key=lambda x: (x.is_file(), x.name.lower()))
        return "\n".join(("d " if e.is_dir() else "f ") + e.name for e in entries) or "(empty directory)"
    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    start = max(1, offset)
    end = min(len(lines), start + limit - 1)
    # 1-based line numbers let the model cite/target lines precisely.
    return "\n".join(f"{i}: {lines[i-1]}" for i in range(start, end + 1))


# --- write --------------------------------------------------------------------
_write_params = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "description": "Path of the file to create or overwrite."},
        "content": {"type": "string", "description": "Full contents to write."},
    },
    "required": ["path", "content"],
}


@_tool("write", "Create or fully overwrite a file. Use `edit` for partial changes.", _write_params)
def write(path: str, content: str) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"OK: wrote {len(content)} chars to {path}"


# --- edit ---------------------------------------------------------------------
_edit_params = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "description": "Path of the file to edit."},
        "old_string": {"type": "string", "description": "Exact text to find (must be unique)."},
        "new_string": {"type": "string", "description": "Text to replace it with."},
        "replace_all": {"type": "boolean", "description": "Replace every occurrence (default false)."},
    },
    "required": ["path", "old_string", "new_string"],
}


@_tool("edit", "Find-and-replace an EXACT block in a file. Fails if old_string is missing or not unique (unless replace_all).", _edit_params)
def edit(path: str, old_string: str, new_string: str, replace_all: bool = False) -> str:
    p = Path(path)
    if not p.exists():
        return f"ERROR: file does not exist: {path}"
    text = p.read_text(encoding="utf-8")
    count = text.count(old_string)
    if count == 0:
        # This error message is a FREE CORRECTION SIGNAL — the model re-reads and retries.
        return f"ERROR: old_string not found in {path}. Re-read the file; it may have changed."
    if count > 1 and not replace_all:
        return f"ERROR: old_string matches {count} places in {path}. Add context to make it unique, or set replace_all=true."
    new_text = text.replace(old_string, new_string) if replace_all else text.replace(old_string, new_string, 1)
    p.write_text(new_text, encoding="utf-8")
    return f"OK: replaced {count if replace_all else 1} occurrence(s) in {path}"


# --- shell --------------------------------------------------------------------
_shell_params = {
    "type": "object",
    "properties": {
        "command": {"type": "string", "description": "Shell command to run (Windows cmd)."},
    },
    "required": ["command"],
}


@_tool("shell", "Run a shell command and return stdout+stderr (truncated). Use for tests, builds, grep, etc.", _shell_params)
def shell(command: str) -> str:
    # NOTE: a production agent adds permission prompts + sandboxing here.
    try:
        r = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=120)
        out = (r.stdout + r.stderr).strip()
        if len(out) > 8000:
            out = out[:8000] + f"\n... (truncated, {len(out)-8000} more chars)"
        return out or "(no output)"
    except subprocess.TimeoutExpired:
        return "ERROR: command timed out after 120s"


# --- grep ---------------------------------------------------------------------
_grep_params = {
    "type": "object",
    "properties": {
        "pattern": {"type": "string", "description": "Regex to search for."},
        "path": {"type": "string", "description": "File or directory to search (default cwd)."},
    },
    "required": ["pattern"],
}


@_tool("grep", "Search file contents for a regex. Returns matching lines with file:line prefixes.", _grep_params)
def grep(pattern: str, path: str = ".") -> str:
    regex = re.compile(pattern)
    root = Path(path)
    hits = []
    files = [root] if root.is_file() else [p for p in root.rglob("*") if p.is_file()]
    for f in files:
        try:
            for i, line in enumerate(f.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                if regex.search(line):
                    hits.append(f"{f}:{i}: {line}")
        except OSError:
            continue
        if len(hits) > 200:
            hits.append("... (truncated at 200 hits)")
            break
    return "\n".join(hits) if hits else "(no matches)"


# --- glob ---------------------------------------------------------------------
_glob_params = {
    "type": "object",
    "properties": {
        "pattern": {"type": "string", "description": "Glob pattern, e.g. '**/*.py' or 'src/*.ts'."},
        "path": {"type": "string", "description": "Directory to search (default cwd)."},
    },
    "required": ["pattern"],
}


@_tool("glob", "Find files by name pattern (e.g. '**/*.py'). Returns paths.", _glob_params)
def glob(pattern: str, path: str = ".") -> str:
    root = Path(path)
    matches = []
    for p in root.rglob("*"):
        rel = str(p.relative_to(root))
        if fnmatch.fnmatch(rel, pattern) or fnmatch.fnmatch(p.name, pattern):
            matches.append(str(p))
        if len(matches) > 200:
            matches.append("... (truncated at 200)")
            break
    return "\n".join(matches) if matches else "(no matches)"


# =============================================================================
#  STRUCTURAL NAVIGATION TOOLS (powered by CodeGraph / tree-sitter)
# =============================================================================
# These let the agent navigate by SYMBOL instead of by line number.
# Read codegraph.py to see how symbols + the call graph are built.
# =============================================================================

_index_params = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "description": "Directory to index (default: current dir)."},
    },
}


@_tool("index_code", "Build/refresh the symbol map + call graph for a directory. Call this BEFORE list_symbols/find_callers/get_symbol. Cheap on re-runs (skips unchanged files by mtime).", _index_params)
def index_code(path: str = ".") -> str:
    if graph is None:
        return "ERROR: code graph not initialized"
    return graph.index(path)


_overview_params = {"type": "object", "properties": {}}


@_tool("graph_overview", "Show the full codebase map: every file, its functions/classes, line ranges, and what each calls. The structural 'table of contents'.", _overview_params)
def graph_overview() -> str:
    if graph is None:
        return "ERROR: code graph not initialized"
    return graph.overview()


_list_symbols_params = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "description": "File to list symbols in."},
    },
    "required": ["path"],
}


@_tool("list_symbols", "List all functions/classes/methods in a file with line ranges + signatures. Use instead of reading the whole file when you just need structure.", _list_symbols_params)
def list_symbols(path: str) -> str:
    if graph is None:
        return "ERROR: code graph not initialized"
    syms = graph.list_symbols(path)
    if not syms:
        return f"(no symbols indexed in {path}; run index_code first)"
    out = [f"{path}: {len(syms)} symbol(s)"]
    for s in syms:
        calls = f"  -> {', '.join(s['calls'][:6])}" if s.get("calls") else ""
        out.append(f"  [{s['kind']}] {s['name']}  L{s['start_line']}-{s['end_line']}{calls}")
    return "\n".join(out)


_get_symbol_params = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "description": "File containing the symbol."},
        "name": {"type": "string", "description": "Symbol (function/class) name."},
    },
    "required": ["path", "name"],
}


@_tool("get_symbol", "Return the full source code of one function/class by name. Navigates by symbol, not line number — robust to edits shifting code around.", _get_symbol_params)
def get_symbol(path: str, name: str) -> str:
    if graph is None:
        return "ERROR: code graph not initialized"
    return graph.get_symbol(path, name)


_callers_params = {
    "type": "object",
    "properties": {
        "name": {"type": "string", "description": "Function name to find callers of."},
    },
    "required": ["name"],
}


@_tool("find_callers", "Reverse call graph: who calls a function named `name`? Returns file:line for each caller. Vital for safe edits — check impact before changing a function.", _callers_params)
def find_callers(name: str) -> str:
    if graph is None:
        return "ERROR: code graph not initialized"
    return graph.find_callers(name)


_callees_params = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "description": "File containing the function."},
        "name": {"type": "string", "description": "Function name."},
    },
    "required": ["path", "name"],
}


@_tool("find_callees", "Forward call graph: what does function `name` in `path` call? Helps understand what a function depends on.", _callees_params)
def find_callees(path: str, name: str) -> str:
    if graph is None:
        return "ERROR: code graph not initialized"
    return graph.find_callees(path, name)


# =============================================================================
#  SUMMARY TOOL (the LLM layer on top of structure)
# =============================================================================
# Structure (tree-sitter/ast) tells us WHERE symbols are and what they call.
# It cannot tell us WHAT they do in plain English. For that, we ask the LLM
# once per symbol and CACHE the result to disk, keyed by a hash of the source.
# Subsequent calls hit the cache unless the source changed. This is the
# two-layer design: exact structure (cheap, cached) + approximate summary
# (LLM, lazy, cached).
# =============================================================================
_summarize_params = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "description": "File containing the symbol."},
        "name": {"type": "string", "description": "Function/class to summarize."},
    },
    "required": ["path", "name"],
}

_SUMMARY_CACHE: dict[str, str] = {}


def _summary_cache_key(source: str) -> str:
    return hashlib.sha256(source.encode("utf-8")).hexdigest()[:16]


@_tool("summarize_symbol", "Get a one-line plain-English summary of what a function/class does. Generated by the LLM once, then cached to disk (re-generates only if the source changes).", _summarize_params)
def summarize_symbol(path: str, name: str) -> str:
    if graph is None:
        return "ERROR: code graph not initialized"
    if model is None:
        return "ERROR: model client not available"

    # 1. Fetch the symbol's source via the structural layer (exact).
    src = graph.get_symbol(path, name)
    if src.startswith("ERROR"):
        return src

    # 2. Cache hit? Keyed by source hash so edits auto-invalidate.
    key = f"{path}::{name}::{_summary_cache_key(src)}"
    if key in _SUMMARY_CACHE:
        return f"[cached] {_SUMMARY_CACHE[key]}"

    # 3. Cache miss: ask the LLM for a one-line summary.
    prompt = [
        {"role": "system", "content": "Summarize what the given code does in ONE line (max 80 chars). Be specific about behavior, not just the name. Reply with only the summary."},
        {"role": "user", "content": f"File: {path}\nSymbol: {name}\n\n```\n{src}\n```"},
    ]
    try:
        resp = model.chat(prompt, tools=[])
        summary = (resp.content or "").strip().split("\n")[0][:120]
    except Exception as e:
        return f"ERROR summarizing: {e}"

    # 4. Cache + return.
    _SUMMARY_CACHE[key] = summary
    return summary
