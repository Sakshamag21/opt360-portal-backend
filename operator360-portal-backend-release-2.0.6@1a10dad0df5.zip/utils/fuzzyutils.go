package utils

import (
	"math"
	"strings"
	"unicode"
)

// FuzzySearchResult represents a single fuzzy search match with its score
type FuzzySearchResult struct {
	Text  string
	Score float64
}

// CalculateFuzzyScore computes a fuzzy match score between a query and a target string.
// The score ranges from 0.0 to 1.0, where:
// - 1.0 is an exact match (case-insensitive)
// - Higher scores indicate better matches
// - 0.0 indicates no match
//
// The algorithm considers:
// 1. Exact substring matches (highest priority)
// 2. Prefix matches (high priority)
// 3. Levenshtein distance-based fuzzy matching (tolerates typos)
// 4. Acronym matching (e.g., "ARTL" matches "Airtel")
func CalculateFuzzyScore(query, target string) float64 {
	if query == "" || target == "" {
		return 0.0
	}

	query = strings.ToLower(strings.TrimSpace(query))
	target = strings.ToLower(strings.TrimSpace(target))

	// Exact match
	if query == target {
		return 1.0
	}

	// Exact substring match (e.g., "air" in "airtel")
	if strings.Contains(target, query) {
		// Higher score if it matches at the start
		if strings.HasPrefix(target, query) {
			return 0.95
		}
		// Slightly lower if it's in the middle
		return 0.85
	}

	// Prefix match (e.g., "air" matches "airtel india")
	if strings.HasPrefix(target, query) {
		return 0.90
	}

	// Check for acronym match (e.g., "ARTL" -> "Airtel")
	if acronymScore := calculateAcronymScore(query, target); acronymScore > 0 {
		return acronymScore
	}

	// Levenshtein distance-based fuzzy matching
	// Only consider it a match if the strings are reasonably similar
	score := calculateLevenshteinScore(query, target)

	// Only return matches with a score above threshold to avoid noise
	if score > 0.7 {
		return score
	}

	return 0.0
}

// calculateAcronymScore checks if the query matches an acronym formed from the target.
// For example, "ARTL" would match "Airtel" or "Air Tel Ltd".
func calculateAcronymScore(query, target string) float64 {
	words := strings.FieldsFunc(target, func(r rune) bool {
		return !unicode.IsLetter(r) && !unicode.IsDigit(r)
	})

	if len(words) == 0 {
		return 0
	}

	// Build acronym from target words
	acronym := ""
	for _, word := range words {
		if len(word) > 0 {
			acronym += string(word[0])
		}
	}
	acronym = strings.ToLower(acronym)

	// Check if query matches the acronym
	if query == acronym {
		return 0.92
	}

	// Check if query is a prefix of the acronym
	if strings.HasPrefix(acronym, query) {
		return 0.88
	}

	return 0
}

// calculateLevenshteinScore computes a normalized score based on Levenshtein distance.
// Returns a score from 0.0 to 1.0, where:
// - 1.0 is an exact match
// - Higher scores indicate fewer edits needed
func calculateLevenshteinScore(query, target string) float64 {
	if query == target {
		return 1.0
	}

	maxLen := len(query)
	if len(target) > maxLen {
		maxLen = len(target)
	}

	if maxLen == 0 {
		return 1.0
	}

	// Calculate Levenshtein distance
	distance := levenshteinDistance(query, target)

	// Convert distance to similarity score (0.0 to 1.0)
	// Distance of 0 → score of 1.0
	// Distance equal to max length → score of 0.0
	score := 1.0 - (float64(distance) / float64(maxLen))

	// Apply a penalty for very long strings with small distances
	// to avoid matching long strings with short queries
	if len(query) < len(target)/2 {
		score *= 0.7
	}

	return math.Max(0, score)
}

// levenshteinDistance calculates the Levenshtein distance between two strings.
// It represents the minimum number of single-character edits (insertions, deletions, substitutions)
// required to change one string into the other.
func levenshteinDistance(s1, s2 string) int {
	l1 := len(s1)
	l2 := len(s2)

	if l1 == 0 {
		return l2
	}
	if l2 == 0 {
		return l1
	}

	// Create a matrix to store distances
	// We only need the previous row and current row
	prev := make([]int, l2+1)
	curr := make([]int, l2+1)

	// Initialize first row
	for i := 0; i <= l2; i++ {
		prev[i] = i
	}

	for i := 1; i <= l1; i++ {
		curr[0] = i

		for j := 1; j <= l2; j++ {
			cost := 1
			if s1[i-1] == s2[j-1] {
				cost = 0
			}

			curr[j] = min(
				curr[j-1]+1, // insertion
				min(prev[j]+1, // deletion
					prev[j-1]+cost), // substitution
			)
		}

		// Copy current row to previous row for next iteration
		copy(prev, curr)
	}

	return curr[l2]
}

// min returns the minimum of two integers
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
