package Maps

import (
    "fmt"
    "log"
    "net/http"
    "strconv"
    "strings"
    "sync"
    "time"

    "opt360-portal-backend/db"
    "opt360-portal-backend/models"

    "github.com/gin-gonic/gin"
)

var (
    cachedHeatmaps    = make(map[string][][3]float64)
    cachedStateCounts = make(map[string]gin.H)
    cacheMutex        sync.RWMutex
    cacheTime         time.Time
)

// RefreshHeatmapCache calculates the India and State-level heatmaps and saves them to RAM
func RefreshHeatmapCache() error {
    database, err := db.GetDB()
    if err != nil {
        return fmt.Errorf("DB connection error: %v", err)
    }

    newCache := make(map[string][][3]float64)

    // 1. Fetch and Cache India View
    indiaRows, err := database.Query(`
        SELECT 
            AVG(ST_LATITUDE(l.loc)) as lat,
            AVG(ST_LONGITUDE(l.loc)) as lng,
            AVG(
                CASE 
                    WHEN m.risk_bucket = 'Critical' THEN 10.0
                    WHEN m.risk_bucket = 'High' THEN 5.0
                    WHEN m.risk_bucket = 'Medium' THEN 2.0
                    WHEN m.risk_bucket = 'Low' THEN 0.5
                    ELSE 0.0 
                END
            ) * LOG(1 + COUNT(*)) as zri
        FROM operator360.opt_master m
        JOIN operator360.operator_sync_location l ON l.opt_id = m.id
        WHERE l.loc IS NOT NULL 
        GROUP BY ROUND(ST_LATITUDE(l.loc) / 0.18), ROUND(ST_LONGITUDE(l.loc) / 0.18)
    `)
    if err != nil {
        return fmt.Errorf("india query error: %v", err)
    }

    indiaPoints := make([][3]float64, 0)
    for indiaRows.Next() {
        var p [3]float64
        indiaRows.Scan(&p[0], &p[1], &p[2])
        indiaPoints = append(indiaPoints, p)
    }
    indiaRows.Close()
    newCache[""] = indiaPoints // "" represents India

    // 2. Fetch and Cache ALL State Views
    stateRows, err := database.Query(`
        SELECT 
            m.state,
            AVG(ST_LATITUDE(l.loc)) as lat,
            AVG(ST_LONGITUDE(l.loc)) as lng,
            AVG(
                CASE 
                    WHEN m.risk_bucket = 'Critical' THEN 10.0
                    WHEN m.risk_bucket = 'High' THEN 5.0
                    WHEN m.risk_bucket = 'Medium' THEN 2.0
                    WHEN m.risk_bucket = 'Low' THEN 0.5
                    ELSE 0.0 
                END
            ) * LOG(1 + COUNT(*)) as zri
        FROM operator360.opt_master m
        JOIN operator360.operator_sync_location l ON l.opt_id = m.id
        WHERE l.loc IS NOT NULL AND m.state IS NOT NULL AND m.state != ''
        GROUP BY m.state, ROUND(ST_LATITUDE(l.loc) / 0.05), ROUND(ST_LONGITUDE(l.loc) / 0.05)
    `)
    if err != nil {
        return fmt.Errorf("state query error: %v", err)
    }

    statePointsMap := make(map[string][][3]float64)
    for stateRows.Next() {
        var stateName string
        var p [3]float64
        stateRows.Scan(&stateName, &p[0], &p[1], &p[2])
        statePointsMap[stateName] = append(statePointsMap[stateName], p)
    }
    stateRows.Close()

    for stateName, points := range statePointsMap {
        newCache[stateName] = points
    }

    // 3. Fetch and Cache Operator Counts for all states
    countRows, err := database.Query(`
        SELECT 
            m.state,
            COUNT(m.id) as total,
            COALESCE(SUM(CASE WHEN m.risk_bucket = 'Critical' THEN 1 ELSE 0 END), 0) as critical,
            COALESCE(SUM(CASE WHEN m.risk_bucket = 'High' THEN 1 ELSE 0 END), 0) as high,
            COALESCE(SUM(CASE WHEN m.risk_bucket = 'Medium' THEN 1 ELSE 0 END), 0) as medium,
            COALESCE(SUM(CASE WHEN m.risk_bucket = 'Low' THEN 1 ELSE 0 END), 0) as low,
            COALESCE(SUM(CASE WHEN m.risk_bucket IS NULL OR m.risk_bucket = 'No' THEN 1 ELSE 0 END), 0) as no
        FROM operator360.opt_master m
        JOIN operator360.operator_sync_location l ON l.opt_id = m.id
        WHERE m.state IS NOT NULL AND m.state != ''
        GROUP BY m.state
    `)
    if err != nil {
        return fmt.Errorf("state count query error: %v", err)
    }

    newCounts := make(map[string]gin.H)
    for countRows.Next() {
        var stateName string
        var total, critical, high, medium, low, no int
        countRows.Scan(&stateName, &total, &critical, &high, &medium, &low, &no)

        newCounts[stateName] = gin.H{
            "total":    total,
            "critical": critical,
            "high":     high,
            "medium":   medium,
            "low":      low,
            "no":       no,
        }
    }
    countRows.Close()

    // Save everything to global RAM
    cacheMutex.Lock()
    cachedHeatmaps = newCache
    cachedStateCounts = newCounts
    cacheTime = time.Now()
    cacheMutex.Unlock()

    log.Printf("[HeatmapCacheWorker] ✅ Cache refreshed successfully. India + %d states cached.", len(newCache)-1)
    return nil
}

// StartHeatmapCacheWorker runs in the background.
func StartHeatmapCacheWorker() {
    log.Println("[HeatmapCacheWorker] Server started. Running initial cache refresh...")
    refreshWithRetry()

    for {
        now := time.Now()
        nextRun := time.Date(now.Year(), now.Month(), now.Day(), 2, 0, 0, 0, now.Location())
        if !nextRun.After(now) {
            nextRun = nextRun.Add(24 * time.Hour)
        }

        durationUntilNextRun := time.Until(nextRun)
        log.Printf("[HeatmapCacheWorker] Next nightly cache refresh scheduled for %s (in %s)",
            nextRun.Format("2006-01-02 15:04:05"),
            durationUntilNextRun.Round(time.Minute),
        )

        time.Sleep(durationUntilNextRun)
        log.Println("[HeatmapCacheWorker] It's 2:00 AM. Auto-refreshing cache...")
        refreshWithRetry()
    }
}

func refreshWithRetry() {
    maxRetries := 3
    var lastErr error

    for i := 1; i <= maxRetries; i++ {
        log.Printf("[HeatmapCacheWorker] Attempt %d/%d...", i, maxRetries)
        err := RefreshHeatmapCache()
        if err == nil {
            return
        }
        lastErr = err
        time.Sleep(10 * time.Second)
    }
    log.Printf("[HeatmapCacheWorker] ❌ CRITICAL: Failed to refresh cache after %d attempts. Last error: %v", maxRetries, lastErr)
}

// GetHeatmapZRI returns pre-calculated ZRI points for the map canvas
func GetHeatmapZRI(c *gin.Context) {
    state := strings.TrimSpace(c.Query("state"))
    district := strings.TrimSpace(c.Query("district"))

    // 1. INDIA & STATE VIEW: Serve instantly from RAM cache
    if district == "" {
        cacheMutex.RLock()
        points, found := cachedHeatmaps[state]
        cacheMutex.RUnlock()

        if found {
            c.Header("Cache-Control", "public, max-age=3600")
            c.JSON(http.StatusOK, points)
            return
        }
    }

    // 2. DISTRICT VIEW: Query the database normally (Live)
    database, err := db.GetDB()
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Database connection unavailable"})
        return
    }

    query := `
        SELECT 
            AVG(ST_LATITUDE(l.loc)) as lat,
            AVG(ST_LONGITUDE(l.loc)) as lng,
            AVG(
                CASE 
                    WHEN m.risk_bucket = 'Critical' THEN 10.0
                    WHEN m.risk_bucket = 'High' THEN 5.0
                    WHEN m.risk_bucket = 'Medium' THEN 2.0
                    WHEN m.risk_bucket = 'Low' THEN 0.5
                    ELSE 0.0 
                END
            ) * LOG(1 + COUNT(*)) as zri
        FROM operator360.opt_master m
        JOIN operator360.operator_sync_location l ON l.opt_id = m.id
        WHERE l.loc IS NOT NULL 
    `

    var args []interface{}
    if state != "" {
        query += ` AND m.state = ?`
        args = append(args, state)
    }
    if district != "" {
        query += ` AND m.district = ?`
        args = append(args, district)
    }

    gridSize := 0.01 // Districts use smaller grids for better detail
    query += `
        GROUP BY 
            ROUND(ST_LATITUDE(l.loc) / ?),
            ROUND(ST_LONGITUDE(l.loc) / ?)
    `
    args = append(args, gridSize, gridSize)

    rows, err := database.Query(query, args...)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch heatmap ZRI data"})
        return
    }
    defer rows.Close()

    heatPoints := make([][3]float64, 0)
    for rows.Next() {
        var point [3]float64
        if err := rows.Scan(&point[0], &point[1], &point[2]); err != nil {
            continue
        }
        heatPoints = append(heatPoints, point)
    }

    c.Header("Cache-Control", "public, max-age=300")
    c.JSON(http.StatusOK, heatPoints)
}

// GetDistrictOperators serves operator pins filtered by State and District
func GetDistrictOperators(c *gin.Context) {
    userInterface, exists := c.Get("user")
    if !exists {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "User not found in context"})
        return
    }
    _, ok := userInterface.(*models.User)
    if !ok {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to parse user from context"})
        return
    }

    database, err := db.GetDB()
    if err != nil {
        log.Printf("[GetDistrictOperators] DB connection error: %v", err)
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Database connection unavailable"})
        return
    }

    state := strings.TrimSpace(c.Query("state"))
    district := strings.TrimSpace(c.Query("district"))

    if state == "" || district == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "state and district query params are required"})
        return
    }

    limit := 5000
    if l, err := strconv.Atoi(c.Query("limit")); err == nil && l > 0 {
        if l > 5000 {
            l = 5000
        }
        limit = l
    }

    query := `
        SELECT
            m.id,
            ST_LATITUDE(l.loc) AS lat,
            ST_LONGITUDE(l.loc) AS lon,
            COALESCE(m.risk_bucket, 'No') as risk_bucket,
            COALESCE(m.state, 'N/A') as state,
            COALESCE(m.district, 'N/A') as district
        FROM operator360.opt_master m
        JOIN operator360.operator_sync_location l ON l.opt_id = m.id
        WHERE m.state = ?
        AND m.district = ?
        LIMIT ?
    `

    args := []interface{}{strings.ToLower(state), strings.ToLower(district), limit}

    rows, err := database.Query(query, args...)
    if err != nil {
        log.Printf("[GetDistrictOperators] Query error: %v", err)
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch district operators"})
        return
    }
    defer rows.Close()

    operators := make([][6]interface{}, 0, limit)
    for rows.Next() {
        var id, riskBucket, opState, opDistrict string
        var lat, lon float64
        if err := rows.Scan(&id, &lat, &lon, &riskBucket, &opState, &opDistrict); err != nil {
            log.Printf("[GetDistrictOperators] Row scan error: %v", err)
            continue
        }

        code, ok := riskBucketCode[riskBucket]
        if !ok {
            code = "n"
        }

        operators = append(operators, [6]interface{}{lat, lon, code, id, opState, opDistrict})
    }

    c.JSON(http.StatusOK, gin.H{"operators": operators})
}

// GetOperatorCount returns the total number of operators and risk bucket breakdown
func GetOperatorCount(c *gin.Context) {
    state := strings.TrimSpace(c.Query("state"))
    district := strings.TrimSpace(c.Query("district"))

    // 1. STATE VIEW: Serve instantly from RAM cache (if no district selected)
    if district == "" && state != "" {
        cacheMutex.RLock()
        counts, found := cachedStateCounts[state]
        cacheMutex.RUnlock()

        if found {
            c.Header("Cache-Control", "public, max-age=3600")
            c.JSON(http.StatusOK, counts)
            return
        }
    }

    // 2. INDIA VIEW or DISTRICT VIEW: Query DB live
    database, err := db.GetDB()
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Database connection unavailable"})
        return
    }

    if state == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "state query param is required"})
        return
    }

    query := `
        SELECT 
            COUNT(m.id) as total,
            COALESCE(SUM(CASE WHEN m.risk_bucket = 'Critical' THEN 1 ELSE 0 END), 0) as critical,
            COALESCE(SUM(CASE WHEN m.risk_bucket = 'High' THEN 1 ELSE 0 END), 0) as high,
            COALESCE(SUM(CASE WHEN m.risk_bucket = 'Medium' THEN 1 ELSE 0 END), 0) as medium,
            COALESCE(SUM(CASE WHEN m.risk_bucket = 'Low' THEN 1 ELSE 0 END), 0) as low,
            COALESCE(SUM(CASE WHEN m.risk_bucket IS NULL OR m.risk_bucket = 'No' THEN 1 ELSE 0 END), 0) as no
        FROM operator360.opt_master m
        JOIN operator360.operator_sync_location l ON l.opt_id = m.id
        WHERE m.state = ?
    `
    args := []interface{}{state}

    if district != "" {
        query += " AND m.district = ?"
        args = append(args, district)
    }

    var total, critical, high, medium, low, no int
    err = database.QueryRow(query, args...).Scan(&total, &critical, &high, &medium, &low, &no)
    if err != nil {
        log.Printf("[GetOperatorCount] Query error: %v", err)
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to count operators"})
        return
    }

    c.JSON(http.StatusOK, gin.H{
        "total":    total,
        "critical": critical,
        "high":     high,
        "medium":   medium,
        "low":      low,
        "no":       no,
    })
}