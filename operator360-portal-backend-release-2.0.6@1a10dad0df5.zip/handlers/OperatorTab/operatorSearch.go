package OperatorTab

import (
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"sort"
	"strings"

	"opt360-portal-backend/db"
	"opt360-portal-backend/models"
	"opt360-portal-backend/utils"

	"github.com/gin-gonic/gin"
)

// sortColumns whitelists the only columns a client may sort by — never
// interpolate a client-supplied string directly into ORDER BY.
var sortColumns = map[string]string{
	"risk_score": "risk_score",
	"last_sync":  "last_sync_timestamp",
}

// SearchOperators handles POST /api/operator_search.
//
// This is the single, unified replacement for the previously-separate
// operator_list, active_operator_list, inactive_operator_list, high_risk_operator,
// med_risk_operator, low_risk_operator, operator_list_with_risk and
// filter_operator_list endpoints. Sourced entirely from operator360.opt_master —
// no cross-cluster UID-DB join (see docs/VIEW_OPERATORS_REDESIGN_PLAN.md); status
// comes directly from opt_master.is_active.
//
// Body (all fields optional):
//
//	ro           – regional office to search. Defaults to the caller's own RO.
//	               Not access-restricted: any authenticated user may view any
//	               RO's operators (viewing is unrestricted; only feedback
//	               submission is RO-scoped).
//	state        – filter by state
//	district     – filter by district
//	id           – filter by operator id (exact match)
//	ea           – filter by ea name
//	ea_code      – filter by ea code (exact match — what the View Operators typeahead sends)
//	reg          – filter by registrar name
//	reg_code     – filter by registrar code (exact match — what the View Operators typeahead sends)
//	risk_bucket  – filter by risk bucket (High | Medium | Low | No)
//	status       – filter by status (active | inactive), from opt_master.is_active
//	sort_by      – risk_score | last_sync (default: none, falls back to id ASC)
//	sort_dir     – asc | desc (default: asc)
//	page         – page number (default 1)
//	page_size    – records per page (default 20, max 1000)
func SearchOperators(c *gin.Context) {

	// ── 1. Auth guard ──────────────────────────────────────────────────────────
	userInterface, exists := c.Get("user")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not found in context"})
		return
	}
	user := userInterface.(*models.User)

	// ── 2. Parse request body ─────────────────────────────────────────────────
	var req models.OperatorSearchRequest
	if err := c.ShouldBindJSON(&req); err != nil && err.Error() != "EOF" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body", "details": err.Error()})
		return
	}

	filterQuery := strings.TrimSpace(req.Query)
	filterID := strings.TrimSpace(req.ID)
	filterName := strings.TrimSpace(req.Name)

	// TechCentre/HeadQuarters users see all ROs by default (no RO filter) —
	// see models.ResolveRO. A normal user still defaults to their own RO —
	// except when searching by a specific operator ID with no explicit RO
	// given: knowing the exact ID shouldn't require also knowing/guessing
	// which RO it belongs to, so ID search stays global (n'[o RO filter) for
	// every user unless they explicitly pick one.
	var filterRO string
	if filterID != "" && strings.TrimSpace(req.RO) == "" {
		filterRO = ""
	} else {
		filterRO = models.ResolveRO(strings.TrimSpace(req.RO), user)
	}
	filterState := strings.TrimSpace(req.State)
	filterDistrict := strings.TrimSpace(req.District)
	filterEA := strings.TrimSpace(req.EA)
	filterEACode := strings.TrimSpace(req.EACode)
	filterReg := strings.TrimSpace(req.Reg)
	filterRegCode := strings.TrimSpace(req.RegCode)
	filterRiskBucket := strings.TrimSpace(req.RiskBucket)
	filterStatus := strings.ToLower(strings.TrimSpace(req.Status))

	// ── 3. Determine if fuzzy search is active ────────────────────────────────
	isFuzzySearch := filterQuery != ""

	// ── 4. Pagination ──────────────────────────────────────────────────────────
	page := req.Page
	if page < 1 {
		page = 1
	}
	pageSize := req.PageSize
	if pageSize < 1 || pageSize > 1000 {
		pageSize = 20
	}
	offset := (page - 1) * pageSize

	// ── 5. Sort ────────────────────────────────────────────────────────────────
	// For fuzzy search, sorting will be done in-memory by relevance score after results are fetched
	orderBySQL := "ORDER BY id ASC"
	sortBy := strings.ToLower(strings.TrimSpace(req.SortBy))
	if !isFuzzySearch && sortBy != "" {
		if col, ok := sortColumns[sortBy]; ok {
			dir := "ASC"
			if strings.EqualFold(strings.TrimSpace(req.SortDir), "desc") {
				dir = "DESC"
			}
			orderBySQL = "ORDER BY " + col + " " + dir + ", id ASC"
		}
	}

	// ── 6. opt360 DB connection ────────────────────────────────────────────────
	opt360DB, err := db.GetDB()
	if err != nil {
		log.Printf("[SearchOperators] opt360 DB error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"error":   "Database connection unavailable",
			"details": err.Error(),
		})
		return
	}

	// ── 7. Build WHERE (excluding fuzzy search fields) ──────────────────────────
	// When using fuzzy search, we fetch a broader set of results and filter/score in-memory
	var whereClauses []string
	var args []interface{}
	if filterRO != "" {
		whereClauses = append(whereClauses, "ro = ?")
		args = append(args, filterRO)
	}
	if filterState != "" {
		whereClauses = append(whereClauses, "state = ?")
		args = append(args, filterState)
	}
	if filterDistrict != "" {
		whereClauses = append(whereClauses, "district = ?")
		args = append(args, filterDistrict)
	}
	// For fuzzy search, skip exact ID and Name matching at the DB level
	// We'll apply fuzzy matching in-memory instead
	if !isFuzzySearch {
		if filterID != "" {
			whereClauses = append(whereClauses, "id = ?")
			args = append(args, filterID)
		}
		if filterName != "" {
			whereClauses = append(whereClauses, "name = ?")
			args = append(args, filterName)
		}
	}
	if filterEA != "" {
		whereClauses = append(whereClauses, "ea = ?")
		args = append(args, filterEA)
	}
	if filterEACode != "" {
		whereClauses = append(whereClauses, "ea_code = ?")
		args = append(args, filterEACode)
	}
	if filterReg != "" {
		whereClauses = append(whereClauses, "reg = ?")
		args = append(args, filterReg)
	}
	if filterRegCode != "" {
		whereClauses = append(whereClauses, "reg_code = ?")
		args = append(args, filterRegCode)
	}
	if filterRiskBucket != "" {
		whereClauses = append(whereClauses, "risk_bucket = ?")
		args = append(args, filterRiskBucket)
	}
	if filterStatus == "active" {
		// opt_master.is_active is a numeric column where 1 means active and
		// every other value (including NULL) means inactive.
		whereClauses = append(whereClauses, "is_active = 1")
	} else if filterStatus == "inactive" {
		// NULL doesn't satisfy is_active <> 1 under SQL's three-valued logic, so
		// it has to be spelled out explicitly to count NULL as inactive too.
		whereClauses = append(whereClauses, "(is_active IS NULL OR is_active <> 1)")
	}

	var whereSQL string
	if len(whereClauses) > 0 {
		whereSQL = "WHERE " + strings.Join(whereClauses, " AND ")
	}
	fromSQL := "FROM operator360.opt_master"
	selectCols := `SELECT id, uid, name, phone, email, risk_score, risk_bucket, reg, reg_code, ea, ea_code, ro, district, state, last_sync_timestamp, data_path, is_active,last_packet_timestamp as last_packet_date, dissociation_date, dissociation_reason_code as dissociation_reason`

	// ── 8. Fetch all candidate rows (no pagination yet for fuzzy search) ────────
	// For fuzzy search, we fetch all candidates, apply fuzzy matching in-memory,
	// then paginate. For non-fuzzy search, we use database-level pagination.
	var allOperators []models.SearchOperator

	dataQuery := selectCols + " " + fromSQL + " " + whereSQL
	if !isFuzzySearch {
		dataQuery += " " + orderBySQL + " LIMIT ? OFFSET ?"
		dataQuery = dataQuery + ""
	}

	var rows *sql.Rows
	var rErr error

	if isFuzzySearch {
		// For fuzzy search, fetch all results without pagination limit
		rows, rErr = opt360DB.Query(dataQuery, args...)
	} else {
		// For non-fuzzy search, use database-level pagination
		dataArgs := append(args, pageSize, offset)
		rows, rErr = opt360DB.Query(dataQuery, dataArgs...)
	}

	if rErr != nil {
		log.Printf("[SearchOperators] Data query error: %v", rErr)
		c.JSON(http.StatusInternalServerError, gin.H{
			"error":   "Failed to fetch operator records",
			"details": rErr.Error(),
		})
		return
	}
	defer rows.Close()

	// ── 9. Scan rows and apply fuzzy matching ──────────────────────────────────
	for rows.Next() {
		var op models.SearchOperator
		var (
			uid                sql.NullString
			phone              sql.NullString
			email              sql.NullString
			riskScore          sql.NullFloat64
			riskBucket         sql.NullString
			reg                sql.NullString
			regCode            sql.NullString
			ea                 sql.NullString
			eaCode             sql.NullString
			ro                 sql.NullString
			district           sql.NullString
			state              sql.NullString
			lastSyncTimestamp  sql.NullTime
			dataPath           sql.NullString
			isActive           sql.NullInt64
			lastPacketDate     sql.NullTime
			dissociationDate   sql.NullTime
			dissociationReason sql.NullString
		)
		if err := rows.Scan(
			&op.ID, &uid, &op.Name, &phone, &email,
			&riskScore, &riskBucket,
			&reg, &regCode, &ea, &eaCode, &ro, &district, &state,
			&lastSyncTimestamp, &dataPath, &isActive,
			&lastPacketDate, &dissociationDate, &dissociationReason,
		); err != nil {
			log.Printf("[SearchOperators] Row scan error: %v", err)
			c.JSON(http.StatusInternalServerError, gin.H{
				"error":   "Failed to process operator record",
				"details": err.Error(),
			})
			return
		}

		// Apply fuzzy matching if a query was provided
		if isFuzzySearch {
			// Calculate fuzzy match score against both ID and Name
			idScore := utils.CalculateFuzzyScore(filterQuery, op.ID)
			nameScore := utils.CalculateFuzzyScore(filterQuery, op.Name)

			// Use the higher of the two scores
			op.FuzzyMatchScore = idScore
			if nameScore > idScore {
				op.FuzzyMatchScore = nameScore
			}

			// Skip operators that don't match the fuzzy query
			if op.FuzzyMatchScore == 0.0 {
				continue
			}
		}

		// Map nullable fields
		if uid.Valid {
			op.UID = uid.String
		}
		if phone.Valid {
			op.Phone = phone.String
		}
		if email.Valid {
			op.Email = email.String
		}
		if riskScore.Valid {
			op.RiskScore = &riskScore.Float64
		}
		if riskBucket.Valid {
			op.RiskBucket = &riskBucket.String
		}
		if reg.Valid {
			op.Reg = &reg.String
		}
		if regCode.Valid {
			op.RegCode = &regCode.String
		}
		if ea.Valid {
			op.EA = &ea.String
		}
		if eaCode.Valid {
			op.EACode = &eaCode.String
		}
		if ro.Valid {
			op.RO = &ro.String
		}
		if district.Valid {
			op.District = &district.String
		}
		if state.Valid {
			op.State = &state.String
		}
		if lastSyncTimestamp.Valid {
			op.LastSyncTimestamp = &lastSyncTimestamp.Time
		}
		if dataPath.Valid {
			op.DataPath = &dataPath.String
		}
		if lastPacketDate.Valid {
			op.LastPacketDate = &lastPacketDate.Time
		}
		if dissociationDate.Valid {
			op.DissociationDate = &dissociationDate.Time
		}
		if dissociationReason.Valid {
			op.DissociationReason = &dissociationReason.String
		}
		// Normalize opt_master's raw is_active (1/other/NULL) into "active"/"inactive"
		// so callers get a consistent value regardless of the underlying representation.
		normalizedStatus := "inactive"
		if isActive.Valid && isActive.Int64 == 1 {
			normalizedStatus = "active"
		}
		op.Status = &normalizedStatus
		allOperators = append(allOperators, op)
	}
	if err := rows.Err(); err != nil {
		log.Printf("[SearchOperators] Row iteration error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"error":   "Error while reading operator records",
			"details": err.Error(),
		})
		return
	}

	// ── 10. Handle sorting and pagination for fuzzy search results ───────────────
	var operators []models.SearchOperator
	var total int

	if isFuzzySearch {
		// For fuzzy search, sort by fuzzy match score (descending), then by ID
		sort.Slice(allOperators, func(i, j int) bool {
			if allOperators[i].FuzzyMatchScore != allOperators[j].FuzzyMatchScore {
				return allOperators[i].FuzzyMatchScore > allOperators[j].FuzzyMatchScore
			}
			return allOperators[i].ID < allOperators[j].ID
		})

		total = len(allOperators)

		// Apply pagination to sorted results
		endIdx := offset + pageSize
		if endIdx > total {
			endIdx = total
		}
		if offset < total {
			operators = allOperators[offset:endIdx]
		} else {
			operators = []models.SearchOperator{}
		}
	} else {
		// For non-fuzzy search, use database count and the already-paginated results
		countQuery := "SELECT COUNT(*) " + fromSQL + " " + whereSQL
		if cntErr := opt360DB.QueryRow(countQuery, args...).Scan(&total); cntErr != nil {
			log.Printf("[SearchOperators] Count query error: %v", cntErr)
			c.JSON(http.StatusInternalServerError, gin.H{
				"error":   "Failed to count records",
				"details": cntErr.Error(),
			})
			return
		}
		operators = allOperators
	}

	// ── 11. Calculate total pages ──────────────────────────────────────────────
	totalPages := 0
	if total > 0 {
		totalPages = total / pageSize
		if total%pageSize != 0 {
			totalPages++
		}
	}

	appliedFilters := models.OperatorSearchAppliedFilters{
		Query:      filterQuery,
		RO:         filterRO,
		State:      filterState,
		District:   filterDistrict,
		ID:         filterID,
		Name:       filterName,
		EA:         filterEA,
		EACode:     filterEACode,
		Reg:        filterReg,
		RegCode:    filterRegCode,
		RiskBucket: filterRiskBucket,
		Status:     filterStatus,
		SortBy:     sortBy,
		SortDir:    strings.ToLower(strings.TrimSpace(req.SortDir)),
	}

	logMsg := "[SearchOperators]"
	if isFuzzySearch {
		logMsg += " [FUZZY]"
	}
	logMsg += fmt.Sprintf(
		" query=%q ro=%s state=%q district=%q id=%q name=%q ea=%q ea_code=%q reg=%q reg_code=%q risk_bucket=%q status=%q sort=%q/%q → %d/%d records (page %d/%d)",
		filterQuery, filterRO, filterState, filterDistrict, filterID, filterName, filterEA, filterEACode, filterReg, filterRegCode, filterRiskBucket, filterStatus,
		appliedFilters.SortBy, appliedFilters.SortDir, len(operators), total, page, totalPages,
	)
	log.Printf(logMsg)

	c.JSON(http.StatusOK, models.OperatorSearchResponse{
		Data:           operators,
		Total:          total,
		Page:           page,
		PageSize:       pageSize,
		TotalPages:     totalPages,
		AppliedFilters: appliedFilters,
	})
}
