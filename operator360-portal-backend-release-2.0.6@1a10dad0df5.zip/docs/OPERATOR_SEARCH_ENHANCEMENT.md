# Enhanced Operator Search Feature

## Overview

The Enhanced Operator Search feature enables users to instantly find specific operator profiles using flexible, forgiving search logic. The implementation includes dual-field search and fuzzy matching algorithms that tolerate typos, partial entries, and spelling variations.

## Features

### 1. Dual-Field Search

The search functionality now accepts queries that are matched against:
- **Operator Name**: Full name or partial name matching
- **Operator ID**: Exact or fuzzy ID matching

### 2. Fuzzy Matching Logic

The fuzzy matching algorithm supports multiple matching strategies:

#### a) Exact Match (Score: 1.0)
When the query exactly matches the target (case-insensitive).
```
Query: "Airtel India"
Target: "Airtel India"
Score: 1.0
```

#### b) Exact Substring Match (Score: 0.85-0.95)
When the query is found as a substring within the target.
```
Query: "Airtel"
Target: "Airtel India Private Limited"
Score: 0.95 (prefix match - higher score)

Query: "India"
Target: "Airtel India Private Limited"
Score: 0.85 (middle match - lower score)
```

#### c) Prefix Match (Score: 0.90)
When the target starts with the query.
```
Query: "Air"
Target: "Airtel"
Score: 0.90
```

#### d) Acronym Matching (Score: 0.88-0.92)
When the query matches an acronym formed from the target's words.
```
Query: "ARTL"
Target: "Airtel"
Score: 0.92 (forms acronym A-R-T-L)

Query: "AP"
Target: "Airtel Private Limited"
Score: 0.92 (forms acronym A-P-L, but query matches A-P)
```

#### e) Fuzzy Matching via Levenshtein Distance (Score: 0.0-1.0)
Tolerates typos and spelling variations using edit distance.
```
Query: "Airtel"
Target: "Airtle"
Score: ~0.83 (one substitution needed)

Query: "Airtel"
Target: "Aitl"
Score: ~0.71 (acceptable fuzzy match)
```

## API Usage

### Endpoint
```
POST /api/operator_search
```

### Request Body Structure

```json
{
  "query": "Airtel",           // Optional: Fuzzy search across name and ID
  "ro": "Bangalore",            // Optional: Regional office filter
  "state": "Karnataka",         // Optional: State filter
  "district": "Bangalore",      // Optional: District filter
  "id": "OP123",                // Optional: Exact operator ID (ignored if query is provided)
  "name": "Operator Name",      // Optional: Exact operator name (ignored if query is provided)
  "ea": "East Anglia",          // Optional: Electrical Authority filter
  "ea_code": "EA123",           // Optional: EA code filter
  "reg": "Registrar Name",      // Optional: Registrar filter
  "reg_code": "REG123",         // Optional: Registrar code filter
  "risk_bucket": "High",        // Optional: Risk bucket filter (High|Medium|Low|No)
  "status": "active",           // Optional: Status filter (active|inactive)
  "sort_by": "risk_score",      // Optional: Sort column (risk_score|last_sync)
  "sort_dir": "desc",           // Optional: Sort direction (asc|desc)
  "page": 1,                    // Optional: Page number (default: 1)
  "page_size": 20               // Optional: Records per page (default: 20, max: 1000)
}
```

### Response Structure

```json
{
  "data": [
    {
      "id": "OP001",
      "uid": "UID001",
      "name": "Airtel India Private Limited",
      "phone": "+91-1234567890",
      "email": "contact@airtel.in",
      "risk_score": 75.5,
      "risk_bucket": "High",
      "reg": "Registrar Name",
      "reg_code": "REG123",
      "ea": "East Anglia",
      "ea_code": "EA123",
      "ro": "Bangalore",
      "district": "Bangalore",
      "state": "Karnataka",
      "last_sync_timestamp": "2025-09-15T10:30:00Z",
      "data_path": "/data/operators/op001",
      "status": "active",
      "last_packet_date": "2025-09-15T10:30:00Z",
      "dissociation_date": null,
      "dissociation_reason": null
    }
  ],
  "total": 152,
  "page": 1,
  "page_size": 20,
  "total_pages": 8,
  "applied_filters": {
    "query": "Airtel",
    "ro": "Bangalore",
    "state": "Karnataka",
    "district": "Bangalore",
    "id": "",
    "name": "",
    "ea": "",
    "ea_code": "",
    "reg": "",
    "reg_code": "",
    "risk_bucket": "",
    "status": "",
    "sort_by": "",
    "sort_dir": ""
  }
}
```

## Usage Examples

### Example 1: Fuzzy Search by Name
Find operators with names similar to "Airtel"
```bash
curl -X POST http://localhost:8080/api/operator_search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Airtel",
    "page": 1,
    "page_size": 20
  }'
```

### Example 2: Acronym-Based Search
Find operators using acronym matching
```bash
curl -X POST http://localhost:8080/api/operator_search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "ARTL",
    "page": 1,
    "page_size": 20
  }'
```

### Example 3: Typo-Tolerant Search
Find operators despite typos in the query
```bash
curl -X POST http://localhost:8080/api/operator_search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Airtle",  // Typo: "Airtle" instead of "Airtel"
    "page": 1,
    "page_size": 20
  }'
```

### Example 4: Search with Additional Filters
Combine fuzzy search with other filters
```bash
curl -X POST http://localhost:8080/api/operator_search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Airtel",
    "state": "Karnataka",
    "risk_bucket": "High",
    "status": "active",
    "page": 1,
    "page_size": 20
  }'
```

### Example 5: Traditional Exact Search (Backward Compatible)
Old-style exact searches still work
```bash
curl -X POST http://localhost:8080/api/operator_search \
  -H "Content-Type: application/json" \
  -d '{
    "id": "OP001",
    "ro": "Bangalore",
    "page": 1,
    "page_size": 20
  }'
```

## Search Algorithm Details

### Fuzzy Matching Flow

1. **Receive Query**: User enters a search query (e.g., "Airtel" or "ARTL")
2. **Fetch Candidates**: Fetch all operators matching other filters (state, district, risk_bucket, etc.)
3. **Calculate Scores**: For each candidate, calculate fuzzy match score:
   - Against operator ID
   - Against operator Name
   - Use the higher score
4. **Filter Results**: Exclude operators with score 0.0 (no match)
5. **Sort by Relevance**: Sort by fuzzy match score (descending)
6. **Apply Pagination**: Return the requested page of results

### Score Calculation Priority

The algorithm prioritizes matches in this order:
1. Exact match (score: 1.0)
2. Prefix match (score: 0.95)
3. Exact substring match at start (score: 0.95)
4. Exact substring match (score: 0.85)
5. Acronym match (score: 0.88-0.92)
6. Levenshtein-based fuzzy match (score: 0.0-1.0, threshold: 0.7)

## Performance Considerations

- **Database Query**: For fuzzy searches, all matching records are fetched from the database (with other filters applied), then fuzzy matching is done in-memory
- **Pagination Strategy**:
  - Fuzzy search: Fetch all candidates → sort by score → paginate
  - Exact search: Database-level pagination (more efficient)
- **Recommended Page Size**: 20-50 records for optimal performance
- **Maximum Page Size**: 1000 records

## Backward Compatibility

The implementation is fully backward compatible:
- Existing searches using `id`, `name`, `ea`, `reg`, etc. continue to work as exact matches
- The new `query` field is optional
- When `query` is not provided, the handler uses traditional exact-match filtering

## Implementation Files

### Modified Files
1. **models/optMaster.go**
   - Added `Query` field to `OperatorSearchRequest`
   - Added `Name` field to `OperatorSearchRequest`
   - Added `FuzzyMatchScore` field to `SearchOperator`
   - Added `Query` field to `OperatorSearchAppliedFilters`

2. **handlers/OperatorTab/operatorSearch.go**
   - Enhanced `SearchOperators()` function with fuzzy matching logic
   - Added fuzzy search detection
   - Implemented in-memory fuzzy matching and sorting
   - Added logging for fuzzy search operations

### New Files
1. **utils/fuzzyutils.go**
   - `CalculateFuzzyScore()`: Main fuzzy matching function
   - `calculateAcronymScore()`: Acronym matching logic
   - `calculateLevenshteinScore()`: Edit distance-based matching
   - `levenshteinDistance()`: Levenshtein distance calculation

## Logging

The handler logs all search operations with details:
```
[SearchOperators] [FUZZY] query="Airtel" ro=Bangalore state="Karnataka" ... → 15/152 records (page 1/8)
```

The `[FUZZY]` tag indicates a fuzzy search was performed.

## Future Enhancements

Potential improvements:
1. Caching of frequently searched operators
2. Machine learning-based ranking
3. Phonetic matching (e.g., Soundex, Metaphone)
4. Partial word matching with word boundaries
5. Search result popularity scoring
6. Analytics tracking for search queries
