package auth

import (
	"log"
	"sync"
	"time"

	"opt360-portal-backend/db"
	"opt360-portal-backend/models"
)

// userCacheTTL is how long a cached user lookup is considered fresh.
// Short enough that status/role/group changes propagate quickly, long enough
// to keep the auth middleware off the DB on every request.
const userCacheTTL = 5 * time.Minute

type cachedUser struct {
	user      *models.User
	cachedAt  time.Time
}

var (
	userCache   sync.Map // adID -> *cachedUser
)

// GetUserByADID retrieves user information from database, with an in-memory
// cache to avoid hitting the DB on every authenticated request (the auth
// middleware calls this on every /api/* call). Cache misses fall through to
// db.GetUserByADID; hits return the cached entry if still fresh.
func GetUserByADID(adID string) (*models.User, bool) {
	// Cache lookup
	if entry, ok := userCache.Load(adID); ok {
		cu := entry.(*cachedUser)
		if time.Since(cu.cachedAt) < userCacheTTL {
			return cu.user, true
		}
		// Stale — fall through to DB and refresh
	}

	user, err := db.GetUserByADID(adID)
	if err != nil {
		log.Printf("Error getting user by ADID '%s': %v", adID, err)
		return nil, false
	}

	userCache.Store(adID, &cachedUser{user: user, cachedAt: time.Now()})
	return user, true
}

// InvalidateUserCache removes a single user's cached entry. Call this after
// any mutation that changes the user's DB state (status, role, group, email)
// so the next auth middleware lookup sees the fresh value instead of waiting
// for the TTL to expire.
func InvalidateUserCache(adID string) {
	userCache.Delete(adID)
}

// GetAllUsers retrieves all users from database
func GetAllUsers() ([]models.User, error) {
	return db.GetAllUsers()
}
