"""Entry point: an interactive REPL.

Usage:  python main.py
Then type coding tasks. The agent runs the loop and replies. Type 'exit' to quit.

This file is intentionally trivial — the interesting logic lives in agent.py.
"""
from agent import Agent
from model import ModelClient


def main():
    print("=" * 60)
    print("  coding-agent  -  powered by GLM-5.2")
    print("  type a coding task, or 'exit' to quit")
    print("=" * 60)

    agent = Agent(ModelClient())

    while True:
        try:
            goal = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not goal:
            continue
        if goal.lower() in {"exit", "quit"}:
            break

        try:
            answer = agent.run(goal)
            print(f"\n[DONE] {answer}")
        except Exception as e:
            print(f"\n[ERROR] agent error: {type(e).__name__}: {e}")


if __name__ == "__main__":
    main()
