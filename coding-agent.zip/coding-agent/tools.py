"""The agent's tools — its "hands and eyes".

FLOW PERSPECTIVE: every tool here is a plain Python function. The model cannot
call them directly. Instead:
  1. The model emits a tool-call intent (name + arguments).
  2. The agent loop (agent.py) looks up the function by name and runs it.
  3. The return value (always a STRING) is fed back to the model as a
     `role=tool` message. That's how the model "sees" what happened.

Each tool is described to the model by a JSON schema (TOOL_SPECS). The model
reads those descriptions to decide WHICH tool fits its current need. Good
descriptions = good tool use; vague ones = the model misuses tools.
"""
from __future__ import annotations

import fnmatch
import re
import subprocess
from pathlib import Path

# Each entry is the OpenAI function-tool shape: name, description, JSON schema.
TOOL_SPECS: list[dict] = []
TOOL_REGISTRY: dict[str, callable] = {}


def _tool(name: str, description: str, params: dict):
    """Decorator: register a function as an agent tool + record its schema."""
    def deco(fn):
        TOOL_REGISTRY[name] = fn
        TOOL_SPECS.append({
            "type": "function",
            "function": {
                "name": name,
                "description": description,
                "parameters": params,
            },
        })
        return fn
    return deco


# --- read ---------------------------------------------------------------------
_read_params = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "description": "Path to the file or directory to read."},
        "offset": {"type": "integer", "description": "1-based line to start at (optional)."},
        "limit": {"type": "integer", "description": "Max lines to read (optional)."},
    },
    "required": ["path"],
}


@_tool("read", "Read a file's contents (with line numbers) or list a directory.", _read_params)
def read(path: str, offset: int = 1, limit: int = 2000) -> str:
    p = Path(path)
    if not p.exists():
        return f"ERROR: path does not exist: {path}"
    if p.is_dir():
        entries = sorted(p.iterdir(), key=lambda x: (x.is_file(), x.name.lower()))
        return "\n".join(("d " if e.is_dir() else "f ") + e.name for e in entries) or "(empty directory)"
    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    start = max(1, offset)
    end = min(len(lines), start + limit - 1)
    # 1-based line numbers let the model cite/target lines precisely.
    return "\n".join(f"{i}: {lines[i-1]}" for i in range(start, end + 1))


# --- write --------------------------------------------------------------------
_write_params = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "description": "Path of the file to create or overwrite."},
        "content": {"type": "string", "description": "Full contents to write."},
    },
    "required": ["path", "content"],
}


@_tool("write", "Create or fully overwrite a file. Use `edit` for partial changes.", _write_params)
def write(path: str, content: str) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"OK: wrote {len(content)} chars to {path}"


# --- edit ---------------------------------------------------------------------
_edit_params = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "description": "Path of the file to edit."},
        "old_string": {"type": "string", "description": "Exact text to find (must be unique)."},
        "new_string": {"type": "string", "description": "Text to replace it with."},
        "replace_all": {"type": "boolean", "description": "Replace every occurrence (default false)."},
    },
    "required": ["path", "old_string", "new_string"],
}


@_tool("edit", "Find-and-replace an EXACT block in a file. Fails if old_string is missing or not unique (unless replace_all).", _edit_params)
def edit(path: str, old_string: str, new_string: str, replace_all: bool = False) -> str:
    p = Path(path)
    if not p.exists():
        return f"ERROR: file does not exist: {path}"
    text = p.read_text(encoding="utf-8")
    count = text.count(old_string)
    if count == 0:
        # This error message is a FREE CORRECTION SIGNAL — the model re-reads and retries.
        return f"ERROR: old_string not found in {path}. Re-read the file; it may have changed."
    if count > 1 and not replace_all:
        return f"ERROR: old_string matches {count} places in {path}. Add context to make it unique, or set replace_all=true."
    new_text = text.replace(old_string, new_string) if replace_all else text.replace(old_string, new_string, 1)
    p.write_text(new_text, encoding="utf-8")
    return f"OK: replaced {count if replace_all else 1} occurrence(s) in {path}"


# --- shell --------------------------------------------------------------------
_shell_params = {
    "type": "object",
    "properties": {
        "command": {"type": "string", "description": "Shell command to run (Windows cmd)."},
    },
    "required": ["command"],
}


@_tool("shell", "Run a shell command and return stdout+stderr (truncated). Use for tests, builds, grep, etc.", _shell_params)
def shell(command: str) -> str:
    # NOTE: a production agent adds permission prompts + sandboxing here.
    try:
        r = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=120)
        out = (r.stdout + r.stderr).strip()
        if len(out) > 8000:
            out = out[:8000] + f"\n... (truncated, {len(out)-8000} more chars)"
        return out or "(no output)"
    except subprocess.TimeoutExpired:
        return "ERROR: command timed out after 120s"


# --- grep ---------------------------------------------------------------------
_grep_params = {
    "type": "object",
    "properties": {
        "pattern": {"type": "string", "description": "Regex to search for."},
        "path": {"type": "string", "description": "File or directory to search (default cwd)."},
    },
    "required": ["pattern"],
}


@_tool("grep", "Search file contents for a regex. Returns matching lines with file:line prefixes.", _grep_params)
def grep(pattern: str, path: str = ".") -> str:
    regex = re.compile(pattern)
    root = Path(path)
    hits = []
    files = [root] if root.is_file() else [p for p in root.rglob("*") if p.is_file()]
    for f in files:
        try:
            for i, line in enumerate(f.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                if regex.search(line):
                    hits.append(f"{f}:{i}: {line}")
        except OSError:
            continue
        if len(hits) > 200:
            hits.append("... (truncated at 200 hits)")
            break
    return "\n".join(hits) if hits else "(no matches)"


# --- glob ---------------------------------------------------------------------
_glob_params = {
    "type": "object",
    "properties": {
        "pattern": {"type": "string", "description": "Glob pattern, e.g. '**/*.py' or 'src/*.ts'."},
        "path": {"type": "string", "description": "Directory to search (default cwd)."},
    },
    "required": ["pattern"],
}


@_tool("glob", "Find files by name pattern (e.g. '**/*.py'). Returns paths.", _glob_params)
def glob(pattern: str, path: str = ".") -> str:
    root = Path(path)
    matches = []
    for p in root.rglob("*"):
        rel = str(p.relative_to(root))
        if fnmatch.fnmatch(rel, pattern) or fnmatch.fnmatch(p.name, pattern):
            matches.append(str(p))
        if len(matches) > 200:
            matches.append("... (truncated at 200)")
            break
    return "\n".join(matches) if matches else "(no matches)"
