"""A calculator for basic statistics on a list of numbers.

NOTE: This script has SEVERAL BUGS on purpose. Feed it to the coding agent and
watch the think-act-observe loop find and fix them one by one.

Run (when fixed):  python buggy_stats.py
"""
from typing import List


def mean(numbers: List[float]) -> float:
    """Return the average of a list of numbers."""
    # BUG 1: division by zero if the list is empty
    #        (also: no guard against empty input)
    return sum(numbers) / len(numbers)


def median(numbers: List[float]) -> float:
    """Return the median value."""
    # BUG 2: the function assumes the list is sorted, but the caller
    #        passes unsorted data -> silently wrong answers
    n = len(numbers)
    mid = n // 2
    if n % 2 == 1:
        return numbers[mid]
    return (numbers[mid - 1] + numbers[mid]) / 2


def mode(numbers: List[float]) -> float:
    """Return the most common value."""
    # BUG 3: returns the value with the LOWEST count, not the highest
    #        (the max/min are swapped). Behavior looks plausible but is wrong.
    counts = {}
    for num in numbers:
        counts[num] = counts.get(num, 0) + 1
    return min(counts, key=counts.get)


def variance(numbers: List[float]) -> float:
    """Return the population variance."""
    # BUG 4: off-by-one in the denominator (population vs sample confusion),
    #        and uses `mean` of the SQUARES instead of mean of (x - mean)^2
    #        -> wrong formula entirely, but no crash
    n = len(numbers)
    m = mean(numbers)
    return sum((x - m) ** 2 for x in numbers) / (n - 1)  # should be / n for population


def summarize(numbers: List[float]) -> dict:
    """Return a summary dict of all stats."""
    # BUG 5: typo'd key "meen" instead of "mean" -> downstream code breaks
    return {
        "meen": mean(numbers),
        "median": median(numbers),
        "mode": mode(numbers),
        "variance": variance(numbers),
    }


def main():
    # BUG 6: the input list is not sorted before being passed to median(),
    #        which combines with BUG 2 to produce a wrong median.
    data = [4, 1, 7, 3, 9, 2, 8, 5, 6]

    print("=== Statistics Summary ===")
    print(f"Data:      {data}")
    print(f"Count:     {len(data)}")
    print(f"Mean:      {mean(data)}")
    print(f"Median:    {median(data)}")
    print(f"Mode:      {mode(data)}")
    print(f"Variance:  {variance(data)}")
    print(f"Summary:   {summarize(data)}")

    # Bonus: this call will crash with ZeroDivisionError once BUG 1 is unfixed
    print("Empty mean:", mean([]))


if __name__ == "__main__":
    main()
