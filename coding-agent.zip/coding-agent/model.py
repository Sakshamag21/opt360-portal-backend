"""The ModelClient: how the agent talks to the LLM (the "brain").

This file is intentionally tiny and isolated. The agent loop (agent.py) calls
`ModelClient.chat(...)` and gets back a normalized Response. It does not care
about HTTP, JSON, or OpenAI-specific shapes — that's all hidden here.

KEY FLOW IDEA: the model is STATELESS. Each `chat()` call sends the ENTIRE
conversation history (`messages`) plus the tool catalog (`tools`). The model
has no memory between calls — the `messages` array IS its memory. The agent
loop is what grows that array turn by turn.
"""
from __future__ import annotations

import json
import urllib.request
from dataclasses import dataclass, field

from config import API_KEY, BASE_URL, MODEL_ID


@dataclass
class ToolCall:
    """A single tool-call INTENT emitted by the model.

    The model does NOT run this tool — it only expresses the intent to.
    The agent loop is responsible for actually executing it (see agent.py).
    """
    id: str          # correlation id; must be echoed back in the tool result
    name: str        # which tool, e.g. "read"
    arguments: dict  # parsed args, e.g. {"path": "foo.py"}


@dataclass
class Response:
    """Normalized model response: a text reply, a set of tool calls, or both."""
    content: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)

    @property
    def wants_to_use_tools(self) -> bool:
        return bool(self.tool_calls)

    @property
    def is_final(self) -> bool:
        """The loop ENDS when the model replies with NO tool calls."""
        return not self.wants_to_use_tools


class ModelClient:
    """Thin OpenAI-compatible chat-completions client for GLM 5.2."""

    def __init__(self, base_url: str = BASE_URL, model: str = MODEL_ID, api_key: str = API_KEY):
        self.base_url = base_url
        self.model = model
        self.api_key = api_key

    def chat(self, messages: list[dict], tools: list[dict]) -> Response:
        """Send the conversation + tool catalog to the model, get back a Response.

        `messages` = full history (system, user, assistant, tool results).
        `tools`    = schema of available tools (see tools.py).
        """
        payload = {
            "model": self.model,
            "messages": messages,
            "tools": tools,
            "temperature": 0,  # deterministic-ish; coding wants precision
        }
        body = self._post("/chat/completions", payload)

        choice = body["choices"][0]
        msg = choice["message"]

        # Parse tool-call intents. NOTE: `arguments` comes back as a JSON
        # *string* in the OpenAI format, so we parse it to a dict here so the
        # agent loop can work with it cleanly.
        tool_calls = []
        for tc in msg.get("tool_calls") or []:
            try:
                args = json.loads(tc["function"]["arguments"])
            except (json.JSONDecodeError, KeyError):
                args = {}
            tool_calls.append(ToolCall(
                id=tc["id"],
                name=tc["function"]["name"],
                arguments=args,
            ))

        return Response(content=msg.get("content"), tool_calls=tool_calls)

    def _post(self, path: str, payload: dict) -> dict:
        url = f"{self.base_url}{path}"
        data = json.dumps(payload).encode()
        req = urllib.request.Request(url, data=data)
        req.add_header("Content-Type", "application/json")
        if self.api_key and self.api_key != "not-required":
            req.add_header("Authorization", f"Bearer {self.api_key}")
        with urllib.request.urlopen(req, timeout=120) as r:
            return json.loads(r.read().decode())
