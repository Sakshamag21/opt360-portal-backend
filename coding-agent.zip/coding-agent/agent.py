"""THE AGENT LOOP — the heart of how a coding agent works.

Read this file top-to-bottom; it's the whole point. Everything else
(model.py, tools.py) is plumbing. THE LOOP is the idea.

THE PATTERN (ReAct — Reason + Act):

    user gives a GOAL
    ┌─────────────────────────────────────────────────┐
    │ 1. THINK:    model proposes the next action     │  <- model.chat()
    │ 2. ACT:      agent runs the tool the model      │  <- _dispatch()
    │              asked for (read/edit/shell/...)     │
    │ 3. OBSERVE:  result goes back into `messages`   │  <- role=tool message
    │ 4. LOOP:     model thinks again WITH the new    │
    │              observation in context              │
    │ 5. STOP:     when the model replies with NO     │  <- response.is_final
    │              tool calls -> done, show the answer │
    └─────────────────────────────────────────────────┘

THREE THINGS TO NOTICE:
  (a) The model never executes anything. It only emits INTENTS (tool calls).
      The agent loop is the only thing that touches the filesystem / shell.
  (b) The model has no memory. The `messages` list IS its memory — it grows
      each turn and is re-sent in full on every model call.
  (c) Observation changes reasoning. When a tool returns an error, the model
      sees it and adjusts. That feedback is what makes the loop CONVERGE on a
      correct result instead of guessing once and being wrong.
"""
from __future__ import annotations

import json

from config import MAX_ITERATIONS, SYSTEM_PROMPT
from model import ModelClient, Response
from tools import TOOL_REGISTRY, TOOL_SPECS


class Agent:
    def __init__(self, model: ModelClient | None = None):
        self.model = model or ModelClient()
        # messages = the running conversation, including tool calls + results.
        # This is the agent's MEMORY. Seeded with the system prompt.
        self.messages: list[dict] = [{"role": "system", "content": SYSTEM_PROMPT}]

    def run(self, goal: str) -> str:
        """Run the full think-act-observe loop for a user goal. Returns the final answer."""
        # Seed the conversation with the user's goal.
        self.messages.append({"role": "user", "content": goal})

        for step in range(1, MAX_ITERATIONS + 1):
            print(f"\n— step {step} —")

            # 1. THINK: ask the model what to do next, given the WHOLE history
            #    and the catalog of tools it's allowed to call.
            response = self.model.chat(self.messages, TOOL_SPECS)

            # Record the assistant's turn in memory (future turns will see it).
            self.messages.append(self._assistant_message(response))

            # 2. DECIDE: is the model done, or does it want to call a tool?
            if response.is_final:
                # No tool calls -> the model is handing back a final answer.
                return response.content or "(no response)"

            # 3. ACT + OBSERVE: run each requested tool, feed results back.
            for call in response.tool_calls:
                print(f"  -> {call.name}({json.dumps(call.arguments)[:120]})")
                result = self._dispatch(call.name, call.arguments)
                # Truncate huge results so one tool doesn't blow up context.
                preview = result if len(result) <= 6000 else result[:6000] + "\n... (truncated)"
                # 4. OBSERVE: the tool result becomes a message the model sees next turn.
                self.messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": preview,
                })
            # 5. LOOP: back to step 1. The model now thinks again WITH the new
            #    tool results in context.

        return "WARNING: hit MAX_ITERATIONS without the model finishing."

    # --- dispatch -------------------------------------------------------------
    def _dispatch(self, name: str, args: dict) -> str:
        """Look up a tool by name and run it. This is the ONLY execution path.

        Everything the agent does to the outside world funnels through here.
        That centralization is what makes tools auditable + safe to gate later.
        """
        fn = TOOL_REGISTRY.get(name)
        if fn is None:
            return f"ERROR: unknown tool '{name}'. Available: {list(TOOL_REGISTRY)}"
        try:
            return fn(**args)
        except TypeError as e:
            return f"ERROR: bad arguments for '{name}': {e}"
        except Exception as e:
            return f"ERROR: {type(e).__name__}: {e}"

    # --- message shaping ------------------------------------------------------
    @staticmethod
    def _assistant_message(response: Response) -> dict:
        """Rebuild the assistant message in OpenAI shape, including tool_calls.

        The model's tool-call intents must be echoed back into context verbatim
        (with matching ids) so the next turn's tool results can be correlated.
        """
        msg: dict = {"role": "assistant", "content": response.content}
        if response.tool_calls:
            msg["tool_calls"] = [
                {
                    "id": c.id,
                    "type": "function",
                    "function": {
                        "name": c.name,
                        "arguments": json.dumps(c.arguments),
                    },
                }
                for c in response.tool_calls
            ]
        return msg
