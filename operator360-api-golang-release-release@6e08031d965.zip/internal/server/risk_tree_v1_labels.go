package server

// Display copy for GET /api/v1/risk-tree-1. The feature registry has ids and
// long generated descriptions but no short UI labels, so they live here.
// Anything not listed falls back to a humanized id (names), the registry
// description's first sentence (checks) and params-derived text (window).
// Move these into registry columns once the registry grows them.

type signalLabel struct {
	Name   string
	Checks string
	Window string // overrides the params-derived window when the registry has no period_in_days
}

var signalLabels = map[string]signalLabel{
	// Biometrics
	"bio_mfc_fraud_score_v2": {Name: "Manual biometric fraud",
		Checks: "Packets flagged for finger, iris or face swap, mixing, non-human capture or proof-of-presence issues, ranked against all operators."},
	"bio_sfc_fraud_score_v2": {Name: "Systematic fraud stage",
		Checks: "Non-systematic packets made while the operator was in a systematic-fraud stage.",
		Window: "Cumulative · compared with all operators"},

	// Work
	"work_machine_change_score_v2": {Name: "Machines used",
		Checks: "Number of different machines the operator has worked on.",
		Window: "Last 90 days · compared with all operators"},
	"work_opt_hof_score_v2": {Name: "Marked as head of family",
		Checks: "Residents for whom the operator is recorded as head of family.",
		Window: "Since 2020 · compared with all operators"},
	"work_multiple_optname_score_v2": {Name: "Multiple operator names",
		Checks: "Distinct names the operator has used.",
		Window: "Since 2020 · compared with all operators"},
	"work_pob_declared_score_v2": {Name: "Proof of birth declared",
		Checks: "Packets where the operator declared a resident's proof of birth.",
		Window: "Last 365 days · compared with all operators"},
	"work_opt_machinesync_score_v2": {Name: "Machine sync gaps",
		Checks: "Packets created while the operator's machine was not syncing."},

	// Authentication
	"auth_device_change_score_v2": {Name: "Device or modality changes",
		Checks: "Times the operator switched authentication device or modality (finger, iris, face)."},
	"auth_oddhour_txn_score_v2": {Name: "Odd-hour authentication",
		Checks: "Authentications between 10 pm and 6 am."},
	"auth_liveness_failure_streak_score_v2": {Name: "Liveness failure streak",
		Checks: "Consecutive liveness failures, with recent failures weighted more."},
	"auth_failure_ratio_score_v2": {Name: "Authentication failure ratio",
		Checks: "Share of the operator's authentications that failed, corrected for low volume."},
	"auth_txn_failure_gap_score_v2": {Name: "Gap between failures",
		Checks: "Average time between failed authentications.",
		Window: "Last 7 days"},

	// Suspicious transactions
	"sustxn_outstate_pkts_score_v2": {Name: "Out-of-state packets",
		Checks: "Packets for residents from a different state than the operator."},
	"sustxn_oddhour_pkts_score_v2": {Name: "Packets outside working hours",
		Checks: "Packets made after the declared working hours."},
	"sustxn_res_mobilechange_score_v2": {Name: "Resident mobile changes",
		Checks: "Mobile number changes per resident.",
		Window: "Since 2020 · compared with all operators"},
	"sustxn_res_namechange_score_v2": {Name: "Resident name changes",
		Checks: "Name changes for the same resident.",
		Window: "Since 2020 · compared with all operators"},
	"sustxn_parallel_enrolment_score_v2": {Name: "Parallel enrolments",
		Checks: "Enrolments the operator ran in parallel."},

	// Hardware (the category config weights hardware_machine_change_score_v2,
	// the PROD signal is hardware_machine_signature_change_score_v2)
	"hardware_machine_signature_change_score_v2": {Name: "Machine signature changes",
		Checks: "Packets made on a machine whose signature changed."},
	"hardware_machine_change_score_v2": {Name: "Machine signature changes",
		Checks: "Packets made on a machine whose signature changed."},
	"hardware_multiple_biodev_score_v2": {Name: "Multiple biometric devices",
		Checks: "Number of biometric devices the operator used."},

	// Document (ranked directly on raw features, served as one signal)
	"document_category_score_v2": {Name: "QC errors on documents",
		Checks: "QC verdicts on proof-of-presence (PoP) and date-of-entry (DOE1) documents."},
	"doc_qc_error_score_v2": {Name: "QC errors on documents",
		Checks: "QC verdicts on proof-of-presence (PoP) and date-of-entry (DOE1) documents."},
}

var featureLabels = map[string]string{
	// Biometrics
	"bio_packet_finger_swap_count_daily_v1":         "Finger-swap packets",
	"bio_packet_finger_mixed_count_daily_v1":        "Finger-mixed packets",
	"bio_packet_finger_toe_print_count_daily_v1":    "Toe-print packets",
	"bio_packet_face_pop_count_daily_v1":            "Face proof-of-presence packets",
	"bio_packet_iris_pop_count_daily_v1":            "Iris proof-of-presence packets",
	"bio_packet_iris_non_human_count_daily_v1":      "Non-human iris packets",
	"bio_packet_face_non_human_count_daily_v1":      "Non-human face packets",
	"bio_packet_iris_mixed_count_daily_v1":          "Iris-mixed packets",
	"bio_packet_iris_swap_count_daily_v1":           "Iris-swap packets",
	"bio_packet_face_adult_as_child_count_daily_v1": "Adult captured as child packets",
	"bio_packet_fraud_count_daily_v1":               "Biometric fraud packets",
	"bio_packet_finger_fraud_count_daily_v1":        "Finger fraud packets",
	"bio_packet_slap_right_fraud_count_daily_v1":    "Right-slap fraud packets",
	"bio_packet_slap_right_swap_count_daily_v1":     "Right-slap swap packets",
	"bio_sfc_fraud_incidents_v1":                    "Systematic-fraud-stage packets",

	// Work
	"work_operator_name_unique_count_cumulative_v1":   "Unique names used",
	"work_machine_change_instances_v1":                "Machines used",
	"work_opt_hof_instances_v1":                       "Head-of-family residents",
	"work_pob_declared_instances_v1":                  "Proof-of-birth declarations",
	"work_machine_sync_gap_v1":                        "Machine sync gap",
	"work_packet_upload_total_count_daily_v1":         "Packets uploaded",
	"work_packet_upload_new_count_daily_v1":           "New enrolment packets",
	"work_packet_upload_update_count_daily_v1":        "Update packets",
	"work_machine_unique_count_daily_v1":              "Unique machines (day)",
	"work_machine_change_instances_24h_v1":            "Machine changes (24h)",
	"work_machine_ip_change_instances_count_daily_v1": "Machine IP changes",
	"work_machineip_isp_change_count_daily_v1":        "ISP switches (day)",
	"work_machineip_isp_change_count_cumulative_v1":   "ISP switches (all time)",

	// Authentication
	"auth_modality_change_incidents_24h_v1":      "Modality switches",
	"auth_device_change_incidents_Finger_24h_v1": "Finger device changes",
	"auth_device_change_incidents_Iris_24h_v1":   "Iris device changes",
	"auth_oddhour_incidents_24h_v1":              "Odd-hour authentications",
	"auth_liveness_failure_streak_live_v1":       "Liveness failure streak",
	"auth_txn_failure_count_1h_v1":               "Failed authentications",
	"auth_txn_count_1h_v1":                       "Authentications",
	"auth_txn_failure_gap_sec_live_v1":           "Seconds between failures",
	"auth_liveness_failure_incidents_24h_v2":     "Liveness failures",
	"auth_device_change_incidents_v1":            "Device changes",
	"auth_biomismatch_incidents_24h_v1":          "Biometric mismatches",

	// Suspicious transactions
	"sustxn_outstate_pkts_instances_24h_v2":                 "Out-of-state packets",
	"sustxn_oddhour_pkts_instances_24h_v2":                  "Odd-hour packets",
	"sustxn_oddhour_pkts_instances_24h_v1":                  "Odd-hour packets (v1, deprecated)",
	"sustxn_res_mobilechange_instances_count_cumulative_v2": "Resident mobile changes",
	"sustxn_res_namechange_instances_count_cumulative_v2":   "Resident name changes",
	"sustxn_parallel_enrolment_eid_count_daily_v1":          "Parallel enrolments",

	// Hardware
	"hardware_machine_change_instances_24h_v2":  "Packets on changed-signature machines",
	"hardware_multiple_biodev_instances_24h_v2": "Biometric devices used",

	// Document
	"doc_qc_error_pop_incidents_count_daily_v1":  "PoP QC errors",
	"doc_qc_error_doe1_incidents_count_daily_v1": "DOE1 QC errors",
}
