package server

import (
	"encoding/json"
	"reflect"
	"strings"
	"testing"
	"time"
)

func TestParseDependentFeatures(t *testing.T) {
	// Real registry value, including the newlines and stray spaces it has.
	mfc := `[scoring_method:rank_scoring, feature_id:[bio_packet_finger_toe_print_count_daily_v1,bio_packet_face_pop_count_daily_v1
     ,bio_packet_finger_swap_count_daily_v1,
     bio_packet_face_adult_as_child_count_daily_v1], range_start:0, range_end:1, weights:{bio_packet_finger_toe_print_count_daily_v1:10,
     bio_packet_face_pop_count_daily_v1:8 ,
     bio_packet_finger_swap_count_daily_v1:4,
     bio_packet_face_adult_as_child_count_daily_v1:2
     }, method:weighted_average, period_in_days:30]`
	p := parseDependentFeatures(mfc)

	wantIDs := []string{
		"bio_packet_finger_toe_print_count_daily_v1", "bio_packet_face_pop_count_daily_v1",
		"bio_packet_finger_swap_count_daily_v1", "bio_packet_face_adult_as_child_count_daily_v1",
	}
	if got := p["feature_id"].List; !reflect.DeepEqual(got, wantIDs) {
		t.Errorf("feature_id = %v, want %v", got, wantIDs)
	}
	if got := p["weights"].Map["bio_packet_face_pop_count_daily_v1"]; got != 8 {
		t.Errorf("weights[face_pop] = %v, want 8", got)
	}
	if got := p["period_in_days"].Raw; got != "30" {
		t.Errorf("period_in_days = %q, want 30", got)
	}

	cat := parseDependentFeatures("[risk_weightage:{work_category_score_v2:1, bio_category_score_v2:1,hardware_category_score_v2:1}, scoring_function:max_scoring]")
	if len(cat["risk_weightage"].Map) != 3 || cat["scoring_function"].Raw != "max_scoring" {
		t.Errorf("category params parsed wrong: %+v", cat)
	}

	ratio := registryNode{Params: parseDependentFeatures("[scoring_method:wilson_fraud_scoring, feature_id_numerator:auth_txn_failure_count_1h_v1, feature_id_denominator:auth_txn_count_1h_v1, period_in_days:30]")}
	if got := ratio.inputIDs(); !reflect.DeepEqual(got, []string{"auth_txn_failure_count_1h_v1", "auth_txn_count_1h_v1"}) {
		t.Errorf("ratio inputs = %v", got)
	}
}

func TestInfluenceFor(t *testing.T) {
	cases := []struct {
		w, max   float64
		allEqual bool
		want     string
	}{
		{4, 4, false, "high"},
		{2, 4, false, "medium"},
		{1, 4, false, "low"},
		{2, 2, true, "equal"},
	}
	for _, c := range cases {
		if got := influenceFor(c.w, c.max, c.allEqual); got != c.want {
			t.Errorf("influenceFor(%v, %v, %v) = %q, want %q", c.w, c.max, c.allEqual, got, c.want)
		}
	}
}

// exampleRegistry is the PROD registry slice needed for the example operator,
// with dependent_features copied from the registry.
func exampleRegistry() map[string]registryNode {
	rows := map[string]string{
		"bio_category_score_v2":                 "[risk_weightage:{bio_sfc_fraud_score_v2:1, bio_mfc_fraud_score_v2:4}, scoring_function:softmax_scoring]",
		"bio_mfc_fraud_score_v2":                "[scoring_method:rank_scoring, feature_id:[bio_packet_finger_toe_print_count_daily_v1,bio_packet_face_pop_count_daily_v1,bio_packet_iris_pop_count_daily_v1,bio_packet_iris_non_human_count_daily_v1,bio_packet_face_non_human_count_daily_v1,bio_packet_iris_mixed_count_daily_v1,bio_packet_iris_swap_count_daily_v1,bio_packet_finger_swap_count_daily_v1,bio_packet_finger_mixed_count_daily_v1,bio_packet_face_adult_as_child_count_daily_v1], range_start:0, range_end:1, method:weighted_average, period_in_days:30]",
		"bio_sfc_fraud_score_v2":                "[scoring_method:rank_scoring, feature_id:bio_sfc_fraud_incidents_v1, range_start:0, range_end:1]",
		"work_category_score_v2":                "[risk_weightage:{work_machine_change_score_v2:4,work_opt_hof_score_v2:4,work_pob_declared_score_v2:2,work_opt_machinesync_score_v2:2,work_multiple_optname_score_v2:4}, scoring_function:softmax_scoring]",
		"work_machine_change_score_v2":          "[scoring_method:rank_scoring, feature_id:work_machine_change_instances_v1, range_start:0.5, range_end:1]",
		"work_opt_hof_score_v2":                 "[scoring_method:rank_scoring, feature_id:work_opt_hof_instances_v1]",
		"work_pob_declared_score_v2":            "[scoring_method:rank_scoring, feature_id:work_pob_declared_instances_v1]",
		"work_opt_machinesync_score_v2":         "[scoring_method:rank_scoring, feature_id:work_machine_sync_gap_v1]",
		"work_multiple_optname_score_v2":        "[scoring_method:rank_scoring, feature_id:work_operator_name_unique_count_cumulative_v1]",
		"auth_category_score_v2":                "[risk_weightage:{auth_device_change_score_v2:1, auth_failure_ratio_score_v2:1,auth_liveness_failure_streak_score_v2:1,auth_oddhour_txn_score_v2:1,auth_txn_failure_gap_score_v2:1}, scoring_function:softmax_scoring]",
		"auth_device_change_score_v2":           "[scoring_method:winsorized_zscoring, feature_id:[auth_device_change_incidents_Finger_24h_v1,auth_device_change_incidents_Iris_24h_v1,auth_modality_change_incidents_24h_v1], period_in_days:30]",
		"auth_failure_ratio_score_v2":           "[scoring_method:wilson_fraud_scoring, feature_id_numerator:auth_txn_failure_count_1h_v1, feature_id_denominator:auth_txn_count_1h_v1, period_in_days:30]",
		"auth_liveness_failure_streak_score_v2": "[scoring_method:exponential_decay_scoring, feature_id:auth_liveness_failure_streak_live_v1, period_in_days:30]",
		"auth_oddhour_txn_score_v2":             "[scoring_method:winsorized_zscoring, feature_id:auth_oddhour_incidents_24h_v1, period_in_days:30]",
		// auth_txn_failure_gap_score_v2 deliberately absent: it is not PROD.
		"sustxn_category_score_v2":         "[risk_weightage:{sustxn_outstate_pkts_score_v2:2, sustxn_res_mobilechange_score_v2:2,sustxn_oddhour_pkts_score_v2:2,sustxn_res_namechange_score_v2:2}, scoring_function:softmax_scoring]",
		"sustxn_outstate_pkts_score_v2":    "[scoring_method:rank_scoring, feature_id:sustxn_outstate_pkts_instances_24h_v2, period_in_days:30]",
		"sustxn_oddhour_pkts_score_v2":     "[scoring_method:rank_scoring, feature_id:sustxn_oddhour_pkts_instances_24h_v2, period_in_days:30]",
		"sustxn_res_mobilechange_score_v2": "[scoring_method:rank_scoring, feature_id:sustxn_res_mobilechange_instances_count_cumulative_v2]",
		"sustxn_res_namechange_score_v2":   "[scoring_method:rank_scoring, feature_id:sustxn_res_namechange_instances_count_cumulative_v2]",
		// Registry mismatch reproduced: the category weights
		// hardware_machine_change_score_v2, the PROD signal has another id.
		"hardware_category_score_v2":                 "[risk_weightage:{hardware_machine_change_score_v2:4, hardware_multiple_biodev_score_v2:4}, scoring_function:softmax_scoring]",
		"hardware_machine_signature_change_score_v2": "[scoring_method:rank_scoring, feature_id:hardware_machine_change_instances_24h_v2]",
		"hardware_multiple_biodev_score_v2":          "[scoring_method:rank_scoring, feature_id:hardware_multiple_biodev_instances_24h_v2, period_in_days:30]",
		"document_category_score_v2":                 "[scoring_method:rank_scoring, feature_id:[doc_qc_error_doe1_incidents_count_daily_v1, doc_qc_error_pop_incidents_count_daily_v1], method:weighted_average]",
	}
	reg := map[string]registryNode{}
	for id, deps := range rows {
		reg[id] = registryNode{FeatureID: id, FeatureName: stripVersion(id), Params: parseDependentFeatures(deps)}
	}
	return reg
}

func mustTime(t *testing.T, s string) time.Time {
	t.Helper()
	v, err := time.Parse(time.RFC3339, s)
	if err != nil {
		t.Fatal(err)
	}
	return v
}

// exampleInput is operator JK-SMS-SST-0987 as served by /api/v1/risk-tree.
func exampleInput(t *testing.T) riskTreeInput {
	f := func(v float64) *float64 { return &v }
	feat := func(id, value, ts string) FeatureRow {
		return FeatureRow{FeatureID: id, FeatureValue: value, LastUpdated: mustTime(t, ts)}
	}
	return riskTreeInput{
		OperatorID:            "JK-SMS-SST-0987",
		ROName:                "Chandigarh",
		OverallRiskScore:      f(0.98),
		LastPacket:            time.Date(2026, 9, 19, 23, 59, 21, 0, ist),
		RiskAnalysisUpdatedAt: "2026-09-25 10:30:50",
		CategoryScores: map[string]*float64{
			"document": f(0), "work": f(0.58), "authentication": f(0.5),
			"suspicious": f(0), "biometrics": f(0.98), "hardware": f(0),
		},
		Features: []FeatureRow{
			feat("work_operator_name_unique_count_cumulative_v1", "1", "2026-09-22T00:32:10+05:30"),
			feat("work_packet_upload_update_count_daily_v1", "1", "2026-09-18T12:25:45+05:30"),
			feat("work_machineip_isp_change_count_cumulative_v1", "1", "2026-09-18T12:25:45+05:30"),
			feat("work_machineip_isp_change_count_daily_v1", "1", "2026-09-18T12:25:45+05:30"),
			feat("work_packet_upload_new_count_daily_v1", "1", "2026-09-18T12:23:12+05:30"),
			feat("work_machine_unique_count_daily_v1", "2", "2026-09-18T12:10:42+05:30"),
			feat("work_packet_upload_total_count_daily_v1", "2", "2026-09-18T12:10:42+05:30"),
			feat("work_machine_change_instances_24h_v1", "2", "2026-09-18T12:10:42+05:30"),
			feat("work_machine_ip_change_instances_count_daily_v1", "2", "2026-09-18T12:10:42+05:30"),
			feat("auth_liveness_failure_incidents_24h_v2", "2", "2026-09-19T05:30:19+05:30"),
			feat("auth_device_change_incidents_v1", "2", "2026-09-19T05:30:19+05:30"),
			feat("auth_modality_change_incidents_24h_v1", "2", "2026-09-19T05:30:19+05:30"),
			feat("auth_oddhour_incidents_24h_v1", "2", "2026-09-19T05:30:19+05:30"),
			feat("auth_biomismatch_incidents_24h_v1", "2", "2026-09-19T05:30:19+05:30"),
			feat("sustxn_outstate_pkts_instances_24h_v2", "98", "2026-09-15T16:24:08+05:30"),
			feat("sustxn_oddhour_pkts_instances_24h_v2", "98", "2026-09-15T16:24:08+05:30"),
			feat("sustxn_oddhour_pkts_instances_24h_v1", "98", "2026-09-15T16:05:49+05:30"),
			feat("bio_packet_fraud_count_daily_v1", "18", "2026-09-01T22:42:28+05:30"),
			feat("bio_packet_finger_fraud_count_daily_v1", "18", "2026-09-01T22:39:40+05:30"),
			feat("bio_packet_finger_swap_count_daily_v1", "10", "2026-09-01T22:39:38+05:30"),
			feat("bio_packet_slap_right_fraud_count_daily_v1", "18", "2026-09-01T22:36:16+05:30"),
			feat("bio_packet_slap_right_swap_count_daily_v1", "10", "2026-09-01T22:34:21+05:30"),
		},
		Registry: exampleRegistry(),
	}
}

func categoryByID(t *testing.T, resp RiskTreeV1Response, id string) CategoryV1 {
	t.Helper()
	for _, c := range resp.Categories {
		if c.CategoryID == id {
			return c
		}
	}
	t.Fatalf("category %q missing", id)
	return CategoryV1{}
}

func healthTypes(resp RiskTreeV1Response) map[string][]string {
	out := map[string][]string{}
	for _, h := range resp.DataHealth {
		out[h.Type] = append(out[h.Type], h.CategoryIDs...)
	}
	return out
}

func TestBuildRiskTreeV1Example(t *testing.T) {
	now := time.Date(2026, 9, 26, 10, 0, 0, 0, ist)
	resp := buildRiskTreeV1(exampleInput(t), now)

	// Driver and ordering.
	if !reflect.DeepEqual(resp.RiskDriver.CategoryIDs, []string{"biometrics"}) {
		t.Errorf("driver = %v, want [biometrics]", resp.RiskDriver.CategoryIDs)
	}
	if resp.Categories[0].CategoryID != "biometrics" || resp.Categories[1].CategoryID != "work" || resp.Categories[2].CategoryID != "authentication" {
		t.Errorf("categories not sorted by score: %s, %s, %s", resp.Categories[0].CategoryID, resp.Categories[1].CategoryID, resp.Categories[2].CategoryID)
	}

	// Biometrics: stale driver, finger swap is the only evidence, the other
	// bio features are context, 9 inputs missing.
	bio := categoryByID(t, resp, "biometrics")
	if !bio.IsDriver || bio.Status != statusStale {
		t.Errorf("biometrics driver=%v status=%q, want true/stale", bio.IsDriver, bio.Status)
	}
	mfc := bio.Signals[0]
	if mfc.SignalID != "bio_mfc_fraud_score_v2" || mfc.Influence != "high" || mfc.Weight != 4 || mfc.TotalWeight != 5 {
		t.Errorf("first bio signal = %+v", mfc)
	}
	if len(mfc.Evidence) != 1 || mfc.Evidence[0].FeatureID != "bio_packet_finger_swap_count_daily_v1" || mfc.Evidence[0].Value != 10 {
		t.Fatalf("mfc evidence = %+v", mfc.Evidence)
	}
	if mfc.Evidence[0].DaysBeforeLastPacket != 18 || mfc.Evidence[0].Freshness != "stale" {
		t.Errorf("finger swap freshness = %d/%q, want 18/stale", mfc.Evidence[0].DaysBeforeLastPacket, mfc.Evidence[0].Freshness)
	}
	if len(mfc.MissingInputs) != 9 {
		t.Errorf("mfc missing inputs = %d, want 9", len(mfc.MissingInputs))
	}
	if bio.Signals[1].Influence != "low" {
		t.Errorf("sfc influence = %q, want low", bio.Signals[1].Influence)
	}
	if len(bio.OtherActivity) != 4 {
		t.Errorf("bio other_activity = %d, want 4", len(bio.OtherActivity))
	}

	// Work: scored; only the unique-name count feeds a signal.
	work := categoryByID(t, resp, "work")
	if work.Status != statusScored || work.IsDriver {
		t.Errorf("work status=%q driver=%v", work.Status, work.IsDriver)
	}
	if len(work.OtherActivity) != 8 {
		t.Errorf("work other_activity = %d, want 8", len(work.OtherActivity))
	}

	// Authentication: equal influence; the non-PROD signal is flagged.
	auth := categoryByID(t, resp, "authentication")
	for _, s := range auth.Signals {
		if s.Influence != "equal" {
			t.Errorf("auth signal %s influence = %q, want equal", s.SignalID, s.Influence)
		}
	}
	if !strings.Contains(auth.MethodText, "All 5 signals count equally") {
		t.Errorf("auth method text = %q", auth.MethodText)
	}

	// Suspicious: 0 score with 98/98 evidence is a conflict.
	sus := categoryByID(t, resp, "suspicious")
	if sus.Status != statusConflict {
		t.Errorf("suspicious status = %q, want conflict", sus.Status)
	}

	// Hardware and document have no evidence served.
	if s := categoryByID(t, resp, "hardware").Status; s != statusNoEvidence {
		t.Errorf("hardware status = %q, want no_evidence", s)
	}
	doc := categoryByID(t, resp, "document")
	if doc.Status != statusNoEvidence || len(doc.Signals) != 1 || len(doc.Signals[0].MissingInputs) != 2 {
		t.Errorf("document = status %q, %d signals", doc.Status, len(doc.Signals))
	}

	// Data health.
	h := healthTypes(resp)
	if !reflect.DeepEqual(h["stale_driver_evidence"], []string{"biometrics"}) {
		t.Errorf("stale_driver_evidence = %v", h["stale_driver_evidence"])
	}
	if !reflect.DeepEqual(h["score_conflicts_with_evidence"], []string{"suspicious"}) {
		t.Errorf("score_conflicts_with_evidence = %v", h["score_conflicts_with_evidence"])
	}
	if !reflect.DeepEqual(h["no_evidence_served"], []string{"hardware", "document"}) {
		t.Errorf("no_evidence_served = %v", h["no_evidence_served"])
	}
	if got := h["signal_not_in_registry"]; !reflect.DeepEqual(got, []string{"authentication", "hardware"}) {
		t.Errorf("signal_not_in_registry = %v, want [authentication hardware]", got)
	}
	if _, ok := h["overall_score_mismatch"]; ok {
		t.Error("unexpected overall_score_mismatch")
	}

	// Empty collections must serialize as [] not null.
	b, err := json.Marshal(resp)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(b), ":null") && !strings.Contains(string(b), `"category_score":null`) {
		t.Errorf("unexpected null in response: %s", b)
	}
}

func TestBuildRiskTreeV1NoRiskAnalysisRow(t *testing.T) {
	in := exampleInput(t)
	in.CategoryScores = map[string]*float64{}
	resp := buildRiskTreeV1(in, time.Now())

	if len(resp.RiskDriver.CategoryIDs) != 0 {
		t.Errorf("driver = %v, want none", resp.RiskDriver.CategoryIDs)
	}
	for _, c := range resp.Categories {
		if c.Status != statusNotScored || c.CategoryScore != nil {
			t.Errorf("%s status=%q score=%v, want not_scored/nil", c.CategoryID, c.Status, c.CategoryScore)
		}
	}
	if h := healthTypes(resp)["category_not_scored"]; len(h) != 6 {
		t.Errorf("category_not_scored = %v, want 6 categories", h)
	}
}

func TestBuildRiskTreeV1OverallMismatch(t *testing.T) {
	in := exampleInput(t)
	overall := 0.5
	in.OverallRiskScore = &overall
	resp := buildRiskTreeV1(in, time.Now())
	if _, ok := healthTypes(resp)["overall_score_mismatch"]; !ok {
		t.Error("expected overall_score_mismatch when overall 0.50 vs max category 0.98")
	}
}
