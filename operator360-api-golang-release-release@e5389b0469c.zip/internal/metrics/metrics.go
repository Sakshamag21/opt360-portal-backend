package metrics

import (
	"fmt"
	"net/http"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

// --- Metrics Declarations ---

var (
	requestsTotal = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "http_requests_total",
			Help: "Total number of HTTP requests processed, labeled by method, route and status code.",
		},
		[]string{"method", "path", "status"},
	)

	requestDuration = prometheus.NewHistogramVec(
		prometheus.HistogramOpts{
			Name:    "http_request_duration_seconds",
			Help:    "HTTP request latency in seconds, labeled by method, route and status code.",
			Buckets: prometheus.DefBuckets, // Default Prometheus buckets matching Python's default Histogram behavior
		},
		[]string{"method", "path", "status"},
	)

	requestsInFlight = prometheus.NewGauge(
		prometheus.GaugeOpts{
			Name: "http_requests_in_flight",
			Help: "Number of HTTP requests currently being served.",
		},
	)

	// Custom exponential buckets to match Python's (100.0, 1000.0, 10000.0, 100000.0, 1000000.0, 10000000.0)
	responseSize = prometheus.NewHistogramVec(
		prometheus.HistogramOpts{
			Name:    "http_response_size_bytes",
			Help:    "Size of HTTP responses in bytes, labeled by method, route and status code.",
			Buckets: []float64{100.0, 1000.0, 10000.0, 100000.0, 1000000.0, 10000000.0},
		},
		[]string{"method", "path", "status"},
	)
)

// init registers all metrics with the default Prometheus registry
func init() {
	prometheus.MustRegister(requestsTotal)
	prometheus.MustRegister(requestDuration)
	prometheus.MustRegister(requestsInFlight)
	prometheus.MustRegister(responseSize)
}

// Handler returns the Prometheus scrape handler to mount at /metrics.
func Handler() http.Handler {
	return promhttp.Handler()
}

// statusRecorder wraps http.ResponseWriter to capture the status code and response size
type statusRecorder struct {
	http.ResponseWriter
	status       int
	bytesWritten int
}

func (rec *statusRecorder) WriteHeader(code int) {
	rec.status = code
	rec.ResponseWriter.WriteHeader(code)
}

func (rec *statusRecorder) Write(b []byte) (int, error) {
	if rec.status == 0 {
		rec.status = 200 // Default to 200 if WriteHeader wasn't called explicitly
	}
	n, err := rec.ResponseWriter.Write(b)
	rec.bytesWritten += n
	return n, err
}

// Middleware instruments every request handled by next with request count,
// latency and response-size metrics.
func Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requestsInFlight.Inc()
		defer requestsInFlight.Dec()

		startTime := time.Now()
		rec := &statusRecorder{ResponseWriter: w, status: 200}

		// Pass request to the next handler
		next.ServeHTTP(rec, r)

		// Extract method and route label equivalent
		method := r.Method
		path := routeLabel(r)
		status := fmt.Sprintf("%d", rec.status)

		// Record metrics
		requestsTotal.WithLabelValues(method, path, status).Inc()
		requestDuration.WithLabelValues(method, path, status).Observe(time.Since(startTime).Seconds())
		responseSize.WithLabelValues(method, path, status).Observe(float64(rec.bytesWritten))
	})
}

// routeLabel returns the registered route pattern rather than the raw URL path,
// so the "path" label stays low-cardinality even for parameterized routes.
func routeLabel(r *http.Request) string {
	// In Go 1.22+, the router automatically populates r.Pattern (e.g., "/api/v1/risk-tree")
	// This perfectly replaces Python's "werkzeug.routing_rule" behavior.
	if r.Pattern != "" {
		return r.Pattern
	}

	// Fallback to URL path if pattern is not resolved (ignores query parameters)
	if r.URL != nil {
		return r.URL.Path
	}
	return "/"
}
