package main

import (
    "context"
    "errors"
    "log/slog"
    "net/http"
    "os"
    "os/signal"
    "syscall"
    "time"

    "operator360-api/internal/config"
    "operator360-api/internal/database"
    "operator360-api/internal/metrics"
    "operator360-api/internal/server"
)

func main() {
    // Setup logging to mirror Go's standard log package
    logger := slog.New(slog.NewJSONHandler(os.Stdout, nil))
    slog.SetDefault(logger)

    // 1. Load Configuration
    configPath := os.Getenv("CONFIG_PATH")
    if configPath == "" {
        configPath = "/app/resources/config.yaml"
    }

    cfg, err := config.Load(configPath)
    if err != nil {
        slog.Error("failed to load configuration", "error", err)
        os.Exit(1)
    }

    // 2. Initialize Database Connection Pools
    mysqlDBWrapper, err := database.NewMySQLPool(cfg)
    if err != nil {
        slog.Error("failed to open database connection pool", "error", err)
        os.Exit(1)
    }
    defer mysqlDBWrapper.Pool().Close()

    clickhouseDB, err := database.NewClickHousePool(cfg)
    if err != nil {
        slog.Error("failed to open clickhouse connection pool", "error", err)
        os.Exit(1)
    }
    defer clickhouseDB.Close()

    // 3. Initialize Server instance (mirrors srv = server.New(cfg, db))
    srv := server.New(cfg, mysqlDBWrapper, clickhouseDB)
    
    // 4. Register DB stats for Prometheus (mirrors metrics.register_db_stats(db))
    metrics.RegisterDBStats(mysqlDBWrapper.Pool())

    // 5. Initialize HTTP Router
    mux := http.NewServeMux()

    // Register all routes onto the mux instance (mirrors srv.register_routes(app))
    srv.RegisterRoutes(mux)

    // 6. Wrap the app with metrics middleware
    wrappedMux := metrics.Middleware(mux)

    // 7. Configure Production HTTP Server
    port := os.Getenv("PORT")
    if port == "" {
        port = "8000"
    }
    addr := "0.0.0.0:" + port

    httpSrv := &http.Server{
        Addr:              addr,
        Handler:           wrappedMux,
        ReadHeaderTimeout: 5 * time.Second,
        ReadTimeout:       15 * time.Second,
        WriteTimeout:      30 * time.Second,
        IdleTimeout:       120 * time.Second,
    }

    // 8. Start Server
    go func() {
        slog.Info("Operator360 API listening", "address", addr)
        if err := httpSrv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
            slog.Error("server error", "error", err)
            os.Exit(1)
        }
    }()

    // Graceful shutdown
    quit := make(chan os.Signal, 1)
    signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
    <-quit

    slog.Info("Shutting down server...")
    ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
    defer cancel()

    if err := httpSrv.Shutdown(ctx); err != nil {
        slog.Error("Server forced to shutdown", "error", err)
    }
    slog.Info("Server exited successfully.")
}