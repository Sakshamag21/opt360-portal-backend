# Operator Risk Tree Service

A high-performance Go API microservice endpoint that aggregates, filters, and structures risk assessment metrics for platform operators. It safely unifies structured configurations from **MySQL** with distributed analytics columns from **ClickHouse**, replacing and optimizing legacy Pandas matrix processing natively in Go.

## 🏗️ System Architecture & Workflow

The endpoint processes operational tracking data across three sequential pipeline execution layers:

1. **Identity & Vital Verification (MySQL):** Looks up master metrics (`risk_score`, `last_packet_timestamp`) using an arbitrary operators master catalog table.
2. **Aggregated Category Processing (ClickHouse):** Uses time-series maximization techniques (`argMax` over `updated_at`) to isolate the most recent categorical score records and regional naming data.
3. **Feature Deduplication & Classification (ClickHouse):** 
   * Fetches raw operational telemetry parameters from the designated Feature Store.
   * Splits records into **Score Keys** (containing `_score`) and **Active Rolling Metrics** (last 10 days only).
   * Sorts tracking parameters chronologically descending and drops duplicate older values to preserve active tracking states.
   * Maps features dynamically into categorical response matrices using structural config matching rules.

---

## 🌐 API Reference

### Get Risk Tree Matrix

Fetches categorized threat landscapes, structural category scores, and underlying feature indicators for an isolated identity code.

* **URL Route:** `/api/v1/risk-tree`
* **HTTP Method:** `GET`
* **Content-Type:** `application/json`

#### Query Parameters

| Parameter | Type | Required | Description |
| :--- | :--- | :--- | :--- |
| `opt_id` | `string` | **Yes** | Unique verification lookup code for the target Operator (e.g., `UPSIL16109`). |

---

## 📋 Data Contract & Schemas

### 🟢 Success Response Structure (`200 OK`)
The serialization layer guarantees schema stability across executions. Elements without corresponding backend tracking history fall back to explicit JSON structures (`[]` or `null`) instead of missing entirely from objects.

```json
{
  "operator_id": "string",
  "ro_name": "string",
  "overall_risk_score": "float64 | string | null",
  "last_packet_timestamp": "string (YYYY-MM-DD HH:MM:SS)",
  "risk_analysis_updated_at": "string (YYYY-MM-DD HH:MM:SS)",
  "categories": [
    {
      "category_name": "string",
      "category_score": "float64 | int | null",
      "features": [
        {
          "feature_id": "string",
          "feature_value": "int | float64 | string | null",
          "description": "string",
          "last_updated": "string (ISO-8601 / RFC3339 with Timezone offset)"
        }
      ]
    }
  ],
  "error": "string (optional)"
}
```

### 🧱 Field Specifications & Types

#### 1. Root Element (`RiskTreeResponse`)
* **`operator_id`** (`string`): Absolute identifier submitted in the query payload.
* **`ro_name`** (`string`): The mapped regional operations branch location name.
* **`overall_risk_score`** (`float64 | string | null`): Core hazard evaluation rank. Falls back to raw text if casting calculations fail.
* **`last_packet_timestamp`** (`string`): The final data packet window. Always matches layout format `YYYY-MM-DD HH:MM:SS`.
* **`risk_analysis_updated_at`** (`string`): Processing engine execution stamp.
* **`categories`** (`array[Category]`): Continuous taxonomy matrix containing clustered scores and indicators.

#### 2. Structural Node (`Category`)
* **`category_name`** (`string`): Clean structural classification title (e.g., `"Authentication Category"`).
* **`category_score`** (`float64 | int | null`): Section calculation balance indicator.
* **`features`** (`array[Feature]`): Chronologically sorted tracking items mapped to this block. Leaves an empty array (`[]`) if zero features qualify.

#### 3. Core Metric Element (`Feature`)
* **`feature_id`** (`string`): Low-level machine parameter tag key.
* **`feature_value`** (`int | float64 | string | null`): Dynamic cell scalar value. 
  * **Dynamic Numeric Casting:** Whole fractional numbers (e.g., `21.00`) are truncated directly to **Integers** (`21`). Real decimals are preserved as **Floats** (`0.63`).
  * Empty elements or arithmetic execution breaks (`NaN`) serialize explicitly as **`null`**.
* **`description`** (`string`): Plaintext operational description and tracking pipeline context.
* **`last_updated`** (`string`): Timestamp with zone offsets formatting (e.g., `2026-09-22T12:12:53+05:30`).

---

## 🛑 Production Troubleshooting & Errors

When runtime engine faults occur, the endpoint bubbles upstream exceptions into a standardized wrapper using appropriate HTTP Status context blocks.

### Error Envelope Schema
```json
{
  "error": "string"
}
```

### Common Exception Cases
* **`400 Bad Request`**: Triggered if the query parameter payload drops the mandatory `opt_id` field.
* **`404 Not Found`**: Triggered if the target identity string is completely absent from the MySQL registry ledger.
* **`500 Internal Server Error`**: Triggered during infrastructural connection degradation or physical infrastructure time-outs. 

#### Example Database Timeout Trace (`500 Internal Server Error`)
```json
{
  "error": "MySQL query failed: dial tcp 10.10.106.159:3306: connectex: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond."
}
```
