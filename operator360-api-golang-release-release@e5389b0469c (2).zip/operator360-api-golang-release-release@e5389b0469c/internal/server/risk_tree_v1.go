package server

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"sync"
	"time"
)

// registryTTL bounds how stale the in-process copy of the feature registry
// can get; the registry changes rarely and is read on every request.
const registryTTL = 10 * time.Minute

// ist is the zone opt_master.last_packet_timestamp is written in. The MySQL
// DSN has no loc, so the driver returns that wall clock labelled UTC.
var ist = time.FixedZone("IST", 5*3600+30*60)

// GetRiskTreeV1 handles GET /api/v1/risk-tree-1: the risk tree with
// explanations (driver, signals, evidence, data health). The original
// /api/v1/risk-tree is left unchanged for existing clients.
func (s *Server) GetRiskTreeV1(w http.ResponseWriter, r *http.Request) {
	optID := r.URL.Query().Get("opt_id")
	if optID == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "Operator ID (opt_id) is required"})
		return
	}
	ctx := r.Context()
	in := riskTreeInput{OperatorID: optID}

	// 1. Overall score and last packet from MySQL opt_master.
	var riskScore sql.NullString
	var lastPacket sql.NullTime
	err := s.DB.Pool().QueryRowContext(ctx, fmt.Sprintf(
		"SELECT risk_score, last_packet_timestamp FROM %s WHERE id = ? LIMIT 1", s.Config.OptTable(),
	), optID).Scan(&riskScore, &lastPacket)
	if errors.Is(err, sql.ErrNoRows) {
		writeJSON(w, http.StatusNotFound, map[string]string{"error": "Operator not found"})
		return
	}
	if err != nil {
		log.Printf("[risk-tree-1] MySQL query failed opt_id=%s: %v", optID, err)
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "MySQL query failed: " + err.Error()})
		return
	}
	if riskScore.Valid {
		if f, err := strconv.ParseFloat(riskScore.String, 64); err == nil {
			in.OverallRiskScore = &f
		}
	}
	if lastPacket.Valid {
		t := lastPacket.Time
		in.LastPacket = time.Date(t.Year(), t.Month(), t.Day(), t.Hour(), t.Minute(), t.Second(), 0, ist)
	}

	// 2. Category scores from ClickHouse risk_analysis. No row is not an
	// error: every category is then reported as not_scored.
	in.CategoryScores, in.ROName, in.RiskAnalysisUpdatedAt, err = s.fetchCategoryScores(ctx, optID)
	if err != nil {
		log.Printf("[risk-tree-1] risk_analysis query failed opt_id=%s: %v", optID, err)
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "ClickHouse risk_analysis query failed: " + err.Error()})
		return
	}

	// 3. Latest value per feature from the ClickHouse feature store.
	in.Features, err = s.fetchFeatureRows(ctx, optID)
	if err != nil {
		log.Printf("[risk-tree-1] feature store query failed opt_id=%s: %v", optID, err)
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "ClickHouse feature store query failed: " + err.Error()})
		return
	}

	// 4. Scoring lineage from the MySQL feature registry (cached).
	in.Registry, err = s.riskRegistry(ctx)
	if err != nil {
		log.Printf("[risk-tree-1] feature registry load failed: %v", err)
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "Feature registry query failed: " + err.Error()})
		return
	}

	writeJSON(w, http.StatusOK, buildRiskTreeV1(in, time.Now()))
}

func (s *Server) fetchCategoryScores(ctx context.Context, optID string) (map[string]*float64, string, string, error) {
	scores := map[string]*float64{}
	var roName, updatedStr, optIDDb string
	var docScore, workScore, authScore, suspScore, bioScore, hwScore sql.NullString
	err := s.chDB.QueryRowContext(ctx, fmt.Sprintf(`
		SELECT
			argMax(ro_name, updated_at) AS ro_name,
			opt_id,
			argMax(document_category_score, updated_at)       AS document_category_score,
			argMax(work_category_score, updated_at)           AS work_category_score,
			argMax(authentication_category_score, updated_at) AS authentication_category_score,
			argMax(suspicious_category_score, updated_at)     AS suspicious_category_score,
			argMax(biometrics_category_score, updated_at)     AS biometrics_category_score,
			argMax(hardware_category_score, updated_at)       AS hardware_category_score,
			toString(max(updated_at))                         AS updated_at_str
		FROM %s
		WHERE opt_id = ?
		GROUP BY opt_id
		LIMIT 1
	`, s.Config.RiskAnalysisTable()), optID).Scan(&roName, &optIDDb, &docScore, &workScore, &authScore, &suspScore, &bioScore, &hwScore, &updatedStr)
	if errors.Is(err, sql.ErrNoRows) {
		return scores, "", "", nil
	}
	if err != nil {
		return nil, "", "", err
	}

	raw := map[string]sql.NullString{
		"document_category_score":       docScore,
		"work_category_score":           workScore,
		"authentication_category_score": authScore,
		"suspicious_category_score":     suspScore,
		"biometrics_category_score":     bioScore,
		"hardware_category_score":       hwScore,
	}
	for _, def := range riskCategoryDefs {
		if v := raw[def.ScoreColumn]; v.Valid {
			if f, err := strconv.ParseFloat(v.String, 64); err == nil {
				scores[def.ID] = &f
			}
		}
	}
	return scores, roName, updatedStr, nil
}

func (s *Server) fetchFeatureRows(ctx context.Context, optID string) ([]FeatureRow, error) {
	rows, err := s.chDB.QueryContext(ctx, fmt.Sprintf(`
		SELECT feature_id,
			toString(argMax(feature_value, last_updated_at)) AS feature_value,
			argMax(description, last_updated_at)             AS description,
			max(last_updated_at)                             AS max_last_updated_at,
			argMax(feature_group, last_updated_at)           AS feature_group
		FROM %s
		WHERE entity_id = ?
		GROUP BY feature_id
	`, s.Config.FeatureStoreTable()), optID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []FeatureRow
	for rows.Next() {
		var f FeatureRow
		if err := rows.Scan(&f.FeatureID, &f.FeatureValue, &f.Description, &f.LastUpdated, &f.FeatureGroup); err != nil {
			log.Printf("[risk-tree-1] feature row scan failed opt_id=%s: %v", optID, err)
			continue
		}
		out = append(out, f)
	}
	return out, rows.Err()
}

// registryCache holds the parsed PROD rows of the feature registry.
type registryCache struct {
	mu      sync.Mutex
	nodes   map[string]registryNode
	expires time.Time
}

// riskRegistry returns the cached registry, reloading it after registryTTL.
// If a reload fails but an older copy exists, the older copy is served.
func (s *Server) riskRegistry(ctx context.Context) (map[string]registryNode, error) {
	c := s.riskRegCache
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.nodes != nil && time.Now().Before(c.expires) {
		return c.nodes, nil
	}

	nodes, err := s.loadRiskRegistry(ctx)
	if err != nil {
		if c.nodes != nil {
			log.Printf("[risk-tree-1] registry reload failed, serving cached copy: %v", err)
			return c.nodes, nil
		}
		return nil, err
	}
	c.nodes, c.expires = nodes, time.Now().Add(registryTTL)
	return nodes, nil
}

func (s *Server) loadRiskRegistry(ctx context.Context) (map[string]registryNode, error) {
	rows, err := s.DB.Pool().QueryContext(ctx, fmt.Sprintf(
		"SELECT feature_id, feature_name, description, dependent_features FROM %s WHERE status = 'PROD'",
		s.Config.FeatureTable(),
	))
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	nodes := map[string]registryNode{}
	for rows.Next() {
		var id, name, desc, deps sql.NullString
		if err := rows.Scan(&id, &name, &desc, &deps); err != nil {
			return nil, err
		}
		if !id.Valid || id.String == "" {
			continue
		}
		nodes[id.String] = registryNode{
			FeatureID:   id.String,
			FeatureName: name.String,
			Description: desc.String,
			Params:      parseDependentFeatures(deps.String),
		}
	}
	return nodes, rows.Err()
}
