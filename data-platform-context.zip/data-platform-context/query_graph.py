#!/usr/bin/env python3
"""
Standalone GraphRAG PostgreSQL Query Tool.

Queries the GraphRAG knowledge graph stored in PostgreSQL (Docker container)
to retrieve entities, relationships, communities, and search results.

Usage:
    python query_graph.py                        # Interactive mode
    python query_graph.py --search "active UIDs" # Search entities
    python query_graph.py --table uid_master     # Get table schema
    python query_graph.py --tables               # List all tables
    python query_graph.py --graph                # Full graph (entities + relationships)
    python query_graph.py --communities          # List communities
    python query_graph.py --join uid_master uid_address  # Find join path
    python query_graph.py --sql "SELECT * FROM entities LIMIT 5"  # Raw SQL

Connection:
    Docker container: graphrag-postgres
    Database: graphrag | User: graphrag | Password: graphrag123
    Port: 5432 (mapped from container)

Schema (see postgres/init/01_schema.sql):
    entities      — tables, columns, concepts (entity_id, name, type, description, properties, tsv)
    relationships — graph edges (source_id, target_id, type, description, properties)
    communities   — entity groupings (community_id, title, summary, entity_ids[])
    text_units    — NL descriptions (entity_id, text, source)
    query_paths   — pre-computed join paths (start_table, need, joins)
    v_neighbors   — view: entity → neighbor expansion
    v_columns     — view: all columns with parent table
    v_joins       — view: all table-to-table joins
"""

import sys
import os
import json
import subprocess
import argparse
from pathlib import Path

# ─── Configuration ─────────────────────────────────────────────────────────────
CONTAINER = "graphrag-postgres"
DB_USER = "graphrag"
DB_NAME = "graphrag"
DB_PASSWORD = "graphrag123"
TEMP_DIR = os.path.join(os.environ.get("TEMP", "/tmp"), "opencode")
os.makedirs(TEMP_DIR, exist_ok=True)


# ═══════════════════════════════════════════════════════════════════════════════
#  CORE QUERY FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════
def query(sql):
    """
    Execute SQL on the GraphRAG PostgreSQL database via docker exec psql.
    Returns results as a list of Python dicts.

    Method:
      1. Wrap SQL in JSON aggregation for clean parsing
      2. Write to temp file (avoids Windows cmd quote issues)
      3. docker cp into container
      4. docker exec psql with -t -A (tuples only, unaligned)
      5. Parse JSON output
    """
    # Wrap in JSON aggregation
    json_sql = f"SELECT coalesce(json_agg(row_to_json(t)), '[]'::json) FROM ({sql}) t;"

    # Write SQL to temp file
    temp_path = os.path.join(TEMP_DIR, "pg_query_standalone.sql")
    with open(temp_path, "w", encoding="utf-8") as f:
        f.write(json_sql)

    # Copy to container
    container_path = "/tmp/pg_query_standalone.sql"
    cp = subprocess.run(
        ["docker", "cp", temp_path, f"{CONTAINER}:{container_path}"],
        capture_output=True, text=True,
    )
    if cp.returncode != 0:
        print(f"ERROR: docker cp failed: {cp.stderr.strip()}")
        print(f"Is the container '{CONTAINER}' running? Start it with:")
        print(f"  cd C:\\data-platform-context\\postgres && docker compose up -d")
        sys.exit(1)

    # Execute via psql
    result = subprocess.run(
        ["docker", "exec", CONTAINER, "psql",
         "-U", DB_USER, "-d", DB_NAME,
         "-t", "-A", "-f", container_path],
        capture_output=True, text=True, encoding="utf-8",
    )

    if result.returncode != 0:
        print(f"ERROR: psql error: {result.stderr.strip()}")
        sys.exit(1)

    output = result.stdout.strip()
    if not output or output == "null":
        return []

    try:
        return json.loads(output)
    except json.JSONDecodeError as e:
        cleaned = output.replace("\\u0000", "")
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            print(f"ERROR: JSON parse error: {e}")
            print(f"Output: {output[:500]}")
            sys.exit(1)


def query_single(sql):
    """Execute SQL and return a single scalar value."""
    result = query(sql)
    if result and isinstance(result, list) and len(result) > 0:
        if isinstance(result[0], dict):
            # Return first value
            return list(result[0].values())[0]
        return result[0]
    return None


def sql_escape(s):
    """Escape a string for safe inclusion in SQL single-quoted literal."""
    return str(s).replace("'", "''")


# ═══════════════════════════════════════════════════════════════════════════════
#  HEALTH CHECK
# ═══════════════════════════════════════════════════════════════════════════════
def health_check():
    """Check if PostgreSQL container is running and has data."""
    try:
        count = query_single("SELECT count(*) AS cnt FROM entities")
        return count and count > 0
    except Exception:
        return False


def db_stats():
    """Print database statistics."""
    stats = {
        "Entities": "SELECT count(*) FROM entities",
        "Relationships": "SELECT count(*) FROM relationships",
        "Communities": "SELECT count(*) FROM communities",
        "Text Units": "SELECT count(*) FROM text_units",
        "Query Paths": "SELECT count(*) FROM query_paths",
    }
    print("=" * 60)
    print("          GraphRAG PostgreSQL Database Stats")
    print("=" * 60)
    for label, sql in stats.items():
        count = query_single(sql)
        print(f"  {label:<20} {str(count):>10} rows")
    # Entity type breakdown
    types = query("SELECT type, count(*) AS cnt FROM entities GROUP BY type ORDER BY cnt DESC")
    print("-" * 60)
    print("  Entity Types Breakdown")
    for t in types:
        print(f"    {t['type']:<20} {str(t['cnt']):>10}")
    print("=" * 60)


# ═══════════════════════════════════════════════════════════════════════════════
#  SEARCH FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════
def search_entities(query_text, top_k=10):
    """
    Full-text search across all entities using PostgreSQL's ts_rank (BM25).
    Returns matching entities with relevance scores.
    """
    tq = sql_escape(query_text)
    sql = f"""
    SELECT entity_id, name, type, description, properties,
           ROUND(ts_rank(tsv, websearch_to_tsquery('english', '{tq}'))::numeric, 4) AS score
    FROM entities
    WHERE tsv @@ websearch_to_tsquery('english', '{tq}')
    ORDER BY score DESC
    LIMIT {int(top_k)}
    """
    return query(sql)


def search_with_neighbors(query_text, top_k=10):
    """
    Full-text search + graph expansion + text units in ONE query.
    Returns entities with their neighbors and matched text.
    """
    tq = sql_escape(query_text)
    sql = f"""
    WITH search_results AS (
        SELECT e.entity_id, e.name, e.type, e.description, e.properties,
               ts_rank(e.tsv, websearch_to_tsquery('english', '{tq}')) AS score
        FROM entities e
        WHERE e.tsv @@ websearch_to_tsquery('english', '{tq}')
        ORDER BY score DESC
        LIMIT {int(top_k)}
    )
    SELECT
        sr.entity_id, sr.name, sr.type, sr.description, sr.properties,
        ROUND(sr.score::numeric, 4) AS score,
        COALESCE(
            (SELECT json_agg(json_build_object(
                'entity_id', vn.neighbor_id,
                'name', vn.neighbor_name,
                'type', vn.neighbor_type,
                'description', vn.neighbor_description,
                'relationship', vn.relationship_type
            ))
            FROM v_neighbors vn
            WHERE vn.entity_id = sr.entity_id
              AND vn.neighbor_id NOT IN (SELECT entity_id FROM search_results)),
            '[]'::json
        ) AS neighbors,
        COALESCE(
            (SELECT json_agg(json_build_object(
                'text', tu.text, 'source', tu.source
            ))
            FROM text_units tu
            WHERE tu.entity_id = sr.entity_id
            LIMIT 3),
            '[]'::json
        ) AS matched_texts
    FROM search_results sr
    ORDER BY sr.score DESC
    """
    return query(sql)


def search_communities(query_text, top_k=5):
    """Search community summaries via full-text search."""
    tq = sql_escape(query_text)
    sql = f"""
    SELECT community_id, title, summary, entity_count,
           ROUND(ts_rank(
               to_tsvector('english', coalesce(title, '') || ' ' || coalesce(summary, '')),
               websearch_to_tsquery('english', '{tq}')
           )::numeric, 4) AS score,
           key_relationships, query_examples
    FROM communities
    WHERE to_tsvector('english', coalesce(title, '') || ' ' || coalesce(summary, ''))
          @@ websearch_to_tsquery('english', '{tq}')
    ORDER BY score DESC
    LIMIT {int(top_k)}
    """
    return query(sql)


# ═══════════════════════════════════════════════════════════════════════════════
#  TABLE & SCHEMA FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════
def list_tables():
    """List all table entities in the graph."""
    sql = """
    SELECT entity_id, name, description, properties
    FROM entities
    WHERE type = 'TABLE'
    ORDER BY name
    """
    return query(sql)


def get_table_schema(table_name):
    """Get full table schema: columns, joins, community — in ONE query."""
    tn = sql_escape(table_name.lower())
    sql = f"""
    SELECT
        t.name, t.description, t.properties,
        COALESCE(
            (SELECT json_agg(json_build_object(
                'name', c.name,
                'description', c.description,
                'properties', c.properties
            ) ORDER BY c.name)
            FROM entities c
            JOIN relationships r ON r.target_id = c.entity_id
            WHERE r.source_id = t.entity_id AND r.type = 'HAS_COLUMN'),
            '[]'::json
        ) AS columns,
        COALESCE(
            (SELECT json_agg(json_build_object(
                'target_table', t2.name,
                'relationship', r.type,
                'description', r.description,
                'properties', r.properties
            ))
            FROM relationships r
            JOIN entities t2 ON r.target_id = t2.entity_id
            WHERE r.source_id = t.entity_id AND r.type = 'JOINS_TO'
              AND t2.type = 'TABLE'),
            '[]'::json
        ) AS joins,
        COALESCE(
            (SELECT json_build_object(
                'id', c.community_id, 'title', c.title
            )
            FROM communities c
            WHERE t.entity_id = ANY(c.entity_ids)
            LIMIT 1),
            'null'::json
        ) AS community
    FROM entities t
    WHERE t.type = 'TABLE' AND lower(t.name) = '{tn}'
    """
    rows = query(sql)
    return rows[0] if rows else None


def get_join_path(from_table, to_table):
    """Find join path between two tables."""
    ft = sql_escape(from_table.lower())
    tt = sql_escape(to_table.lower())

    # Check direct join
    sql = f"""
    SELECT r.type, r.description, r.properties,
           s.name AS source_name, t.name AS target_name
    FROM relationships r
    JOIN entities s ON r.source_id = s.entity_id
    JOIN entities t ON r.target_id = t.entity_id
    WHERE r.type = 'JOINS_TO' AND s.type = 'TABLE' AND t.type = 'TABLE'
    AND (
        (lower(s.name) = '{ft}' AND lower(t.name) = '{tt}')
        OR
        (lower(s.name) = '{tt}' AND lower(t.name) = '{ft}')
    )
    LIMIT 1
    """
    rows = query(sql)
    if rows:
        r = rows[0]
        props = r.get("properties", {}) or {}
        return {
            "from": from_table,
            "to": to_table,
            "direct": True,
            "join_keys": props.get("join_keys", []),
            "cardinality": props.get("cardinality", ""),
            "description": r.get("description", ""),
        }

    # Check query_paths for multi-hop
    sql = f"""
    SELECT need, joins FROM query_paths WHERE lower(start_table) = '{ft}'
    """
    rows = query(sql)
    for r in rows:
        joins = r.get("joins", []) or []
        for j in joins:
            if j.get("to", "").lower() == to_table.lower():
                return {
                    "from": from_table,
                    "to": to_table,
                    "direct": False,
                    "join_keys": j.get("on", []),
                    "via_query_path": r.get("need", ""),
                }

    return {
        "from": from_table,
        "to": to_table,
        "direct": False,
        "join_keys": [],
        "note": "No direct join found. Use uid and shard_hint as common keys.",
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  FULL GRAPH EXPORT
# ═══════════════════════════════════════════════════════════════════════════════
def get_full_graph():
    """Export the entire graph: all entities + all relationships + all communities."""
    entities = query("SELECT entity_id, name, type, description, properties FROM entities ORDER BY type, name")
    relationships = query("""
        SELECT r.source_id, r.target_id, r.type, r.description, r.properties,
               s.name AS source_name, t.name AS target_name
        FROM relationships r
        JOIN entities s ON r.source_id = s.entity_id
        JOIN entities t ON r.target_id = t.entity_id
        ORDER BY r.type, s.name
    """)
    communities = query("SELECT community_id, title, summary, entity_count, entity_ids, key_relationships, query_examples FROM communities ORDER BY community_id")

    return {
        "entities": entities,
        "relationships": relationships,
        "communities": communities,
        "stats": {
            "entity_count": len(entities),
            "relationship_count": len(relationships),
            "community_count": len(communities),
        },
    }


def get_entity_neighbors(entity_id):
    """Get all neighbors of an entity (graph expansion)."""
    eid = sql_escape(entity_id)
    sql = f"""
    SELECT neighbor_id, neighbor_name, neighbor_type, neighbor_description,
           relationship_type, relationship_description
    FROM v_neighbors
    WHERE entity_id = '{eid}'
    ORDER BY neighbor_type, neighbor_name
    """
    return query(sql)


# ═══════════════════════════════════════════════════════════════════════════════
#  PRETTY PRINTING
# ═══════════════════════════════════════════════════════════════════════════════
def print_json(data):
    """Pretty-print JSON with proper indentation."""
    print(json.dumps(data, indent=2, ensure_ascii=False, default=str))


def print_entities(entities):
    """Pretty-print entity search results."""
    if not entities:
        print("  No results found.")
        return
    for e in entities:
        score = e.get("score", "")
        score_str = f" (score: {score})" if score else ""
        print(f"\n  [{e.get('type', '?')}] {e.get('name', '?')}{score_str}")
        desc = e.get("description", "")
        if desc:
            print(f"    {desc[:200]}")
        props = e.get("properties", {})
        if props:
            for k, v in list(props.items())[:5]:
                print(f"    • {k}: {v}")
        neighbors = e.get("neighbors", [])
        if neighbors:
            print(f"    Neighbors ({len(neighbors)}):")
            for n in neighbors[:5]:
                print(f"      → [{n.get('type', '?')}] {n.get('name', '?')} ({n.get('relationship', '?')})")
            if len(neighbors) > 5:
                print(f"      ... and {len(neighbors) - 5} more")
        texts = e.get("matched_texts", [])
        if texts:
            print(f"    Matched texts:")
            for t in texts[:2]:
                print(f"      \"{t.get('text', '')[:120]}\"")


def print_tables(tables):
    """Pretty-print table list."""
    if not tables:
        print("  No tables found.")
        return
    for t in tables:
        print(f"\n  [TABLE] {t['name']}")
        desc = t.get("description", "")
        if desc:
            print(f"     {desc[:200]}")
        props = t.get("properties", {})
        if props and props.get("row_count"):
            print(f"     Rows: {props['row_count']}")


def print_table_schema(schema):
    """Pretty-print a table's full schema."""
    if not schema:
        print("  Table not found.")
        return
    print(f"\n  [TABLE] {schema['name']}")
    print(f"     Description: {schema.get('description', 'N/A')}")
    props = schema.get("properties", {})
    if props:
        print(f"     Properties: {json.dumps(props, indent=2)}")

    columns = schema.get("columns", []) or []
    print(f"\n     Columns ({len(columns)}):")
    for c in columns:
        cprops = c.get("properties", {}) or {}
        dtype = cprops.get("data_type", "?")
        importance = cprops.get("importance", "")
        imp_marker = " ⭐" if importance == "high" else ""
        print(f"       • {c['name']:<35} {dtype:<15}{imp_marker}")
        if c.get("description"):
            print(f"         {c['description'][:150]}")

    joins = schema.get("joins", []) or []
    if joins:
        print(f"\n     Joins ({len(joins)}):")
        for j in joins:
            print(f"       → {j.get('target_table', '?')} ({j.get('relationship', '?')})")
            if j.get("description"):
                print(f"         {j['description'][:150]}")
            jprops = j.get("properties", {}) or {}
            if jprops.get("join_keys"):
                print(f"         Join keys: {jprops['join_keys']}")

    community = schema.get("community")
    if community:
        print(f"\n     Community: {community.get('id', '?')} — {community.get('title', '?')}")


# ═══════════════════════════════════════════════════════════════════════════════
#  INTERACTIVE MODE
# ═══════════════════════════════════════════════════════════════════════════════
def interactive_mode():
    """Interactive REPL for querying the graph."""
    print("\n" + "=" * 60)
    print("  GraphRAG PostgreSQL Query Tool -- Interactive Mode")
    print("=" * 60)

    if not health_check():
        print("\n[ERROR] Cannot connect to PostgreSQL container.")
        print(f"   Container: {CONTAINER}")
        print(f"   Start it:  cd C:\\data-platform-context\\postgres && docker compose up -d")
        return

    db_stats()

    print("\nCommands:")
    print("  search <query>          -- Full-text search entities")
    print("  graph <query>           -- Search with neighbors + text units")
    print("  communities <query>     -- Search communities")
    print("  tables                  -- List all tables")
    print("  table <name>            -- Get table schema (columns, joins)")
    print("  join <table1> <table2>  -- Find join path between tables")
    print("  neighbors <entity_id>   -- Get entity neighbors")
    print("  full                    -- Export full graph (JSON)")
    print("  stats                   -- Database statistics")
    print("  sql <raw SQL>           -- Execute raw SQL")
    print("  quit                    -- Exit")

    while True:
        try:
            user_input = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break

        if not user_input:
            continue

        parts = user_input.split(None, 1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        if cmd in ("quit", "exit", "q"):
            print("Bye!")
            break
        elif cmd == "search" and arg:
            results = search_entities(arg)
            print(f"\n  Found {len(results)} entities:")
            print_entities(results)
        elif cmd == "graph" and arg:
            results = search_with_neighbors(arg)
            print(f"\n  Found {len(results)} entities with neighbors:")
            print_entities(results)
        elif cmd == "communities" and arg:
            results = search_communities(arg)
            if results:
                for c in results:
                    print(f"\n  [COMM] {c['community_id']}: {c['title']} (score: {c.get('score', '?')})")
                    print(f"     {c.get('summary', '')[:300]}")
                    if c.get("query_examples"):
                        print(f"     Examples: {c['query_examples'][:3]}")
            else:
                print("  No communities found.")
        elif cmd == "tables":
            tables = list_tables()
            print(f"\n  Found {len(tables)} tables:")
            print_tables(tables)
        elif cmd == "table" and arg:
            schema = get_table_schema(arg)
            print_table_schema(schema)
        elif cmd == "join" and arg:
            tables = arg.split()
            if len(tables) == 2:
                result = get_join_path(tables[0], tables[1])
                print_json(result)
            else:
                print("  Usage: join <table1> <table2>")
        elif cmd == "neighbors" and arg:
            neighbors = get_entity_neighbors(arg)
            print(f"\n  Found {len(neighbors)} neighbors:")
            for n in neighbors:
                print(f"  → [{n.get('neighbor_type', '?')}] {n.get('neighbor_name', '?')} ({n.get('relationship_type', '?')})")
        elif cmd == "full":
            graph = get_full_graph()
            print_json(graph)
            print(f"\n  Stats: {graph['stats']}")
        elif cmd == "stats":
            db_stats()
        elif cmd == "sql" and arg:
            results = query(arg)
            print_json(results)
        else:
            print("  Unknown command. Type 'quit' to exit.")


# ═══════════════════════════════════════════════════════════════════════════════
#  CLI ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(
        description="Query the GraphRAG PostgreSQL knowledge graph.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python query_graph.py                                # Interactive mode
  python query_graph.py --search "active UIDs"
  python query_graph.py --graph "address update"
  python query_graph.py --tables
  python query_graph.py --table uid_master
  python query_graph.py --join uid_master uid_address
  python query_graph.py --communities "biometric"
  python query_graph.py --neighbors "tbl_uid_master"
  python query_graph.py --full
  python query_graph.py --sql "SELECT * FROM entities LIMIT 5"
        """,
    )
    parser.add_argument("--search", metavar="QUERY", help="Full-text search entities")
    parser.add_argument("--graph", metavar="QUERY", help="Search with graph expansion (neighbors + text)")
    parser.add_argument("--communities", metavar="QUERY", help="Search communities")
    parser.add_argument("--tables", action="store_true", help="List all tables")
    parser.add_argument("--table", metavar="NAME", help="Get table schema (columns, joins, community)")
    parser.add_argument("--join", nargs=2, metavar=("T1", "T2"), help="Find join path between two tables")
    parser.add_argument("--neighbors", metavar="ENTITY_ID", help="Get neighbors of an entity")
    parser.add_argument("--full", action="store_true", help="Export full graph as JSON")
    parser.add_argument("--stats", action="store_true", help="Database statistics")
    parser.add_argument("--sql", metavar="SQL", help="Execute raw SQL")
    parser.add_argument("--top", type=int, default=10, help="Top K results (default: 10)")

    args = parser.parse_args()

    # No arguments → interactive mode
    if len(sys.argv) == 1:
        interactive_mode()
        return

    # Health check
    if not health_check():
        print("[ERROR] Cannot connect to PostgreSQL container.")
        print(f"   Container: {CONTAINER}")
        print(f"   Start it:  cd C:\\data-platform-context\\postgres && docker compose up -d")
        sys.exit(1)

    # Execute command
    if args.stats:
        db_stats()
    elif args.search:
        results = search_entities(args.search, top_k=args.top)
        print(f"Found {len(results)} entities:")
        print_entities(results)
    elif args.graph:
        results = search_with_neighbors(args.graph, top_k=args.top)
        print(f"Found {len(results)} entities with neighbors:")
        print_entities(results)
    elif args.communities:
        results = search_communities(args.communities, top_k=args.top)
        if results:
            for c in results:
                print(f"\n[COMM] {c['community_id']}: {c['title']} (score: {c.get('score', '?')})")
                print(f"   {c.get('summary', '')[:300]}")
        else:
            print("No communities found.")
    elif args.tables:
        tables = list_tables()
        print(f"Found {len(tables)} tables:")
        print_tables(tables)
    elif args.table:
        schema = get_table_schema(args.table)
        print_table_schema(schema)
    elif args.join:
        result = get_join_path(args.join[0], args.join[1])
        print_json(result)
    elif args.neighbors:
        neighbors = get_entity_neighbors(args.neighbors)
        print(f"Found {len(neighbors)} neighbors:")
        for n in neighbors:
            print(f"  → [{n.get('neighbor_type', '?')}] {n.get('neighbor_name', '?')} ({n.get('relationship_type', '?')})")
    elif args.full:
        graph = get_full_graph()
        print_json(graph)
        print(f"\nStats: {graph['stats']}", file=sys.stderr)
    elif args.sql:
        results = query(args.sql)
        print_json(results)


if __name__ == "__main__":
    main()
