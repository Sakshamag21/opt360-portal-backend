# Data Platform — Table Relationships & Navigation

> Living document. Updated as new tables are analyzed.
> Purpose: Help the text-to-SQL agent understand how tables relate to each other and navigate between them.
>
> **Companion files:**
> - [knowledge_graph.md](./knowledge_graph.md) — visual Mermaid graph, column flow diagram, ownership matrix, query path finder
> - [knowledge_graph.yaml](./knowledge_graph.yaml) — structured graph data for programmatic consumption (5 tables, 6 edges, 41 column groups, 10 concepts, 12 query paths)
> - [graph_rag_index.json](./graph_rag_index.json) — GraphRAG index: 217 entities, 343 relationships, 5 communities, 321 text units (incl. 94 LLM-enriched), 12 query paths
> - [graph_rag_vector_retriever.py](./graph_rag_vector_retriever.py) — **primary retriever**: TF-IDF vector space model + synonym expansion + LLM-enriched descriptions + graph expansion. 100% test accuracy. Import as `from graph_rag_vector_retriever import VectorGraphRAG`
> - [graph_rag_retriever.py](./graph_rag_retriever.py) — original keyword-based retriever (deprecated — use vector_retriever instead)
> - [graph_rag_architecture.md](./graph_rag_architecture.md) — how the search works (3-layer retrieval without embeddings), limitations, upgrade path
> - [text_to_sql_documentation.md](./text_to_sql_documentation.md) — **complete system documentation**: context layer, knowledge graph, GraphRAG index, retrieval pipeline, text-to-SQL pipeline, worked example, usage guide
> - [text_to_sql.py](./text_to_sql.py) — main pipeline: question → GraphRAG retrieval → context assembly → LLM SQL generation → EXPLAIN → execute. Interactive mode: `python text_to_sql.py`
> - [graph_rag_visualization.html](./graph_rag_visualization.html) — interactive visualization of the GraphRAG index

---

## Tables Catalogued

| # | Table | Type | Row Count | Columns | Context File | YAML File |
|---|-------|------|-----------|---------|--------------|-----------|
| 1 | `strot.mysql_uid_v2.uid_master` | Current state | ~1.46B | 30 | [md](./strot.mysql_uid_v2.uid_master.md) | [yaml](./strot.mysql_uid_v2.uid_master.yaml) |
| 2 | `strot.mysql_uid_v2.uid_his_master` | History | ~2.87B | 28 | [md](./strot.mysql_uid_v2.uid_his_master.md) | [yaml](./strot.mysql_uid_v2.uid_his_master.yaml) |
| 3 | `strot.mysql_uid_v2.uid_address` | Address (current) | ~1.46B | 31 | [md](./strot.mysql_uid_v2.uid_address.md) | [yaml](./strot.mysql_uid_v2.uid_address.yaml) |
| 4 | `strot.mysql_uid_v2.uid_his_address` | Address (history) | ~1.51B | 32 | [md](./strot.mysql_uid_v2.uid_his_address.md) | [yaml](./strot.mysql_uid_v2.uid_his_address.yaml) |
| 5 | `strot.mysql_uid_v2.uid_origin_tracker_enriched` | Enrolment tracker | ~3.29B | 68 | [md](./strot.mysql_uid_v2.uid_origin_tracker_enriched.md) | [yaml](./strot.mysql_uid_v2.uid_origin_tracker_enriched.yaml) |
| 6 | `flink_stream.stream_enu.enu_uc_opt_action_v2` | Client action tracking | ~687M | 32 | [md](./flink_stream.stream_enu.enu_uc_opt_action_v2.md) | [yaml](./flink_stream.stream_enu.enu_uc_opt_action_v2.yaml) |
| 7 | `flink_stream.stream_enu.telemetry_uc` | Client telemetry | ~295M | 19 | [md](./flink_stream.stream_enu.telemetry_uc.md) | [yaml](./flink_stream.stream_enu.telemetry_uc.yaml) |
| 8 | `flink_stream.stream_enu.enu_bfc_analytics_raw_v1` | Biometric fraud check | ~79M | 30 | [md](./flink_stream.stream_enu.enu_bfc_analytics_raw_v1.md) | [yaml](./flink_stream.stream_enu.enu_bfc_analytics_raw_v1.yaml) |
| 9 | `mysql_uidmasterv1.uidmasterv1_1.station_reg_helper` | Station/TPM registration | ~296K | 35 | [md](./mysql_uidmasterv1.uidmasterv1_1.station_reg_helper.md) | [yaml](./mysql_uidmasterv1.uidmasterv1_1.station_reg_helper.yaml) |

---

## Schema Overview: `mysql_uid_v2`

```
┌────────────────────────────────────────────────────────────────────────┐
│                          strot.mysql_uid_v2                            │
│                                                                        │
│  ┌─────────────────┐         ┌─────────────────────┐                   │
│  │   uid_master    │◄────────│   uid_his_master    │                   │
│  │  (current state)│  1 : N  │  (history snapshots) │                   │
│  │                 │────────►│                     │                   │
│  └────────┬────────┘  uid    └──────────┬──────────┘                   │
│           │  uid                    uid │ eid                          │
│           │ 1 : 1                       │ 1 : N                         │
│           ▼                             ▼                              │
│  ┌─────────────────┐         ┌─────────────────────┐                   │
│  │   uid_address   │◄────────│  uid_his_address    │                   │
│  │ (current addr)  │  1 : N  │ (address history)   │                   │
│  │                 │────────►│                     │                   │
│  └────────┬────────┘  uid    └─────────────────────┘                   │
│           │                                                            │
│           │ uid                                                        │
│           │ 1 : N                                                      │
│           ▼                                                            │
│  ┌─────────────────────────────┐                                       │
│  │ uid_origin_tracker_enriched │                                       │
│  │  (enrolment events, 3.29B)  │                                       │
│  │  join via uid + eid         │                                       │
│  └─────────────────────────────┘                                       │
│                                                                        │
│  Cross-table joins:                                                    │
│    uid_master ↔ uid_address           (1:1, on uid)                    │
│    uid_his_master ↔ uid_his_address   (1:N, on uid + eid)              │
│    uid_origin_tracker ↔ uid_his_master (1:N, on uid + eid)            │
│    uid_origin_tracker ↔ uid_his_address (1:N, on uid + eid)           │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

---

## Relationships

### 1. `uid_master` ↔ `uid_his_master`

| Property | Value |
|----------|-------|
| Relationship type | **One-to-Many** (1:N) |
| Direction | One `uid_master` row → Many `uid_his_master` rows |
| Join key | **`uid`** (encrypted Aadhaar number, varchar) |
| Also share | `shard_hint`, `uid_status_key`, `res_dob_year`, `poi`, `poa`, `pob`, `verification_type`, `info_shre_cnsnt`, `biometric_flag`, `isnri`, and most demographic columns |
| Semantic meaning | When a UID's details are updated in `uid_master`, the previous version of that row is inserted into `uid_his_master`. Each `uid_his_master` row is a historical snapshot. Average ~2.77 history rows per UID. |

#### Column Mapping

| uid_master | uid_his_master | Notes |
|------------|----------------|-------|
| `uid_master_key` | `uid_his_key` | Different PK column; both are bigint surrogate keys, both non-contiguous |
| `uid` | `uid` | **Primary join key** — same encrypted value in both |
| — | `eid` | **Only in uid_his_master** — enrolment ID for the update event |
| `uid_status_key` | `uid_status_key` | Same codes; 87.8% NULL in history |
| `res_dob_year` | `res_dob_year` | Same; higher NULL rate (52.6%) in history |
| `res_guardian_uid` | `res_guardian_uid` | Same semantics |
| `res_guardian_eid` | `res_guardian_eid` | Same semantics |
| `res_mobile_num_hash` | `res_mobile_num_hash` | Same semantics |
| `res_email_id_hash` | `res_email_id_hash` | Same semantics |
| `bnk_shre_cnsnt` | `bnk_shre_cnsnt` | Both effectively NULL (deprecated) |
| `info_shre_cnsnt` | `info_shre_cnsnt` | Same; history has extra `'N'` legacy values |
| `verification_type` | `verification_type` | Same; history has extra `'N'` legacy values |
| `poi` | `poi` | Same free-text values |
| `poa` | `poa` | Same free-text values |
| `pob` | `pob` | Same free-text values |
| `hof_proof` | `hof_proof` | Same free-text values |
| `other_proof` | `other_proof` | Both entirely NULL (deprecated) |
| `res_lang_code` | `res_lang_code` | Same codes; no official mapping |
| `biometric_flag` | `biometric_flag` | Same; history has extra `'N'` legacy values |
| `biometric_exception_ind` | `biometric_exception_ind` | Same semantics |
| `isnri` | `isnri` | Same; history has extra `'N'` legacy values |
| `res_dod` | `res_dod` | **uid_master**: has values; **uid_his_master**: entirely NULL |
| `issue_date` | `issue_date` | Both present; history range is narrower (2024→2026) |
| `created_by` | `created_by` | Same |
| `creation_date` | `creation_date` | Same; history starts 2017 (vs 2010 in master) |
| `last_updated_by` | `last_updated_by` | Same |
| `last_updated_date` | `last_updated_date` | Same |
| `shard_hint` | `shard_hint` | Same — first 2 digits of UID, use for partition pruning in both |
| `isforeigner` | — | **Only in uid_master** |
| `nationality_code` | — | **Only in uid_master** |
| `uid_expiry_date` | — | **Only in uid_master** |

#### Example Queries

**Get current record for a UID:**
```sql
SELECT * FROM strot.mysql_uid_v2.uid_master
WHERE uid = '<encrypted_uid>'
```

**Get full update history for a UID:**
```sql
SELECT * FROM strot.mysql_uid_v2.uid_his_master
WHERE uid = '<encrypted_uid>'
ORDER BY last_updated_date DESC
```

**Join current + history for a UID:**
```sql
SELECT
    m.uid, m.uid_status_key AS current_status,
    h.uid_status_key AS historical_status,
    h.eid, h.last_updated_date AS history_date
FROM strot.mysql_uid_v2.uid_master m
JOIN strot.mysql_uid_v2.uid_his_master h
    ON m.uid = h.uid
WHERE m.uid = '<encrypted_uid>'
ORDER BY h.last_updated_date DESC
```

**Use shard_hint for partition pruning in joins:**
```sql
SELECT m.uid, h.eid, h.last_updated_date
FROM strot.mysql_uid_v2.uid_master m
JOIN strot.mysql_uid_v2.uid_his_master h
    ON m.uid = h.uid AND m.shard_hint = h.shard_hint
WHERE m.shard_hint = '45'
LIMIT 100
```

### 2. `uid_master` ↔ `uid_address`

| Property | Value |
|----------|-------|
| Relationship type | **One-to-One** (1:1) |
| Direction | One `uid_master` row → One `uid_address` row |
| Join key | **`uid`** (encrypted Aadhaar number, varchar) |
| Also share | `shard_hint`, `created_by`, `creation_date`, `last_updated_by`, `last_updated_date` |
| Row count match | Both ~1.46B rows (near-exact 1:1) |
| Semantic meaning | `uid_address` contains the resident's address (geographic hierarchy: VTC, district, subdistrict, state, country, pincode). `uid_master` contains the demographic/identity data. Together they form the complete resident record. |

#### Column Mapping

| uid_master | uid_address | Notes |
|------------|-------------|-------|
| `uid_master_key` | `addr_key` | Different PK column; both bigint surrogate keys, both non-contiguous |
| `uid` | `uid` | **Primary join key** — same encrypted value in both |
| `shard_hint` | `shard_hint` | Same — first 2 digits of UID, use for partition pruning in both |
| `created_by` | `created_by` | Same |
| `creation_date` | `creation_date` | Same date range (2010→2026) |
| `last_updated_by` | `last_updated_by` | Same |
| `last_updated_date` | `last_updated_date` | Same date range (2010→2026) |
| — | `res_addr_*` columns | **Only in uid_address** — VTC, district, subdistrict, state, PO, pincode, country, address lines |
| `uid_status_key`, `res_dob_year`, etc. | — | **Only in uid_master** — demographic/identity data |

#### Example Queries

**Get address for a specific UID:**
```sql
SELECT a.res_addr_state_name, a.res_addr_district_name, a.res_addr_vtc_name, a.res_addr_pincode
FROM strot.mysql_uid_v2.uid_address a
WHERE a.uid = '<encrypted_uid>'
```

**Join demographic + address data:**
```sql
SELECT
    m.uid, m.uid_status_key, m.res_dob_year, m.verification_type,
    a.res_addr_state_code, a.res_addr_state_name, a.res_addr_district_name,
    a.res_addr_pincode, a.shard_hint
FROM strot.mysql_uid_v2.uid_master m
JOIN strot.mysql_uid_v2.uid_address a
    ON m.uid = a.uid AND m.shard_hint = a.shard_hint
WHERE m.shard_hint = '45'
LIMIT 100
```

**Count residents by state (with active status filter):**
```sql
SELECT a.res_addr_state_code, a.res_addr_state_name, COUNT(*) AS cnt
FROM strot.mysql_uid_v2.uid_address a
JOIN strot.mysql_uid_v2.uid_master m
    ON a.uid = m.uid AND a.shard_hint = m.shard_hint
WHERE m.uid_status_key = 1
GROUP BY a.res_addr_state_code, a.res_addr_state_name
ORDER BY cnt DESC
```

### 3. `uid_address` ↔ `uid_his_address`

| Property | Value |
|----------|-------|
| Relationship type | **One-to-Many** (1:N) |
| Direction | One `uid_address` row → Many `uid_his_address` rows |
| Join key | **`uid`** (encrypted Aadhaar number, varchar) |
| Also share | `shard_hint`, all `res_addr_*` columns, `created_by`, `creation_date`, `last_updated_by`, `last_updated_date` |
| Semantic meaning | When a UID's address is updated in `uid_address`, the previous version is inserted into `uid_his_address`. Each history row is a previous address snapshot. |

#### Column Mapping

| uid_address | uid_his_address | Notes |
|-------------|-----------------|-------|
| `addr_key` | `his_addr_key` | Different PK column; both bigint surrogate keys, both non-contiguous |
| `uid` | `uid` | **Primary join key** — same encrypted value in both |
| — | `eid` | **Only in uid_his_address** — enrolment ID for the update event |
| `res_addr_*` columns | `res_addr_*` columns | Same geographic hierarchy columns in both |
| `shard_hint` | `shard_hint` | Same — use for partition pruning |
| `created_by` / `creation_date` / `last_updated_by` / `last_updated_date` | Same | Same audit columns |

#### Key Differences

| Aspect | uid_address | uid_his_address |
|--------|-------------|-----------------|
| Row count | ~1.46B | ~1.51B (slightly more — some UIDs have multiple address history rows) |
| `eid` column | Not present | Present (always populated) |
| Date range start | 2010-08-21 | 2017-08-17 (history retention began later) |
| Subdistrict NULL rate | 6.1% | 11.8% |
| Pincode NULL rate | 0% | 0.02% |
| State name NULL | ~0% | 0.34% (some rows have valid code but NULL name) |
| Literal `'NULL'` strings | Rare | Present in subdistrict/PO columns |

#### Example Queries

**Get address history for a specific UID:**
```sql
SELECT eid, res_addr_state_name, res_addr_district_name, res_addr_vtc_name, res_addr_pincode, last_updated_date
FROM strot.mysql_uid_v2.uid_his_address
WHERE uid = '<encrypted_uid>'
ORDER BY last_updated_date DESC
```

**Correlate address history with demographic history (same enrolment event):**
```sql
SELECT
    hm.eid, hm.last_updated_date AS update_date,
    hm.uid_status_key, hm.res_dob_year,
    ha.res_addr_state_name, ha.res_addr_district_name, ha.res_addr_pincode
FROM strot.mysql_uid_v2.uid_his_master hm
JOIN strot.mysql_uid_v2.uid_his_address ha
    ON hm.uid = ha.uid AND hm.eid = ha.eid AND hm.shard_hint = ha.shard_hint
WHERE hm.shard_hint = '45'
LIMIT 100
```

### 4. `uid_origin_tracker_enriched` ↔ `uid_his_master` / `uid_his_address`

| Property | Value |
|----------|-------|
| Relationship type | **One-to-Many** (1:N) — one enrolment event can produce multiple history rows |
| Join key | **`uid`** + **`eid`** (enrolment ID) |
| Also share | `shard_hint` |
| Semantic meaning | `uid_origin_tracker_enriched` tracks every enrolment/update event (who, when, how, what fields changed). The history tables (`uid_his_master`, `uid_his_address`) store the resulting snapshots. Joining on `uid` + `eid` links the enrolment event metadata to the history records it produced. |
| Row count | ~3.29B (largest table — one row per enrolment packet, including updates) |

#### What the tracker adds

The tracker table contains metadata **not available** in the history tables:
- `registrar_code`, `ea_code` — who conducted the enrolment
- `operator_id`, `supervisor_id` — who operated the device
- `enr_mode` — online vs offline
- `update_ind`, `reject_ind` — whether it was an update or rejection
- `updt_*` flags — which specific fields were changed (varbinary: `b'00'`=no, `b'11'`=yes)
- `source`, `packet_version` — workflow type and software version

#### Example Queries

**Find what fields were updated in a specific enrolment event:**
```sql
SELECT
    eid, update_ind, reject_ind,
    CAST(updt_address AS varchar) AS addr_updated,
    CAST(updt_resident_name AS varchar) AS name_updated,
    CAST(updt_dob AS varchar) AS dob_updated,
    CAST(updt_poi AS varchar) AS poi_updated,
    CAST(updt_poa AS varchar) AS poa_updated
FROM strot.mysql_uid_v2.uid_origin_tracker_enriched
WHERE uid = '<encrypted_uid>' AND shard_hint = '45'
  AND update_ind = true
ORDER BY enr_date DESC
LIMIT 10
```

**Correlate enrolment event with history snapshots:**
```sql
SELECT
    t.eid, t.enr_date, t.update_ind, t.reject_ind,
    t.registrar_code, t.operator_id,
    CAST(t.updt_address AS varchar) AS addr_updated,
    CAST(t.updt_resident_name AS varchar) AS name_updated,
    hm.uid_status_key, hm.res_dob_year,
    ha.res_addr_state_name, ha.res_addr_pincode
FROM strot.mysql_uid_v2.uid_origin_tracker_enriched t
LEFT JOIN strot.mysql_uid_v2.uid_his_master hm
    ON t.uid = hm.uid AND t.eid = hm.eid AND t.shard_hint = hm.shard_hint
LEFT JOIN strot.mysql_uid_v2.uid_his_address ha
    ON t.uid = ha.uid AND t.eid = ha.eid AND t.shard_hint = ha.shard_hint
WHERE t.shard_hint = '45' AND t.update_ind = true
LIMIT 100
```

> ⚠️ **Always filter by `shard_hint`** when querying `uid_origin_tracker_enriched` — it's 3.29B rows and full scans will time out.

---

## Shared Concepts (across all tables in `mysql_uid_v2`)

| Concept | Column(s) | Description |
|---------|-----------|-------------|
| **Encrypted UID** | `uid` | Base64-like encrypted Aadhaar number. Present in all UID tables. Primary join key. PII. |
| **Enrolment ID** | `eid` | Present in history tables (`uid_his_master`, `uid_his_address`) and `uid_origin_tracker_enriched`. Used to correlate enrolment events with history snapshots. |
| **Shard hint** | `shard_hint` | First 2 digits of the UID. MySQL sharding is based on this. Always include in WHERE clause for partition pruning. |
| **UID status** | `uid_status_key` | Integer status code. `1` = active, `99` = deactivated. See per-table YAML for full mapping. |
| **Proof documents** | `poi`, `poa`, `pob`, `hof_proof` | Free-text document names. Use `LIKE '%keyword%'` and `LOWER()`. |
| **Consent flags** | `info_shre_cnsnt` | `'1'` = consented, `'0'` = not. History table may have `'N'` legacy values. |
| **PII columns** | `uid`, `res_guardian_uid`, `res_guardian_eid` (encrypted); `res_mobile_num_hash`, `res_email_id_hash` (hashed) | Never attempt decryption in SQL. |
| **Geographic hierarchy** | `res_addr_*` columns | Country → State → District → Subdistrict → VTC → PO → Pincode. Present in `uid_address` and `uid_his_address`. Filter by `res_addr_state_code` (not name) due to spelling variants. |
| **Deprecated columns** | `bnk_shre_cnsnt`, `other_proof`, `res_f_addr_line1/2/3` | Entirely NULL or >99.99% NULL in all known tables. Do not rely on them. |
| **Language code** | `res_lang_code` | No official mapping available — ask the user when needed. |
| **Data quality — state names** | `res_addr_state_name` | Same code can have different name spellings (Odisha/Orissa, Puducherry/Pondicherry). Always filter by `res_addr_state_code`. |
| **Data quality — country codes** | `res_addr_country_code` | Inconsistent values (`'356'`, `'India'`, `'001'`). Use `res_addr_country_name = 'India'` for complete filtering. |
| **Literal `'NULL'` strings** | Various | Some columns contain the literal string `'NULL'` in addition to actual NULLs. Filter with `WHERE col IS NOT NULL AND col != 'NULL'`. |

---

## Cross-Schema Relationships (flink_stream + mysql_uidmasterv1)

The data platform spans 3 schemas. The original `strot.mysql_uid_v2` tables contain **server-side** enrolment data. The `flink_stream.stream_enu` tables contain **client-side** activity (operator actions, telemetry, biometric fraud checks). The `mysql_uidmasterv1.uidmasterv1_1` table contains **device-level** station/TPM registration.

### Cross-Schema Schema Overview

```
┌──────────────────── strot.mysql_uid_v2 ────────────────────┐
│  (server-side enrolment/identity data)                      │
│                                                             │
│  uid_origin_tracker_enriched (3.29B)                        │
│    ├─ registrar_code  ◄────────────────────────────┐        │
│    ├─ ea_code         ◄────────────────────────────┤        │
│    └─ operator_id     ◄──────────────────────┐     │        │
│                                               │     │        │
└───────────────────────────────────────────────┼─────┼────────┘
                                                │     │
                            ┌───────────────────┘     │
                            │                         │
┌──── flink_stream.stream_enu ─────────┐   ┌── mysql_uidmasterv1.uidmasterv1_1 ──┐
│  (client-side activity)              │   │  (device registration)               │
│                                      │   │                                      │
│  enu_uc_opt_action_v2 (687M)         │   │  station_reg_helper (296K)           │
│    ├─ operator_id    ◄───────────────┘   │    ├─ registrar_id        ◄─────────┤
│    ├─ registrar      ◄────────────────────┤    ├─ enrollment_agency_code ◄──────┤
│    ├─ ea             ◄────────────────────┤    ├─ station_id          ◄─────────┤
│    ├─ station_id    ◄─────────────────────┤    └─ machine_id  ◄─────────────────┤
│    ├─ session_id    ◄──┐                  │                                      │
│    └─ event_id       ◄─┤                  └──────────────────────────────────────┘
│                        │                             ▲
│  telemetry_uc (295M)   │                             │
│    ├─ actor_id        ◄┤  (= operator_id)            │
│    ├─ sid             ◄┤  (= session context)        │
│    ├─ pdata_id        ◄┤  (= machine_id)             │
│    └─ eid (event key) ◄┤                             │
│                        │                             │
│  enu_bfc_analytics_raw_v1 (79M)                    │
│    ├─ operatorid      ◄┤  (= operator_id)            │
│    ├─ machinecode     ◄┤  (= machine_id)             │
│    ├─ sid             ◄┘  (= session context)        │
│    └─ eventid          (UUID, standalone)            │
│                                                      │
└──────────────────────────────────────────────────────┘
```

### Cross-Schema Join Keys

| Join Key | strot.mysql_uid_v2 | flink_stream.stream_enu | mysql_uidmasterv1 |
|----------|---------------------|------------------------|-------------------|
| **Registrar code** | `registrar_code` (origin_tracker) | `registrar` (enu_uc_opt_action_v2) | `registrar_id` (station_reg_helper) |
| **EA code** | `ea_code` (origin_tracker) | `ea` (enu_uc_opt_action_v2) | `enrollment_agency_code` (station_reg_helper) |
| **Operator ID** | `operator_id` (origin_tracker) | `operator_id` (enu_uc_opt), `operatorid` (bfc), `actor_id` (telemetry) | — |
| **Station ID** | — | `station_id` (enu_uc_opt_action_v2) | `station_id` (station_reg_helper) |
| **Machine/Device ID** | — | `machinecode` (bfc), `pdata_id` (telemetry) | `machine_id` (station_reg_helper) |
| **Session ID** | — | `session_id` (enu_uc_opt), `sid` (telemetry, bfc) | — |
| **UID (encrypted)** | `uid` (all tables) | `resident_uid` (enu_uc_opt, ~99% NULL) | — |

### Relationship 5: enu_uc_opt_action_v2 ↔ enu_bfc_analytics_raw_v1

| Property | Value |
|----------|-------|
| Relationship type | **Many-to-Many** (N:N) |
| Join key | `operator_id` ↔ `operatorid` (same format, e.g. `MH_MIT_JG_NS249784`) |
| Also joinable on | `sid` ↔ `sid` (session ID — links events in same client session) |
| Semantic meaning | enu_uc_opt_action_v2 tracks workflow stage events; enu_bfc_analytics_raw_v1 tracks biometric fraud check evaluations within the same session. Joining gives a complete view of what stages occurred and what biometric checks ran. |
| Caveat | N:N — one operator has many events in both tables. Always filter by date and session_id for meaningful joins. |

### Relationship 6: enu_uc_opt_action_v2 ↔ telemetry_uc

| Property | Value |
|----------|-------|
| Relationship type | **Many-to-Many** (N:N) |
| Join key | `operator_id` ↔ `actor_id` (same operator login ID format) |
| Also joinable on | `session_id` ↔ `sid` (session context) |
| Semantic meaning | enu_uc_opt_action_v2 tracks workflow stages; telemetry_uc tracks application errors/debug events. Joining shows which errors occurred during which workflow stages. |
| Caveat | N:N. Telemetry events are application-level (exceptions, stacktraces), not workflow-level. Use `sid` for session-level correlation. |

### Relationship 7: enu_uc_opt_action_v2 ↔ station_reg_helper

| Property | Value |
|----------|-------|
| Relationship type | **Many-to-One** (N:1) |
| Join key | `station_id` ↔ `station_id` |
| Also joinable on | `registrar` ↔ `registrar_id`, `ea` ↔ `enrollment_agency_code` |
| Semantic meaning | Each enrolment session runs on a station registered in station_reg_helper. Joining links the client activity to the device's TPM/security info. |
| Caveat | `station_id` in enu_uc_opt_action_v2 is NULL ~77% of the time. Use registrar+EA as fallback join for aggregate analysis. |

### Relationship 8: enu_bfc_analytics_raw_v1 ↔ telemetry_uc

| Property | Value |
|----------|-------|
| Relationship type | **Many-to-Many** (N:N) |
| Join key | `sid` ↔ `sid` (session ID) |
| Also joinable on | `machinecode` ↔ `pdata_id` (device identifier) |
| Semantic meaning | BFC evaluations and telemetry errors within the same client session. Joining shows if BFC errors correlate with application errors. |
| Caveat | N:N. Both tables are large (79M + 295M). Always filter by date first. |

### Relationship 9: enu_bfc_analytics_raw_v1 ↔ station_reg_helper

| Property | Value |
|----------|-------|
| Relationship type | **Many-to-One** (N:1) |
| Join key | `machinecode` ↔ `machine_id` (same `<manufacturer><UUID>` format) |
| Semantic meaning | Each BFC evaluation runs on a machine registered in station_reg_helper. Joining links biometric fraud check results to the device's TPM/security posture. |

### Relationship 10: telemetry_uc ↔ station_reg_helper

| Property | Value |
|----------|-------|
| Relationship type | **Many-to-One** (N:1) |
| Join key | `pdata_id` ↔ `machine_id` (same `<manufacturer><UUID>` format) |
| Semantic meaning | Each telemetry event comes from a machine in station_reg_helper. Joining links client errors to device registration/TPM info. |

### Relationship 11: station_reg_helper ↔ uid_origin_tracker_enriched (cross-schema)

| Property | Value |
|----------|-------|
| Relationship type | **Many-to-One** (N:1) |
| Join key | `registrar_id` ↔ `registrar_code`, `enrollment_agency_code` ↔ `ea_code` |
| Semantic meaning | station_reg_helper has device registration per registrar/EA; uid_origin_tracker_enriched has enrolment events per registrar/EA. Joining links device security posture to enrolment activity. |
| Caveat | No direct row-level link — different granularity (device vs enrolment event). Use for aggregate analysis (e.g. TPM coverage by registrar). |

### Relationship 12: enu_uc_opt_action_v2 ↔ uid_origin_tracker_enriched (cross-schema)

| Property | Value |
|----------|-------|
| Relationship type | **Many-to-Many** (N:N) |
| Join key | `registrar` ↔ `registrar_code`, `ea` ↔ `ea_code`, `operator_id` ↔ `operator_id` |
| Semantic meaning | enu_uc_opt_action_v2 has client-side stage events; uid_origin_tracker_enriched has server-side enrolment events. Same codes used in both. Joining links client workflow to server-side enrolment outcomes. |
| Caveat | N:N, different event granularity. No direct row-level link (client events ≠ server events). Use for aggregate analysis only. |

### Cross-Schema Join Caveats

1. **No `shard_hint`** in flink_stream or mysql_uidmasterv1 tables — cross-schema joins cannot use shard_hint for partition pruning on the flink/station side
2. **`operator_id` format matches** across all schemas — but cardinality is N:N (one operator has many events in all tables)
3. **`machine_id` / `machinecode` / `pdata_id`** all use the same `<manufacturer><UUID>` format across enu_bfc_analytics_raw_v1, telemetry_uc, and station_reg_helper
4. **`registrar` / `registrar_id` / `registrar_code`** and **`ea` / `enrollment_agency_code` / `ea_code`** use the same numeric codes across all 3 schemas
5. **`sid`** (session ID) links telemetry_uc and enu_bfc_analytics_raw_v1 events within the same client session
6. Cross-schema joins are **expensive** — always filter by date on the flink_stream side first to narrow the dataset before joining
7. **`resident_uid`** in enu_uc_opt_action_v2 could join to `uid` in strot tables, but it's NULL ~99% of the time (only populated in late stages)

---

## Navigation Guide for the Agent

1. **Need the current/latest state of a UID?** → Query `uid_master`.
2. **Need the update history for a UID?** → Query `uid_his_master`, filter by `uid`.
3. **Need the current address for a UID?** → Query `uid_address`, filter by `uid`.
4. **Need the address history for a UID?** → Query `uid_his_address`, filter by `uid`.
5. **Need enrolment event metadata (who, when, how, what changed)?** → Query `uid_origin_tracker_enriched`, filter by `uid` + `shard_hint`.
6. **Need to know which fields were updated in an event?** → Query `uid_origin_tracker_enriched`, check `updt_*` varbinary flags (`b'11'` = updated).
7. **Need to join current + history (demographic)?** → Join `uid_master` + `uid_his_master` on `uid` (and `shard_hint`).
8. **Need to join current + history (address)?** → Join `uid_address` + `uid_his_address` on `uid` (and `shard_hint`).
9. **Need to join demographic + address (current)?** → Join `uid_master` + `uid_address` on `uid` (and `shard_hint`).
10. **Need to correlate demographic history + address history (same event)?** → Join `uid_his_master` + `uid_his_address` on `uid` + `eid` (and `shard_hint`).
11. **Need to correlate enrolment event with history snapshots?** → Join `uid_origin_tracker_enriched` + `uid_his_master` / `uid_his_address` on `uid` + `eid` (and `shard_hint`).
12. **Need enrolment ID (`eid`)?** → Available in `uid_his_master`, `uid_his_address`, and `uid_origin_tracker_enriched`.
13. **Need foreigner/nationality/expiry info?** → Only available in `uid_master`.
14. **Need geographic/location data (state, district, pincode, etc.)?** → Only available in `uid_address` and `uid_his_address`.
15. **Need registrar/operator/agency info?** → Available in `uid_origin_tracker_enriched` (`registrar_code`, `ea_code`, `operator_id`). Also in `enu_uc_opt_action_v2` (`registrar`, `ea`, `operator_id`) and `station_reg_helper` (`registrar_id`, `enrollment_agency_code`).
16. **Need client-side operator actions/stage events?** → Query `enu_uc_opt_action_v2` (687M rows). Filter on `event_timestamp`. Use `session_id` to track a full session journey.
17. **Need client application errors/telemetry?** → Query `telemetry_uc` (295M rows). Filter on `ets`. Use `type='ERROR'` for errors. Never SELECT `stacktrace` without LIMIT.
18. **Need biometric fraud check results?** → Query `enu_bfc_analytics_raw_v1` (79M rows). Filter on `eventtimestamp`. Use `modelname` to distinguish AGE_VERIFICATION vs UNSYSTEMATIC checks. Use `TRY_CAST(modelprediction AS double)` for age values.
19. **Need device/station TPM registration info?** → Query `station_reg_helper` (296K rows). Use `creation_date` for date filtering (NOT `capture_timestamp` — has zero dates). Use `trim(manufacturer)` for clean grouping.
20. **Need to link client events to server-side enrolment?** → Join on `registrar`/`registrar_code` and `ea`/`ea_code`. Cross-schema, N:N, aggregate-level only.
21. **Need to link biometric checks to device security?** → Join `enu_bfc_analytics_raw_v1.machinecode` ↔ `station_reg_helper.machine_id` (N:1).
22. **Need to link telemetry errors to device info?** → Join `telemetry_uc.pdata_id` ↔ `station_reg_helper.machine_id` (N:1).
23. **Always add `shard_hint`** to WHERE clause when querying `strot.mysql_uid_v2` tables by UID for partition pruning. **Mandatory** for `uid_origin_tracker_enriched` (3.29B rows). **Does NOT apply** to `flink_stream` or `mysql_uidmasterv1` tables — use their respective timestamp columns.
24. **All `strot.mysql_uid_v2` tables are very large** (1.46B–3.29B rows). `flink_stream` tables are large (79M–687M rows). `station_reg_helper` is small (296K). Always use `LIMIT` and predicates.
25. **Read host:** `10.10.116.39` for all SELECT queries. No writes allowed on any table.

---

## Pending / To Be Analysed

> Add new tables here as they are discovered. Move to the "Tables Catalogued" section once analysed.

- 7 undocumented tables in `strot.mysql_uid_v2`: `eid_reject_master`, `ot_addr_master`, `ot_addr_master_staging2`, `request_tracker`, `uid_master_address`, `uid_origin_tracker`, `uid_tat_ageing_summary`

---

## Changelog

| Date | Change |
|------|--------|
| 2026-10-09 | Initial creation. Added `uid_master` and `uid_his_master` with full relationship mapping. |
| 2026-10-09 | Added `uid_address` table (1:1 with `uid_master`). Updated schema diagram, navigation guide, and relationship #2. |
| 2026-10-09 | Added `uid_his_address` table (1:N with `uid_address`). Updated schema diagram, navigation guide, relationship #3, and shared concepts. Added `eid` cross-table correlation pattern. |
| 2026-10-09 | Added `uid_origin_tracker_enriched` table (3.29B rows, largest table). Updated schema diagram, navigation guide, relationship #4, and shared concepts. Added varbinary `updt_*` flag documentation and shard-sampled distributions. |
| 2026-10-09 | Created `knowledge_graph.md` and `knowledge_graph.yaml` — visual Mermaid graph, column flow diagram, ownership matrix, concept layer, query path finder. 5 tables, 6 edges, 41 column groups, 10 concepts, 12 query paths. |
| 2026-10-09 | Built GraphRAG index (`graph_rag_index.json`): 217 entities (5 tables, 189 columns, 10 concepts, 3 hosts, 3 join keys, 7 data quality issues), 343 relationships, 5 communities with reports, 227 text units, 12 query paths. Created `graph_rag_retriever.py` (global/local/hybrid search) and `graph_rag_visualization.html` (interactive). |
| 2026-10-09 | Upgraded to TF-IDF vector space retriever (`graph_rag_vector_retriever.py`): from-scratch TF-IDF with numpy, domain synonym expansion (35 groups), LLM-enriched entity descriptions (92 entities, 94 text units). 100% test accuracy on 20 semantic queries. Created `graph_rag_architecture.md` documenting the 3-layer retrieval approach. |
| 2026-10-10 | Built end-to-end text-to-SQL pipeline (`text_to_sql.py`): question → GraphRAG retrieval (TF-IDF + LLM re-rank) → context assembly → GLM-5.2 SQL generation → EXPLAIN validation → Trino execution. Fixed varbinary handling (`from_utf8()` not `CAST()`), trailing semicolons, missing LIMIT. Tested on complex multi-table queries. Created `llm_client.py` (GLM-5.2-FP8 API wrapper). |
| 2026-10-10 | Created `text_to_sql_documentation.md` — comprehensive system documentation covering all 5 layers (table context, knowledge graph, GraphRAG index, retrieval pipeline, text-to-SQL pipeline), worked end-to-end example, usage guide, design decisions, limitations, and upgrade path. |
| 2026-10-10 | Implemented BM25 (Okapi BM25) as alternative to TF-IDF (`bm25_retriever.py`). Ran full comparison: 35 parameter configurations, 20 test queries, complex real-world query, end-to-end SQL generation. **Result: TF-IDF wins 14/20 vs BM25 13/20** — BM25's length normalization backfires on short uniform corpus. After LLM re-ranking, both converge to identical SQL. Created `tfidf_vs_bm25_comparison.md` documenting the full study. |
| 2026-10-16 | Added 4 new tables across 2 new schemas: `flink_stream.stream_enu.enu_uc_opt_action_v2` (687M rows, 32 cols — operator action/stage tracking), `flink_stream.stream_enu.telemetry_uc` (295M rows, 19 cols — client telemetry/error logging), `flink_stream.stream_enu.enu_bfc_analytics_raw_v1` (79M rows, 30 cols — biometric fraud check analytics), `mysql_uidmasterv1.uidmasterv1_1.station_reg_helper` (296K rows, 35 cols — station/TPM registration). Added cross-schema relationships (5-12), cross-schema join key mapping, updated navigation guide (items 16-25), and updated tables catalogued (9 tables total). Platform now spans 3 schemas, 9 tables, 305 columns. |
