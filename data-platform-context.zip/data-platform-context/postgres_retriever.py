#!/usr/bin/env python3
"""
PostgreSQL-backed GraphRAG Retriever.

Replaces JSON file loading + BM25-from-scratch with:
  - Full-text search: PostgreSQL's built-in tsvector + ts_rank (BM25)
  - Graph traversal: SQL JOINs on relationships table
  - Vector search: pgvector HNSW index (ready for embeddings)

No JSON file. No BM25 rebuild. Just SQL queries to a running PostgreSQL instance.

Same interface as CleanGraphRAG — drop-in replacement.

Connection: Uses `docker exec psql` (no Python PostgreSQL driver needed).
"""

import sys
import os
import json
import subprocess
import tempfile
from pathlib import Path

# Reuse tokenizer and synonyms from original
sys.path.insert(0, str(Path(__file__).parent))
from graph_rag_vector_retriever import (
    SYNONYM_GROUPS, SYNONYM_MAP,
    tokenize, expand_synonyms,
)

# ─── Configuration ──────────────────────────────────────────────────

CONTAINER = "graphrag-postgres"
DB_USER = "graphrag"
DB_NAME = "graphrag"
TEMP_DIR = os.path.join(os.environ.get("TEMP", "/tmp"), "opencode")
os.makedirs(TEMP_DIR, exist_ok=True)


class PostgresGraphRAG:
    """
    GraphRAG retriever backed by PostgreSQL.

    Replaces the JSON + BM25-from-scratch approach with SQL queries:
      - Full-text search via PostgreSQL's built-in tsvector/ts_rank (BM25)
      - Graph expansion via SQL JOINs on the relationships table
      - One SQL query replaces: JSON load + BM25 build + scoring + graph traversal

    Same interface as CleanGraphRAG — drop-in replacement.
    """

    def __init__(self):
        self.synonym_map = SYNONYM_MAP
        self.synonym_groups = SYNONYM_GROUPS
        self.tokenize_fn = tokenize

        # Verify connection
        if not self._health_check():
            raise RuntimeError(
                f"Cannot connect to PostgreSQL container '{CONTAINER}'. "
                f"Run: cd C:\\data-platform-context\\postgres && docker compose up -d"
            )

    # ═════════════════════════════════════════════════════════════════
    #  SQL EXECUTION LAYER
    # ═════════════════════════════════════════════════════════════════

    def _query(self, sql):
        """
        Execute SQL via psql in the Docker container.
        Returns results as a list of Python dicts.

        Uses JSON aggregation for clean parsing — no CSV splitting, no quoting issues.
        Pipes SQL via stdin (no temp file, no docker cp — 5x faster).
        """
        # Wrap in JSON aggregation
        json_sql = f"SELECT coalesce(json_agg(row_to_json(t)), '[]'::json) FROM ({sql}) t;"

        # Pipe SQL directly via stdin — no docker cp needed
        result = subprocess.run(
            ["docker", "exec", "-i", CONTAINER, "psql",
             "-U", DB_USER, "-d", DB_NAME,
             "-t", "-A"],
            input=json_sql,
            capture_output=True, text=True, encoding="utf-8",
        )

        if result.returncode != 0:
            raise RuntimeError(f"psql error: {result.stderr.strip()}")

        output = result.stdout.strip()
        if not output or output == "null":
            return []

        try:
            return json.loads(output)
        except json.JSONDecodeError as e:
            # Try to fix common issues
            cleaned = output.replace("\\u0000", "")
            try:
                return json.loads(cleaned)
            except json.JSONDecodeError:
                raise RuntimeError(f"JSON parse error: {e}\nOutput: {output[:500]}")

    def _health_check(self):
        """Check if PostgreSQL is running and has data."""
        try:
            result = self._query("SELECT count(*) AS cnt FROM entities")
            return result and result[0].get("cnt", 0) > 0
        except Exception:
            return False

    # ═════════════════════════════════════════════════════════════════
    #  QUERY BUILDING
    # ═════════════════════════════════════════════════════════════════

    def _build_tsquery(self, query):
        """
        Build a websearch_to_tsquery string with synonym expansion.

        Uses websearch_to_tsquery format (like a web search engine):
          - Terms are ANDed by default
          - OR creates alternatives between adjacent terms
          - More forgiving than to_tsquery (no syntax errors on multi-word phrases)

        Example:
          Query: "is the person still alive"
          Tokens: [person, still, alive]
          Synonyms: alive → {alive, living, deceased, death, die, dead, passed, away}
          Result: "person still alive OR living OR deceased OR death OR die OR dead OR passed OR away"

        Multi-word synonyms (e.g., "head of family") are split into individual words
        to avoid phrase-matching issues.
        """
        tokens = self.tokenize_fn(query)
        if not tokens:
            return ""

        # Remove duplicates while preserving order
        seen = set()
        unique_tokens = []
        for t in tokens:
            if t not in seen:
                seen.add(t)
                unique_tokens.append(t)

        # Build OR groups using websearch syntax
        parts = []
        used = set()

        for token in unique_tokens:
            if token in used:
                continue
            used.add(token)

            syn_group = self.synonym_map.get(token)
            if syn_group:
                # Collect all terms (token + synonyms), splitting multi-word synonyms
                all_terms = [token]
                for s in syn_group:
                    if s not in used:
                        used.add(s)
                        # Split multi-word synonyms into individual words
                        for word in s.split():
                            if word not in all_terms:
                                all_terms.append(word)
                # Join with OR for websearch_to_tsquery
                parts.append(" OR ".join(all_terms))
            else:
                parts.append(token)

        return " ".join(parts)

    def _sql_escape(self, s):
        """Escape a string for safe inclusion in SQL single-quoted literal."""
        return str(s).replace("'", "''")

    # ═════════════════════════════════════════════════════════════════
    #  SEARCH (same interface as CleanGraphRAG)
    # ═════════════════════════════════════════════════════════════════

    def search(self, query, mode="hybrid", top_k=10, use_llm_rerank=False, llm_top_k=5):
        """
        Unified search. Same interface as CleanGraphRAG.search().

        Two-stage retrieval when use_llm_rerank=True:
          Stage 1: PostgreSQL full-text search (fast, index-backed)
          Stage 2: LLM re-ranking (optional, higher precision)
        """
        result = {"query": query, "mode": mode}

        if mode in ("global", "hybrid"):
            result["global_results"] = self._global_search(query, top_k=3)

        if mode in ("local", "hybrid"):
            local_results = self._local_search(
                query, top_k=top_k * 3 if use_llm_rerank else top_k
            )

            if use_llm_rerank and local_results:
                try:
                    from llm_client import LLMClient
                    llm = LLMClient()

                    candidates = local_results[:llm_top_k]
                    candidate_texts = []
                    for c in candidates:
                        desc = c.get("description", "")[:150]
                        name = c.get("name", "")
                        etype = c.get("type", "")
                        candidate_texts.append({
                            "name": name,
                            "text": f"[{etype}] {name}: {desc}",
                            "_original": c,
                        })

                    ranked = llm.rerank(query, candidate_texts)

                    reranked = []
                    for item in ranked:
                        original = item.get("_original", {})
                        original["pg_score"] = original.pop("score", 0)
                        original["llm_score"] = item.get("llm_score", 0)
                        original["llm_rank"] = item.get("llm_rank", 0)
                        original["score"] = item.get("llm_score", 0) / 10.0
                        reranked.append(original)

                    reranked_ids = {r["entity_id"] for r in reranked}
                    for r in local_results:
                        if r["entity_id"] not in reranked_ids:
                            r["pg_score"] = r.pop("score", 0)
                            r["llm_score"] = 0
                            r["llm_rank"] = 0
                            reranked.append(r)

                    result["local_results"] = reranked[:top_k]
                    result["llm_reranked"] = True
                except Exception as e:
                    result["local_results"] = local_results[:top_k]
                    result["llm_reranked"] = False
                    result["llm_error"] = str(e)
            else:
                result["local_results"] = local_results[:top_k]
                result["llm_reranked"] = False

        if mode == "hybrid":
            # Find communities for local results — batched into ONE query
            local_eids = [lr["entity_id"] for lr in result.get("local_results", [])]
            if local_eids:
                eid_list = ",".join(f"'{self._sql_escape(eid)}'" for eid in local_eids)
                comm_rows = self._query(
                    f"SELECT DISTINCT community_id FROM communities "
                    f"WHERE entity_ids && ARRAY[{eid_list}]::text[]"
                )
                local_communities = {c["community_id"] for c in comm_rows}
            else:
                local_communities = set()
            result["local_community_ids"] = list(local_communities)

        return result

    def _local_search(self, query, top_k=10):
        """
        Full-text search + graph expansion + text units in ONE SQL query.

        Replaces:
          - JSON file loading
          - BM25 vocabulary/matrix rebuild
          - Scoring all 222 documents
          - Manual Python graph traversal
          - Manual text unit lookup

        With a single SQL query that:
          1. Searches the GIN index (instant, only matching rows)
          2. Ranks by ts_rank (built-in BM25)
          3. Expands graph via v_neighbors view
          4. Fetches text units
        """
        tsquery = self._build_tsquery(query)
        if not tsquery:
            return []

        tsq = self._sql_escape(tsquery)

        # ONE query: full-text search + graph expansion + text units
        sql = f"""
        WITH search_results AS (
            SELECT e.entity_id, e.name, e.type, e.description, e.properties,
                   ts_rank(e.tsv, websearch_to_tsquery('english', '{tsq}')) AS score
            FROM entities e
            WHERE e.tsv @@ websearch_to_tsquery('english', '{tsq}')
            ORDER BY score DESC
            LIMIT {int(top_k)}
        )
        SELECT
            sr.entity_id, sr.name, sr.type, sr.description, sr.properties,
            ROUND(sr.score::numeric, 4) AS score,
            COALESCE(
                (SELECT json_agg(json_build_object(
                    'entity_id', vn.neighbor_id,
                    'name', vn.neighbor_name,
                    'type', vn.neighbor_type,
                    'description', vn.neighbor_description,
                    'relationship', vn.relationship_type
                ))
                FROM v_neighbors vn
                WHERE vn.entity_id = sr.entity_id
                  AND vn.neighbor_id NOT IN (SELECT entity_id FROM search_results)),
                '[]'::json
            ) AS neighbors,
            COALESCE(
                (SELECT json_agg(json_build_object(
                    'text', tu.text, 'source', tu.source
                ))
                FROM text_units tu
                WHERE tu.entity_id = sr.entity_id
                LIMIT 2),
                '[]'::json
            ) AS matched_texts
        FROM search_results sr
        ORDER BY sr.score DESC
        """

        rows = self._query(sql)

        # Format to match the existing interface
        output = []
        for row in rows:
            neighbors = row.get("neighbors", []) or []
            matched = row.get("matched_texts", []) or []
            output.append({
                "entity_id": row["entity_id"],
                "name": row["name"],
                "type": row["type"],
                "score": float(row.get("score", 0)),
                "description": row.get("description", ""),
                "properties": row.get("properties", {}),
                "matched_texts": [t["text"][:150] for t in matched],
                "neighbors": neighbors[:15],
            })

        return output

    def _global_search(self, query, top_k=3):
        """Search community summaries via full-text search."""
        tsquery = self._build_tsquery(query)
        if not tsquery:
            return []

        tsq = self._sql_escape(tsquery)

        sql = f"""
        SELECT community_id, title, summary, entity_count,
               ts_rank(
                   to_tsvector('english', coalesce(title, '') || ' ' || coalesce(summary, '')),
                   websearch_to_tsquery('english', '{tsq}')
               ) AS score,
               key_relationships, query_examples
        FROM communities
        WHERE to_tsvector('english', coalesce(title, '') || ' ' || coalesce(summary, ''))
              @@ websearch_to_tsquery('english', '{tsq}')
        ORDER BY score DESC
        LIMIT {int(top_k)}
        """

        rows = self._query(sql)

        return [{
            "community_id": r["community_id"],
            "title": r["title"],
            "score": float(r.get("score", 0)),
            "summary": r.get("summary", ""),
            "entity_count": r.get("entity_count", 0),
            "key_relationships": r.get("key_relationships", []),
            "query_examples": r.get("query_examples", []),
        } for r in rows]

    # ═════════════════════════════════════════════════════════════════
    #  TABLE CONTEXT (same interface as CleanGraphRAG)
    # ═════════════════════════════════════════════════════════════════

    def get_table_context(self, table_name):
        """Get full table schema: columns, joins, community — in ONE query."""
        tn = self._sql_escape(table_name.lower())

        sql = f"""
        SELECT
            t.name, t.description, t.properties,
            COALESCE(
                (SELECT json_agg(json_build_object(
                    'name', c.name,
                    'description', c.description,
                    'properties', c.properties
                ) ORDER BY c.name)
                FROM entities c
                JOIN relationships r ON r.target_id = c.entity_id
                WHERE r.source_id = t.entity_id AND r.type = 'HAS_COLUMN'),
                '[]'::json
            ) AS columns,
            COALESCE(
                (SELECT json_agg(json_build_object(
                    'target_table', t2.name,
                    'relationship', r.type,
                    'description', r.description,
                    'properties', r.properties
                ))
                FROM relationships r
                JOIN entities t2 ON r.target_id = t2.entity_id
                WHERE r.source_id = t.entity_id AND r.type = 'JOINS_TO'
                  AND t2.type = 'TABLE'),
                '[]'::json
            ) AS joins,
            COALESCE(
                (SELECT json_build_object(
                    'id', c.community_id, 'title', c.title
                )
                FROM communities c
                WHERE t.entity_id = ANY(c.entity_ids)
                LIMIT 1),
                'null'::json
            ) AS community
        FROM entities t
        WHERE t.type = 'TABLE' AND lower(t.name) = '{tn}'
        """

        rows = self._query(sql)
        if not rows:
            return None

        r = rows[0]
        return {
            "table": r["name"],
            "description": r.get("description", ""),
            "properties": r.get("properties", {}),
            "columns": r.get("columns", []),
            "joins": r.get("joins", []),
            "community": r.get("community"),
        }

    # ═════════════════════════════════════════════════════════════════
    #  JOIN PATH (same interface as CleanGraphRAG)
    # ═════════════════════════════════════════════════════════════════

    def get_join_path(self, from_table, to_table):
        """Find join path between two tables via SQL."""
        ft = self._sql_escape(from_table.lower())
        tt = self._sql_escape(to_table.lower())

        # Check both directions for direct join
        sql = f"""
        SELECT r.type, r.description, r.properties,
               s.name AS source_name, t.name AS target_name
        FROM relationships r
        JOIN entities s ON r.source_id = s.entity_id
        JOIN entities t ON r.target_id = t.entity_id
        WHERE r.type = 'JOINS_TO' AND s.type = 'TABLE' AND t.type = 'TABLE'
        AND (
            (lower(s.name) = '{ft}' AND lower(t.name) = '{tt}')
            OR
            (lower(s.name) = '{tt}' AND lower(t.name) = '{ft}')
        )
        LIMIT 1
        """

        rows = self._query(sql)
        if rows:
            r = rows[0]
            props = r.get("properties", {}) or {}
            return {
                "from": from_table,
                "to": to_table,
                "direct": True,
                "join_keys": props.get("join_keys", []),
                "cardinality": props.get("cardinality", ""),
                "description": r.get("description", ""),
            }

        # Check query_paths for multi-hop
        sql = f"""
        SELECT need, joins FROM query_paths WHERE lower(start_table) = '{ft}'
        """

        rows = self._query(sql)
        for r in rows:
            joins = r.get("joins", []) or []
            for j in joins:
                if j.get("to", "").lower() == to_table.lower():
                    return {
                        "from": from_table,
                        "to": to_table,
                        "direct": False,
                        "join_keys": j.get("on", []),
                        "via_query_path": r.get("need", ""),
                    }

        return {
            "from": from_table,
            "to": to_table,
            "direct": False,
            "join_keys": [],
            "note": "No direct join found. Use uid and shard_hint as common keys.",
        }

    # ═════════════════════════════════════════════════════════════════
    #  BATCH METHODS (avoid N separate docker exec calls)
    # ═════════════════════════════════════════════════════════════════

    def get_table_contexts_batch(self, table_names):
        """Get full table context for multiple tables in ONE query.
        Returns: {table_name: context_dict}
        """
        if not table_names:
            return {}
        names_lower = [self._sql_escape(t.lower()) for t in table_names]
        name_list = ",".join(f"'{n}'" for n in names_lower)

        sql = f"""
        SELECT
            t.name, t.description, t.properties,
            COALESCE(
                (SELECT json_agg(json_build_object(
                    'name', c.name,
                    'description', c.description,
                    'properties', c.properties
                ) ORDER BY c.name)
                FROM entities c
                JOIN relationships r ON r.target_id = c.entity_id
                WHERE r.source_id = t.entity_id AND r.type = 'HAS_COLUMN'),
                '[]'::json
            ) AS columns,
            COALESCE(
                (SELECT json_agg(json_build_object(
                    'target_table', t2.name,
                    'relationship', r.type,
                    'description', r.description,
                    'properties', r.properties
                ))
                FROM relationships r
                JOIN entities t2 ON r.target_id = t2.entity_id
                WHERE r.source_id = t.entity_id AND r.type = 'JOINS_TO'
                  AND t2.type = 'TABLE'),
                '[]'::json
            ) AS joins,
            COALESCE(
                (SELECT json_build_object(
                    'id', c.community_id, 'title', c.title
                )
                FROM communities c
                WHERE t.entity_id = ANY(c.entity_ids)
                LIMIT 1),
                'null'::json
            ) AS community
        FROM entities t
        WHERE t.type = 'TABLE' AND lower(t.name) IN ({name_list})
        """

        rows = self._query(sql)
        result = {}
        for r in rows:
            result[r["name"]] = {
                "table": r["name"],
                "description": r.get("description", ""),
                "properties": r.get("properties", {}),
                "columns": r.get("columns", []),
                "joins": r.get("joins", []),
                "community": r.get("community"),
            }
        return result

    def get_join_paths_batch(self, table_pairs):
        """Get join paths for multiple table pairs in ONE query.
        Input: [(from_table, to_table), ...]
        Returns: {(from, to): join_path_dict}
        """
        if not table_pairs:
            return {}

        # Collect all unique table names
        all_tables = set()
        for t1, t2 in table_pairs:
            all_tables.add(t1.lower())
            all_tables.add(t2.lower())
        name_list = ",".join(f"'{self._sql_escape(t)}'" for t in all_tables)

        # Single query: get all JOINS_TO relationships between these tables
        sql = f"""
        SELECT r.type, r.description, r.properties,
               s.name AS source_name, t.name AS target_name
        FROM relationships r
        JOIN entities s ON r.source_id = s.entity_id
        JOIN entities t ON r.target_id = t.entity_id
        WHERE r.type = 'JOINS_TO' AND s.type = 'TABLE' AND t.type = 'TABLE'
        AND lower(s.name) IN ({name_list})
        AND lower(t.name) IN ({name_list})
        """
        rows = self._query(sql)

        # Build a lookup: (source, target) → relationship
        rel_lookup = {}
        for r in rows:
            src = r.get("source_name", "")
            tgt = r.get("target_name", "")
            props = r.get("properties", {}) or {}
            rel_lookup[(src.lower(), tgt.lower())] = {
                "type": r.get("type", ""),
                "description": r.get("description", ""),
                "join_keys": props.get("join_keys", []),
                "cardinality": props.get("cardinality", ""),
            }

        # Also check query_paths for multi-hop (single query for all)
        sql2 = f"""
        SELECT need, joins, start_table FROM query_paths
        WHERE lower(start_table) IN ({name_list})
        """
        qp_rows = self._query(sql2)

        # Build query_paths lookup: start_table → [{to, on}]
        qp_lookup = {}
        for r in qp_rows:
            start = r.get("start_table", "").lower()
            joins = r.get("joins", []) or []
            qp_lookup.setdefault(start, []).append({
                "need": r.get("need", ""),
                "joins": joins,
            })

        # Now resolve each pair
        result = {}
        for from_table, to_table in table_pairs:
            ft = from_table.lower()
            tt = to_table.lower()
            key = (from_table, to_table)

            # Check direct join (both directions)
            direct = rel_lookup.get((ft, tt)) or rel_lookup.get((tt, ft))
            if direct:
                result[key] = {
                    "from": from_table,
                    "to": to_table,
                    "direct": True,
                    "join_keys": direct["join_keys"],
                    "cardinality": direct.get("cardinality", ""),
                    "description": direct.get("description", ""),
                }
                continue

            # Check query_paths for multi-hop
            found = False
            for qp in qp_lookup.get(ft, []):
                for j in qp.get("joins", []):
                    if j.get("to", "").lower() == tt:
                        result[key] = {
                            "from": from_table,
                            "to": to_table,
                            "direct": False,
                            "join_keys": j.get("on", []),
                            "via_query_path": qp.get("need", ""),
                        }
                        found = True
                        break
                if found:
                    break

            if not found:
                result[key] = {
                    "from": from_table,
                    "to": to_table,
                    "direct": False,
                    "join_keys": [],
                    "note": "No direct join found. Use uid and shard_hint as common keys.",
                }

        return result

    def vector_search(self, embedding, top_k=10):
        """
        Search by vector similarity (requires embeddings to be populated).

        Args:
            embedding: list of floats (768-dim) — from an embedding model
            top_k: number of results

        Returns:
            List of entities sorted by cosine similarity.

        Usage (when you have an embedding model):
            embedding = embed("is the person still alive")
            results = retriever.vector_search(embedding, top_k=10)
        """
        vec_str = "[" + ",".join(str(float(x)) for x in embedding) + "]"

        sql = f"""
        SELECT entity_id, name, type, description, properties,
               1 - (embedding <=> '{vec_str}'::vector) AS similarity
        FROM entities
        WHERE embedding IS NOT NULL
        ORDER BY embedding <=> '{vec_str}'::vector
        LIMIT {int(top_k)}
        """

        rows = self._query(sql)

        return [{
            "entity_id": r["entity_id"],
            "name": r["name"],
            "type": r["type"],
            "score": float(r.get("similarity", 0)),
            "description": r.get("description", ""),
            "properties": r.get("properties", {}),
        } for r in rows]

    # ═════════════════════════════════════════════════════════════════
    #  HYBRID SEARCH (text + vector, for future use)
    # ═════════════════════════════════════════════════════════════════

    def hybrid_search(self, query, embedding=None, top_k=10, use_llm_rerank=False, llm_top_k=5):
        """
        Combine full-text search + vector search (when embeddings available).

        If no embedding is provided, falls back to full-text search only.
        If embedding is provided, merges text + vector results using reciprocal rank fusion.
        """
        if embedding is None:
            return self.search(query, mode="hybrid", top_k=top_k,
                             use_llm_rerank=use_llm_rerank, llm_top_k=llm_top_k)

        # Get text results
        text_results = self._local_search(query, top_k=top_k * 2)

        # Get vector results
        vec_results = self.vector_search(embedding, top_k=top_k * 2)

        # Reciprocal Rank Fusion
        rrf_k = 60
        scores = {}

        for rank, r in enumerate(text_results):
            eid = r["entity_id"]
            scores[eid] = scores.get(eid, {"entity": r, "score": 0})
            scores[eid]["score"] += 1.0 / (rrf_k + rank + 1)

        for rank, r in enumerate(vec_results):
            eid = r["entity_id"]
            if eid not in scores:
                scores[eid] = {"entity": r, "score": 0}
            scores[eid]["score"] += 1.0 / (rrf_k + rank + 1)

        # Sort by fused score
        merged = sorted(scores.values(), key=lambda x: x["score"], reverse=True)

        results = []
        for item in merged[:top_k]:
            entity = item["entity"]
            entity["score"] = round(item["score"], 4)
            results.append(entity)

        return {"query": query, "mode": "hybrid", "local_results": results,
                "global_results": self._global_search(query, top_k=3),
                "llm_reranked": False}
