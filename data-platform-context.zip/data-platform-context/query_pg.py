import subprocess, os

CONTAINER = "graphrag-postgres"
DB_USER = "graphrag"
DB_NAME = "graphrag"
TEMP_DIR = os.path.join(os.environ.get("TEMP", "/tmp"), "opencode")

sql_path = os.path.join(TEMP_DIR, "migrate_columns.sql")
subprocess.run(["docker", "cp", sql_path, f"{CONTAINER}:/tmp/migrate_columns.sql"], capture_output=True)
r = subprocess.run(
    ["docker", "exec", CONTAINER, "psql", "-U", DB_USER, "-d", DB_NAME,
     "-v", "ON_ERROR_STOP=1", "-f", "/tmp/migrate_columns.sql"],
    capture_output=True, text=True, encoding="utf-8",
)
print("STDERR (last 1500 chars):")
print(r.stderr[-1500:] if r.stderr else "(empty)")
