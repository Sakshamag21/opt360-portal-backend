# Table: flink_stream.stream_enu.telemetry_uc

## Overview

| Property | Value |
|----------|-------|
| **Catalog** | `flink_stream` |
| **Schema** | `stream_enu` |
| **Table** | `telemetry_uc` |
| **Full Reference** | `flink_stream.stream_enu.telemetry_uc` |
| **Row Count** | ~295M (295,078,178) |
| **Columns** | 19 |
| **Date Range** | 2025-01-01 → present (near-real-time) |
| **Source** | Flink streaming pipeline |
| **Access** | Read-only via Trino at `10.10.116.39:8080` |

## Description

Telemetry and error-logging table for the Aadhaar **Update Client (UC)** desktop application. Each row is a telemetry event (`ERROR` or `DEBUG`) emitted by the enrolment/update client software. Captures exceptions, stacktraces, operator/device context, and client version info.

This is **application-level telemetry** — it tracks client software errors and debug events, not enrolment data. It complements `enu_uc_opt_action_v2` (which tracks workflow stage events).

## Column Dictionary (19 columns)

### Event Identity

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `eid` | varchar | Event UUID | Always populated. Primary key |
| `mid` | varchar | Message UUID | Always populated. Groups related events |
| `ets` | timestamp(6) | Event timestamp | **Primary filter column**. 2025–present |
| `ver` | varchar | Telemetry schema version | Always `3.0` |
| `type` | varchar | Event type | `ERROR` (57%), `DEBUG` (42%), NULL (0.6%) |

### Actor / Operator

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `actor_id` | varchar | Operator login ID | NULL ~32%. Format: `UIDN0518389` |
| `actor_type` | varchar | Actor type | `OPERATOR` (68%) or NULL (32%) |
| `sid` | varchar | Session ID | NULL ~33%. Format: `S<timestamp>` |

### Device / Environment

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `did` | varchar | Device ID | ~100% NULL (deprecated) |
| `pdata_id` | varchar | Hardware device ID | ~100% populated. `<mfr>.<UUID>` |
| `pdata_version` | varchar | Client build version | Always populated. `3.3.4.2.<build>-...` |
| `platform` | varchar | OS details (free-text) | Always populated. Windows 10/11 info |
| `channel` | varchar | Network interface | `wlan2 - Wi-Fi`, `eth2 - LAN` etc. |
| `env` | varchar | Environment | `Prod` (99.998%), `dev` |
| `pid` | varchar | Process/Production ID | ~100% NULL (deprecated) |

### Error Details

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `error` | varchar | Error message text | NULL ~43%. Can be JSON or plain text |
| `error_type` | varchar | Error type code | NULL ~43%. `UC-GEN-146`, `UOS-GEN-101` etc. |
| `stacktrace` | varchar | Full Java stacktrace | NULL ~42%. **Very long text — never SELECT without LIMIT** |
| `message` | varchar | Additional message | NULL ~58% |

## type Values

| Value | Count | % | Meaning |
|-------|-------|---|---------|
| `ERROR` | 169M | 57.2% | Error event — exception/failure occurred |
| `DEBUG` | 124M | 42.2% | Debug event — diagnostic info |
| `NULL` | 1.9M | 0.6% | Unspecified |

## error_type Values (Top 20)

| Code | Count | Meaning |
|------|-------|---------|
| `NULL` | 126M | No error (DEBUG events) |
| `UC-GEN-146` | 109M | "no such context in list" (HTTP server context issue) |
| `UC-GEN-190` | 17M | General error |
| `UOS-GEN-101` | 5.6M | Backend gRPC SystemError — key/token fetch failure |
| `UC-GEN-196` | 3.5M | Security error — security requirements not met |
| `UC-GEN-112` | 3.4M | General error |
| `UC-GEN-197` | 2.8M | General error |
| `UC_PAC_002` | 2.5M | PAC code error |
| `UC-GRPC-DEADLINE_EXCEEDED` | 2.3M | gRPC timeout |
| `UC-GRPC-UNAVAILABLE` | 2.1M | gRPC server unavailable |
| `UOS-AUTH-102` | 2.1M | Authentication error |
| `UOS-BPR-101` | 2.0M | BPR (Biometric Participant Registry) error |
| `UC-MOB-001` | 1.8M | "Entered same mobile number for mobile update" |
| `UC-GEN-008` | 1.7M | General error |
| `UC-VAL-004` | 1.3M | Validation error |
| `UC-OTP-006` | 1.1M | OTP error |
| `UC-VAL-001` | 823K | Validation error |
| `300` | 704K | HTTP-style error code |
| `BMS-REQ-201` | 660K | Biometric service request error |
| `UC-GRPC-INTERNAL` | 626K | gRPC internal error |

**Error type prefix convention:**
- `UC-*` = Update Client errors
- `UOS-*` = Update Online Services (backend) errors
- `UC-GRPC-*` = gRPC communication errors
- `UC-MOB-*` = Mobile-related errors
- `UC-OTP-*` = OTP errors
- `UC-VAL-*` = Validation errors
- `UC-PAC-*` / `UC_PAC_*` = PAC code errors
- `BMS-*` = Biometric service errors

## Querying Guidance

1. **No `shard_hint`** — use `ets` for partition pruning
2. **Always add LIMIT** — 295M rows
3. **Filter ets anomalies** — add `AND ets >= TIMESTAMP '2024-01-01'` (~29 rows have anomalous years 2017, 2027–2165)
4. **NEVER SELECT stacktrace without LIMIT** — contains very long Java stacktrace text. Use `substr(stacktrace, 1, 500)` for preview
5. **Filter by `type='ERROR'`** to focus on errors (excludes DEBUG)
6. **`error_type` is NULL for DEBUG events** — pair with `type='ERROR'` or check NULL
7. **`platform` is free-text** — use `LIKE '%Windows 11%'` or `LIKE '%Windows 10%'` for grouping
8. **Counting events** — `count(DISTINCT eid)` (eid can appear on multiple rows)
9. **Counting operators** — `count(DISTINCT actor_id)` (NULL for ~32% of rows)
10. **No resident PII** — only operator login IDs (not encrypted)

## Example Queries

### Top errors in last 7 days

```sql
SELECT error_type, count(*) AS cnt
FROM flink_stream.stream_enu.telemetry_uc
WHERE ets >= current_date - interval '7' day
  AND ets >= TIMESTAMP '2024-01-01'
  AND type = 'ERROR'
GROUP BY error_type
ORDER BY cnt DESC
LIMIT 20
```

### Error count by client version (last 1 month)

```sql
SELECT pdata_version, count(*) AS error_count
FROM flink_stream.stream_enu.telemetry_uc
WHERE ets >= current_date - interval '1' month
  AND type = 'ERROR'
GROUP BY pdata_version
ORDER BY error_count DESC
LIMIT 20
```

### Errors by operator (last 1 day)

```sql
SELECT actor_id, error_type, count(*) AS cnt
FROM flink_stream.stream_enu.telemetry_uc
WHERE ets >= current_date - interval '1' day
  AND type = 'ERROR'
  AND actor_id IS NOT NULL
GROUP BY actor_id, error_type
ORDER BY cnt DESC
LIMIT 100
```

### Error trend by day

```sql
SELECT date(ets) AS event_date, count(*) AS error_count
FROM flink_stream.stream_enu.telemetry_uc
WHERE ets >= current_date - interval '30' day
  AND type = 'ERROR'
GROUP BY date(ets)
ORDER BY event_date DESC
LIMIT 100
```

### Preview a specific error's stacktrace

```sql
SELECT eid, error_type, error, substr(stacktrace, 1, 500) AS stacktrace_preview
FROM flink_stream.stream_enu.telemetry_uc
WHERE error_type = 'UC-GEN-196'
  AND ets >= current_date - interval '1' day
LIMIT 10
```
