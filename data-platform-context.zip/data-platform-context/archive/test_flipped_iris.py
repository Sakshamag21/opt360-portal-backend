#!/usr/bin/env python3
"""
Test: 'Give me all the UIDs in last one week which have flipped iris in the manual fraud check'
"""

import time, requests, json

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, timeout=300):
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "test-query",
    }
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        return result

    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    query_id = result.get("id", "")

    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.3)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
        attempts += 1

    col_names = [c.get("name", f"col_{i}") for i, c in enumerate(columns)] if columns else []
    return {"columns": col_names, "rows": all_data, "row_count": len(all_data), "query_id": query_id}


# ─── Query: UIDs with flipped iris in BFC fraud check, last 1 week ───────────
# From the graph:
#   - enu_bfc_analytics_raw_v1.modality = 'IRIS' (iris capture)
#   - enu_bfc_analytics_raw_v1.errorreasoncode = 'FLIPPED' (flipped image)
#   - enu_bfc_analytics_raw_v1.haserror = true (error/anomaly detected)
#   - enu_bfc_analytics_raw_v1.eventtimestamp (time filter)
#   - enu_bfc_analytics_raw_v1.operatorid (operator who performed the check)
#   - enu_bfc_analytics_raw_v1.modelname = 'UNSYSTEMATIC_MANUAL_CHECK' (manual fraud check)
#
# This table has operatorid but NOT resident_uid. To get UIDs we need to join
# to enu_uc_opt_action_v2 via session_id/sid, which has resident_uid.

sql = """
SELECT
    b.eventtimestamp,
    b.sid,
    b.modality,
    b.modelname,
    b.errorreasoncode,
    b.operatorid,
    b.machinecode,
    a.resident_uid,
    a.operator_id,
    a.stage,
    a.event_timestamp AS session_event_time
FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1 b
LEFT JOIN flink_stream.stream_enu.enu_uc_opt_action_v2 a
    ON a.session_id = b.sid
    AND a.resident_uid IS NOT NULL
WHERE b.modality = 'IRIS'
  AND b.errorreasoncode = 'FLIPPED'
  AND b.haserror = true
  AND b.modelname = 'UNSYSTEMATIC_MANUAL_CHECK'
  AND b.eventtimestamp >= current_date - interval '7' day
ORDER BY b.eventtimestamp DESC
LIMIT 20
"""

print("=" * 70)
print("Query: UIDs with flipped iris in manual fraud check (last 1 week)")
print("=" * 70)
print(f"SQL:\n{sql}\n")

start = time.time()
result = trino_query(sql)
elapsed = round(time.time() - start, 2)

if "error" in result:
    print(f"ERROR: {result['error'].get('message', result['error'])}")
else:
    cols = result.get("columns", [])
    rows = result.get("rows", [])
    print(f"Rows: {result.get('row_count', 0)} | Query ID: {result.get('query_id', 'N/A')} | Time: {elapsed}s")
    print(f"Columns: {', '.join(cols)}\n")

    if rows:
        # Print as table
        print(f"{'eventtimestamp':<26} {'sid':<22} {'errorreasoncode':<12} {'resident_uid':<14} {'operator_id':<25} {'stage'}")
        print("-" * 120)
        for row in rows:
            ts = str(row[0] or '')[:25]
            sid = str(row[1] or '')[:21]
            reason = str(row[3] or '')[:11]  # modelname
            err = str(row[4] or '')[:11]
            uid = str(row[7] or 'NULL')
            op = str(row[8] or '')[:24]
            stage = str(row[9] or '')[:20]
            print(f"{ts:<26} {sid:<22} {err:<12} {uid:<14} {op:<25} {stage}")
    else:
        print("No rows returned.")

print(f"\nTotal time: {elapsed}s")
