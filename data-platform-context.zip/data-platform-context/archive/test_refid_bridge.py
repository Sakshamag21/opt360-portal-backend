#!/usr/bin/env python3
"""
Test the refid bridge: BFC.refid -> uid_origin_tracker_enriched.refid -> UID
Also test: BFC.refid -> opt_action.session_id (with uc- prefix) -> resident_uid
"""

import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, timeout=300):
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "bridge-test",
    }
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        return result
    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    query_id = result.get("id", "")
    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.3)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
        attempts += 1
    col_names = [c.get("name", f"col_{i}") for i, c in enumerate(columns)] if columns else []
    return {"columns": col_names, "rows": all_data, "row_count": len(all_data), "query_id": query_id}

def show(label, result, max_rows=10):
    print("=" * 70)
    print(label)
    print("=" * 70)
    if "error" in result:
        print(f"  ERROR: {result['error'].get('message', result['error'])}\n")
        return
    cols = result.get("columns", [])
    rows = result.get("rows", [])
    print(f"  Rows: {result.get('row_count', 0)} | query_id={result.get('query_id', 'N/A')}")
    if cols:
        print(f"  Cols: {', '.join(cols)}")
    for row in rows[:max_rows]:
        print(f"    {row}")
    print()


# ─── 1. Search uid_origin_tracker_enriched by BFC refid ──────────────────────
# refid from BFC: 2e70f4f8-00e7-4623-a493-216ff44822aa (operator K1_CAMP_GBA_413)
show("1. uid_origin_tracker_enriched WHERE refid = BFC refid", trino_query("""
    SELECT uid, refid, eid, enr_date, operator_id, registrar_code, ea_code
    FROM strot.mysql_uid_v2.uid_origin_tracker_enriched
    WHERE refid = '2e70f4f8-00e7-4623-a493-216ff44822aa'
    LIMIT 5
"""))

# ─── 2. Search opt_action by BFC refid (with uc- prefix) ─────────────────────
show("2. opt_action WHERE session_id = 'uc-' + BFC refid", trino_query("""
    SELECT session_id, operator_id, resident_uid, stage, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE session_id = 'uc-2e70f4f8-00e7-4623-a493-216ff44822aa'
    LIMIT 10
"""))

# ─── 3. THE FULL QUERY: BFC flipped iris -> uid_origin_tracker -> UID ────────
show("3. FULL QUERY: Flipped iris UIDs (last 1 week) via refid bridge", trino_query("""
    SELECT
        b.eventtimestamp,
        b.sid,
        b.refid,
        b.operatorid,
        b.machinecode,
        b.modality,
        b.errorreasoncode,
        b.modelname,
        t.uid AS encrypted_uid,
        t.eid AS enrolment_id,
        t.operator_id,
        t.registrar_code,
        t.ea_code,
        t.enr_date
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1 b
    JOIN strot.mysql_uid_v2.uid_origin_tracker_enriched t
      ON t.refid = b.refid
    WHERE b.modality = 'IRIS'
      AND b.errorreasoncode = 'FLIPPED'
      AND b.haserror = true
      AND b.modelname = 'UNSYSTEMATIC_MANUAL_CHECK'
      AND b.eventtimestamp >= current_date - interval '7' day
    ORDER BY b.eventtimestamp DESC
    LIMIT 20
"""))

# ─── 4. Count total flipped iris events in last week (with and without UID) ──
show("4. Count: flipped iris events vs. those with a matching UID", trino_query("""
    SELECT
        count(*) AS total_flipped_iris,
        count(t.uid) AS with_uid
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1 b
    LEFT JOIN strot.mysql_uid_v2.uid_origin_tracker_enriched t
      ON t.refid = b.refid
    WHERE b.modality = 'IRIS'
      AND b.errorreasoncode = 'FLIPPED'
      AND b.haserror = true
      AND b.modelname = 'UNSYSTEMATIC_MANUAL_CHECK'
      AND b.eventtimestamp >= current_date - interval '7' day
"""))

# ─── 5. Also try: BFC -> opt_action via refid = REPLACE(session_id, 'uc-', '') ─
show("5. BFC -> opt_action via refid = REPLACE(session_id,'uc-','')", trino_query("""
    SELECT
        b.eventtimestamp,
        b.refid,
        b.operatorid,
        a.resident_uid,
        a.operator_id,
        a.stage,
        a.event_timestamp
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1 b
    JOIN flink_stream.stream_enu.enu_uc_opt_action_v2 a
      ON a.session_id = CONCAT('uc-', b.refid)
    WHERE b.modality = 'IRIS'
      AND b.errorreasoncode = 'FLIPPED'
      AND b.haserror = true
      AND b.eventtimestamp >= current_date - interval '7' day
      AND a.resident_uid IS NOT NULL
    ORDER BY b.eventtimestamp DESC
    LIMIT 20
"""))
