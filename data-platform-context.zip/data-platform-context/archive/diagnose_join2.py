#!/usr/bin/env python3
"""
Find the correct join path between BFC flipped-iris events and resident UIDs.
"""

import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, timeout=300):
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "diagnose2",
    }
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        return result
    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    query_id = result.get("id", "")
    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.3)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
        attempts += 1
    col_names = [c.get("name", f"col_{i}") for i, c in enumerate(columns)] if columns else []
    return {"columns": col_names, "rows": all_data, "row_count": len(all_data), "query_id": query_id}

def show(label, result, max_rows=8):
    print("=" * 70)
    print(label)
    print("=" * 70)
    if "error" in result:
        print(f"  ERROR: {result['error'].get('message', result['error'])}\n")
        return
    cols = result.get("columns", [])
    rows = result.get("rows", [])
    print(f"  Rows: {result.get('row_count', 0)} | query_id={result.get('query_id', 'N/A')}")
    if cols:
        print(f"  Cols: {', '.join(cols)}")
    for row in rows[:max_rows]:
        print(f"    {row}")
    print()


# ─── 1. opt_action full column list (use flink_stream catalog) ───────────────
show("1. opt_action columns (flink_stream.information_schema)", trino_query("""
    SELECT column_name, data_type
    FROM flink_stream.information_schema.columns
    WHERE table_schema = 'stream_enu'
      AND table_name = 'enu_uc_opt_action_v2'
    ORDER BY ordinal_position
"""))

# ─── 2. BFC full column list ─────────────────────────────────────────────────
show("2. BFC columns", trino_query("""
    SELECT column_name, data_type
    FROM flink_stream.information_schema.columns
    WHERE table_schema = 'stream_enu'
      AND table_name = 'enu_bfc_analytics_raw_v1'
    ORDER BY ordinal_position
"""))

# ─── 3. opt_action sample with all key columns ───────────────────────────────
show("3. opt_action sample (with machine_id, operator_id, resident_uid)", trino_query("""
    SELECT session_id, machine_id, operator_id, operator_uid, resident_uid,
           stage, stage_status, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE event_timestamp >= current_date - interval '1' day
      AND resident_uid IS NOT NULL
    LIMIT 5
"""))

# ─── 4. BFC sample with operatorid, machinecode ──────────────────────────────
show("4. BFC sample (flipped iris, with operatorid, machinecode)", trino_query("""
    SELECT sid, operatorid, machinecode, modality, errorreasoncode, eventtimestamp
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
    WHERE modality = 'IRIS'
      AND errorreasoncode = 'FLIPPED'
      AND haserror = true
      AND eventtimestamp >= current_date - interval '1' day
    LIMIT 5
"""))

# ─── 5. Try join on operatorid = operator_id AND machinecode = machine_id ────
#       with a time window
show("5. Join on operator+machine+time window (5 min)", trino_query("""
    SELECT DISTINCT
        b.eventtimestamp AS bfc_time,
        b.sid,
        b.operatorid,
        b.machinecode,
        a.resident_uid,
        a.operator_id,
        a.machine_id,
        a.stage,
        a.event_timestamp AS action_time
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1 b
    JOIN flink_stream.stream_enu.enu_uc_opt_action_v2 a
      ON a.operator_id = b.operatorid
     AND a.machine_id = b.machinecode
     AND a.event_timestamp BETWEEN b.eventtimestamp - interval '10' minute
                               AND b.eventtimestamp + interval '10' minute
    WHERE b.modality = 'IRIS'
      AND b.errorreasoncode = 'FLIPPED'
      AND b.haserror = true
      AND b.eventtimestamp >= current_date - interval '2' day
      AND a.resident_uid IS NOT NULL
    ORDER BY b.eventtimestamp DESC
    LIMIT 10
"""))
