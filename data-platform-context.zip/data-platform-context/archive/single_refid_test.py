#!/usr/bin/env python3
"""Test: look up a SINGLE refid in uid_origin_tracker_enriched"""
import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, label=""):
    headers = {"Content-Type": "text/plain", "X-Trino-User": TRINO_USER, "X-Trino-Source": "single"}
    print(f"[{label}] start...")
    start = time.time()
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        print(f"[{label}] ERROR: {str(result['error'])[:300]}")
        return None
    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    qid = result.get("id", "")
    state = result.get("stats", {}).get("state", "")
    print(f"[{label}] qid={qid}, initial state={state}")
    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.5)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        attempts += 1
        if attempts % 40 == 0:
            print(f"[{label}] still {state}... {round(time.time()-start,1)}s, rows={len(all_data)}")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
    elapsed = round(time.time() - start, 2)
    cols = [c.get("name", "") for c in columns] if columns else []
    print(f"[{label}] DONE: {state}, rows={len(all_data)}, {elapsed}s")
    return {"columns": cols, "rows": all_data, "query_id": qid, "state": state, "elapsed": elapsed}


# Test 1: single refid (from BFC flipped iris event)
# refid = 6012086f-5550-421b-834d-1b46e4916aa0 (operator PRO032_45, 2026-10-19 17:49)
r = trino_query("""
    SELECT uid, refid, eid, enr_date, operator_id, registrar_code, ea_code
    FROM strot.mysql_uid_v2.uid_origin_tracker_enriched
    WHERE refid = '6012086f-5550-421b-834d-1b46e4916aa0'
    LIMIT 5
""", "single-refid")
if r and r["rows"]:
    for row in r["rows"]:
        print(f"  {row}")
else:
    print("  No rows or error")
print()

# Test 2: single refid via opt_action (session_id = 'uc-' + refid)
r = trino_query("""
    SELECT session_id, resident_uid, operator_id, stage, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE session_id = 'uc-6012086f-5550-421b-834d-1b46e4916aa0'
    LIMIT 5
""", "single-optaction")
if r and r["rows"]:
    for row in r["rows"]:
        print(f"  {row}")
else:
    print("  No rows or error")
