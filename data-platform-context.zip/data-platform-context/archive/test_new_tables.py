#!/usr/bin/env python3
"""
Test queries on the newly migrated flink_stream and station_reg_helper tables.
1. Search the GraphRAG graph for columns in these tables
2. Run Trino queries that return UID-related data
"""

import json, subprocess, os, time, requests

# ─── Config ────────────────────────────────────────────────────────────────────
CONTAINER = "graphrag-postgres"
DB_USER = "graphrag"
DB_NAME = "graphrag"
TEMP_DIR = os.path.join(os.environ.get("TEMP", "/tmp"), "opencode")
os.makedirs(TEMP_DIR, exist_ok=True)

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"


# ─── GraphRAG query ────────────────────────────────────────────────────────────
def graph_query(sql):
    json_sql = f"SELECT coalesce(json_agg(row_to_json(t)), '[]'::json) FROM ({sql}) t;"
    tmp = os.path.join(TEMP_DIR, "q.sql")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(json_sql)
    subprocess.run(["docker", "cp", tmp, f"{CONTAINER}:/tmp/q.sql"], capture_output=True)
    r = subprocess.run(
        ["docker", "exec", CONTAINER, "psql", "-U", DB_USER, "-d", DB_NAME, "-t", "-A", "-f", "/tmp/q.sql"],
        capture_output=True, text=True, encoding="utf-8",
    )
    out = r.stdout.strip()
    return json.loads(out) if out and out != "null" else []


# ─── Trino query ───────────────────────────────────────────────────────────────
def trino_query(sql, timeout=120):
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "test-queries",
    }
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        return {"error": result["error"]}

    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])

    query_id = result.get("id", "")
    attempts = 0
    while result.get("nextUri") and attempts < 500:
        time.sleep(0.3)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
        attempts += 1

    col_names = [c.get("name", f"col_{i}") for i, c in enumerate(columns)] if columns else []
    return {"columns": col_names, "rows": all_data, "row_count": len(all_data), "query_id": query_id}


def print_trino_result(result, max_rows=10):
    if "error" in result:
        print(f"  ERROR: {result['error'].get('message', result['error'])}")
        return
    cols = result.get("columns", [])
    rows = result.get("rows", [])
    print(f"  Rows: {result.get('row_count', 0)} | Query ID: {result.get('query_id', 'N/A')}")
    if cols:
        print(f"  Columns: {', '.join(cols)}")
    if rows:
        print(f"  First {min(len(rows), max_rows)} rows:")
        for row in rows[:max_rows]:
            # Truncate long values
            display = [str(v)[:60] if v else str(v) for v in row]
            print(f"    {display}")
    print()


# ═══════════════════════════════════════════════════════════════
#  1. GRAPH SEARCH — verify new columns are findable
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("1. GRAPH SEARCH: Search for 'operator uid' in the graph")
print("=" * 70)
results = graph_query("""
    SELECT entity_id, name, type, description,
           ROUND(ts_rank(tsv, websearch_to_tsquery('english', 'operator uid'))::numeric, 4) AS score
    FROM entities
    WHERE tsv @@ websearch_to_tsquery('english', 'operator uid')
    ORDER BY score DESC
    LIMIT 10
""")
for r in results:
    print(f"  [{r['type']}] {r['name']} (score: {r.get('score', '?')})")
    print(f"    {(r.get('description') or '')[:150]}")
    print()

print("\n" + "=" * 70)
print("2. GRAPH SEARCH: Search for 'resident uid encrypted' in the graph")
print("=" * 70)
results = graph_query("""
    SELECT entity_id, name, type, description,
           ROUND(ts_rank(tsv, websearch_to_tsquery('english', 'resident uid encrypted'))::numeric, 4) AS score
    FROM entities
    WHERE tsv @@ websearch_to_tsquery('english', 'resident uid encrypted')
    ORDER BY score DESC
    LIMIT 10
""")
for r in results:
    print(f"  [{r['type']}] {r['name']} (score: {r.get('score', '?')})")
    print(f"    {(r.get('description') or '')[:150]}")
    print()

print("\n" + "=" * 70)
print("3. GRAPH: All UID-related columns in flink_stream tables")
print("=" * 70)
results = graph_query("""
    SELECT e.name, e.description, e.properties->>'data_type' AS data_type,
           e.properties->>'importance' AS importance
    FROM entities e
    WHERE e.type = 'COLUMN'
      AND (e.name LIKE '%uid%' OR e.search_text ILIKE '%uid%')
      AND (e.name LIKE 'enu_%' OR e.name LIKE 'telemetry%' OR e.name LIKE 'station%')
    ORDER BY e.name
""")
for r in results:
    print(f"  {r['name']:<50} {r.get('data_type', '?'):<15} [{r.get('importance', '?')}]")
    print(f"    {(r.get('description') or '')[:150]}")
    print()


# ═══════════════════════════════════════════════════════════════
#  4. TRINO QUERY — resident_uid from enu_uc_opt_action_v2
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("4. TRINO: Sample resident_uids from enu_uc_opt_action_v2")
print("=" * 70)
result = trino_query("""
    SELECT resident_uid, operator_id, stage, stage_status, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE resident_uid IS NOT NULL
    ORDER BY event_timestamp DESC
    LIMIT 5
""")
print_trino_result(result)


# ═══════════════════════════════════════════════════════════════
#  5. TRINO QUERY — operator_uid from enu_uc_opt_action_v2
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("5. TRINO: Sample operator_uids from enu_uc_opt_action_v2")
print("=" * 70)
result = trino_query("""
    SELECT operator_uid, operator_id, operator_name, stage, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE operator_uid IS NOT NULL
    ORDER BY event_timestamp DESC
    LIMIT 5
""")
print_trino_result(result)


# ═══════════════════════════════════════════════════════════════
#  6. TRINO QUERY — hof_uid (Head of Family UID)
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("6. TRINO: Sample hof_uids (Head of Family) from enu_uc_opt_action_v2")
print("=" * 70)
result = trino_query("""
    SELECT hof_uid, resident_uid, operator_id, enrolment_type, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE hof_uid IS NOT NULL
    ORDER BY event_timestamp DESC
    LIMIT 5
""")
print_trino_result(result)


# ═══════════════════════════════════════════════════════════════
#  7. TRINO QUERY — Cross-schema: join flink operator_uid with uid_master
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("7. TRINO: Cross-schema join — flink resident_uid to uid_master uid")
print("=" * 70)
result = trino_query("""
    SELECT a.resident_uid, a.operator_id, a.stage, a.event_timestamp,
           b.uid_status_key
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2 a
    JOIN strot.mysql_uid_v2.uid_master b
      ON a.resident_uid = b.uid AND b.shard_hint = '45'
    WHERE a.resident_uid IS NOT NULL
    ORDER BY a.event_timestamp DESC
    LIMIT 5
""")
print_trino_result(result)


# ═══════════════════════════════════════════════════════════════
#  8. TRINO QUERY — station_reg_helper with registrar/EA
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("8. TRINO: Station registration with registrar_id and EA code")
print("=" * 70)
result = trino_query("""
    SELECT machine_id, registrar_id, enrollment_agency_code, station_id, status, is_tpm_present
    FROM mysql_uidmasterv1.uidmasterv1_1.station_reg_helper
    WHERE registrar_id IS NOT NULL
    LIMIT 5
""")
print_trino_result(result)

print("\n" + "=" * 70)
print("ALL TEST QUERIES COMPLETE")
print("=" * 70)
