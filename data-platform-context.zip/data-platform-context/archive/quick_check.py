#!/usr/bin/env python3
"""
Quick check: is Trino responsive? What are the modelname values?
Then run the BFC query step by step.
"""
import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, label="", timeout=180):
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "quick",
    }
    print(f"[{label}] Sending query...")
    start = time.time()
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        print(f"[{label}] ERROR: {result['error'].get('message', '')[:200]}")
        return None

    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    query_id = result.get("id", "")
    state = result.get("stats", {}).get("state", "")
    print(f"[{label}] Initial state: {state}, query_id: {query_id}")

    attempts = 0
    while result.get("nextUri") and attempts < 600:
        time.sleep(0.5)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        attempts += 1
        if attempts % 20 == 0:
            print(f"[{label}] Still running... state={state}, rows so far={len(all_data)}, {round(time.time()-start,1)}s")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break

    elapsed = round(time.time() - start, 2)
    col_names = [c.get("name", f"col_{i}") for i, c in enumerate(columns)] if columns else []
    print(f"[{label}] Done: state={state}, rows={len(all_data)}, time={elapsed}s")
    return {"columns": col_names, "rows": all_data, "row_count": len(all_data),
            "query_id": query_id, "state": state, "elapsed": elapsed}


# 1. Simple responsiveness check
r = trino_query("SELECT 1 AS ping", "ping")
if r:
    print(f"  Result: {r['rows']}\n")

# 2. Distinct modelname values (BFC, last 1 day, to avoid full scan)
r = trino_query("""
    SELECT modelname, count(*) AS cnt
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
    WHERE eventtimestamp >= current_date - interval '1' day
    GROUP BY modelname
    ORDER BY cnt DESC
""", "modelnames")
if r:
    print(f"  Modelname values:")
    for row in r["rows"]:
        print(f"    {row}")
    print()

# 3. BFC flipped iris WITHOUT modelname filter (last 7 days, LIMIT 20) - known to work
r = trino_query("""
    SELECT eventtimestamp, sid, refid, operatorid, machinecode, modelname
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
    WHERE modality = 'IRIS'
      AND errorreasoncode = 'FLIPPED'
      AND haserror = true
      AND eventtimestamp >= current_date - interval '7' day
    ORDER BY eventtimestamp DESC
    LIMIT 20
""", "flipped-no-model-filter")
if r:
    print(f"  Columns: {r['columns']}")
    for row in r["rows"][:5]:
        print(f"    {row}")
    print()

# 4. BFC flipped iris WITH modelname filter (last 7 days, LIMIT 20)
r = trino_query("""
    SELECT eventtimestamp, sid, refid, operatorid, machinecode, modelname
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
    WHERE modality = 'IRIS'
      AND errorreasoncode = 'FLIPPED'
      AND haserror = true
      AND modelname = 'UNSYSTEMATIC_MANUAL_CHECK'
      AND eventtimestamp >= current_date - interval '7' day
    ORDER BY eventtimestamp DESC
    LIMIT 20
""", "flipped-with-model-filter")
if r:
    print(f"  Columns: {r['columns']}")
    for row in r["rows"][:5]:
        print(f"    {row}")
    print()
