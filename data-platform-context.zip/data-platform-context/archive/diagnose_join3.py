#!/usr/bin/env python3
"""
Pinpoint the join: take a specific BFC flipped-iris event and find its
matching opt_action row to retrieve the resident_uid.
"""

import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, timeout=300):
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "diagnose3",
    }
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        return result
    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    query_id = result.get("id", "")
    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.3)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
        attempts += 1
    col_names = [c.get("name", f"col_{i}") for i, c in enumerate(columns)] if columns else []
    return {"columns": col_names, "rows": all_data, "row_count": len(all_data), "query_id": query_id}

def show(label, result, max_rows=8):
    print("=" * 70)
    print(label)
    print("=" * 70)
    if "error" in result:
        print(f"  ERROR: {result['error'].get('message', result['error'])}\n")
        return
    cols = result.get("columns", [])
    rows = result.get("rows", [])
    print(f"  Rows: {result.get('row_count', 0)} | query_id={result.get('query_id', 'N/A')}")
    if cols:
        print(f"  Cols: {', '.join(cols)}")
    for row in rows[:max_rows]:
        print(f"    {row}")
    print()


# ─── 1. Pick a specific BFC event: operatorid=BLS133_015 ─────────────────────
show("1. BFC flipped iris for operator BLS133_015 on 2026-10-19", trino_query("""
    SELECT sid, operatorid, machinecode, modality, errorreasoncode, eventtimestamp
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
    WHERE modality = 'IRIS'
      AND errorreasoncode = 'FLIPPED'
      AND haserror = true
      AND operatorid = 'BLS133_015'
      AND eventtimestamp >= TIMESTAMP '2026-10-19 00:00:00'
    LIMIT 5
"""))

# ─── 2. Find opt_action rows for the same operator on same day ───────────────
show("2. opt_action for operator BLS133_015 on 2026-10-19", trino_query("""
    SELECT session_id, station_machine_code, operator_id, operator_uid,
           resident_uid, stage, stage_status, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE operator_id = 'BLS133_015'
      AND event_timestamp >= TIMESTAMP '2026-10-19 00:00:00'
      AND event_timestamp <  TIMESTAMP '2026-10-20 00:00:00'
    ORDER BY event_timestamp
    LIMIT 20
"""))

# ─── 3. Same operator, last 7 days, with resident_uid ────────────────────────
show("3. opt_action for BLS133_015 with resident_uid (last 7 days)", trino_query("""
    SELECT session_id, station_machine_code, operator_id, resident_uid,
           stage, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE operator_id = 'BLS133_015'
      AND event_timestamp >= current_date - interval '7' day
      AND resident_uid IS NOT NULL
    ORDER BY event_timestamp DESC
    LIMIT 10
"""))

# ─── 4. Check: what's the format of station_machine_code in opt_action? ──────
show("4. opt_action station_machine_code samples", trino_query("""
    SELECT DISTINCT station_machine_code, operator_id
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE operator_id = 'BLS133_015'
      AND event_timestamp >= current_date - interval '7' day
    LIMIT 10
"""))

# ─── 5. Does BFC machinecode match opt_action station_machine_code? ──────────
# BFC machinecode = 'LENOVOE565F535-1E19-F3BF-5BAD-478E5EE96E1C'
show("5. opt_action for machine LENOVOE565F535...", trino_query("""
    SELECT session_id, station_machine_code, operator_id, resident_uid,
           stage, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE station_machine_code = 'LENOVOE565F535-1E19-F3BF-5BAD-478E5EE96E1C'
      AND event_timestamp >= current_date - interval '7' day
    ORDER BY event_timestamp DESC
    LIMIT 10
"""))

# ─── 6. Try: maybe BFC sid is a sub-string of opt_action session_id or vice versa
show("6. opt_action session_id format check", trino_query("""
    SELECT session_id, operator_id, resident_uid, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE event_timestamp >= current_date - interval '1' day
    LIMIT 5
"""))

# ─── 7. Try: opt_action WHERE session_id LIKE BFC sid prefix ─────────────────
show("7. opt_action session_id LIKE 'S1461048062970%'", trino_query("""
    SELECT session_id, station_machine_code, operator_id, resident_uid,
           stage, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE session_id LIKE 'S1461048062970%'
    LIMIT 10
"""))
