#!/usr/bin/env python3
"""
Diagnose the session_id format mismatch between BFC and opt_action tables,
then build a working query for flipped iris UIDs.
"""

import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, timeout=300):
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "diagnose",
    }
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        return result
    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    query_id = result.get("id", "")
    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.3)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
        attempts += 1
    col_names = [c.get("name", f"col_{i}") for i, c in enumerate(columns)] if columns else []
    return {"columns": col_names, "rows": all_data, "row_count": len(all_data), "query_id": query_id}

def show(label, result, max_rows=5):
    print("=" * 70)
    print(label)
    print("=" * 70)
    if "error" in result:
        print(f"  ERROR: {result['error'].get('message', result['error'])}\n")
        return
    cols = result.get("columns", [])
    rows = result.get("rows", [])
    print(f"  Rows: {result.get('row_count', 0)} | Time: query_id={result.get('query_id', 'N/A')}")
    if cols:
        print(f"  Cols: {', '.join(cols)}")
    for row in rows[:max_rows]:
        print(f"    {row}")
    print()


# ─── 1. Sample sid from BFC (flipped iris events) ────────────────────────────
show("1. BFC sid samples (flipped iris, last 7 days)", trino_query("""
    SELECT sid, eventtimestamp, operatorid, machinecode
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
    WHERE modality = 'IRIS'
      AND errorreasoncode = 'FLIPPED'
      AND haserror = true
      AND eventtimestamp >= current_date - interval '7' day
    LIMIT 5
"""))

# ─── 2. Sample session_id from opt_action ────────────────────────────────────
show("2. opt_action session_id samples (recent)", trino_query("""
    SELECT session_id, resident_uid, operator_id, stage, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE event_timestamp >= current_date - interval '7' day
      AND resident_uid IS NOT NULL
    LIMIT 5
"""))

# ─── 3. Check if opt_action has a 'sid' column too ───────────────────────────
show("3. opt_action columns matching 'sid' or 'session'", trino_query("""
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = 'stream_enu'
      AND table_name = 'enu_uc_opt_action_v2'
      AND (column_name ILIKE '%sid%' OR column_name ILIKE '%session%')
"""))

# ─── 4. Check BFC columns matching 'sid' or 'session' ────────────────────────
show("4. BFC columns matching 'sid' or 'session'", trino_query("""
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = 'stream_enu'
      AND table_name = 'enu_bfc_analytics_raw_v1'
      AND (column_name ILIKE '%sid%' OR column_name ILIKE '%session%')
"""))

# ─── 5. Try joining on session_id = sid ──────────────────────────────────────
show("5. Test join: opt_action.session_id = BFC.sid (with resident_uid)", trino_query("""
    SELECT b.sid, b.eventtimestamp, a.resident_uid, a.operator_id, a.stage
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1 b
    JOIN flink_stream.stream_enu.enu_uc_opt_action_v2 a
      ON a.session_id = b.sid
    WHERE b.modality = 'IRIS'
      AND b.errorreasoncode = 'FLIPPED'
      AND b.haserror = true
      AND b.eventtimestamp >= current_date - interval '7' day
      AND a.resident_uid IS NOT NULL
    LIMIT 5
"""))

# ─── 6. Check the actual format of session_id vs sid ─────────────────────────
show("6. Compare formats: BFC.sid vs opt_action.session_id", trino_query("""
    SELECT
        (SELECT sid FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
         WHERE sid IS NOT NULL LIMIT 1) AS bfc_sid_sample,
        (SELECT session_id FROM flink_stream.stream_enu.enu_uc_opt_action_v2
         WHERE session_id IS NOT NULL LIMIT 1) AS opt_session_id_sample
"""))

# ─── 7. Try: does opt_action have an 'srn' or 'request_id' col? ──────────────
show("7. All opt_action columns", trino_query("""
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = 'stream_enu'
      AND table_name = 'enu_uc_opt_action_v2'
    ORDER BY ordinal_position
"""))
