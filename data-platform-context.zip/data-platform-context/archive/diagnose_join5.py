#!/usr/bin/env python3
"""
Find the bridge: BFC.sid or BFC.refid -> uid_origin_tracker_enriched -> UID
"""

import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, timeout=300):
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "diagnose5",
    }
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        return result
    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    query_id = result.get("id", "")
    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.3)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
        attempts += 1
    col_names = [c.get("name", f"col_{i}") for i, c in enumerate(columns)] if columns else []
    return {"columns": col_names, "rows": all_data, "row_count": len(all_data), "query_id": query_id}

def show(label, result, max_rows=10):
    print("=" * 70)
    print(label)
    print("=" * 70)
    if "error" in result:
        print(f"  ERROR: {result['error'].get('message', result['error'])}\n")
        return
    cols = result.get("columns", [])
    rows = result.get("rows", [])
    print(f"  Rows: {result.get('row_count', 0)} | query_id={result.get('query_id', 'N/A')}")
    if cols:
        print(f"  Cols: {', '.join(cols)}")
    for row in rows[:max_rows]:
        print(f"    {row}")
    print()


# ─── 1. BFC refid samples (what does refid look like?) ───────────────────────
show("1. BFC refid samples (flipped iris)", trino_query("""
    SELECT sid, refid, operatorid, modality, errorreasoncode, eventtimestamp
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
    WHERE modality = 'IRIS'
      AND errorreasoncode = 'FLIPPED'
      AND haserror = true
      AND eventtimestamp >= current_date - interval '2' day
    LIMIT 5
"""))

# ─── 2. uid_origin_tracker_enriched FULL column list ─────────────────────────
show("2. uid_origin_tracker_enriched ALL columns", trino_query("""
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = 'mysql_uid_v2'
      AND table_name = 'uid_origin_tracker_enriched'
    ORDER BY ordinal_position
"""), max_rows=50)

# ─── 3. uid_origin_tracker_enriched sample (looking for SRN/session) ─────────
show("3. uid_origin_tracker_enriched sample (recent)", trino_query("""
    SELECT *
    FROM strot.mysql_uid_v2.uid_origin_tracker_enriched
    LIMIT 3
"""), max_rows=3)

# ─── 4. Try: does uid_origin_tracker_enriched have a column matching BFC sid? ─
# BFC sid = 'S146104806297020261014151129'
show("4. Search uid_origin_tracker_enriched for BFC sid value", trino_query("""
    SELECT *
    FROM strot.mysql_uid_v2.uid_origin_tracker_enriched
    WHERE CAST(uid AS VARCHAR) LIKE 'S1461048062970%'
       OR CAST(uid AS VARCHAR) = 'S146104806297020261014151129'
    LIMIT 5
"""))

# ─── 5. List all tables in mysql_uid_v2 schema ───────────────────────────────
show("5. Tables in strot.mysql_uid_v2", trino_query("""
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = 'mysql_uid_v2'
    ORDER BY table_name
"""), max_rows=20)

# ─── 6. Check uid_master columns for any session/srn field ───────────────────
show("6. uid_master columns (srn/session/origin)", trino_query("""
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = 'mysql_uid_v2'
      AND table_name = 'uid_master'
      AND (column_name ILIKE '%srn%' OR column_name ILIKE '%session%'
           OR column_name ILIKE '%origin%' OR column_name ILIKE '%packet%')
    ORDER BY ordinal_position
"""))
