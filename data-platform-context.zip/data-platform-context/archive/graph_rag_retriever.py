#!/usr/bin/env python3
"""
GraphRAG Retriever for strot.mysql_uid_v2

Implements two retrieval modes from the graph_rag_index.json:

  1. GLOBAL search  — finds the most relevant community reports for broad questions
     Example: "How do I find demographic change history for a UID?"

  2. LOCAL search   — finds the most relevant entities and their neighborhoods for specific questions
     Example: "What columns are in uid_origin_tracker_enriched?"

Usage:
  from graph_rag_retriever import GraphRAGRetriever

  retriever = GraphRAGRetriever()
  results = retriever.search("How do I find what fields were updated for a UID?", mode="global")
  results = retriever.search("res_dob_year column", mode="local")

CLI:
  python graph_rag_retriever.py "your question here" --mode global
  python graph_rag_retriever.py "your question here" --mode local
  python graph_rag_retriever.py "your question here" --mode hybrid
"""

import sys
import json
import re
import argparse
import textwrap
from pathlib import Path
from collections import defaultdict, Counter

INDEX_PATH = Path(r"C:\data-platform-context\graph_rag_index.json")

# ─── Stopwords ───────────────────────────────────────────────────────────────

STOPWORDS = {
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "must", "can", "shall", "to", "of", "in",
    "on", "at", "by", "for", "with", "about", "against", "between", "into",
    "through", "during", "before", "after", "above", "below", "from", "up",
    "down", "out", "off", "over", "under", "again", "further", "then",
    "once", "here", "there", "when", "where", "why", "how", "all", "both",
    "each", "few", "more", "most", "other", "some", "such", "no", "nor",
    "not", "only", "own", "same", "so", "than", "too", "very", "s", "t",
    "just", "i", "you", "he", "she", "it", "we", "they", "me", "him",
    "her", "us", "them", "my", "your", "his", "its", "our", "their",
    "this", "that", "these", "those", "what", "which", "who", "whom",
    "and", "or", "but", "if", "while", "as", "also", "get", "find",
    "show", "tell", "give", "want", "need", "like", "use", "using",
}

# Domain-specific synonyms / expansions
SYNONYMS = {
    "address": ["address", "addr", "res_addr", "pincode", "location", "residence"],
    "demographic": ["demographic", "demo", "master", "uid_master", "identity"],
    "history": ["history", "his", "historical", "previous", "old", "past", "snapshot", "archive"],
    "enrolment": ["enrolment", "enrollment", "enr", "tracker", "origin_tracker", "event", "packet"],
    "update": ["update", "updated", "change", "changed", "modify", "modified", "updt"],
    "join": ["join", "link", "connect", "relate", "relationship", "navigate"],
    "uid": ["uid", "aadhaar", "resident", "person", "individual"],
    "eid": ["eid", "enrolment_id", "enrollment_id", "event_id"],
    "shard": ["shard", "shard_hint", "partition", "prune", "hint"],
    "pii": ["pii", "personal", "private", "sensitive", "encrypted", "hashed"],
    "current": ["current", "latest", "live", "present", "now", "active"],
    "count": ["count", "how many", "number", "total", "aggregate", "sum"],
    "status": ["status", "state", "uid_status", "enr_status"],
    "state": ["state", "res_addr_state", "province"],
    "district": ["district", "res_addr_district"],
    "pincode": ["pincode", "zip", "postal", "res_addr_pincode"],
    "operator": ["operator", "operator_id", "enroller"],
    "registrar": ["registrar", "registrar_code", "agency"],
    "dob": ["dob", "date of birth", "res_dob_year", "birth"],
    "gender": ["gender", "sex"],
    "biometric": ["biometric", "biometric_flag", "fingerprint", "iris", "photo"],
    "foreigner": ["foreigner", "isforeigner", "foreign", "nri", "isnri", "nationality"],
    "date": ["date", "enr_date", "creation_date", "last_updated_date", "timestamp"],
    "query": ["query", "sql", "select", "search", "find", "lookup"],
}

def tokenize(text):
    """Tokenize text into lowercase keywords, removing stopwords."""
    text = text.lower()
    # Split on non-alphanumeric (keep underscores for column names)
    tokens = re.findall(r'[a-z0-9_]+', text)
    return [t for t in tokens if t not in STOPWORDS and len(t) > 1]

def expand_tokens(tokens):
    """Expand tokens with domain-specific synonyms."""
    expanded = set(tokens)
    for token in list(tokens):
        for syn_key, syn_vals in SYNONYMS.items():
            if token in syn_vals or token == syn_key:
                expanded.update(syn_vals)
    return expanded

# ─── Retriever ───────────────────────────────────────────────────────────────

class GraphRAGRetriever:
    """Retriever for the GraphRAG index. Supports global and local search."""

    def __init__(self, index_path=INDEX_PATH):
        with open(index_path, "r", encoding="utf-8") as f:
            self.index = json.load(f)

        # Build lookup maps
        self.entity_map = {e["entity_id"]: e for e in self.index["entities"]}
        self.entity_by_name = {}
        for e in self.index["entities"]:
            self.entity_by_name[e["name"].lower()] = e["entity_id"]
            # Also index by partial name
            if "." in e["name"]:
                # Column entity like "uid_master.uid" — also index just the column part
                col_part = e["name"].split(".", 1)[1].lower()
                if col_part not in self.entity_by_name:
                    self.entity_by_name[col_part] = e["entity_id"]

        # Build adjacency: entity_id -> [relationship_ids]
        self.outgoing = defaultdict(list)  # entity_id -> [(rel, target_id)]
        self.incoming = defaultdict(list)  # entity_id -> [(rel, source_id)]
        for rel in self.index["relationships"]:
            self.outgoing[rel["source"]].append(rel)
            self.incoming[rel["target"]].append(rel)

        # Build text unit lookup: entity_id -> [text_units]
        self.text_units_by_entity = defaultdict(list)
        for tu in self.index["text_units"]:
            self.text_units_by_entity[tu["entity_id"]].append(tu)

        # Pre-tokenize text units for faster scoring
        self.text_unit_tokens = {}
        for tu in self.index["text_units"]:
            self.text_unit_tokens[tu["text_unit_id"]] = set(tokenize(tu["text"]))

        # Pre-tokenize community summaries
        self.community_tokens = {}
        for comm in self.index["communities"]:
            tokens = set(tokenize(comm["summary"] + " " + comm["title"]))
            self.community_tokens[comm["community_id"]] = tokens

    def _score_text(self, query_tokens, text_tokens):
        """Score a text against query tokens using overlap."""
        if not text_tokens:
            return 0.0
        overlap = len(query_tokens & text_tokens)
        return overlap / max(len(query_tokens), 1)

    def global_search(self, query, top_k=3):
        """
        Global search: find the most relevant community reports.
        Best for broad questions like "How do I find demographic history?"
        """
        query_tokens = expand_tokens(set(tokenize(query)))
        if not query_tokens:
            return []

        scored = []
        for comm in self.index["communities"]:
            comm_tokens = self.community_tokens[comm["community_id"]]
            score = self._score_text(query_tokens, comm_tokens)
            # Boost score for community title match
            title_tokens = set(tokenize(comm["title"]))
            title_score = self._score_text(query_tokens, title_tokens)
            total_score = score + title_score * 0.5
            scored.append((total_score, comm))

        scored.sort(key=lambda x: x[0], reverse=True)
        results = []
        for score, comm in scored[:top_k]:
            if score > 0:
                results.append({
                    "community_id": comm["community_id"],
                    "title": comm["title"],
                    "score": round(score, 4),
                    "summary": comm["summary"],
                    "entity_count": comm["entity_count"],
                    "key_relationships": comm.get("key_relationships", []),
                    "query_examples": comm.get("query_examples", []),
                })
        return results

    def local_search(self, query, top_k=10, expand_depth=1):
        """
        Local search: find the most relevant entities and their neighborhoods.
        Best for specific questions like "What columns are in uid_origin_tracker_enriched?"
        """
        query_tokens = expand_tokens(set(tokenize(query)))
        if not query_tokens:
            return []

        # Score all entities by their text units
        scored_entities = []
        for entity in self.index["entities"]:
            best_score = 0.0
            best_text = ""
            for tu in self.text_units_by_entity.get(entity["entity_id"], []):
                tu_tokens = self.text_unit_tokens.get(tu["text_unit_id"], set())
                score = self._score_text(query_tokens, tu_tokens)
                if score > best_score:
                    best_score = score
                    best_text = tu["text"]

            # Also check entity name and description
            name_tokens = set(tokenize(entity["name"]))
            desc_tokens = set(tokenize(entity.get("description", "")))
            name_score = self._score_text(query_tokens, name_tokens) * 2.0  # Boost name matches
            desc_score = self._score_text(query_tokens, desc_tokens)

            total_score = max(best_score, name_score, desc_score)
            if total_score > 0:
                scored_entities.append((total_score, entity, best_text))

        scored_entities.sort(key=lambda x: x[0], reverse=True)

        # Expand to neighborhood
        results = []
        seen = set()
        for score, entity, best_text in scored_entities[:top_k]:
            eid = entity["entity_id"]
            if eid in seen:
                continue
            seen.add(eid)

            # Get neighbors
            neighbors = []
            if expand_depth >= 1:
                for rel in self.outgoing.get(eid, []):
                    target = self.entity_map.get(rel["target"])
                    if target and target["entity_id"] not in seen:
                        neighbors.append({
                            "entity_id": target["entity_id"],
                            "name": target["name"],
                            "type": target["type"],
                            "relationship": rel["type"],
                            "description": rel["description"],
                        })
                for rel in self.incoming.get(eid, []):
                    source = self.entity_map.get(rel["source"])
                    if source and source["entity_id"] not in seen:
                        neighbors.append({
                            "entity_id": source["entity_id"],
                            "name": source["name"],
                            "type": source["type"],
                            "relationship": rel["type"],
                            "description": rel["description"],
                        })

            results.append({
                "entity_id": eid,
                "name": entity["name"],
                "type": entity["type"],
                "score": round(score, 4),
                "description": entity.get("description", ""),
                "properties": entity.get("properties", {}),
                "matched_text": best_text,
                "neighbors": neighbors[:15],  # Limit neighbors
            })
        return results

    def search(self, query, mode="hybrid", top_k=10):
        """
        Unified search. Modes: 'global', 'local', 'hybrid'.
        Returns a dict with results from the selected mode(s).
        """
        result = {"query": query, "mode": mode}

        if mode in ("global", "hybrid"):
            result["global_results"] = self.global_search(query, top_k=3)

        if mode in ("local", "hybrid"):
            result["local_results"] = self.local_search(query, top_k=top_k)

        if mode == "hybrid":
            # Also find which communities the local results belong to
            local_communities = set()
            for lr in result.get("local_results", []):
                eid = lr["entity_id"]
                for comm in self.index["communities"]:
                    if eid in comm.get("entity_ids", []):
                        local_communities.add(comm["community_id"])
            result["local_community_ids"] = list(local_communities)

        return result

    def get_table_context(self, table_name):
        """Get full context for a specific table — all columns, relationships, and community."""
        table_name = table_name.lower()
        eid = self.entity_by_name.get(table_name)
        if not eid:
            return None

        entity = self.entity_map[eid]
        columns = []
        joins = []

        for rel in self.outgoing.get(eid, []):
            target = self.entity_map.get(rel["target"])
            if target and target["type"] == "COLUMN":
                columns.append({
                    "name": target["name"],
                    "description": target.get("description", ""),
                    "properties": target.get("properties", {}),
                })
            elif target and target["type"] == "TABLE":
                joins.append({
                    "target_table": target["name"],
                    "relationship": rel["type"],
                    "description": rel["description"],
                    "properties": rel.get("properties", {}),
                })

        # Find community
        community = None
        for comm in self.index["communities"]:
            if eid in comm.get("entity_ids", []):
                community = {"id": comm["community_id"], "title": comm["title"]}
                break

        return {
            "table": entity["name"],
            "description": entity.get("description", ""),
            "properties": entity.get("properties", {}),
            "columns": columns,
            "joins": joins,
            "community": community,
        }

    def get_join_path(self, from_table, to_table):
        """Find the join path between two tables."""
        from_table = from_table.lower()
        to_table = to_table.lower()

        from_eid = self.entity_by_name.get(from_table)
        to_eid = self.entity_by_name.get(to_table)

        if not from_eid or not to_eid:
            return None

        # Direct join
        for rel in self.outgoing.get(from_eid, []):
            if rel["target"] == to_eid and rel["type"] == "JOINS_TO":
                return {
                    "from": from_table,
                    "to": to_table,
                    "direct": True,
                    "join_keys": rel.get("properties", {}).get("join_keys", []),
                    "cardinality": rel.get("properties", {}).get("cardinality", ""),
                    "description": rel["description"],
                }

        # Try reverse
        for rel in self.outgoing.get(to_eid, []):
            if rel["target"] == from_eid and rel["type"] == "JOINS_TO":
                return {
                    "from": from_table,
                    "to": to_table,
                    "direct": True,
                    "join_keys": rel.get("properties", {}).get("join_keys", []),
                    "cardinality": rel.get("properties", {}).get("cardinality", ""),
                    "description": rel["description"],
                }

        # No direct join found — check query paths
        for qp in self.index.get("query_paths", []):
            if qp.get("start", "").lower() == from_table:
                for j in qp.get("joins", []):
                    if j.get("to", "").lower() == to_table:
                        return {
                            "from": from_table,
                            "to": to_table,
                            "direct": False,
                            "join_keys": j.get("on", []),
                            "via_query_path": qp.get("need", ""),
                        }

        return {
            "from": from_table,
            "to": to_table,
            "direct": False,
            "join_keys": [],
            "note": "No direct join found. Use uid and shard_hint as common keys."
        }


# ─── CLI ─────────────────────────────────────────────────────────────────────

def format_global_results(results):
    lines = []
    lines.append("=" * 70)
    lines.append("GLOBAL SEARCH RESULTS (Community Reports)")
    lines.append("=" * 70)
    for r in results:
        lines.append(f"\n📊 {r['community_id']}: {r['title']} (score: {r['score']})")
        lines.append(f"   Entities: {r['entity_count']}")
        lines.append(f"\n   Summary:")
        # Wrap summary
        summary = r["summary"]
        for line in textwrap.wrap(summary, width=80, initial_indent="   ", subsequent_indent="   "):
            lines.append(line)
        if r.get("key_relationships"):
            lines.append(f"\n   Key Relationships:")
            for kr in r["key_relationships"]:
                lines.append(f"     • {kr}")
        if r.get("query_examples"):
            lines.append(f"\n   Query Examples:")
            for qe in r["query_examples"]:
                lines.append(f"     • {qe}")
    return "\n".join(lines)

def format_local_results(results):
    lines = []
    lines.append("=" * 70)
    lines.append("LOCAL SEARCH RESULTS (Entity Neighborhoods)")
    lines.append("=" * 70)
    for r in results:
        lines.append(f"\n🔍 [{r['type']}] {r['name']} (score: {r['score']})")
        desc = r.get("description", "")
        if desc:
            for line in textwrap.wrap(desc, width=80, initial_indent="   ", subsequent_indent="   "):
                lines.append(line)
        if r.get("matched_text"):
            lines.append(f"   Matched: {r['matched_text'][:120]}...")
        props = r.get("properties", {})
        if props:
            lines.append(f"   Properties:")
            for k, v in props.items():
                val_str = str(v)
                if len(val_str) > 80:
                    val_str = val_str[:77] + "..."
                lines.append(f"     {k}: {val_str}")
        if r.get("neighbors"):
            lines.append(f"   Neighbors ({len(r['neighbors'])}):")
            for n in r["neighbors"][:8]:
                lines.append(f"     → [{n['type']}] {n['name']} ({n['relationship']})")
    return "\n".join(lines)

def main():
    parser = argparse.ArgumentParser(description="GraphRAG Retriever for strot.mysql_uid_v2")
    parser.add_argument("query", help="Search query")
    parser.add_argument("--mode", choices=["global", "local", "hybrid"], default="hybrid",
                        help="Search mode (default: hybrid)")
    parser.add_argument("--top-k", type=int, default=10, help="Number of results (default: 10)")
    args = parser.parse_args()

    retriever = GraphRAGRetriever()
    result = retriever.search(args.query, mode=args.mode, top_k=args.top_k)

    print(f"\nQuery: '{args.query}'")
    print(f"Mode: {args.mode}")

    if "global_results" in result:
        print()
        print(format_global_results(result["global_results"]))

    if "local_results" in result:
        print()
        print(format_local_results(result["local_results"]))

    if "local_community_ids" in result:
        print()
        print("-" * 70)
        print(f"Local results belong to communities: {', '.join(result['local_community_ids'])}")

if __name__ == "__main__":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    main()
