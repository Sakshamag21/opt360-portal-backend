#!/usr/bin/env python3
"""
The IDEAL query: single JOIN on refid between BFC and uid_origin_tracker_enriched.

BFC.refid  ->  uid_origin_tracker_enriched.refid  ->  uid

This is the clean, correct way to express the question in SQL.
"""
import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, label=""):
    headers = {"Content-Type": "text/plain", "X-Trino-User": TRINO_USER, "X-Trino-Source": "ideal-join"}
    print(f"[{label}] start...")
    start = time.time()
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        print(f"[{label}] ERROR: {str(result['error'])[:400]}")
        return None
    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    qid = result.get("id", "")
    state = result.get("stats", {}).get("state", "")
    print(f"[{label}] qid={qid}, state={state}")
    attempts = 0
    while result.get("nextUri") and attempts < 2000:
        time.sleep(0.5)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        attempts += 1
        if attempts % 40 == 0:
            processed = result.get("stats", {}).get("processedRows", "?")
            print(f"[{label}] still {state}... {round(time.time()-start,1)}s, rows={len(all_data)}, processedRows={processed}")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
    elapsed = round(time.time() - start, 2)
    cols = [c.get("name", "") for c in columns] if columns else []
    print(f"[{label}] DONE: {state}, rows={len(all_data)}, {elapsed}s")
    return {"columns": cols, "rows": all_data, "query_id": qid, "state": state, "elapsed": elapsed}


# ═══════════════════════════════════════════════════════════════
#  THE IDEAL QUERY — single JOIN on refid
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("IDEAL QUERY: BFC.refid JOIN uid_origin_tracker_enriched.refid -> uid")
print("=" * 70)

sql = """
SELECT
    b.eventtimestamp,
    b.sid,
    b.refid,
    b.operatorid,
    b.machinecode,
    t.uid,
    t.eid,
    t.operator_id,
    t.registrar_code,
    t.ea_code,
    t.creation_date
FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1 b
JOIN strot.mysql_uid_v2.uid_origin_tracker_enriched t
    ON t.refid = b.refid
WHERE b.modality = 'IRIS'
  AND b.errorreasoncode = 'FLIPPED'
  AND b.haserror = true
  AND b.modelname = 'UNSYSTEMATIC_MANUAL_CHECK'
  AND b.eventtimestamp >= current_date - interval '7' day
ORDER BY b.eventtimestamp DESC
LIMIT 20
"""
print(f"\nSQL:\n{sql}\n")

r = trino_query(sql, "ideal-join")

if r and r["rows"]:
    print(f"\n{'=' * 70}")
    print(f"RESULT: {r['row_count']} rows | Time: {r['elapsed']}s")
    print(f"{'=' * 70}\n")
    print(f"{'#':<3} {'event_time':<26} {'operator':<25} {'encrypted_uid':<50} {'eid'}")
    print("-" * 140)
    for i, row in enumerate(r["rows"], 1):
        ts = str(row[0] or '')[:25]
        op = str(row[3] or '')[:24]
        uid = str(row[5] or '')[:49]
        eid = str(row[6] or '')[:28]
        print(f"{i:<3} {ts:<26} {op:<25} {uid:<50} {eid}")
    print(f"\nQuery ID: {r['query_id']}")
    print(f"Total time: {r['elapsed']}s")
else:
    print("\nQuery did not complete or returned no rows.")
