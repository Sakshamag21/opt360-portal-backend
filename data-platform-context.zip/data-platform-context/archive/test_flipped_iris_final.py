#!/usr/bin/env python3
"""
Two-step: Get flipped iris BFC events, then look up UIDs by refid.
"""
import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, label="", timeout=180):
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "twostep-final",
    }
    print(f"[{label}] Sending query...")
    start = time.time()
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        print(f"[{label}] ERROR: {result['error'].get('message', '')[:300]}")
        return None
    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    query_id = result.get("id", "")
    attempts = 0
    while result.get("nextUri") and attempts < 600:
        time.sleep(0.5)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        attempts += 1
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
    elapsed = round(time.time() - start, 2)
    col_names = [c.get("name", f"col_{i}") for i, c in enumerate(columns)] if columns else []
    state = result.get("stats", {}).get("state", "")
    print(f"[{label}] Done: state={state}, rows={len(all_data)}, time={elapsed}s")
    return {"columns": col_names, "rows": all_data, "row_count": len(all_data), "query_id": query_id}


# ═══════════════════════════════════════════════════════════════
#  STEP 1: Get flipped iris BFC events (last 1 week, LIMIT 20)
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("STEP 1: Flipped iris in manual fraud check (last 1 week)")
print("=" * 70)

bfc = trino_query("""
    SELECT eventtimestamp, sid, refid, operatorid, machinecode
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
    WHERE modality = 'IRIS'
      AND errorreasoncode = 'FLIPPED'
      AND haserror = true
      AND modelname = 'UNSYSTEMATIC_MANUAL_CHECK'
      AND eventtimestamp >= current_date - interval '7' day
    ORDER BY eventtimestamp DESC
    LIMIT 20
""", "step1-bfc")

if not bfc or not bfc["rows"]:
    print("No BFC rows found. Exiting.")
    exit(1)

bfc_rows = bfc["rows"]
refids = [r[2] for r in bfc_rows if r[2]]
print(f"\nFound {len(bfc_rows)} flipped iris events with {len(refids)} refids\n")


# ═══════════════════════════════════════════════════════════════
#  STEP 2: Look up UIDs by refid in uid_origin_tracker_enriched
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("STEP 2: Look up UIDs in uid_origin_tracker_enriched by refid")
print("=" * 70)

refid_list = ", ".join(f"'{r}'" for r in refids)
uids = trino_query(f"""
    SELECT uid, refid, eid, enr_date, operator_id, registrar_code, ea_code
    FROM strot.mysql_uid_v2.uid_origin_tracker_enriched
    WHERE refid IN ({refid_list})
""", "step2-uids")

uid_rows = uids["rows"] if uids else []
print(f"\nFound {len(uid_rows)} UID matches\n")


# ═══════════════════════════════════════════════════════════════
#  STEP 3: Merge and display
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("RESULT: UIDs with flipped iris in manual fraud check (last 1 week)")
print("=" * 70)

uid_map = {r[1]: r for r in uid_rows}  # refid -> row

print(f"\n{'#':<3} {'event_time':<26} {'operator_id':<25} {'encrypted_uid':<50} {'enrolment_id (EID)'}")
print("-" * 140)

matched = 0
for i, bfc_row in enumerate(bfc_rows, 1):
    ts = str(bfc_row[0] or '')[:25]
    op = str(bfc_row[3] or '')[:24]
    refid = bfc_row[2]
    uid_row = uid_map.get(refid)
    if uid_row:
        uid = str(uid_row[0] or '')[:49]
        eid = str(uid_row[2] or '')[:28]
        print(f"{i:<3} {ts:<26} {op:<25} {uid:<50} {eid}")
        matched += 1
    else:
        print(f"{i:<3} {ts:<26} {op:<25} (no UID match - refid: {refid})")

print(f"\n{'=' * 70}")
print(f"SUMMARY")
print(f"{'=' * 70}")
print(f"  Total flipped iris events (last 7 days, LIMIT 20): {len(bfc_rows)}")
print(f"  Matched to UIDs: {matched}")
print(f"  Unmatched: {len(bfc_rows) - matched}")
print(f"\n  Note: UIDs are encrypted (base64) as stored in uid_origin_tracker_enriched.")
print(f"  The EID (enrolment ID) is a 28-digit number containing the enrolment timestamp.")
print(f"  To get plaintext 12-digit UIDs, join to enu_uc_opt_action_v2.resident_uid")
print(f"  via session_id = 'uc-' || refid (where refid matches).")

# ═══════════════════════════════════════════════════════════════
#  STEP 4: Also try opt_action for plaintext UIDs
# ═══════════════════════════════════════════════════════════════
print(f"\n{'=' * 70}")
print("STEP 4: Look up plaintext UIDs in enu_uc_opt_action_v2 via session_id")
print("=" * 70)

# session_id in opt_action = 'uc-' || refid
session_ids = [f"'uc-{r}'" for r in refids]
sid_list = ", ".join(session_ids)
opt = trino_query(f"""
    SELECT session_id, resident_uid, operator_id, stage, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE session_id IN ({sid_list})
      AND resident_uid IS NOT NULL
""", "step4-optaction")

opt_rows = opt["rows"] if opt else []
print(f"\nFound {len(opt_rows)} plaintext UID matches\n")

if opt_rows:
    opt_map = {r[0]: r for r in opt_rows}  # session_id -> row
    print(f"\n{'#':<3} {'event_time':<26} {'plaintext_uid':<16} {'operator_id':<25} {'stage'}")
    print("-" * 100)
    matched2 = 0
    for i, bfc_row in enumerate(bfc_rows, 1):
        ts = str(bfc_row[0] or '')[:25]
        refid = bfc_row[2]
        sid = f"uc-{refid}"
        opt_row = opt_map.get(sid)
        if opt_row:
            uid = str(opt_row[1] or '')[:15]
            op = str(opt_row[2] or '')[:24]
            stage = str(opt_row[3] or '')[:20]
            print(f"{i:<3} {ts:<26} {uid:<16} {op:<25} {stage}")
            matched2 += 1
        else:
            print(f"{i:<3} {ts:<26} (no plaintext UID)")
    print(f"\n  Plaintext UID matches: {matched2}/{len(bfc_rows)}")
