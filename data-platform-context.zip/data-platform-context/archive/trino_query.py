import strot_query as sq

query=''

read_trino=['10.10.116.39']
write_trino=['10.10.116.75','10.10.118.10']

### How to do write query
sq.query(query, host=write_trino[0])

### How to do read query
sq.query(query, host=read_trino[0])