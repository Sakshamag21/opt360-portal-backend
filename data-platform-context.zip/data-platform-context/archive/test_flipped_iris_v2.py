#!/usr/bin/env python3
"""
Two-step approach to avoid expensive cross-catalog JOIN:
  Step 1: Get flipped iris BFC events with their refids (last 1 week, LIMIT 20)
  Step 2: Look up each refid in uid_origin_tracker_enriched to get the UID
"""

import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, timeout=120):
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "twostep",
    }
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        return result
    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    query_id = result.get("id", "")
    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.3)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
        attempts += 1
    col_names = [c.get("name", f"col_{i}") for i, c in enumerate(columns)] if columns else []
    return {"columns": col_names, "rows": all_data, "row_count": len(all_data), "query_id": query_id}


# ═══════════════════════════════════════════════════════════════
#  STEP 1: Get flipped iris BFC events (last 1 week)
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("STEP 1: Flipped iris BFC events (last 1 week)")
print("=" * 70)

start = time.time()
bfc_result = trino_query("""
    SELECT eventtimestamp, sid, refid, operatorid, machinecode,
           modality, errorreasoncode, modelname
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
    WHERE modality = 'IRIS'
      AND errorreasoncode = 'FLIPPED'
      AND haserror = true
      AND modelname = 'UNSYSTEMATIC_MANUAL_CHECK'
      AND eventtimestamp >= current_date - interval '7' day
    ORDER BY eventtimestamp DESC
    LIMIT 20
""")
elapsed1 = round(time.time() - start, 2)

if "error" in bfc_result:
    print(f"ERROR: {bfc_result['error'].get('message', bfc_result['error'])}")
    exit(1)

bfc_rows = bfc_result.get("rows", [])
print(f"Rows: {len(bfc_rows)} | Time: {elapsed1}s | query_id: {bfc_result.get('query_id')}")
print(f"Columns: {', '.join(bfc_result.get('columns', []))}\n")

for row in bfc_rows:
    print(f"  {row}")
print()


# ═══════════════════════════════════════════════════════════════
#  STEP 2: Look up UIDs by refid in uid_origin_tracker_enriched
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("STEP 2: Look up UIDs for each refid in uid_origin_tracker_enriched")
print("=" * 70)

refids = [row[2] for row in bfc_rows if row[2]]
print(f"Refids to look up: {len(refids)}\n")

if refids:
    # Build IN clause
    refid_list = ", ".join(f"'{r}'" for r in refids)

    start = time.time()
    uid_result = trino_query(f"""
        SELECT uid, refid, eid, enr_date, operator_id, registrar_code, ea_code
        FROM strot.mysql_uid_v2.uid_origin_tracker_enriched
        WHERE refid IN ({refid_list})
    """)
    elapsed2 = round(time.time() - start, 2)

    if "error" in uid_result:
        print(f"ERROR: {uid_result['error'].get('message', uid_result['error'])}")
    else:
        uid_rows = uid_result.get("rows", [])
        print(f"Rows: {len(uid_rows)} | Time: {elapsed2}s | query_id: {uid_result.get('query_id')}")
        print(f"Columns: {', '.join(uid_result.get('columns', []))}\n")

        for row in uid_rows:
            print(f"  {row}")
        print()

    # ═══════════════════════════════════════════════════════════════
    #  STEP 3: Merge BFC events with UIDs
    # ═══════════════════════════════════════════════════════════════
    print("=" * 70)
    print("STEP 3: Merged result - Flipped iris events with UIDs")
    print("=" * 70)

    uid_map = {row[1]: row for row in uid_rows}  # refid -> uid row

    print(f"\n{'eventtimestamp':<26} {'operatorid':<25} {'encrypted_uid':<50} {'eid'}")
    print("-" * 130)
    matched = 0
    for bfc_row in bfc_rows:
        ts = str(bfc_row[0] or '')[:25]
        op = str(bfc_row[3] or '')[:24]
        refid = bfc_row[2]
        uid_row = uid_map.get(refid)
        if uid_row:
            uid = str(uid_row[0] or '')[:49]
            eid = str(uid_row[2] or '')[:28]
            print(f"{ts:<26} {op:<25} {uid:<50} {eid}")
            matched += 1
        else:
            print(f"{ts:<26} {op:<25} (no UID found for refid {refid})")

    print(f"\nMatched: {matched}/{len(bfc_rows)} events have UIDs")
    print(f"\nTotal time: {round(elapsed1 + elapsed2, 2)}s")
else:
    print("No refids found in BFC events.")
