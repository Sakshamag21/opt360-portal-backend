#!/usr/bin/env python3
"""
Strategy: filter uid_origin_tracker_enriched by recent creation_date (likely indexed),
then match refids in Python. Also test if operator_id + machine_id lookup is fast.
"""
import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, label=""):
    headers = {"Content-Type": "text/plain", "X-Trino-User": TRINO_USER, "X-Trino-Source": "strategy"}
    print(f"[{label}] start...")
    start = time.time()
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        print(f"[{label}] ERROR: {str(result['error'])[:300]}")
        return None
    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    qid = result.get("id", "")
    state = result.get("stats", {}).get("state", "")
    print(f"[{label}] qid={qid}, state={state}")
    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.5)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        attempts += 1
        if attempts % 40 == 0:
            print(f"[{label}] still {state}... {round(time.time()-start,1)}s, rows={len(all_data)}")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
    elapsed = round(time.time() - start, 2)
    cols = [c.get("name", "") for c in columns] if columns else []
    print(f"[{label}] DONE: {state}, rows={len(all_data)}, {elapsed}s")
    return {"columns": cols, "rows": all_data, "query_id": qid, "state": state, "elapsed": elapsed}


# Test 1: Count recent rows by creation_date (is it fast?)
r = trino_query("""
    SELECT count(*) AS cnt
    FROM strot.mysql_uid_v2.uid_origin_tracker_enriched
    WHERE creation_date >= current_date - interval '7' day
""", "count-recent")
if r and r["rows"]:
    print(f"  Recent rows (last 7 days by creation_date): {r['rows'][0][0]}\n")

# Test 2: Get recent rows with refid (limit to last 7 days)
r = trino_query("""
    SELECT uid, refid, eid, operator_id, source_client_machine_id, creation_date
    FROM strot.mysql_uid_v2.uid_origin_tracker_enriched
    WHERE creation_date >= current_date - interval '7' day
    LIMIT 5
""", "recent-sample")
if r and r["rows"]:
    for row in r["rows"]:
        print(f"  {row}")
    print()

# Test 3: Look up by operator_id + machine_id (BFC operator PRO032_45, machine Dell Inc.5307...)
r = trino_query("""
    SELECT uid, refid, eid, operator_id, source_client_machine_id, creation_date
    FROM strot.mysql_uid_v2.uid_origin_tracker_enriched
    WHERE operator_id = 'PRO032_45'
      AND source_client_machine_id = 'Dell Inc.5307D1B6-71F6-B057-11F9-7C9CABA4459B'
    LIMIT 5
""", "op-machine-lookup")
if r and r["rows"]:
    for row in r["rows"]:
        print(f"  {row}")
    print()

# Test 4: Look up by operator_id only
r = trino_query("""
    SELECT uid, refid, eid, operator_id, creation_date
    FROM strot.mysql_uid_v2.uid_origin_tracker_enriched
    WHERE operator_id = 'PRO032_45'
    LIMIT 5
""", "op-only-lookup")
if r and r["rows"]:
    for row in r["rows"]:
        print(f"  {row}")
    print()
