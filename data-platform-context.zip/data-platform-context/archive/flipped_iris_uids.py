#!/usr/bin/env python3
"""
FINAL: Get UIDs for flipped iris events by joining BFC -> uid_origin_tracker_enriched
via operator_id (fast, indexed) + refid (exact match).
"""
import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, label=""):
    headers = {"Content-Type": "text/plain", "X-Trino-User": TRINO_USER, "X-Trino-Source": "final"}
    print(f"[{label}] start...")
    start = time.time()
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        print(f"[{label}] ERROR: {str(result['error'])[:400]}")
        return None
    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    qid = result.get("id", "")
    state = result.get("stats", {}).get("state", "")
    print(f"[{label}] qid={qid}, state={state}")
    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.5)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        attempts += 1
        if attempts % 40 == 0:
            print(f"[{label}] still {state}... {round(time.time()-start,1)}s, rows={len(all_data)}")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
    elapsed = round(time.time() - start, 2)
    cols = [c.get("name", "") for c in columns] if columns else []
    print(f"[{label}] DONE: {state}, rows={len(all_data)}, {elapsed}s")
    return {"columns": cols, "rows": all_data, "query_id": qid, "state": state, "elapsed": elapsed}


# ═══════════════════════════════════════════════════════════════
#  Step 1: Get BFC flipped iris events (last 7 days, LIMIT 20)
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("QUESTION: Give me all the UIDs in last 1 week which have flipped")
print("          iris in the manual fraud check")
print("=" * 70)

bfc = trino_query("""
    SELECT eventtimestamp, sid, refid, operatorid, machinecode
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
    WHERE modality = 'IRIS'
      AND errorreasoncode = 'FLIPPED'
      AND haserror = true
      AND modelname = 'UNSYSTEMATIC_MANUAL_CHECK'
      AND eventtimestamp >= current_date - interval '7' day
    ORDER BY eventtimestamp DESC
    LIMIT 20
""", "step1-bfc")

if not bfc or not bfc["rows"]:
    print("No BFC events found.")
    exit(1)

bfc_rows = bfc["rows"]
# Get unique operator IDs
operators = list(set(r[3] for r in bfc_rows if r[3]))
print(f"\n  BFC events: {len(bfc_rows)}")
print(f"  Unique operators: {len(operators)}\n")


# ═══════════════════════════════════════════════════════════════
#  Step 2: For each operator, get their UIDs from uid_origin_tracker
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("Step 2: Looking up UIDs by operator_id in uid_origin_tracker_enriched")
print("=" * 70)

op_list = ", ".join(f"'{o}'" for o in operators)
uids = trino_query(f"""
    SELECT uid, refid, eid, operator_id, creation_date
    FROM strot.mysql_uid_v2.uid_origin_tracker_enriched
    WHERE operator_id IN ({op_list})
""", "step2-uids")

uid_rows = uids["rows"] if uids else []
print(f"\n  Found {len(uid_rows)} UID records for these operators\n")


# ═══════════════════════════════════════════════════════════════
#  Step 3: Match BFC events to UIDs by refid
# ═══════════════════════════════════════════════════════════════
print("=" * 70)
print("RESULT: UIDs with flipped iris in manual fraud check (last 7 days)")
print("=" * 70)

# Build refid -> uid mapping
refid_to_uid = {}
for row in uid_rows:
    refid = row[1]
    refid_to_uid[refid] = row

print(f"\n{'#':<3} {'event_time':<26} {'operator':<25} {'encrypted_uid':<50} {'enrolment_id (EID)'}")
print("-" * 145)

matched = 0
for i, bfc_row in enumerate(bfc_rows, 1):
    ts = str(bfc_row[0] or '')[:25]
    op = str(bfc_row[3] or '')[:24]
    refid = bfc_row[2]
    sid = bfc_row[1]

    uid_row = refid_to_uid.get(refid)
    if uid_row:
        uid = str(uid_row[0] or '')[:49]
        eid = str(uid_row[2] or '')[:28]
        print(f"{i:<3} {ts:<26} {op:<25} {uid:<50} {eid}")
        matched += 1
    else:
        print(f"{i:<3} {ts:<26} {op:<25} (no UID match - refid: {refid})")

print(f"\n{'=' * 70}")
print(f"SUMMARY")
print(f"{'=' * 70}")
print(f"  Total flipped iris events (last 7 days):    {len(bfc_rows)} (LIMIT 20)")
print(f"  Successfully matched to UIDs:               {matched}")
print(f"  Unmatched:                                  {len(bfc_rows) - matched}")
print(f"  Total time: {round(bfc.get('elapsed', 0) + uids.get('elapsed', 0) if uids else 0, 2)}s")
print()
print("  Notes:")
print("  - UIDs are encrypted (base64) as stored in uid_origin_tracker_enriched")
print("  - EID = enrolment ID (28-digit, contains enrolment timestamp)")
print("  - BFC.sid = uid_origin_tracker_enriched.eid (session/enrolment ID)")
print("  - BFC.refid = uid_origin_tracker_enriched.refid (UUID reference)")
print("  - Join path: BFC.operatorid = uid_origin_tracker.operator_id (indexed, fast)")
print("    then BFC.refid = uid_origin_tracker.refid (exact match)")
