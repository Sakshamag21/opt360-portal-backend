#!/usr/bin/env python3
"""
Final diagnosis: find the right way to get UIDs for flipped-iris BFC events.
Strategy:
  A. Check ALL BFC columns (maybe there's a UID we missed)
  B. Wide time-window join: same operator + same machine, same day, look for SRNGeneration
  C. Check if uid_origin_tracker_enriched can bridge the gap
"""

import time, requests

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

def trino_query(sql, timeout=300):
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "diagnose4",
    }
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        return result
    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])
    query_id = result.get("id", "")
    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.3)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
        attempts += 1
    col_names = [c.get("name", f"col_{i}") for i, c in enumerate(columns)] if columns else []
    return {"columns": col_names, "rows": all_data, "row_count": len(all_data), "query_id": query_id}

def show(label, result, max_rows=10):
    print("=" * 70)
    print(label)
    print("=" * 70)
    if "error" in result:
        print(f"  ERROR: {result['error'].get('message', result['error'])}\n")
        return
    cols = result.get("columns", [])
    rows = result.get("rows", [])
    print(f"  Rows: {result.get('row_count', 0)} | query_id={result.get('query_id', 'N/A')}")
    if cols:
        print(f"  Cols: {', '.join(cols)}")
    for row in rows[:max_rows]:
        print(f"    {row}")
    print()


# ─── A. Full BFC column list ─────────────────────────────────────────────────
show("A. ALL BFC columns (looking for any UID field)", trino_query("""
    SELECT column_name, data_type
    FROM flink_stream.information_schema.columns
    WHERE table_schema = 'stream_enu'
      AND table_name = 'enu_bfc_analytics_raw_v1'
    ORDER BY ordinal_position
"""), max_rows=30)

# ─── B. Does BLS133_015 exist in opt_action at all? ──────────────────────────
show("B. opt_action for BLS133_015 (any date, last 30 days)", trino_query("""
    SELECT operator_id, station_machine_code, resident_uid, stage, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE operator_id = 'BLS133_015'
      AND event_timestamp >= current_date - interval '30' day
    ORDER BY event_timestamp DESC
    LIMIT 10
"""))

# ─── C. opt_action for machine LENOVOE565F535 on 2026-10-19 ──────────────────
show("C. opt_action for machine LENOVOE565F535 on 2026-10-19", trino_query("""
    SELECT operator_id, station_machine_code, resident_uid, stage, event_timestamp
    FROM flink_stream.stream_enu.enu_uc_opt_action_v2
    WHERE station_machine_code = 'LENOVOE565F535-1E19-F3BF-5BAD-478E5EE96E1C'
      AND event_timestamp >= TIMESTAMP '2026-10-19 00:00:00'
      AND event_timestamp <  TIMESTAMP '2026-10-20 00:00:00'
    ORDER BY event_timestamp
    LIMIT 20
"""))

# ─── D. Try a 30-minute time window join for the specific BFC event ──────────
show("D. Join BFC flipped iris → opt_action SRNGeneration (30 min before)", trino_query("""
    SELECT
        b.eventtimestamp AS bfc_time,
        b.sid,
        b.operatorid,
        b.machinecode,
        a.resident_uid,
        a.stage,
        a.event_timestamp AS srn_time
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1 b
    JOIN flink_stream.stream_enu.enu_uc_opt_action_v2 a
      ON a.operator_id = b.operatorid
     AND a.station_machine_code = b.machinecode
     AND a.event_timestamp BETWEEN b.eventtimestamp - interval '30' minute
                               AND b.eventtimestamp + interval '5' minute
     AND a.stage = 'SRNGeneration'
     AND a.resident_uid IS NOT NULL
    WHERE b.modality = 'IRIS'
      AND b.errorreasoncode = 'FLIPPED'
      AND b.haserror = true
      AND b.eventtimestamp >= current_date - interval '2' day
    ORDER BY b.eventtimestamp DESC
    LIMIT 10
"""))

# ─── E. Same as D, but without the stage filter (any stage with resident_uid) ─
show("E. Join BFC → opt_action (any stage with resident_uid, 30 min window)", trino_query("""
    SELECT
        b.eventtimestamp AS bfc_time,
        b.sid,
        b.operatorid,
        b.machinecode,
        a.resident_uid,
        a.stage,
        a.event_timestamp AS action_time
    FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1 b
    JOIN flink_stream.stream_enu.enu_uc_opt_action_v2 a
      ON a.operator_id = b.operatorid
     AND a.station_machine_code = b.machinecode
     AND a.event_timestamp BETWEEN b.eventtimestamp - interval '60' minute
                               AND b.eventtimestamp + interval '5' minute
     AND a.resident_uid IS NOT NULL
    WHERE b.modality = 'IRIS'
      AND b.errorreasoncode = 'FLIPPED'
      AND b.haserror = true
      AND b.eventtimestamp >= current_date - interval '2' day
    ORDER BY b.eventtimestamp DESC
    LIMIT 10
"""))

# ─── F. Check uid_origin_tracker_enriched columns ────────────────────────────
show("F. uid_origin_tracker_enriched columns (looking for session/srn)", trino_query("""
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = 'mysql_uid_v2'
      AND table_name = 'uid_origin_tracker_enriched'
      AND (column_name ILIKE '%srn%' OR column_name ILIKE '%session%'
           OR column_name ILIKE '%uid%' OR column_name ILIKE '%operator%'
           OR column_name ILIKE '%machine%')
    ORDER BY ordinal_position
"""))
