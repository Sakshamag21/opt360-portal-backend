#!/usr/bin/env python3
"""
Test the intent classification + metadata handling.
Tests: METADATA queries, SEMANTIC_SEARCH, and DATA_QUERY.
"""
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r"C:\data-platform-context")

from text_to_sql import TextToSQL

# Initialize
tts = TextToSQL(use_llm_rerank=False, verbose=True)

# Test questions — one of each intent type
test_questions = [
    # METADATA queries
    "how many tables are there?",
    "describe the uid_master table",
    "what columns does enu_bfc_analytics_raw_v1 have?",
    "what is the join path between uid_master and uid_address?",
    "what data quality issues exist?",

    # SEMANTIC_SEARCH
    "which table has biometric fraud check data?",
    "where can I find operator action data?",

    # DATA_QUERY (should go through SQL generation)
    "how many UIDs are active in shard 45?",
]

for q in test_questions:
    print("\n" + "=" * 75)
    print(f"QUESTION: {q}")
    print("=" * 75)

    result = tts.generate(q, execute=False, explain=False)

    print(f"\n--- RESULT ---")
    print(f"Intent: {result.get('intent')}")
    print(f"Elapsed: {result.get('elapsed')}s")

    if result.get("metadata_answer"):
        print(f"\nMETADATA ANSWER:")
        print(result["metadata_answer"][:500])

    if result.get("sql"):
        print(f"\nSQL:")
        print(result["sql"][:300])

    print()
