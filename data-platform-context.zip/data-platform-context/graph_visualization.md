# GraphRAG — Live Table Relationship Graph

> **Source:** Retrieved live from PostgreSQL (`graphrag-postgres` container) on 2026-10-19
> **Interactive HTML:** [graph_visualization.html](./graph_visualization.html) — open in browser for full interactivity (drag nodes, hover for details, filter edges, pan/zoom)
> **Raw data:** [postgres_graph_state.json](./postgres_graph_state.json)

## Current State (235 entities, 380 relationships)

| Entity Type | Count |
|-------------|-------|
| TABLE | 9 |
| COLUMN | 189 |
| CONCEPT | 14 |
| JOIN_KEY | 8 |
| DATA_QUALITY_ISSUE | 12 |
| HOST | 3 |
| **Total** | **235** |

| Relationship Type | Count |
|-------------------|-------|
| HAS_COLUMN | 202 |
| CONCEPT_CONTAINS_COLUMN | 114 |
| SEMANTICALLY_LINKED | 19 |
| JOIN_KEY_IN_TABLE | 16 |
| AFFECTS_TABLE | 15 |
| JOINS_TO | 14 |
| **Total** | **380** |

## Tables (9)

| Entity ID | Table | Schema | Rows | Cols | Date Range |
|-----------|-------|--------|------|------|------------|
| E0001 | `uid_master` | strot.mysql_uid_v2 | 1.46B | 30 | 2010-08-21 → 2026-10-09 |
| E0002 | `uid_his_master` | strot.mysql_uid_v2 | 2.87B | 28 | 2017-08-17 → 2026-10-09 |
| E0003 | `uid_address` | strot.mysql_uid_v2 | 1.46B | 31 | 2010-08-21 → 2026-10-09 |
| E0004 | `uid_his_address` | strot.mysql_uid_v2 | 1.51B | 32 | 2017-08-17 → 2026-10-09 |
| E0005 | `uid_origin_tracker_enriched` | strot.mysql_uid_v2 | 3.29B | 68 | — |
| E0218 | `enu_uc_opt_action_v2` | flink_stream.stream_enu | 687M | 32 | 2024-11-15 → 2026-10-16 |
| E0219 | `telemetry_uc` | flink_stream.stream_enu | 295M | 19 | 2025-01-01 → 2026-10-16 |
| E0220 | `enu_bfc_analytics_raw_v1` | flink_stream.stream_enu | 79M | 30 | 2026-03-09 → 2026-10-16 |
| E0221 | `station_reg_helper` | mysql_uidmasterv1.uidmasterv1_1 | 296K | 35 | 2024-03-12 → 2026-10-16 |

## JOINS_TO Relationships (14)

### Within-schema (strot.mysql_uid_v2) — 6 edges

```mermaid
graph TD
    subgraph strot["strot.mysql_uid_v2 (server-side)"]
        UM["uid_master<br/>1.46B rows"]
        UHM["uid_his_master<br/>2.87B rows"]
        UA["uid_address<br/>1.46B rows"]
        UHA["uid_his_address<br/>1.51B rows"]
        UOT["uid_origin_tracker_enriched<br/>3.29B rows"]
    end

    UM -->|"1:N (uid, shard_hint)"| UHM
    UM -->|"1:1 (uid, shard_hint)"| UA
    UA -->|"1:N (uid, shard_hint)"| UHA
    UOT -->|"1:N (uid, eid, shard_hint)"| UHM
    UOT -->|"1:N (uid, eid, shard_hint)"| UHA
    UHM -->|"1:N (uid, eid, shard_hint)"| UHA

    style UM fill:#1a3a5c,stroke:#58a6ff,stroke-width:2px,color:#fff
    style UHM fill:#1a3a5c,stroke:#58a6ff,stroke-width:2px,color:#fff
    style UA fill:#1a3a5c,stroke:#58a6ff,stroke-width:2px,color:#fff
    style UHA fill:#1a3a5c,stroke:#58a6ff,stroke-width:2px,color:#fff
    style UOT fill:#1a3a5c,stroke:#58a6ff,stroke-width:3px,color:#fff
```

### Cross-schema (flink_stream + mysql_uidmasterv1) — 8 edges

```mermaid
graph LR
    subgraph strot["strot.mysql_uid_v2"]
        UOT["uid_origin_tracker_enriched<br/>3.29B rows"]
    end

    subgraph flink["flink_stream.stream_enu"]
        OPT["enu_uc_opt_action_v2<br/>687M rows"]
        TEL["telemetry_uc<br/>295M rows"]
        BFC["enu_bfc_analytics_raw_v1<br/>79M rows"]
    end

    subgraph mysql["mysql_uidmasterv1.uidmasterv1_1"]
        SRH["station_reg_helper<br/>296K rows"]
    end

    OPT -.->|"N:N (operator_id, session_id)"| BFC
    OPT -.->|"N:N (operator_id, session_id)"| TEL
    OPT -.->|"N:1 (station_id, registrar, ea)"| SRH
    BFC -.->|"N:N (sid, machinecode)"| TEL
    BFC -.->|"N:1 (machinecode)"| SRH
    TEL -.->|"N:1 (pdata_id)"| SRH
    SRH -.->|"N:1 (registrar_id, ea_code)"| UOT
    OPT -.->|"N:N (registrar, ea, operator_id)"| UOT

    style UOT fill:#1a3a5c,stroke:#58a6ff,stroke-width:2px,color:#fff
    style OPT fill:#1a3a2c,stroke:#3fb950,stroke-width:2px,color:#fff
    style TEL fill:#1a3a2c,stroke:#3fb950,stroke-width:2px,color:#fff
    style BFC fill:#1a3a2c,stroke:#3fb950,stroke-width:2px,color:#fff
    style SRH fill:#3a2c1a,stroke:#d29922,stroke-width:2px,color:#fff
```

## Full Graph (all 14 edges)

```mermaid
graph TD
    subgraph strot["strot.mysql_uid_v2 (server-side, 5 tables)"]
        UM["uid_master<br/>1.46B / 30 cols"]
        UHM["uid_his_master<br/>2.87B / 28 cols"]
        UA["uid_address<br/>1.46B / 31 cols"]
        UHA["uid_his_address<br/>1.51B / 32 cols"]
        UOT["uid_origin_tracker_enriched<br/>3.29B / 68 cols"]
    end

    subgraph flink["flink_stream.stream_enu (client-side, 3 tables)"]
        OPT["enu_uc_opt_action_v2<br/>687M / 32 cols"]
        TEL["telemetry_uc<br/>295M / 19 cols"]
        BFC["enu_bfc_analytics_raw_v1<br/>79M / 30 cols"]
    end

    subgraph mysql["mysql_uidmasterv1 (device mgmt, 1 table)"]
        SRH["station_reg_helper<br/>296K / 35 cols"]
    end

    %% Within-schema (solid)
    UM -->|"1:N"| UHM
    UM -->|"1:1"| UA
    UA -->|"1:N"| UHA
    UOT -->|"1:N"| UHM
    UOT -->|"1:N"| UHA
    UHM -->|"1:N"| UHA

    %% Cross-schema (dashed)
    OPT -.->|"N:N"| BFC
    OPT -.->|"N:N"| TEL
    OPT -.->|"N:1"| SRH
    BFC -.->|"N:N"| TEL
    BFC -.->|"N:1"| SRH
    TEL -.->|"N:1"| SRH
    SRH -.->|"N:1"| UOT
    OPT -.->|"N:N"| UOT

    style UM fill:#1a3a5c,stroke:#58a6ff,stroke-width:2px,color:#fff
    style UHM fill:#1a3a5c,stroke:#58a6ff,stroke-width:2px,color:#fff
    style UA fill:#1a3a5c,stroke:#58a6ff,stroke-width:2px,color:#fff
    style UHA fill:#1a3a5c,stroke:#58a6ff,stroke-width:2px,color:#fff
    style UOT fill:#1a3a5c,stroke:#58a6ff,stroke-width:3px,color:#fff
    style OPT fill:#1a3a2c,stroke:#3fb950,stroke-width:2px,color:#fff
    style TEL fill:#1a3a2c,stroke:#3fb950,stroke-width:2px,color:#fff
    style BFC fill:#1a3a2c,stroke:#3fb950,stroke-width:2px,color:#fff
    style SRH fill:#3a2c1a,stroke:#d29922,stroke-width:2px,color:#fff
```

## Cross-Schema Join Keys (8)

| Join Key | Format | Schemas | Column Aliases |
|----------|--------|---------|----------------|
| `uid` | Base64 encrypted blob | strot | uid |
| `eid` | Long numeric string | strot | eid |
| `shard_hint` | 2-digit UID prefix | strot | shard_hint |
| `operator_id` | e.g. MH_MIT_JG_NS249784 | strot, flink_stream | operator_id, operatorid, actor_id |
| `registrar_code` | 3-digit numeric | strot, flink_stream, mysql_uidmasterv1 | registrar_code, registrar, registrar_id |
| `ea_code` | 4-digit numeric | strot, flink_stream, mysql_uidmasterv1 | ea_code, ea, enrollment_agency_code |
| `machine_id` | `<manufacturer><UUID>` | flink_stream, mysql_uidmasterv1 | machine_id, machinecode, pdata_id |
| `session_id` | uc-`<UUID>` or S`<timestamp>` | flink_stream | session_id, sid |

## Concepts (14)

| Entity ID | Concept | Primary Table(s) |
|-----------|---------|-----------------|
| E0195 | Identity | strot tables |
| E0196 | Enrolment | strot tables |
| E0197 | Demographics | strot tables |
| E0198 | Address | strot tables |
| E0199 | Update Tracking | strot tables |
| E0200 | Enrolment Channel | strot tables |
| E0201 | Audit | strot tables |
| E0202 | PII | strot tables |
| E0203 | Deprecated | strot tables |
| E0204 | Data Quality Issues | strot tables |
| E0227 | Client Activity | enu_uc_opt_action_v2 |
| E0228 | Biometric Fraud Check | enu_bfc_analytics_raw_v1 |
| E0229 | Device Security | station_reg_helper |
| E0230 | Cross-Schema Join Keys | all schemas |

## Data Quality Issues (12)

| Entity ID | Issue | Table | Column(s) | Fix |
|-----------|-------|-------|-----------|-----|
| E0211 | State Name Variants | strot | — | — |
| E0212 | Country Code Variants | strot | — | — |
| E0213 | Literal NULL Strings | strot | — | — |
| E0214 | Legacy 'N' Values | strot | — | — |
| E0215 | enr_date Anomalies | strot | — | — |
| E0216 | res_dob_year Non-Numeric | strot | — | — |
| E0217 | updt_* Varbinary Encoding | strot | — | — |
| E0231 | capture_timestamp zero dates | station_reg_helper | capture_timestamp | Use creation_date |
| E0232 | manufacturer trailing null bytes | station_reg_helper | manufacturer | trim(manufacturer) |
| E0233 | modelprediction varchar | enu_bfc_analytics_raw_v1 | modelprediction | TRY_CAST AS double |
| E0234 | stage_status casing | enu_uc_opt_action_v2 | stage_status | UPPER(stage_status) = 'COMPLETED' |
| E0235 | bfc deprecated columns | enu_bfc_analytics_raw_v1 | 5 columns | Do not use |

## Query Paths (20)

| # | Need | Start Table |
|---|------|-------------|
| 1 | Current demographic info | uid_master |
| 2 | Current address | uid_address |
| 3 | Current demo + address | uid_master |
| 4 | Demographic change history | uid_his_master |
| 5 | Address change history | uid_his_address |
| 6 | Full history (demo + address) | uid_his_master |
| 7 | What fields changed in an update | uid_origin_tracker_enriched |
| 8 | Who enrolled/updated and when | uid_origin_tracker_enriched |
| 9 | Event + resulting snapshots | uid_origin_tracker_enriched |
| 10 | Current + history (demographic) | uid_master |
| 11 | Current + history (address) | uid_address |
| 12 | Everything for a UID | uid_master |
| 13 | Client-side operator actions/stage events | enu_uc_opt_action_v2 |
| 14 | Client application errors/telemetry | telemetry_uc |
| 15 | Biometric fraud check results | enu_bfc_analytics_raw_v1 |
| 16 | Device/station TPM registration info | station_reg_helper |
| 17 | BFC results + device security (cross-schema) | enu_bfc_analytics_raw_v1 |
| 18 | Telemetry errors + device info (cross-schema) | telemetry_uc |
| 19 | Client actions + BFC results (same session) | enu_uc_opt_action_v2 |
| 20 | Station registration + server-side enrolment (cross-schema aggregate) | station_reg_helper |
