# Trino Table Context Layer — `strot.mysql_uid_v2.uid_origin_tracker_enriched`

> Context layer for text-to-SQL. Catalog: `strot` · Schema: `mysql_uid_v2` · Table: `uid_origin_tracker_enriched`
>
> **Enrolment tracking table (enriched).** Tracks every enrolment/update event for a UID. Each row represents one enrolment packet/event. Contains enrolment metadata (registrar, operator, mode, status) and varbinary "update indicator" flags (`updt_*`) that indicate which resident fields were changed in that event. The largest table in the schema (~3.29B rows).

## Quick Facts

| Property | Value |
|----------|-------|
| Full table reference | `strot.mysql_uid_v2.uid_origin_tracker_enriched` |
| Approximate row count | **3,292,012,027** (~3.29 billion) |
| Column count | 70 |
| Source connector | MySQL , exposed via Trino |
| Read host | `10.10.116.39` |
| Write hosts | `10.10.116.75`, `10.10.118.10` |

> ⚠️ **Largest table (~3.29B rows).** Full-table scans are extremely expensive — they will time out. **Always** use `shard_hint` filters, `tracker_key` ranges, `uid` predicates, or `LIMIT`. Never run aggregations without a predicate.

### Relationship to other tables

- Joined to `uid_master` / `uid_his_master` / `uid_address` / `uid_his_address` via **`uid`**
- `eid` column matches `eid` in `uid_his_master` and `uid_his_address` — can be used to correlate enrolment events with history snapshots
- `enr_type` is semantically similar to `verification_type` in `uid_master` (both use `'D'` = demographic)

---

## Column Dictionary

### Enrolment Identity & Keys (columns 1–5)

| # | Column | Type | Description | Notes | Importance |
|---|--------|------|-------------|-------|------------|
| 1 | `tracker_key` | bigint | Surrogate primary key | Non-contiguous. Useful for sampling with `WHERE tracker_key <= N`. | Low |
| 2 | `uid` | varchar | Encrypted UID (Aadhaar number) | PII (encrypted). **Primary join key** to all other UID tables. | High |
| 3 | `refid` | varchar | Reference ID (UUID format) | E.g. `b08fe5a1-f774-4eb4-8db4-9b198116c329`. Unique per enrolment packet. | Medium |
| 4 | `eid` | varchar | Enrolment ID | E.g. `2085230300345320160528163328`. Same as `eid` in history tables. Encodes enrolment metadata (registrar code, timestamp, etc.). | High |
| 5 | `enr_date` | timestamp(6) | Enrolment date/time | When the enrolment packet was created. Note: some very old rows have anomalous dates (e.g. year 99). | High |

### Enrolment Details (columns 6–11)

| # | Column | Type | Description | Notes | Importance |
|---|--------|------|-------------|-------|------------|
| 6 | `enr_num` | varchar | Enrolment number | Shorter form of eid (e.g. `20852303003453`). | Medium |
| 7 | `enr_type` | varchar | Enrolment type | `'D'` = demographic. Similar to `verification_type` in `uid_master`. | Medium |
| 8 | `enr_mode` | varchar | Enrolment mode | `'OFFLINE'`, `'ONLINE'`. | Medium |
| 9 | `enr_status` | varchar | Enrolment status | `'R'` = registered/processed. | High |
| 10 | `enr_status_date` | timestamp(6) | Enrolment status date | When the status was last updated. | Medium |
| 11 | `available_in_abis` | varchar | Whether biometrics are available in ABIS | `'0'` / `'1'`. ABIS = Automated Biometric Identification System. | Low |

### Application & Registrar Info (columns 12–17)

| # | Column | Type | Description | Notes | Importance |
|---|--------|------|-------------|-------|------------|
| 12 | `app_num` | varchar | Application number | | Low |
| 13 | `registrar_code` | varchar | Registrar code | E.g. `206`, `618`, `001`. Identifies the enrolment registrar (e.g. state govt, bank, PSU). | High |
| 14 | `ea_code` | varchar | Enrolment Agency code | E.g. `2085`, `1408`. Identifies the agency that conducted the enrolment. | Medium |
| 15 | `operator_id` | varchar | Operator ID | E.g. `NPS_S_BhagyshrI`, `ZKK_S_0055`. The person who operated the enrolment device. | Medium |
| 16 | `supervisor_id` | varchar | Supervisor ID | Often NULL. The person who supervised the enrolment. | Low |
| 17 | `upload_time` | timestamp(6) | Packet upload time | When the enrolment packet was uploaded to the server. | Medium |

### Flags & Indicators (columns 18–23)

| # | Column | Type | Description | Notes | Importance |
|---|--------|------|-------------|-------|------------|
| 18 | `update_ind` | boolean | Whether this is an update enrolment (vs new enrolment) | `false` = new enrolment, `true` = update to existing UID. | High |
| 19 | `reject_ind` | boolean | Whether this enrolment was rejected | `false` = not rejected, `true` = rejected. | High |
| 20 | `auth_extraction_status` | varchar | Auth extraction status | Mostly NULL. | Low |
| 21 | `auth_extraction_status_date` | timestamp(6) | Auth extraction status date | Mostly NULL. | Low |
| 22 | `ischild` | varchar | Whether this is a child enrolment | `'0'` = no, `'1'` = yes. Child enrolments require guardian linkage. | Medium |
| 23 | `linkedenrolment_eid` | varchar | Linked enrolment EID (for child/HoF linkage) | EID of the parent/guardian enrolment. NULL if not linked. | Medium |

### Biometric Match Indices (columns 24–29)

| # | Column | Type | Description | Notes | Importance |
|---|--------|------|-------------|-------|------------|
| 24 | `bestphotocbeffmatchidx` | integer | Best photo CBEFF match index | Mostly NULL. Biometric matching score/index. | Low |
| 25 | `bestleftslabcbeffmatchidx` | integer | Best left slap CBEFF match index | Mostly NULL. Fingerprint match. | Low |
| 26 | `bestrightslabcbeffmatchidx` | integer | Best right slap CBEFF match index | Mostly NULL. Fingerprint match. | Low |
| 27 | `bestthumbsslabcbeffmatchidx` | integer | Best thumbs slap CBEFF match index | Mostly NULL. Fingerprint match. | Low |
| 28 | `bestleftiriscbeffmatchidx` | integer | Best left iris CBEFF match index | Mostly NULL. Iris match. | Low |
| 29 | `bestrightiriscbeffmatchidx` | integer | Best right iris CBEFF match index | Mostly NULL. Iris match. | Low |

### Packet & Source Info (columns 30–36)

| # | Column | Type | Description | Notes | Importance |
|---|--------|------|-------------|-------|------------|
| 30 | `packet_version` | varchar | Enrolment packet version | E.g. `3.1.0.0`, `3.2.0.0`, `4.7.0.3`. Indicates the software version used. | Low |
| 31 | `source` | varchar | Source system | E.g. `SEDA`, `MOU`. Identifies the enrolment workflow type. | Medium |
| 32 | `source_request_id` | varchar | Source request ID | Mostly NULL. | Low |
| 33 | `source_client_id` | varchar | Source client ID | E.g. `23030`, `65071`. | Low |
| 34 | `source_client_machine_id` | varchar | Source client machine ID | Device identifier (e.g. `LENOVOBD570A78-...`, `Dell Inc.ADD0A375-...`). | Low |
| 35 | `source_client_version` | varchar | Source client version | E.g. `3.1.0.0`, `4.7.0.3`. | Low |
| 36 | `created_by` | varchar | Source/creator of the record | E.g. `TEMPORAL WORKFLOW`, `STRUCTURAL WORKFLOW`, `enrolserver`. | Low |

### Audit & Shard (columns 37–40)

| # | Column | Type | Description | Notes | Importance |
|---|--------|------|-------------|-------|------------|
| 37 | `creation_date` | timestamp(6) | Record creation timestamp | | Medium |
| 38 | `last_updated_by` | varchar | Last updater | Typically `enrolserver`. | Medium |
| 39 | `last_updated_date` | timestamp(6) | Last update timestamp | | High |
| 40 | `shard_hint` | varchar | Sharding hint, basically first 2 digits of every Aadhaar number/UID, used for efficient querying as the MySQL sharding is done based on this | **Always use for partition pruning** — this table is 3.29B rows, full scans will time out. | High |

### Update Indicator Flags (columns 41–70)

> These are `varbinary` columns that indicate whether a specific resident field was updated in this enrolment event.
> - `b'00'` = field was **not** updated
> - `b'11'` = field **was** updated
> - Cast with `CAST(col AS varchar)` if you need to filter in SQL.

| # | Column | Type | Description (field tracked) | Importance |
|---|--------|------|----------------------------|------------|
| 41 | `updt_uid_status` | varbinary | UID status was updated | Medium |
| 42 | `updt_resident_name` | varbinary | Resident name was updated | High |
| 43 | `updt_resident_name_local` | varbinary | Resident name (local language) was updated | Low |
| 44 | `updt_dob` | varbinary | Date of birth was updated | High |
| 45 | `updt_dob_type` | varbinary | DOB type was updated | Low |
| 46 | `updt_gender` | varbinary | Gender was updated | Medium |
| 47 | `updt_guardian_details` | varbinary | Guardian details were updated | Medium |
| 48 | `updt_introducer_details` | varbinary | Introducer details were updated | Low |
| 49 | `updt_mobile_details` | varbinary | Mobile number was updated | High |
| 50 | `updt_email_details` | varbinary | Email ID was updated | Low |
| 51 | `updt_bank_sharing_cnst` | varbinary | Bank sharing consent was updated | Low |
| 52 | `updt_info_sharing_cnst` | varbinary | Info sharing consent was updated | Medium |
| 53 | `updt_resident_lang_code` | varbinary | Resident language code was updated | Low |
| 54 | `updt_hof_proof` | varbinary | Head-of-Family proof was updated | Medium |
| 55 | `updt_resident_dod` | varbinary | Date of death was updated | Medium |
| 56 | `updt_address` | varbinary | Address was updated | High |
| 57 | `updt_address_local` | varbinary | Address (local language) was updated | Low |
| 58 | `updt_extended_attributes` | varbinary | Extended attributes were updated | Low |
| 59 | `updt_photo` | varbinary | Photo was updated | Medium |
| 60 | `updt_exception_photo` | varbinary | Exception photo was updated | Low |
| 61 | `updt_biometric_exception` | varbinary | Biometric exception was updated | Low |
| 62 | `updt_biometrics` | varbinary | Biometrics were updated | Medium |
| 63 | `updt_nri` | varbinary | NRI flag was updated | Low |
| 64 | `updt_foreign_resident` | varbinary | Foreign resident flag was updated | Low |
| 65 | `updt_nationality` | varbinary | Nationality was updated | Low |
| 66 | `updt_poi` | varbinary | Proof of Identity was updated | High |
| 67 | `updt_pob` | varbinary | Proof of Date of Birth was updated | Medium |
| 68 | `updt_poa` | varbinary | Proof of Address was updated | High |
| 69 | `updt_extended_attributes` | varbinary | (duplicate — see #58) | Low |
| 70 | *(column 70 — see above)* | | | |

> **Note:** Columns 41–70 are `varbinary` flags. To check if a field was updated, use: `WHERE CAST(updt_address AS varchar) = '11'`

---

## Categorical Value Mappings

> ⚠️ Full-table aggregations time out on this 3.29B-row table. Distributions below are from a single shard sample (`shard_hint = '45'`, ~41.2M rows) and should be treated as **representative, not exact**. Shard 45 has ~1.25% of total rows.

### enr_type

| Code | Count (shard 45) | % | Meaning (inferred) |
|------|-------------------|---|--------------------|
| `N` | 18,227,224 | 44.3% | New enrolment |
| `D` | 14,083,401 | 34.2% | Demographic update |
| `B` | 8,777,753 | 21.3% | Biometric update |
| `C` | 82,069 | 0.2% | Child enrolment |
| `Q` | 12,660 | <0.1% | — |

### enr_mode

| Code | Count (shard 45) | % | Meaning |
|------|-------------------|---|---------|
| `OFFLINE` | 33,530,577 | 81.4% | Offline enrolment (device-based) |
| `ONLINE` | 7,652,530 | 18.6% | Online enrolment |

### enr_status

| Code | Count (shard 45) | % | Meaning (inferred) |
|------|-------------------|---|--------------------|
| `C` | 39,523,017 | 96.0% | Completed / processed |
| `R` | 1,644,557 | 4.0% | Registered / pending |
| `IP` | 15,533 | <0.1% | In progress |

### update_ind

| Value | Count (shard 45) | % | Meaning |
|-------|-------------------|---|---------|
| `true` | 41,183,072 | ~99.99% | Update to existing UID |
| `NULL` | 31 | <0.1% | Unspecified |
| `false` | 4 | <0.1% | New enrolment (very rare in this table) |

> **Note:** Almost all rows in this table are updates (`update_ind = true`). New enrolments appear to be stored elsewhere or in very small numbers here. Use `enr_type` = `N` to identify new enrolments instead.

### reject_ind

| Value | Count (shard 45) | % | Meaning |
|-------|-------------------|---|---------|
| `false` | 24,775,398 | 60.2% | Not rejected |
| `true` | 16,407,709 | 39.8% | Rejected |

### ischild

| Value | Count (shard 45) | % | Meaning |
|-------|-------------------|---|---------|
| `0` | 37,807,988 | 91.8% | Not a child enrolment |
| `1` | 3,375,119 | 8.2% | Child enrolment (requires guardian linkage) |

### source

| Code | Count (shard 45) | % | Meaning (inferred) |
|------|-------------------|---|--------------------|
| `ECMP` | 17,622,691 | 42.8% | Enrolment Client Multi-Platform |
| `UCS` | 15,127,116 | 36.7% | Universal Client Station |
| `SEDA` | 3,974,720 | 9.7% | Standard enrolment (SEDA workflow) |
| `UpdateSSP` | 1,862,123 | 4.5% | SSP update workflow |
| `UpdateMou` | 1,111,999 | 2.7% | MoU-based update workflow |
| `ECL` | 707,246 | 1.7% | ECL client |
| `UC` | 231,860 | 0.6% | Universal Client |
| `UpdateLite` | 164,235 | 0.4% | Lite update workflow |
| `UpdateRBA` | 163,596 | 0.4% | RBA update workflow |
| `UpdateCogent` | 103,925 | 0.3% | Cogent update workflow |
| `SSUP` | 78,931 | 0.2% | SSUP workflow |
| `MOU` | 22,005 | 0.1% | MoU-based enrolment |
| `QC` | 12,660 | <0.1% | Quality check |

### available_in_abis

| Value | Count (shard 45) | % | Meaning |
|-------|-------------------|---|---------|
| `1` | 23,392,880 | 56.8% | Biometrics available in ABIS |
| `0` | 17,790,227 | 43.2% | Biometrics not available in ABIS |

### packet_version

> Software version of the enrolment client. Highly varied (~200+ distinct values). Top values:

| Version | Count (shard 45) | Notes |
|---------|-------------------|-------|
| `3.3.4.2` | 16,802,600 | Most common (with many sub-variants like `3.3.4.2/208-2`) |
| `3.3.3.3` | 2,548,422 | |
| `3.0.0.0` | 2,500,286 | |
| `2.0.0.0` | 1,860,189 | |
| `3.2.0.0` | 1,583,610 | |
| `NULL` | 1,529,586 | |
| `2.2.1.0` | 1,475,525 | |
| `1.3.4.0` | 1,379,315 | |
| `3.1.0.0` | 1,370,747 | |
| (others) | smaller | Many sub-variants of `3.3.4.2` with suffixes |

### created_by (workflow type)
- `TEMPORAL WORKFLOW` — standard/temporal processing
- `STRUCTURAL WORKFLOW` — structural processing (newer)

---

## Date Ranges

> From shard 45 sample. `enr_date` has severe anomalies — filter with `WHERE enr_date > TIMESTAMP '2010-01-01'` for valid data.

| Column | Min | Max | Notes |
|--------|-----|-----|-------|
| `enr_date` | 0007-06-14 | 8205-04-22 | **Severe anomalies** — year 7 to year 8205. Filter for valid range. |
| `creation_date` | 2010-08-21 23:07:45 | 2026-10-09 02:31:10 | Valid range |
| `last_updated_date` | 2016-11-25 01:42:17 | 2026-10-09 02:31:10 | Valid range |

| Column | Shard 45 Range |
|--------|----------------|
| `tracker_key` | `1` – `43,519,660` |

---

## Sample Row (anonymized shape)

```
tracker_key         : 43255652
uid                 : <encrypted base64 blob>
refid               : 'b08fe5a1-f774-4eb4-8db4-9b198116c329'
eid                 : '2085230300345320160528163328'
enr_date            : 2016-05-28 16:33:28
enr_num             : '20852303003453'
enr_type            : 'D'
enr_mode            : 'OFFLINE'
enr_status          : 'R'
enr_status_date     : 2026-09-19 14:00:51
available_in_abis   : '0'
registrar_code      : '206'
ea_code             : '2085'
operator_id         : 'NPS_S_BhagyshrI'
supervisor_id       : NULL
upload_time         : 2016-05-28 16:33:28
update_ind          : false
reject_ind          : false
ischild             : '0'
linkedenrolment_eid : '2085230300345320160528163328'
packet_version      : '3.1.0.0'
source              : 'SEDA'
source_client_id    : '23030'
source_client_machine_id : 'LENOVOBD570A78-...'
source_client_version    : '3.1.0.0'
created_by          : 'TEMPORAL WORKFLOW'
creation_date       : 2026-09-19 14:00:51
last_updated_by     : 'enrolserver'
last_updated_date   : 2026-09-19 14:00:51
shard_hint          : '87'
updt_* (all)        : b'00' (no fields updated — new enrolment)
```

**Sample with updates (update enrolment):**
```
update_ind          : true
reject_ind          : true
enr_mode            : 'ONLINE'
source              : 'MOU'
created_by          : 'STRUCTURAL WORKFLOW'
updt_info_sharing_cnst : b'11' (info sharing consent updated)
updt_hof_proof        : b'11' (HoF proof updated)
updt_address (all others) : b'00' / b'11'
```

---

## Querying Guidance/ Rules (text-to-SQL)

1. **CRITICAL — Always scope queries.** This is a 3.29B-row table. Full scans will time out. Always use:
   - `shard_hint` filter (e.g. `WHERE shard_hint = '45'`) — **most important**
   - `tracker_key` range (e.g. `WHERE tracker_key <= 100000`)
   - `uid` filter for specific resident
   - `LIMIT N`
2. **Never run `COUNT(*)` or `GROUP BY` without a `shard_hint` filter** — it will time out.
3. **For distribution queries**, filter by a single `shard_hint` to get a representative sample (each shard has ~36M rows).
4. **Varbinary flags:** `updt_*` columns are `varbinary`. To filter, cast: `WHERE CAST(updt_address AS varchar) = '11'` (field was updated).
5. **Enrolment vs update:** Use `update_ind = false` for new enrolments, `update_ind = true` for updates to existing UIDs.
6. **Rejected enrolments:** Use `reject_ind = true` to find rejected packets.
7. **Correlating with history:** Join on `uid` + `eid` to link enrolment events to history snapshots in `uid_his_master` / `uid_his_address`.
8. **Registrar/Agency analysis:** Use `registrar_code` and `ea_code` for enrolment channel analysis.
9. **PII handling:** `uid` is encrypted. `operator_id`, `supervisor_id` are operator identifiers. Never attempt decryption.
10. **Date anomaly:** Some `enr_date` values are anomalous (e.g. year 99) — filter with `WHERE enr_date > TIMESTAMP '2010-01-01'` if needed.
11. **Read vs write:** run `SELECT` on read host `10.10.116.39`; No write is allowed on this table.
12. **Priority:** the importance is defined in the column dictionary, mostly problems are solved with High and Medium priority columns.
