# Text-to-SQL with GraphRAG — High-Level Design (HLD)

> **Version:** 2.0  
> **Date:** October 2026  
> **Status:** Production  
> **Author:** Data Platform Team

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [System Overview](#2-system-overview)
3. [Architecture](#3-architecture)
4. [Component Design](#4-component-design)
5. [Data Architecture](#5-data-architecture)
6. [Retrieval Pipeline](#6-retrieval-pipeline)
7. [LLM Integration](#7-llm-integration)
8. [Query Execution Layer](#8-query-execution-layer)
9. [Data Flow](#9-data-flow)
10. [Technology Stack](#10-technology-stack)
11. [Design Decisions](#11-design-decisions)
---

## 1. Executive Summary

### 1.1 Purpose

This document describes the architecture of a **text-to-SQL system** that converts natural-language questions about UID/Aadhaar data into Trino SQL queries, executes them, and returns results. The system uses a **GraphRAG (Graph Retrieval-Augmented Generation)** pattern to provide the LLM with rich, structured context about database schemas, column semantics, table relationships, and data quality rules.

### 1.2 Problem Statement

| Challenge | Solution |
|-----------|----------|
| Users need data from Trino but don't know SQL | Natural-language interface → SQL generation |
| 5 tables with 189 columns — LLM can't hold all schema context in prompt | GraphRAG retrieves only relevant context per query |
| Tables are massive (1.46B–3.29B rows) — naive SQL times out | Hard rules (shard_hint, LIMIT, date filters) injected into LLM prompt |
| Column names are cryptic (`updt_resident_name`, `res_dob_year`) | Entity descriptions + enriched natural-language questions in the graph |
| Varbinary columns require special handling (`from_utf8()` not `CAST`) | Data quality rules encoded as graph entities and query rules |
| Multi-table joins are complex (uid + eid + shard_hint, not just uid) | Join paths pre-computed and stored as graph relationships |

### 1.3 Key Metrics

| Metric | Value |
|--------|-------|
| Tables covered | 5 |
| Total entities in graph | 217 (5 tables, 189 columns, 10 concepts, 7 DQ issues, 3 hosts, 3 join keys) |
| Relationships | 343 |
| Text units (descriptions + enriched questions) | 321 |
| Pre-computed query paths | 12 |
| Retrieval top-5 recall | 100% |
| Retrieval top-1 accuracy (with LLM re-ranking) | 85% |
| End-to-end latency (question → SQL) | 5–40s (LLM-bound) |
| LLM API calls per query | 2 (re-ranking + SQL generation) |
| LLM model | GLM-5.2-FP8 (served via vLLM, OpenAI-compatible API) |
| Database for GraphRAG storage | PostgreSQL 16 + pgvector 0.8.7 |

---

## 2. System Overview

### 2.1 Scope

The system provides a natural-language interface to query UID/Aadhaar data stored in Trino. It covers:

- **Schema `strot.mysql_uid_v2`** containing 5 tables
- **Read-only access** via Trino read host (no writes)
- **Single-shard sampling** for large tables (shard_hint predicate mandatory)

### 2.2 Tables Covered

| Table | Rows | Description | Role |
|-------|------|-------------|------|
| `uid_master` | 1.46B | Current identity & demographic data per UID | Primary source table |
| `uid_his_master` | 2.77B | History of uid_master (one row per update event) | Historical demographics |
| `uid_address` | 1.46B | Current address per UID (1:1 with uid_master) | Current address |
| `uid_his_address` | 2.77B | History of uid_address | Historical addresses |
| `uid_origin_tracker_enriched` | 3.29B | Enrolment/update event tracker with update flags | Enrolment metadata + update tracking |

### 2.3 Users

| User Type | Access Pattern |
|-----------|---------------|
| Data analysts | Ask questions in natural language, get SQL + results |
| Business users | Ask questions, get results (SQL hidden) |
| Developers | Extend context layer (add tables, update descriptions) |

### 2.4 Key Constraints

- **No internet access** in the deployment environment — cannot install Python packages at runtime
- **LLM is the bottleneck** (5–40s per query), not storage or retrieval
- **Tables are sharded** — all queries must include `shard_hint` predicate for partition pruning
- **Varbinary columns** require `from_utf8()` not `CAST()` — a Trino-specific quirk
- **Read-only** — no writes to any table, ever

---

## 3. Architecture

### 3.1 Architecture Diagram

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                              SYSTEM ARCHITECTURE                              │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────┐                                                            │
│  │   User      │                                                            │
│  │  Question   │                                                            │
│  └──────┬──────┘                                                            │
│         │                                                                    │
│         ▼                                                                    │
│  ┌──────────────────────────────────────────────────────────────────┐       │
│  │                    TEXT-TO-SQL PIPELINE                          │       │
│  │                     (text_to_sql.py)                             │       │
│  │                                                                  │       │
│  │  ┌─────────────────────────────────────────────────────────┐    │       │
│  │  │  STEP 1: GraphRAG RETRIEVAL                              │    │       │
│  │  │                                                          │    │       │
│  │  │  ┌─────────────────────┐    ┌────────────────────────┐ │    │       │
│  │  │  │  Stage 1: Retrieval │    │  Stage 2: LLM Re-rank  │ │    │       │
│  │  │  │  (PostgreSQL FTS)   │───▶│  (GLM-5.2-FP8)         │ │    │       │
│  │  │  │                     │    │                        │ │    │       │
│  │  │  │  • Synonym expansion│    │  • Re-rank top 10      │ │    │       │
│  │  │  │  • websearch_to_   │    │    candidates by       │ │    │       │
│  │  │  │    tsquery (BM25)  │    │    semantic relevance  │ │    │       │
│  │  │  │  • ts_rank scoring │    │  • Score 0–10 each     │ │    │       │
│  │  │  │  • Graph expansion │    │  • Return sorted list  │ │    │       │
│  │  │  │    via SQL JOINs   │    │                        │ │    │       │
│  │  │  │  • 100% recall     │    │  • 85% top-1 accuracy  │ │    │       │
│  │  │  └─────────┬──────────┘    └───────────┬────────────┘ │    │       │
│  │  │            │                           │              │    │       │
│  │  │            └───────────┬───────────────┘              │    │       │
│  │  │                        ▼                              │    │       │
│  │  └────────────────────────┼──────────────────────────────┘    │       │
│  │                           │                                   │       │
│  │  ┌────────────────────────▼──────────────────────────────┐    │       │
│  │  │  STEP 2: CONTEXT ASSEMBLY                              │    │       │
│  │  │                                                        │    │       │
│  │  │  • Fetch table schemas (columns, types, descriptions)│    │       │
│  │  │  • Fetch join paths (which tables connect, on what)  │    │       │
│  │  │  • Fetch data quality warnings                       │    │       │
│  │  │  • Fetch query rules (shard_hint, from_utf8, etc.)   │    │       │
│  │  │  • Build structured prompt (~15K–28K chars)          │    │       │
│  │  └────────────────────────┬──────────────────────────────┘    │       │
│  │                           │                                   │       │
│  │  ┌────────────────────────▼──────────────────────────────┐    │       │
│  │  │  STEP 3: LLM SQL GENERATION     ★ LLM CALL #2        │    │       │
│  │  │                                                        │    │       │
│  │  │  System prompt: Trino SQL expert + 9 hard rules       │    │       │
│  │  │  User prompt: Context + question                      │    │       │
│  │  │  → Generates Trino SQL query                          │    │       │
│  │  │  → Post-processing: strip semicolons, add LIMIT       │    │       │
│  │  └────────────────────────┬──────────────────────────────┘    │       │
│  │                           │                                   │       │
│  │  ┌────────────────────────▼──────────────────────────────┐    │       │
│  │  │  STEP 4: EXPLAIN VALIDATION (optional)                │    │       │
│  │  │                                                        │    │       │
│  │  │  • Run EXPLAIN <sql> on Trino                         │    │       │
│  │  │  • Catch syntax errors before execution               │    │       │
│  │  │  • Skip if EXPLAIN fails (let user see error)         │    │       │
│  │  └────────────────────────┬──────────────────────────────┘    │       │
│  │                           │                                   │       │
│  │  ┌────────────────────────▼──────────────────────────────┐    │       │
│  │  │  STEP 5: QUERY EXECUTION (optional)                   │    │       │
│  │  │                                                        │    │       │
│  │  │  • Execute SQL on Trino read host                     │    │       │
│  │  │  • Return results as DataFrame                         │    │       │
│  │  └────────────────────────┬──────────────────────────────┘    │       │
│  │                           │                                   │       │
│  └───────────────────────────┼───────────────────────────────────┘       │
│                              │                                           │
│         ┌────────────────────┼────────────────────┐                     │
│         ▼                    ▼                    ▼                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐          │
│  │  PostgreSQL  │  │  GLM-5.2-FP8 │  │      Trino           │          │
│  │  (GraphRAG)  │  │  (LLM API)   │  │   (Query Engine)     │          │
│  │              │  │              │  │                      │          │
│  │  Port 5432   │  │  Port 32320  │  │  Read Host:          │          │
│  │  Container   │  │  vLLM serve  │  │  10.10.116.39        │          │
│  │              │  │              │  │                      │          │
│  │  • Entities  │  │  • Reasoning │  │  • strot.mysql_uid_  │          │
│  │  • Relations │  │    model     │  │    v2 schema         │          │
│  │  • FTS (BM25)│  │  • 524K ctx  │  │  • 5 tables          │          │
│  │  • pgvector  │  │  • No auth   │  │  • 1.46B–3.29B rows  │          │
│  │              │  │              │  │  • Read-only         │          │
│  └──────────────┘  └──────────────┘  └──────────────────────┘          │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Architectural Patterns

| Pattern | Where | Why |
|---------|-------|-----|
| **RAG (Retrieval-Augmented Generation)** | Steps 1–3 | LLM can't hold 189 column descriptions in prompt; retrieve only relevant context |
| **Two-stage retrieval** | Step 1 | Stage 1 (FTS) ensures high recall; Stage 2 (LLM) ensures high precision |
| **GraphRAG** | Step 1 + graph expansion | Relationships (HAS_COLUMN, JOINS_TO) enrich context beyond flat document retrieval |
| **Knowledge graph** | PostgreSQL | Entities + relationships stored as structured data, not just text chunks |
| **Prompt engineering** | Step 3 | Hard rules (shard_hint, from_utf8, TRY_CAST) prevent dangerous SQL on large tables |
| **Graceful degradation** | Fallback retriever | If PostgreSQL is down, falls back to JSON + BM25 |

### 3.3 Design Principles

1. **Entity-specific documents** — Each TF-IDF/BM25 document contains only information about that entity. Relationships are navigated via graph edges, not embedded in document text. This eliminates 30–50% term overlap between table and column documents.

2. **Synonym expansion is deterministic** — 34 hardcoded synonym groups bridge the lexical gap (e.g., "changed" → {update, updt, modified, changed}). Not LLM-generated — for speed (milliseconds) and determinism.

3. **LLM is used sparingly** — Only 2 LLM calls per query: re-ranking (Stage 2) and SQL generation (Step 3). Everything else is deterministic (SQL queries, string building, Trino execution).

4. **Read-only by design** — No writes to any database. PostgreSQL stores the GraphRAG index (metadata about tables), Trino stores the actual data (1.46B–3.29B rows per table). Neither is modified by user queries.

5. **Fallback resilience** — If PostgreSQL is unavailable, the system falls back to CleanGraphRAG (JSON file + BM25 from scratch). Same interface, same results, slightly slower initialization.

---

## 4. Component Design

### 4.1 Component Map

```
┌─────────────────────────────────────────────────────────────────────┐
│                        COMPONENT MAP                                 │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Layer 1: ORCHESTRATION                                             │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  text_to_sql.py — TextToSQL class                         │     │
│  │  • Pipeline orchestrator (5 steps)                        │     │
│  │  • Context assembly (builds LLM prompt)                   │     │
│  │  • SQL post-processing (strip semicolons, add LIMIT)      │     │
│  │  • EXPLAIN validation + Trino execution                   │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Layer 2: RETRIEVAL                                                 │
│  ┌───────────────────────────┐  ┌───────────────────────────┐     │
│  │  postgres_retriever.py    │  │  clean_retriever.py       │     │
│  │  PostgresGraphRAG         │  │  CleanGraphRAG (fallback) │     │
│  │                           │  │                           │     │
│  │  • PostgreSQL FTS (BM25)  │  │  • BM25 from scratch      │     │
│  │  • SQL JOIN graph expand  │  │  • Python dict traversal  │     │
│  │  • Synonym expansion      │  │  • Synonym expansion      │     │
│  │  • LLM re-rank (optional) │  │  • LLM re-rank (optional) │     │
│  │  • vector_search() ready  │  │                           │     │
│  └───────────────────────────┘  └───────────────────────────┘     │
│                                                                     │
│  Layer 3: LLM CLIENT                                                │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  llm_client.py — LLMClient class                          │     │
│  │  • Direct HTTP to GLM-5.2-FP8 (no SDK dependency)        │     │
│  │  • chat(), chat_json(), batch_chat()                      │     │
│  │  • rerank() — Stage 2 re-ranking                          │     │
│  │  • generate_sql() — Step 3 SQL generation                 │     │
│  │  • health_check()                                         │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Layer 4: DATA STORAGE                                              │
│  ┌───────────────────────────┐  ┌───────────────────────────┐     │
│  │  PostgreSQL 16            │  │  Trino                    │     │
│  │  (GraphRAG metadata)     │  │  (Source data)            │     │
│  │                           │  │                           │     │
│  │  • entities (217)         │  │  • uid_master (1.46B)     │     │
│  │  • relationships (343)    │  │  • uid_his_master (2.77B) │     │
│  │  • text_units (321)       │  │  • uid_address (1.46B)    │     │
│  │  • communities (5)        │  │  • uid_his_address (2.77B)│     │
│  │  • query_paths (12)       │  │  • uid_origin_tracker_    │     │
│  │  • pgvector (HNSW index)  │  │    enriched (3.29B)       │     │
│  └───────────────────────────┘  └───────────────────────────┘     │
│                                                                     │
│  Layer 5: CONTEXT FILES (source of truth)                          │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  C:\data-platform-context\                                │     │
│  │  • strot.mysql_uid_v2.uid_master.md / .yaml              │     │
│  │  • strot.mysql_uid_v2.uid_his_master.md / .yaml          │     │
│  │  • strot.mysql_uid_v2.uid_address.md / .yaml             │     │
│  │  • strot.mysql_uid_v2.uid_his_address.md / .yaml         │     │
│  │  • strot.mysql_uid_v2.uid_origin_tracker_enriched.md/.yaml│    │
│  │  • relationship.md (living document)                     │     │
│  │  • knowledge_graph.md / .yaml / .html                   │     │
│  └───────────────────────────────────────────────────┘     │     │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 4.2 Component Specifications

#### 4.2.1 TextToSQL (`text_to_sql.py`)

| Attribute | Value |
|-----------|-------|
| **Role** | Pipeline orchestrator |
| **Input** | Natural-language question (string) |
| **Output** | SQL query (string) + optional results (DataFrame) |
| **LLM calls** | 0 (delegates to retriever + LLMClient) |
| **Key methods** | `generate(question, execute, explain)` |
| **Retriever** | PostgresGraphRAG (primary), CleanGraphRAG (fallback) |
| **Context size** | 15K–28K chars (assembled from retrieval results) |

#### 4.2.2 PostgresGraphRAG (`postgres_retriever.py`)

| Attribute | Value |
|-----------|-------|
| **Role** | Two-stage retrieval (FTS + optional LLM re-ranking) |
| **Input** | Natural-language query (string) |
| **Output** | Ranked list of entities with graph neighbors |
| **Stage 1** | PostgreSQL `websearch_to_tsquery` + `ts_rank` (BM25) |
| **Stage 2** | GLM-5.2-FP8 LLM re-ranking (optional) |
| **Graph expansion** | SQL JOINs on `relationships` table + `v_neighbors` view |
| **Recall** | 100% top-5 (Stage 1) |
| **Precision** | 85% top-1 (Stage 1 + Stage 2) |
| **Query time** | ~1.1s per query (docker exec overhead; ~0.01s with native driver) |
| **Interface** | `search()`, `get_table_context()`, `get_join_path()`, `vector_search()` |

#### 4.2.3 LLMClient (`llm_client.py`)

| Attribute | Value |
|-----------|-------|
| **Role** | Direct HTTP wrapper for GLM-5.2-FP8 API |
| **API** | `http://10.10.109.101:32320/glm52/v1` (OpenAI-compatible, vLLM) |
| **Auth** | None (internal network) |
| **Context window** | 524,288 tokens |
| **Model type** | Reasoning model (`reasoning` field = thinking, `content` field = answer) |
| **Key constraint** | `max_tokens` must be ≥500 (model runs out during reasoning otherwise) |
| **Methods** | `chat()`, `chat_json()`, `batch_chat()`, `rerank()`, `generate_sql()`, `health_check()` |

#### 4.2.4 PostgreSQL (GraphRAG Storage)

| Attribute | Value |
|-----------|-------|
| **Image** | `pgvector/pgvector:pg16` |
| **Port** | 5432 |
| **Database** | `graphrag` |
| **Extensions** | `vector` (pgvector 0.8.7), `uuid-ossp` |
| **Tables** | `entities`, `relationships`, `text_units`, `communities`, `query_paths` |
| **Views** | `v_columns`, `v_joins`, `v_neighbors` |
| **Full-text search** | `tsvector` columns + GIN indexes + `websearch_to_tsquery` |
| **Vector search** | `VECTOR(768)` column + HNSW index (ready, embeddings not yet populated) |
| **Graph traversal** | SQL JOINs on `relationships` table (B-tree indexes on source_id, target_id, type) |
| **Volume** | 217 entities, 343 relationships, 321 text units, 5 communities, 12 query paths |

#### 4.2.5 Trino (Query Execution)

| Attribute | Value |
|-----------|-------|
| **Role** | Distributed SQL query engine for source data |
| **Read host** | `10.10.116.39` |
| **Schema** | `strot.mysql_uid_v2` |
| **Access** | Read-only (SELECT only, no writes) |
| **Query module** | `strot_query` (imported as `sq`) |
| **Table sizes** | 1.46B – 3.29B rows per table |
| **Sharding** | `shard_hint` column (first 2 digits of UID) for partition pruning |
| **Return format** | `{'query': str, 'success': int, 'data': (columns, rows), 'df': DataFrame}` |

---

## 5. Data Architecture

### 5.1 PostgreSQL Schema (GraphRAG Metadata)

```
┌─────────────────────────────────────────────────────────────────────┐
│                    POSTGRESQL SCHEMA                                 │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  entities                                                 │     │
│  │  ─────────                                                │     │
│  │  entity_id       TEXT PK                                  │     │
│  │  name            TEXT                                     │     │
│  │  type            TEXT (TABLE|COLUMN|CONCEPT|DQ_ISSUE|...) │     │
│  │  description     TEXT                                     │     │
│  │  properties      JSONB (data_type, importance, notes)     │     │
│  │  search_text     TEXT (clean, entity-specific only)       │     │
│  │  tsv             TSVECTOR (auto from search_text)         │     │
│  │  embedding       VECTOR(768) (NULL — for future use)      │     │
│  │  created_at      TIMESTAMPTZ                              │     │
│  │  updated_at      TIMESTAMPTZ                              │     │
│  │                                                           │     │
│  │  Indexes:                                                 │     │
│  │  • GIN(tsv)           — full-text search                  │     │
│  │  • GIN(properties)    — JSONB property lookup             │     │
│  │  • HNSW(embedding)    — vector ANN search (future)        │     │
│  │  • B-tree(type, name) — entity type/name lookup           │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  relationships                                            │     │
│  │  ────────────                                             │     │
│  │  id              SERIAL PK                                │     │
│  │  source_id       TEXT FK → entities                       │     │
│  │  target_id       TEXT FK → entities                       │     │
│  │  type            TEXT (HAS_COLUMN|JOINS_TO|HAS_CONCEPT|.) │     │
│  │  description     TEXT                                     │     │
│  │  properties      JSONB (join_keys, cardinality)           │     │
│  │                                                           │     │
│  │  Indexes:                                                 │     │
│  │  • B-tree(source_id, type) — outgoing edges               │     │
│  │  • B-tree(target_id, type) — incoming edges               │     │
│  │  • GIN(properties)         — join key lookup              │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  text_units                                               │     │
│  │  ──────────                                               │     │
│  │  unit_id         TEXT PK                                  │     │
│  │  entity_id       TEXT FK → entities                       │     │
│  │  text            TEXT (natural-language description)      │     │
│  │  source          TEXT (original | llm_enriched)           │     │
│  │  tsv             TSVECTOR (auto from text)                │     │
│  │                                                           │     │
│  │  Indexes:                                                 │     │
│  │  • GIN(tsv)           — full-text search on text units    │     │
│  │  • B-tree(entity_id)  — lookup by entity                  │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  communities                                              │     │
│  │  ───────────                                              │     │
│  │  community_id    TEXT PK                                  │     │
│  │  title           TEXT                                     │     │
│  │  summary         TEXT                                     │     │
│  │  entity_count    INTEGER                                  │     │
│  │  entity_ids      TEXT[] (array of entity IDs)             │     │
│  │  key_relationships TEXT[]                                 │     │
│  │  query_examples  TEXT[]                                   │     │
│  │  report          TEXT                                     │     │
│  │                                                           │     │
│  │  Indexes:                                                 │     │
│  │  • GIN(entity_ids)   — membership lookup                  │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  query_paths                                              │     │
│  │  ───────────                                              │     │
│  │  id              SERIAL PK                                │     │
│  │  start_table     TEXT                                     │     │
│  │  need            TEXT (what this path answers)            │     │
│  │  joins           JSONB ([{to, on, cardinality}, ...])     │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Views:                                                             │
│  • v_columns  — all columns with parent table (HAS_COLUMN JOIN)    │
│  • v_joins    — all table-to-table joins (JOINS_TO JOIN)           │
│  • v_neighbors — entity neighbors (bidirectional graph expansion)  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 5.2 Entity Types

| Type | Count | Examples |
|------|-------|---------|
| TABLE | 5 | `uid_master`, `uid_origin_tracker_enriched` |
| COLUMN | 189 | `uid_master.res_dod`, `uid_origin_tracker_enriched.updt_resident_name` |
| CONCEPT | 10 | `Demographics`, `Update Tracking`, `Enrolment` |
| DATA_QUALITY_ISSUE | 7 | `Legacy 'N' Values`, `Varbinary Update Flags`, `enr_date Anomalies` |
| JOIN_KEY | 3 | `uid`, `eid`, `shard_hint` |
| HOST | 3 | `10.10.116.39` (read), `10.10.109.101` (LLM) |

### 5.3 Relationship Types

| Type | Count | Description |
|------|-------|-------------|
| HAS_COLUMN | 189 | Table → Column |
| JOINS_TO | 6 | Table → Table (with join_keys, cardinality) |
| HAS_CONCEPT | ~10 | Entity → Concept |
| AFFECTS | 7 | Data quality issue → Column/Table |
| DEPENDS_ON | ~3 | Query path dependencies |

### 5.4 Graph Topology

```
                    ┌─────────────┐
                    │  uid_master │
                    │  (1.46B)    │
                    └──────┬──────┘
                           │
              ┌────────────┼────────────┐
              │ JOINS_TO   │ JOINS_TO   │ HAS_COLUMN (30 columns)
              │ 1:N        │ 1:1        │
              ▼            ▼            ▼
     ┌──────────────┐ ┌──────────────┐ ┌────────────┐
     │uid_his_master│ │ uid_address  │ │ res_dod    │
     │ (2.77B)      │ │ (1.46B)      │ │ res_dob_year│
     └──────┬───────┘ └──────┬───────┘ │ uid_status  │
            │                │         │ ...         │
            │ JOINS_TO       │ JOINS_TO│             │
            │ 1:N            │ 1:N     │             │
            ▼                ▼         └────────────┘
     ┌──────────────┐ ┌──────────────┐
     │uid_his_address│ │uid_his_address│
     │ (2.77B)      │ │ (2.77B)      │
     └──────┬───────┘ └──────────────┘
            │
            │ JOINS_TO (1:N)
            │ on uid + eid + shard_hint
            │
    ┌───────┴──────────────┐
    │uid_origin_tracker_   │
    │enriched (3.29B)      │
    │                      │
    │ 68 columns including │
    │ 25 updt_* flags      │
    └──────────────────────┘
```

### 5.5 Clean Document Design

Each entity's `search_text` (indexed for full-text search) contains **only entity-specific information** — no cross-entity leakage:

| Entity Type | search_text contains | search_text does NOT contain |
|-------------|---------------------|------------------------------|
| COLUMN | column name, description, data_type, notes, enriched questions | table name prefix, community title, other columns' info |
| TABLE | table name, description, warning, row count, column count | community title, all column names, host info, full_reference |
| CONCEPT | concept name, description | member column names |
| COMMUNITY | title, summary, query examples | member entity names (use entity_ids array + JOIN) |

**Rationale:** Eliminates 30–50% term overlap between table and column documents. Relationships are navigated via graph edges (SQL JOINs), not shared text tokens.

---

## 6. Retrieval Pipeline

### 6.1 Two-Stage Retrieval

```
┌──────────────────────────────────────────────────────────────────────┐
│                    TWO-STAGE RETRIEVAL PIPELINE                       │
├──────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  User Question: "has the name been updated"                          │
│  Tokens: [has, name, updated]                                        │
│                                                                      │
│  ┌───────────────────────────────────────────────────────────┐      │
│  │  SYNONYM EXPANSION (deterministic, hardcoded)             │      │
│  │                                                           │      │
│  │  name → {name, resident_name, full_name}                  │      │
│  │  updated → {updated, updt, update, changed, modified}     │      │
│  │                                                           │      │
│  │  Result: "has name OR resident_name OR full_name          │      │
│  │           updated OR updt OR update OR changed OR modified"│     │
│  │                                                           │      │
│  │  34 synonym groups covering: update, death, address,      │      │
│  │  document, identity, age, gender, phone, foreigner, etc.  │      │
│  └───────────────────────────────┬───────────────────────────┘      │
│                                  │                                   │
│                                  ▼                                   │
│  ┌───────────────────────────────────────────────────────────┐      │
│  │  STAGE 1: PostgreSQL FULL-TEXT SEARCH                     │      │
│  │  (websearch_to_tsquery + ts_rank, index-backed)           │      │
│  │                                                           │      │
│  │  SQL:                                                     │      │
│  │    SELECT entity_id, name, type, description, properties, │      │
│  │           ts_rank(tsv, websearch_to_tsquery(...)) AS score│      │
│  │    FROM entities                                          │      │
│  │    WHERE tsv @@ websearch_to_tsquery(...)                 │      │
│  │    ORDER BY score DESC                                    │      │
│  │    LIMIT 30                                               │      │
│  │                                                           │      │
│  │  + Graph expansion (SQL JOIN on v_neighbors):             │      │
│  │    SELECT ... FROM search_results                         │      │
│  │    LEFT JOIN v_neighbors ON ...                           │      │
│  │    LEFT JOIN text_units ON ...                            │      │
│  │                                                           │      │
│  │  Result: 10–15 entities with neighbors and text units     │      │
│  │  Recall: 100% (expected entity always in top-5)           │      │
│  │  Time: ~1.1s (docker exec) / ~0.01s (native driver)       │      │
│  └───────────────────────────────┬───────────────────────────┘      │
│                                  │                                   │
│                                  ▼                                   │
│  ┌───────────────────────────────────────────────────────────┐      │
│  │  STAGE 2: LLM RE-RANKING (optional, GLM-5.2-FP8)         │      │
│  │                                                           │      │
│  │  Send top-10 candidates to LLM:                           │      │
│  │    "Rank these 10 items by relevance to the query.        │      │
│  │     Return JSON with scores 0–10."                        │      │
│  │                                                           │      │
│  │  LLM understands semantics that FTS can't:                │      │
│  │    • "age" → res_dob_year (age = birth year)              │      │
│  │    • "person alive" → res_dod (NULL dod = alive)          │      │
│  │    • "name changed" → updt_resident_name (not updt_dob)   │      │
│  │                                                           │      │
│  │  Result: candidates re-sorted by LLM score                │      │
│  │  Precision: 85% top-1 (after re-ranking)                  │      │
│  │  Time: 3–8s                                               │      │
│  └───────────────────────────────┬───────────────────────────┘      │
│                                  │                                   │
│                                  ▼                                   │
│  Top results: uid_origin_tracker_enriched.updt_resident_name        │
│               uid_origin_tracker_enriched (table)                   │
│               Update Tracking (concept)                             │
│               uid_origin_tracker_enriched.updt_resident_name_local  │
│               ...                                                    │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

### 6.2 Synonym Expansion

The system uses 34 hardcoded synonym groups to bridge the lexical gap between user vocabulary and database schema vocabulary.

| User Word | Synonym Group | Database Columns Matched |
|-----------|--------------|-------------------------|
| changed | {update, updt, modified, changed} | updt_resident_name, updt_dob, ... |
| dead | {death, dod, deceased, died, alive} | res_dod, updt_resident_dod |
| document | {proof, poi, poa, pob} | poi, poa, pob, hof_proof |
| age | {age, dob, birth, year, old} | res_dob_year, updt_dob |
| phone | {phone, mobile, number} | res_mobile_num_hash |
| foreigner | {foreigner, foreign, nri, nationality} | isforeigner, isnri |

**Design decision:** Synonym expansion is hardcoded (not LLM-generated) for:
- **Speed:** Milliseconds vs 3–8s for an LLM call
- **Determinism:** Same input always produces same output
- **Control:** Domain experts curate the mappings

### 6.3 Graph Expansion

After full-text search finds matching entities, graph expansion enriches the results with related entities:

```
FTS match: uid_origin_tracker_enriched.updt_resident_name
    │
    ├── HAS_COLUMN → uid_origin_tracker_enriched (parent table)
    ├── HAS_CONCEPT → Update Tracking (concept)
    └── AFFECTS → Varbinary Update Flags (data quality issue)
         └── Describes: b'00' = not updated, b'11' = updated
             └── Query rule: use from_utf8(col) = '11', NOT CAST(col AS varchar)
```

This ensures the LLM receives not just the matching column, but its parent table, related concepts, and critical data quality rules — all in one retrieval step.

### 6.4 Retrieval Performance

| Metric | Stage 1 only (FTS) | Stage 1 + Stage 2 (FTS + LLM) |
|--------|:---:|:---:|
| Top-1 accuracy | 13/20 (65%) | **17/20 (85%)** |
| Top-5 recall | 20/20 (100%) | 20/20 (100%) |
| Latency | ~1.1s | ~1.1s + 3–8s LLM |
| LLM calls | 0 | 1 |

---

## 7. LLM Integration

### 7.1 GLM-5.2-FP8 Model

| Attribute | Value |
|-----------|-------|
| **Model** | GLM-5.2-FP8 |
| **Type** | Reasoning model (chain-of-thought) |
| **Serving** | vLLM (OpenAI-compatible API) |
| **Endpoint** | `http://10.10.109.101:32320/glm52/v1` |
| **Auth** | None (internal network) |
| **Context window** | 524,288 tokens |
| **Response fields** | `content` (final answer), `reasoning` (thinking process) |
| **Key constraint** | `max_tokens` must be ≥500 (reasoning consumes tokens before answer) |
| **Response time** | 0.7–25s (varies by prompt complexity) |

### 7.2 LLM Call #1: Re-ranking

| Attribute | Value |
|-----------|-------|
| **Purpose** | Re-rank Stage 1 candidates by semantic relevance |
| **Input** | User question + 10 candidate entity descriptions |
| **Input size** | ~2,000 tokens |
| **Output** | JSON array of `{index, score}` (0–10) |
| **Output size** | ~500 tokens |
| **Latency** | 3–8s |
| **Example** | Query "age" → LLM scores res_dob_year highest (understands age = birth year) |

### 7.3 LLM Call #2: SQL Generation

| Attribute | Value |
|-----------|-------|
| **Purpose** | Generate Trino SQL from retrieved context + user question |
| **Input** | System prompt (9 hard rules) + context (15K–28K chars) + question |
| **Input size** | ~5,000 tokens |
| **Output** | Trino SQL query |
| **Output size** | ~300 tokens |
| **Latency** | 2–12s |

### 7.4 SQL Generation Rules (System Prompt)

The LLM receives 9 hard rules injected into the system prompt:

| # | Rule | Rationale |
|---|------|-----------|
| 1 | Always include `WHERE shard_hint = 'XX'` | Tables are sharded; full scans time out |
| 2 | Use `from_utf8(col) = '11'` for varbinary | `CAST(varbinary AS varchar)` throws in Trino |
| 3 | Use `TRY_CAST(res_dob_year AS integer)` | Some values are non-numeric |
| 4 | Filter `enr_date > TIMESTAMP '2010-01-01'` | enr_date has anomalies (year 7–8205) |
| 5 | Always add `LIMIT 100` if missing | Prevents massive result sets |
| 6 | Strip trailing semicolons | Trino doesn't accept them |
| 7 | Join on uid + eid + shard_hint (not just uid) | uid alone causes cartesian explosion |
| 8 | Use `count(DISTINCT uid)` for counts | UIDs appear in multiple rows |
| 9 | Never write to any table | Read-only access |

### 7.5 LLM Call Flow

```
                    ┌──────────────────┐
                    │  User Question   │
                    └────────┬─────────┘
                             │
                             ▼
                    ┌──────────────────┐
                    │  Synonym Expand  │  ──── No LLM (hardcoded dict)
                    └────────┬─────────┘
                             │
                             ▼
                    ┌──────────────────┐
                    │  PostgreSQL FTS  │  ──── No LLM (ts_rank BM25)
                    └────────┬─────────┘
                             │
                             ▼
                    ┌──────────────────┐
                    │  LLM Re-rank     │  ★ CALL #1 (3–8s)
                    │  (10 candidates) │
                    └────────┬─────────┘
                             │
                             ▼
                    ┌──────────────────┐
                    │  Context Assembly│  ──── No LLM (SQL + string building)
                    └────────┬─────────┘
                             │
                             ▼
                    ┌──────────────────┐
                    │  LLM SQL Gen     │  ★ CALL #2 (2–12s)
                    │  (context + q)   │
                    └────────┬─────────┘
                             │
                             ▼
                    ┌──────────────────┐
                    │  EXPLAIN + Exec  │  ──── No LLM (Trino)
                    └──────────────────┘

    Total LLM calls: 2
    Total LLM time:  5–20s
    Total pipeline:  6–22s (LLM-bound)
```

---

## 8. Query Execution Layer

### 8.1 Trino Integration

The system queries Trino via the `strot_query` module:

```python
import strot_query as sq

result = sq.query("SELECT uid_status_key, count(*) FROM strot.mysql_uid_v2.uid_master WHERE shard_hint = '45' GROUP BY uid_status_key")
# result = {
#     'query': 'SELECT ...',
#     'success': 1,
#     'data': (['uid_status_key', '_col1'], [('A', 12345), ...]),
#     'df': DataFrame
# }
```

### 8.2 EXPLAIN Validation

Before executing generated SQL, the system optionally runs `EXPLAIN`:

```sql
EXPLAIN (TYPE LOGICAL)
SELECT uid_status_key, count(*) 
FROM strot.mysql_uid_v2.uid_master 
WHERE shard_hint = '45' 
GROUP BY uid_status_key
```

- **Pass** → SQL is syntactically valid, proceed to execution
- **Fail** → Return error to user, don't execute

### 8.3 SQL Post-Processing

| Step | Operation | Reason |
|------|-----------|--------|
| 1 | Strip trailing semicolons | Trino doesn't accept `;` |
| 2 | Add `LIMIT 100` if no LIMIT clause | Prevents massive result sets |
| 3 | Validate `shard_hint` presence | Warns if missing (not a hard block) |

### 8.4 Query Execution Safety

| Safety Measure | Implementation |
|----------------|---------------|
| Read-only host | All queries go to read host `10.10.116.39` |
| No DDL/DML | LLM system prompt prohibits writes; EXPLAIN catches DDL |
| Shard pruning | System prompt mandates `shard_hint` in WHERE clause |
| Result limiting | `LIMIT 100` auto-added if missing |
| Date filtering | `enr_date > TIMESTAMP '2010-01-01'` for tracker table |

---

## 9. Data Flow

### 9.1 End-to-End Flow

```
User: "how many uids by status in shard 45"
  │
  │  1. TOKENIZE + SYNONYM EXPAND
  │     "status" → {status, active, deactivated, expired}
  │     "shard" → {shard, shard_hint, partition}
  │     "how many" → {count, count, total, number}
  │
  ▼  2. POSTGRESQL FULL-TEXT SEARCH (Stage 1)
  │     SQL: SELECT ... WHERE tsv @@ websearch_to_tsquery(...)
  │     → uid_master.uid_status_key (score: 0.97)
  │     → uid_master (score: 0.85)
  │     → uid_his_master.uid_status_key (score: 0.79)
  │     → uid_master.uid_expiry_date (score: 0.60)
  │     → ... (10 results total)
  │     + Graph expansion: each result enriched with neighbors
  │
  ▼  3. LLM RE-RANKING (Stage 2)                    ★ CALL #1
  │     Send 10 candidates to GLM-5.2-FP8
  │     LLM understands "status" = uid_status_key (not expiry_date)
  │     → uid_master.uid_status_key (LLM score: 9/10)
  │     → uid_his_master.uid_status_key (8/10)
  │     → uid_master (7/10)
  │     → ...
  │
  ▼  4. CONTEXT ASSEMBLY
  │     • Table: uid_master (30 columns, description, warning)
  │     • Table: uid_his_master (30 columns, description)
  │     • Join: uid_master → uid_his_master (1:N on uid, shard_hint)
  │     • Column: uid_status_key (varchar, High importance)
  │     • Rule: shard_hint mandatory, LIMIT 100, no writes
  │     • Assembled prompt: ~28K chars
  │
  ▼  5. LLM SQL GENERATION                         ★ CALL #2
  │     System: "You are a Trino SQL expert. Rules: ..."
  │     User: "<28K chars context> Question: how many uids by status in shard 45"
  │     LLM generates:
  │       SELECT uid_status_key, count(*) AS uid_count
  │       FROM strot.mysql_uid_v2.uid_master
  │       WHERE shard_hint = '45'
  │       GROUP BY uid_status_key
  │       ORDER BY uid_count DESC
  │       LIMIT 100
  │
  ▼  6. SQL POST-PROCESSING
  │     • Strip semicolons (none present)
  │     • LIMIT already present (100)
  │     • shard_hint present ('45')
  │
  ▼  7. EXPLAIN VALIDATION
  │     EXPLAIN (TYPE LOGICAL) SELECT ...
  │     → Pass (valid syntax)
  │
  ▼  8. TRINO EXECUTION
  │     SELECT uid_status_key, count(*) AS uid_count
  │       FROM strot.mysql_uid_v2.uid_master
  │       WHERE shard_hint = '45'
  │       GROUP BY uid_status_key
  │       ORDER BY uid_count DESC
  │       LIMIT 100
  │
  ▼  9. RESULT
  │     uid_status_key | uid_count
  │     ──────────────┼──────────
  │     A              | 45,123,456
  │     R              |  1,234,567
  │     ... (18 rows, 1.0s)
  │
  ▼
  User receives: SQL + results
```

### 9.2 Timing Breakdown

| Step | Component | Time | Type |
|------|-----------|------|------|
| 1 | Synonym expansion | <1ms | Deterministic |
| 2 | PostgreSQL FTS + graph expansion | ~1.1s | SQL query |
| 3 | LLM re-ranking | 3–8s | ★ LLM call #1 |
| 4 | Context assembly | <10ms | String building |
| 5 | LLM SQL generation | 2–12s | ★ LLM call #2 |
| 6 | SQL post-processing | <1ms | String ops |
| 7 | EXPLAIN validation | 0.5–2s | Trino query |
| 8 | Query execution | 0.5–5s | Trino query |
| **Total** | | **7–28s** | LLM-bound |

---

## 10. Technology Stack

### 10.1 Stack Summary

| Layer | Technology | Version | Why |
|-------|-----------|---------|-----|
| **GraphRAG storage** | PostgreSQL | 16 | One DB for FTS + graph + vectors |
| **Vector search** | pgvector | 0.8.7 | HNSW index, ready for embeddings |
| **LLM** | GLM-5.2-FP8 | — | Reasoning model, 524K context |
| **LLM serving** | vLLM | — | OpenAI-compatible API |
| **Query engine** | Trino | — | Distributed SQL for large tables |
| **Containerization** | Docker | — | PostgreSQL + pgAdmin |
| **Python** | CPython | 3.x | Runtime for pipeline |
| **Numerical** | numpy | — | Used in fallback BM25 retriever |
| **HTTP** | requests | — | LLM API calls |

## 11. Design Decisions

### 11.1 Decision Log

| # | Decision | Alternatives Considered | Rationale |
|---|----------|------------------------|-----------|
| 1 | **PostgreSQL over Neo4j** | Neo4j, MongoDB, SQLite | One DB for FTS + vectors + graph; SQL consistency with Trino; pgvector maturity |
| 2 | **PostgreSQL over JSON file** | Keep JSON + BM25 from scratch | Persistent index, no rebuild per query, built-in BM25, ready for embeddings |
| 3 | **Clean entity-specific documents** | Include community titles, table names in column docs | Eliminates 30–50% term overlap; relationships via graph edges, not shared text |
| 4 | **BM25 (websearch_to_tsquery) over TF-IDF** | Custom TF-IDF, custom BM25 | PostgreSQL's built-in stemming + BM25; no maintenance burden |
| 5 | **Hardcoded synonym groups over LLM expansion** | LLM generates synonyms per query | Speed (ms vs seconds), determinism, control |
| 6 | **Two-stage retrieval (FTS + LLM)** | FTS only, LLM only | FTS ensures 100% recall; LLM ensures 85% precision; both needed |
| 7 | **GLM-5.2-FP8 for both re-ranking and SQL gen** | Different models per task | Single model simplifies ops; reasoning capability helps both tasks |
| 8 | **Docker exec psql over Python driver** | psycopg2, pg8000 | No internet to install drivers; docker exec works with zero dependencies |
| 9 | **Fallback to CleanGraphRAG (JSON+BM25)** | Hard fail if PostgreSQL down | System remains functional during PostgreSQL maintenance |
| 10 | **websearch_to_tsquery over to_tsquery** | to_tsquery, plainto_tsquery | Handles OR syntax + multi-word synonyms without syntax errors |
| 11 | **34 synonym groups (hardcoded)** | 50+ groups, LLM-generated | Covers all test queries; diminishing returns beyond this |
| 12 | **pgvector HNSW index created but empty** | Don't create until needed | Ready for immediate use when embedding model becomes available |

### 11.2 Trade-offs

| Trade-off | Choice | Cost |
|-----------|--------|------|
| Speed vs precision | Two-stage retrieval (FTS + LLM) | +3–8s for LLM re-ranking |
| Flexibility vs determinism | Hardcoded synonyms | Manual curation required |
| Simplicity vs performance | Docker exec psql (no driver) | +1s per query vs native driver |
| Clean docs vs rich docs | Entity-specific only | Some queries need LLM to bridge gap |

## Appendix B: Glossary

| Term | Definition |
|------|-----------|
| **GraphRAG** | Graph Retrieval-Augmented Generation — uses a knowledge graph to retrieve structured context for an LLM |
| **TF-IDF** | Term Frequency-Inverse Document Frequency — lexical text matching algorithm |
| **BM25** | Okapi BM25 — improved TF-IDF with term saturation and length normalization |
| **tsvector** | PostgreSQL data type for pre-processed full-text search vectors |
| **tsquery** | PostgreSQL data type for full-text search queries |
| **ts_rank** | PostgreSQL function that ranks tsvector matches (implements BM25-like scoring) |
| **pgvector** | PostgreSQL extension for vector storage and ANN (Approximate Nearest Neighbor) search |
| **HNSW** | Hierarchical Navigable Small World — graph-based ANN index algorithm |
| **GIN** | Generalized Inverted Index — PostgreSQL index type for tsvector and JSONB |
| **shard_hint** | First 2 digits of UID, used for partition pruning in Trino |
| **uid** | Encrypted Aadhaar number (Base64-like blob), primary join key |
| **eid** | Enrolment event ID, used for cross-table correlation in history tables |
| **varbinary** | Binary column type; `updt_*` columns use b'00' = not updated, b'11' = updated |
| **vLLM** | High-throughput LLM serving engine (OpenAI-compatible API) |
| **GLM-5.2-FP8** | Reasoning LLM with `reasoning` (thinking) and `content` (answer) fields |

---

> **End of Document**
