// API client for the Chatbot backend

const API_BASE = '/api'

function getToken(): string | null {
  return localStorage.getItem('token')
}

export function setTokens(token: string, refreshToken: string) {
  localStorage.setItem('token', token)
  localStorage.setItem('refreshToken', refreshToken)
}

export function clearTokens() {
  localStorage.removeItem('token')
  localStorage.removeItem('refreshToken')
}

export function getCurrentUser(): string | null {
  const userStr = localStorage.getItem('user')
  return userStr ? JSON.parse(userStr) : null
}

export function setCurrentUser(user: any) {
  localStorage.setItem('user', JSON.stringify(user))
}

async function request(method: string, path: string, body?: any): Promise<any> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  }
  const token = getToken()
  if (token) {
    headers['Authorization'] = `Bearer ${token}`
  }

  const opts: RequestInit = { method, headers }
  if (body) {
    opts.body = JSON.stringify(body)
  }

  const res = await fetch(`${API_BASE}${path}`, opts)

  // If 401, try to refresh the token
  if (res.status === 401) {
    const refreshed = await tryRefresh()
    if (refreshed) {
      // Retry with new token
      headers['Authorization'] = `Bearer ${getToken()}`
      const retryRes = await fetch(`${API_BASE}${path}`, { method, headers, body: opts.body })
      if (!retryRes.ok) {
        throw await retryRes.json().catch(() => ({ error: 'Request failed' }))
      }
      return retryRes.json()
    }
    // Refresh failed — redirect to login
    clearTokens()
    window.location.href = '/login'
    throw { error: 'Authentication required' }
  }

  if (!res.ok) {
    throw await res.json().catch(() => ({ error: 'Request failed' }))
  }

  return res.json()
}

async function tryRefresh(): Promise<boolean> {
  const refreshToken = localStorage.getItem('refreshToken')
  if (!refreshToken) return false

  try {
    const res = await fetch(`${API_BASE}/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken }),
    })
    if (!res.ok) return false
    const data = await res.json()
    if (data.success && data.token) {
      localStorage.setItem('token', data.token)
      return true
    }
    return false
  } catch {
    return false
  }
}

// ─── Auth API ──────────────────────────────────────────────────
export const authApi = {
  login: (username: string, password: string) =>
    request('POST', '/auth/login', { username, password }),

  me: () => request('GET', '/auth/me'),

  changePassword: (oldPassword: string, newPassword: string) =>
    request('POST', '/auth/change-password', { oldPassword, newPassword }),
}

// ─── User Management API (admin) ──────────────────────────────
export const usersApi = {
  list: () => request('GET', '/users'),
  create: (data: { username: string; email: string; password: string; role: string; fullName?: string }) =>
    request('POST', '/users', data),
  update: (userId: number, data: { role?: string; fullName?: string; isActive?: boolean; password?: string }) =>
    request('PUT', `/users/${userId}`, data),
  delete: (userId: number) => request('DELETE', `/users/${userId}`),
}

// ─── Conversation API ──────────────────────────────────────────
export const conversationsApi = {
  list: () => request('GET', '/conversations'),
  listAll: () => request('GET', '/conversations?all=true'),
  get: (id: string) => request('GET', `/conversations/${id}`),
  create: (title?: string) => request('POST', '/conversations', { title: title || 'New Chat' }),
  delete: (id: string) => request('DELETE', `/conversations/${id}`),
  rename: (id: string, title: string) => request('PUT', `/conversations/${id}`, { title }),
}

// ─── Pipeline API ──────────────────────────────────────────────
export const pipelineApi = {
  ask: (conversationId: string, question: string, settings?: any) =>
    request('POST', '/pipeline/ask', { conversationId, question, settings }),

  execute: (conversationId: string, messageIndex: number) =>
    request('POST', '/pipeline/execute', { conversationId, messageIndex }),

  regenerate: (conversationId: string, messageIndex: number, feedback: string, settings?: any, context?: string) =>
    request('POST', '/pipeline/regenerate', { conversationId, messageIndex, feedback, settings, context }),

  // SSE stream — returns EventSource
  stream: (taskId: string): EventSource => {
    const token = getToken()
    // EventSource doesn't support custom headers, so pass token as query param
    return new EventSource(`${API_BASE}/pipeline/stream/${taskId}?token=${encodeURIComponent(token || '')}`)
  },
}

// ─── Admin: Context Remarks & Editing ─────────────────────────
export const adminApi = {
  addRemark: (conversationId: string, messageIndex: number, remark: string) =>
    request('POST', '/messages/remark', { conversationId, messageIndex, remark }),

  updateContext: (conversationId: string, messageIndex: number, context: string) =>
    request('PUT', `/conversations/${conversationId}/messages/${messageIndex}/context`, { context }),

  // Add Table to GraphRAG
  discoverTable: (table: string) =>
    request('POST', '/admin/table/discover', { table }),

  generateContext: (data: { table: string; tableName: string; columns: any[]; rowCount?: number; sampleData?: any[]; sampleColumns?: string[] }) =>
    request('POST', '/admin/table/generate-context', data),

  saveTable: (data: {
    table: string
    tableName: string
    schema: string
    tableDescription: string
    columns: any[]
    rowCount?: number
    searchKeywords?: string
    sampleData?: any[]
  }) => request('POST', '/admin/table/save', data),
}

// ─── Feedback API ──────────────────────────────────────────────
export const feedbackApi = {
  check: (conversationId: string, messageIndex: number) =>
    request('GET', `/feedback/check?conversationId=${conversationId}&messageIndex=${messageIndex}`),

  merge: (conversationId: string, messageIndex: number) =>
    request('POST', '/feedback/merge', { conversationId, messageIndex }),
}

// ─── Audit API ─────────────────────────────────────────────────
export const auditApi = {
  list: (limit = 50) => request('GET', `/audit?limit=${limit}`),
}

// ─── Health API ────────────────────────────────────────────────
export const healthApi = {
  check: () => request('GET', '/health'),
}
