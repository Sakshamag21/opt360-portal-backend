// Shared types

export interface User {
  id: number
  username: string
  email: string
  role: 'admin' | 'analyst'
  fullName?: string
  isActive?: boolean
  createdAt?: string
}

export interface Conversation {
  id: string
  title: string
  created_at: string
  updated_at: string
  message_count: number
  username?: string
  full_name?: string
}

export interface ConversationDetail extends Conversation {
  messages: Message[]
}

export type MessageStatus =
  | 'pending_verification'
  | 'executing'
  | 'regenerating'
  | 'rejected'
  | 'completed'
  | 'error'

export interface PipelineStep {
  name: string
  status: 'done' | 'error' | 'warning' | 'pending'
  detail?: string
  elapsed?: number
}

export interface QueryResult {
  success: boolean
  columns?: string[]
  rows?: any[][]
  row_count?: number
  query_id?: string
  error?: string
}

export interface QueryStats {
  execution_time_ms?: number
  query_id?: string
  state?: string
  cpu_time_ms?: number
  wall_time_ms?: number
  queued_time_ms?: number
  peak_memory_bytes?: number
  processed_rows?: number
  processed_bytes?: number
  physical_input_bytes?: number
  physical_input_rows?: number
  scheduled_nodes?: number
  active_nodes?: number
  total_nodes?: number
  explain_plan?: string | null
}

export interface Message {
  role: 'user' | 'assistant'
  content?: string  // for user messages
  // For assistant messages:
  question?: string
  intent?: string
  sql?: string
  context?: string
  original_context?: string
  reasoning?: string
  explain_result?: { valid: boolean; error: string } | null
  explain_plan?: string | null
  query_result?: QueryResult | null
  query_stats?: QueryStats | null
  metadata_answer?: string
  metadata_data?: any
  status?: MessageStatus
  elapsed?: number
  steps?: PipelineStep[]
  error?: string
  feedback?: string
  feedback_history?: { feedback: string; previous_sql: string }[]
  admin_remark?: string
  admin_remark_by?: string
  admin_remark_at?: string
  context_edited?: boolean
  context_edited_by?: string
  context_edited_at?: string
  feedback_merged?: boolean
  _index?: number
}

export interface AuditEntry {
  id: number
  user_id?: number
  username?: string
  conv_id?: string
  question?: string
  sql_text?: string
  execution_status: string
  row_count?: number
  latency_seconds?: number
  trino_query_id?: string
  error_message?: string
  created_at: string
}

// SSE event types
export interface SSEEvent {
  type: 'status' | 'step_start' | 'step_done' | 'step_error' | 'step_warning' | 'result' | 'error' | 'done' | 'close'
  data: any
}
