import { useState, useEffect } from 'react'
import type { FormEvent } from 'react'
import type { User } from '../types'
import { usersApi } from '../api'
import { Sidebar } from '../components/Sidebar'
import { useAuth } from '../auth-context'

export function AdminPage() {
  const { user } = useAuth()
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [form, setForm] = useState({
    username: '',
    email: '',
    password: '',
    role: 'analyst',
    fullName: '',
    isActive: true,
  })
  const [error, setError] = useState('')

  const loadUsers = async () => {
    setLoading(true)
    try {
      const data = await usersApi.list()
      if (data.success) setUsers(data.users)
    } catch (err) {
      console.error('Failed to load users:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadUsers()
  }, [])

  const openCreate = () => {
    setEditingUser(null)
    setForm({ username: '', email: '', password: '', role: 'analyst', fullName: '', isActive: true })
    setError('')
    setShowModal(true)
  }

  const openEdit = (u: User) => {
    setEditingUser(u)
    setForm({
      username: u.username,
      email: u.email,
      password: '',
      role: u.role,
      fullName: u.fullName || '',
      isActive: u.isActive ?? true,
    })
    setError('')
    setShowModal(true)
  }

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError('')
    try {
      if (editingUser) {
        const updates: any = { role: form.role, fullName: form.fullName, isActive: form.isActive }
        if (form.password) updates.password = form.password
        await usersApi.update(editingUser.id, updates)
      } else {
        await usersApi.create({
          username: form.username,
          email: form.email,
          password: form.password,
          role: form.role,
          fullName: form.fullName,
        })
      }
      setShowModal(false)
      loadUsers()
    } catch (err: any) {
      setError(err.error || 'Operation failed')
    }
  }

  const handleDelete = async (userId: number) => {
    if (!confirm('Delete this user? This cannot be undone.')) return
    try {
      await usersApi.delete(userId)
      loadUsers()
    } catch (err: any) {
      alert(err.error || 'Delete failed')
    }
  }

  return (
    <div className="app-layout">
      <Sidebar
        user={user!}
        conversations={[]}
        currentConvId={null}
        onSelectConv={() => {}}
        onNewChat={() => {}}
        onDeleteConv={() => {}}
      />
      <div className="app-main">
        <div className="app-header">
          <div className="header-left">
            <span className="header-title">👥 User Management</span>
          </div>
        </div>

        <div className="admin-page">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h2>Users ({users.length})</h2>
            <button className="btn btn-primary" onClick={openCreate}>➕ Add User</button>
          </div>

          {loading ? (
            <div className="empty-state"><span className="spinner" /> Loading users...</div>
          ) : (
            <table className="user-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Name</th>
                  <th>Status</th>
                  <th>Created</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map(u => (
                  <tr key={u.id}>
                    <td>{u.id}</td>
                    <td><strong>{u.username}</strong></td>
                    <td>{u.email}</td>
                    <td><span className={`role-badge ${u.role}`}>{u.role}</span></td>
                    <td>{u.fullName || '-'}</td>
                    <td>{u.isActive ? <span className="success-text">Active</span> : <span className="error-text">Inactive</span>}</td>
                    <td className="muted">{u.createdAt?.slice(0, 10)}</td>
                    <td>
                      <button className="btn btn-secondary btn-sm" onClick={() => openEdit(u)}>Edit</button>
                      {u.id !== user!.id && (
                        <button className="btn btn-danger btn-sm" style={{ marginLeft: 4 }} onClick={() => handleDelete(u.id)}>Delete</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {showModal && (
          <div className="modal-overlay" onClick={() => setShowModal(false)}>
            <div className="modal" onClick={e => e.stopPropagation()}>
              <h3>{editingUser ? `Edit User: ${editingUser.username}` : 'Add New User'}</h3>
              {error && <div className="verify-banner rejected"><span className="text">{error}</span></div>}
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label>Username</label>
                  <input
                    type="text"
                    value={form.username}
                    onChange={e => setForm({ ...form, username: e.target.value })}
                    disabled={!!editingUser}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Email</label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={e => setForm({ ...form, email: e.target.value })}
                    disabled={!!editingUser}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Full Name</label>
                  <input
                    type="text"
                    value={form.fullName}
                    onChange={e => setForm({ ...form, fullName: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label>Role</label>
                  <select value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>
                    <option value="analyst">Analyst</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>{editingUser ? 'New Password (leave blank to keep current)' : 'Password'}</label>
                  <input
                    type="password"
                    value={form.password}
                    onChange={e => setForm({ ...form, password: e.target.value })}
                    required={!editingUser}
                    placeholder={editingUser ? '••••••' : ''}
                  />
                </div>
                {editingUser && (
                  <div className="form-group">
                    <label>
                      <input
                        type="checkbox"
                        checked={form.isActive}
                        onChange={e => setForm({ ...form, isActive: e.target.checked })}
                        style={{ width: 'auto', marginRight: 8 }}
                      />
                      Active
                    </label>
                  </div>
                )}
                <div className="modal-actions">
                  <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                  <button type="submit" className="btn btn-primary">{editingUser ? 'Update' : 'Create'}</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
