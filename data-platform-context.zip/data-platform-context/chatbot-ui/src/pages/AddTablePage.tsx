import { useState } from 'react'
import { Link } from 'react-router-dom'
import { adminApi } from '../api'
import { useAuth } from '../auth-context'
import { Sidebar } from '../components/Sidebar'

interface ColumnInfo {
  name: string
  type: string
  extra?: string
  comment?: string
  description?: string
}

type Step = 'input' | 'discovering' | 'review' | 'generating' | 'saving' | 'done' | 'error'

export function AddTablePage() {
  const { user } = useAuth()
  const [step, setStep] = useState<Step>('input')
  const [tableInput, setTableInput] = useState('')
  const [discoveredTable, setDiscoveredTable] = useState('')
  const [tableName, setTableName] = useState('')
  const [schema, setSchema] = useState('')
  const [rowCount, setRowCount] = useState<number | null>(null)
  const [columns, setColumns] = useState<ColumnInfo[]>([])
  const [tableDescription, setTableDescription] = useState('')
  const [reasoning, setReasoning] = useState('')
  const [error, setError] = useState('')
  const [result, setResult] = useState<any>(null)
  const [sampleData, setSampleData] = useState<any[]>([])
  const [sampleColumns, setSampleColumns] = useState<string[]>([])
  const [searchKeywords, setSearchKeywords] = useState('')

  // Step 1: Discover table in Trino
  const handleDiscover = async () => {
    const table = tableInput.trim()
    if (!table) return

    setStep('discovering')
    setError('')
    try {
      const data = await adminApi.discoverTable(table)
      if (data.success) {
        setDiscoveredTable(data.table)
        setTableName(data.tableName)
        setSchema(data.schema)
        setRowCount(data.rowCount)
        setColumns(data.columns)
        setSampleData(data.sampleData || [])
        setSampleColumns(data.sampleColumns || [])
        setStep('review')
      } else {
        setError(data.error || 'Discovery failed')
        setStep('error')
      }
    } catch (err: any) {
      setError(err.error || err.message || 'Discovery failed')
      setStep('error')
    }
  }

  // Step 2: Generate context with LLM
  const handleGenerate = async () => {
    setStep('generating')
    setError('')
    try {
      const data = await adminApi.generateContext({
        table: discoveredTable,
        tableName,
        columns,
        rowCount: rowCount || undefined,
        sampleData,
        sampleColumns,
      })
      if (data.success) {
        setTableDescription(data.tableDescription)
        setColumns(data.columns)
        setReasoning(data.reasoning || '')
        setSearchKeywords(data.searchKeywords || '')
        setStep('review')
      } else {
        setError(data.error || 'Context generation failed')
        setStep('error')
      }
    } catch (err: any) {
      setError(err.error || err.message || 'Context generation failed')
      setStep('error')
    }
  }

  // Step 3: Save to GraphRAG
  const handleSave = async () => {
    setStep('saving')
    setError('')
    try {
      const data = await adminApi.saveTable({
        table: discoveredTable,
        tableName,
        schema,
        tableDescription,
        columns,
        rowCount: rowCount || undefined,
        searchKeywords,
        sampleData,
      })
      if (data.success) {
        setResult(data)
        setStep('done')
      } else {
        setError(data.error || 'Save failed')
        setStep('error')
      }
    } catch (err: any) {
      setError(err.error || err.message || 'Save failed')
      setStep('error')
    }
  }

  // Update a column description
  const updateColumnDesc = (index: number, desc: string) => {
    setColumns(prev => prev.map((c, i) => i === index ? { ...c, description: desc } : c))
  }

  const reset = () => {
    setStep('input')
    setTableInput('')
    setDiscoveredTable('')
    setTableName('')
    setSchema('')
    setRowCount(null)
    setColumns([])
    setTableDescription('')
    setReasoning('')
    setError('')
    setResult(null)
    setSampleData([])
    setSampleColumns([])
    setSearchKeywords('')
  }

  return (
    <div className="app-layout">
      <Sidebar
        user={user!}
        conversations={[]}
        currentConvId={null}
        onSelectConv={() => {}}
        onNewChat={() => {}}
        onDeleteConv={() => {}}
      />
      <div className="app-main">
        <div className="app-header">
          <div className="header-left">
            <Link to="/" className="btn btn-ghost btn-sm" style={{ marginRight: '0.5rem' }}>← Back</Link>
            <span className="header-title">📊 Add Table to GraphRAG</span>
          </div>
        </div>

        <div className="chat-container">
          <div style={{ maxWidth: '900px', margin: '0 auto', padding: '2rem 1rem' }}>

            {/* Progress indicator */}
            <div className="wizard-progress" style={{ display: 'flex', gap: '0.5rem', marginBottom: '2rem' }}>
              {['Discover', 'Generate', 'Review', 'Save'].map((label, i) => {
                const isActive = (step === 'review' && i === 1) || (step === 'generating' && i === 1) ||
                  (step === 'review' && i === 2) || (step === 'saving' && i === 3) || (step === 'done' && i === 3) ||
                  (step === 'discovering' && i === 0)
                const isDone = (step === 'review' && i === 0) || (step === 'done' && i < 3) ||
                  (step === 'saving' && i < 3) || (step === 'generating' && i < 1) ||
                  (step === 'review' && i === 0 && tableDescription)
                return (
                  <div key={i} style={{
                    flex: 1,
                    padding: '0.5rem',
                    textAlign: 'center',
                    borderRadius: '6px',
                    fontSize: '0.8rem',
                    fontWeight: isActive ? 600 : 400,
                    background: isDone ? '#e6f4ea' : isActive ? '#e8f0fe' : 'var(--neutral-50)',
                    color: isDone ? '#137333' : isActive ? '#1967d2' : 'var(--text-tertiary)',
                    border: `1px solid ${isDone ? '#34a853' : isActive ? '#4285f4' : 'var(--border)'}`,
                  }}>
                    {isDone ? '✅' : isActive ? '🔄' : `${i + 1}.`} {label}
                  </div>
                )
              })}
            </div>

            {/* Step: Input table name */}
            {step === 'input' && (
              <div className="wizard-card">
                <h3>Step 1: Enter Table Name</h3>
                <p className="muted">Enter the fully-qualified Trino table name to discover its schema.</p>
                <input
                  type="text"
                  className="table-input"
                  placeholder="e.g., strot.mysql_uid_v2.uid_master"
                  value={tableInput}
                  onChange={e => setTableInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleDiscover()}
                  style={{ width: '100%', padding: '0.6rem', fontSize: '0.9rem', fontFamily: 'Consolas, monospace' }}
                />
                <div className="muted" style={{ marginTop: '0.5rem', fontSize: '0.75rem' }}>
                  Format: <code>catalog.schema.table</code> — The table must be accessible in Trino at <code>http://10.10.116.39:8080</code>
                </div>
                <div style={{ marginTop: '1rem' }}>
                  <button className="btn btn-primary" onClick={handleDiscover} disabled={!tableInput.trim()}>
                    🔍 Discover Table
                  </button>
                </div>
              </div>
            )}

            {/* Step: Discovering */}
            {step === 'discovering' && (
              <div className="wizard-card">
                <div className="verify-banner executing">
                  <span className="icon"><span className="spinner" /></span>
                  <span className="text">Discovering table schema from Trino...<div className="sub">Querying SHOW COLUMNS FROM {tableInput}</div></span>
                </div>
              </div>
            )}

            {/* Step: Generating context */}
            {step === 'generating' && (
              <div className="wizard-card">
                <div className="verify-banner executing">
                  <span className="icon"><span className="spinner" /></span>
                  <span className="text">Generating context with GLM-5.2...<div className="sub">The LLM is analyzing {columns.length} columns and writing descriptions.</div></span>
                </div>
              </div>
            )}

            {/* Step: Saving */}
            {step === 'saving' && (
              <div className="wizard-card">
                <div className="verify-banner executing">
                  <span className="icon"><span className="spinner" /></span>
                  <span className="text">Saving to GraphRAG PostgreSQL...<div className="sub">Creating TABLE entity + {columns.length} COLUMN entities + relationships.</div></span>
                </div>
              </div>
            )}

            {/* Step: Review (discovered + LLM-generated) */}
            {step === 'review' && (
              <div className="wizard-card">
                <h3>Step 2-3: Review Table Context</h3>
                <div className="muted" style={{ marginBottom: '1rem' }}>
                  Discovered: <code>{discoveredTable}</code> · {rowCount != null ? `${rowCount.toLocaleString()} rows` : 'row count unknown'} · {columns.length} columns
                </div>

                {/* Table description */}
                <div style={{ marginBottom: '1.5rem' }}>
                  <label style={{ fontWeight: 600, fontSize: '0.85rem', display: 'block', marginBottom: '0.4rem' }}>
                    Table Description
                    {tableDescription && <span className="muted" style={{ fontWeight: 400 }}> (generated by LLM — edit if needed)</span>}
                  </label>
                  <textarea
                    className="feedback-textarea"
                    value={tableDescription}
                    onChange={e => setTableDescription(e.target.value)}
                    rows={3}
                    placeholder="Click 'Generate with LLM' to auto-generate, or write manually..."
                    style={{ width: '100%' }}
                  />
                  {!tableDescription && (
                    <button className="btn btn-primary btn-sm" style={{ marginTop: '0.5rem' }} onClick={handleGenerate}>
                      🤖 Generate with LLM
                    </button>
                  )}
                </div>

                {/* LLM Reasoning */}
                {reasoning && (
                  <details style={{ marginBottom: '1rem' }}>
                    <summary style={{ cursor: 'pointer', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                      🧠 LLM Reasoning ({reasoning.length} chars)
                    </summary>
                    <pre className="reasoning-text" style={{ marginTop: '0.5rem' }}>{reasoning}</pre>
                  </details>
                )}

                {/* Sample Data */}
                {sampleData.length > 0 && (
                  <details style={{ marginBottom: '1rem' }}>
                    <summary style={{ cursor: 'pointer', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                      📊 Sample Data ({sampleData.length} rows from Trino)
                    </summary>
                    <div style={{ marginTop: '0.5rem', overflowX: 'auto' }}>
                      <table style={{ width: '100%', fontSize: '0.72rem', borderCollapse: 'collapse' }}>
                        <thead>
                          <tr>
                            {sampleColumns.map((col, i) => (
                              <th key={i} style={{ textAlign: 'left', padding: '4px 8px', borderBottom: '2px solid var(--border)', whiteSpace: 'nowrap' }}>{col}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {sampleData.slice(0, 5).map((row, i) => (
                            <tr key={i}>
                              {row.map((cell: any, j: number) => (
                                <td key={j} style={{ padding: '4px 8px', borderBottom: '1px solid var(--border)', maxWidth: '150px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={String(cell ?? 'NULL')}>
                                  {String(cell ?? 'NULL').slice(0, 30)}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </details>
                )}

                {/* Search Keywords */}
                {searchKeywords && (
                  <div style={{ marginBottom: '1rem' }}>
                    <label style={{ fontWeight: 600, fontSize: '0.85rem', display: 'block', marginBottom: '0.4rem' }}>
                      🔍 Search Keywords
                      <span className="muted" style={{ fontWeight: 400 }}> (natural-language phrases users might type — used for FTS indexing)</span>
                    </label>
                    <textarea
                      className="feedback-textarea"
                      value={searchKeywords}
                      onChange={e => setSearchKeywords(e.target.value)}
                      rows={2}
                      style={{ width: '100%' }}
                    />
                  </div>
                )}

                {/* Column descriptions */}
                <div>
                  <label style={{ fontWeight: 600, fontSize: '0.85rem', display: 'block', marginBottom: '0.4rem' }}>
                    Column Descriptions ({columns.length} columns)
                  </label>
                  <div className="column-list">
                    {columns.map((col, i) => (
                      <div key={i} className="column-row">
                        <div className="column-header">
                          <span className="col-name">{col.name}</span>
                          <span className="col-type">{col.type}</span>
                          {col.comment && <span className="col-comment" title={col.comment}>💬</span>}
                        </div>
                        <input
                          type="text"
                          className="col-desc-input"
                          placeholder="Column description..."
                          value={col.description || ''}
                          onChange={e => updateColumnDesc(i, e.target.value)}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="verify-actions" style={{ marginTop: '1.5rem' }}>
                  <button className="btn btn-primary" onClick={handleSave} disabled={!tableDescription.trim()}>
                    ✓ Save to GraphRAG
                  </button>
                  {!tableDescription && (
                    <button className="btn btn-secondary" onClick={handleGenerate}>
                      🤖 Generate with LLM
                    </button>
                  )}
                  <button className="btn btn-ghost" onClick={reset}>↩ Start Over</button>
                </div>
              </div>
            )}

            {/* Step: Done */}
            {step === 'done' && result && (
              <div className="wizard-card">
                <div className="verify-banner completed">
                  <span className="icon">✅</span>
                  <span className="text">
                    Table added to GraphRAG successfully!
                    <div className="sub">{result.message}</div>
                  </span>
                </div>
                <div style={{ marginTop: '1rem' }}>
                  <div className="muted" style={{ marginBottom: '0.5rem' }}>
                    Table Entity: <code>{result.tableEntityId}</code> · {result.columnCount} columns created
                  </div>
                  <div className="verify-actions">
                    <Link to="/" className="btn btn-primary">💬 Go to Chat</Link>
                    <button className="btn btn-secondary" onClick={reset}>📊 Add Another Table</button>
                  </div>
                </div>
              </div>
            )}

            {/* Step: Error */}
            {step === 'error' && (
              <div className="wizard-card">
                <div className="verify-banner rejected">
                  <span className="icon">❌</span>
                  <span className="text">{error}</span>
                </div>
                <div className="verify-actions" style={{ marginTop: '1rem' }}>
                  <button className="btn btn-primary" onClick={() => setStep('input')}>↩ Try Again</button>
                </div>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  )
}
