import { useState, useEffect } from 'react'
import type { AuditEntry } from '../types'
import { auditApi } from '../api'
import { Sidebar } from '../components/Sidebar'
import { useAuth } from '../auth-context'

export function AuditPage() {
  const { user } = useAuth()
  const [entries, setEntries] = useState<AuditEntry[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      try {
        const data = await auditApi.list(100)
        if (data.success) setEntries(data.entries)
      } catch (err) {
        console.error('Failed to load audit log:', err)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const statusIcon = (s: string) => {
    if (s === 'success') return '✅'
    if (s === 'failed') return '❌'
    if (s === 'skipped') return '⏭️'
    return '•'
  }

  return (
    <div className="app-layout">
      <Sidebar
        user={user!}
        conversations={[]}
        currentConvId={null}
        onSelectConv={() => {}}
        onNewChat={() => {}}
        onDeleteConv={() => {}}
      />
      <div className="app-main">
        <div className="app-header">
          <div className="header-left">
            <span className="header-title">📋 Audit Log</span>
          </div>
        </div>

        <div className="admin-page">
          <h2>Query Audit Log ({entries.length} entries)</h2>

          {loading ? (
            <div className="empty-state"><span className="spinner" /> Loading...</div>
          ) : entries.length === 0 ? (
            <div className="empty-state">No audit entries yet</div>
          ) : (
            <div className="results-table">
              <table>
                <thead>
                  <tr>
                    <th>Time</th>
                    {user?.role === 'admin' && <th>User</th>}
                    <th>Question</th>
                    <th>SQL</th>
                    <th>Status</th>
                    <th>Rows</th>
                    <th>Latency</th>
                    <th>Error</th>
                  </tr>
                </thead>
                <tbody>
                  {entries.map(e => (
                    <tr key={e.id}>
                      <td className="muted">{e.created_at?.slice(0, 19).replace('T', ' ')}</td>
                      {user?.role === 'admin' && <td>{e.username || '-'}</td>}
                      <td style={{ maxWidth: '200px' }} title={e.question}>{e.question?.slice(0, 80)}</td>
                      <td style={{ maxWidth: '300px' }} title={e.sql_text}>
                        <code style={{ fontSize: '0.7rem' }}>{e.sql_text?.slice(0, 100)}</code>
                      </td>
                      <td>{statusIcon(e.execution_status)} {e.execution_status}</td>
                      <td>{e.row_count ?? '-'}</td>
                      <td>{e.latency_seconds ? `${e.latency_seconds}s` : '-'}</td>
                      <td style={{ maxWidth: '200px' }} className="error-text">{e.error_message?.slice(0, 80) || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
