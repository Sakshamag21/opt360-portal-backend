import { useState, useEffect, useRef, useCallback } from 'react'
import type { Conversation, Message, PipelineStep } from '../types'
import { conversationsApi, pipelineApi, adminApi } from '../api'
import { MessageView } from '../components/MessageView'
import { useAuth } from '../auth-context'

const EXAMPLES = [
  'How many active UIDs are there?',
  'Count of UIDs by status',
  'How many tables are there?',
  'Describe the uid_master table',
  'Which table has biometric fraud check data?',
]

export function ChatPage() {
  const { user } = useAuth()
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [currentConv, setCurrentConv] = useState<Conversation | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [feedbackValues, setFeedbackValues] = useState<Record<number, string>>({})
  const [busyMsgIndex, setBusyMsgIndex] = useState<number | null>(null)
  const [showAllUsers, setShowAllUsers] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const isAdmin = user?.role === 'admin'

  // Load conversation list
  const loadConversations = useCallback(async () => {
    try {
      const data = isAdmin && showAllUsers
        ? await conversationsApi.listAll()
        : await conversationsApi.list()
      if (data.success) {
        setConversations(data.conversations)
        // Auto-select first conversation if none selected
        if (!currentConv && data.conversations.length > 0) {
          selectConversation(data.conversations[0].id)
        }
      }
    } catch (err) {
      console.error('Failed to load conversations:', err)
    }
  }, [currentConv, isAdmin, showAllUsers])

  useEffect(() => {
    loadConversations()
  }, [loadConversations])

  // Select a conversation
  const selectConversation = async (convId: string) => {
    try {
      const data = await conversationsApi.get(convId)
      if (data.success) {
        const conv = data.conversation
        setCurrentConv({
          id: conv.id,
          title: conv.title,
          created_at: conv.created_at,
          updated_at: conv.updated_at,
          message_count: conv.messages?.length || 0,
        })
        setMessages(conv.messages || [])
      }
    } catch (err) {
      console.error('Failed to load conversation:', err)
    }
  }

  // New chat
  const newChat = async () => {
    try {
      const data = await conversationsApi.create()
      if (data.success) {
        await loadConversations()
        selectConversation(data.conversation.id)
      }
    } catch (err) {
      console.error('Failed to create conversation:', err)
    }
  }

  // Delete conversation
  const deleteConversation = async (convId: string) => {
    if (!confirm('Delete this conversation?')) return
    try {
      await conversationsApi.delete(convId)
      await loadConversations()
      if (currentConv?.id === convId) {
        const remaining = conversations.filter(c => c.id !== convId)
        if (remaining.length > 0) {
          selectConversation(remaining[0].id)
        } else {
          setCurrentConv(null)
          setMessages([])
        }
      }
    } catch (err) {
      console.error('Failed to delete conversation:', err)
    }
  }

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // SSE stream handler
  const streamTask = async (taskId: string, isAsk: boolean) => {
    return new Promise<void>((resolve) => {
      const es = pipelineApi.stream(taskId)

      es.addEventListener('status', (e: any) => {
        const data = JSON.parse(e.data)
        console.log('[SSE] status:', data)
      })

      es.addEventListener('step_start', (e: any) => {
        const data = JSON.parse(e.data)
        console.log('[SSE] step_start:', data)
        if (isAsk) {
          setMessages(prev => {
            const last = prev[prev.length - 1]
            if (last && last.role === 'assistant') {
              const updated = { ...last, steps: [...(last.steps || []), { name: data.name, status: 'pending' as const, elapsed: 0 }] }
              return [...prev.slice(0, -1), updated]
            }
            return prev
          })
        }
      })

      es.addEventListener('step_done', (e: any) => {
        const data: PipelineStep = JSON.parse(e.data)
        console.log('[SSE] step_done:', data)
        if (isAsk) {
          setMessages(prev => {
            const last = prev[prev.length - 1]
            if (last && last.role === 'assistant' && last.steps) {
              const steps = [...last.steps]
              const idx = steps.findIndex(s => s.name === data.name && s.status === 'pending')
              if (idx >= 0) {
                steps[idx] = { ...data, status: 'done' }
              } else {
                steps.push(data)
              }
              return [...prev.slice(0, -1), { ...last, steps }]
            }
            return prev
          })
        }
      })

      es.addEventListener('step_error', (e: any) => {
        const data = JSON.parse(e.data)
        console.log('[SSE] step_error:', data)
        if (isAsk) {
          setMessages(prev => {
            const last = prev[prev.length - 1]
            if (last && last.role === 'assistant' && last.steps) {
              const steps = [...last.steps]
              const idx = steps.findIndex(s => s.name === data.name && s.status === 'pending')
              if (idx >= 0) {
                steps[idx] = { name: data.name, status: 'error', detail: data.error || data.detail, elapsed: data.elapsed }
              }
              return [...prev.slice(0, -1), { ...last, steps }]
            }
            return prev
          })
        }
      })

      es.addEventListener('step_warning', (e: any) => {
        const data = JSON.parse(e.data)
        console.log('[SSE] step_warning:', data)
        if (isAsk) {
          setMessages(prev => {
            const last = prev[prev.length - 1]
            if (last && last.role === 'assistant' && last.steps) {
              const steps = [...last.steps]
              const idx = steps.findIndex(s => s.name === data.name && s.status === 'pending')
              if (idx >= 0) {
                steps[idx] = { name: data.name, status: 'warning', detail: data.detail, elapsed: data.elapsed }
              }
              return [...prev.slice(0, -1), { ...last, steps }]
            }
            return prev
          })
        }
      })

      es.addEventListener('result', (e: any) => {
        const data = JSON.parse(e.data)
        console.log('[SSE] result:', data)

        if (isAsk) {
          // Replace the placeholder assistant message with the result
          setMessages(prev => {
            const last = prev[prev.length - 1]
            if (last && last.role === 'assistant') {
              const updated: Message = {
                ...last,
                intent: data.intent,
                sql: data.sql,
                context: data.context,
                reasoning: data.reasoning,
                explain_result: data.explain_result,
                explain_plan: data.explain_plan,
                query_result: data.query_result,
                query_stats: data.query_stats,
                metadata_answer: data.metadata_answer,
                status: data.status || 'pending_verification',
                error: data.error,
              }
              return [...prev.slice(0, -1), updated]
            }
            return prev
          })
        } else {
          // Execute or regenerate — update the specific message
          setMessages(prev => prev.map((m, i) => {
            if (i === busyMsgIndex) {
              if (data.sql) {
                // Regeneration result
                return {
                  ...m,
                  sql: data.sql || m.sql,
                  reasoning: data.reasoning || m.reasoning,
                  query_result: null,
                  query_stats: null,
                  explain_result: data.explain_result || null,
                  explain_plan: data.explain_plan || null,
                  status: data.status || 'pending_verification',
                  error: data.error,
                }
              } else {
                // Execution result
                return {
                  ...m,
                  query_result: data.query_result,
                  query_stats: data.query_stats,
                  status: data.status || 'completed',
                }
              }
            }
            return m
          }))
        }
      })

      es.addEventListener('error', (e: any) => {
        console.error('[SSE] error event:', e)
        try {
          const data = JSON.parse(e.data)
          console.error('[SSE] error data:', data)
        } catch {}
      })

      es.addEventListener('close', () => {
        console.log('[SSE] stream closed')
        es.close()
        setBusyMsgIndex(null)
        resolve()
      })

      es.onerror = () => {
        console.error('[SSE] connection error')
        es.close()
        setBusyMsgIndex(null)
        resolve()
      }
    })
  }

  // Ask a question
  const handleAsk = async () => {
    const question = input.trim()
    if (!question || loading) return

    if (!currentConv) {
      // Create a new conversation first
      try {
        const data = await conversationsApi.create()
        if (data.success) {
          await loadConversations()
          await selectConversation(data.conversation.id)
        }
      } catch (err) {
        console.error('Failed to create conversation:', err)
        return
      }
    }

    const convId = currentConv?.id
    if (!convId) return

    setInput('')
    setLoading(true)

    // Add user message + placeholder assistant message
    const userMsg: Message = { role: 'user', content: question }
    const assistantPlaceholder: Message = { role: 'assistant', status: 'executing', steps: [] }
    setMessages(prev => [...prev, userMsg, assistantPlaceholder])

    try {
      const data = await pipelineApi.ask(convId, question, {
        useRerank: true,
        runExplain: true,
      })

      if (data.success && data.taskId) {
        await streamTask(data.taskId, true)
        // Reload conversation to get the persisted message
        await selectConversation(convId)
      }
    } catch (err: any) {
      console.error('Ask failed:', err)
      setMessages(prev => {
        const last = prev[prev.length - 1]
        if (last && last.role === 'assistant') {
          return [...prev.slice(0, -1), { ...last, status: 'error', error: err.error || 'Pipeline failed' }]
        }
        return prev
      })
    } finally {
      setLoading(false)
    }
  }

  // Run SQL (execute)
  const handleRun = async (msgIndex: number) => {
    if (!currentConv) return
    setBusyMsgIndex(msgIndex)
    setMessages(prev => prev.map((m, i) => i === msgIndex ? { ...m, status: 'executing' } : m))

    try {
      const data = await pipelineApi.execute(currentConv.id, msgIndex)
      if (data.success && data.taskId) {
        await streamTask(data.taskId, false)
        await selectConversation(currentConv.id)
      }
    } catch (err: any) {
      console.error('Execute failed:', err)
      setMessages(prev => prev.map((m, i) => i === msgIndex ? { ...m, status: 'pending_verification' } : m))
    } finally {
      setBusyMsgIndex(null)
    }
  }

  // Reject SQL
  const handleReject = (msgIndex: number) => {
    setMessages(prev => prev.map((m, i) => i === msgIndex ? { ...m, status: 'rejected' } : m))
  }

  // Regenerate SQL with feedback
  const handleRegenerate = async (msgIndex: number, feedback: string) => {
    if (!currentConv || !feedback.trim()) return
    setBusyMsgIndex(msgIndex)
    setMessages(prev => prev.map((m, i) => i === msgIndex ? { ...m, status: 'regenerating' } : m))

    try {
      const data = await pipelineApi.regenerate(currentConv.id, msgIndex, feedback)
      if (data.success && data.taskId) {
        await streamTask(data.taskId, false)
        await selectConversation(currentConv.id)
      }
    } catch (err: any) {
      console.error('Regenerate failed:', err)
      setMessages(prev => prev.map((m, i) => i === msgIndex ? { ...m, status: 'rejected' } : m))
    } finally {
      setBusyMsgIndex(null)
    }
  }

  // Cancel reject
  const handleCancelReject = (msgIndex: number) => {
    setMessages(prev => prev.map((m, i) => i === msgIndex ? { ...m, status: 'pending_verification' } : m))
  }

  // Admin: Save context remark
  const handleSaveRemark = async (msgIndex: number, remark: string) => {
    if (!currentConv || !remark.trim()) return
    try {
      await adminApi.addRemark(currentConv.id, msgIndex, remark.trim())
      setMessages(prev => prev.map((m, i) => i === msgIndex ? {
        ...m,
        admin_remark: remark.trim(),
        admin_remark_by: user?.username,
      } : m))
    } catch (err) {
      console.error('Failed to save remark:', err)
    }
  }

  // Admin: Save edited context
  const handleSaveContext = async (msgIndex: number, context: string) => {
    if (!currentConv) return
    try {
      await adminApi.updateContext(currentConv.id, msgIndex, context)
      setMessages(prev => prev.map((m, i) => i === msgIndex ? {
        ...m,
        context,
        context_edited: true,
        context_edited_by: user?.username,
      } : m))
    } catch (err) {
      console.error('Failed to update context:', err)
    }
  }

  // Admin: Regenerate SQL with modified context
  const handleRegenerateWithContext = async (msgIndex: number, context: string, feedback: string) => {
    if (!currentConv) return
    setBusyMsgIndex(msgIndex)
    setMessages(prev => prev.map((m, i) => i === msgIndex ? { ...m, status: 'regenerating' } : m))

    try {
      // Save the modified context first
      await adminApi.updateContext(currentConv.id, msgIndex, context)

      // Trigger regeneration with the custom context
      const data = await pipelineApi.regenerate(
        currentConv.id, msgIndex,
        feedback || 'Context modified by admin — regenerating SQL with updated context.',
        undefined,
        context,
      )
      if (data.success && data.taskId) {
        await streamTask(data.taskId, false)
        await selectConversation(currentConv.id)
      }
    } catch (err: any) {
      console.error('Regenerate with context failed:', err)
      setMessages(prev => prev.map((m, i) => i === msgIndex ? { ...m, status: 'rejected' } : m))
    } finally {
      setBusyMsgIndex(null)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleAsk()
    }
  }

  return (
    <div className="app-layout">
      <Sidebar
        user={user!}
        conversations={conversations}
        currentConvId={currentConv?.id || null}
        onSelectConv={selectConversation}
        onNewChat={newChat}
        onDeleteConv={deleteConversation}
        showAllUsers={showAllUsers}
        onToggleAllUsers={() => setShowAllUsers(prev => !prev)}
      />
      <div className="app-main">
        <div className="app-header">
          <div className="header-left">
            <span className="header-title">{currentConv?.title || 'New Chat'}</span>
          </div>
          <div className="header-right">
            <HealthBadge />
          </div>
        </div>

        <div className="chat-container">
          {messages.length === 0 ? (
            <div className="welcome-screen">
              <h2>👋 Welcome to UID Data Query Assistant</h2>
              <p>Ask questions about UID/Aadhaar data in natural language.</p>
              <div className="welcome-examples">
                {EXAMPLES.map((ex, i) => (
                  <div key={i} className="welcome-example" onClick={() => setInput(ex)}>
                    💡 {ex}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="message-list">
              {messages.map((msg, i) => (
                <MessageView
                  key={i}
                  message={msg}
                  msgIndex={i}
                  conversationId={currentConv?.id}
                  onRun={handleRun}
                  onReject={handleReject}
                  onRegenerate={handleRegenerate}
                  onCancelReject={handleCancelReject}
                  feedbackValue={feedbackValues[i] || ''}
                  onFeedbackChange={(val) => setFeedbackValues(prev => ({ ...prev, [i]: val }))}
                  busy={busyMsgIndex === i}
                  isAdmin={isAdmin}
                  onSaveRemark={handleSaveRemark}
                  onSaveContext={handleSaveContext}
                  onRegenerateWithContext={handleRegenerateWithContext}
                />
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}

          <div className="chat-input-area">
            <div className="chat-input-wrapper">
              <textarea
                className="chat-input"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask a question about UID/Aadhaar data..."
                rows={1}
                disabled={loading}
              />
              <button className="btn btn-primary" onClick={handleAsk} disabled={loading || !input.trim()}>
                {loading ? <span className="spinner" /> : 'Send'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

import { Sidebar } from '../components/Sidebar'
import { healthApi } from '../api'

function HealthBadge() {
  const [status, setStatus] = useState<'online' | 'offline' | 'checking'>('checking')

  useEffect(() => {
    const check = async () => {
      try {
        const data = await healthApi.check()
        if (data.services) {
          setStatus(data.services.trino === 'online' && data.services.llm === 'online' ? 'online' : 'offline')
        }
      } catch {
        setStatus('offline')
      }
    }
    check()
    const interval = setInterval(check, 30000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="health-badge">
      <span className={`health-dot ${status}`} />
      {status === 'online' ? 'All Systems Online' : status === 'checking' ? 'Checking...' : 'System Issues'}
    </div>
  )
}
