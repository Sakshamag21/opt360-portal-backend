import { createContext, useContext, useState, useEffect } from 'react'
import type { ReactNode } from 'react'
import type { User } from './types'
import { authApi, setTokens, clearTokens, setCurrentUser, getCurrentUser } from './api'

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (username: string, password: string) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check for existing token on mount
    const savedUser = getCurrentUser()
    const token = localStorage.getItem('token')
    if (savedUser && token) {
      // Verify token is still valid
      authApi.me()
        .then(data => {
          if (data.success && data.user) {
            setUser(data.user)
            setCurrentUser(data.user)
          } else {
            clearTokens()
            setUser(null)
          }
        })
        .catch(() => {
          clearTokens()
          setUser(null)
        })
        .finally(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [])

  const login = async (username: string, password: string) => {
    const data = await authApi.login(username, password)
    if (data.success && data.token) {
      setTokens(data.token, data.refreshToken)
      setCurrentUser(data.user)
      setUser(data.user)
    } else {
      throw new Error(data.error || 'Login failed')
    }
  }

  const logout = () => {
    clearTokens()
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
