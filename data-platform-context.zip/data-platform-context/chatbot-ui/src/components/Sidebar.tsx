import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import type { User, Conversation } from '../types'
import { useAuth } from '../auth-context'

interface Props {
  user: User
  conversations: Conversation[]
  currentConvId: string | null
  onSelectConv: (id: string) => void
  onNewChat: () => void
  onDeleteConv: (id: string) => void
  showAllUsers?: boolean
  onToggleAllUsers?: () => void
}

export function Sidebar({ user, conversations, currentConvId, onSelectConv, onNewChat, onDeleteConv, showAllUsers, onToggleAllUsers }: Props) {
  const { logout } = useAuth()
  const location = useLocation()
  const [showUserMenu, setShowUserMenu] = useState(false)

  const initials = (user.fullName || user.username).slice(0, 2).toUpperCase()

  return (
    <aside className="app-sidebar">
      <div className="sidebar-header">
        <span className="logo">🏛️</span>
        <div>
          <div className="title">UID Query Assistant</div>
          <div className="subtitle">GraphRAG + GLM-5.2</div>
        </div>
      </div>

      <div className="sidebar-section">
        <button className="btn btn-primary btn-block" onClick={onNewChat}>➕ New Chat</button>
      </div>

      {user.role === 'admin' && (
        <div className="sidebar-section">
          <div className="sidebar-section-title">Navigation</div>
          <Link to="/" className="nav-link">
            <div className={`conversation-item ${location.pathname === '/' ? 'active' : ''}`}>
              <span className="conv-title">💬 Chat</span>
            </div>
          </Link>
          <Link to="/admin" className="nav-link">
            <div className={`conversation-item ${location.pathname === '/admin' ? 'active' : ''}`}>
              <span className="conv-title">👥 User Management</span>
            </div>
          </Link>
          <Link to="/add-table" className="nav-link">
            <div className={`conversation-item ${location.pathname === '/add-table' ? 'active' : ''}`}>
              <span className="conv-title">📊 Add Table to Graph</span>
            </div>
          </Link>
          <Link to="/audit" className="nav-link">
            <div className={`conversation-item ${location.pathname === '/audit' ? 'active' : ''}`}>
              <span className="conv-title">📋 Audit Log</span>
            </div>
          </Link>
        </div>
      )}

      <div className="sidebar-section">
        <div className="sidebar-section-title">
          Conversations ({conversations.length})
          {user.role === 'admin' && onToggleAllUsers && (
            <button
              className={`toggle-btn ${showAllUsers ? 'active' : ''}`}
              onClick={onToggleAllUsers}
              title={showAllUsers ? 'Showing all users' : 'Showing only your conversations'}
              style={{ marginLeft: 'auto', fontSize: '0.7rem', padding: '2px 8px' }}
            >
              {showAllUsers ? '🌐 All Users' : '👤 Mine'}
            </button>
          )}
        </div>
      </div>

      <div className="sidebar-content">
        {conversations.length === 0 ? (
          <div className="empty-state">No conversations yet</div>
        ) : (
          conversations.map(conv => (
            <div
              key={conv.id}
              className={`conversation-item ${conv.id === currentConvId ? 'active' : ''}`}
              onClick={() => onSelectConv(conv.id)}
              style={{ margin: '0 0.5rem 2px' }}
            >
              <span className="conv-title">{conv.title}</span>
              {showAllUsers && conv.username && (
                <span className="conv-user" style={{ fontSize: '0.7rem', color: '#888', display: 'block' }}>by {conv.username}</span>
              )}
              <button
                className="conv-delete"
                onClick={(e) => { e.stopPropagation(); onDeleteConv(conv.id) }}
                title="Delete conversation"
              >
                🗑️
              </button>
            </div>
          ))
        )}
      </div>

      <div className="sidebar-footer">
        {showUserMenu ? (
          <div>
            <div className="user-chip" onClick={() => setShowUserMenu(false)}>
              <div className="user-avatar">{initials}</div>
              <div className="user-info">
                <div className="user-name">{user.fullName || user.username}</div>
                <div className="user-role">{user.role}</div>
              </div>
            </div>
            <div style={{ marginTop: '0.5rem' }}>
              <button className="btn btn-secondary btn-block btn-sm" onClick={logout}>Sign Out</button>
            </div>
          </div>
        ) : (
          <div className="user-chip" onClick={() => setShowUserMenu(true)}>
            <div className="user-avatar">{initials}</div>
            <div className="user-info">
              <div className="user-name">{user.fullName || user.username}</div>
              <div className="user-role"><span className={`role-badge ${user.role}`}>{user.role}</span></div>
            </div>
          </div>
        )}
      </div>
    </aside>
  )
}
