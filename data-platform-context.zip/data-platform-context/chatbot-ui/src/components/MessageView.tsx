import { useState, useEffect } from 'react'
import type { Message } from '../types'
import { feedbackApi } from '../api'

interface Props {
  message: Message
  msgIndex: number
  conversationId?: string
  onRun: (msgIndex: number) => void
  onReject: (msgIndex: number) => void
  onRegenerate: (msgIndex: number, feedback: string) => void
  onCancelReject: (msgIndex: number) => void
  feedbackValue: string
  onFeedbackChange: (value: string) => void
  busy: boolean
  isAdmin?: boolean
  onSaveRemark?: (msgIndex: number, remark: string) => void
  onSaveContext?: (msgIndex: number, context: string) => void
  onRegenerateWithContext?: (msgIndex: number, context: string, feedback: string) => void
}

export function MessageView({
  message, msgIndex, conversationId, onRun, onReject, onRegenerate, onCancelReject,
  feedbackValue, onFeedbackChange, busy,
  isAdmin, onSaveRemark, onSaveContext, onRegenerateWithContext,
}: Props) {
  const [showThoughts, setShowThoughts] = useState(false)
  const [showContext, setShowContext] = useState(false)
  const [showPerf, setShowPerf] = useState(false)
  const [editingContext, setEditingContext] = useState(false)
  const [contextDraft, setContextDraft] = useState('')
  const [contextFeedback, setContextFeedback] = useState('')
  const [remarkDraft, setRemarkDraft] = useState('')
  const [mergeState, setMergeState] = useState<'idle' | 'checking' | 'available' | 'merging' | 'merged' | 'none'>('idle')
  const [mergeResult, setMergeResult] = useState<any>(null)

  if (message.role === 'user') {
    return (
      <div className="message user">
        <div className="message-avatar">👤</div>
        <div className="message-content">
          <div className="message-author">You</div>
          <div className="message-text">{message.content}</div>
        </div>
      </div>
    )
  }

  // Assistant message
  const status = message.status
  const steps = message.steps || []
  const feedbackHistory = message.feedback_history || []
  const hasReasoning = message.reasoning && message.reasoning.trim()
  const hasContext = message.context && message.context.trim()

  // Check if this message has feedback that can be merged to graph
  useEffect(() => {
    if (status === 'completed' && conversationId && mergeState === 'idle' && !message.feedback_merged) {
      setMergeState('checking')
      feedbackApi.check(conversationId, msgIndex).then(data => {
        if (data.success && data.hasFeedback && !data.alreadyMerged) {
          setMergeState('available')
        } else if (data.success && data.alreadyMerged) {
          setMergeState('merged')
        } else {
          setMergeState('none')
        }
      }).catch(() => setMergeState('none'))
    } else if (message.feedback_merged) {
      setMergeState('merged')
    }
  }, [status, conversationId, msgIndex, message.feedback_merged])

  const handleMergeFeedback = async () => {
    if (!conversationId) return
    setMergeState('merging')
    try {
      const data = await feedbackApi.merge(conversationId, msgIndex)
      if (data.success) {
        setMergeResult(data)
        setMergeState('merged')
      } else {
        setMergeState('available')
      }
    } catch (err) {
      setMergeState('available')
    }
  }

  return (
    <div className="message assistant">
      <div className="message-avatar">🤖</div>
      <div className="message-content">
        <div className="message-author">Assistant</div>

        {/* Error (pipeline failed before SQL) */}
        {message.error && !message.sql && (
          <div className="verify-banner rejected">
            <span className="icon">❌</span>
            <span className="text">{message.error}</span>
          </div>
        )}

        {/* Pipeline steps */}
        {steps.length > 0 && (
          <div className="pipeline-steps">
            {steps.map((s, i) => {
              const icon = { done: '✅', error: '❌', warning: '⚠️', pending: '⏳' }[s.status] || '⏳'
              return (
                <span key={i} className={`step-badge step-${s.status}`}>
                  {icon} {s.name} · {s.elapsed || 0}s
                </span>
              )
            })}
          </div>
        )}

        {/* Feedback history */}
        {feedbackHistory.map((fh, i) => (
          <div key={i} className="feedback-history">
            <span className="label">↩️ Feedback #{i + 1}:</span> {fh.feedback}
          </div>
        ))}

        {/* ─── Thoughts Panel (LLM Reasoning) ─── */}
        {hasReasoning && (
          <div className="collapsible-panel">
            <button
              className="panel-toggle"
              onClick={() => setShowThoughts(!showThoughts)}
            >
              {showThoughts ? '▼' : '▶'} 🧠 Thoughts (LLM Reasoning)
            </button>
            {showThoughts && (
              <div className="panel-body thoughts-body">
                <pre className="reasoning-text">{message.reasoning}</pre>
              </div>
            )}
          </div>
        )}

        {/* Metadata answer (intent = METADATA or SEMANIC_SEARCH) */}
        {message.metadata_answer && !message.sql && (
          <>
            <div className="section-card"><h4>📋 Metadata Answer</h4></div>
            <div className="metadata-answer" dangerouslySetInnerHTML={{ __html: renderMarkdown(message.metadata_answer) }} />
          </>
        )}

        {/* Generated SQL */}
        {message.sql && (
          <>
            <div className="section-card">
              <h4>
                {status === 'rejected' ? '📝 Generated SQL (rejected)' :
                 status === 'regenerating' ? '📝 Previous SQL (regenerating...)' :
                 feedbackHistory.length > 0 ? `📝 Generated SQL (revision #${feedbackHistory.length})` :
                 '📝 Generated SQL'}
              </h4>
            </div>
            <div className="sql-block">
              <pre>{message.sql}</pre>
            </div>
            {message.elapsed ? <div className="muted">⏱ Pipeline time: {message.elapsed}s</div> : null}
          </>
        )}

        {/* ─── Admin Context Panel ─── */}
        {isAdmin && hasContext && (
          <div className="collapsible-panel admin-panel">
            <button
              className="panel-toggle admin-toggle"
              onClick={() => setShowContext(!showContext)}
            >
              {showContext ? '▼' : '▶'} 📎 Retrieved Context
              {message.context_edited && <span className="edited-badge" title={`Edited by ${message.context_edited_by}`}> ✏️ edited</span>}
            </button>
            {showContext && (
              <div className="panel-body">
                {/* Context view/edit */}
                {editingContext ? (
                  <>
                    <textarea
                      className="context-editor"
                      value={contextDraft}
                      onChange={e => setContextDraft(e.target.value)}
                      rows={15}
                    />
                    <input
                      className="context-feedback-input"
                      type="text"
                      placeholder="Optional: feedback for re-generation (e.g., 'Added missing uid_status table to context')"
                      value={contextFeedback}
                      onChange={e => setContextFeedback(e.target.value)}
                    />
                    <div className="verify-actions" style={{ marginTop: '0.5rem' }}>
                      <button
                        className="btn btn-primary"
                        onClick={() => {
                          if (onRegenerateWithContext) {
                            onRegenerateWithContext(msgIndex, contextDraft, contextFeedback)
                          }
                          setEditingContext(false)
                          setContextFeedback('')
                        }}
                        disabled={busy}
                      >
                        🔄 Save &amp; Re-generate SQL
                      </button>
                      <button
                        className="btn btn-secondary"
                        onClick={() => {
                          if (onSaveContext) onSaveContext(msgIndex, contextDraft)
                          setEditingContext(false)
                        }}
                        disabled={busy}
                      >
                        💾 Save Context Only
                      </button>
                      <button
                        className="btn btn-ghost"
                        onClick={() => setEditingContext(false)}
                      >
                        ↩ Cancel
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <pre className="context-text">{message.context}</pre>
                    {message.original_context && message.context_edited && (
                      <div className="muted" style={{ marginTop: '0.25rem' }}>
                        📝 Original context saved — {message.context!.length.toLocaleString()} chars (was {message.original_context.length.toLocaleString()})
                      </div>
                    )}
                    <div className="verify-actions" style={{ marginTop: '0.5rem' }}>
                      <button
                        className="btn btn-secondary btn-sm"
                        onClick={() => {
                          setContextDraft(message.context || '')
                          setEditingContext(true)
                        }}
                        disabled={busy}
                      >
                        ✏️ Edit Context
                      </button>
                    </div>
                  </>
                )}

                {/* Admin Remark Section */}
                <div className="admin-remark-section" style={{ marginTop: '0.75rem', paddingTop: '0.75rem', borderTop: '1px solid var(--border)' }}>
                  <div className="muted" style={{ fontSize: '0.8rem', marginBottom: '0.25rem' }}>Admin Remark on Context</div>
                  {message.admin_remark && !remarkDraft && (
                    <div className="remark-display" style={{ marginBottom: '0.5rem' }}>
                      <div className="remark-text" style={{ fontStyle: 'italic', color: 'var(--text-secondary)' }}>
                        "{message.admin_remark}"
                      </div>
                      <div className="muted" style={{ fontSize: '0.7rem' }}>
                        — {message.admin_remark_by} · {message.admin_remark_at}
                      </div>
                      <button
                        className="btn btn-ghost btn-sm"
                        onClick={() => setRemarkDraft(message.admin_remark || '')}
                        style={{ marginTop: '0.25rem' }}
                      >
                        ✏️ Edit Remark
                      </button>
                    </div>
                  )}
                  {(!message.admin_remark || remarkDraft) && (
                    <>
                      <textarea
                        className="feedback-textarea"
                        placeholder="Add a remark about this context (e.g., 'Missing uid_status table', 'Join path incorrect')..."
                        value={remarkDraft}
                        onChange={e => setRemarkDraft(e.target.value)}
                        rows={2}
                      />
                      <div className="verify-actions" style={{ marginTop: '0.25rem' }}>
                        <button
                          className="btn btn-primary btn-sm"
                          onClick={() => {
                            if (onSaveRemark && remarkDraft.trim()) {
                              onSaveRemark(msgIndex, remarkDraft)
                              setRemarkDraft('')
                            }
                          }}
                          disabled={!remarkDraft.trim()}
                        >
                          💬 Save Remark
                        </button>
                        {message.admin_remark && (
                          <button
                            className="btn btn-ghost btn-sm"
                            onClick={() => setRemarkDraft('')}
                          >
                            Cancel
                          </button>
                        )}
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Verification UI */}
        {status === 'pending_verification' && message.sql && !busy && (
          <>
            <div className="verify-banner pending">
              <span className="icon">⏳</span>
              <span className="text">
                SQL generated — awaiting your verification
                <div className="sub">Review the query above, then approve to run it or reject to provide corrections.</div>
              </span>
            </div>
            <div className="verify-actions">
              <button className="btn btn-success" onClick={() => onRun(msgIndex)}>✓ Run Query</button>
              <button className="btn btn-danger" onClick={() => onReject(msgIndex)}>✗ Reject &amp; Correct</button>
            </div>
          </>
        )}

        {status === 'pending_verification' && message.sql && busy && (
          <div className="verify-banner executing">
            <span className="icon"><span className="spinner" /></span>
            <span className="text">Processing...</span>
          </div>
        )}

        {status === 'executing' && (
          <div className="verify-banner executing">
            <span className="icon">🔄</span>
            <span className="text">Executing query against Trino...<div className="sub">Results will appear here when ready.</div></span>
          </div>
        )}

        {status === 'regenerating' && (
          <div className="verify-banner regenerating">
            <span className="icon">🤖</span>
            <span className="text">Regenerating SQL with your feedback...<div className="sub">GLM-5.2 is revising the query.</div></span>
          </div>
        )}

        {status === 'rejected' && message.sql && !busy && (
          <>
            <div className="verify-banner rejected">
              <span className="icon">✗</span>
              <span className="text">
                SQL rejected — provide feedback for correction
                <div className="sub">Describe what's wrong and the LLM will regenerate the query.</div>
              </span>
            </div>
            <textarea
              className="feedback-textarea"
              placeholder="e.g., The WHERE clause should filter by uid_status_key = 1 (active), not 0. Also add a GROUP BY registrar_id clause."
              value={feedbackValue}
              onChange={e => onFeedbackChange(e.target.value)}
            />
            <div className="verify-actions">
              <button className="btn btn-primary" onClick={() => onRegenerate(msgIndex, feedbackValue)}>🔄 Regenerate SQL</button>
              <button className="btn btn-secondary" onClick={() => onRun(msgIndex)}>✓ Run Anyway</button>
              <button className="btn btn-ghost" onClick={() => onCancelReject(msgIndex)}>↩ Cancel</button>
            </div>
          </>
        )}

        {status === 'completed' && message.query_result?.success && (
          <div className="verify-banner completed">
            <span className="icon">✅</span>
            <span className="text">Query executed successfully</span>
          </div>
        )}

        {/* ─── Feedback Merge to Graph ─── */}
        {status === 'completed' && mergeState === 'available' && (
          <div className="feedback-merge-banner">
            <div className="feedback-merge-icon">💡</div>
            <div className="feedback-merge-body">
              <div className="feedback-merge-title">Save corrections to knowledge graph?</div>
              <div className="feedback-merge-desc">
                This query was corrected based on your feedback ({feedbackHistory.length} round{feedbackHistory.length !== 1 ? 's' : ''}).
                Merging it to the graph will improve future SQL generation for similar questions.
              </div>
            </div>
            <button className="btn btn-primary" onClick={handleMergeFeedback} disabled={busy}>
              🔗 Merge to Graph
            </button>
          </div>
        )}

        {mergeState === 'merging' && (
          <div className="feedback-merge-banner merging">
            <div className="feedback-merge-icon"><span className="spinner" /></div>
            <div className="feedback-merge-body">
              <div className="feedback-merge-title">Merging feedback to graph...</div>
              <div className="feedback-merge-desc">LLM is consolidating the corrections into a query insight.</div>
            </div>
          </div>
        )}

        {mergeState === 'merged' && (
          <div className="feedback-merge-banner merged">
            <div className="feedback-merge-icon">✅</div>
            <div className="feedback-merge-body">
              <div className="feedback-merge-title">Corrections merged to knowledge graph</div>
              {mergeResult ? (
                <div className="feedback-merge-desc">
                  Insight: <strong>{mergeResult.insightTitle}</strong> · Linked to {mergeResult.tablesLinked} table{mergeResult.tablesLinked !== 1 ? 's' : ''}
                </div>
              ) : (
                <div className="feedback-merge-desc">Future queries will benefit from this learning.</div>
              )}
            </div>
          </div>
        )}

        {/* Query results */}
        {message.query_result && message.query_result.success && message.query_result.rows && message.query_result.rows.length > 0 && (
          <>
            <div className="section-card">
              <h4>📊 Results · {message.query_result.row_count} row{message.query_result.row_count !== 1 ? 's' : ''}</h4>
            </div>
            <div className="results-table">
              <table>
                <thead>
                  <tr>
                    {message.query_result.columns?.map((col, i) => (
                      <th key={i}>{col}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {message.query_result.rows.slice(0, 100).map((row, i) => (
                    <tr key={i}>
                      {row.map((cell, j) => (
                        <td key={j} title={String(cell ?? '')}>{String(cell ?? '')}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {message.query_result.row_count! > 100 && (
              <div className="muted">Showing first 100 of {message.query_result.row_count} rows</div>
            )}
          </>
        )}

        {message.query_result && !message.query_result.success && (
          <div className="verify-banner rejected">
            <span className="icon">❌</span>
            <span className="text">Execution failed: {message.query_result.error || 'unknown error'}</span>
          </div>
        )}

        {/* ─── Query Performance Panel ─── */}
        {message.query_stats && (
          <details className="perf-panel" open={false}>
            <summary className="perf-summary" onClick={(e) => { e.preventDefault(); setShowPerf(!showPerf) }}>
              {showPerf ? '▼' : '▶'} ⚡ Query Performance
              {message.query_stats.cpu_time_ms != null && message.query_stats.cpu_time_ms > 0 && (
                <span className="perf-badge">CPU {(message.query_stats.cpu_time_ms / 1000).toFixed(2)}s</span>
              )}
              {message.query_stats.peak_memory_bytes != null && message.query_stats.peak_memory_bytes > 0 && (
                <span className="perf-badge">{formatBytes(message.query_stats.peak_memory_bytes)} peak</span>
              )}
              {message.query_stats.physical_input_bytes != null && message.query_stats.physical_input_bytes > 0 && (
                <span className="perf-badge">{formatBytes(message.query_stats.physical_input_bytes)} read</span>
              )}
            </summary>
            {showPerf && (
              <div className="perf-body">
                {/* Stats grid */}
                <div className="perf-grid">
                  <div className="perf-stat">
                    <span className="perf-stat-label">Execution Time</span>
                    <span className="perf-stat-value">{formatMs(message.query_stats.execution_time_ms)}</span>
                  </div>
                  <div className="perf-stat">
                    <span className="perf-stat-label">CPU Time</span>
                    <span className="perf-stat-value">{formatMs(message.query_stats.cpu_time_ms)}</span>
                  </div>
                  <div className="perf-stat">
                    <span className="perf-stat-label">Wall Time</span>
                    <span className="perf-stat-value">{formatMs(message.query_stats.wall_time_ms)}</span>
                  </div>
                  <div className="perf-stat">
                    <span className="perf-stat-label">Queued Time</span>
                    <span className="perf-stat-value">{formatMs(message.query_stats.queued_time_ms)}</span>
                  </div>
                  <div className="perf-stat">
                    <span className="perf-stat-label">Peak Memory</span>
                    <span className="perf-stat-value highlight">{formatBytes(message.query_stats.peak_memory_bytes)}</span>
                  </div>
                  <div className="perf-stat">
                    <span className="perf-stat-label">Rows Processed</span>
                    <span className="perf-stat-value">{(message.query_stats.processed_rows ?? 0).toLocaleString()}</span>
                  </div>
                  <div className="perf-stat">
                    <span className="perf-stat-label">Data Processed</span>
                    <span className="perf-stat-value">{formatBytes(message.query_stats.processed_bytes)}</span>
                  </div>
                  <div className="perf-stat">
                    <span className="perf-stat-label">Physical Read</span>
                    <span className="perf-stat-value highlight">{formatBytes(message.query_stats.physical_input_bytes)}</span>
                  </div>
                  <div className="perf-stat">
                    <span className="perf-stat-label">Rows Read</span>
                    <span className="perf-stat-value">{(message.query_stats.physical_input_rows ?? 0).toLocaleString()}</span>
                  </div>
                  <div className="perf-stat">
                    <span className="perf-stat-label">Workers</span>
                    <span className="perf-stat-value">{message.query_stats.active_nodes ?? 0} / {message.query_stats.total_nodes ?? 0}</span>
                  </div>
                  <div className="perf-stat">
                    <span className="perf-stat-label">Query ID</span>
                    <span className="perf-stat-value mono">{message.query_stats.query_id || message.query_result?.query_id || '—'}</span>
                  </div>
                  <div className="perf-stat">
                    <span className="perf-stat-label">State</span>
                    <span className="perf-stat-value">{message.query_stats.state || 'FINISHED'}</span>
                  </div>
                </div>

                {/* EXPLAIN Plan */}
                {message.query_stats.explain_plan && (
                  <details className="explain-plan">
                    <summary>📋 Execution Plan (EXPLAIN)</summary>
                    <pre className="plan-text">{message.query_stats.explain_plan}</pre>
                  </details>
                )}

                {/* EXPLAIN plan from verification stage (if not executed yet) */}
                {!message.query_stats.explain_plan && message.explain_plan && (
                  <details className="explain-plan">
                    <summary>📋 Execution Plan (EXPLAIN)</summary>
                    <pre className="plan-text">{message.explain_plan}</pre>
                  </details>
                )}
              </div>
            )}
          </details>
        )}

        {/* EXPLAIN plan shown during verification (before execution) */}
        {!message.query_stats && message.explain_plan && (
          <details className="perf-panel">
            <summary className="perf-summary" onClick={(e) => { e.preventDefault(); setShowPerf(!showPerf) }}>
              {showPerf ? '▼' : '▶'} 📋 Execution Plan (EXPLAIN)
            </summary>
            {showPerf && (
              <div className="perf-body">
                <pre className="plan-text">{message.explain_plan}</pre>
              </div>
            )}
          </details>
        )}
      </div>
    </div>
  )
}

// Simple markdown to HTML converter for metadata answers
function renderMarkdown(md: string): string {
  let html = md
  // Escape HTML
  html = html.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  // Headers
  html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>')
  html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>')
  html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>')
  // Bold
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  // Inline code
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>')
  // Table (basic — assumes pipe format)
  if (html.includes('|')) {
    const lines = html.split('\n')
    const tableLines = lines.filter(l => l.trim().startsWith('|'))
    if (tableLines.length >= 2) {
      let table = '<table>'
      tableLines.forEach((line, i) => {
        const cells = line.split('|').filter(c => c.trim()).map(c => c.trim())
        if (i === 1 && cells.every(c => /^[-:]+$/.test(c))) return // skip separator
        if (i === 0) {
          table += '<tr>' + cells.map(c => `<th>${c}</th>`).join('') + '</tr>'
        } else {
          table += '<tr>' + cells.map(c => `<td>${c}</td>`).join('') + '</tr>'
        }
      })
      table += '</table>'
      html = html.replace(tableLines.join('\n'), table)
    }
  }
  // Line breaks
  html = html.replace(/\n/g, '<br>')
  return html
}

// ─── Performance formatting helpers ───
function formatBytes(bytes: number | undefined | null): string {
  if (!bytes || bytes === 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let val = bytes
  let unitIdx = 0
  while (val >= 1024 && unitIdx < units.length - 1) {
    val /= 1024
    unitIdx++
  }
  return `${val.toFixed(1)} ${units[unitIdx]}`
}

function formatMs(ms: number | undefined | null): string {
  if (!ms || ms === 0) return '0ms'
  if (ms < 1000) return `${ms}ms`
  return `${(ms / 1000).toFixed(2)}s`
}
