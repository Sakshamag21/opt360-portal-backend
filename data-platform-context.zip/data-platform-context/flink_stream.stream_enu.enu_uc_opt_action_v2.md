# Table: flink_stream.stream_enu.enu_uc_opt_action_v2

## Overview

| Property | Value |
|----------|-------|
| **Catalog** | `flink_stream` |
| **Schema** | `stream_enu` |
| **Table** | `enu_uc_opt_action_v2` |
| **Full Reference** | `flink_stream.stream_enu.enu_uc_opt_action_v2` |
| **Row Count** | ~687M (686,532,381) |
| **Columns** | 32 |
| **Date Range** | 2024-11-15 → present (near-real-time) |
| **Source** | Flink streaming pipeline |
| **Access** | Read-only via Trino at `10.10.116.39:8080` |

## Description

Operator action / stage-event tracking table for Aadhaar enrolment and update sessions. Each row represents **one stage event** (e.g. `FingerValidation`, `DemoCapture`, `OPERATOR_AUTH`) in an enrolment/update client session. Populated by a Flink streaming pipeline.

This table is in a **different schema** (`flink_stream.stream_enu`) from the main UID tables (`strot.mysql_uid_v2`). It has **no `shard_hint` column** — use `event_timestamp` for partition pruning instead.

## Column Dictionary (32 columns)

### Station / Device

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `station_id` | varchar | Enrolment station ID | NULL ~77% |
| `station_machine_code` | varchar | Machine code | NULL ~86% |
| `station_release_version` | varchar | Client software version | Mostly NULL |
| `machine_ip_address` | varchar | Machine IP | Mostly NULL |
| `latitude` | varchar | GPS latitude | NULL ~86%, stored as varchar |
| `longitude` | varchar | GPS longitude | NULL ~86%, stored as varchar |

### Operator

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `operator_uid` | varchar | Encrypted UID of operator | NULL ~50%. PII (encrypted) |
| `operator_id` | varchar | Operator login ID | ~100% populated. Format: `RDDE_GPG_NS804223` |
| `operator_name` | varchar | Operator name (plaintext) | ~84% populated. PII |

### Resident

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `resident_uid` | varchar | Encrypted UID of resident | NULL ~99% (only late stages). PII |
| `resident_sid` | varchar | Resident session ID | NULL ~6%. Links stages in a session |
| `hof_uid` | varchar | Encrypted HoF UID | NULL ~98%. PII |
| `enrolment_type` | varchar | `N`=New, `U`=Update | NULL ~86% (pre-demo stages) |
| `resident_age_group` | varchar | Age group | Almost entirely NULL |
| `resident_type` | varchar | Resident type | Almost entirely NULL |

### Event / Stage

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `update_bit_indicator` | varchar | 32-char binary update flags | NULL ~86%. See below |
| `stage` | varchar | Pipeline stage name | See stage values below |
| `stage_status` | varchar | `Completed` / `INITIATED` / `COMPLETED` | Casing issue — use UPPER() |
| `event_id` | varchar | UUID for this event | Primary event key |
| `event_timestamp` | timestamp | Event time | **Primary filter column**. 2024-11-15 → present |
| `version` | varchar | Schema version | Always `1.0` |
| `txn_id` | varchar | Transaction ID | Mostly NULL |
| `session_id` | varchar | UC session ID (`uc-<UUID>`) | Links all stages in a session |

### Geography / Organization

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `ea` | varchar | Enrolment Agency code | Numeric string |
| `registrar` | varchar | Registrar code | 3-digit numeric |
| `subdistrict` | varchar | Subdistrict | |
| `district` | varchar | District | |
| `state` | varchar | Indian state | Top: UP, Maharashtra, Rajasthan |
| `pincode` | varchar | PIN code | 6-digit |
| `ro` | varchar | Regional Office | Top: Ranchi, Lucknow, Mumbai, Delhi |
| `ea_name` | varchar | EA name | Mostly NULL |
| `reg_name` | varchar | Registrar name | Mostly NULL |

## Stage Values (Workflow)

Stages are roughly ordered by flow:

| Stage | Count | Meaning |
|-------|-------|---------|
| `OPERATOR_AUTH` | 25M | Operator authentication (session start) |
| `DemoCapture` | 95M | Demographic data capture |
| `POIValidation` | 4.6M | Proof of Identity validation |
| `POAValidation` | 4.3M | Proof of Address validation |
| `POBValidation` | 10M | Proof of Birth validation |
| `PORValidation` | 7.8M | Proof of Relationship validation |
| `POFValidation` | 85K | Proof of Family validation |
| `BioAuth` | 72M | Biometric authentication |
| `FingerValidation` | 147M | Fingerprint capture/validation |
| `IrisValidation` | 94M | Iris scan capture/validation |
| `FaceValidation` | 62M | Face photo capture/validation |
| `ExceptionPhotoValidation` | 65K | Exception photo (biometric exceptions) |
| `SRNGeneration` | 16M | Service Request Number generation |
| `AckSlipUpload` | 70M | Acknowledgement slip upload |
| `AckSlipDownload` | 74M | Acknowledgement slip download |
| `UserCancel` | 5.3M | User cancelled the session |

> ⚠️ **Data quality issue:** ~12K rows have Indian state names (Maharashtra, UP, etc.) in the `stage` column. Filter with `WHERE stage IN (...)` for clean results.

## stage_status Values

| Value | Count | % | Meaning |
|-------|-------|---|---------|
| `Completed` | 662M | 96.4% | Stage completed |
| `INITIATED` | 15M | 2.2% | Stage initiated (in-progress/abandoned) |
| `COMPLETED` | 9.7M | 1.4% | Same as 'Completed' (uppercase variant) |

> ⚠️ Use `UPPER(stage_status) = 'COMPLETED'` to match both casing variants.

## update_bit_indicator

32-character binary string where each position represents a field updated in this event:
- `'1'` = field updated
- `'0'` = field not updated
- `NULL` = not an update event (new enrolment or pre-demographic stage)

Most common pattern: `10111000000010000000000000000000` (78M rows)

Check individual positions with: `substring(update_bit_indicator, <position>, 1) = '1'`

> The exact bit-position-to-field mapping needs official confirmation but is believed to align with the `updt_*` flag order in `uid_origin_tracker_enriched`.

## Querying Guidance

1. **No `shard_hint`** — use `event_timestamp` for partition pruning
2. **Always add LIMIT** — 687M rows
3. **stage_status casing** — use `UPPER(stage_status) = 'COMPLETED'`
4. **stage data quality** — filter with `WHERE stage IN (...)` to exclude ~12K bad rows
5. **update_bit_indicator** — use `substring(col, pos, 1) = '1'` for individual bits
6. **Counting sessions** — `count(DISTINCT session_id)`
7. **Counting residents** — `count(DISTINCT resident_uid)` but note ~99% NULL
8. **Track a session journey** — `WHERE session_id = 'uc-...'` ordered by `event_timestamp`
9. **PII** — `operator_uid`, `resident_uid`, `hof_uid` are encrypted; `operator_name` is plaintext

## Example Queries

### Count events by stage (last 7 days)

```sql
SELECT stage, count(*) AS cnt
FROM flink_stream.stream_enu.enu_uc_opt_action_v2
WHERE event_timestamp >= current_date - interval '7' day
  AND stage IN ('FingerValidation','DemoCapture','IrisValidation','AckSlipDownload',
                'BioAuth','AckSlipUpload','FaceValidation','OPERATOR_AUTH',
                'SRNGeneration','POBValidation','PORValidation','UserCancel',
                'POIValidation','POAValidation','POFValidation','ExceptionPhotoValidation')
GROUP BY stage
ORDER BY cnt DESC
LIMIT 100
```

### Track a single session's journey

```sql
SELECT stage, stage_status, event_timestamp, operator_id, enrolment_type
FROM flink_stream.stream_enu.enu_uc_opt_action_v2
WHERE session_id = 'uc-4c8869f2-81df-4ce1-9a24-10145c94e0ec'
ORDER BY event_timestamp
LIMIT 100
```

### Completion rate by stage (last 1 month)

```sql
SELECT
    stage,
    count(*) AS total_events,
    count_if(UPPER(stage_status) = 'COMPLETED') AS completed,
    round(count_if(UPPER(stage_status) = 'COMPLETED') * 100.0 / count(*), 2) AS completion_pct
FROM flink_stream.stream_enu.enu_uc_opt_action_v2
WHERE event_timestamp >= current_date - interval '1' month
GROUP BY stage
ORDER BY total_events DESC
LIMIT 100
```

### Update events by state (last 1 month)

```sql
SELECT state, count(*) AS update_events
FROM flink_stream.stream_enu.enu_uc_opt_action_v2
WHERE event_timestamp >= current_date - interval '1' month
  AND enrolment_type = 'U'
  AND state IS NOT NULL
GROUP BY state
ORDER BY update_events DESC
LIMIT 100
```
