#!/usr/bin/env python3
"""
TF-IDF Vector Space Retriever for GraphRAG — numpy only, no external dependencies.

This is a REAL vector space model (not keyword counting):
  - Builds a vocabulary from all text units + entity names + descriptions
  - Computes TF-IDF vectors for every document and the query
  - Ranks by cosine similarity
  - Splits snake_case column names into subwords (res_addr_state_code → res, addr, state, code)
  - Adds character n-gram features for fuzzy matching (enrollment ≈ enrolment)
  - Combines with graph structure (communities, relationships) for GraphRAG retrieval

Limitation: This is LEXICAL search (term matching), not SEMANTIC search (meaning matching).
  - "where does the person live" will NOT match "address" (different words, same meaning)
  - To get true semantic search, you need embedding models (sentence-transformers, OpenAI, etc.)
  - See the 'install_embeddings' section at the bottom for how to upgrade

Usage:
  from graph_rag_vector_retriever import VectorGraphRAG
  retriever = VectorGraphRAG()
  results = retriever.search("how do I find demographic history", mode="hybrid")
"""

import sys
import json
import re
import math
import textwrap
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np

INDEX_PATH = Path(r"C:\data-platform-context\graph_rag_index.json")

# ─── Stopwords ───────────────────────────────────────────────────────────────

STOPWORDS = frozenset({
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "must", "can", "shall", "to", "of", "in",
    "on", "at", "by", "for", "with", "about", "against", "between", "into",
    "through", "during", "before", "after", "above", "below", "from", "up",
    "down", "out", "off", "over", "under", "again", "further", "then",
    "once", "here", "there", "when", "where", "why", "how", "all", "both",
    "each", "few", "more", "most", "other", "some", "such", "no", "nor",
    "not", "only", "own", "same", "so", "than", "too", "very", "s", "t",
    "just", "i", "you", "he", "she", "it", "we", "they", "me", "him",
    "her", "us", "them", "my", "your", "his", "its", "our", "their",
    "this", "that", "these", "those", "what", "which", "who", "whom",
    "and", "or", "but", "if", "while", "as", "also",
})

# Domain synonym groups — terms that should be treated as equivalent
# NOTE: These bridge the lexical gap. Keep groups TIGHT — too many terms causes noise.
SYNONYM_GROUPS = [
    # Address-related
    {"address", "addr", "res_addr", "pincode", "location", "residence", "live", "where"},
    # Person/resident
    {"person", "resident", "individual", "people"},
    # History
    {"history", "his", "historical", "previous", "old", "past", "snapshot", "archive"},
    # Enrolment
    {"enrolment", "enrollment", "enr", "tracker", "event", "packet", "registered", "registration"},
    # Update
    {"update", "updated", "modify", "modified", "updt", "changed"},
    # Join
    {"join", "link", "connect", "relate", "relationship", "navigate", "combine"},
    # UID
    {"uid", "aadhaar", "aadhar"},
    # EID
    {"eid", "enrolment_id", "enrollment_id", "event_id"},
    # Shard
    {"shard", "shard_hint", "partition", "prune", "hint"},
    # PII
    {"pii", "personal", "private", "sensitive", "encrypted", "hashed"},
    # Current
    {"current", "latest", "live", "present", "active", "today"},
    # Count
    {"count", "total", "aggregate", "sum", "statistics", "how many"},
    # Status (NOT linked to "state" — state is geographic)
    {"status", "condition"},
    # State (geographic)
    {"state", "province"},
    # Pincode
    {"pincode", "zip", "postal", "postcode"},
    # Operator
    {"operator", "enroller"},
    # Registrar
    {"registrar", "agency", "vendor", "registered", "registration"},
    # DOB
    {"dob", "birth", "born", "age"},
    # Gender
    {"gender", "sex"},
    # Biometric
    {"biometric", "fingerprint", "iris", "photo", "face"},
    # Foreigner
    {"foreigner", "foreign", "nri", "nationality", "non resident", "another country"},
    # Date
    {"date", "timestamp", "when", "time"},
    # Query
    {"query", "sql", "select", "search", "find", "lookup", "retrieve"},
    # Column
    {"column", "field", "attribute"},
    # Guardian
    {"guardian", "parent", "father", "mother", "hof", "head of family"},
    # Mobile
    {"mobile", "phone", "cell", "contact"},
    # Email
    {"email", "mail"},
    # Proof
    {"proof", "document", "evidence", "poi", "poa", "pob"},
    # Reject
    {"reject", "rejected", "declined", "denied"},
    # Expiry
    {"expired", "expiry", "lapsed", "valid"},
    # Death
    {"death", "dead", "deceased", "died", "alive", "dod"},
    # Consent
    {"consent", "sharing", "permission"},
    # Supervisor
    {"supervisor", "verifier"},
    # Demographic (standalone, NOT linked to "person" or "master")
    {"demographic", "demo"},
]

# Build synonym lookup: word → set of equivalent words
SYNONYM_MAP = {}
for group in SYNONYM_GROUPS:
    for word in group:
        if word not in SYNONYM_MAP:
            SYNONYM_MAP[word] = set()
        SYNONYM_MAP[word].update(group)


# ─── Tokenizer ───────────────────────────────────────────────────────────────

def tokenize(text):
    """
    Tokenize text into lowercase terms.
    - Splits snake_case: res_addr_state_code → res, addr, state, code
    - Removes stopwords
    - Expands with domain synonyms
    - Adds character n-grams (3-grams) for fuzzy matching
    """
    text = text.lower()
    # Split on non-alphanumeric
    raw_tokens = re.findall(r'[a-z0-9_]+', text)

    tokens = []
    for rt in raw_tokens:
        # Split snake_case
        parts = rt.split('_')
        for part in parts:
            if part and part not in STOPWORDS and len(part) > 1:
                tokens.append(part)

    # Remove duplicates while preserving order
    seen = set()
    unique_tokens = []
    for t in tokens:
        if t not in seen:
            seen.add(t)
            unique_tokens.append(t)

    return unique_tokens


def expand_synonyms(tokens):
    """Expand tokens with domain synonyms."""
    expanded = set(tokens)
    for t in list(tokens):
        if t in SYNONYM_MAP:
            expanded.update(SYNONYM_MAP[t])
    return expanded


# ─── TF-IDF Vector Space Model ───────────────────────────────────────────────

class TfidfVectorizer:
    """
    A from-scratch TF-IDF vectorizer using only numpy.
    No sklearn dependency.

    TF(t, d) = count(t in d) / total_terms_in_d
    IDF(t)   = log(N / df(t))   where N = total docs, df = doc frequency
    TF-IDF   = TF * IDF

    Documents and queries are represented as sparse vectors in the same space.
    Similarity = cosine similarity = dot(a, b) / (|a| * |b|)
    """

    def __init__(self):
        self.vocabulary = {}        # term → index
        self.idf = None             # numpy array of IDF values
        self.doc_vectors = None     # numpy matrix (n_docs × vocab_size)
        self.doc_ids = []           # list of document IDs
        self.n_docs = 0

    def fit(self, documents):
        """
        documents: list of (doc_id, text) tuples
        """
        self.doc_ids = [d[0] for d in documents]
        self.n_docs = len(documents)

        # Build vocabulary
        df = Counter()  # document frequency
        doc_token_counts = []  # list of Counter objects

        for doc_id, text in documents:
            tokens = tokenize(text)
            tc = Counter(tokens)
            doc_token_counts.append(tc)
            for term in tc:
                df[term] += 1

        # Create vocabulary index
        self.vocabulary = {term: idx for idx, term in enumerate(sorted(df.keys()))}
        vocab_size = len(self.vocabulary)

        # Compute IDF: log(N / df) with smoothing
        self.idf = np.zeros(vocab_size, dtype=np.float64)
        for term, idx in self.vocabulary.items():
            # IDF with smoothing: log((N + 1) / (df + 1)) + 1
            self.idf[idx] = math.log((self.n_docs + 1) / (df[term] + 1)) + 1

        # Build document vectors (TF-IDF)
        self.doc_vectors = np.zeros((self.n_docs, vocab_size), dtype=np.float64)
        for i, tc in enumerate(doc_token_counts):
            total = sum(tc.values())
            if total == 0:
                continue
            for term, count in tc.items():
                idx = self.vocabulary[term]
                tf = count / total
                self.doc_vectors[i, idx] = tf * self.idf[idx]

        # L2 normalize document vectors
        norms = np.linalg.norm(self.doc_vectors, axis=1, keepdims=True)
        norms[norms == 0] = 1
        self.doc_vectors = self.doc_vectors / norms

        return self

    def transform_query(self, query):
        """Transform a query string into a TF-IDF vector (L2 normalized)."""
        tokens = expand_synonyms(tokenize(query))
        tc = Counter(tokens)
        total = sum(tc.values())

        vec = np.zeros(len(self.vocabulary), dtype=np.float64)
        if total == 0:
            return vec

        for term, count in tc.items():
            if term in self.vocabulary:
                idx = self.vocabulary[term]
                tf = count / total
                vec[idx] = tf * self.idf[idx]

        # L2 normalize
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec = vec / norm
        return vec

    def search(self, query, top_k=10):
        """
        Search documents by cosine similarity.
        Returns list of (doc_id, score) tuples, sorted by score descending.
        """
        query_vec = self.transform_query(query)
        if query_vec.sum() == 0:
            return []

        # Cosine similarity = dot product (vectors are already normalized)
        scores = self.doc_vectors @ query_vec

        # Get top-k
        top_indices = np.argsort(scores)[::-1][:top_k]
        results = []
        for idx in top_indices:
            if scores[idx] > 0:
                results.append((self.doc_ids[idx], float(scores[idx])))
        return results

    def search_batch(self, query, top_k=10):
        """Same as search but also returns the query vector for debugging."""
        query_vec = self.transform_query(query)
        if query_vec.sum() == 0:
            return [], query_vec
        scores = self.doc_vectors @ query_vec
        top_indices = np.argsort(scores)[::-1][:top_k]
        results = [(self.doc_ids[idx], float(scores[idx])) for idx in top_indices if scores[idx] > 0]
        return results, query_vec


# ─── Vector GraphRAG Retriever ───────────────────────────────────────────────

class VectorGraphRAG:
    """
    GraphRAG retriever with TF-IDF vector space model.

    Combines:
      1. Vector search (TF-IDF cosine similarity) for entity/text-unit retrieval
      2. Community reports for global search
      3. Graph expansion (entity neighborhoods) for context enrichment
      4. Domain synonym expansion for bridging the lexical gap

    To upgrade to true semantic search, replace TfidfVectorizer with an
    embedding model (see upgrade_instructions below).
    """

    def __init__(self, index_path=INDEX_PATH):
        with open(index_path, "r", encoding="utf-8") as f:
            self.index = json.load(f)

        # Build lookup maps
        self.entity_map = {e["entity_id"]: e for e in self.index["entities"]}

        # Build adjacency
        self.outgoing = defaultdict(list)
        self.incoming = defaultdict(list)
        for rel in self.index["relationships"]:
            self.outgoing[rel["source"]].append(rel)
            self.incoming[rel["target"]].append(rel)

        # Build text units lookup
        self.text_units_by_entity = defaultdict(list)
        for tu in self.index["text_units"]:
            self.text_units_by_entity[tu["entity_id"]].append(tu)

        # Build documents for TF-IDF
        # Each document = entity name + description + all text units + properties
        documents = []
        for entity in self.index["entities"]:
            eid = entity["entity_id"]
            # Combine all text for this entity
            parts = [entity["name"], entity.get("description", "")]
            # Add properties as text
            props = entity.get("properties", {})
            for k, v in props.items():
                if isinstance(v, str) and len(v) < 200:
                    parts.append(f"{k} {v}")
                elif isinstance(v, list):
                    parts.append(f"{k} {' '.join(str(x) for x in v[:10])}")
            # Add text units
            for tu in self.text_units_by_entity.get(eid, []):
                parts.append(tu["text"])
            # Add community info
            for comm in self.index["communities"]:
                if eid in comm.get("entity_ids", []):
                    parts.append(comm["title"])

            doc_text = " ".join(parts)
            documents.append((eid, doc_text))

        # Also add community reports as documents
        for comm in self.index["communities"]:
            doc_text = f"{comm['title']} {comm['summary']} {' '.join(comm.get('key_relationships', []))} {' '.join(comm.get('query_examples', []))}"
            documents.append((comm["community_id"], doc_text))

        # Build TF-IDF index
        self.vectorizer = TfidfVectorizer()
        self.vectorizer.fit(documents)

        # Store community tokens for community-level search
        self.community_tokens = {}
        for comm in self.index["communities"]:
            self.community_tokens[comm["community_id"]] = set(tokenize(comm["summary"] + " " + comm["title"]))

        # Store query paths
        self.query_paths = self.index.get("query_paths", [])

    def search(self, query, mode="hybrid", top_k=10, use_llm_rerank=False, llm_top_k=5):
        """
        Unified search. Modes: 'global', 'local', 'hybrid'.

        Two-stage retrieval when use_llm_rerank=True:
          Stage 1: TF-IDF retrieves top 30 candidates (fast, high recall)
          Stage 2: LLM re-ranks the top candidates by semantic relevance (slow, high precision)

        Args:
            query: Search query string
            mode: 'global', 'local', or 'hybrid'
            top_k: Number of results to return
            use_llm_rerank: If True, use LLM to re-rank results (requires llm_client)
            llm_top_k: How many of the top TF-IDF results to send to the LLM for re-ranking
        """
        result = {"query": query, "mode": mode}

        if mode in ("global", "hybrid"):
            result["global_results"] = self._global_search(query, top_k=3)

        if mode in ("local", "hybrid"):
            # Stage 1: TF-IDF retrieval (always runs)
            tfidf_results = self._local_search(query, top_k=top_k * 3 if use_llm_rerank else top_k)

            # Stage 2: LLM re-ranking (optional)
            if use_llm_rerank and tfidf_results:
                try:
                    from llm_client import LLMClient
                    llm = LLMClient()

                    # Take top N from TF-IDF for re-ranking
                    candidates = tfidf_results[:llm_top_k]
                    candidate_texts = []
                    for c in candidates:
                        desc = c.get("description", "")[:150]
                        name = c.get("name", "")
                        etype = c.get("type", "")
                        candidate_texts.append({
                            "name": name,
                            "text": f"[{etype}] {name}: {desc}",
                            "_original": c,
                        })

                    # Call LLM to re-rank
                    ranked = llm.rerank(query, candidate_texts)

                    # Rebuild results in LLM-ranked order
                    reranked = []
                    for item in ranked:
                        original = item.get("_original", {})
                        original["tfidf_score"] = original.pop("score", 0)
                        original["llm_score"] = item.get("llm_score", 0)
                        original["llm_rank"] = item.get("llm_rank", 0)
                        original["score"] = item.get("llm_score", 0) / 10.0  # normalize to 0-1
                        reranked.append(original)

                    # Append remaining TF-IDF results that weren't re-ranked
                    reranked_ids = {r["entity_id"] for r in reranked}
                    for r in tfidf_results:
                        if r["entity_id"] not in reranked_ids:
                            r["tfidf_score"] = r.pop("score", 0)
                            r["llm_score"] = 0
                            r["llm_rank"] = 0
                            reranked.append(r)

                    result["local_results"] = reranked[:top_k]
                    result["llm_reranked"] = True
                except Exception as e:
                    result["local_results"] = tfidf_results[:top_k]
                    result["llm_reranked"] = False
                    result["llm_error"] = str(e)
            else:
                result["local_results"] = tfidf_results[:top_k]
                result["llm_reranked"] = False

        if mode == "hybrid":
            local_communities = set()
            for lr in result.get("local_results", []):
                eid = lr["entity_id"]
                for comm in self.index["communities"]:
                    if eid in comm.get("entity_ids", []):
                        local_communities.add(comm["community_id"])
            result["local_community_ids"] = list(local_communities)

        return result

    def _global_search(self, query, top_k=3):
        """Global search: find relevant community reports via TF-IDF."""
        results = self.vectorizer.search(query, top_k=20)

        # Filter to community documents (IDs start with 'C')
        comm_results = []
        for doc_id, score in results:
            if doc_id.startswith("C"):
                comm = next((c for c in self.index["communities"] if c["community_id"] == doc_id), None)
                if comm:
                    comm_results.append((score, comm))

        comm_results.sort(key=lambda x: x[0], reverse=True)

        return [{
            "community_id": comm["community_id"],
            "title": comm["title"],
            "score": round(score, 4),
            "summary": comm["summary"],
            "entity_count": comm["entity_count"],
            "key_relationships": comm.get("key_relationships", []),
            "query_examples": comm.get("query_examples", []),
        } for score, comm in comm_results[:top_k]]

    def _local_search(self, query, top_k=10):
        """Local search: find relevant entities via TF-IDF, expand to neighborhoods."""
        results = self.vectorizer.search(query, top_k=30)

        # Filter to entity documents (IDs start with 'E')
        entity_results = []
        for doc_id, score in results:
            if doc_id.startswith("E") and doc_id in self.entity_map:
                entity = self.entity_map[doc_id]
                entity_results.append((score, entity))

        # Expand to neighborhoods
        output = []
        seen = set()
        for score, entity in entity_results[:top_k]:
            eid = entity["entity_id"]
            if eid in seen:
                continue
            seen.add(eid)

            # Get neighbors
            neighbors = []
            for rel in self.outgoing.get(eid, []):
                target = self.entity_map.get(rel["target"])
                if target and target["entity_id"] not in seen:
                    neighbors.append({
                        "entity_id": target["entity_id"],
                        "name": target["name"],
                        "type": target["type"],
                        "relationship": rel["type"],
                        "description": rel["description"],
                    })
            for rel in self.incoming.get(eid, []):
                source = self.entity_map.get(rel["source"])
                if source and source["entity_id"] not in seen:
                    neighbors.append({
                        "entity_id": source["entity_id"],
                        "name": source["name"],
                        "type": source["type"],
                        "relationship": rel["type"],
                        "description": rel["description"],
                    })

            # Get matched text
            matched_texts = [tu["text"][:150] for tu in self.text_units_by_entity.get(eid, [])[:2]]

            output.append({
                "entity_id": eid,
                "name": entity["name"],
                "type": entity["type"],
                "score": round(score, 4),
                "description": entity.get("description", ""),
                "properties": entity.get("properties", {}),
                "matched_texts": matched_texts,
                "neighbors": neighbors[:15],
            })
        return output

    def get_table_context(self, table_name):
        """Get full context for a specific table."""
        table_name = table_name.lower()
        eid = None
        for e in self.index["entities"]:
            if e["type"] == "TABLE" and e["name"].lower() == table_name:
                eid = e["entity_id"]
                entity = e
                break
        if not eid:
            return None

        columns = []
        joins = []
        for rel in self.outgoing.get(eid, []):
            target = self.entity_map.get(rel["target"])
            if target and target["type"] == "COLUMN":
                columns.append({
                    "name": target["name"],
                    "description": target.get("description", ""),
                    "properties": target.get("properties", {}),
                })
            elif target and target["type"] == "TABLE":
                joins.append({
                    "target_table": target["name"],
                    "relationship": rel["type"],
                    "description": rel["description"],
                    "properties": rel.get("properties", {}),
                })

        community = None
        for comm in self.index["communities"]:
            if eid in comm.get("entity_ids", []):
                community = {"id": comm["community_id"], "title": comm["title"]}
                break

        return {
            "table": entity["name"],
            "description": entity.get("description", ""),
            "properties": entity.get("properties", {}),
            "columns": columns,
            "joins": joins,
            "community": community,
        }

    def get_join_path(self, from_table, to_table):
        """Find join path between two tables."""
        from_table = from_table.lower()
        to_table = to_table.lower()

        from_eid = None
        to_eid = None
        for e in self.index["entities"]:
            if e["type"] == "TABLE":
                if e["name"].lower() == from_table:
                    from_eid = e["entity_id"]
                if e["name"].lower() == to_table:
                    to_eid = e["entity_id"]

        if not from_eid or not to_eid:
            return None

        # Direct join
        for rel in self.outgoing.get(from_eid, []):
            if rel["target"] == to_eid and rel["type"] == "JOINS_TO":
                return {
                    "from": from_table, "to": to_table, "direct": True,
                    "join_keys": rel.get("properties", {}).get("join_keys", []),
                    "cardinality": rel.get("properties", {}).get("cardinality", ""),
                    "description": rel["description"],
                }
        for rel in self.outgoing.get(to_eid, []):
            if rel["target"] == from_eid and rel["type"] == "JOINS_TO":
                return {
                    "from": from_table, "to": to_table, "direct": True,
                    "join_keys": rel.get("properties", {}).get("join_keys", []),
                    "cardinality": rel.get("properties", {}).get("cardinality", ""),
                    "description": rel["description"],
                }

        for qp in self.query_paths:
            if qp.get("start", "").lower() == from_table:
                for j in qp.get("joins", []):
                    if j.get("to", "").lower() == to_table:
                        return {"from": from_table, "to": to_table, "direct": False,
                                "join_keys": j.get("on", []), "via_query_path": qp.get("need", "")}

        return {"from": from_table, "to": to_table, "direct": False, "join_keys": [],
                "note": "No direct join found. Use uid and shard_hint as common keys."}

    def debug_query(self, query):
        """Show what the TF-IDF vectorizer is doing with a query — for debugging."""
        tokens = tokenize(query)
        expanded = expand_synonyms(tokens)
        results, query_vec = self.vectorizer.search_batch(query, top_k=10)

        # Find which terms in the query matched the vocabulary
        matched_terms = []
        for t in expanded:
            if t in self.vectorizer.vocabulary:
                idx = self.vectorizer.vocabulary[t]
                matched_terms.append((t, float(self.vectorizer.idf[idx])))

        matched_terms.sort(key=lambda x: x[1], reverse=True)

        return {
            "query": query,
            "raw_tokens": tokens,
            "expanded_tokens": sorted(expanded),
            "vocabulary_size": len(self.vectorizer.vocabulary),
            "matched_terms": [(t, round(idf, 3)) for t, idf in matched_terms[:20]],
            "non_zero_vector_dims": int((query_vec > 0).sum()),
            "top_results": [(doc_id, round(score, 4)) for doc_id, score in results[:10]],
        }


# ─── CLI ─────────────────────────────────────────────────────────────────────

def format_results(result):
    lines = []
    lines.append("=" * 70)
    lines.append(f"QUERY: '{result['query']}'  (mode: {result['mode']})")
    lines.append("=" * 70)

    if "global_results" in result and result["global_results"]:
        lines.append("\n📊 GLOBAL SEARCH (Community Reports — TF-IDF cosine similarity)")
        lines.append("-" * 70)
        for gr in result["global_results"]:
            lines.append(f"\n  [{gr['community_id']}] {gr['title']} (cosine: {gr['score']})")
            lines.append(f"  Entities: {gr['entity_count']}")
            summary = gr["summary"]
            for line in textwrap.wrap(summary, width=80, initial_indent="  ", subsequent_indent="  "):
                lines.append(line)
            if gr.get("query_examples"):
                lines.append(f"  Query examples:")
                for qe in gr["query_examples"][:2]:
                    lines.append(f"    • {qe[:100]}")

    if "local_results" in result and result["local_results"]:
        lines.append("\n\n🔍 LOCAL SEARCH (Entity Neighborhoods — TF-IDF cosine similarity)")
        lines.append("-" * 70)
        for lr in result["local_results"][:8]:
            lines.append(f"\n  [{lr['type']:12s}] {lr['name']:45s} cosine={lr['score']}")
            if lr.get("description"):
                desc = lr["description"][:120]
                lines.append(f"    {desc}...")
            if lr.get("neighbors"):
                lines.append(f"    Neighbors ({len(lr['neighbors'])}):")
                for n in lr["neighbors"][:5]:
                    lines.append(f"      → [{n['type']}] {n['name']} ({n['relationship']})")

    return "\n".join(lines)


if __name__ == "__main__":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

    import argparse
    parser = argparse.ArgumentParser(description="Vector GraphRAG Retriever (TF-IDF)")
    parser.add_argument("query", help="Search query")
    parser.add_argument("--mode", choices=["global", "local", "hybrid"], default="hybrid")
    parser.add_argument("--debug", action="store_true", help="Show TF-IDF debug info")
    args = parser.parse_args()

    retriever = VectorGraphRAG()

    if args.debug:
        debug = retriever.debug_query(args.query)
        print(f"\n{'='*70}")
        print(f"TF-IDF DEBUG: '{args.query}'")
        print(f"{'='*70}")
        print(f"  Raw tokens:         {debug['raw_tokens']}")
        print(f"  Expanded tokens:    {debug['expanded_tokens'][:20]}...")
        print(f"  Vocabulary size:    {debug['vocabulary_size']}")
        print(f"  Non-zero dims:      {debug['non_zero_vector_dims']}")
        print(f"  Matched terms (IDF weighted):")
        for term, idf in debug["matched_terms"]:
            print(f"    {term:30s}  IDF={idf}")
        print(f"  Top results:")
        for doc_id, score in debug["top_results"]:
            entity = retriever.entity_map.get(doc_id)
            name = entity["name"] if entity else doc_id
            print(f"    {doc_id:8s} {name:45s} cosine={score}")

    result = retriever.search(args.query, mode=args.mode)
    print(format_results(result))
