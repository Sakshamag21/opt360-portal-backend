#!/usr/bin/env python3
"""
Query Logger — logs text-to-SQL questions, generated SQL, and token usage
to the PostgreSQL query_log table.

Usage:
    from query_logger import QueryLogger

    logger = QueryLogger()

    # Log a question (before execution)
    log_id = logger.log_question(
        user_id="saksham.nisg",
        question="count of mobile/name/address updates last 1 month",
        generated_sql="SELECT count_if(...) FROM ...",
        tokens_input=5000,
        tokens_output=300,
        retriever_used="none",
        llm_rerank_used=False,
        context_chars=18600,
    )

    # Update with execution results
    logger.log_execution(
        log_id=log_id,
        execution_status="success",
        row_count=6,
        latency_seconds=1.5,
        trino_query_id="20261015_123456_001",
    )

    # Or log everything at once
    log_id = logger.log_full(
        user_id="saksham.nisg",
        question="how many UIDs by status in shard 45",
        generated_sql="SELECT uid_status_key, count(*) FROM ...",
        tokens_input=5000,
        tokens_output=300,
        execution_status="success",
        row_count=10,
        latency_seconds=0.8,
        trino_query_id="20261015_123456_002",
    )

    # Search past questions
    results = logger.search("mobile update")
    for r in results:
        print(f"  [{r['id']}] {r['question']} -> {r['row_count']} rows")

    # Get usage stats
    stats = logger.stats()
    print(f"  Total queries: {stats['total_queries']}")
    print(f"  Total tokens: {stats['total_tokens']}")
"""

import os
import json
import subprocess
from datetime import datetime
from typing import Optional, Dict, List, Any

# ─── Configuration ──────────────────────────────────────────────────────────

CONTAINER = "graphrag-postgres"
DB_USER = "graphrag"
DB_NAME = "graphrag"
TEMP_DIR = os.path.join(os.environ.get("TEMP", "/tmp"), "opencode")
os.makedirs(TEMP_DIR, exist_ok=True)


class QueryLogger:
    """Logs text-to-SQL queries to PostgreSQL query_log table."""

    def __init__(self, user_id: str = "unknown"):
        """
        Args:
            user_id: Default user ID for this logger instance.
                     Can be overridden per-call.
        """
        self.default_user_id = user_id
        self._verify_table()

    def _verify_table(self):
        """Check that the query_log table exists."""
        try:
            result = self._query(
                "SELECT count(*) AS cnt FROM query_log"
            )
            if not result:
                raise RuntimeError(
                    "query_log table not found. "
                    "Run: docker exec graphrag-postgres psql -U graphrag -d graphrag "
                    "-f /docker-entrypoint-initdb.d/02_query_log.sql"
                )
        except Exception as e:
            raise RuntimeError(
                f"Cannot connect to PostgreSQL or query_log table missing: {e}"
            )

    # ═══════════════════════════════════════════════════════════════════════
    #  SQL EXECUTION
    # ═══════════════════════════════════════════════════════════════════════

    def _query(self, sql: str) -> List[Dict]:
        """
        Execute SQL via psql in the Docker container. Returns rows as dicts.
        
        For SELECT queries, wraps in JSON aggregation for clean parsing.
        For INSERT...RETURNING queries, uses a CTE wrapper.
        """
        sql_stripped = sql.strip()
        
        # Detect INSERT with RETURNING — needs CTE wrapper
        if sql_stripped.upper().startswith("INSERT"):
            # Wrap INSERT...RETURNING in a CTE so we can SELECT from it
            json_sql = f"WITH ins AS ({sql_stripped.rstrip(';')}) SELECT coalesce(json_agg(row_to_json(t)), '[]'::json) FROM (SELECT * FROM ins) t;"
        else:
            json_sql = f"SELECT coalesce(json_agg(row_to_json(t)), '[]'::json) FROM ({sql_stripped}) t;"

        temp_path = os.path.join(TEMP_DIR, "ql_query.sql")
        with open(temp_path, "w", encoding="utf-8") as f:
            f.write(json_sql)

        container_path = "/tmp/ql_query.sql"
        cp = subprocess.run(
            ["docker", "cp", temp_path, f"{CONTAINER}:{container_path}"],
            capture_output=True, text=True,
        )
        if cp.returncode != 0:
            raise RuntimeError(f"docker cp failed: {cp.stderr}")

        result = subprocess.run(
            ["docker", "exec", CONTAINER, "psql",
             "-U", DB_USER, "-d", DB_NAME,
             "-t", "-A", "-f", container_path],
            capture_output=True, text=True, encoding="utf-8",
        )

        if result.returncode != 0:
            raise RuntimeError(f"psql error: {result.stderr.strip()}")

        output = result.stdout.strip()
        if not output or output == "null":
            return []

        try:
            return json.loads(output)
        except json.JSONDecodeError as e:
            cleaned = output.replace("\\u0000", "")
            try:
                return json.loads(cleaned)
            except json.JSONDecodeError:
                raise RuntimeError(f"JSON parse error: {e}\nOutput: {output[:500]}")

    def _execute(self, sql: str) -> bool:
        """Execute a non-SELECT SQL (INSERT/UPDATE). Returns True on success."""
        temp_path = os.path.join(TEMP_DIR, "ql_exec.sql")
        with open(temp_path, "w", encoding="utf-8") as f:
            f.write(sql)

        container_path = "/tmp/ql_exec.sql"
        subprocess.run(
            ["docker", "cp", temp_path, f"{CONTAINER}:{container_path}"],
            capture_output=True, text=True,
        )

        result = subprocess.run(
            ["docker", "exec", CONTAINER, "psql",
             "-U", DB_USER, "-d", DB_NAME,
             "-f", container_path],
            capture_output=True, text=True, encoding="utf-8",
        )

        if result.returncode != 0:
            raise RuntimeError(f"psql error: {result.stderr.strip()}")
        return True

    def _escape(self, s: Any) -> str:
        """Escape a value for SQL single-quoted literal."""
        if s is None:
            return "NULL"
        return "'" + str(s).replace("'", "''") + "'"

    # ═══════════════════════════════════════════════════════════════════════
    #  LOGGING METHODS
    # ═══════════════════════════════════════════════════════════════════════

    def log_question(
        self,
        question: str,
        generated_sql: str = None,
        user_id: str = None,
        tokens_input: int = 0,
        tokens_output: int = 0,
        retriever_used: str = None,
        llm_rerank_used: bool = False,
        context_chars: int = None,
    ) -> int:
        """
        Log a question + generated SQL. Returns the log row ID.

        Use this when you want to log the question immediately (before execution),
        then call log_execution() later with the results.
        """
        uid = user_id or self.default_user_id

        sql = f"""
        INSERT INTO query_log (
            user_id, question, generated_sql,
            tokens_input, tokens_output,
            execution_status,
            retriever_used, llm_rerank_used, context_chars
        ) VALUES (
            {self._escape(uid)},
            {self._escape(question)},
            {self._escape(generated_sql)},
            {int(tokens_input or 0)},
            {int(tokens_output or 0)},
            'pending',
            {self._escape(retriever_used)},
            {'TRUE' if llm_rerank_used else 'FALSE'},
            {int(context_chars) if context_chars else 'NULL'}
        )
        RETURNING id;
        """
        rows = self._query(sql)
        if rows:
            return rows[0]["id"]
        raise RuntimeError("Failed to insert query log entry")

    def log_execution(
        self,
        log_id: int,
        execution_status: str = "success",
        row_count: int = None,
        latency_seconds: float = None,
        trino_query_id: str = None,
        error_message: str = None,
    ):
        """Update a log entry with execution results."""
        sql = f"""
        UPDATE query_log SET
            executed = TRUE,
            execution_status = {self._escape(execution_status)},
            row_count = {int(row_count) if row_count is not None else 'NULL'},
            latency_seconds = {float(latency_seconds) if latency_seconds is not None else 'NULL'},
            trino_query_id = {self._escape(trino_query_id)},
            error_message = {self._escape(error_message)}
        WHERE id = {int(log_id)};
        """
        self._execute(sql)

    def log_full(
        self,
        question: str,
        generated_sql: str = None,
        user_id: str = None,
        tokens_input: int = 0,
        tokens_output: int = 0,
        execution_status: str = "success",
        row_count: int = None,
        latency_seconds: float = None,
        trino_query_id: str = None,
        error_message: str = None,
        retriever_used: str = None,
        llm_rerank_used: bool = False,
        context_chars: int = None,
    ) -> int:
        """
        Log everything in one call (question + SQL + execution + tokens).
        Returns the log row ID.
        """
        uid = user_id or self.default_user_id
        executed = execution_status in ("success", "failed")
        executed_val = "TRUE" if executed else "FALSE"
        exec_at = "NOW()" if executed else "NULL"

        sql = f"""
        INSERT INTO query_log (
            user_id, question, generated_sql,
            tokens_input, tokens_output,
            executed, execution_status,
            row_count, latency_seconds,
            trino_query_id, error_message,
            retriever_used, llm_rerank_used, context_chars,
            executed_at
        ) VALUES (
            {self._escape(uid)},
            {self._escape(question)},
            {self._escape(generated_sql)},
            {int(tokens_input or 0)},
            {int(tokens_output or 0)},
            {executed_val},
            {self._escape(execution_status)},
            {int(row_count) if row_count is not None else 'NULL'},
            {float(latency_seconds) if latency_seconds is not None else 'NULL'},
            {self._escape(trino_query_id)},
            {self._escape(error_message)},
            {self._escape(retriever_used)},
            {'TRUE' if llm_rerank_used else 'FALSE'},
            {int(context_chars) if context_chars else 'NULL'},
            {exec_at}
        )
        RETURNING id;
        """
        rows = self._query(sql)
        if rows:
            return rows[0]["id"]
        raise RuntimeError("Failed to insert query log entry")

    # ═══════════════════════════════════════════════════════════════════════
    #  QUERY / ANALYTICS METHODS
    # ═══════════════════════════════════════════════════════════════════════

    def search(self, keyword: str, limit: int = 20) -> List[Dict]:
        """Search past questions by keyword (full-text search)."""
        kw = self._escape(keyword)
        sql = f"""
        SELECT id, user_id, question, generated_sql, execution_status,
               row_count, tokens_total, latency_seconds, created_at
        FROM query_log
        WHERE to_tsvector('english', question) @@ websearch_to_tsquery('english', {kw})
           OR question ILIKE {'%' + keyword + '%'}
        ORDER BY created_at DESC
        LIMIT {int(limit)}
        """
        return self._query(sql)

    def recent(self, limit: int = 20, user_id: str = None) -> List[Dict]:
        """Get recent queries, optionally filtered by user."""
        if user_id:
            sql = f"""
            SELECT id, user_id, question, generated_sql, execution_status,
                   row_count, tokens_total, latency_seconds, created_at
            FROM query_log
            WHERE user_id = {self._escape(user_id)}
            ORDER BY created_at DESC
            LIMIT {int(limit)}
            """
        else:
            sql = f"""
            SELECT id, user_id, question, generated_sql, execution_status,
                   row_count, tokens_total, latency_seconds, created_at
            FROM query_log
            ORDER BY created_at DESC
            LIMIT {int(limit)}
            """
        return self._query(sql)

    def stats(self, user_id: str = None) -> Dict:
        """Get usage statistics."""
        where = f"WHERE user_id = {self._escape(user_id)}" if user_id else ""

        sql = f"""
        SELECT
            count(*) AS total_queries,
            count(*) FILTER (WHERE execution_status = 'success') AS successful,
            count(*) FILTER (WHERE execution_status = 'failed') AS failed,
            count(*) FILTER (WHERE execution_status = 'pending') AS pending,
            coalesce(sum(tokens_input), 0) AS total_input_tokens,
            coalesce(sum(tokens_output), 0) AS total_output_tokens,
            coalesce(sum(tokens_total), 0) AS total_tokens,
            coalesce(avg(tokens_total), 0) AS avg_tokens_per_query,
            coalesce(avg(latency_seconds), 0) AS avg_latency,
            coalesce(sum(row_count), 0) AS total_rows_returned,
            min(created_at) AS first_query,
            max(created_at) AS last_query
        FROM query_log
        {where}
        """
        rows = self._query(sql)
        return rows[0] if rows else {}

    def get(self, log_id: int) -> Optional[Dict]:
        """Get a specific log entry by ID."""
        sql = f"SELECT * FROM query_log WHERE id = {int(log_id)}"
        rows = self._query(sql)
        return rows[0] if rows else None

    def get_sql(self, log_id: int) -> Optional[str]:
        """Get just the generated SQL for a log entry (for re-execution)."""
        sql = f"SELECT generated_sql FROM query_log WHERE id = {int(log_id)}"
        rows = self._query(sql)
        if rows and rows[0].get("generated_sql"):
            return rows[0]["generated_sql"]
        return None


# ─── CLI for testing ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    import io
    import sys
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

    logger = QueryLogger(user_id="test_user")

    print("=" * 60)
    print("Query Logger Test")
    print("=" * 60)

    # Test 1: Log a question
    print("\n1. Logging a question...")
    log_id = logger.log_question(
        question="count of mobile, name, address updates last 1 month",
        generated_sql="SELECT count_if(from_utf8(updt_mobile_details)='10') AS mobile_succ FROM strot.mysql_uid_v2.uid_origin_tracker_enriched WHERE enr_date >= current_date - interval '1' month",
        tokens_input=5000,
        tokens_output=300,
        retriever_used="none",
        context_chars=18600,
    )
    print(f"   Log ID: {log_id}")

    # Test 2: Update with execution results
    print("\n2. Logging execution results...")
    logger.log_execution(
        log_id=log_id,
        execution_status="success",
        row_count=6,
        latency_seconds=1.5,
        trino_query_id="20261015_123456_001",
    )
    print(f"   Updated log ID {log_id}")

    # Test 3: Log everything at once
    print("\n3. Logging full entry...")
    log_id2 = logger.log_full(
        question="how many UIDs by status in shard 45",
        generated_sql="SELECT uid_status_key, count(*) FROM strot.mysql_uid_v2.uid_master WHERE shard_hint='45' GROUP BY uid_status_key",
        tokens_input=4500,
        tokens_output=250,
        execution_status="success",
        row_count=10,
        latency_seconds=0.8,
        trino_query_id="20261015_123456_002",
    )
    print(f"   Log ID: {log_id2}")

    # Test 4: Search
    print("\n4. Searching for 'mobile'...")
    results = logger.search("mobile")
    for r in results:
        print(f"   [{r['id']}] {r['question'][:60]}... -> {r['execution_status']}")

    # Test 5: Recent
    print("\n5. Recent queries...")
    results = logger.recent(limit=5)
    for r in results:
        print(f"   [{r['id']}] [{r['created_at']}] {r['question'][:60]}...")

    # Test 6: Stats
    print("\n6. Usage stats...")
    stats = logger.stats()
    print(f"   Total queries:      {stats.get('total_queries', 0)}")
    print(f"   Successful:         {stats.get('successful', 0)}")
    print(f"   Failed:             {stats.get('failed', 0)}")
    print(f"   Total input tokens: {stats.get('total_input_tokens', 0):,}")
    print(f"   Total output tokens:{stats.get('total_output_tokens', 0):,}")
    print(f"   Total tokens:       {stats.get('total_tokens', 0):,}")
    print(f"   Avg tokens/query:   {stats.get('avg_tokens_per_query', 0):.0f}")
    print(f"   Avg latency:        {stats.get('avg_latency', 0):.2f}s")
    print(f"   Total rows returned:{stats.get('total_rows_returned', 0):,}")

    # Verify tokens_total trigger worked
    print("\n7. Verifying tokens_total trigger...")
    entry = logger.get(log_id)
    print(f"   Log {log_id}: input={entry['tokens_input']}, output={entry['tokens_output']}, total={entry['tokens_total']}")
    assert entry['tokens_total'] == entry['tokens_input'] + entry['tokens_output'], "tokens_total trigger failed!"
    print(f"   Trigger works correctly: {entry['tokens_input']} + {entry['tokens_output']} = {entry['tokens_total']}")

    # Cleanup test data
    print("\n8. Cleaning up test data...")
    logger._execute(f"DELETE FROM query_log WHERE user_id = 'test_user'")
    print("   Test data deleted")

    print("\n" + "=" * 60)
    print("All tests passed!")
    print("=" * 60)
