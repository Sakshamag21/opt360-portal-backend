# Trino Table Context Layer — `strot.mysql_uid_v2.uid_address`

> Context layer for text-to-SQL. Catalog: `strot` · Schema: `mysql_uid_v2` · Table: `uid_address`
>
> **Address table for UID records.** One row per UID containing the resident's address. 1:1 relationship with `uid_master` (joined on `uid`). Address is primarily captured via the geographic hierarchy (VTC → subdistrict → district → state → country + pincode), not free-text address lines.

## Quick Facts

| Property | Value |
|----------|-------|
| Full table reference | `strot.mysql_uid_v2.uid_address` |
| Approximate row count | **1,455,878,397** (~1.46 billion) |
| Column count | 31 |
| Relationship to uid_master | **1:1** (one address row per UID) |
| Source connector | MySQL , exposed via Trino |
| Data date range | 2010-08-21 → 2026-10-09 (active, updated daily) |
| Read host | `10.10.116.39` |
| Write hosts | `10.10.116.75`, `10.10.118.10` |

> ⚠️ **Large table (~1.46B rows).** Always use `LIMIT`, `shard_hint` for partition pruning, or `uid` predicates. Avoid `SELECT *` without a limit.

---

## Column Dictionary

| # | Column | Type | Description | Notes | Importance Based on Usage |
|---|--------|------|-------------|-------|---------------------------|
| 1 | `addr_key` | bigint | Surrogate primary key | Range `1`–`20,492,616`. **Not contiguous** (1.46B rows vs 20M max key → heavily reused/sharded). Useful for sampling with `WHERE addr_key <= N`. | Low |
| 2 | `uid` | varchar | Encrypted UID (Aadhaar number) | Base64-like encrypted blob. **Never** store/return in plaintext. PII. **Primary join key** to `uid_master` / `uid_his_master`. | High |
| 3 | `res_addr_vtc_code` | varchar | Village/Town/City code | E.g. `00655114`. Always populated. | Low |
| 4 | `res_addr_vtc_name` | varchar | Village/Town/City name (English) | E.g. `Jamtara`. Always populated. | High |
| 5 | `res_addr_vtc_name_local` | varchar | Village/Town/City name (local language) | E.g. `जामताड़ा`. ~0.005% NULL. | Low |
| 6 | `res_addr_district_code` | varchar | District code | E.g. `00343`. Always populated. | Low |
| 7 | `res_addr_district_name` | varchar | District name (English) | E.g. `Jamtara`. Always populated. | High |
| 8 | `res_addr_district_name_local` | varchar | District name (local language) | ~0.005% NULL. | Low |
| 9 | `res_addr_subdistrict_code` | varchar | Sub-district / Tehsil code | E.g. `005747`. ~6.1% NULL (some addresses don't have subdistrict). | Low |
| 10 | `res_addr_subdistrict_name` | varchar | Sub-district / Tehsil name (English) | ~6.1% NULL (same as code). | Medium |
| 11 | `res_addr_subdistrict_name_local` | varchar | Sub-district / Tehsil name (local language) | ~6.2% NULL. Also contains literal `'NULL'` strings in some rows. | Low |
| 12 | `res_addr_state_code` | varchar | State/UT code | E.g. `20` = Jharkhand. Codes `01`–`37`. See [state codes](#res_addr_state_code). | Medium |
| 13 | `res_addr_state_name` | varchar | State/UT name (English) | E.g. `Jharkhand`. Some data quality issues (Orissa vs Odisha, Pondicherry vs Puducherry). | High |
| 14 | `res_addr_state_name_local` | varchar | State/UT name (local language) | ~0.005% NULL. | Low |
| 15 | `res_addr_po_name` | varchar | Post Office name (English) | E.g. `Jamtara`. ~0.17% NULL. | Medium |
| 16 | `res_addr_po_name_local` | varchar | Post Office name (local language) | ~0.17% NULL. | Low |
| 17 | `res_addr_pincode` | varchar | PIN code (postal code) | E.g. `815351`. **Always populated** (0% NULL). 6-digit Indian postal code. | High |
| 18 | `res_f_addr_line1` | varchar | Free-text address line 1 | **>99.99% NULL** — address is captured via geographic hierarchy, not free-text lines. | Low |
| 19 | `res_f_addr_line1_local` | varchar | Free-text address line 1 (local language) | **>99.99% NULL**. | Low |
| 20 | `res_f_addr_line2` | varchar | Free-text address line 2 | **>99.99% NULL**. | Low |
| 21 | `res_f_addr_line2_local` | varchar | Free-text address line 2 (local language) | **>99.99% NULL**. | Low |
| 22 | `res_f_addr_line3` | varchar | Free-text address line 3 | **>99.99% NULL**. | Low |
| 23 | `res_f_addr_line3_local` | varchar | Free-text address line 3 (local language) | **>99.99% NULL**. | Low |
| 24 | `res_addr_country_code` | varchar | Country code | `356` = India (ISO-3166 numeric). Data quality issues: some rows have `'India'` (string) or `'001'` instead of `'356'`. See [country codes](#res_addr_country_code). | Low |
| 25 | `res_addr_country_name` | varchar | Country name (English) | `India` for vast majority. Some rows have `'356'` in the name field. | Medium |
| 26 | `res_addr_country_name_local` | varchar | Country name (local language) | ~5.1% NULL. Often populated with `356` instead of a local-language name. | Low |
| 27 | `created_by` | varchar | Source/creator of the record | E.g. `enrolserver`, or ETL CSV filenames like `uid_address-ETL-92-20160827.csv`. | Low |
| 28 | `creation_date` | timestamp(6) | Record creation timestamp | Range 2010-08-21 → 2026-10-09. | Medium |
| 29 | `last_updated_by` | varchar | Last updater | Typically `enrolserver`. | Medium |
| 30 | `last_updated_date` | timestamp(6) | Last update timestamp | Range 2010-08-21 → 2026-10-09. | High |
| 31 | `shard_hint` | varchar | Sharding hint, basically first 2 digits of every Aadhaar number/UID, used for efficient querying as the MySQL sharding is done based on this | E.g. `37`. Use for partition pruning / faster queries. | High |

---

## Geographic Hierarchy

```
Country
  └── State / UT
       └── District
            └── Sub-district / Tehsil  (6.1% NULL — not all addresses have this)
                 └── Village / Town / City (VTC)
                      └── Post Office (PO)
                           └── Pincode  (always populated)
```

Each level has: `code`, `name` (English), `name_local` (local language).

---

## Categorical Value Mappings

### res_addr_state_code

| Code | State/UT Name | Count | Notes |
|------|---------------|-------|-------|
| `09` | Uttar Pradesh | 243,685,240 | |
| `27` | Maharashtra | 131,257,548 | |
| `10` | Bihar | 125,049,021 | |
| `19` | West Bengal | 108,328,806 | |
| `23` | Madhya Pradesh | 89,002,945 | |
| `08` | Rajasthan | 84,777,925 | |
| `33` | Tamil Nadu | 82,143,362 | |
| `29` | Karnataka | 72,751,252 | |
| `24` | Gujarat | 71,766,973 | |
| `28` | Andhra Pradesh | 69,119,753 | |
| `21` | Odisha | 46,009,136 | Also appears as `Orissa` (2,698,080 rows) — data quality issue |
| `32` | Kerala | 41,483,001 | |
| `20` | Jharkhand | 39,738,177 | |
| `18` | Assam | 35,373,840 | |
| `03` | Punjab | 34,472,512 | |
| `06` | Haryana | 33,701,870 | |
| `36` | Telangana | 32,689,467 | |
| `22` | Chhattisgarh | 31,788,020 | |
| `07` | Delhi | 24,613,008 | |
| `01` | Jammu and Kashmir | 12,948,682 | |
| `05` | Uttarakhand | 12,824,352 | |
| `02` | Himachal Pradesh | 8,571,212 | |
| `16` | Tripura | 4,290,921 | |
| `17` | Meghalaya | 3,069,739 | |
| `14` | Manipur | 2,921,324 | |
| `30` | Goa | 1,784,521 | |
| `13` | Nagaland | 1,541,940 | |
| `15` | Mizoram | 1,325,332 | |
| `12` | Arunachal Pradesh | 1,324,702 | |
| `04` | Chandigarh | 1,259,389 | |
| `34` | Puducherry | 715,904 | Also appears as `Pondicherry` (711,584 rows) — data quality issue |
| `11` | Sikkim | 647,898 | |
| `26` | Dadra and Nagar Haveli | 368,544 | |
| `35` | Andaman and Nicobar Islands | 297,446 | Also appears as `Andaman & Nicobar Islands` (118,291 rows) |
| `37` | Ladakh | 271,422 | |
| `25` | Daman and Diu | 140,060 | |
| `31` | Lakshadweep | 82,325 | |

> **Data quality notes:**
> - `21` = Odisha/Orissa (name varies) — use `res_addr_state_code` for reliable filtering, not `res_addr_state_name`
> - `34` = Puducherry/Pondicherry (name varies)
> - `35` = Andaman and Nicobar Islands (name varies: "and" vs "&")

### res_addr_country_code

| Code | Name | Count | Notes |
|------|------|-------|-------|
| `356` | India | 1,389,124,343 | ISO-3166 numeric for India (correct) |
| `India` | India | 65,250,524 | Data quality issue — country name in code field |
| `001` | India | 1,499,703 | Data quality issue — incorrect code |
| `356` | `356` | 3,774 | Data quality issue — code in name field |
| `NULL` | `NULL` | 52 | |
| `365` | INDIA | 1 | Data quality issue |

> **Filtering advice:** Use `res_addr_country_code = '356'` for India. Be aware that ~4.6% of rows have incorrect country code values (`'India'` or `'001'`). If you need all India rows, use: `WHERE res_addr_country_code IN ('356', 'India', '001')` or filter by `res_addr_country_name = 'India'`.

---

## Date Ranges

| Column | Min | Max |
|--------|-----|-----|
| `creation_date` | 2010-08-21 18:55:49 | 2026-10-09 03:18:18 |
| `last_updated_date` | 2010-08-21 18:55:49 | 2026-10-09 03:18:18 |

---

## NULL Summary

| Column | NULL Count | NULL % | Notes |
|--------|-----------|--------|-------|
| `res_addr_pincode` | 0 | 0% | **Always populated** |
| `res_addr_vtc_code` / `vtc_name` | ~0 | ~0% | Essentially always populated |
| `res_addr_district_code` / `district_name` | ~0 | ~0% | Essentially always populated |
| `res_addr_state_code` / `state_name` | ~0 | ~0% | Essentially always populated |
| `res_addr_vtc_name_local` | 70,503 | 0.005% | |
| `res_addr_district_name_local` | 71,242 | 0.005% | |
| `res_addr_state_name_local` | 71,490 | 0.005% | |
| `res_addr_po_name` / `po_name_local` | ~2.4M | ~0.17% | |
| `res_addr_subdistrict_code` / `name` | ~88.8M | ~6.1% | Not all addresses have subdistrict |
| `res_addr_subdistrict_name_local` | ~90.5M | ~6.2% | Also contains literal `'NULL'` strings |
| `res_addr_country_name_local` | ~73.8M | ~5.1% | |
| `res_f_addr_line1` | ~1.456B | **>99.99%** | Essentially unused |
| `res_f_addr_line2` | ~1.456B | **>99.99%** | Essentially unused |
| `res_f_addr_line3` | ~1.456B | **>99.99%** | Essentially unused |

---

## Sample Row (anonymized shape)

```
addr_key              : 20487010
uid                   : <encrypted base64 blob>
res_addr_vtc_code     : '00655114'
res_addr_vtc_name     : 'Jamtara'
res_addr_vtc_name_local : 'जामताड़ा'
res_addr_district_code: '00343'
res_addr_district_name: 'Jamtara'
res_addr_district_name_local : 'जामताड़ा'
res_addr_subdistrict_code    : '005747'
res_addr_subdistrict_name    : 'Jamtara'
res_addr_subdistrict_name_local : 'जामताड़ा'
res_addr_state_code   : '20'
res_addr_state_name   : 'Jharkhand'
res_addr_state_name_local : 'झारखण्ड'
res_addr_po_name      : 'Jamtara'
res_addr_po_name_local: 'जमतरा'
res_addr_pincode      : '815351'
res_f_addr_line1      : NULL
res_f_addr_line2      : NULL
res_f_addr_line3      : NULL
res_addr_country_code : '356'
res_addr_country_name : 'India'
created_by            : 'enrolserver'
creation_date         : 2026-10-08 19:50:50
last_updated_by       : 'enrolserver'
last_updated_date     : 2026-10-08 19:50:50
shard_hint            : '37'
```

---

## Querying Guidance/ Rules (text-to-SQL)

1. **Always scope queries.** With ~1.46B rows, prefer:
   - `LIMIT N`
   - Use `shard_hint` for faster partition pruning
   - `uid` filters when looking up address for a specific resident
   - State/district/pincode filters for geographic analysis
2. **Avoid full-table aggregations** without a predicate; they scan the entire table.
3. **Geographic hierarchy:** Address is structured as Country → State → District → Subdistrict → VTC → PO → Pincode. Always give priority to the `name` columns before the `code` columns.
4. **Data quality — state names:** Prefer the usage of `res_addr_state_name` over the `res_addr_state_code`.
5. **Data quality — country codes:** `res_addr_country_code` has inconsistent values (`'356'`, `'India'`, `'001'`). Use `res_addr_country_name = 'India'` or `res_addr_country_code IN ('356', 'India', '001')` for complete India filtering.
6. **Free-text address lines are unused:** `res_f_addr_line1/2/3` (and `_local` variants) are >99.99% NULL. Do not rely on them — use the geographic hierarchy columns instead.
7. **Local language columns:** `_local` variants contain local-language names (Devanagari, Telugu, Kannada, etc.). Some contain literal `'NULL'` strings — filter with `WHERE col IS NOT NULL AND col != 'NULL'` if needed.
8. **PII handling:** `uid` is encrypted. Never attempt decryption in SQL.
9. **Pincode is always populated** and is the most reliable granular location filter.
10. **Read vs write:** run `SELECT` on read host `10.10.116.39`; No write is allowed on this table.
11. **Priority:** the importance is defined in the column dictionary, mostly problems are solved with High and Medium priority columns.
