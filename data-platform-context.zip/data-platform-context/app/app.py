#!/usr/bin/env python3
"""
Streamlit Chatbot UI for the Text-to-SQL Pipeline.

Wraps the GraphRAG + GLM-5.2-FP8 pipeline (text_to_sql.py) in a
chat-style interface with live progress, SQL highlighting, result
tables, and audit logging.

Usage:
    python -m streamlit run app.py
"""

import sys
import os
import time
import json
import threading
import requests
import pandas as pd
from pathlib import Path
from urllib.parse import quote

import streamlit as st

# ─── Path setup ──────────────────────────────────────────────────────────────
CONTEXT_DIR = r"C:\data-platform-context"
sys.path.insert(0, CONTEXT_DIR)

# Make sure the app's own directory is on the path so conversation_store is importable
_APP_DIR = str(Path(__file__).resolve().parent)
if _APP_DIR not in sys.path:
    sys.path.insert(0, _APP_DIR)

import conversation_store as cs

# ─── Trino config ────────────────────────────────────────────────────────────
TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"


# ═══════════════════════════════════════════════════════════════════════════════
#  TRINO REST API
# ═══════════════════════════════════════════════════════════════════════════════
def trino_query(sql, timeout=600):
    """Execute a SQL query on Trino via the REST API, polling nextUri."""
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "text-to-sql-chatbot",
    }
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        return result

    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])

    query_id = result.get("id", "")

    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.3)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        state = result.get("stats", {}).get("state", "")
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
        attempts += 1

    result["data"] = all_data
    result["columns"] = columns
    result["query_id"] = query_id
    return result


def trino_explain(sql):
    """Run EXPLAIN on a SQL query. Returns (valid: bool, error: str)."""
    try:
        result = trino_query(f"EXPLAIN {sql}", timeout=30)
        if "error" in result:
            return False, result["error"].get("message", str(result["error"]))
        state = result.get("stats", {}).get("state", "")
        if state == "FAILED":
            err = result.get("error", {})
            return False, err.get("message", "EXPLAIN failed")
        return True, ""
    except Exception as e:
        return False, str(e)


# ═══════════════════════════════════════════════════════════════════════════════
#  CACHED PIPELINE COMPONENTS
# ═══════════════════════════════════════════════════════════════════════════════
@st.cache_resource(show_spinner=False)
def get_pipeline():
    """Initialize the TextToSQL pipeline. Cached across reruns."""
    from text_to_sql import TextToSQL
    return TextToSQL(use_llm_rerank=True, verbose=False)


def safe_init_logger():
    """Try to initialize the query logger; return None if unavailable."""
    try:
        from query_logger import QueryLogger
        return QueryLogger(user_id="streamlit_user")
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════════════════════
#  SQL GENERATION PROMPT
# ═══════════════════════════════════════════════════════════════════════════════
_SQL_SYSTEM_PROMPT = """You are a Trino SQL expert. Generate a valid Trino SQL query based on the user's question and the provided database context.

Rules:
- Only include shard_hint = '<value>' in the WHERE clause if the user explicitly mentions a specific shard in their question. Do NOT default to any shard.
- When using shard_hint, also add it to JOIN ON clauses for joined large tables.
- Never SELECT * without LIMIT on large tables (>1B rows)
- Use TRY_CAST instead of CAST for res_dob_year (has non-numeric values)
- Filter enr_date with WHERE enr_date > TIMESTAMP '2010-01-01' (has anomalies)
- For updt_* varbinary columns, use from_utf8(col) = '11' to filter (NOT CAST(col AS varchar)). b'00'=not updated, b'11'=updated.
- uid is encrypted — never try to decrypt or display it
- No writes allowed — only SELECT queries
- Do NOT add a semicolon at the end
- Return ONLY the SQL query, no explanation

IMPORTANT — Conversation Context:
- You are given the conversation history (previous questions and their SQL).
- If the current question is a follow-up (e.g., "now show only active ones", "filter that by...", "what about in shard 12"), resolve references using the history.
- The SQL you generate must be a COMPLETE, standalone query — do not reference CTEs or subqueries from previous SQL unless you include them in your new query.
- You may modify, refine, or build upon the previous SQL to answer the follow-up question."""


def _build_sql_prompt(question, context, history=None):
    """
    Build the user prompt for SQL generation.

    Args:
        question: The current natural-language question.
        context: Retrieved GraphRAG context (tables, columns, joins, rules).
        history: List of previous {question, sql} dicts from the same conversation.
                 Used so the LLM can resolve follow-up references.
    """
    # Build conversation history section
    history_block = ""
    if history:
        history_lines = []
        for i, h in enumerate(history, 1):
            history_lines.append(f"  Q{i}: {h['question']}")
            history_lines.append(f"  SQL {i}:\n{h['sql']}")
            history_lines.append("")
        history_block = f"""
=== CONVERSATION HISTORY (previous questions and SQL in this chat) ===
{chr(10).join(history_lines)}
"""
        history_block += "The current question may be a follow-up to the above. Resolve any references accordingly.\n\n"

    return f"""Database context:
{context}
{history_block}User question: {question}

Generate a Trino SQL query:"""


# ═══════════════════════════════════════════════════════════════════════════════
#  PIPELINE EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════
def _execute_pipeline(question, settings, history, tts):
    """
    Pure pipeline execution — no Streamlit calls. Safe for background threads.

    settings keys: use_rerank, auto_execute, run_explain,
                   show_context, show_reasoning
    history: Optional list of {question, sql} dicts from prior turns in
             the same conversation, so the LLM can resolve follow-up references.
    """
    total_start = time.time()

    # Override rerank setting
    tts.use_llm_rerank = settings["use_rerank"]

    result = {
        "question": question,
        "role": "assistant",
        "sql": None,
        "context": None,
        "reasoning": None,
        "retrieval_results": None,
        "explain_result": None,
        "query_result": None,
        "elapsed": 0,
        "steps": [],
        "error": None,
        "status": None,
        "feedback": None,
        "feedback_history": [],
    }

    # In verify mode, never auto-execute — the user must approve first
    verify_mode = settings.get("verify_before_run", True)
    effective_auto_execute = settings["auto_execute"] and not verify_mode

    # ── STEP 1: GraphRAG Retrieval ──
    step_start = time.time()
    try:
        rag_results = tts.retriever.search(
            question,
            mode="hybrid",
            top_k=15,
            use_llm_rerank=settings["use_rerank"],
            llm_top_k=10,
        )
        local_count = len(rag_results.get("local_results", []))
        global_count = len(rag_results.get("global_results", []))
        reranked = rag_results.get("llm_reranked", False)
        elapsed = round(time.time() - step_start, 2)
        result["retrieval_results"] = rag_results
        result["steps"].append({
            "name": "GraphRAG Retrieval",
            "status": "done",
            "detail": f"{local_count} entities, {global_count} communities"
                      + (f", LLM re-rank applied" if reranked and settings["use_rerank"] else ""),
            "elapsed": elapsed,
        })
    except Exception as e:
        result["steps"].append({
            "name": "GraphRAG Retrieval",
            "status": "error",
            "detail": str(e),
            "elapsed": round(time.time() - step_start, 2),
        })
        result["error"] = f"Retrieval failed: {e}"
        result["elapsed"] = round(time.time() - total_start, 2)
        return result

    # ── STEP 2: Context Assembly ──
    step_start = time.time()
    try:
        context = tts._assemble_context(question, rag_results)
        result["context"] = context
        result["steps"].append({
            "name": "Context Assembly",
            "status": "done",
            "detail": f"{len(context):,} chars assembled",
            "elapsed": round(time.time() - step_start, 2),
        })
    except Exception as e:
        result["steps"].append({
            "name": "Context Assembly",
            "status": "error",
            "detail": str(e),
            "elapsed": round(time.time() - step_start, 2),
        })
        result["error"] = f"Context assembly failed: {e}"
        result["elapsed"] = round(time.time() - total_start, 2)
        return result

    # ── STEP 3: LLM SQL Generation ──
    step_start = time.time()
    try:
        content, reasoning = tts.llm.chat(
            _build_sql_prompt(question, context, history=history),
            system=_SQL_SYSTEM_PROMPT,
            temperature=0.1,
            max_tokens=3000,
            return_reasoning=True,
        )

        if not content:
            result["error"] = f"LLM returned no content. Reasoning: {(reasoning or 'none')[:300]}"
            result["steps"].append({
                "name": "LLM SQL Generation",
                "status": "error",
                "detail": result["error"],
                "elapsed": round(time.time() - step_start, 2),
            })
            result["elapsed"] = round(time.time() - total_start, 2)
            return result

        # Clean up SQL — strip markdown fences and trailing semicolons
        sql = content.strip()
        if sql.startswith("```"):
            lines = sql.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            sql = "\n".join(lines).strip()

        if sql.endswith(";"):
            sql = sql[:-1].strip()

        # Safety: ensure LIMIT on billion-row tables
        if "LIMIT" not in sql.upper():
            sql = sql.rstrip() + "\nLIMIT 100"

        result["sql"] = sql
        result["reasoning"] = reasoning
        result["steps"].append({
            "name": "LLM SQL Generation",
            "status": "done",
            "detail": "GLM-5.2-FP8 generated SQL",
            "elapsed": round(time.time() - step_start, 2),
        })
    except Exception as e:
        result["steps"].append({
            "name": "LLM SQL Generation",
            "status": "error",
            "detail": str(e),
            "elapsed": round(time.time() - step_start, 2),
        })
        result["error"] = f"SQL generation failed: {e}"
        result["elapsed"] = round(time.time() - total_start, 2)
        return result

    # ── STEP 4: EXPLAIN Validation (optional) ──
    if settings["run_explain"]:
        step_start = time.time()
        try:
            valid, err = trino_explain(sql)
            result["explain_result"] = {"valid": valid, "error": err}
            if valid:
                result["steps"].append({
                    "name": "EXPLAIN Validation",
                    "status": "done",
                    "detail": "SQL syntax valid",
                    "elapsed": round(time.time() - step_start, 2),
                })
            else:
                result["steps"].append({
                    "name": "EXPLAIN Validation",
                    "status": "warning",
                    "detail": f"Issue: {err[:150]}",
                    "elapsed": round(time.time() - step_start, 2),
                })
        except Exception as e:
            result["explain_result"] = {"valid": None, "error": str(e)}
            result["steps"].append({
                "name": "EXPLAIN Validation",
                "status": "warning",
                "detail": str(e)[:150],
                "elapsed": round(time.time() - step_start, 2),
            })

    # ── STEP 5: Query Execution (optional) ──
    if effective_auto_execute:
        step_start = time.time()
        try:
            exec_result = trino_query(sql, timeout=600)
            if "error" in exec_result:
                err_msg = exec_result["error"].get("message", str(exec_result["error"]))
                result["query_result"] = {"success": False, "error": err_msg}
                result["steps"].append({
                    "name": "Query Execution",
                    "status": "error",
                    "detail": err_msg[:150],
                    "elapsed": round(time.time() - step_start, 2),
                })
            else:
                cols = exec_result.get("columns", [])
                data = exec_result.get("data", [])
                col_names = [c.get("name", f"col_{i}") for i, c in enumerate(cols)] if cols else []
                result["query_result"] = {
                    "success": True,
                    "columns": col_names,
                    "rows": data,
                    "row_count": len(data),
                    "query_id": exec_result.get("query_id", ""),
                }
                result["steps"].append({
                    "name": "Query Execution",
                    "status": "done",
                    "detail": f"{len(data)} rows returned (ID: {exec_result.get('query_id', 'N/A')[:20]})",
                    "elapsed": round(time.time() - step_start, 2),
                })
        except Exception as e:
            result["query_result"] = {"success": False, "error": str(e)}
            result["steps"].append({
                "name": "Query Execution",
                "status": "error",
                "detail": str(e)[:150],
                "elapsed": round(time.time() - step_start, 2),
            })

    result["elapsed"] = round(time.time() - total_start, 2)

    # Set verification status
    if result.get("error") and not result.get("sql"):
        result["status"] = "error"
    elif result.get("sql") and not result.get("query_result"):
        # SQL generated but not executed — awaiting user verification
        result["status"] = "pending_verification"
    elif result.get("query_result"):
        result["status"] = "completed"

    return result


def run_pipeline(question, settings, history=None):
    """
    Run the full text-to-SQL pipeline and return a result dict.
    (Synchronous wrapper — used for backwards compat.)
    """
    tts = get_pipeline()
    st.session_state["_pipeline"] = tts
    return _execute_pipeline(question, settings, history, tts)
    """
    Run the full text-to-SQL pipeline and return a result dict.
    (Synchronous wrapper — used for backwards compat.)
    """
    tts = get_pipeline()
    st.session_state["_pipeline"] = tts
    return _execute_pipeline(question, settings, history, tts)


# ═══════════════════════════════════════════════════════════════════════════════
#  BACKGROUND PIPELINE EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════
class PipelineTask:
    """Holds state for a background pipeline run, so it survives conversation switches."""

    def __init__(self, conv_id, question, settings, history, tts, logger):
        self.conv_id = conv_id
        self.question = question
        self.result = None
        self.error = None
        self.done = False
        self.logger = logger
        self.thread = threading.Thread(target=self._run, args=(question, settings, history, tts), daemon=True)

    def _run(self, question, settings, history, tts):
        try:
            self.result = _execute_pipeline(question, settings, history, tts)
        except Exception as e:
            self.error = str(e)
        finally:
            self.done = True

    def start(self):
        self.thread.start()


# ═══════════════════════════════════════════════════════════════════════════════
#  SQL CORRECTION PROMPT (for feedback-based regeneration)
# ═══════════════════════════════════════════════════════════════════════════════
def _build_correction_prompt(question, previous_sql, feedback, context, history=None):
    """
    Build a prompt for regenerating SQL based on user feedback.

    The LLM sees the original context, the rejected SQL, and the user's
    correction feedback, then generates a revised query.
    """
    history_block = ""
    if history:
        history_lines = []
        for i, h in enumerate(history, 1):
            history_lines.append(f"  Q{i}: {h['question']}")
            history_lines.append(f"  SQL {i}:\n{h['sql']}")
            history_lines.append("")
        history_block = f"""
=== CONVERSATION HISTORY (previous questions and SQL in this chat) ===
{chr(10).join(history_lines)}
"""

    return f"""Database context:
{context}
{history_block}User question: {question}

The following SQL was previously generated but the USER REJECTED it:

--- PREVIOUS SQL (REJECTED) ---
{previous_sql}
--- END PREVIOUS SQL ---

The user provided this feedback explaining what's wrong and what to fix:
"{feedback}"

Please generate a CORRECTED Trino SQL query that:
1. Addresses the issues identified in the user's feedback
2. Still answers the original question correctly
3. Follows all the SQL rules from the system prompt

Generate a corrected Trino SQL query:"""


# ═══════════════════════════════════════════════════════════════════════════════
#  VERIFICATION TASK (background execute or regenerate after user approval)
# ═══════════════════════════════════════════════════════════════════════════════
class VerificationTask:
    """
    Background task for the verify-then-run flow.

    Two modes:
      - "execute": Run the approved SQL against Trino
      - "regenerate": Regenerate SQL using user feedback via the LLM
    """

    def __init__(self, conv_id, msg_index, task_type, logger=None, **kwargs):
        self.conv_id = conv_id
        self.msg_index = msg_index
        self.task_type = task_type  # "execute" or "regenerate"
        self.result = None
        self.error = None
        self.done = False
        self.logger = logger
        self.kwargs = kwargs
        self.thread = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        try:
            if self.task_type == "execute":
                self._execute_sql()
            elif self.task_type == "regenerate":
                self._regenerate_sql()
        except Exception as e:
            self.error = str(e)
        finally:
            self.done = True

    def _execute_sql(self):
        """Execute the approved SQL against Trino."""
        sql = self.kwargs["sql"]
        step_start = time.time()

        exec_result = trino_query(sql, timeout=600)

        if "error" in exec_result:
            err_msg = exec_result["error"].get("message", str(exec_result["error"]))
            self.result = {
                "query_result": {"success": False, "error": err_msg},
                "status": "completed",
                "exec_elapsed": round(time.time() - step_start, 2),
            }
        else:
            cols = exec_result.get("columns", [])
            data = exec_result.get("data", [])
            col_names = [c.get("name", f"col_{i}") for i, c in enumerate(cols)] if cols else []
            self.result = {
                "query_result": {
                    "success": True,
                    "columns": col_names,
                    "rows": data,
                    "row_count": len(data),
                    "query_id": exec_result.get("query_id", ""),
                },
                "status": "completed",
                "exec_elapsed": round(time.time() - step_start, 2),
            }

    def _regenerate_sql(self):
        """Regenerate SQL using user feedback via the LLM."""
        question = self.kwargs["question"]
        previous_sql = self.kwargs["previous_sql"]
        feedback = self.kwargs["feedback"]
        context = self.kwargs["context"]
        history = self.kwargs.get("history", [])
        tts = self.kwargs["tts"]

        prompt = _build_correction_prompt(
            question, previous_sql, feedback, context, history
        )

        content, reasoning = tts.llm.chat(
            prompt,
            system=_SQL_SYSTEM_PROMPT,
            temperature=0.1,
            max_tokens=3000,
            return_reasoning=True,
        )

        if not content:
            self.result = {
                "error": f"LLM returned no content. Reasoning: {(reasoning or 'none')[:300]}",
                "sql": previous_sql,  # Keep the old SQL
                "status": "pending_verification",
                "reasoning": reasoning,
            }
            return

        # Clean up SQL — strip markdown fences and trailing semicolons
        sql = content.strip()
        if sql.startswith("```"):
            lines = sql.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            sql = "\n".join(lines).strip()

        if sql.endswith(";"):
            sql = sql[:-1].strip()

        # Safety: ensure LIMIT on billion-row tables
        if "LIMIT" not in sql.upper():
            sql = sql.rstrip() + "\nLIMIT 100"

        self.result = {
            "sql": sql,
            "reasoning": reasoning,
            "status": "pending_verification",
            "query_result": None,
            "explain_result": None,
            "error": None,
        }

    def start(self):
        self.thread.start()


@st.fragment(run_every=1)
def _poll_background_tasks():
    """Check if any background pipeline has completed. Save results to DB and rerun."""
    tasks = st.session_state.get("_active_tasks", {})
    if not tasks:
        return

    completed = []
    for conv_id, task in list(tasks.items()):
        if task.done:
            completed.append(conv_id)

    for conv_id in completed:
        task = tasks.pop(conv_id)
        result = task.result
        if result is None:
            result = {
                "role": "assistant",
                "question": task.question,
                "error": f"Pipeline failed: {task.error}",
                "sql": None,
                "context": None,
                "reasoning": None,
                "retrieval_results": None,
                "explain_result": None,
                "query_result": None,
                "elapsed": 0,
                "steps": [],
                "status": "error",
                "feedback": None,
                "feedback_history": [],
            }
        result["role"] = "assistant"

        # Strip retrieval_results before saving (large internal data)
        save_result = dict(result)
        if save_result.get("retrieval_results"):
            save_result["retrieval_results"] = None

        # Save to DB
        cs.add_message(conv_id, save_result)

        # Audit log (best-effort)
        if task.logger and result.get("sql"):
            try:
                qr = result.get("query_result") or {}
                task.logger.log_full(
                    question=result["question"],
                    generated_sql=result["sql"],
                    execution_status=(
                        "success" if qr.get("success")
                        else ("failed" if qr else "skipped")
                    ),
                    row_count=qr.get("row_count") if qr.get("success") else None,
                    latency_seconds=result.get("elapsed"),
                    trino_query_id=qr.get("query_id") if qr else None,
                    error_message=(
                        qr.get("error") if qr and not qr.get("success")
                        else result.get("error")
                    ),
                    retriever_used=getattr(st.session_state.get("_pipeline"), "retriever_type", "unknown"),
                    llm_rerank_used=st.session_state.settings.get("use_rerank", True),
                    context_chars=len(result["context"]) if result.get("context") else None,
                )
            except Exception:
                pass

    # ── Poll verification tasks (execute / regenerate) ──
    vtasks = st.session_state.get("_verification_tasks", {})
    vcompleted = []
    for vkey, vtask in list(vtasks.items()):
        if vtask.done:
            vcompleted.append(vkey)

    for vkey in vcompleted:
        vtask = vtasks.pop(vkey)
        conv_id = vtask.conv_id
        msg_index = vtask.msg_index

        # Load current messages from DB to get the message at msg_index
        messages = cs.get_messages(conv_id)
        if msg_index >= len(messages):
            continue
        msg = messages[msg_index]

        vresult = vtask.result
        if vresult is None:
            # Task failed
            msg["status"] = "error"
            msg["error"] = f"Verification task failed: {vtask.error}"
        else:
            # Apply the task result to the message
            if vtask.task_type == "execute":
                # SQL was executed — add query_result
                msg["query_result"] = vresult.get("query_result")
                msg["status"] = vresult.get("status", "completed")
                # Add execution step
                steps = msg.get("steps", [])
                qr = vresult.get("query_result", {})
                if qr.get("success"):
                    steps.append({
                        "name": "Query Execution (verified)",
                        "status": "done",
                        "detail": f"{qr['row_count']} rows returned",
                        "elapsed": vresult.get("exec_elapsed", 0),
                    })
                else:
                    steps.append({
                        "name": "Query Execution (verified)",
                        "status": "error",
                        "detail": qr.get("error", "unknown")[:150],
                        "elapsed": vresult.get("exec_elapsed", 0),
                    })
                msg["steps"] = steps

                # Audit log
                if vtask.logger and msg.get("sql"):
                    try:
                        vtask.logger.log_full(
                            question=msg.get("question", ""),
                            generated_sql=msg["sql"],
                            execution_status="success" if qr.get("success") else "failed",
                            row_count=qr.get("row_count") if qr.get("success") else None,
                            latency_seconds=vresult.get("exec_elapsed"),
                            trino_query_id=qr.get("query_id"),
                            error_message=qr.get("error") if not qr.get("success") else None,
                            retriever_used="verified_execute",
                            llm_rerank_used=False,
                            context_chars=None,
                        )
                    except Exception:
                        pass

            elif vtask.task_type == "regenerate":
                # SQL was regenerated — update SQL, reset results
                old_sql = msg.get("sql")
                msg["sql"] = vresult.get("sql", old_sql)
                msg["reasoning"] = vresult.get("reasoning", msg.get("reasoning"))
                msg["query_result"] = None
                msg["explain_result"] = None
                msg["error"] = vresult.get("error")
                msg["status"] = vresult.get("status", "pending_verification")

                # Track feedback history for audit
                fb_history = msg.get("feedback_history", [])
                fb_history.append({
                    "feedback": vtask.kwargs.get("feedback", ""),
                    "previous_sql": old_sql,
                })
                msg["feedback_history"] = fb_history
                msg["feedback"] = None  # Clear current feedback

                # Add regeneration step
                steps = msg.get("steps", [])
                steps.append({
                    "name": "SQL Regeneration (user feedback)",
                    "status": "done",
                    "detail": "GLM-5.2 regenerated SQL based on user feedback",
                    "elapsed": 0,
                })
                msg["steps"] = steps

        # Save updated message to DB
        cs.update_message(conv_id, msg_index, msg)

    if completed or vcompleted:
        st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
#  PAGE CONFIG & PROFESSIONAL CSS
# ═══════════════════════════════════════════════════════════════════════════════
st.set_page_config(
    page_title="UID Data Query Assistant",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    /* ═══ Global Theme ═══ */
    :root {
        --primary: #1a56db;
        --primary-dark: #1e40af;
        --primary-light: #dbeafe;
        --success: #059669;
        --success-light: #d1fae5;
        --warning: #d97706;
        --warning-light: #fef3c7;
        --error: #dc2626;
        --error-light: #fee2e2;
        --neutral-50: #f9fafb;
        --neutral-100: #f3f4f6;
        --neutral-200: #e5e7eb;
        --neutral-300: #d1d5db;
        --neutral-500: #6b7280;
        --neutral-700: #374151;
        --neutral-900: #111827;
    }

    /* Remove default Streamlit padding */
    .stApp {
        max-width: 100% !important;
        padding-top: 0 !important;
    }
    .block-container {
        max-width: 1400px !important;
        padding-top: 1rem !important;
        padding-bottom: 1rem !important;
    }

    /* ═══ Header Bar ═══ */
    .app-header {
        background: linear-gradient(135deg, #1e3a8a 0%, #1a56db 100%);
        color: white;
        padding: 1.25rem 2rem;
        border-radius: 0 0 12px 12px;
        margin: -1rem -2rem 1.5rem -2rem;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .app-header h1 {
        margin: 0;
        font-size: 1.5rem;
        font-weight: 700;
        letter-spacing: -0.5px;
    }
    .app-header .subtitle {
        font-size: 0.8rem;
        opacity: 0.85;
        margin-top: 2px;
    }
    .app-header .badge-row {
        display: flex;
        gap: 8px;
        align-items: center;
    }
    .header-badge {
        background: rgba(255,255,255,0.15);
        border: 1px solid rgba(255,255,255,0.25);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.72rem;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    /* ═══ Chat Messages ═══ */
    .stChatMessage {
        padding: 1rem 1.25rem !important;
        border-radius: 10px !important;
        margin-bottom: 0.75rem !important;
        border: 1px solid var(--neutral-200);
        box-shadow: 0 1px 3px rgba(0,0,0,0.04);
    }

    /* ═══ Pipeline Step Badges ═══ */
    .pipeline-steps {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        margin-bottom: 10px;
    }
    .step-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 10px;
        border-radius: 6px;
        font-size: 0.72rem;
        font-weight: 600;
        line-height: 1.4;
        white-space: nowrap;
    }
    .step-done {
        background: var(--success-light);
        color: #065f46;
        border: 1px solid #6ee7b7;
    }
    .step-error {
        background: var(--error-light);
        color: #991b1b;
        border: 1px solid #fca5a5;
    }
    .step-warning {
        background: var(--warning-light);
        color: #92400e;
        border: 1px solid #fcd34d;
    }
    .step-pending {
        background: var(--neutral-100);
        color: var(--neutral-700);
        border: 1px solid var(--neutral-300);
    }

    /* ═══ Section Cards ═══ */
    .section-card {
        background: white;
        border: 1px solid var(--neutral-200);
        border-radius: 10px;
        padding: 1rem 1.25rem;
        margin-bottom: 0.75rem;
    }
    .section-card h4 {
        margin: 0 0 0.6rem 0;
        font-size: 0.85rem;
        font-weight: 700;
        color: var(--neutral-700);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    /* ═══ SQL Code Block ═══ */
    .stCodeBlock {
        border-radius: 8px !important;
        border: 1px solid var(--neutral-200) !important;
    }

    /* ═══ Metadata Footer ═══ */
    .result-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        padding: 8px 0;
        font-size: 0.75rem;
        color: var(--neutral-500);
        border-top: 1px solid var(--neutral-100);
        margin-top: 8px;
    }
    .result-meta span {
        display: inline-flex;
        align-items: center;
        gap: 3px;
    }

    /* ═══ Verification UI (verify-then-run) ═══ */
    .verify-banner {
        background: linear-gradient(135deg, #fef3c7 0%, #fef9e7 100%);
        border: 1px solid #f59e0b;
        border-radius: 10px;
        padding: 12px 16px;
        margin: 10px 0;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .verify-banner.pending {
        background: linear-gradient(135deg, #fef3c7 0%, #fef9e7 100%);
        border-color: #f59e0b;
    }
    .verify-banner.executing {
        background: linear-gradient(135deg, #dbeafe 0%, #eff6ff 100%);
        border-color: #3b82f6;
    }
    .verify-banner.regenerating {
        background: linear-gradient(135deg, #ede9fe 0%, #f5f3ff 100%);
        border-color: #8b5cf6;
    }
    .verify-banner.rejected {
        background: linear-gradient(135deg, #fee2e2 0%, #fef2f2 100%);
        border-color: #ef4444;
    }
    .verify-banner.completed {
        background: linear-gradient(135deg, #d1fae5 0%, #ecfdf5 100%);
        border-color: #10b981;
    }
    .verify-banner .icon {
        font-size: 1.3rem;
    }
    .verify-banner .text {
        font-size: 0.85rem;
        font-weight: 600;
        color: var(--neutral-700);
    }
    .verify-banner .text .sub {
        font-weight: 400;
        color: var(--neutral-500);
        font-size: 0.78rem;
        margin-top: 2px;
    }
    .feedback-history {
        background: var(--neutral-50);
        border-left: 3px solid var(--warning);
        padding: 8px 12px;
        margin: 6px 0;
        border-radius: 0 6px 6px 0;
        font-size: 0.78rem;
        color: var(--neutral-700);
    }
    .feedback-history .label {
        font-weight: 600;
        color: var(--warning);
    }

    /* ═══ Sidebar ═══ */
    section[data-testid="stSidebar"] {
        background: var(--neutral-50) !important;
        border-right: 1px solid var(--neutral-200);
    }
    section[data-testid="stSidebar"] .stMarkdown h1,
    section[data-testid="stSidebar"] .stMarkdown h2,
    section[data-testid="stSidebar"] .stMarkdown h3 {
        font-size: 0.78rem !important;
        font-weight: 700 !important;
        text-transform: uppercase;
        letter-spacing: 0.6px;
        color: var(--neutral-500) !important;
        margin-bottom: 0.5rem !important;
        padding-bottom: 0.4rem;
        border-bottom: 1px solid var(--neutral-200);
    }

    /* ═══ Inline same-page links ═══ */
    a.conv-link-inline {
        display: block;
        padding: 6px 12px;
        color: var(--primary);
        text-decoration: none;
        font-size: 0.82rem;
        border-radius: 6px;
        margin-bottom: 2px;
    }
    a.conv-link-inline:hover {
        background: var(--primary-light);
    }

    /* ═══ Sidebar Buttons (in-page navigation) ═══ */
    .stButton > button {
        border-radius: 8px !important;
        font-size: 0.82rem !important;
        transition: all 0.15s ease !important;
    }
    .stButton > button[kind="secondary"] {
        background: white !important;
        border: 1px solid var(--neutral-200) !important;
        color: var(--neutral-700) !important;
        text-align: left !important;
    }
    .stButton > button[kind="secondary"]:hover {
        background: var(--primary-light) !important;
        border-color: var(--primary) !important;
        color: var(--primary-dark) !important;
    }
    .stButton > button[kind="primary"] {
        background: var(--primary) !important;
        border-color: var(--primary) !important;
        color: white !important;
        font-weight: 600 !important;
    }
    .stButton > button[kind="primary"]:hover {
        background: var(--primary-dark) !important;
        border-color: var(--primary-dark) !important;
    }

    /* ═══ Health Status Dots ═══ */
    .health-dot {
        display: inline-block;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        margin-right: 6px;
    }
    .health-dot.ok { background: var(--success); box-shadow: 0 0 6px rgba(5,150,105,0.4); }
    .health-dot.down { background: var(--error); }

    /* ═══ Data Table ═══ */
    .stDataFrame {
        border: 1px solid var(--neutral-200);
        border-radius: 8px;
        overflow: hidden;
    }

    /* ═══ Welcome / Empty State ═══ */
    .welcome-card {
        text-align: center;
        padding: 3rem 2rem;
        background: var(--neutral-50);
        border: 1px dashed var(--neutral-300);
        border-radius: 12px;
        margin: 1rem 0;
    }
    .welcome-card h2 {
        color: var(--neutral-700);
        font-size: 1.3rem;
        margin-bottom: 0.5rem;
    }
    .welcome-card p {
        color: var(--neutral-500);
        font-size: 0.9rem;
        margin-bottom: 1.5rem;
    }
    .welcome-examples {
        display: flex;
        flex-direction: column;
        gap: 8px;
        max-width: 500px;
        margin: 0 auto;
        text-align: left;
    }
    .welcome-example {
        padding: 10px 16px;
        background: white;
        border: 1px solid var(--neutral-200);
        border-radius: 8px;
        font-size: 0.85rem;
        color: var(--neutral-700);
        cursor: default;
    }
    .welcome-example:hover {
        border-color: var(--primary);
    }

    /* ═══ Footer ═══ */
    .app-footer {
        text-align: center;
        padding: 1.5rem 0 0.5rem;
        border-top: 1px solid var(--neutral-200);
        margin-top: 2rem;
    }
    .app-footer p {
        font-size: 0.72rem;
        color: var(--neutral-500);
        margin: 0;
    }

    /* ═══ Conversation Header ═══ */
    .conv-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 1rem;
    }
    .conv-header h2 {
        margin: 0;
        font-size: 1.2rem;
        font-weight: 700;
        color: var(--neutral-900);
    }
    .conv-header .conv-meta {
        font-size: 0.78rem;
        color: var(--neutral-500);
    }

    /* ═══ Toggle Styling ═══ */
    .stToggle > div {
        padding-top: 4px;
        padding-bottom: 4px;
    }
</style>
""", unsafe_allow_html=True)


def _same_page_link(href, label):
    """Render an HTML link that navigates within the same page (no new tab)."""
    st.markdown(
        f'<a href="{href}" class="conv-link-inline">{label}</a>',
        unsafe_allow_html=True,
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  RENDERING HELPERS
# ═══════════════════════════════════════════════════════════════════════════════
def _render_steps(steps):
    """Render pipeline step badges."""
    parts = []
    for s in steps:
        status = s.get("status", "pending")
        icon = {"done": "✅", "error": "❌", "warning": "⚠️", "pending": "⏳"}.get(status, "⏳")
        elapsed = s.get("elapsed", 0)
        parts.append(
            f'<span class="step-badge step-{status}">{icon} {s["name"]} · {elapsed}s</span>'
        )
    st.markdown(f'<div class="pipeline-steps">{"".join(parts)}</div>', unsafe_allow_html=True)
    st.caption(" | ".join(f'{s["name"]}: {s.get("detail","")}' for s in steps))


def _render_meta(msg):
    """Render metadata line."""
    elapsed = msg.get("elapsed", 0)
    parts = [f"⏱ {elapsed}s"]
    if msg.get("retrieval_results"):
        lr = msg["retrieval_results"].get("local_results", [])
        parts.append(f"🔍 {len(lr)} entities retrieved")
    if msg.get("sql"):
        parts.append("🤖 GLM-5.2-FP8")
    qr = msg.get("query_result")
    if qr and qr.get("success"):
        parts.append(f"📊 {qr['row_count']} rows")
    st.markdown(
        f'<div class="result-meta">{"".join(f"<span>{p}</span>" for p in parts)}</div>',
        unsafe_allow_html=True,
    )


def _render_assistant_message(msg, msg_index=0):
    """Render an assistant response with steps, SQL, verification UI, results, etc."""
    status = msg.get("status")
    conv_id = st.session_state.current_conv_id

    # Top-level error (pipeline failed before SQL was generated)
    if msg.get("error") and not msg.get("sql"):
        st.error(f"❌ {msg['error']}")
        if msg.get("steps"):
            _render_steps(msg["steps"])
        _render_meta(msg)
        return

    # Metadata answer (from intent classification — no SQL)
    if msg.get("metadata_answer") and not msg.get("sql"):
        st.markdown("""
        <div class="section-card">
            <h4>📋 Metadata Answer</h4>
        </div>
        """, unsafe_allow_html=True)
        st.markdown(msg["metadata_answer"])
        _render_meta(msg)
        return

    # Pipeline step badges
    if msg.get("steps"):
        _render_steps(msg["steps"])

    # Feedback history (previous rejections → regenerations)
    fb_history = msg.get("feedback_history", [])
    if fb_history:
        for i, fh in enumerate(fb_history):
            st.markdown(f"""
            <div class="feedback-history">
                <span class="label">↩️ Feedback #{i+1}:</span> {fh.get('feedback', '')}
            </div>
            """, unsafe_allow_html=True)

    # Generated SQL
    if msg.get("sql"):
        label = "📝 Generated SQL"
        if status == "rejected":
            label = "📝 Generated SQL (rejected)"
        elif status == "regenerating":
            label = "📝 Previous SQL (regenerating...)"
        elif fb_history:
            label = f"📝 Generated SQL (revision #{len(fb_history)})"
        st.markdown(f"""
        <div class="section-card">
            <h4>{label}</h4>
        </div>
        """, unsafe_allow_html=True)
        st.code(msg["sql"], language="sql")
        st.caption(f"⏱ Total pipeline time: {msg.get('elapsed', 0)}s")

    # ── Verification UI ──
    if status == "pending_verification" and msg.get("sql"):
        _render_verification_pending(msg, msg_index, conv_id)

    elif status == "executing":
        st.markdown("""
        <div class="verify-banner executing">
            <span class="icon">🔄</span>
            <span class="text">Executing query against Trino...<div class="sub">Results will appear here when ready.</div></span>
        </div>
        """, unsafe_allow_html=True)

    elif status == "regenerating":
        st.markdown("""
        <div class="verify-banner regenerating">
            <span class="icon">🤖</span>
            <span class="text">Regenerating SQL with your feedback...<div class="sub">GLM-5.2 is revising the query. This takes a few seconds.</div></span>
        </div>
        """, unsafe_allow_html=True)

    elif status == "rejected" and msg.get("sql"):
        _render_verification_rejected(msg, msg_index, conv_id)

    elif status == "completed":
        if msg.get("query_result") and msg["query_result"].get("success"):
            st.markdown("""
            <div class="verify-banner completed">
                <span class="icon">✅</span>
                <span class="text">Query executed successfully</span>
            </div>
            """, unsafe_allow_html=True)

    # Retrieved context (collapsible)
    if msg.get("context") and st.session_state.settings.get("show_context"):
        with st.expander("📖 Retrieved Context (GraphRAG)", expanded=False):
            st.text(msg["context"])

    # LLM reasoning (collapsible)
    if msg.get("reasoning") and st.session_state.settings.get("show_reasoning"):
        with st.expander("🧠 LLM Reasoning (chain-of-thought)", expanded=False):
            st.text(msg["reasoning"])

    # Query results
    qr = msg.get("query_result")
    if qr:
        if qr.get("success"):
            row_count = qr['row_count']
            st.markdown(f"""
            <div class="section-card">
                <h4>📊 Results · {row_count} row{'s' if row_count != 1 else ''}</h4>
            </div>
            """, unsafe_allow_html=True)
            cols = qr.get("columns", [])
            rows = qr.get("rows", [])
            if cols and rows:
                df = pd.DataFrame(rows, columns=cols)
                st.dataframe(df, width="stretch")
            elif cols:
                st.info("Query returned 0 rows.")
            else:
                st.info("Query executed successfully (no tabular data).")
        else:
            st.error(f"❌ Execution failed: {qr.get('error', 'unknown error')}")
            # Allow re-verification after execution error
            if msg.get("sql"):
                _render_verification_pending(msg, msg_index, conv_id, label="↻ Try Again")

    _render_meta(msg)


def _render_verification_pending(msg, msg_index, conv_id, label=None):
    """Show Run / Reject buttons for a pending SQL verification."""
    st.markdown("""
    <div class="verify-banner pending">
        <span class="icon">⏳</span>
        <span class="text">SQL generated — awaiting your verification<div class="sub">Review the query above, then approve to run it or reject to provide corrections.</div></span>
    </div>
    """, unsafe_allow_html=True)

    col1, col2, _ = st.columns([1, 1, 3])
    with col1:
        run_label = label or "✓ Run Query"
        if st.button(run_label, key=f"run_{msg_index}", type="primary"):
            # Update status to executing
            msg["status"] = "executing"
            cs.update_message(conv_id, msg_index, msg)
            # Start execution task
            tts = get_pipeline()
            logger = st.session_state.get("_logger") or safe_init_logger()
            st.session_state["_logger"] = logger
            task = VerificationTask(
                conv_id=conv_id,
                msg_index=msg_index,
                task_type="execute",
                logger=logger,
                sql=msg["sql"],
            )
            task.start()
            if "_verification_tasks" not in st.session_state:
                st.session_state["_verification_tasks"] = {}
            st.session_state["_verification_tasks"][f"{conv_id}_{msg_index}"] = task
            st.rerun()
    with col2:
        if st.button("✗ Reject & Correct", key=f"reject_{msg_index}"):
            msg["status"] = "rejected"
            cs.update_message(conv_id, msg_index, msg)
            st.rerun()


def _render_verification_rejected(msg, msg_index, conv_id):
    """Show feedback input + regenerate button after user rejects SQL."""
    st.markdown("""
    <div class="verify-banner rejected">
        <span class="icon">✗</span>
        <span class="text">SQL rejected — provide feedback for correction<div class="sub">Describe what's wrong and the LLM will regenerate the query.</div></span>
    </div>
    """, unsafe_allow_html=True)

    feedback = st.text_area(
        "What needs to be corrected?",
        key=f"feedback_{msg_index}",
        height=90,
        placeholder="e.g., The WHERE clause should filter by uid_status_key = 1 (active), not 0. Also add a GROUP BY registrar_id clause.",
    )

    col1, col2, col3, _ = st.columns([1.2, 1, 1, 2])
    with col1:
        if st.button("🔄 Regenerate SQL", key=f"regen_{msg_index}", type="primary"):
            if not feedback or not feedback.strip():
                st.warning("Please describe the correction before regenerating.")
            else:
                msg["status"] = "regenerating"
                msg["feedback"] = feedback.strip()
                cs.update_message(conv_id, msg_index, msg)

                # Build conversation history for context-aware regeneration
                history = []
                for m in st.session_state.messages:
                    if m.get("role") == "user" and m.get("content"):
                        history.append({"question": m["content"], "sql": None})
                    elif m.get("role") == "assistant" and m.get("question") and m.get("sql"):
                        if history:
                            history[-1]["sql"] = m["sql"]
                        else:
                            history.append({"question": m["question"], "sql": m["sql"]})

                tts = get_pipeline()
                logger = st.session_state.get("_logger") or safe_init_logger()
                st.session_state["_logger"] = logger

                task = VerificationTask(
                    conv_id=conv_id,
                    msg_index=msg_index,
                    task_type="regenerate",
                    logger=logger,
                    question=msg.get("question", ""),
                    previous_sql=msg["sql"],
                    feedback=feedback.strip(),
                    context=msg.get("context", ""),
                    history=history,
                    tts=tts,
                )
                task.start()
                if "_verification_tasks" not in st.session_state:
                    st.session_state["_verification_tasks"] = {}
                st.session_state["_verification_tasks"][f"{conv_id}_{msg_index}"] = task
                st.rerun()
    with col2:
        if st.button("✓ Run Anyway", key=f"runanyway_{msg_index}"):
            # User changed their mind — run the SQL as-is
            msg["status"] = "executing"
            cs.update_message(conv_id, msg_index, msg)
            tts = get_pipeline()
            logger = st.session_state.get("_logger") or safe_init_logger()
            st.session_state["_logger"] = logger
            task = VerificationTask(
                conv_id=conv_id,
                msg_index=msg_index,
                task_type="execute",
                logger=logger,
                sql=msg["sql"],
            )
            task.start()
            if "_verification_tasks" not in st.session_state:
                st.session_state["_verification_tasks"] = {}
            st.session_state["_verification_tasks"][f"{conv_id}_{msg_index}"] = task
            st.rerun()
    with col3:
        if st.button("↩ Cancel", key=f"cancel_{msg_index}"):
            # Go back to pending verification
            msg["status"] = "pending_verification"
            cs.update_message(conv_id, msg_index, msg)
            st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
#  HEALTH CHECKS
# ═══════════════════════════════════════════════════════════════════════════════
@st.cache_resource(show_spinner=False)
def check_llm_health():
    """Quick LLM health check with short timeout — just tests HTTP reachability."""
    try:
        r = requests.get("http://10.10.109.101:32320/glm52/v1/models", timeout=3)
        return r.status_code == 200
    except Exception:
        return False


@st.cache_resource(show_spinner=False)
def check_trino_health():
    try:
        r = requests.get(f"{TRINO_URL}/v1/info", timeout=3)
        return r.status_code == 200
    except Exception:
        return False


# ═══════════════════════════════════════════════════════════════════════════════
#  SESSION STATE & URL ROUTING
# ═══════════════════════════════════════════════════════════════════════════════
if "settings" not in st.session_state:
    st.session_state.settings = {
        "use_rerank": True,
        "auto_execute": False,
        "run_explain": True,
        "show_context": False,
        "show_reasoning": False,
        "verify_before_run": True,
    }

# ─── Handle URL query params (?new=1, ?conv_id=xxx, ?question=xxx) ───────────
_qp = st.query_params

if "new" in _qp:
    new_conv = cs.create_conversation()
    st.session_state.current_conv_id = new_conv["id"]
    st.session_state.messages = []
    st.query_params["conv_id"] = new_conv["id"]
    del st.query_params["new"]
    st.rerun()

if "question" in _qp:
    _prefill = _qp["question"]
    new_conv = cs.create_conversation()
    st.session_state.current_conv_id = new_conv["id"]
    st.session_state.messages = []
    st.session_state["pending_question"] = _prefill
    st.query_params["conv_id"] = new_conv["id"]
    del st.query_params["question"]
    st.rerun()

if "conv_id" in _qp:
    _requested = _qp["conv_id"]
    if cs.load_conversation(_requested):
        st.session_state.current_conv_id = _requested
        st.session_state.messages = cs.get_messages(_requested)
    else:
        del st.query_params["conv_id"]
        st.rerun()
elif "current_conv_id" not in st.session_state:
    convs = cs.list_conversations()
    if convs:
        st.session_state.current_conv_id = convs[0]["id"]
        st.session_state.messages = cs.get_messages(convs[0]["id"])
    else:
        new_conv = cs.create_conversation()
        st.session_state.current_conv_id = new_conv["id"]
        st.session_state.messages = []
elif "current_conv_id" in st.session_state:
    st.session_state.messages = cs.get_messages(st.session_state.current_conv_id)


# ═══════════════════════════════════════════════════════════════════════════════
#  SIDEBAR
# ═══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    # ── Conversation management ──
    st.markdown("## Conversations")

    # New chat — in-page navigation (no new tab)
    if st.button("➕ New Chat", use_container_width=True, type="primary"):
        new_conv = cs.create_conversation()
        st.session_state.current_conv_id = new_conv["id"]
        st.session_state.messages = []
        st.query_params["conv_id"] = new_conv["id"]
        st.rerun()

    convs = cs.list_conversations()
    if convs:
        st.markdown(f"<small style='color:#6b7280;'>{len(convs)} conversation{'s' if len(convs) != 1 else ''}</small>", unsafe_allow_html=True)
        for c in convs:
            is_active = c["id"] == st.session_state.current_conv_id
            label = ("▸ " if is_active else "") + c["title"]
            _help = f"{c['message_count']} messages · updated {c['updated_at'][:19]}"

            col_conv, col_del = st.columns([5, 1])
            with col_conv:
                # In-page conversation switch (no new tab)
                if st.button(
                    label,
                    key=f"conv_{c['id']}",
                    use_container_width=True,
                    help=_help,
                    type="primary" if is_active else "secondary",
                ):
                    st.session_state.current_conv_id = c["id"]
                    st.session_state.messages = cs.get_messages(c["id"])
                    st.query_params["conv_id"] = c["id"]
                    st.rerun()
            with col_del:
                if st.button("🗑️", key=f"del_{c['id']}", help="Delete conversation"):
                    cs.delete_conversation(c["id"])
                    remaining = cs.list_conversations()
                    if remaining:
                        st.session_state.current_conv_id = remaining[0]["id"]
                        st.session_state.messages = cs.get_messages(remaining[0]["id"])
                        st.query_params["conv_id"] = remaining[0]["id"]
                    else:
                        new_conv = cs.create_conversation()
                        st.session_state.current_conv_id = new_conv["id"]
                        st.session_state.messages = []
                        st.query_params["conv_id"] = new_conv["id"]
                    st.rerun()
    else:
        st.caption("No conversations yet.")

    st.divider()

    # ── Pipeline settings ──
    st.markdown("## Pipeline Settings")

    st.session_state.settings["use_rerank"] = st.toggle(
        "LLM Re-ranking",
        value=st.session_state.settings["use_rerank"],
        help="Use GLM-5.2 to re-rank retrieval candidates (slower but more accurate)",
    )
    st.session_state.settings["verify_before_run"] = st.toggle(
        "Verify before run",
        value=st.session_state.settings.get("verify_before_run", True),
        help="Show generated SQL for your approval before executing. Reject to provide feedback and regenerate.",
    )
    st.session_state.settings["auto_execute"] = st.toggle(
        "Auto-execute SQL",
        value=st.session_state.settings["auto_execute"],
        help="Run SQL automatically (only when 'Verify before run' is off)",
        disabled=st.session_state.settings.get("verify_before_run", True),
    )
    st.session_state.settings["run_explain"] = st.toggle(
        "EXPLAIN validation",
        value=st.session_state.settings["run_explain"],
        help="Validate SQL syntax with EXPLAIN before execution",
    )
    st.session_state.settings["show_context"] = st.toggle(
        "Show retrieved context",
        value=st.session_state.settings["show_context"],
        help="Display the GraphRAG context sent to the LLM",
    )
    st.session_state.settings["show_reasoning"] = st.toggle(
        "Show LLM reasoning",
        value=st.session_state.settings["show_reasoning"],
        help="Display GLM-5.2's chain-of-thought reasoning",
    )

    st.divider()

    st.markdown("## Query Options")

    st.divider()

    # ── Health checks ──
    st.markdown("## System Health")
    try:
        trino_ok = check_trino_health()
    except Exception:
        trino_ok = False
    try:
        llm_ok = check_llm_health()
    except Exception:
        llm_ok = False

    llm_dot = "ok" if llm_ok else "down"
    trino_dot = "ok" if trino_ok else "down"
    llm_label = "Online" if llm_ok else "Offline"
    trino_label = "Online" if trino_ok else "Offline"

    st.markdown(f"""
    <div style="display:flex; flex-direction:column; gap:8px;">
        <div style="display:flex; align-items:center; justify-content:space-between; padding:8px 12px; background:white; border:1px solid #e5e7eb; border-radius:8px;">
            <span style="font-size:0.82rem; font-weight:500; color:#374151;">GLM-5.2 LLM</span>
            <span style="font-size:0.78rem; color:#6b7280;"><span class="health-dot {llm_dot}"></span>{llm_label}</span>
        </div>
        <div style="display:flex; align-items:center; justify-content:space-between; padding:8px 12px; background:white; border:1px solid #e5e7eb; border-radius:8px;">
            <span style="font-size:0.82rem; font-weight:500; color:#374151;">Trino</span>
            <span style="font-size:0.78rem; color:#6b7280;"><span class="health-dot {trino_dot}"></span>{trino_label}</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.divider()

    # ── Query audit history ──
    st.markdown("## Audit Log")
    logger = st.session_state.get("_logger")
    if logger is None:
        logger = safe_init_logger()
        st.session_state["_logger"] = logger
    if logger:
        try:
            recent = logger.recent(limit=5)
            if recent:
                for r in recent:
                    status_icon = {"success": "✅", "failed": "❌", "pending": "⏳"}.get(
                        r.get("execution_status"), "❓"
                    )
                    label = f"{status_icon} {r['question'][:50]}..."
                    # In-page: create new conversation with pending question
                    if st.button(label, key=f"audit_{r['question'][:30]}", use_container_width=True, help=r['question']):
                        new_conv = cs.create_conversation()
                        st.session_state.current_conv_id = new_conv["id"]
                        st.session_state.messages = []
                        st.session_state["pending_question"] = r["question"]
                        st.query_params["conv_id"] = new_conv["id"]
                        st.rerun()
            else:
                st.caption("No queries logged yet.")
        except Exception:
            st.caption("Query log unavailable.")
    else:
        st.caption("Query logger not connected.")

    st.divider()
    st.caption("UID Data Query Assistant\nGraphRAG · GLM-5.2-FP8 · Trino")


# ═══════════════════════════════════════════════════════════════════════════════
#  MAIN AREA — HEADER + CHAT INTERFACE
# ═══════════════════════════════════════════════════════════════════════════════

# ── Professional header bar ──
_trino_status = "✅" if trino_ok else "❌"
_llm_status = "✅" if llm_ok else "❌"
st.markdown(f"""
<div class="app-header">
    <div>
        <h1>🏛️ UID Data Query Assistant</h1>
        <div class="subtitle">Natural Language → Trino SQL · GraphRAG + GLM-5.2-FP8</div>
    </div>
    <div class="badge-row">
        <span class="header-badge">{_llm_status} GLM-5.2</span>
        <span class="header-badge">{_trino_status} Trino</span>
    </div>
</div>
""", unsafe_allow_html=True)

# ── Conversation title ──
_current_conv = cs.load_conversation(st.session_state.current_conv_id)
_conv_title = _current_conv.get("title", "New Chat") if _current_conv else "New Chat"
_conv_count = len(st.session_state.messages)

st.markdown(f"""
<div class="conv-header">
    <h2>💬 {_conv_title}</h2>
    <span class="conv-meta">{_conv_count} message{'s' if _conv_count != 1 else ''}</span>
</div>
""", unsafe_allow_html=True)

# ── Display chat history ──
for idx, msg in enumerate(st.session_state.messages):
    role = msg.get("role", "assistant")
    with st.chat_message(role):
        if role == "user":
            st.markdown(msg.get("content", ""))
        else:
            _render_assistant_message(msg, idx)

# ── Show "Running..." indicator if a pipeline is active for this conversation ──
_active_tasks = st.session_state.get("_active_tasks", {})
_current_task = _active_tasks.get(st.session_state.current_conv_id)
if _current_task and not _current_task.done:
    with st.chat_message("assistant"):
        st.info("🔄 Pipeline running in background... Results will appear here shortly.")

# ── Poll background tasks (saves completed results to DB and triggers rerun) ──
_poll_background_tasks()

# ── Welcome / empty state ──
if not st.session_state.messages:
    st.markdown("""
    <div class="welcome-card">
        <h2>👋 Welcome to UID Data Query Assistant</h2>
        <p>Ask questions about UID/Aadhaar data in natural language. The assistant will
        generate Trino SQL, validate it, execute it, and return results — all in real time.</p>
        <div class="welcome-examples">
            <div class="welcome-example">💡 How many active UIDs are there?</div>
            <div class="welcome-example">💡 Count of UIDs by status</div>
            <div class="welcome-example">💡 How many UIDs have address updates?</div>
            <div class="welcome-example">💡 Show the distribution of UID status codes for shard 12</div>
        </div>
    </div>
    """, unsafe_allow_html=True)

# ── Handle pending question from audit log click ──
pending = st.session_state.pop("pending_question", None)

# ── Chat input ──
user_input = st.chat_input("Ask a question about UID/Aadhaar data...")
if pending and not user_input:
    user_input = pending

if user_input:
    # Add and display user message — persist to disk
    user_msg = {"role": "user", "content": user_input}
    st.session_state.messages.append(user_msg)
    cs.add_message(st.session_state.current_conv_id, user_msg)

    with st.chat_message("user"):
        st.markdown(user_input)

    # Build conversation history (previous Q&A pairs) for context-aware follow-ups
    _history = []
    for m in st.session_state.messages:
        if m.get("role") == "user" and m.get("content"):
            _history.append({"question": m["content"], "sql": None})
        elif m.get("role") == "assistant" and m.get("question") and m.get("sql"):
            if _history:
                _history[-1]["sql"] = m["sql"]
            else:
                _history.append({"question": m["question"], "sql": m["sql"]})

    # Start pipeline in a background thread (survives conversation switches)
    tts = get_pipeline()
    st.session_state["_pipeline"] = tts
    logger = st.session_state.get("_logger") or safe_init_logger()
    st.session_state["_logger"] = logger

    task = PipelineTask(
        conv_id=st.session_state.current_conv_id,
        question=user_input,
        settings=dict(st.session_state.settings),  # snapshot settings
        history=_history,
        tts=tts,
        logger=logger,
    )
    task.start()

    if "_active_tasks" not in st.session_state:
        st.session_state["_active_tasks"] = {}
    st.session_state["_active_tasks"][st.session_state.current_conv_id] = task

    # Show running indicator
    with st.chat_message("assistant"):
        st.info("🔄 Running pipeline... This will appear when results are ready. You can switch conversations — the pipeline continues in the background.")

# ── Footer ──
st.markdown("""
<div class="app-footer">
    <p>UID Data Query Assistant · Powered by GraphRAG, GLM-5.2-FP8 &amp; Trino · Read-only access to strot.mysql_uid_v2</p>
</div>
""", unsafe_allow_html=True)
