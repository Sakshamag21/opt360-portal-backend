"""
Script to create 6 new suspension signals in the Signal API.

Run this in Jupyter (which has access to the internal network).

Usage:
    python create_signals.py

Or paste into a Jupyter cell and run.
"""
import requests
import json

SIGNAL_API_BASE = "http://10.10.118.48:8000"

# ─── The 6 signals to create ─────────────────────────────────────────────────
# Fields match the Go API's CreateSignal SQL:
#   id, name, version, description, feature_id, feature_version,
#   threshold, severity_level, user

SIGNALS_TO_CREATE = [
    {
        "id": "opt_qc_doe2_suspension",
        "name": "Operator QC DOE2 Suspension Signal",
        "version": 1,
        "description": "Operator making packets which have been identified in DOE2 error category by QC",
        "feature_id": "doc_qc_error_doe2_incidents_count_monthly_v1",
        "feature_version": 1,
        "threshold": 30,
        "severity_level": 10,
        "user": "saksham.nisg",
    },
    {
        "id": "opt_qc_de_suspension",
        "name": "Operator QC DE Suspension Signal",
        "version": 1,
        "description": "Operator making packets which have been identified in DE error category by QC",
        "feature_id": "doc_qc_error_de_incidents_count_monthly_v1",
        "feature_version": 1,
        "threshold": 30,
        "severity_level": 10,
        "user": "saksham.nisg",
    },
    {
        "id": "opt_qc_be_suspension",
        "name": "Operator QC BE Suspension Signal",
        "version": 1,
        "description": "Operator making packets which have been identified in BE error category by QC",
        "feature_id": "doc_qc_error_be_incidents_count_monthly_v1",
        "feature_version": 1,
        "threshold": 30,
        "severity_level": 10,
        "user": "saksham.nisg",
    },
    # NOTE: Flipped iris already exists as version 1 at threshold=2.
    # Creating version 2 at threshold=5 as requested.
    {
        "id": "opt_bio_flipped_iris_cumulative_count_1d_suspension",
        "name": "Operator Flipped Iris Suspension",
        "version": 2,
        "description": "Operator making packets which have been given Flipped verdict in Iris modality in MFC",
        "feature_id": "bio_packet_iris_flipped_count_cumulative_v1",
        "feature_version": 1,
        "threshold": 5,
        "severity_level": 10,
        "user": "saksham.nisg",
    },
    {
        "id": "opt_bio_mixed_iris_cumulative_count_1d_suspension",
        "name": "Operator Mixed Iris Suspension",
        "version": 1,
        "description": "Operator making packets which have been given Mixed verdict in Iris modality in MFC",
        "feature_id": "bio_packet_iris_mixed_count_cumulative_v1",
        "feature_version": 1,
        "threshold": 5,
        "severity_level": 10,
        "user": "saksham.nisg",
    },
    {
        "id": "opt_bio_mixed_finger_cumulative_count_1d_suspension",
        "name": "Operator Mixed Finger Suspension",
        "version": 1,
        "description": "Operator making packets which have been given Mixed verdict in Finger modality in MFC",
        "feature_id": "bio_packet_finger_mixed_count_cumulative_v1",
        "feature_version": 1,
        "threshold": 5,
        "severity_level": 10,
        "user": "saksham.nisg",
    },
]

# ─── Existing signals to verify (should already exist) ───────────────────────
EXISTING_SIGNALS_TO_CHECK = [
    {"feature_id": "doc_qc_error_pop_incidents_count_monthly_v1", "expected_signal_id": "opt_qc_pop_suspension", "expected_threshold": 2},
    {"feature_id": "doc_qc_error_doe1_incidents_count_monthly_v1", "expected_signal_id": "opt_qc_doe1_suspension", "expected_threshold": 5},
]


def check_api_health():
    """Check if the Signal API is reachable."""
    try:
        resp = requests.get(f"{SIGNAL_API_BASE}/", timeout=10)
        print(f"✅ Signal API is reachable (status {resp.status_code})")
        return True
    except requests.exceptions.ConnectionError:
        print(f"❌ Signal API is NOT reachable at {SIGNAL_API_BASE}")
        print("   Make sure you're running this from Jupyter on the internal network.")
        return False
    except Exception as e:
        print(f"❌ Signal API error: {e}")
        return False


def get_signals_info(feature_id):
    """Fetch existing signals for a feature_id."""
    try:
        resp = requests.get(f"{SIGNAL_API_BASE}/api/signal/info/{feature_id}", timeout=15)
        return resp.json()
    except Exception as e:
        return {"success": False, "error": str(e)}


def create_signal(signal_data):
    """Create a single signal via the API."""
    try:
        resp = requests.post(
            f"{SIGNAL_API_BASE}/api/signal/create",
            json=signal_data,
            timeout=15,
        )
        return resp.json()
    except Exception as e:
        return {"success": False, "error": str(e)}


def main():
    print("=" * 70)
    print("  Operator360 Signal Creation Script")
    print("=" * 70)
    print()

    # 1. Check API health
    if not check_api_health():
        return
    print()

    # 2. Verify existing signals
    print("─── Step 1: Verify existing signals ─────────────────────────────────")
    print()
    for existing in EXISTING_SIGNALS_TO_CHECK:
        fid = existing["feature_id"]
        result = get_signals_info(fid)
        if result.get("success") and result.get("data", {}).get("count", 0) > 0:
            signals = result["data"]["signals"]
            for sig in signals:
                marker = "✅" if sig.get("id") == existing["expected_signal_id"] else "  "
                print(f"  {marker} {sig.get('id')} → {fid} (threshold={sig.get('threshold')}, severity={sig.get('severity_level')})")
            # Check if expected signal exists
            found = any(s.get("id") == existing["expected_signal_id"] for s in signals)
            if not found:
                print(f"  ⚠️  Expected signal '{existing['expected_signal_id']}' NOT found for {fid}")
        else:
            print(f"  ⚠️  No signals found for {fid} — {result.get('message', result.get('error', 'unknown'))}")
    print()

    # 3. Check which new signals already exist (to avoid duplicates)
    print("─── Step 2: Check for existing duplicates ───────────────────────────")
    print()
    to_create = []
    for signal in SIGNALS_TO_CREATE:
        fid = signal["feature_id"]
        sid = signal["id"]
        result = get_signals_info(fid)
        already_exists = False
        if result.get("success") and result.get("data", {}).get("count", 0) > 0:
            for sig in result["data"]["signals"]:
                # Match on both id AND version to allow new versions of existing signals
                if sig.get("id") == sid and int(sig.get("version", 0)) == signal["version"]:
                    print(f"  ⏭️  {sid} v{signal['version']} already exists for {fid} (threshold={sig.get('threshold')}) — skipping")
                    already_exists = True
                    break
        if not already_exists:
            print(f"  📝 {sid} v{signal['version']} → {fid} — will create (threshold={signal['threshold']})")
            to_create.append(signal)
    print()

    if not to_create:
        print("─── All signals already exist. Nothing to create. ───────────────────")
        return

    # 4. Create new signals
    print(f"─── Step 3: Create {len(to_create)} new signals ────────────────────────────")
    print()
    success_count = 0
    fail_count = 0
    for signal in to_create:
        print(f"  Creating: {signal['id']} → {signal['feature_id']} (threshold={signal['threshold']})...")
        result = create_signal(signal)
        if result.get("success"):
            print(f"  ✅ Created successfully")
            success_count += 1
        else:
            print(f"  ❌ Failed: {result.get('message', result.get('error', result))}")
            fail_count += 1
        print()

    # 5. Summary
    print("─── Summary ─────────────────────────────────────────────────────────")
    print(f"  Created: {success_count}")
    print(f"  Failed:  {fail_count}")
    print(f"  Skipped (already existed): {len(SIGNALS_TO_CREATE) - len(to_create)}")
    print()

    # 6. Final verification
    print("─── Step 4: Verify all signals after creation ───────────────────────")
    print()
    all_signals = SIGNALS_TO_CREATE + [
        {"id": existing["expected_signal_id"], "feature_id": existing["feature_id"], "threshold": existing["expected_threshold"], "version": 1}
        for existing in EXISTING_SIGNALS_TO_CHECK
    ]
    for signal in all_signals:
        fid = signal["feature_id"]
        sid = signal["id"]
        result = get_signals_info(fid)
        if result.get("success") and result.get("data", {}).get("count", 0) > 0:
            found = False
            for sig in result["data"]["signals"]:
                if sig.get("id") == sid and int(sig.get("version", 0)) == signal["version"]:
                    print(f"  ✅ {sid} v{signal['version']} → {fid} (threshold={sig.get('threshold')}, severity={sig.get('severity_level')})")
                    found = True
                    break
            if not found:
                print(f"  ❌ {sid} NOT found for {fid}")
        else:
            print(f"  ❌ No signals returned for {fid}")
    print()
    print("Done!")


if __name__ == "__main__":
    main()
