#!/usr/bin/env python3
"""
Conversation store — persists chat sessions to a SQLite database.

Each conversation has metadata (title, timestamps) and a list of messages.
Messages are stored as JSON blobs so the full assistant response
(including SQL, query results, steps, reasoning, etc.) is preserved.

Database file: conversations.db (next to this module).
"""

import sqlite3
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


# ─── Database location ───────────────────────────────────────────────────────
DB_PATH = Path(__file__).resolve().parent / "conversations.db"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def _init_db():
    """Create tables if they don't exist."""
    conn = _get_conn()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS conversations (
            id          TEXT PRIMARY KEY,
            title       TEXT NOT NULL DEFAULT 'New Chat',
            created_at  TEXT NOT NULL,
            updated_at  TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS messages (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            conv_id     TEXT NOT NULL,
            role        TEXT NOT NULL,
            content     TEXT NOT NULL,
            created_at  TEXT NOT NULL,
            FOREIGN KEY (conv_id) REFERENCES conversations(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conv_id);
    """)
    conn.commit()
    conn.close()


# Initialize on import
_init_db()


# ─── Fields to strip from assistant messages before saving ───────────────────
# retrieval_results is large internal pipeline data — not needed for display.
_SAVE_STRIP_KEYS = {"retrieval_results"}


def _clean_message(msg: dict) -> dict:
    """Remove fields that shouldn't be persisted (large internal data)."""
    return {k: v for k, v in msg.items() if k not in _SAVE_STRIP_KEYS}


# ═══════════════════════════════════════════════════════════════════════════════
#  CRUD OPERATIONS
# ═══════════════════════════════════════════════════════════════════════════════
def create_conversation(title: str = "New Chat") -> dict:
    """Create a new conversation row and return the conv dict."""
    conv_id = f"conv_{uuid.uuid4().hex[:12]}"
    now = _now_iso()
    conn = _get_conn()
    conn.execute(
        "INSERT INTO conversations (id, title, created_at, updated_at) VALUES (?, ?, ?, ?)",
        (conv_id, title, now, now),
    )
    conn.commit()
    conn.close()
    return {"id": conv_id, "title": title, "created_at": now, "updated_at": now, "messages": []}


def load_conversation(conv_id: str) -> Optional[dict]:
    """Load a conversation (without messages). Returns None if not found."""
    conn = _get_conn()
    row = conn.execute(
        "SELECT id, title, created_at, updated_at FROM conversations WHERE id = ?",
        (conv_id,),
    ).fetchone()
    conn.close()
    if row is None:
        return None
    return dict(row)


def delete_conversation(conv_id: str) -> bool:
    """Delete a conversation and all its messages. Returns True if deleted."""
    conn = _get_conn()
    cur = conn.execute("DELETE FROM conversations WHERE id = ?", (conv_id,))
    conn.commit()
    deleted = cur.rowcount > 0
    conn.close()
    return deleted


def list_conversations() -> list:
    """Return all conversations sorted by updated_at descending."""
    conn = _get_conn()
    rows = conn.execute(
        """
        SELECT c.id, c.title, c.created_at, c.updated_at,
               (SELECT count(*) FROM messages m WHERE m.conv_id = c.id) AS message_count
        FROM conversations c
        ORDER BY c.updated_at DESC
        """,
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def rename_conversation(conv_id: str, title: str) -> bool:
    """Rename a conversation. Returns True on success."""
    conn = _get_conn()
    cur = conn.execute(
        "UPDATE conversations SET title = ?, updated_at = ? WHERE id = ?",
        (title, _now_iso(), conv_id),
    )
    conn.commit()
    success = cur.rowcount > 0
    conn.close()
    return success


def add_message(conv_id: str, message: dict):
    """
    Append a message to a conversation and persist to DB.

    The message is JSON-serialized with default=str for safety.
    ``retrieval_results`` is stripped (large internal pipeline data).
    If this is the first user message, the conversation title is auto-set.
    """
    conn = _get_conn()

    # Verify conversation exists
    row = conn.execute("SELECT id, title FROM conversations WHERE id = ?", (conv_id,)).fetchone()
    if row is None:
        conn.close()
        return

    # Clean and serialize the message
    clean = _clean_message(message)
    content_json = json.dumps(clean, ensure_ascii=False, default=str)
    role = clean.get("role", "assistant")
    now = _now_iso()

    conn.execute(
        "INSERT INTO messages (conv_id, role, content, created_at) VALUES (?, ?, ?, ?)",
        (conv_id, role, content_json, now),
    )

    # Auto-title from first user message
    if role == "user" and (row["title"] in (None, "", "New Chat")):
        text = clean.get("content", "")
        title = text[:50] + ("..." if len(text) > 50 else "")
        conn.execute(
            "UPDATE conversations SET title = ?, updated_at = ? WHERE id = ?",
            (title, now, conv_id),
        )
    else:
        conn.execute("UPDATE conversations SET updated_at = ? WHERE id = ?", (now, conv_id))

    conn.commit()
    conn.close()


def get_messages(conv_id: str) -> list:
    """Return the deserialized message list for a conversation."""
    conn = _get_conn()
    rows = conn.execute(
        "SELECT content FROM messages WHERE conv_id = ? ORDER BY id ASC",
        (conv_id,),
    ).fetchall()
    conn.close()

    messages = []
    for r in rows:
        try:
            messages.append(json.loads(r["content"]))
        except (json.JSONDecodeError, TypeError):
            continue
    return messages


def get_message_count(conv_id: str) -> int:
    """Return the number of messages in a conversation."""
    conn = _get_conn()
    row = conn.execute(
        "SELECT count(*) AS cnt FROM messages WHERE conv_id = ?",
        (conv_id,),
    ).fetchone()
    conn.close()
    return row["cnt"] if row else 0


def update_message(conv_id: str, msg_index: int, message: dict) -> bool:
    """
    Update an existing message by its 0-based index in the conversation.

    Used by the verify-then-run flow: when the user approves/rejects SQL,
    the message's status, SQL, and query_result are updated in place.

    Returns True if the message was found and updated.
    """
    conn = _get_conn()
    rows = conn.execute(
        "SELECT id FROM messages WHERE conv_id = ? ORDER BY id ASC",
        (conv_id,),
    ).fetchall()
    if msg_index < 0 or msg_index >= len(rows):
        conn.close()
        return False
    db_id = rows[msg_index]["id"]
    clean = _clean_message(message)
    content_json = json.dumps(clean, ensure_ascii=False, default=str)
    now = _now_iso()
    conn.execute(
        "UPDATE messages SET content = ? WHERE id = ?",
        (content_json, db_id),
    )
    conn.execute("UPDATE conversations SET updated_at = ? WHERE id = ?", (now, conv_id))
    conn.commit()
    conn.close()
    return True
