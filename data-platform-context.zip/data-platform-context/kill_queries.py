#!/usr/bin/env python3
"""Check Trino for running queries and cancel orphaned ones."""
import requests, json

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"

# Get all queries
r = requests.get(f"{TRINO_URL}/v1/query", headers={"X-Trino-User": TRINO_USER}, timeout=15)
queries = r.json() if r.status_code == 200 else []

print(f"Total queries visible: {len(queries)}\n")

# Show running queries
running = [q for q in queries if q.get("state") in ("RUNNING", "QUEUED", "PLANNING", "STARTING")]
print(f"Running/Queued queries: {len(running)}\n")
for q in running:
    qid = q.get("queryId", "?")
    state = q.get("state", "?")
    sql = q.get("query", "")[:120]
    elapsed = q.get("queryStats", {}).get("elapsedTime", "?")
    print(f"  [{state}] {qid} ({elapsed})")
    print(f"    {sql}")
    print()

# Cancel all running queries
print("=" * 60)
print("Canceling all running queries...")
for q in running:
    qid = q.get("queryId")
    if qid:
        try:
            cr = requests.delete(f"{TRINO_URL}/v1/query/{qid}", headers={"X-Trino-User": TRINO_USER}, timeout=10)
            print(f"  {qid}: cancel status={cr.status_code}")
        except Exception as e:
            print(f"  {qid}: cancel error={e}")

print("\nDone. Now retry your query.")
