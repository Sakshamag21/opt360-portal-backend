# Trino Table Context Layer — `strot.mysql_uid_v2.uid_his_master`

> Context layer for text-to-SQL. Catalog: `strot` · Schema: `mysql_uid_v2` · Table: `uid_his_master`
>
> **History table for `uid_master`.** When a UID's details are updated in `uid_master`, the previous version of that row is inserted here. Each row represents a historical snapshot of a UID record. A single UID can have multiple history rows.

## Quick Facts

| Property | Value |
|----------|-------|
| Full table reference | `strot.mysql_uid_v2.uid_his_master` |
| Approximate row count | **2,874,468,722** (~2.87 billion) |
| Column count | 28 |
| Distinct UIDs | ~1,039,629,842 (~1.04 billion) |
| Avg history rows per UID | ~2.77 |
| Source connector | MySQL , exposed via Trino |
| Data date range | 2017-08-17 → 2026-10-09 (active, updated daily) |
| Read host | `10.10.116.39` |
| Write hosts | `10.10.116.75`, `10.10.118.10` |

> ⚠️ **Very large table (~2.87B rows).** Always use `LIMIT`, `shard_hint` for partition pruning, or date/uid predicates. Avoid `SELECT *` without a limit.

### Differences from `uid_master`

| Change | Detail |
|--------|--------|
| **Added column** | `eid` (varchar) — Enrolment ID for this enrolment/update event |
| **Removed columns** | `isforeigner`, `nationality_code`, `uid_expiry_date` — not tracked in history |
| **PK column** | `uid_his_key` (bigint) replaces `uid_master_key` |
| **Higher NULL rates** | Many columns have significantly more NULLs than `uid_master` (historical snapshots may be incomplete) |
| **'N' values** | Several flag columns contain `'N'` alongside `'0'`/`'1'`/`NULL` — legacy placeholder values |
| `res_dod` | Entirely NULL in this table (date of death is only on the current record in `uid_master`) |
| `issue_date` range | Narrower (2024-07-22 → 2026-07-21) — only recent issues generate history |

---

## Column Dictionary

| # | Column | Type | Description | Notes | Importance Based on Usage |
|---|--------|------|-------------|-------|---------------------------|
| 1 | `uid_his_key` | bigint | Surrogate primary key for history table | Range `1`–`36,158,940`. **Not contiguous** (2.87B rows vs 36M max key). Useful for sampling with `WHERE uid_his_key <= N`. | Low |
| 2 | `uid` | varchar | Encrypted UID (Aadhaar number) | Base64-like encrypted blob. **Never** store/return in plaintext. PII. Same encryption as `uid_master.uid`. Can be used to join history rows to the current record in `uid_master`. | High |
| 3 | `eid` | varchar | Enrolment ID for this enrolment/update event | Long numeric string (e.g. `2010108180018720151027110632`). Encodes enrolment metadata. Mostly unique per row (max ~4 duplicates). **Not present in `uid_master`.** | High |
| 4 | `uid_status_key` | integer | Status code of the UID at time of history snapshot | Mostly `NULL` (87.8%); `1` = active (12.0%). See [uid_status_key codes](#uid_status_key). | Low |
| 5 | `res_dob_year` | varchar | Year of birth of resident | Stored as text. Range `0`–`2096`; ~52.6% NULL. Cast with `CAST(res_dob_year AS integer)` / `TRY_CAST` when filtering. The dob year greater than the current year is wrong or anomalous. | High |
| 6 | `res_guardian_uid` | varchar | Encrypted UID of guardian, mostly available for child enrolment or Head of Family enrolment | Mostly `NULL` for adults. PII (encrypted). Same semantics as `uid_master`. | Medium |
| 7 | `res_guardian_eid` | varchar | Encrypted enrolment ID of guardian | Mostly `NULL`. PII (encrypted). | Low |
| 8 | `res_mobile_num_hash` | varchar | SHA-256 hash of resident's mobile number | Hex string (64 chars). PII (hashed). Higher NULL rate than `uid_master`. | Low |
| 9 | `res_email_id_hash` | varchar | SHA-256 hash of resident's email ID | Hex string (64 chars). Largely `NULL`. PII (hashed). | Low |
| 10 | `bnk_shre_cnsnt` | varchar | Bank-share consent flag | **Almost entirely NULL** (99.99%). Tiny `'N'` values (321,938). Deprecated column. | Low |
| 11 | `info_shre_cnsnt` | varchar | Info-share consent flag | `'1'` = consented (85.6%), `'0'` = not consented (13.9%), `NULL` (0.5%), `'N'` (legacy). | Low |
| 12 | `verification_type` | varchar | Type of demographic verification | `'D'` = demographic (51.7%), `NULL` (42.9%), `'H'` = head-of-family (5.4%), `'I'` = iris, `'N'` (legacy). See [verification_type](#verification_type). | Medium |
| 13 | `poi` | varchar | Proof of Identity document submitted | Free-text document name. `NULL` for ~59.2%. See [poi](#poi). | High |
| 14 | `poa` | varchar | Proof of Address document submitted | Free-text document name. `NULL` for ~53.8%. See [poa](#poa). | High |
| 15 | `pob` | varchar | Proof of Date of Birth document submitted | Free-text document name. `NULL` for ~91.7% (DOB proof is optional). See [pob](#pob). | High |
| 16 | `hof_proof` | varchar | Head-of-Family relationship proof | Free-text. `NULL` for ~94.6% (only for HoF-linked enrolments). | Medium |
| 17 | `other_proof` | varchar | Other supporting proof | **Entirely NULL** (deprecated column). | Low |
| 18 | `res_lang_code` | varchar | Language code of resident's preferred language | Numeric-string code. `NULL` for ~6.6%. No official mapping available — ask the user about the mapping while using this column. See [res_lang_code](#res_lang_code). | Medium |
| 19 | `biometric_flag` | varchar | Whether biometrics were captured | `'1'` = yes (31.9%), `'0'` = no (6.9%), `NULL` (61.2%), `'N'` (legacy). | Medium |
| 20 | `biometric_exception_ind` | boolean | Biometric exception indicator | `NULL` (99.6%), `true` = exception (0.3%), `false` = no exception (0.02%). | Low |
| 21 | `isnri` | varchar | Is Non-Resident Indian flag | `NULL` (69.1%), `'0'` = no (30.9%), `'1'` = yes (~10k), `'N'` (legacy). | Medium |
| 22 | `res_dod` | timestamp(6) | Date of death of resident | **Entirely NULL** in history table. Date of death is only on the current record in `uid_master`. | Low |
| 23 | `issue_date` | timestamp(6) | Date the UID was issued | Range 2024-07-22 → 2026-07-21. Narrower than `uid_master` — only recent issues generate history. | High |
| 24 | `created_by` | varchar | Source/creator of the record | Typically `enrolserver`. | Low |
| 25 | `creation_date` | timestamp(6) | Record creation timestamp | Range 2017-08-17 → 2026-10-09. | Medium |
| 26 | `last_updated_by` | varchar | Last updater | Typically `enrolserver`. | Medium |
| 27 | `last_updated_date` | timestamp(6) | Last update timestamp | Range 2017-08-17 → 2026-10-09. | High |
| 28 | `shard_hint` | varchar | Sharding hint, basically first 2 digits of every Aadhaar number/UID, used for efficient querying as the MySQL sharding is done based on this | E.g. `'69'`, `'99'`, `'72'`. Use for partition pruning / faster queries. | High |

---

## Categorical Value Mappings

### uid_status_key

| Code | Count | % | Meaning (inferred) |
|------|-------|---|--------------------|
| NULL | 2,526,226,636 | 87.8% | Not set (historical snapshot) |
| 1 | 344,596,878 | 12.0% | Active / Issued |
| 8 | 3,341,485 | 0.1% | — |
| 0 | 298,685 | <0.1% | — |
| 3 | 1,782 | <0.1% | — |
| 34 | 1,346 | <0.1% | — |
| 99 | 632 | <0.1% | Deactivated / Cancelled |
| 33 | 631 | <0.1% | — |
| 9 | 313 | <0.1% | — |
| 28 | 189 | <0.1% | — |
| 4 | 94 | <0.1% | — |
| 51 | 49 | <0.1% | — |
| 7 | 2 | <0.1% | — |

> Codes `1` (active) and `99` (deactivated) are the most semantically useful. Most history rows have `NULL` status — the status was not always captured in historical snapshots.

### verification_type

| Code | Count | % | Meaning |
|------|-------|---|---------|
| `D` | 1,484,968,990 | 51.7% | Demographic verification (document-based) |
| `NULL` | 1,233,167,723 | 42.9% | Unspecified |
| `H` | 154,714,442 | 5.4% | Head-of-Family / biometric-based verification |
| `I` | 1,500,580 | <0.1% | - |
| `N` | 116,987 | <0.1% | - |

### info_shre_cnsnt
- `'1'` (2,460,045,849) = consented
- `'0'` (400,645,082) = not consented
- `NULL` (13,775,949) = unspecified
- `'N'` (1,842) = legacy placeholder

### biometric_flag
- `'1'` (916,068,729) = biometrics captured
- `'0'` (197,885,362) = biometrics not captured
- `NULL` (1,760,324,233) = not applicable/unspecified
- `'N'` (190,398) = legacy placeholder

### biometric_exception_ind
- `NULL` (2,864,042,842) = not applicable (99.6%)
- `true` (9,990,121) = biometric exception (0.3%)
- `false` (435,759) = no exception (0.02%)

### isnri
- `NULL` (1,986,841,996) = unspecified (69.1%)
- `'0'` (887,435,227) = not NRI (30.9%)
- `'N'` (181,383) = legacy placeholder
- `'1'` (10,116) = NRI

### res_lang_code

No official Mapping Available, ask the user about the mapping while using this column

| Code | Count |
|------|-------|
| `06` | 1,207,450,024 |
| `23` | 261,317,672 |
| `21` | 248,486,475 |
| `13` | 219,702,594 |
| `NULL` | 190,571,220 |
| `20` | 164,851,457 |
| `07` | 152,567,068 |
| `05` | 122,542,023 |
| `02` | 120,958,489 |
| `15` | 85,423,887 |
| `16` | 53,590,616 |
| `11`, `22`, `01`, `14`, `09`, `12` | smaller |

> A few rows contain Devanagari-digit variants (e.g. `०६`, `२१`) and literal string `'NULL'` (8,021 rows) — data-quality artifacts. Normalize with `CAST` or `REPLACE` if grouping is needed.

### eid
Enrolment ID — long numeric string encoding enrolment metadata (e.g. `2010108180018720151027110632`). Mostly unique per history row; a small number of EIDs appear up to 4 times (multiple updates within the same enrolment). Value `'0'` (5 rows) is a placeholder.

### poi (Proof of Identity) — top values
Voter ID, NPR Process, Ration/PDS Photo Card, Photo ID by Educational Institution, PAN Card, Certificate of Identity (various issuers), Passport, Driving License, etc. `NULL` for ~59.2%. **Free-text** — exact phrasing varies; prefer `LIKE` matching.

### poa (Proof of Address) — top values
Ration Card, Voter ID, NPR Process, Certificate of Address (Village Panchayat), Signed Letter by Educational Institution, Electricity Bill, Bank Statement/Passbook, Passport, Driving License, etc. `NULL` for ~53.8%. **Free-text**.

### pob (Proof of Date of Birth) — top values
Birth Certificate, PAN Card, Marksheet (Govt Board/University), SSLC Book/Certificate, Passport, School Leaving Certificate, etc. `NULL` for ~91.7% (DOB proof is optional). **Free-text**.

---

## Date Ranges

| Column | Min | Max |
|--------|-----|-----|
| `issue_date` | 2024-07-22 06:36:39 | 2026-07-21 17:05:34 |
| `creation_date` | 2017-08-17 15:09:31 | 2026-10-09 01:15:16 |
| `last_updated_date` | 2017-08-17 15:09:48 | 2026-10-09 01:15:16 |
| `res_dod` | — (entirely NULL) | — (entirely NULL) |

---

## Sample Row (anonymized shape)

```
uid_his_key      : 33858369
uid              : <encrypted base64 blob>
eid              : '2010108180018720151027110632'
uid_status_key   : NULL
res_dob_year     : '1986'
res_guardian_uid : NULL
res_mobile_num_hash : NULL
info_shre_cnsnt  : '1'
verification_type: 'D'
poi              : 'NPR Process'
poa              : 'NPR Process'
res_lang_code    : '02'
biometric_flag   : NULL
isnri            : NULL
issue_date       : NULL
created_by       : 'enrolserver'
creation_date    : 2026-05-22 17:20:11
last_updated_by  : 'enrolserver'
last_updated_date: 2026-05-22 17:20:11
shard_hint       : '99'
```

---

## Querying Guidance/ Rules (text-to-SQL)

1. **Always scope queries.** With ~2.87B rows, prefer:
   - `LIMIT N`
   - Use `shard_hint` for faster partition pruning
   - Date filters on `creation_date` / `last_updated_date`
   - `uid` filters when looking up history for a specific resident
2. **Avoid full-table aggregations** without a predicate; they scan the entire table.
3. **Free-text columns** (`poi`, `poa`, `pob`, `hof_proof`) use inconsistent phrasing — use `LIKE '%keyword%'` and `LOWER()`.
4. **Type casting:** `res_dob_year` is `varchar` — cast to integer for numeric comparisons. Use `TRY_CAST` to avoid errors on non-numeric values. Values greater than the current year are wrong or anomalous.
5. **PII handling:** `uid`, `res_guardian_uid`, `res_guardian_eid` are encrypted; `res_mobile_num_hash`, `res_email_id_hash` are hashed. Never attempt decryption in SQL.
6. **Deprecated/empty columns:** `bnk_shre_cnsnt`, `other_proof`, and `res_dod` are entirely NULL — do not rely on them.
7. **'N' values:** Several flag columns (`info_shre_cnsnt`, `biometric_flag`, `isnri`, `verification_type`) contain `'N'` as a legacy placeholder. Filter these out if only valid `'0'`/`'1'` values are needed.
8. **History semantics:** Each row is a previous version of a UID record. To get the full update history for a resident, filter by `uid`. To get the current version, query `uid_master` instead. Average ~2.77 history rows per UID.
9. **`eid` column:** Unique to this table (not in `uid_master`). Represents the enrolment ID for the update event that created this history row.
10. **Read vs write:** run `SELECT` on read host `10.10.116.39`; No write is allowed on this table.
11. **Priority:** the importance is defined in the column dictionary, mostly problems are solved with High and Medium priority columns.
