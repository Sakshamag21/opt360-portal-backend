#!/usr/bin/env python3
"""
Clean GraphRAG Retriever — entity-specific documents + BM25 scoring.

Two design principles:
  1. CLEAN DOCUMENTS: Each document contains ONLY information about that entity.
     - Column doc  = column name + column description + column notes + enriched questions
     - Table doc   = table name + table description + table warning
     - Concept doc = concept name + concept description
     - Community doc = community title + community summary + query examples

     Relationships (which column belongs to which table, which tables join, etc.)
     are NOT in the document text — they're navigated via graph edges (HAS_COLUMN,
     JOINS_TO, HAS_CONCEPT) during graph expansion.

  2. BM25 SCORING: Uses Okapi BM25 instead of TF-IDF for Stage 1 retrieval.
     - TF saturation prevents high-frequency terms from dominating
     - Document length normalization is more principled than L2 norm
     - Industry-standard ranking (used by Elasticsearch, Lucene, etc.)

This eliminates the ~30-50% term overlap between table docs and their column docs
that plagued the original TF-IDF implementation.
"""

import sys
import json
import re
import math
import textwrap
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np

# Reuse tokenizer, synonyms from original
from graph_rag_vector_retriever import (
    INDEX_PATH, STOPWORDS, SYNONYM_GROUPS, SYNONYM_MAP,
    tokenize, expand_synonyms,
)
from bm25_retriever import BM25Vectorizer


class CleanGraphRAG:
    """
    GraphRAG retriever with clean entity-specific documents + BM25 scoring.

    Same interface as VectorGraphRAG — drop-in replacement.
    Key differences from the original:
      1. Document text contains ONLY entity-specific information (no cross-entity leakage)
      2. BM25 scoring instead of TF-IDF (term saturation + length normalization)
    Relationships are handled by graph edges, not document text.
    """

    def __init__(self, index_path=INDEX_PATH, k1=1.2, b=0.75):
        """
        Args:
            index_path: Path to graph_rag_index.json
            k1: BM25 term frequency saturation parameter (1.2 is standard)
            b:  BM25 document length normalization parameter (0.75 is standard)
        """
        with open(index_path, "r", encoding="utf-8") as f:
            self.index = json.load(f)

        # Build lookup maps
        self.entity_map = {e["entity_id"]: e for e in self.index["entities"]}

        # Build adjacency
        self.outgoing = defaultdict(list)
        self.incoming = defaultdict(list)
        for rel in self.index["relationships"]:
            self.outgoing[rel["source"]].append(rel)
            self.incoming[rel["target"]].append(rel)

        # Build text units lookup
        self.text_units_by_entity = defaultdict(list)
        for tu in self.index["text_units"]:
            self.text_units_by_entity[tu["entity_id"]].append(tu)

        # ─── KEY DIFFERENCE 1: Build CLEAN documents ────────────
        # Each document contains ONLY entity-specific information.
        # NO community titles, NO table name in column docs, NO cross-entity properties.
        documents = []
        for entity in self.index["entities"]:
            eid = entity["entity_id"]
            doc_text = self._build_clean_doc(entity)
            documents.append((eid, doc_text))

        # Community docs: title + summary + query examples only
        for comm in self.index["communities"]:
            doc_text = f"{comm['title']} {comm['summary']} {' '.join(comm.get('query_examples', []))}"
            documents.append((comm["community_id"], doc_text))

        # ─── KEY DIFFERENCE 2: BM25 index instead of TF-IDF ─────
        self.vectorizer = BM25Vectorizer(k1=k1, b=b)
        self.vectorizer.fit(documents)

        # Store query paths
        self.query_paths = self.index.get("query_paths", [])

    def _build_clean_doc(self, entity):
        """
        Build a document containing ONLY entity-specific information.

        - NO community titles (that's a relationship, handled by graph)
        - NO parent table name in column docs (that's a relationship)
        - NO generic property keys like "table", "importance" (these create noise)
        - YES: name, description, entity-specific notes, enriched questions
        """
        etype = entity.get("type", "")
        name = entity.get("name", "")
        desc = entity.get("description", "")
        props = entity.get("properties", {})
        eid = entity["entity_id"]

        parts = []

        if etype == "COLUMN":
            # Column doc = column name (last part only, not table.column) 
            #              + description + data type + notes + enriched questions
            # Strip the table prefix: "uid_master.res_dod" → "res_dod"
            col_name = name.split(".")[-1] if "." in name else name
            parts.append(col_name)
            parts.append(desc)

            # Only include entity-specific properties (not relational ones)
            if props.get("data_type"):
                parts.append(props["data_type"])
            if props.get("notes"):
                parts.append(props["notes"])

            # Enriched text units (natural-language questions) — these ARE entity-specific
            for tu in self.text_units_by_entity.get(eid, []):
                parts.append(tu["text"])

            # DO NOT add: community title, table name, importance, full_reference

        elif etype == "TABLE":
            # Table doc = table name + description + warning + row count
            parts.append(name)
            parts.append(desc)

            if props.get("warning"):
                parts.append(props["warning"])
            if props.get("row_count"):
                parts.append(f"approximately {props['row_count']} rows")
            if props.get("column_count"):
                parts.append(f"{props['column_count']} columns")

            # Enriched text units for the table (if any)
            for tu in self.text_units_by_entity.get(eid, []):
                parts.append(tu["text"])

            # DO NOT add: community title, all column names, full_reference, host info

        elif etype == "CONCEPT":
            # Concept doc = concept name + description only
            parts.append(name)
            parts.append(desc)

            # Enriched text units
            for tu in self.text_units_by_entity.get(eid, []):
                parts.append(tu["text"])

        elif etype == "DATA_QUALITY_ISSUE":
            # DQ issue doc = name + description + affected columns
            parts.append(name)
            parts.append(desc)
            if props.get("affected_columns"):
                parts.append(" ".join(props["affected_columns"]))

        elif etype == "JOIN_KEY":
            # Join key doc = name + description
            parts.append(name)
            parts.append(desc)

        elif etype == "HOST":
            # Host doc = minimal info
            parts.append(name)
            parts.append(desc)

        else:
            # Fallback: name + description
            parts.append(name)
            parts.append(desc)

        return " ".join(parts)

    # ─── Search methods (identical to VectorGraphRAG) ─────────────

    def search(self, query, mode="hybrid", top_k=10, use_llm_rerank=False, llm_top_k=5):
        """Same interface as VectorGraphRAG.search()"""
        result = {"query": query, "mode": mode}

        if mode in ("global", "hybrid"):
            result["global_results"] = self._global_search(query, top_k=3)

        if mode in ("local", "hybrid"):
            bm25_results = self._local_search(query, top_k=top_k * 3 if use_llm_rerank else top_k)

            if use_llm_rerank and bm25_results:
                try:
                    from llm_client import LLMClient
                    llm = LLMClient()

                    candidates = bm25_results[:llm_top_k]
                    candidate_texts = []
                    for c in candidates:
                        desc = c.get("description", "")[:150]
                        name = c.get("name", "")
                        etype = c.get("type", "")
                        candidate_texts.append({
                            "name": name,
                            "text": f"[{etype}] {name}: {desc}",
                            "_original": c,
                        })

                    ranked = llm.rerank(query, candidate_texts)

                    reranked = []
                    for item in ranked:
                        original = item.get("_original", {})
                        original["bm25_score"] = original.pop("score", 0)
                        original["llm_score"] = item.get("llm_score", 0)
                        original["llm_rank"] = item.get("llm_rank", 0)
                        original["score"] = item.get("llm_score", 0) / 10.0
                        reranked.append(original)

                    reranked_ids = {r["entity_id"] for r in reranked}
                    for r in bm25_results:
                        if r["entity_id"] not in reranked_ids:
                            r["bm25_score"] = r.pop("score", 0)
                            r["llm_score"] = 0
                            r["llm_rank"] = 0
                            reranked.append(r)

                    result["local_results"] = reranked[:top_k]
                    result["llm_reranked"] = True
                except Exception as e:
                    result["local_results"] = bm25_results[:top_k]
                    result["llm_reranked"] = False
                    result["llm_error"] = str(e)
            else:
                result["local_results"] = bm25_results[:top_k]
                result["llm_reranked"] = False

        if mode == "hybrid":
            local_communities = set()
            for lr in result.get("local_results", []):
                eid = lr["entity_id"]
                for comm in self.index["communities"]:
                    if eid in comm.get("entity_ids", []):
                        local_communities.add(comm["community_id"])
            result["local_community_ids"] = list(local_communities)

        return result

    def _global_search(self, query, top_k=3):
        results = self.vectorizer.search(query, top_k=20)

        comm_results = []
        for doc_id, score in results:
            if doc_id.startswith("C"):
                comm = next((c for c in self.index["communities"] if c["community_id"] == doc_id), None)
                if comm:
                    comm_results.append((score, comm))

        comm_results.sort(key=lambda x: x[0], reverse=True)

        return [{
            "community_id": comm["community_id"],
            "title": comm["title"],
            "score": round(score, 4),
            "summary": comm["summary"],
            "entity_count": comm["entity_count"],
            "key_relationships": comm.get("key_relationships", []),
            "query_examples": comm.get("query_examples", []),
        } for score, comm in comm_results[:top_k]]

    def _local_search(self, query, top_k=10):
        results = self.vectorizer.search(query, top_k=30)

        entity_results = []
        for doc_id, score in results:
            if doc_id.startswith("E") and doc_id in self.entity_map:
                entity = self.entity_map[doc_id]
                entity_results.append((score, entity))

        output = []
        seen = set()
        for score, entity in entity_results[:top_k]:
            eid = entity["entity_id"]
            if eid in seen:
                continue
            seen.add(eid)

            neighbors = []
            for rel in self.outgoing.get(eid, []):
                target = self.entity_map.get(rel["target"])
                if target and target["entity_id"] not in seen:
                    neighbors.append({
                        "entity_id": target["entity_id"],
                        "name": target["name"],
                        "type": target["type"],
                        "relationship": rel["type"],
                        "description": rel["description"],
                    })
            for rel in self.incoming.get(eid, []):
                source = self.entity_map.get(rel["source"])
                if source and source["entity_id"] not in seen:
                    neighbors.append({
                        "entity_id": source["entity_id"],
                        "name": source["name"],
                        "type": source["type"],
                        "relationship": rel["type"],
                        "description": rel["description"],
                    })

            matched_texts = [tu["text"][:150] for tu in self.text_units_by_entity.get(eid, [])[:2]]

            output.append({
                "entity_id": eid,
                "name": entity["name"],
                "type": entity["type"],
                "score": round(score, 4),
                "description": entity.get("description", ""),
                "properties": entity.get("properties", {}),
                "matched_texts": matched_texts,
                "neighbors": neighbors[:15],
            })
        return output

    def get_table_context(self, table_name):
        """Same as VectorGraphRAG.get_table_context()"""
        table_name = table_name.lower()
        eid = None
        for e in self.index["entities"]:
            if e["type"] == "TABLE" and e["name"].lower() == table_name:
                eid = e["entity_id"]
                entity = e
                break
        if not eid:
            return None

        columns = []
        joins = []
        for rel in self.outgoing.get(eid, []):
            target = self.entity_map.get(rel["target"])
            if target and target["type"] == "COLUMN":
                columns.append({
                    "name": target["name"],
                    "description": target.get("description", ""),
                    "properties": target.get("properties", {}),
                })
            elif target and target["type"] == "TABLE":
                joins.append({
                    "target_table": target["name"],
                    "relationship": rel["type"],
                    "description": rel["description"],
                    "properties": rel.get("properties", {}),
                })

        community = None
        for comm in self.index["communities"]:
            if eid in comm.get("entity_ids", []):
                community = {"id": comm["community_id"], "title": comm["title"]}
                break

        return {
            "table": entity["name"],
            "description": entity.get("description", ""),
            "properties": entity.get("properties", {}),
            "columns": columns,
            "joins": joins,
            "community": community,
        }

    def get_join_path(self, from_table, to_table):
        """Same as VectorGraphRAG.get_join_path()"""
        from_table = from_table.lower()
        to_table = to_table.lower()

        from_eid = None
        to_eid = None
        for e in self.index["entities"]:
            if e["type"] == "TABLE":
                if e["name"].lower() == from_table:
                    from_eid = e["entity_id"]
                if e["name"].lower() == to_table:
                    to_eid = e["entity_id"]

        if not from_eid or not to_eid:
            return None

        for rel in self.outgoing.get(from_eid, []):
            if rel["target"] == to_eid and rel["type"] == "JOINS_TO":
                return {
                    "from": from_table, "to": to_table, "direct": True,
                    "join_keys": rel.get("properties", {}).get("join_keys", []),
                    "cardinality": rel.get("properties", {}).get("cardinality", ""),
                    "description": rel["description"],
                }
        for rel in self.outgoing.get(to_eid, []):
            if rel["target"] == from_eid and rel["type"] == "JOINS_TO":
                return {
                    "from": from_table, "to": to_table, "direct": True,
                    "join_keys": rel.get("properties", {}).get("join_keys", []),
                    "cardinality": rel.get("properties", {}).get("cardinality", ""),
                    "description": rel["description"],
                }

        for qp in self.query_paths:
            if qp.get("start", "").lower() == from_table:
                for j in qp.get("joins", []):
                    if j.get("to", "").lower() == to_table:
                        return {"from": from_table, "to": to_table, "direct": False,
                                "join_keys": j.get("on", []), "via_query_path": qp.get("need", "")}

        return {"from": from_table, "to": to_table, "direct": False, "join_keys": [],
                "note": "No direct join found. Use uid and shard_hint as common keys."}

    def debug_doc(self, entity_name):
        """Show the clean document text for a specific entity."""
        for e in self.index["entities"]:
            if e["name"] == entity_name:
                doc = self._build_clean_doc(e)
                tokens = tokenize(doc)
                return {
                    "entity": entity_name,
                    "type": e.get("type", ""),
                    "doc_text": doc,
                    "doc_tokens": sorted(set(tokens)),
                    "n_tokens": len(set(tokens)),
                }
        return None
