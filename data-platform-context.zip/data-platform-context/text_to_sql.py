#!/usr/bin/env python3
"""
Text-to-SQL Pipeline — GraphRAG + GLM-5.2-FP8

Full flow:
  1. User asks a natural language question
  2. GraphRAG retrieves relevant context (tables, columns, joins, data quality)
     - Stage 1: BM25 search on clean entity-specific documents (fast, <100ms)
     - Stage 2: LLM re-ranking (optional, 3-8s, higher precision)
  3. Context is assembled into a structured prompt
  4. LLM generates a Trino SQL query
  5. EXPLAIN validates the SQL (optional)
  6. Query executes against Trino (optional)

Usage:
  # Interactive mode
  python text_to_sql.py

  # Single query
  python text_to_sql.py "find residents who died in 2024"

  # With LLM re-ranking + execution
  python text_to_sql.py "find residents who died in 2024" --rerank --execute
"""

import sys
import io
import json
import time
import argparse
from pathlib import Path

# Ensure we can import from the context directory
sys.path.insert(0, str(Path(__file__).parent))

from postgres_retriever import PostgresGraphRAG
from clean_retriever import CleanGraphRAG
from llm_client import LLMClient
from intent_classifier import IntentClassifier
from metadata_handler import MetadataHandler


class TextToSQL:
    """
    Orchestrates the full text-to-SQL pipeline:
    Question → Intent Classification → (Metadata answer | GraphRAG retrieval → SQL generation → Execute)

    Intents:
      METADATA        — answered directly from the graph (no SQL)
      SEMANTIC_SEARCH — FTS search on the graph (no SQL)
      DATA_QUERY      — full SQL pipeline
      HYBRID          — metadata + SQL

    Retrieval: PostgresGraphRAG (PostgreSQL full-text search + graph joins)
    Fallback: CleanGraphRAG (JSON + BM25) if PostgreSQL is unavailable
    """

    def __init__(self, use_llm_rerank=True, verbose=True):
        """
        Args:
            use_llm_rerank: Use LLM to re-rank GraphRAG results (slower but more accurate)
            verbose: Print progress at each step
        """
        # Try PostgreSQL first, fall back to JSON+BM25
        try:
            self.retriever = PostgresGraphRAG()
            self.retriever_type = "postgres"
        except RuntimeError:
            if verbose:
                print("  ⚠ PostgreSQL unavailable, falling back to JSON+BM25")
            self.retriever = CleanGraphRAG()
            self.retriever_type = "json_bm25"
        self.llm = LLMClient()
        self.use_llm_rerank = use_llm_rerank
        self.verbose = verbose

        # Intent classifier + metadata handler
        self.classifier = IntentClassifier(use_llm=True, verbose=verbose)
        self.metadata_handler = MetadataHandler(verbose=verbose)

    def log(self, msg):
        if self.verbose:
            print(msg)

    def generate(self, question, execute=False, explain=False):
        """
        Full pipeline: question → SQL (→ results).

        Args:
            question: Natural language question
            execute: If True, execute the SQL against Trino
            explain: If True, run EXPLAIN before executing

        Returns:
            dict with keys: question, context, sql, explain_result, query_result, elapsed
        """
        result = {
            "question": question,
            "intent": None,
            "sql": None,
            "context": None,
            "explain_result": None,
            "query_result": None,
            "metadata_answer": None,
            "elapsed": 0,
        }

        total_start = time.time()

        # ─── STEP 0: Intent Classification ──────────────────────────
        self.log("\n━━━ STEP 0: INTENT CLASSIFICATION ━━━")

        classification = self.classifier.classify(question)
        intent = classification["intent"]
        result["intent"] = intent
        result["intent_details"] = classification

        # ─── Route based on intent ──────────────────────────────────
        if intent in ("METADATA", "SEMANTIC_SEARCH"):
            # Answer directly from the graph — no SQL generation needed
            self.log(f"\n━━━ METADATA/SEMANTIC HANDLER (no SQL needed) ━━━")

            meta_result = self.metadata_handler.handle(question, intent)
            result["metadata_answer"] = meta_result["answer"]
            result["metadata_data"] = meta_result.get("data", {})
            result["elapsed"] = round(time.time() - total_start, 2)

            self.log(f"\n━━━ DONE ({result['elapsed']}s) — answered from graph ━━━")
            return result

        # For DATA_QUERY and HYBRID, continue to SQL generation
        # (HYBRID will also get metadata alongside)

        # ─── STEP 1: GraphRAG Retrieval ─────────────────────────────
        self.log("\n━━━ STEP 1: GraphRAG RETRIEVAL ━━━")

        if self.use_llm_rerank:
            self.log(f"  Stage 1: PostgreSQL full-text search ({self.retriever_type})...")
            self.log("  Stage 2: LLM re-ranking...")
        else:
            self.log(f"  PostgreSQL full-text search ({self.retriever_type}, no LLM re-rank)...")

        rag_start = time.time()
        rag_results = self.retriever.search(
            question,
            mode="hybrid",
            top_k=15,
            use_llm_rerank=self.use_llm_rerank,
            llm_top_k=10,
        )
        rag_elapsed = time.time() - rag_start

        local_results = rag_results.get("local_results", [])
        global_results = rag_results.get("global_results", [])

        self.log(f"  Found {len(local_results)} entities, {len(global_results)} communities ({rag_elapsed:.1f}s)")

        if self.use_llm_rerank and rag_results.get("llm_reranked"):
            self.log("  LLM re-ranking: ✅ applied")
        elif self.use_llm_rerank:
            self.log(f"  LLM re-ranking: ❌ failed ({rag_results.get('llm_error', 'unknown')})")

        # ─── STEP 2: Context Assembly ───────────────────────────────
        self.log("\n━━━ STEP 2: CONTEXT ASSEMBLY ━━━")

        context = self._assemble_context(question, rag_results)
        result["context"] = context

        self.log(f"  Assembled context ({len(context)} chars)")
        self.log(f"  Tables: {context.count('TABLE:')}  Columns: {context.count('COLUMN:')}  Joins: {context.count('JOIN:')}  Warnings: {context.count('WARNING:')}")

        # ─── STEP 3: LLM SQL Generation ─────────────────────────────
        self.log("\n━━━ STEP 3: LLM SQL GENERATION ━━━")

        sql_start = time.time()
        sql = self.llm.generate_sql(question, context, temperature=0.1)
        sql_elapsed = time.time() - sql_start

        # Clean up the SQL — Trino doesn't like trailing semicolons
        sql = sql.strip()
        if sql.endswith(";"):
            sql = sql[:-1].strip()

        # Add LIMIT if missing and it's a SELECT (not an aggregate with GROUP BY only)
        # For safety on billion-row tables, always ensure a LIMIT
        has_limit = "LIMIT" in sql.upper()
        has_group_by = "GROUP BY" in sql.upper()
        if not has_limit:
            sql = sql.rstrip() + "\nLIMIT 100"

        result["sql"] = sql
        self.log(f"  Generated SQL ({sql_elapsed:.1f}s):")
        for line in sql.split("\n"):
            self.log(f"    {line}")

        # ─── STEP 4: EXPLAIN (optional) ─────────────────────────────
        if explain:
            self.log("\n━━━ STEP 4: EXPLAIN VALIDATION ━━━")
            try:
                import strot_query as sq
                # Strip semicolons for Trino
                clean_sql = sql.rstrip(";").strip()
                explain_sql = f"EXPLAIN {clean_sql}"
                exp_result = sq.query(explain_sql, host="10.10.116.39")
                if exp_result.get("success"):
                    self.log("  ✅ EXPLAIN passed — SQL is valid")
                    result["explain_result"] = {"valid": True}
                else:
                    self.log(f"  ❌ EXPLAIN failed — SQL may be invalid")
                    result["explain_result"] = {"valid": False, "error": str(exp_result.get("data"))}
            except Exception as e:
                self.log(f"  ⚠️  EXPLAIN skipped: {e}")
                result["explain_result"] = {"valid": None, "error": str(e)}

        # ─── STEP 5: Execute (optional) ─────────────────────────────
        if execute:
            self.log("\n━━━ STEP 5: QUERY EXECUTION ━━━")
            try:
                import strot_query as sq
                exec_start = time.time()
                q_result = sq.query(sql, host="10.10.116.39")
                exec_elapsed = time.time() - exec_start

                if q_result.get("success"):
                    columns = q_result.get("data", [None])[0]
                    rows = q_result.get("data", [None, None])[1] if len(q_result.get("data", [])) > 1 else []
                    self.log(f"  ✅ Query executed ({exec_elapsed:.1f}s) — {len(rows)} rows returned")
                    self.log(f"  Columns: {columns}")
                    for i, row in enumerate(rows[:10]):
                        self.log(f"    Row {i+1}: {row}")
                    if len(rows) > 10:
                        self.log(f"    ... ({len(rows) - 10} more rows)")
                    result["query_result"] = {
                        "success": True,
                        "columns": columns,
                        "rows": rows,
                        "row_count": len(rows),
                        "elapsed": round(exec_elapsed, 2),
                    }
                else:
                    self.log(f"  ❌ Query failed: {q_result}")
                    result["query_result"] = {"success": False, "error": str(q_result)}
            except Exception as e:
                self.log(f"  ⚠️  Execution skipped: {e}")
                result["query_result"] = {"success": False, "error": str(e)}

        result["elapsed"] = round(time.time() - total_start, 2)
        self.log(f"\n━━━ DONE ({result['elapsed']}s) ━━━")

        return result

    def _assemble_context(self, question, rag_results):
        """
        Build a structured context string from GraphRAG results.

        Extracts:
        - Relevant tables (with full references, row counts, descriptions)
        - Relevant columns (with types, descriptions, importance)
        - Join paths between found tables
        - Data quality warnings
        - Example SQL from community reports
        """
        local_results = rag_results.get("local_results", [])
        global_results = rag_results.get("global_results", [])

        # ─── Collect tables ─────────────────────────────────────────
        tables_found = {}  # table_name → {entity, columns: []}
        columns_found = []
        warnings = []
        concepts_found = []
        dq_issues = []

        for r in local_results:
            etype = r.get("type", "")
            name = r.get("name", "")
            desc = r.get("description", "")
            props = r.get("properties", {})
            score = r.get("score", 0)

            if etype == "TABLE":
                tables_found[name] = {
                    "entity": r,
                    "full_ref": props.get("full_reference", name),
                    "row_count": props.get("row_count", 0),
                    "column_count": props.get("column_count", 0),
                    "warning": props.get("warning", ""),
                    "columns": [],
                }
                if props.get("warning"):
                    warnings.append(f"Table {name}: {props['warning']}")

            elif etype == "COLUMN":
                columns_found.append(r)
                # Extract table name from column name (format: table.column)
                if "." in name:
                    tbl = name.split(".", 1)[0]
                    if tbl not in tables_found:
                        # Column's table wasn't in top results — add it
                        tables_found[tbl] = {
                            "entity": None,
                            "full_ref": f"strot.mysql_uid_v2.{tbl}",
                            "row_count": 0,
                            "column_count": 0,
                            "warning": "",
                            "columns": [],
                        }
                    tables_found[tbl]["columns"].append(r)

            elif etype == "CONCEPT":
                concepts_found.append(r)

            elif etype == "DATA_QUALITY_ISSUE":
                dq_issues.append(r)

            elif etype == "QUERY_INSIGHT":
                # User-learned query pattern from feedback — treat as a warning/guidance
                props = r.get("properties", {})
                insight_text = f"LEARNED INSIGHT — {name}: {desc}"
                if props.get("correct_sql"):
                    insight_text += f"\n  Correct SQL pattern: {props['correct_sql'][:200]}"
                if props.get("key_columns"):
                    insight_text += f"\n  Key columns: {', '.join(props.get('key_columns', []))}"
                warnings.append(insight_text)

        # ─── Also get full column lists for found tables ────────────
        # Batch: get all table contexts in ONE query
        table_names_list = list(tables_found.keys())
        if table_names_list:
            batch_ctx = self.retriever.get_table_contexts_batch(table_names_list)
            for tbl_name, tbl_info in tables_found.items():
                ctx = batch_ctx.get(tbl_name)
                if ctx:
                    tbl_info["full_ref"] = ctx.get("properties", {}).get("full_reference", tbl_info["full_ref"])
                    tbl_info["row_count"] = ctx.get("properties", {}).get("row_count", tbl_info["row_count"])
                    tbl_info["column_count"] = ctx.get("properties", {}).get("column_count", tbl_info["column_count"])
                    tbl_info["warning"] = ctx.get("properties", {}).get("warning", tbl_info["warning"])
                    tbl_info["all_columns"] = ctx.get("columns", [])
                    tbl_info["joins"] = ctx.get("joins", [])

        # ─── Find join paths between tables ────────────────────────
        join_paths = []
        table_names = list(tables_found.keys())
        # Batch: get all join paths in ONE query
        table_pairs = [(t1, t2) for i, t1 in enumerate(table_names) for t2 in table_names[i+1:]]
        if table_pairs:
            batch_joins = self.retriever.get_join_paths_batch(table_pairs)
            for (t1, t2), jp in batch_joins.items():
                if jp and jp.get("join_keys"):
                    join_paths.append(jp)

        # Also get joins from table context
        for tbl_name, tbl_info in tables_found.items():
            for j in tbl_info.get("joins", []):
                jp = {
                    "from": tbl_name,
                    "to": j.get("target_table", ""),
                    "join_keys": j.get("properties", {}).get("join_keys", []),
                    "cardinality": j.get("properties", {}).get("cardinality", ""),
                    "description": j.get("description", ""),
                }
                # Avoid duplicates
                existing = any(
                    jp["from"] == e["from"] and jp["to"] == e["to"]
                    or jp["from"] == e["to"] and jp["to"] == e["from"]
                    for e in join_paths
                )
                if not existing and jp["to"] in tables_found:
                    join_paths.append(jp)

        # ─── Collect data quality issues ───────────────────────────
        for r in dq_issues:
            props = r.get("properties", {})
            affected = props.get("affected_tables", [])
            cols = props.get("affected_columns", [])
            warnings.append(f"{r['name']}: {r.get('description', '')} (affects: {', '.join(affected)}, columns: {', '.join(cols)})")

        # ─── Collect example SQL from communities ──────────────────
        example_sqls = []
        for gr in global_results:
            for qe in gr.get("query_examples", []):
                example_sqls.append(qe)

        # ─── Build the context string ──────────────────────────────
        lines = []

        # Tables
        lines.append("=== RELEVANT TABLES ===")
        for tbl_name, info in tables_found.items():
            lines.append(f"TABLE: {info['full_ref']}")
            if info["row_count"]:
                lines.append(f"  Rows: ~{info['row_count']:,}  Columns: {info['column_count']}")
            # All columns
            all_cols = info.get("all_columns", [])
            if all_cols:
                lines.append(f"  All columns ({len(all_cols)}):")
                for col in all_cols:
                    col_name = col["name"]
                    col_type = col.get("properties", {}).get("data_type", "unknown")
                    col_desc = col.get("description", "").strip()
                    col_imp = col.get("properties", {}).get("importance", "")
                    # Mark columns that were specifically retrieved as relevant
                    retrieved = any(c["name"].endswith(f".{col_name}") for c in columns_found)
                    marker = " ★" if retrieved else ""
                    imp_tag = f" [{col_imp}]" if col_imp else ""
                    desc_short = col_desc[:80] if col_desc else ""
                    lines.append(f"    {col_name} ({col_type}){imp_tag}{marker} {desc_short}")
            lines.append("")

        # Join paths
        if join_paths:
            lines.append("=== JOIN PATHS ===")
            for jp in join_paths:
                keys = ", ".join(jp.get("join_keys", []))
                card = jp.get("cardinality", "")
                desc = jp.get("description", "")[:100]
                lines.append(f"JOIN: {jp['from']} → {jp['to']} ({card}) ON {keys}")
                if desc:
                    lines.append(f"  {desc}")
            lines.append("")

        # Warnings & learned insights
        if warnings:
            lines.append("=== WARNINGS & LEARNED INSIGHTS ===")
            for w in warnings:
                lines.append(f"WARNING: {w}")
            lines.append("")

        # Query rules
        lines.append("=== QUERY RULES ===")
        lines.append("- Only include shard_hint = '<value>' in the WHERE clause if the user explicitly mentions a specific shard in their question. Do NOT default to any shard.")
        lines.append("- Never SELECT * without LIMIT on large tables (>1B rows)")
        lines.append("- Use TRY_CAST instead of CAST for res_dob_year (has non-numeric values)")
        lines.append("- Filter enr_date with WHERE enr_date > TIMESTAMP '2010-01-01' (has anomalies)")
        lines.append("- For updt_* varbinary columns, use from_utf8(col) = '11' to filter (NOT CAST(col AS varchar)). b'00'=not updated, b'11'=updated. Example: WHERE from_utf8(updt_resident_name) = '11'")
        lines.append("- uid is encrypted — never try to decrypt or display it")
        lines.append("- No writes allowed — only SELECT queries")
        lines.append("- Read host: 10.10.116.39")
        lines.append("- When using shard_hint (user-specified), also add it to JOIN ON clauses for joined large tables")
        lines.append("")

        # Example SQL
        if example_sqls:
            lines.append("=== EXAMPLE SQL PATTERNS ===")
            for i, qe in enumerate(example_sqls[:3], 1):
                lines.append(f"Example {i}: {qe}")
            lines.append("")

        # Concepts
        if concepts_found:
            lines.append("=== RELEVANT CONCEPTS ===")
            for c in concepts_found[:3]:
                lines.append(f"CONCEPT: {c['name']} — {c.get('description', '')[:100]}")
            lines.append("")

        return "\n".join(lines)


# ─── Interactive Mode ────────────────────────────────────────────────────────

def interactive_mode(use_llm_rerank=True):
    """Run an interactive text-to-SQL session."""
    print("=" * 75)
    print("  Text-to-SQL Pipeline — GraphRAG + GLM-5.2-FP8")
    print("=" * 75)
    print()
    print("  Type your question in natural language.")
    print("  The pipeline will:")
    print("    1. Retrieve relevant tables/columns via GraphRAG")
    print("    2. Re-rank with LLM (optional)")
    print("    3. Generate Trino SQL")
    print("    4. EXPLAIN + Execute (optional)")
    print()
    print("  Commands:  :quit  :execute  :explain  :rerank  :norank  :context")
    print()

    tts = TextToSQL(use_llm_rerank=use_llm_rerank, verbose=True)
    do_execute = False
    do_explain = False
    show_context = False

    while True:
        try:
            question = input("\n❯ ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break

        if not question:
            continue

        # Commands
        if question.lower() in (":quit", ":q", "exit", "quit"):
            print("Bye!")
            break
        elif question.lower() == ":execute":
            do_execute = not do_execute
            print(f"  Execute: {'ON' if do_execute else 'OFF'}")
            continue
        elif question.lower() == ":explain":
            do_explain = not do_explain
            print(f"  Explain: {'ON' if do_explain else 'OFF'}")
            continue
        elif question.lower() == ":rerank":
            tts.use_llm_rerank = True
            print("  LLM re-ranking: ON")
            continue
        elif question.lower() == ":norank":
            tts.use_llm_rerank = False
            print("  LLM re-ranking: OFF")
            continue
        elif question.lower() == ":context":
            show_context = not show_context
            print(f"  Show context: {'ON' if show_context else 'OFF'}")
            continue

        # Run the pipeline
        result = tts.generate(question, execute=do_execute, explain=do_explain)

        # Show context if requested
        if show_context and result.get("context"):
            print("\n" + "─" * 75)
            print("RETRIEVED CONTEXT:")
            print("─" * 75)
            print(result["context"])

        # Show final SQL
        print("\n" + "=" * 75)
        print("GENERATED SQL:")
        print("=" * 75)
        print(result["sql"])

        # Show results if executed
        if result.get("query_result"):
            qr = result["query_result"]
            if qr.get("success"):
                print(f"\n{'=' * 75}")
                print(f"RESULTS ({qr.get('row_count', 0)} rows, {qr.get('elapsed', 0)}s):")
                print("=" * 75)
                cols = qr.get("columns", [])
                rows = qr.get("rows", [])
                if cols:
                    print("  | ".join(str(c) for c in cols))
                    print("-" * 75)
                for row in rows[:20]:
                    print("  | ".join(str(v) for v in row))
                if len(rows) > 20:
                    print(f"  ... ({len(rows) - 20} more rows)")
            else:
                print(f"\n❌ Query failed: {qr.get('error', 'unknown')}")

        print(f"\n  Total time: {result['elapsed']}s")


# ─── CLI ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

    parser = argparse.ArgumentParser(description="Text-to-SQL with GraphRAG + GLM-5.2")
    parser.add_argument("question", nargs="?", help="Natural language question (omit for interactive mode)")
    parser.add_argument("--rerank", action="store_true", default=True, help="Use LLM re-ranking (default: on)")
    parser.add_argument("--no-rerank", action="store_true", help="Disable LLM re-ranking")
    parser.add_argument("--execute", action="store_true", help="Execute the generated SQL")
    parser.add_argument("--explain", action="store_true", help="EXPLAIN before executing")
    parser.add_argument("--context", action="store_true", help="Show retrieved context")
    parser.add_argument("--quiet", action="store_true", help="Minimal output")
    args = parser.parse_args()

    use_rerank = not args.no_rerank

    if args.question:
        # Single query mode
        tts = TextToSQL(use_llm_rerank=use_rerank, verbose=not args.quiet)
        result = tts.generate(args.question, execute=args.execute, explain=args.explain)

        if args.context:
            print("\n" + "─" * 75)
            print("CONTEXT:")
            print("─" * 75)
            print(result["context"])

        print("\n" + "=" * 75)
        print("SQL:")
        print("=" * 75)
        print(result["sql"])

        if result.get("query_result", {}).get("success"):
            qr = result["query_result"]
            print(f"\n{'=' * 75}")
            print(f"RESULTS ({qr.get('row_count', 0)} rows):")
            print("=" * 75)
            cols = qr.get("columns", [])
            rows = qr.get("rows", [])
            if cols:
                print("  | ".join(str(c) for c in cols))
            for row in rows[:20]:
                print("  | ".join(str(v) for v in row))
    else:
        # Interactive mode
        interactive_mode(use_llm_rerank=use_rerank)
