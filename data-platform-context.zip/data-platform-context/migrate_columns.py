#!/usr/bin/env python3
"""
Migrate full column definitions for flink_stream and station_reg_helper tables
into the GraphRAG PostgreSQL database — using a single batched SQL file.
"""

import json
import subprocess
import os
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "pyyaml"], capture_output=True)
    import yaml

CONTEXT_DIR = r"C:\data-platform-context"
CONTAINER = "graphrag-postgres"
DB_USER = "graphrag"
DB_NAME = "graphrag"
TEMP_DIR = os.path.join(os.environ.get("TEMP", "/tmp"), "opencode")
os.makedirs(TEMP_DIR, exist_ok=True)

YAML_FILES = [
    os.path.join(CONTEXT_DIR, "flink_stream.stream_enu.enu_bfc_analytics_raw_v1.yaml"),
    os.path.join(CONTEXT_DIR, "flink_stream.stream_enu.enu_uc_opt_action_v2.yaml"),
    os.path.join(CONTEXT_DIR, "flink_stream.stream_enu.telemetry_uc.yaml"),
    os.path.join(CONTEXT_DIR, "mysql_uidmasterv1.uidmasterv1_1.station_reg_helper.yaml"),
]


def sql_escape(s):
    if s is None:
        return ""
    return str(s).replace("'", "''")


def build_props_sql(props):
    """Build a jsonb_build_object() SQL expression from a dict — avoids JSON string escaping issues."""
    parts = []
    for k, v in props.items():
        if v is None:
            continue
        elif isinstance(v, bool):
            val = "true" if v else "false"
        elif isinstance(v, (int, float)):
            val = str(v)
        else:
            val = f"'{sql_escape(v)}'"
        parts.append(f"'{k}', {val}")
    return f"jsonb_build_object({', '.join(parts)})"


def query(sql):
    json_sql = f"SELECT coalesce(json_agg(row_to_json(t)), '[]'::json) FROM ({sql}) t;"
    tmp = os.path.join(TEMP_DIR, "q.sql")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(json_sql)
    subprocess.run(["docker", "cp", tmp, f"{CONTAINER}:/tmp/q.sql"], capture_output=True)
    r = subprocess.run(
        ["docker", "exec", CONTAINER, "psql", "-U", DB_USER, "-d", DB_NAME, "-t", "-A", "-f", "/tmp/q.sql"],
        capture_output=True, text=True, encoding="utf-8",
    )
    out = r.stdout.strip()
    return json.loads(out) if out and out != "null" else []


def build_migration_sql():
    """Build a single SQL file with all inserts/updates."""
    statements = ["BEGIN;"]

    # Get current max entity number
    max_result = query("SELECT MAX(CAST(SUBSTRING(entity_id FROM 2) AS INTEGER)) AS max_num FROM entities WHERE entity_id ~ '^E[0-9]+$'")
    next_num = (max_result[0]["max_num"] or 0) + 1 if max_result else 300

    total_insert = 0
    total_update = 0

    for yaml_path in YAML_FILES:
        if not os.path.exists(yaml_path):
            print(f"[SKIP] File not found: {yaml_path}")
            continue

        with open(yaml_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        tbl_info = data.get("table", {})
        actual_name = tbl_info.get("name", "")
        full_ref = tbl_info.get("full_reference", "")
        columns = data.get("columns", [])

        print(f"\nProcessing: {full_ref} ({len(columns)} columns)")

        # Get table entity_id
        table_results = query(f"SELECT entity_id FROM entities WHERE type = 'TABLE' AND name = '{sql_escape(actual_name)}'")
        if not table_results:
            print(f"  [SKIP] Table entity not found: {actual_name}")
            continue

        table_entity_id = table_results[0]["entity_id"]
        print(f"  Table entity_id: {table_entity_id}")

        # Get existing columns for this table
        existing = query(f"""
            SELECT e.entity_id, e.name
            FROM relationships r
            JOIN entities e ON r.target_id = e.entity_id
            WHERE r.source_id = '{sql_escape(table_entity_id)}'
              AND r.type = 'HAS_COLUMN'
        """)
        existing_map = {}
        for c in existing:
            # Match by qualified name (table.column) or just column name
            existing_map[c["name"]] = c["entity_id"]
            # Also try matching just the column part
            if "." in c["name"]:
                col_part = c["name"].split(".")[-1]
                existing_map[col_part] = c["entity_id"]

        print(f"  Existing columns in DB: {len(existing)}")

        for col in columns:
            col_name = col.get("name", "")
            if not col_name:
                continue

            qualified_name = f"{actual_name}.{col_name}"
            desc = col.get("description", "")
            notes = col.get("notes", "")
            full_desc = f"{desc}"
            if notes:
                full_desc += f" Notes: {notes}"

            props = {
                "data_type": col.get("type", ""),
                "importance": col.get("importance", ""),
                "table": actual_name,
                "notes": notes,
            }
            if col.get("deprecated"):
                props["deprecated"] = True
            if col.get("pii"):
                props["pii"] = True
                props["pii_type"] = col.get("pii_type", "")

            search_text = f"{qualified_name} {desc} {notes}"
            props_sql = build_props_sql(props)

            # Check if column exists (by qualified name or just column name)
            existing_id = existing_map.get(qualified_name) or existing_map.get(col_name)

            if existing_id:
                # UPDATE existing column
                statements.append(f"""
UPDATE entities SET
    name = '{sql_escape(qualified_name)}',
    description = '{sql_escape(full_desc)}',
    properties = {props_sql},
    search_text = '{sql_escape(search_text)}'
WHERE entity_id = '{sql_escape(existing_id)}';
""".strip())
                total_update += 1
            else:
                # INSERT new column + HAS_COLUMN relationship
                entity_id = f"E{next_num:04d}"
                next_num += 1

                statements.append(f"""
INSERT INTO entities (entity_id, name, type, description, properties, search_text)
VALUES (
    '{sql_escape(entity_id)}',
    '{sql_escape(qualified_name)}',
    'COLUMN',
    '{sql_escape(full_desc)}',
    {props_sql},
    '{sql_escape(search_text)}'
);
""".strip())

                rel_desc = f"Table {actual_name} has column {col_name} ({col.get('type', '?')})"
                statements.append(f"""
INSERT INTO relationships (source_id, target_id, type, description)
VALUES (
    '{sql_escape(table_entity_id)}',
    '{sql_escape(entity_id)}',
    'HAS_COLUMN',
    '{sql_escape(rel_desc)}'
);
""".strip())
                total_insert += 1

        # Update column_count on the table entity
        total_cols = len(columns)
        statements.append(f"""
UPDATE entities
SET properties = jsonb_set(properties, '{{column_count}}', '{total_cols}')
WHERE entity_id = '{sql_escape(table_entity_id)}';
""".strip())

    statements.append("COMMIT;")

    print(f"\nTotal: {total_insert} new inserts, {total_update} updates")
    return "\n".join(statements)


if __name__ == "__main__":
    print("GraphRAG PostgreSQL — Full Column Migration (Batched)")
    print("=" * 70)

    total_before = query("SELECT count(*) AS cnt FROM entities WHERE type = 'COLUMN'")[0]["cnt"]
    print(f"Total COLUMN entities before: {total_before}")

    # Build the full SQL migration
    sql = build_migration_sql()

    # Write to temp file
    sql_path = os.path.join(TEMP_DIR, "migrate_columns.sql")
    with open(sql_path, "w", encoding="utf-8") as f:
        f.write(sql)

    print(f"\nSQL file written: {sql_path} ({len(sql)} bytes)")

    # Copy to container and execute
    print("Copying SQL to container...")
    cp = subprocess.run(
        ["docker", "cp", sql_path, f"{CONTAINER}:/tmp/migrate_columns.sql"],
        capture_output=True, text=True,
    )
    if cp.returncode != 0:
        print(f"docker cp failed: {cp.stderr}")
        sys.exit(1)

    print("Executing migration...")
    r = subprocess.run(
        ["docker", "exec", CONTAINER, "psql", "-U", DB_USER, "-d", DB_NAME, "-f", "/tmp/migrate_columns.sql"],
        capture_output=True, text=True, encoding="utf-8",
    )

    if r.returncode != 0:
        print(f"ERROR: {r.stderr}")
        sys.exit(1)

    # Print psql output (shows INSERT/UPDATE counts)
    for line in r.stdout.strip().split("\n"):
        if line.strip():
            print(f"  {line}")

    # Verify
    total_after = query("SELECT count(*) AS cnt FROM entities WHERE type = 'COLUMN'")[0]["cnt"]
    print(f"\n{'=' * 70}")
    print(f"Migration complete!")
    print(f"Total COLUMN entities before: {total_before}")
    print(f"Total COLUMN entities after:  {total_after}")
    print(f"Added: {total_after - total_before} new columns")

    # Final column counts per table
    print(f"\n{'=' * 70}")
    print("FINAL COLUMN COUNTS PER TABLE:")
    results = query("""
        SELECT s.name AS table_name, count(*) AS column_count
        FROM relationships r
        JOIN entities s ON r.source_id = s.entity_id
        JOIN entities t ON r.target_id = t.entity_id
        WHERE r.type = 'HAS_COLUMN' AND s.type = 'TABLE'
        GROUP BY s.name
        ORDER BY s.name
    """)
    for r in results:
        print(f"  {r['table_name']:<45} {r['column_count']} columns")
