# Text-to-SQL with GraphRAG — High-Level Design

> **v2.0 · Oct 2026**

## 1. Overview

Natural-language → Trino SQL pipeline for `strot.mysql_uid_v2` (5 tables, 1.46B–3.29B rows each). Uses GraphRAG to retrieve schema context, then LLM generates SQL.

**Key numbers:** 217 entities · 343 relationships · 85% top-1 accuracy · 100% top-5 recall · 2 LLM calls per query · 7–28s end-to-end

---

## 2. Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                         USER                                │
│                    "how many uids by                        │
│                     status in shard 45"                      │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                  text_to_sql.py                             │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ STEP 1: RETRIEVAL                                   │   │
│  │                                                     │   │
│  │  Synonym expand (hardcoded, 34 groups, <1ms)       │   │
│  │        │                                            │   │
│  │        ▼                                            │   │
│  │  Stage 1: PostgreSQL FTS          Stage 2: LLM     │   │
│  │  (websearch_to_tsquery +          Re-rank          │   │
│  │   ts_rank = BM25, graph           (GLM-5.2-FP8)    │   │
│  │   expansion via SQL JOINs)        ★ CALL #1        │   │
│  │   → 100% recall                   → 85% precision   │   │
│  │   ~1.1s                           3-8s              │   │
│  └──────────────────────┬──────────────────────────────┘   │
│  ┌──────────────────────▼──────────────────────────────┐   │
│  │ STEP 2: CONTEXT ASSEMBLY                            │   │
│  │  Table schemas + join paths + DQ rules + warnings   │   │
│  │  → 15K-28K char structured prompt                   │   │
│  └──────────────────────┬──────────────────────────────┘   │
│  ┌──────────────────────▼──────────────────────────────┐   │
│  │ STEP 3: LLM SQL GENERATION        ★ CALL #2        │   │
│  │  System prompt: 9 hard rules (shard_hint,           │   │
│  │   from_utf8, TRY_CAST, LIMIT, no writes)            │   │
│  │  → Trino SQL query                                  │   │
│  └──────────────────────┬──────────────────────────────┘   │
│  ┌──────────────────────▼──────────────────────────────┐   │
│  │ STEP 4: EXPLAIN → STEP 5: EXECUTE                   │   │
│  │  Validate syntax, then run on Trino read host       │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
        │                    │                     │
        ▼                    ▼                     ▼
┌──────────────┐   ┌──────────────┐   ┌──────────────────┐
│ PostgreSQL   │   │ GLM-5.2-FP8  │   │     Trino        │
│ (GraphRAG)   │   │ (LLM API)    │   │  (Query Engine)  │
│              │   │              │   │                  │
│ entities     │   │ vLLM serve   │   │ Read host:       │
│ relationships│   │ 10.10.109.   │   │ 10.10.116.39     │
│ text_units   │   │ 101:32320    │   │                  │
│ communities  │   │ 524K context │   │ strot.mysql_uid_ │
│ query_paths  │   │ No auth      │   │ v2 (5 tables)    │
│              │   │              │   │ Read-only        │
│ FTS: GIN+BM25│   │ Reasoning    │   │ 1.46B-3.29B rows │
│ Vector: HNSW │   │ model        │   │                  │
└──────────────┘   └──────────────┘   └──────────────────┘
```

**Fallback:** If PostgreSQL is down → CleanGraphRAG (JSON + BM25 from scratch). Same interface, automatic.

---

## 3. Components

| Component | File | Role |
|-----------|------|------|
| **Pipeline** | `text_to_sql.py` | Orchestrates 5 steps: retrieve → assemble → generate → validate → execute |
| **Retriever** | `postgres_retriever.py` | Stage 1 FTS + Stage 2 LLM re-rank + graph expansion via SQL |
| **Fallback** | `clean_retriever.py` | JSON + BM25 from scratch (used if PG unavailable) |
| **LLM Client** | `llm_client.py` | Direct HTTP to GLM-5.2-FP8: `rerank()`, `generate_sql()`, `chat()` |
| **Storage** | PostgreSQL 16 + pgvector | Entities, relationships, text units, communities, query paths |
| **Execution** | Trino (`strot_query` module) | Read-only SQL execution on `10.10.116.39` |

---

## 4. Data Model (PostgreSQL)

```
entities (217 rows)
├── entity_id TEXT PK
├── name, type, description
├── properties JSONB (data_type, importance, notes)
├── search_text TEXT (clean, entity-specific only)
├── tsv TSVECTOR (auto-populated, GIN-indexed)
└── embedding VECTOR(768) (NULL, HNSW-indexed, ready for future)

relationships (343 rows)
├── source_id → entities, target_id → entities
├── type: HAS_COLUMN | JOINS_TO | HAS_CONCEPT | AFFECTS
└── properties JSONB (join_keys, cardinality)

text_units (321 rows)
├── entity_id → entities
├── text (natural-language descriptions + enriched questions)
└── source: original | llm_enriched

communities (5 rows) — entity groupings with summaries
query_paths (12 rows) — pre-computed multi-table join paths

Views: v_columns, v_joins, v_neighbors (graph expansion)
```

**Entity breakdown:** 5 TABLE · 189 COLUMN · 10 CONCEPT · 7 DATA_QUALITY_ISSUE · 3 HOST · 3 JOIN_KEY

**Clean document principle:** Each entity's `search_text` contains only its own info. Relationships are navigated via graph edges (SQL JOINs), not shared text tokens. Eliminates 30–50% term overlap between table and column documents.

---

## 5. Graph Topology

```
                    uid_master (1.46B)
                   /         |
          JOINS_TO 1:N   JOINS_TO 1:1
             /              \
   uid_his_master      uid_address (1.46B)
      (2.77B)               |
                      JOINS_TO 1:N
                             |
                      uid_his_address
                         (2.77B)
                             |
                      JOINS_TO 1:N
                      (uid + eid + shard_hint)
                             |
                   uid_origin_tracker_enriched
                        (3.29B, 68 cols)
                   25 updt_* varbinary flags
```

**Critical join:** `uid_origin_tracker_enriched → uid_his_master` requires **uid + eid + shard_hint** (3 keys). Joining on uid alone causes cartesian explosion.

---

## 6. Retrieval Design

### Two-Stage Pipeline

| Stage | Method | Recall | Latency | LLM? |
|-------|--------|--------|---------|------|
| 1 | PostgreSQL FTS (`websearch_to_tsquery` + `ts_rank`) + graph expansion (SQL JOINs) | 100% top-5 | ~1.1s | No |
| 2 | GLM-5.2-FP8 re-ranks top 10 candidates | 85% top-1 | 3–8s | ★ Call #1 |

### Synonym Expansion (Stage 0, deterministic)

34 hardcoded groups bridge the lexical gap. Not LLM-generated — for speed (ms) and determinism.

```
"changed" → {update, updt, modified, changed}
"dead"    → {death, dod, deceased, died, alive}
"age"     → {age, dob, birth, year, old}
"document"→ {proof, poi, poa, pob}
```

Expanded into `websearch_to_tsquery` OR syntax: `"age OR dob OR birth OR year OR old"`

### Graph Expansion

FTS match → SQL JOIN on `v_neighbors` → related entities (parent table, concepts, DQ issues) returned in the same query. One SQL round-trip replaces 15 lines of Python dict traversal.

---

## 7. LLM Integration

### GLM-5.2-FP8

| Attribute | Value |
|-----------|-------|
| Endpoint | `http://10.10.109.101:32320/glm52/v1` (vLLM, OpenAI-compatible) |
| Type | Reasoning model (`reasoning` field = thinking, `content` = answer) |
| Context | 524,288 tokens |
| `max_tokens` | Must be ≥500 (reasoning consumes tokens before answer) |

### Two Calls Per Query

| Call | Purpose | Input | Output | Time |
|------|---------|-------|--------|------|
| #1 | Re-rank 10 candidates by semantic relevance | ~2K tokens | JSON scores 0–10 | 3–8s |
| #2 | Generate Trino SQL from context + question | ~5K tokens | SQL query | 2–12s |

### SQL Generation Rules (9 hard rules in system prompt)

1. `WHERE shard_hint = 'XX'` mandatory (partition pruning)
2. `from_utf8(col) = '11'` for varbinary (not `CAST`)
3. `TRY_CAST(res_dob_year AS integer)` (non-numeric values exist)
4. `enr_date > TIMESTAMP '2010-01-01'` (anomalies year 7–8205)
5. `LIMIT 100` auto-added if missing
6. Strip trailing semicolons (Trino rejects them)
7. Join on uid + eid + shard_hint (not uid alone)
8. `count(DISTINCT uid)` for counts
9. No writes ever (read-only)

---

## 8. Data Flow (Example)

```
"how many uids by status in shard 45"

1. SYNONYM EXPAND          <1ms    "status OR active OR deactivated"
2. POSTGRESQL FTS          ~1.1s   → uid_status_key (score 0.97)
  + graph expansion                → uid_master table, join paths
3. LLM RE-RANK            3-8s    ★ CALL #1
                                    → uid_status_key #1 (LLM 9/10)
4. CONTEXT ASSEMBLY        <10ms   → 28K char prompt (tables, columns, rules)
5. LLM SQL GENERATION      2-12s   ★ CALL #2
   → SELECT uid_status_key, count(*) AS uid_count
       FROM strot.mysql_uid_v2.uid_master
       WHERE shard_hint = '45'
       GROUP BY uid_status_key
       ORDER BY uid_count DESC
       LIMIT 100
6. EXPLAIN                 0.5-2s  → Pass
7. EXECUTE ON TRINO        1.0s    → 18 rows returned

TOTAL: ~8-23s (LLM-bound)
```

---

## 9. Technology Stack

| Layer | Technology | Why |
|-------|-----------|-----|
| GraphRAG storage | PostgreSQL 16 + pgvector | One DB for FTS + graph + vectors |
| Full-text search | PostgreSQL `websearch_to_tsquery` + `ts_rank` | Built-in BM25, stemming, GIN index |
| Vector search (future) | pgvector HNSW index | Ready for embeddings, zero migration |
| LLM | GLM-5.2-FP8 via vLLM | Reasoning model, 524K context, internal |
| Query engine | Trino (`strot_query` module) | Distributed SQL, read host 10.10.116.39 |
| Containerization | Docker Compose | PostgreSQL + pgAdmin |
| Runtime | Python + numpy + requests | No other packages (no internet) |

**No Python PostgreSQL driver** — uses `docker exec psql` (subprocess). 1.1s overhead per query. Install `pg8000` (pure Python) when available to drop to ~0.01s.

---

## 10. Design Decisions

| Decision | Alternatives | Rationale |
|----------|-------------|-----------|
| PostgreSQL over Neo4j/MongoDB | Neo4j, MongoDB, SQLite | One DB for FTS + vectors + graph; SQL consistency with Trino; pgvector maturity |
| Clean entity-specific documents | Rich docs with community titles in columns | Eliminates 30–50% term overlap; relationships via graph edges |
| Hardcoded synonyms over LLM | LLM generates synonyms per query | Speed (ms vs seconds), determinism, control |
| Two-stage retrieval (FTS + LLM) | FTS only, LLM only | FTS = 100% recall, LLM = 85% precision, both needed |
| Docker exec psql over driver | psycopg2, pg8000 | No internet to install drivers; works with zero deps |
| `websearch_to_tsquery` over `to_tsquery` | `to_tsquery`, `plainto_tsquery` | Handles OR syntax + multi-word synonyms without errors |
| Fallback to JSON+BM25 | Hard fail if PG down | System stays functional during PG maintenance |
| pgvector HNSW index created but empty | Wait until embeddings available | Zero-migration readiness for vector search |

---

## 11. Scalability Path

| Scale | Entities | Solution |
|-------|----------|----------|
| Current (5 tables) | 217 | PostgreSQL (instant) |
| 50 tables | ~2,000 | PostgreSQL (still instant, indexed) |
| 500 tables | ~20,000 | PostgreSQL + install pg8000 driver |
| 5,000 tables | ~200,000 | PostgreSQL + pgbouncer + embedding model |

**Current bottleneck is LLM (5–20s), not storage (1.1s).** Database optimization only matters when LLM is replaced or cached.

---

## 12. File Map

```
C:\data-platform-context\
├── text_to_sql.py              # Pipeline orchestrator
├── postgres_retriever.py       # Primary retriever (PostgreSQL)
├── clean_retriever.py          # Fallback retriever (JSON + BM25)
├── llm_client.py               # GLM-5.2-FP8 API client
├── graph_rag_index.json        # JSON index (fallback data)
├── *.yaml / *.md               # Table context files (5 tables)
└── postgres/
    ├── docker-compose.yml      # PG + pgAdmin
    └── init/01_schema.sql      # Schema, indexes, triggers, views
```
