# Trino Table Context Layer — `strot.mysql_uid_v2.uid_his_address`

> Context layer for text-to-SQL. Catalog: `strot` · Schema: `mysql_uid_v2` · Table: `uid_his_address`
>
> **History table for `uid_address`.** When a UID's address is updated in `uid_address`, the previous version of that row is inserted here. Each row represents a historical snapshot of a UID's address. A single UID can have multiple address history rows.

## Quick Facts

| Property | Value |
|----------|-------|
| Full table reference | `strot.mysql_uid_v2.uid_his_address` |
| Approximate row count | **1,510,130,147** (~1.51 billion) |
| Column count | 32 |
| Source connector | MySQL , exposed via Trino |
| Data date range | 2017-08-17 → 2026-10-09 (active, updated daily) |
| Read host | `10.10.116.39` |
| Write hosts | `10.10.116.75`, `10.10.118.10` |

> ⚠️ **Very large table (~1.51B rows).** Always use `LIMIT`, `shard_hint` for partition pruning, or `uid` predicates. Avoid `SELECT *` without a limit.

### Differences from `uid_address`

| Change | Detail |
|--------|--------|
| **Added column** | `eid` (varchar) — Enrolment ID for this enrolment/update event |
| **PK column** | `his_addr_key` (bigint) replaces `addr_key` |
| **Higher NULL rates** | Subdistrict ~11.8% NULL (vs 6.1% in `uid_address`); pincode 0.02% NULL (vs 0%); some state names NULL (0.34%) |
| **Data date range** | Starts 2017-08-17 (vs 2010-08-21 in `uid_address`) — history retention began later |
| **Literal `'NULL'` strings** | Some columns contain the literal string `'NULL'` in addition to actual NULLs — data-quality artifact |

---

## Column Dictionary

| # | Column | Type | Description | Notes | Importance Based on Usage |
|---|--------|------|-------------|-------|---------------------------|
| 1 | `his_addr_key` | bigint | Surrogate primary key for history table | Range `1`–`19,028,043`. **Not contiguous** (1.51B rows vs 19M max key). Useful for sampling with `WHERE his_addr_key <= N`. | Low |
| 2 | `uid` | varchar | Encrypted UID (Aadhaar number) | Base64-like encrypted blob. **Never** store/return in plaintext. PII. **Primary join key** to `uid_address` / `uid_master` / `uid_his_master`. Always populated (0% NULL). | High |
| 3 | `eid` | varchar | Enrolment ID for this enrolment/update event | Long numeric string (e.g. `1007200467577520110722161113`). Always populated (0% NULL). **Not present in `uid_address`.** Same as `eid` in `uid_his_master`. | High |
| 4 | `res_addr_vtc_code` | varchar | Village/Town/City code | ~0.03% NULL. | High |
| 5 | `res_addr_vtc_name` | varchar | Village/Town/City name (English) | ~0.34% NULL. | High |
| 6 | `res_addr_vtc_name_local` | varchar | Village/Town/City name (local language) | ~0.36% NULL. | Medium |
| 7 | `res_addr_district_code` | varchar | District code | ~0.03% NULL. | High |
| 8 | `res_addr_district_name` | varchar | District name (English) | ~0.34% NULL. | High |
| 9 | `res_addr_district_name_local` | varchar | District name (local language) | | Medium |
| 10 | `res_addr_subdistrict_code` | varchar | Sub-district / Tehsil code | ~11.8% NULL (higher than `uid_address`'s 6.1%). Also contains literal `'NULL'` strings. | Medium |
| 11 | `res_addr_subdistrict_name` | varchar | Sub-district / Tehsil name (English) | ~11.8% NULL. Also contains literal `'NULL'` strings. | Medium |
| 12 | `res_addr_subdistrict_name_local` | varchar | Sub-district / Tehsil name (local language) | Also contains literal `'NULL'` strings. | Low |
| 13 | `res_addr_state_code` | varchar | State/UT code | ~0.03% NULL. Codes `01`–`37`. See [state codes](#res_addr_state_code). | High |
| 14 | `res_addr_state_name` | varchar | State/UT name (English) | ~0.34% NULL — some rows have valid state_code but NULL state_name. Data quality issues (Orissa vs Odisha, Pondicherry vs Puducherry). | High |
| 15 | `res_addr_state_name_local` | varchar | State/UT name (local language) | | Medium |
| 16 | `res_addr_po_name` | varchar | Post Office name (English) | | Medium |
| 17 | `res_addr_po_name_local` | varchar | Post Office name (local language) | | Low |
| 18 | `res_addr_pincode` | varchar | PIN code (postal code) | ~0.02% NULL (vs 0% in `uid_address`). 6-digit Indian postal code. | High |
| 19 | `res_f_addr_line1` | varchar | Free-text address line 1 | **>99.99% NULL** — address is captured via geographic hierarchy. | Low |
| 20 | `res_f_addr_line1_local` | varchar | Free-text address line 1 (local language) | **>99.99% NULL**. | Low |
| 21 | `res_f_addr_line2` | varchar | Free-text address line 2 | **>99.99% NULL**. | Low |
| 22 | `res_f_addr_line2_local` | varchar | Free-text address line 2 (local language) | **>99.99% NULL**. | Low |
| 23 | `res_f_addr_line3` | varchar | Free-text address line 3 | **>99.99% NULL**. | Low |
| 24 | `res_f_addr_line3_local` | varchar | Free-text address line 3 (local language) | **>99.99% NULL**. | Low |
| 25 | `res_addr_country_code` | varchar | Country code | `356` = India (ISO-3166 numeric). ~0.0005% NULL. Data quality issues: some rows have `'India'` or `'001'` instead of `'356'`. See [country codes](#res_addr_country_code). | Medium |
| 26 | `res_addr_country_name` | varchar | Country name (English) | `India` for vast majority. | Low |
| 27 | `res_addr_country_name_local` | varchar | Country name (local language) | Often populated with `356` instead of a local-language name. | Low |
| 28 | `created_by` | varchar | Source/creator of the record | Typically `enrolserver`. | Low |
| 29 | `creation_date` | timestamp(6) | Record creation timestamp | Range 2017-08-17 → 2026-10-09. | Medium |
| 30 | `last_updated_by` | varchar | Last updater | Typically `enrolserver`. | Medium |
| 31 | `last_updated_date` | timestamp(6) | Last update timestamp | Range 2017-08-17 → 2026-10-09. | High |
| 32 | `shard_hint` | varchar | Sharding hint, basically first 2 digits of every Aadhaar number/UID, used for efficient querying as the MySQL sharding is done based on this | E.g. `56`, `51`, `63`. Use for partition pruning / faster queries. | High |

---

## Geographic Hierarchy

Same structure as `uid_address`:

```
Country
  └── State / UT
       └── District
            └── Sub-district / Tehsil  (11.8% NULL — higher than uid_address)
                 └── Village / Town / City (VTC)
                      └── Post Office (PO)
                           └── Pincode  (0.02% NULL)
```

Each level has: `code`, `name` (English), `name_local` (local language).

---

## Categorical Value Mappings

### res_addr_state_code

| Code | State/UT Name | Count | Notes |
|------|---------------|-------|-------|
| `09` | Uttar Pradesh | 222,117,492 | |
| `27` | Maharashtra | 145,333,851 | Some rows have NULL name (619,265) |
| `19` | West Bengal | 118,071,212 | |
| `28` | Andhra Pradesh | 104,999,561 | |
| `10` | Bihar | 101,294,248 | |
| `23` | Madhya Pradesh | 88,800,403 | |
| `33` | Tamil Nadu | 85,659,764 | Some rows have NULL name (504,376) |
| `29` | Karnataka | 84,738,276 | |
| `08` | Rajasthan | 81,242,357 | |
| `24` | Gujarat | 68,693,310 | |
| `21` | Odisha | 54,568,773 | Also appears as `Orissa` (3,734,672 rows) — data quality issue |
| `32` | Kerala | 42,839,463 | |
| `36` | Telangana | 41,134,413 | Some rows have NULL name (462,345) |
| `03` | Punjab | 39,925,337 | |
| `20` | Jharkhand | 38,803,265 | |
| `07` | Delhi | 36,339,694 | |
| `06` | Haryana | 36,310,478 | |
| `22` | Chhattisgarh | 30,932,272 | |
| `18` | Assam | 19,388,787 | |
| `01` | Jammu and Kashmir | 15,389,502 | |
| `05` | Uttarakhand | 13,557,678 | |
| `02` | Himachal Pradesh | 10,112,909 | |
| `16` | Tripura | 3,809,251 | |
| `14` | Manipur | 3,350,758 | |
| `04` | Chandigarh | 2,100,361 | |
| `30` | Goa | 1,997,814 | |
| `13` | Nagaland | 1,703,267 | |
| `17` | Meghalaya | 1,405,446 | |
| `12` | Arunachal Pradesh | 1,245,964 | |
| `15` | Mizoram | 1,085,997 | |
| `34` | Pondicherry | 865,059 | Also appears as `Puducherry` (852,691 rows) — data quality issue |
| `11` | Sikkim | 669,214 | |
| `26` | Dadra and Nagar Haveli | 449,064 | |
| `NULL` | — | 350,665 | Code is NULL |
| (others) | Andaman, Ladakh, Daman and Diu, Lakshadweep | smaller | |

> **Data quality notes:**
> - Same issues as `uid_address`: Orissa/Odisha (code 21), Pondicherry/Puducherry (code 34), Andaman name variants (code 35)
> - **New issue:** Some rows have valid `res_addr_state_code` but `NULL` `res_addr_state_name` (e.g. code `27` with 619,265 NULL names). Always filter by `res_addr_state_code`, not `res_addr_state_name`.
> - Some rows have `NULL` `res_addr_state_code` entirely (350,665 rows, 0.02%)

### res_addr_country_code

| Code | Name | Count | Notes |
|------|------|-------|-------|
| `356` | India | 1,415,143,714 | ISO-3166 numeric for India (correct) |
| `India` | India | 92,700,921 | Data quality issue — country name in code field |
| `001` | India | 2,276,751 | Data quality issue — incorrect code |
| `NULL` | `NULL` | 8,044 | |
| `356` | `356` | 717 | Data quality issue — code in name field |

> **Filtering advice:** Use `res_addr_country_name = 'India'` or `res_addr_country_code IN ('356', 'India', '001')` for complete India filtering. Same issue as `uid_address`.

---

## Date Ranges

| Column | Min | Max |
|--------|-----|-----|
| `creation_date` | 2017-08-17 15:09:46 | 2026-10-09 01:20:20 |
| `last_updated_date` | 2017-08-17 15:10:27 | 2026-10-09 01:20:20 |

> History starts 2017-08-17 (vs 2010-08-21 in `uid_address`). History retention began later than the main table.

---

## NULL Summary

| Column | NULL Count | NULL % | Notes |
|--------|-----------|--------|-------|
| `uid` | 0 | 0% | **Always populated** |
| `eid` | 0 | 0% | **Always populated** |
| `res_addr_pincode` | 303,078 | 0.02% | Near-complete (vs 0% in `uid_address`) |
| `res_addr_country_code` | 8,044 | 0.0005% | |
| `res_addr_vtc_code` | 467,115 | 0.03% | |
| `res_addr_district_code` | 470,101 | 0.03% | |
| `res_addr_state_code` | 470,462 | 0.03% | |
| `res_addr_vtc_name` | 5,103,552 | 0.34% | |
| `res_addr_district_name` | 5,102,693 | 0.34% | |
| `res_addr_state_name` | 5,204,306 | 0.34% | Some rows have valid code but NULL name |
| `res_addr_vtc_name_local` | 5,488,427 | 0.36% | |
| `res_addr_subdistrict_code` | 178,483,976 | **11.8%** | Higher than `uid_address` (6.1%). Also contains literal `'NULL'` strings. |
| `res_addr_subdistrict_name` | 178,941,920 | **11.8%** | Also contains literal `'NULL'` strings. |
| `res_f_addr_line1/2/3` | ~1.51B | **>99.99%** | Essentially unused (same as `uid_address`) |

---

## Sample Row (anonymized shape)

```
his_addr_key          : 17372897
uid                   : <encrypted base64 blob>
eid                   : '1007200467577520110722161113'
res_addr_vtc_code     : '27260703274500'
res_addr_vtc_name     : 'Ladjalgaon'
res_addr_vtc_name_local : 'लाडजळगाव'
res_addr_district_code: '2726'
res_addr_district_name: 'Ahmadnagar'
res_addr_subdistrict_code : 'NULL' (literal string)
res_addr_subdistrict_name : 'NULL' (literal string)
res_addr_state_code   : '27'
res_addr_state_name   : 'Maharashtra'
res_addr_state_name_local : 'महाराष्ट्र'
res_addr_po_name      : 'NULL' (literal string)
res_addr_pincode      : '414502'
res_f_addr_line1      : NULL
res_f_addr_line2      : NULL
res_f_addr_line3      : NULL
res_addr_country_code : '356'
res_addr_country_name : 'India'
created_by            : 'enrolserver'
creation_date         : 2025-11-13 08:34:43
last_updated_by       : 'enrolserver'
last_updated_date     : 2025-11-13 08:34:43
shard_hint            : '56'
```

---

## Querying Guidance/ Rules (text-to-SQL)

1. **Always scope queries.** With ~1.51B rows, prefer:
   - `LIMIT N`
   - Use `shard_hint` for faster partition pruning
   - `uid` filters when looking up address history for a specific resident
   - State/district/pincode filters for geographic analysis
2. **Avoid full-table aggregations** without a predicate; they scan the entire table.
3. **Geographic hierarchy:** Same as `uid_address` — Country → State → District → Subdistrict → VTC → PO → Pincode. Query by `res_addr_state_code` for reliable state-level filtering.
4. **Data quality — state names:** Same issues as `uid_address` (Odisha/Orissa, Puducherry/Pondicherry). Additionally, some rows have valid `res_addr_state_code` but `NULL` `res_addr_state_name`. Always filter by code, not name.
5. **Data quality — country codes:** Same as `uid_address` — inconsistent values (`'356'`, `'India'`, `'001'`). Use `res_addr_country_name = 'India'` for complete filtering.
6. **Literal `'NULL'` strings:** Some columns (especially subdistrict, PO name) contain the literal string `'NULL'` in addition to actual NULLs. Filter with `WHERE col IS NOT NULL AND col != 'NULL'` if needed.
7. **Free-text address lines are unused:** `res_f_addr_line1/2/3` (and `_local` variants) are >99.99% NULL. Do not rely on them.
8. **PII handling:** `uid` is encrypted. Never attempt decryption in SQL.
9. **History semantics:** Each row is a previous version of a UID's address. To get the current address, query `uid_address`. To get full address update history, filter by `uid` here.
10. **`eid` column:** Unique to this table (not in `uid_address`). Represents the enrolment ID for the update event. Same as `eid` in `uid_his_master` — can be used to correlate address history with demographic history.
11. **Read vs write:** run `SELECT` on read host `10.10.116.39`; No write is allowed on this table.
12. **Priority:** the importance is defined in the column dictionary, mostly problems are solved with High and Medium priority columns.
