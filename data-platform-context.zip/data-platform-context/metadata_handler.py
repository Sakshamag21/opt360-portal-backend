#!/usr/bin/env python3
"""
Metadata Handler — Answers metadata and semantic search questions
by querying the GraphRAG PostgreSQL graph directly (no Trino SQL needed).

Handles intents:
  - METADATA:        "how many tables?", "describe uid_master", "what columns..."
  - SEMANTIC_SEARCH: "which table has biometric data?", "where can I find..."
"""

import json
import subprocess
import os
from postgres_retriever import PostgresGraphRAG


class MetadataHandler:
    """
    Answers metadata/semantic questions by querying the GraphRAG PostgreSQL graph.

    Uses PostgresGraphRAG for FTS search and direct SQL queries for structured lookups.
    """

    def __init__(self, verbose=True):
        self.verbose = verbose
        try:
            self.retriever = PostgresGraphRAG()
            self.pg_available = True
        except RuntimeError:
            self.pg_available = False
            from clean_retriever import CleanGraphRAG
            self.retriever = CleanGraphRAG()
        self._container = "graphrag-postgres"
        self._db_user = "graphrag"
        self._db_name = "graphrag"

    def log(self, msg):
        if self.verbose:
            print(msg)

    # ═══════════════════════════════════════════════════════════════
    #  PostgreSQL direct query helper
    # ═══════════════════════════════════════════════════════════════

    def _pg_query(self, sql):
        """Execute SQL on GraphRAG PostgreSQL, return list of dicts."""
        sql = sql.strip().rstrip(";")
        wrapped = f"SELECT coalesce(json_agg(row_to_json(t)), '[]'::json) FROM ({sql}) t;"
        tmp = os.path.join(os.environ.get("TEMP", "/tmp"), "opencode", "meta_q.sql")
        os.makedirs(os.path.dirname(tmp), exist_ok=True)
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(wrapped)
        subprocess.run(["docker", "cp", tmp, f"{self._container}:/tmp/meta_q.sql"],
                       capture_output=True)
        r = subprocess.run(
            ["docker", "exec", self._container, "psql", "-U", self._db_user,
             "-d", self._db_name, "-t", "-A", "-f", "/tmp/meta_q.sql"],
            capture_output=True, text=True, encoding="utf-8",
        )
        if r.returncode != 0:
            return []
        out = r.stdout.strip()
        return json.loads(out) if out and out != "null" else []

    def _pg_query_one(self, sql):
        """Execute SQL, return single dict."""
        sql = sql.strip().rstrip(";")
        wrapped = f"SELECT coalesce(row_to_json(t), 'null'::json) FROM ({sql}) t;"
        tmp = os.path.join(os.environ.get("TEMP", "/tmp"), "opencode", "meta_one.sql")
        os.makedirs(os.path.dirname(tmp), exist_ok=True)
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(wrapped)
        subprocess.run(["docker", "cp", tmp, f"{self._container}:/tmp/meta_one.sql"],
                       capture_output=True)
        r = subprocess.run(
            ["docker", "exec", self._container, "psql", "-U", self._db_user,
             "-d", self._db_name, "-t", "-A", "-f", "/tmp/meta_one.sql"],
            capture_output=True, text=True, encoding="utf-8",
        )
        if r.returncode != 0:
            return None
        out = r.stdout.strip()
        if not out or out == "null":
            return None
        result = json.loads(out)
        return result if isinstance(result, dict) else (result[0] if isinstance(result, list) and result else None)

    # ═══════════════════════════════════════════════════════════════
    #  Public API — called by TextToSQL for METADATA/SEMANTIC intents
    # ═══════════════════════════════════════════════════════════════

    def handle(self, question, intent):
        """
        Handle a metadata or semantic search question.

        Args:
            question: The natural language question
            intent: "METADATA" or "SEMANTIC_SEARCH"

        Returns:
            dict with:
              - answer: str (formatted human-readable answer)
              - data: dict (structured data for UI)
              - intent: str
              - elapsed: float
        """
        import time
        start = time.time()

        self.log(f"\n━━━ METADATA HANDLER (intent={intent}) ━━━")

        # Route to specific handler based on question analysis
        handler = self._route_question(question, intent)
        self.log(f"  Routed to: {handler}")

        if handler == "count_tables":
            answer, data = self._count_tables(question)
        elif handler == "list_tables":
            answer, data = self._list_tables(question)
        elif handler == "describe_table":
            answer, data = self._describe_table(question)
        elif handler == "list_columns":
            answer, data = self._list_columns(question)
        elif handler == "join_path":
            answer, data = self._join_path(question)
        elif handler == "data_quality":
            answer, data = self._data_quality(question)
        elif handler == "list_schemas":
            answer, data = self._list_schemas(question)
        elif handler == "semantic_search":
            answer, data = self._semantic_search(question)
        elif handler == "table_row_count":
            answer, data = self._table_row_count(question)
        elif handler == "list_concepts":
            answer, data = self._list_concepts(question)
        else:
            # Fallback: semantic search
            answer, data = self._semantic_search(question)

        elapsed = round(time.time() - start, 2)
        self.log(f"  Answer generated ({elapsed}s)")

        return {
            "answer": answer,
            "data": data,
            "intent": intent,
            "handler": handler,
            "elapsed": elapsed,
        }

    # ═══════════════════════════════════════════════════════════════
    #  Question router
    # ═══════════════════════════════════════════════════════════════

    def _route_question(self, question, intent):
        """Determine which specific handler to use based on question content."""
        q = question.lower()

        # Schema/catalog listing
        if any(kw in q for kw in ["how many catalog", "how many schema", "list catalog", "list schema",
                                   "what catalog", "what schema", "which catalog", "which schema"]):
            return "list_schemas"

        # Table counts
        if any(kw in q for kw in ["how many table", "number of table", "count of table", "total table"]):
            return "count_tables"

        # Table listing
        if any(kw in q for kw in ["list table", "show table", "what table"]) and not any(kw in q for kw in ["has", "contain", "store", "which"]):
            return "list_tables"

        # Describe a specific table
        if "describe" in q or "schema of" in q or "structure of" in q or "table definition" in q:
            return "describe_table"

        # Column listing
        if any(kw in q for kw in ["what column", "columns in", "fields in", "list column", "show column", "column name", "column type"]):
            return "list_columns"

        # Join paths
        if any(kw in q for kw in ["join path", "how do i join", "how to join", "join between", "join from", "related", "connected", "linked"]):
            return "join_path"

        # Data quality
        if any(kw in q for kw in ["data quality", "quality issue", "data issue", "warning"]):
            return "data_quality"

        # Row count (metadata)
        if any(kw in q for kw in ["how many rows", "row count", "size of"]):
            return "table_row_count"

        # Concepts
        if "concept" in q:
            return "list_concepts"

        # Semantic search (which table has..., where can I find...)
        if intent == "SEMANTIC_SEARCH" or any(kw in q for kw in ["which table", "where can i", "where is", "what table has", "find table", "looking for"]):
            return "semantic_search"

        # If a table name is mentioned, describe it
        known_tables = self._get_table_names()
        for t in known_tables:
            if t in q:
                return "describe_table"

        return "semantic_search"

    def _get_table_names(self):
        """Get list of all table names for matching."""
        rows = self._pg_query("SELECT name FROM entities WHERE type = 'TABLE'")
        return [r["name"] for r in rows]

    def _extract_table_name(self, question):
        """Extract a table name from the question."""
        q = question.lower()
        known_tables = self._get_table_names()
        for t in known_tables:
            if t in q:
                return t
        # Try to extract after "describe" or "table"
        import re
        m = re.search(r"(?:describe|table|columns? (?:in|of|from))\s+([a-z_]+)", q)
        if m:
            return m.group(1)
        return None

    # ═══════════════════════════════════════════════════════════════
    #  Handlers
    # ═══════════════════════════════════════════════════════════════

    def _list_schemas(self, question):
        """List all catalogs/schemas."""
        rows = self._pg_query("""
            SELECT DISTINCT
                properties->>'schema' AS schema,
                properties->>'full_reference' AS full_ref,
                name
            FROM entities
            WHERE type = 'TABLE'
            ORDER BY schema, name
        """)
        schemas = {}
        for r in rows:
            schema = r.get("schema", "unknown")
            if schema not in schemas:
                schemas[schema] = []
            schemas[schema].append(r["name"])

        lines = [f"There are **{len(schemas)} schemas** containing **{len(rows)} tables**:\n"]
        for schema, tables in sorted(schemas.items()):
            lines.append(f"**{schema}** ({len(tables)} tables):")
            for t in tables:
                lines.append(f"  - `{t}`")
            lines.append("")

        return "\n".join(lines), {"schemas": schemas, "total_tables": len(rows)}

    def _count_tables(self, question):
        """Count tables, optionally filtered by schema."""
        q = question.lower()

        # Check if filtering by schema
        rows = self._pg_query("""
            SELECT
                properties->>'schema' AS schema,
                count(*) AS table_count,
                sum(CAST(properties->>'column_count' AS INTEGER)) AS total_columns,
                sum(CAST(properties->>'row_count' AS BIGINT)) AS total_rows
            FROM entities
            WHERE type = 'TABLE'
            GROUP BY properties->>'schema'
            ORDER BY schema
        """)

        total_tables = sum(r["table_count"] for r in rows)
        total_cols = sum(r["total_columns"] or 0 for r in rows)
        total_rows = sum(r["total_rows"] or 0 for r in rows)

        lines = [f"There are **{total_tables} tables** across {len(rows)} schemas:\n"]
        lines.append(f"| Schema | Tables | Columns | Total Rows |")
        lines.append(f"|--------|--------|---------|------------|")
        for r in rows:
            rows_str = f"~{r['total_rows']:,}" if r["total_rows"] else "?"
            lines.append(f"| {r['schema']} | {r['table_count']} | {r['total_columns']} | {rows_str} |")
        lines.append(f"| **Total** | **{total_tables}** | **{total_cols}** | **~{total_rows:,}** |")

        return "\n".join(lines), {"schemas": rows, "total_tables": total_tables}

    def _list_tables(self, question):
        """List all tables with summary info."""
        rows = self._pg_query("""
            SELECT
                e.name,
                e.description,
                e.properties->>'full_reference' AS full_ref,
                e.properties->>'schema' AS schema,
                e.properties->>'row_count' AS row_count,
                e.properties->>'column_count' AS column_count,
                e.properties->>'warning' AS warning
            FROM entities e
            WHERE e.type = 'TABLE'
            ORDER BY e.properties->>'schema', e.name
        """)

        lines = [f"**{len(rows)} tables** in the knowledge graph:\n"]
        for r in rows:
            rc = int(r["row_count"]) if r.get("row_count") else 0
            rc_str = f"~{rc:,}" if rc > 0 else "?"
            cc = r.get("column_count", "?")
            desc = (r.get("description") or "")[:120]
            lines.append(f"### `{r['name']}`")
            lines.append(f"- **Full reference:** `{r['full_ref']}`")
            lines.append(f"- **Rows:** {rc_str}  **Columns:** {cc}")
            lines.append(f"- **Description:** {desc}")
            if r.get("warning"):
                lines.append(f"- ⚠️ **Warning:** {r['warning'][:150]}")
            lines.append("")

        return "\n".join(lines), {"tables": rows}

    def _describe_table(self, question):
        """Describe a specific table — full details with all columns."""
        table_name = self._extract_table_name(question)
        if not table_name:
            return "Could not identify which table you're asking about. Try: 'describe uid_master'", {}

        # Get table entity
        table = self._pg_query_one(f"""
            SELECT entity_id, name, description, properties
            FROM entities
            WHERE type = 'TABLE' AND name = '{table_name.replace("'", "''")}'
        """)
        if not table:
            # Fuzzy match
            tables = self._get_table_names()
            matches = [t for t in tables if table_name in t]
            if matches:
                table_name = matches[0]
                table = self._pg_query_one(f"""
                    SELECT entity_id, name, description, properties
                    FROM entities
                    WHERE type = 'TABLE' AND name = '{table_name.replace("'", "''")}'
                """)
            if not table:
                return f"Table '{table_name}' not found. Available tables: {', '.join(tables)}", {}

        props = table.get("properties", {})

        # Get all columns
        columns = self._pg_query(f"""
            SELECT e.name, e.description, e.properties
            FROM relationships r
            JOIN entities e ON r.target_id = e.entity_id
            WHERE r.source_id = '{table['entity_id']}'
              AND r.type = 'HAS_COLUMN'
              AND e.type = 'COLUMN'
            ORDER BY e.name
        """)

        # Get joins
        joins = self._pg_query(f"""
            SELECT
                r.type, r.description, r.properties,
                te.name AS target_table, te.properties->>'full_reference' AS target_ref
            FROM relationships r
            JOIN entities te ON r.target_id = te.entity_id
            WHERE r.source_id = '{table['entity_id']}'
              AND r.type IN ('JOINS_TO', 'JOIN_KEY_IN_TABLE')
            ORDER BY r.type
        """)

        # Also get incoming joins
        incoming = self._pg_query(f"""
            SELECT
                r.type, r.description, r.properties,
                se.name AS source_table, se.properties->>'full_reference' AS source_ref
            FROM relationships r
            JOIN entities se ON r.source_id = se.entity_id
            WHERE r.target_id = '{table['entity_id']}'
              AND r.type IN ('JOINS_TO', 'JOIN_KEY_IN_TABLE')
        """)

        # Build answer
        lines = [f"## `{props.get('full_reference', table_name)}`\n"]

        desc = table.get("description", "")
        if desc:
            lines.append(f"**Description:** {desc}\n")

        rc = props.get("row_count", 0)
        cc = props.get("column_count", len(columns))
        lines.append(f"**Rows:** ~{int(rc):,}  |  **Columns:** {cc}  |  **Schema:** `{props.get('schema', '?')}`\n")

        if props.get("warning"):
            lines.append(f"⚠️ **Warning:** {props['warning']}\n")

        # Column dictionary
        if columns:
            lines.append(f"### Column Dictionary ({len(columns)} columns)\n")
            lines.append(f"| Column | Type | Importance | Description |")
            lines.append(f"|--------|------|------------|-------------|")
            for col in columns:
                cp = col.get("properties", {})
                col_name = col["name"]
                # Strip table prefix if present
                if "." in col_name:
                    col_name = col_name.split(".")[-1]
                dtype = cp.get("data_type", "?")
                imp = cp.get("importance", "")
                cdesc = (col.get("description") or "")[:100]
                lines.append(f"| `{col_name}` | {dtype} | {imp} | {cdesc} |")

        # Joins
        all_joins = []
        for j in joins:
            jk = j.get("properties", {}).get("join_keys", [])
            card = j.get("properties", {}).get("cardinality", "")
            all_joins.append({
                "direction": "→",
                "other_table": j.get("target_table", ""),
                "type": j["type"],
                "join_keys": jk,
                "cardinality": card,
                "description": j.get("description", ""),
            })
        for j in incoming:
            jk = j.get("properties", {}).get("join_keys", [])
            card = j.get("properties", {}).get("cardinality", "")
            all_joins.append({
                "direction": "←",
                "other_table": j.get("source_table", ""),
                "type": j["type"],
                "join_keys": jk,
                "cardinality": card,
                "description": j.get("description", ""),
            })

        if all_joins:
            lines.append(f"\n### Joins ({len(all_joins)})\n")
            for j in all_joins:
                keys = ", ".join(j["join_keys"]) if j["join_keys"] else "(see description)"
                lines.append(f"- {j['direction']} **{j['other_table']}** ({j['type']}, {j['cardinality']}) ON: {keys}")
                if j["description"]:
                    lines.append(f"  _{j['description'][:150]}_")

        return "\n".join(lines), {
            "table": table,
            "columns": columns,
            "joins": all_joins,
        }

    def _list_columns(self, question):
        """List columns of a specific table."""
        table_name = self._extract_table_name(question)
        if not table_name:
            return "Could not identify which table. Try: 'what columns does uid_master have?'", {}

        table = self._pg_query_one(f"""
            SELECT entity_id, name FROM entities
            WHERE type = 'TABLE' AND name = '{table_name.replace("'", "''")}'
        """)
        if not table:
            return f"Table '{table_name}' not found.", {}

        columns = self._pg_query(f"""
            SELECT e.name, e.description, e.properties
            FROM relationships r
            JOIN entities e ON r.target_id = e.entity_id
            WHERE r.source_id = '{table['entity_id']}'
              AND r.type = 'HAS_COLUMN'
              AND e.type = 'COLUMN'
            ORDER BY e.name
        """)

        lines = [f"**{table_name}** has **{len(columns)} columns**:\n"]
        lines.append("| Column | Type | Importance | Description |")
        lines.append("|--------|------|------------|-------------|")
        for col in columns:
            cp = col.get("properties", {})
            col_name = col["name"].split(".")[-1] if "." in col["name"] else col["name"]
            dtype = cp.get("data_type", "?")
            imp = cp.get("importance", "")
            cdesc = (col.get("description") or "")[:120]
            lines.append(f"| `{col_name}` | {dtype} | {imp} | {cdesc} |")

        return "\n".join(lines), {"columns": columns}

    def _join_path(self, question):
        """Find join path between two tables."""
        import re
        known_tables = self._get_table_names()
        mentioned = [t for t in known_tables if t in question.lower()]

        if len(mentioned) < 2:
            # Show all join paths
            joins = self._pg_query("""
                SELECT
                    se.name AS source_table,
                    te.name AS target_table,
                    r.type,
                    r.description,
                    r.properties->>'join_keys' AS join_keys,
                    r.properties->>'cardinality' AS cardinality
                FROM relationships r
                JOIN entities se ON r.source_id = se.entity_id
                JOIN entities te ON r.target_id = te.entity_id
                WHERE r.type = 'JOINS_TO'
                  AND se.type = 'TABLE'
                  AND te.type = 'TABLE'
                ORDER BY se.name, te.name
            """)
            lines = [f"All **table-to-table joins** ({len(joins)}):\n"]
            for j in joins:
                jk = j.get("join_keys", "")
                card = j.get("cardinality", "")
                lines.append(f"- **{j['source_table']}** → **{j['target_table']}** ({card}) ON: {jk}")
                if j.get("description"):
                    lines.append(f"  _{j['description'][:150]}_")
            return "\n".join(lines), {"joins": joins}

        t1, t2 = mentioned[0], mentioned[1]

        # Use the retriever's join path finder
        jp = self.retriever.get_join_path(t1, t2)

        if jp and jp.get("join_keys"):
            lines = [f"**Join path: `{t1}` → `{t2}`**\n"]
            lines.append(f"- **Join keys:** {', '.join(jp['join_keys'])}")
            if jp.get("cardinality"):
                lines.append(f"- **Cardinality:** {jp['cardinality']}")
            if jp.get("description"):
                lines.append(f"- **Description:** {jp['description']}")
            return "\n".join(lines), {"join_path": jp}
        else:
            return f"No direct join path found between `{t1}` and `{t2}`. They may be connected through intermediate tables.", {}

    def _data_quality(self, question):
        """List data quality issues."""
        issues = self._pg_query("""
            SELECT name, description, properties
            FROM entities
            WHERE type = 'DATA_QUALITY_ISSUE'
            ORDER BY name
        """)

        if not issues:
            return "No data quality issues registered in the graph.", {}

        lines = [f"**{len(issues)} data quality issues** found:\n"]
        for i, issue in enumerate(issues, 1):
            props = issue.get("properties", {})
            lines.append(f"### {i}. {issue['name']}")
            lines.append(f"{issue.get('description', '')}")
            if props.get("fix"):
                lines.append(f"**Fix:** `{props['fix']}`")
            if props.get("columns"):
                lines.append(f"**Affected columns:** {', '.join(props['columns'])}")
            lines.append("")

        return "\n".join(lines), {"issues": issues}

    def _table_row_count(self, question):
        """Get row count metadata for a table."""
        table_name = self._extract_table_name(question)
        if not table_name:
            # List all row counts
            tables = self._pg_query("""
                SELECT name, properties->>'row_count' AS row_count,
                       properties->>'column_count' AS column_count,
                       properties->>'full_reference' AS full_ref
                FROM entities WHERE type = 'TABLE'
                ORDER BY CAST(properties->>'row_count' AS BIGINT) DESC
            """)
            lines = ["**Table sizes** (by row count):\n"]
            lines.append("| Table | Rows | Columns |")
            lines.append("|-------|------|---------|")
            for t in tables:
                rc = int(t["row_count"]) if t.get("row_count") else 0
                lines.append(f"| `{t['name']}` | ~{rc:,} | {t.get('column_count', '?')} |")
            return "\n".join(lines), {"tables": tables}

        table = self._pg_query_one(f"""
            SELECT name, description, properties
            FROM entities WHERE type = 'TABLE' AND name = '{table_name.replace("'", "''")}'
        """)
        if not table:
            return f"Table '{table_name}' not found.", {}

        rc = table.get("properties", {}).get("row_count", "?")
        cc = table.get("properties", {}).get("column_count", "?")
        return f"**{table_name}** has approximately **~{int(rc):,}** rows and **{cc}** columns.", {"table": table}

    def _list_concepts(self, question):
        """List all concepts."""
        concepts = self._pg_query("""
            SELECT name, description, properties
            FROM entities WHERE type = 'CONCEPT'
            ORDER BY name
        """)
        lines = [f"**{len(concepts)} concepts** in the knowledge graph:\n"]
        for c in concepts:
            lines.append(f"### {c['name']}")
            lines.append(f"{c.get('description', '')}\n")
        return "\n".join(lines), {"concepts": concepts}

    def _semantic_search(self, question):
        """Semantic search — find relevant tables/columns/concepts using FTS."""
        # Use the retriever's search
        results = self.retriever.search(
            question,
            mode="hybrid",
            top_k=20,
            use_llm_rerank=False,
        )

        local = results.get("local_results", [])

        # Group by type
        tables = [r for r in local if r.get("type") == "TABLE"]
        columns = [r for r in local if r.get("type") == "COLUMN"]
        concepts = [r for r in local if r.get("type") == "CONCEPT"]
        join_keys = [r for r in local if r.get("type") == "JOIN_KEY"]

        lines = [f"**Semantic search results for:** \"{question}\"\n"]

        if tables:
            lines.append(f"### Relevant Tables ({len(tables)})\n")
            for t in tables[:5]:
                props = t.get("properties", {})
                desc = (t.get("description") or "")[:150]
                rc = props.get("row_count", "?")
                lines.append(f"- **`{t['name']}`** ({props.get('full_reference', '')}) — ~{rc} rows")
                lines.append(f"  {desc}")
            lines.append("")

        if columns:
            lines.append(f"### Relevant Columns ({len(columns)})\n")
            for c in columns[:8]:
                cp = c.get("properties", {})
                col_name = c["name"].split(".")[-1] if "." in c["name"] else c["name"]
                dtype = cp.get("data_type", "?")
                desc = (c.get("description") or "")[:100]
                lines.append(f"- **`{col_name}`** ({dtype}) — {desc}")
            lines.append("")

        if join_keys:
            lines.append(f"### Relevant Join Keys ({len(join_keys)})\n")
            for jk in join_keys[:5]:
                lines.append(f"- **`{jk['name']}`** — {(jk.get('description') or '')[:120]}")
            lines.append("")

        if concepts:
            lines.append(f"### Relevant Concepts ({len(concepts)})\n")
            for c in concepts[:3]:
                lines.append(f"- **{c['name']}** — {(c.get('description') or '')[:150]}")
            lines.append("")

        if not local:
            lines.append("No results found. Try rephrasing your question.")

        return "\n".join(lines), {"results": local}
