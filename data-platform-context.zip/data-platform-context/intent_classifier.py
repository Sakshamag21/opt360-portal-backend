#!/usr/bin/env python3
"""
Intent Classifier — Distinguishes metadata queries from data queries.

Intents:
  METADATA        — asking about the schema itself (tables, columns, joins, DQ issues)
  SEMANTIC_SEARCH — looking for which table/column covers a topic
  DATA_QUERY      — requires SQL against actual data
  HYBRID          — needs both metadata + data

Strategy:
  1. Rule-based patterns (fast, no LLM, high confidence on clear cases)
  2. LLM classification (for ambiguous questions)
"""

import re
import json
from llm_client import LLMClient


# ═══════════════════════════════════════════════════════════════
#  Rule-based patterns
# ═══════════════════════════════════════════════════════════════

# High-confidence METADATA patterns (question is about the schema/graph itself)
METADATA_PATTERNS = [
    # Table counts / listing
    (r"\bhow many tables\b", "METADATA"),
    (r"\bnumber of tables\b", "METADATA"),
    (r"\bcount of tables\b", "METADATA"),
    (r"\blist (all )?tables\b", "METADATA"),
    (r"\bshow (all )?tables\b", "METADATA"),
    (r"\bwhat tables (are |exist |available )", "METADATA"),
    (r"\bwhich tables exist\b", "METADATA"),
    (r"\btables in (the )?(catalog|schema)\b", "METADATA"),

    # Describe / structure
    (r"\bdescribe (the )?table\b", "METADATA"),
    (r"\bdescribe\s+\w+", "METADATA"),
    (r"\bschema of\b", "METADATA"),
    (r"\bstructure of\b", "METADATA"),
    (r"\btable structure\b", "METADATA"),
    (r"\btable definition\b", "METADATA"),

    # Column queries
    (r"\bwhat columns\b", "METADATA"),
    (r"\bcolumns in\b", "METADATA"),
    (r"\bfields in\b", "METADATA"),
    (r"\blist columns\b", "METADATA"),
    (r"\bshow columns\b", "METADATA"),
    (r"\bcolumn (types|names|list)\b", "METADATA"),
    (r"\bwhat (type|data type)\b.*\bcolumn\b", "METADATA"),

    # Join paths
    (r"\bjoin path\b", "METADATA"),
    (r"\bhow (do|to) (i )?join\b", "METADATA"),
    (r"\bjoin between\b", "METADATA"),
    (r"\bhow are .+ (related|connected|linked)\b", "METADATA"),
    (r"\brelationship between\b", "METADATA"),

    # Data quality
    (r"\bdata quality\b", "METADATA"),
    (r"\bquality issues\b", "METADATA"),
    (r"\bdata issues\b", "METADATA"),

    # Row counts (metadata, not actual count)
    (r"\bhow many rows (does|are in|in)\b", "METADATA"),
    (r"\brow count (of|for|in)\b", "METADATA"),
    (r"\bsize of .+ table\b", "METADATA"),

    # Concepts / warnings
    (r"\bwhat (is|are) (a |the )?(concept|warning|pii)\b", "METADATA"),
    (r"\bwhat does\b.*\bmean\b", "METADATA"),

    # Catalog/schema queries
    (r"\bwhat (catalogs|schemas) (are |exist|available)\b", "METADATA"),
    (r"\blist (catalogs|schemas)\b", "METADATA"),
    (r"\bhow many (catalogs|schemas)\b", "METADATA"),
]

# High-confidence SEMANTIC_SEARCH patterns (looking for the right table)
SEMANTIC_SEARCH_PATTERNS = [
    (r"\bwhich table\b", "SEMANTIC_SEARCH"),
    (r"\bwhich tables\b", "SEMANTIC_SEARCH"),
    (r"\bwhere (can i|to) find\b", "SEMANTIC_SEARCH"),
    (r"\bwhere is\b", "SEMANTIC_SEARCH"),
    (r"\bwhat table (has|contains|stores)\b", "SEMANTIC_SEARCH"),
    (r"\bwhat tables (have|contain|store)\b", "SEMANTIC_SEARCH"),
    (r"\bfind (a |the )?table\b", "SEMANTIC_SEARCH"),
    (r"\blooking for\b.*\bdata\b", "SEMANTIC_SEARCH"),
    (r"\bwhich schema\b", "SEMANTIC_SEARCH"),
    (r"\bwhat schema\b", "SEMANTIC_SEARCH"),
    (r"\bsearch for\b.*\b(table|column|entity)\b", "SEMANTIC_SEARCH"),
]

# Compile all patterns
ALL_PATTERNS = [(re.compile(p, re.IGNORECASE), intent) for p, intent in
                METADATA_PATTERNS + SEMANTIC_SEARCH_PATTERNS]


# ═══════════════════════════════════════════════════════════════
#  LLM Classification Prompt
# ═══════════════════════════════════════════════════════════════

LLM_CLASSIFY_PROMPT = """You are an intent classifier for a database Q&A system. The database has a knowledge graph (metadata about tables, columns, joins) and actual data tables (billions of rows in Trino).

Classify the user's question into exactly ONE of these intents:

1. METADATA — The question asks about the SCHEMA/STRUCTURE itself. It wants to know about tables, columns, types, joins, data quality issues, row counts (as metadata), or descriptions. It does NOT need to query actual data.
   Examples: "how many tables are there?", "describe uid_master", "what columns does enu_bfc have?", "what is the join path between uid_master and uid_address?", "what data quality issues exist?", "how many rows does uid_master have?"

2. SEMANTIC_SEARCH — The question is looking for WHICH TABLE or COLUMN to use for a topic, without asking for actual data values.
   Examples: "which table has biometric fraud check data?", "where can I find operator actions?", "what table tracks enrolment events?", "which schema has station registration?"

3. DATA_QUERY — The question requires executing SQL against actual data tables to get real values, counts, or records.
   Examples: "how many UIDs are active?", "find residents who died in 2024", "give me UIDs with flipped iris", "count enrolments by registrar", "show me 10 records from uid_master"

4. HYBRID — The question needs BOTH metadata lookup AND data execution.
   Examples: "which table has the most rows and how many active UIDs are in it?", "describe uid_master and count active UIDs", "what columns does uid_master have and how many are non-null?"

User question: "{question}"

Respond with ONLY the intent name (METADATA, SEMANTIC_SEARCH, DATA_QUERY, or HYBRID). No explanation."""


# ═══════════════════════════════════════════════════════════════
#  Classifier
# ═══════════════════════════════════════════════════════════════

class IntentClassifier:
    """
    Classifies a natural language question into an intent category.

    Strategy:
      1. Rule-based regex patterns (instant, no LLM call)
      2. LLM classification (for ambiguous questions that don't match rules)
    """

    def __init__(self, use_llm=True, verbose=True):
        self.use_llm = use_llm
        self.verbose = verbose
        self.llm = LLMClient() if use_llm else None

    def log(self, msg):
        if self.verbose:
            print(msg)

    def classify(self, question):
        """
        Classify a question into an intent.

        Returns:
            dict with:
              - intent: "METADATA" | "SEMANTIC_SEARCH" | "DATA_QUERY" | "HYBRID"
              - method: "rules" | "llm" | "default"
              - confidence: float 0-1
              - reason: str (why this classification)
        """
        q_lower = question.lower().strip()

        # ─── Step 1: Rule-based patterns ────────────────────────────
        rule_result = self._classify_rules(question)
        if rule_result["confidence"] >= 0.8:
            self.log(f"  🎯 Intent: {rule_result['intent']} (rules, {rule_result['confidence']:.0%}) — {rule_result['reason']}")
            return rule_result

        # ─── Step 2: LLM classification ─────────────────────────────
        if self.use_llm and self.llm:
            llm_result = self._classify_llm(question)
            if llm_result:
                self.log(f"  🎯 Intent: {llm_result['intent']} (LLM, {llm_result['confidence']:.0%}) — {llm_result['reason']}")
                return llm_result

        # ─── Step 3: Default to DATA_QUERY ──────────────────────────
        self.log(f"  🎯 Intent: DATA_QUERY (default) — no pattern matched, no LLM")
        return {
            "intent": "DATA_QUERY",
            "method": "default",
            "confidence": 0.5,
            "reason": "Default — no metadata/search patterns detected",
        }

    def _classify_rules(self, question):
        """Rule-based classification using regex patterns."""
        matches = []

        self.log(f"  [debug] Checking {len(ALL_PATTERNS)} patterns against: {question[:80]}")

        for pattern, intent in ALL_PATTERNS:
            m = pattern.search(question)
            if m:
                matches.append({
                    "intent": intent,
                    "matched_text": m.group(),
                    "pattern": pattern.pattern,
                })

        if matches:
            self.log(f"  [debug] Matched {len(matches)} patterns: {[m['matched_text'] for m in matches]}")

        if not matches:
            return {
                "intent": "DATA_QUERY",
                "method": "rules",
                "confidence": 0.0,
                "reason": "No rule patterns matched",
            }

        # Count intent votes
        intent_counts = {}
        for m in matches:
            intent_counts[m["intent"]] = intent_counts.get(m["intent"], 0) + 1

        # Pick the most-matched intent
        best_intent = max(intent_counts, key=intent_counts.get)
        best_count = intent_counts[best_intent]
        confidence = round(min(0.7 + 0.1 * best_count, 0.95), 2)  # 0.7 base + 0.1 per match, capped at 0.95

        matched_texts = [m["matched_text"] for m in matches if m["intent"] == best_intent]
        reason = f"Matched patterns: {', '.join(matched_texts[:3])}"

        return {
            "intent": best_intent,
            "method": "rules",
            "confidence": confidence,
            "reason": reason,
            "matches": matches,
        }

    def _classify_llm(self, question):
        """LLM-based classification for ambiguous questions."""
        try:
            prompt = LLM_CLASSIFY_PROMPT.format(question=question)
            # Use higher max_tokens — reasoning models need room for reasoning + answer
            response = self.llm.chat(prompt, temperature=0.0, max_tokens=500)
            if response is None:
                self.log("  ⚠ LLM returned None (reasoning model produced no content)")
                return None
            intent = response.strip().upper().split("\n")[0].strip()

            # Normalize
            if "META" in intent:
                intent = "METADATA"
            elif "SEMANTIC" in intent:
                intent = "SEMANTIC_SEARCH"
            elif "HYBRID" in intent:
                intent = "HYBRID"
            elif "DATA" in intent:
                intent = "DATA_QUERY"
            else:
                return None

            return {
                "intent": intent,
                "method": "llm",
                "confidence": 0.75,
                "reason": f"LLM classified as {intent}",
            }
        except Exception as e:
            self.log(f"  ⚠ LLM classification failed: {e}")
            return None
