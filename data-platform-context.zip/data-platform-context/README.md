# data-platform-context — Codebase Guide

This is the complete source for the UID/Aadhaar Text-to-SQL platform with RBAC,
self-learning GraphRAG, and a verify-then-run SQL flow.

## Quick Start

```bash
# 1. Backend (Flask API + serves built React)
cd chatbot-api
python app.py            # starts on 0.0.0.0:8000

# 2. Frontend (only needed for development)
cd chatbot-ui
npm install
npm run dev              # Vite dev server on :5173 (proxies to :8000)
npm run build            # production build → chatbot-ui/dist/ (served by Flask)
```

**Default users:** `admin`/`admin123` (admin), `analyst`/`analyst123` (analyst)

## Repository Structure

```
data-platform-context/
│
├── chatbot-api/                ← Flask backend (the main app you run)
│   ├── app.py                  ← ALL API routes: auth, convos, pipeline SSE,
│   │                              feedback merge, add-table, audit, admin
│   ├── pipeline.py             ← PipelineTask: ask/execute/regenerate,
│   │                              trino_query() with stats, _build_sql_prompt(),
│   │                              _build_correction_prompt(), EXPLAIN
│   ├── auth.py                 ← JWT auth + @auth_required + @admin_required
│   ├── config.py               ← Ports, JWT secret, Trino/LLM URLs
│   ├── db.py                   ← PostgreSQL helpers (docker exec psql, NO psycopg2)
│   ├── init_db.py              ← Creates app_users, app_conversations, app_messages,
│   │                              app_audit_log tables
│   └── start.bat               ← Windows launcher
│
├── chatbot-ui/                 ← React + Vite + TypeScript frontend
│   └── src/
│       ├── App.tsx             ← Router (login/chat/admin/audit/add-table)
│       ├── api.ts              ← API client: auto token refresh, SSE stream,
│       │                          authApi, usersApi, conversationsApi,
│       │                          pipelineApi, adminApi, feedbackApi, auditApi
│       ├── types.ts            ← Message, Conversation, User, QueryStats types
│       ├── index.css           ← ALL styles (custom CSS, no UI library)
│       ├── auth-context.tsx    ← React context for auth state
│       ├── pages/
│       │   ├── LoginPage.tsx
│       │   ├── ChatPage.tsx    ← Main chat: SSE, verify-then-run, all-users toggle
│       │   ├── AddTablePage.tsx← 4-step wizard: discover→generate→review→save
│       │   ├── AdminPage.tsx   ← User management
│       │   └── AuditPage.tsx
│       └── components/
│           ├── MessageView.tsx ← Thoughts panel, SQL, results, perf panel,
│           │                      feedback merge banner, admin context panel
│           └── Sidebar.tsx     ← Conversation list + all-users toggle
│
├── text_to_sql.py              ← Pipeline orchestrator: Step 0 intent routing,
│                                   batched context assembly, LLM SQL generation
├── postgres_retriever.py       ← PostgresGraphRAG: FTS retrieval, batched
│                                   get_table_contexts_batch(), get_join_paths_batch()
├── intent_classifier.py        ← Rules-first (48 regex) + LLM fallback
├── llm_client.py               ← GLM-5.2-FP8 client (reasoning support)
├── metadata_handler.py         ← Answers METADATA/SEMANTIC_SEARCH from graph
├── bm25_retriever.py           ← BM25 retrieval (alt to FTS)
├── graph_rag_vector_retriever.py ← Vector-based retrieval
│
├── app/                        ← Older Streamlit chatbot (pre-React)
│   ├── app.py
│   └── conversation_store.py
│
├── graph-ui/                   ← GraphRAG Navigator (standalone, port 5051)
│   ├── backend/                ← Flask, uses docker exec psql
│   └── frontend/               ← HTML/JS visualization
│
├── archive/                    ← Diagnostic/test scripts (not used in production)
│
├── postgres/                   ← PostgreSQL setup
│   ├── docker-compose.yml      ← graphrag-postgres container
│   ├── init/                   ← Schema + triggers (trg_entities_tsv)
│   ├── migrate_data.sql        ← Initial graph data
│   └── migrate_incremental.sql
│
├── *.yaml, *.md                ← Table schemas & docs (uid_master, uid_address, etc.)
│
└── Documentation
    ├── ARCHITECTURE_HLD.md     ← High-level design
    ├── DESIGN.md
    ├── text_to_sql_documentation.md
    ├── graph_rag_architecture.md
    ├── knowledge_graph.md
    └── relationship.md
```

## Key Concepts

### 1. Verify-Then-Run Flow
User asks → LLM generates SQL → user sees SQL → **approves (Run)** or **rejects with feedback** →
if rejected, LLM regenerates using the feedback. Multiple reject rounds supported.

### 2. Feedback Merge to Graph (Self-Learning)
After a corrected query is approved and run, a 💡 banner appears: "Save corrections to knowledge graph?"
- LLM consolidates the feedback into a **QUERY_INSIGHT** entity
- Entity has rich `search_text` (title + description + question + 15 keywords + SQL + columns)
- `tsv` column auto-populated by `trg_entities_tsv` trigger → FTS-discoverable
- `APPLIES_TO` relationship links insight → relevant TABLE entities
- **Future queries** retrieve the insight via FTS → LLM generates correct SQL from the start
- No runtime search, no manual curation — the graph improves itself with usage

### 3. Intent Classification
- Rules-first: 48 regex patterns, confidence threshold 0.8
- LLM fallback if rules inconclusive
- Routes: METADATA (graph answer), SEMANTIC_SEARCH (graph answer),
  DATA_QUERY (full SQL pipeline), HYBRID (graph + SQL)

### 4. GraphRAG Retrieval (Optimized)
- FTS search on `entities.tsv` (PostgreSQL `to_tsvector`)
- Batched queries: `get_table_contexts_batch()` and `get_join_paths_batch()` (N→1 query)
- stdin piping via `docker exec -i psql` (no psycopg2, no temp files)
- Retrieval: 60s+ → <0.2s; total pipeline: 75s → 13s

### 5. SSE Streaming
- `POST /api/pipeline/ask` returns `taskId` immediately
- Frontend opens `EventSource` to `GET /api/pipeline/stream/<taskId>?token=<jwt>`
- Token passed as query param (EventSource can't set headers)
- Pipeline runs in background thread — switching conversations doesn't stop it
- Keepalive comments prevent timeout

### 6. RBAC
- `@auth_required` → decodes JWT, sets `g.current_user`
- `@admin_required` → MUST be used AFTER `@auth_required` (checks `g.current_user`)
- Admin: all conversations, user management, context editing, add table
- Analyst: own conversations only

### 7. Query Performance
- `trino_explain()` returns full EXPLAIN plan during verification
- `trino_query()` captures Trino REST API stats: CPU, memory, rows, bytes, workers, query ID
- Collapsible "⚡ Query Performance" panel in UI

## External Services

| Service | URL | Purpose |
|---------|-----|---------|
| Trino | http://10.10.116.39:8080 | Read-only queries on strot.mysql_uid_v2 |
| GLM-5.2-FP8 | http://10.10.109.101:32320/glm52/v1 | LLM for SQL/intent/feedback |
| GraphRAG PG | docker: graphrag-postgres:5432 | Knowledge graph + app data |
| pgAdmin | http://localhost:5050 | DB management |
| Graph Navigator | http://localhost:5051 | Graph visualization |

## Important Notes

- **No psycopg2** — all PostgreSQL access via `docker exec -i graphrag-postgres psql` with stdin piping
- **No default shard_hint** — LLM only adds `shard_hint` if user explicitly mentions a shard
- **Flask debug=False, use_reloader=False** — avoids Windows process confusion
- **PyJWT 2.12.1** — `sub` claim MUST be string; `uid` numeric field added
- **`tsv` trigger** — `trg_entities_tsv` builds `tsv` from `search_text` via `to_tsvector('english', search_text)`
