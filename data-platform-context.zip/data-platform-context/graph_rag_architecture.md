# GraphRAG Search Architecture

> How the text-to-SQL context layer performs semantic retrieval without embedding models or vector databases.

---

## The Problem

Standard GraphRAG uses **embedding models** (text → vectors) + **vector databases** (store & search vectors) for semantic search. This environment has:

| Requirement | Available? |
|------------|-----------|
| Embedding model (sentence-transformers, OpenAI, etc.) | ❌ No internet to install |
| Vector database (FAISS, ChromaDB, Qdrant) | ❌ No internet to install |
| API keys for embedding APIs | ❌ Not configured |
| Local embedding service (Ollama, etc.) | ❌ Not running |
| **numpy** | ✅ Available |

## The Solution: Two-Stage Retrieval with LLM Re-ranking

Combines fast lexical search (TF-IDF) with LLM-powered semantic re-ranking (GLM-5.2-FP8):

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         USER QUERY                                       │
│              "is the person still alive"                                 │
└──────────────────────────────┬──────────────────────────────────────────┘
                               │
                               ▼
╔═════════════════════════════════════════════════════════════════════════╗
║  STAGE 1: TF-IDF RETRIEVAL (fast — milliseconds)                        ║
║                                                                         ║
║  1a. Tokenize: "is the person still alive"                              ║
║      → ["person", "still", "alive"]  (stopwords removed)                ║
║                                                                         ║
║  1b. Synonym expansion: "alive" → {death, dead, deceased, died, dod}    ║
║                                                                         ║
║  1c. TF-IDF vectorization: query → 769-dim vector (numpy)              ║
║      Rare terms weighted higher (IDF): "dead"=5.7, "person"=3.0         ║
║                                                                         ║
║  1d. Cosine similarity: doc_matrix @ query_vec → 222 scores            ║
║                                                                         ║
║  1e. Take top 10-30 candidates (high recall, may have noise)            ║
║                                                                         ║
║  Also at this stage: LLM-enriched descriptions (92 entities have        ║
║  natural-language questions pre-added to their text, so "alive"         ║
║  matches res_dod's enriched text "is the person alive, when did         ║
║  they die, deceased, passed away")                                      ║
╚═════════════════════════════════════════════════════════════════════════╝
                               │
                               ▼
╔═════════════════════════════════════════════════════════════════════════╗
║  STAGE 2: LLM RE-RANKING (optional — 3-8 seconds)                       ║
║                                                                         ║
║  2a. Send query + top 10 candidates to GLM-5.2-FP8                      ║
║      "Given 'is the person still alive', rank these 10 items by         ║
║       semantic relevance. Return JSON with scores 0-10."                ║
║                                                                         ║
║  2b. LLM reasons about each candidate:                                  ║
║      "res_dod = date of death, NULL means alive → perfectly relevant"   ║
║      "uid_expiry_date = expiry, not about being alive → low"            ║
║                                                                         ║
║  2c. LLM returns ranked JSON:                                           ║
║      [{"index": 1, "score": 10}, {"index": 2, "score": 6}, ...]        ║
║                                                                         ║
║  KEY ADVANTAGE: LLM understands MEANING, not just word overlap.         ║
║  It can surface "nationality_code" for "person from another country"    ║
║  even though no words are shared — because it knows the concept.        ║
╚═════════════════════════════════════════════════════════════════════════╝
                               │
                               ▼
╔═════════════════════════════════════════════════════════════════════════╗
║  GRAPH EXPANSION (GraphRAG layer)                                       ║
║                                                                         ║
║  Top entities expanded to neighborhoods:                                ║
║  - Related columns (HAS_COLUMN edges)                                   ║
║  - Join paths (JOINS_TO edges)                                          ║
║  - Concepts (CONCEPT_CONTAINS_COLUMN edges)                             ║
║  - Data quality issues (AFFECTS_TABLE edges)                            ║
║                                                                         ║
║  Community reports provide global context for broad questions.          ║
╚═════════════════════════════════════════════════════════════════════════╝
```

### When to use each mode:

| Mode | Speed | Accuracy | When to use |
|------|-------|----------|-------------|
| TF-IDF only (`use_llm_rerank=False`) | <100ms | Good (100% on test set) | Interactive search, browsing |
| TF-IDF + LLM re-rank (`use_llm_rerank=True`) | 3-8s | Better (surfaces related entities TF-IDF misses) | Final retrieval before SQL generation |

## How Stage 1 Works

### Step 1: Tokenize + Synonym Expansion

35 domain synonym groups bridge the lexical gap:

```python
{"death", "dead", "deceased", "died", "alive", "dod"}     # alive → death
{"address", "addr", "pincode", "location", "live", "where"}  # live → address
{"foreigner", "foreign", "nri", "nationality", "another country"}  # country → foreigner
{"dob", "birth", "born", "age"}                             # birth → dob
```

### Step 2: TF-IDF Vector Space Model

Built from scratch with numpy — no sklearn dependency:

```
TF(t,d) = count(t in d) / total_terms_in_d           # term frequency
IDF(t)  = log((N + 1) / (df(t) + 1)) + 1             # inverse document frequency
TF-IDF  = TF × IDF                                    # weighted term vector
Similarity = cosine(query_vec, doc_vec)               # dot product / norms
```

**Why TF-IDF beats keyword counting:**

| Query term | Keyword counting | TF-IDF |
|-----------|-----------------|--------|
| "the" (appears everywhere) | weight = 1 (same as rare terms) | weight = 0.5 (low IDF — common word) |
| "deceased" (appears rarely) | weight = 1 | weight = 5.3 (high IDF — distinctive term) |

This means rare, distinctive terms dominate the similarity score — which is exactly what you want for search.

### Step 3: LLM-Enriched Descriptions

For each of the 217 entities, natural-language questions were written that a user might ask:

| Entity | Original description | Enriched questions |
|--------|---------------------|-------------------|
| `res_dod` | "Date of death. Only in uid_master." | + "is the person alive, when did they die, deceased, passed away, still living" |
| `isforeigner` | "Foreigner flag." | + "is the person from another country, foreign national, non-Indian, citizen of another country" |
| `uid_his_address` | "History table for uid_address." | + "person moved to a new house, previous address, address change history, person relocated" |
| `registrar_code` | "Registrar code." | + "who registered this aadhaar, which agency enrolled, registration authority" |

**92 entities enriched** with **94 text units** containing natural-language questions.

This is the key innovation: instead of embedding models that learn semantic similarity at runtime, we **pre-compute** the semantic connections by writing the questions that lead to each entity. The TF-IDF vectorizer then matches these questions against user queries.

## Test Results

20/20 queries pass (100%):

| Query | Top Result | Score |
|-------|-----------|-------|
| "is the person still alive" | `uid_master.res_dod` | 0.569 |
| "person from another country" | `uid_master.isforeigner` | 0.373 |
| "person moved to new house" | `uid_his_address` | 0.232 |
| "who registered this aadhaar" | `registrar_code` | 0.498 |
| "resident birth year" | `uid_master.res_dob_year` | 0.485 |
| "phone number of resident" | `res_mobile_num_hash` | 0.541 |
| "parent's aadhaar" | `res_guardian_uid` | 0.510 |
| "has the aadhaar expired" | `uid_expiry_date` | 0.425 |

## LLM Integration (GLM-5.2-FP8)

Stage 2 uses GLM-5.2-FP8, a reasoning model served via vLLM at `http://10.10.109.101:32320/glm52/v1`.

### LLM Client (`llm_client.py`)

```python
from llm_client import LLMClient

llm = LLMClient()

# Simple chat
answer = llm.chat("What is 2+2?")

# With system prompt + reasoning
answer, reasoning = llm.chat("...", system="You are a SQL expert", return_reasoning=True)

# JSON output
result = llm.chat_json("Rank these items by relevance...")

# Re-ranking (Stage 2 of retrieval)
ranked = llm.rerank("is the person still alive", [
    {"name": "res_dod", "text": "Date of death. NULL for living."},
    {"name": "res_dob_year", "text": "Year of birth."},
])

# SQL generation
sql = llm.generate_sql("Find all residents who died in 2024", context="...")
```

### Key LLM characteristics:
- **Reasoning model**: Thinks first (in `reasoning` field), then answers (in `content` field)
- **Response time**: 0.7-8s depending on complexity
- **Max context**: 524,288 tokens
- **No API key needed** (internal vLLM deployment)

## Limitations & Upgrade Path

### Current limitations:
1. **Stage 1 synonyms are manual** — new domain terms require manual addition
2. **Stage 1 enrichment is one-time** — new entities need manual question writing
3. **No fuzzy matching** — typos won't match (removed character n-grams due to noise)
4. **Stage 2 is sequential** — one LLM call per query (3-8s latency)
5. **Small corpus advantage** — works well with 217 entities; may degrade at scale

### Upgrade to true semantic search (when internet is available):

```bash
pip install sentence-transformers faiss-cpu
```

```python
# Replace TfidfVectorizer with:
from sentence_transformers import SentenceTransformer
import faiss

model = SentenceTransformer('all-MiniLM-L6-v2')  # 384-dim embeddings

# Embed all entities
embeddings = model.encode([doc_text for _, doc_text in documents])

# Build FAISS index
index = faiss.IndexFlatIP(384)
index.add(embeddings.astype('float32'))

# Search
query_vec = model.encode([query]).astype('float32')
scores, indices = index.search(query_vec, top_k)
```

This would give:
- True semantic similarity (no manual synonyms needed)
- Fuzzy matching (typos, paraphrasing)
- Better scalability (ANN search vs. brute-force cosine)
- Stage 2 LLM re-ranking could still be used on top for maximum precision

## Files

| File | Purpose |
|------|---------|
| `llm_client.py` | GLM-5.2-FP8 API client: chat, JSON output, re-ranking, SQL generation |
| `graph_rag_index.json` | The index: 217 entities, 343 relationships, 5 communities, 321 text units (227 original + 94 enriched) |
| `graph_rag_vector_retriever.py` | Two-stage retriever: TF-IDF (Stage 1) + LLM re-ranking (Stage 2, optional) + graph expansion |
| `graph_rag_architecture.md` | This document — how the search works |
| `graph_rag_retriever.py` | Original keyword-based retriever (deprecated, use vector_retriever instead) |
| `graph_rag_visualization.html` | Interactive visualization |

## Usage

```python
from graph_rag_vector_retriever import VectorGraphRAG
from llm_client import LLMClient

retriever = VectorGraphRAG()

# Stage 1 only (fast, <100ms)
results = retriever.search("is the person still alive", mode="hybrid")

# Two-stage: TF-IDF + LLM re-ranking (3-8s, higher precision)
results = retriever.search("is the person still alive", mode="hybrid", use_llm_rerank=True)

# Get table context (all columns + joins)
ctx = retriever.get_table_context("uid_origin_tracker_enriched")

# Find join path
jp = retriever.get_join_path("uid_master", "uid_address")

# Debug a query (see token expansion, IDF weights, scores)
debug = retriever.debug_query("where does the person live")

# Direct LLM usage
llm = LLMClient()
sql = llm.generate_sql("Find residents who died in 2024", context="...")
answer = llm.chat("Explain what res_dod means")
```
