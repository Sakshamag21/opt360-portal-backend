# Knowledge Graph — `strot.mysql_uid_v2`

> Structured graph of tables, columns, relationships, and shared concepts in the `mysql_uid_v2` schema.
> Designed for text-to-SQL agent navigation. Updated alongside `relationship.md`.

---

## Visual Graph (Mermaid)

```mermaid
graph TB
    %% Table nodes
    UM["🟦 uid_master<br/>Current State<br/>~1.46B rows · 30 cols"]
    UHM["🟨 uid_his_master<br/>Demographic History<br/>~2.87B rows · 28 cols"]
    UA["🟦 uid_address<br/>Current Address<br/>~1.46B rows · 31 cols"]
    UHA["🟨 uid_his_address<br/>Address History<br/>~1.51B rows · 32 cols"]
    UOT["🟥 uid_origin_tracker_enriched<br/>Enrolment Tracker<br/>~3.29B rows · 68 cols"]

    %% Relationships (edges)
    UM -->|"1:N · uid + shard_hint"| UHM
    UM -->|"1:1 · uid + shard_hint"| UA
    UA -->|"1:N · uid + shard_hint"| UHA
    UOT -->|"1:N · uid + eid + shard_hint"| UHM
    UOT -->|"1:N · uid + eid + shard_hint"| UHA
    UHM -.->|"1:N · uid + eid + shard_hint<br/>(cross-correlation)"| UHA

    %% Styling
    classDef current fill:#dbeafe,stroke:#2563eb,stroke-width:2px
    classDef history fill:#fef3c7,stroke:#d97706,stroke-width:2px
    classDef tracker fill:#fee2e2,stroke:#dc2626,stroke-width:2px

    class UM,UA current
    class UHM,UHA history
    class UOT tracker
```

### Legend

| Color | Table Type | Meaning |
|-------|-----------|---------|
| 🟦 Blue | Current state | Live, current data — query these for the latest state |
| 🟨 Yellow | History | Historical snapshots — query these for change history |
| 🟥 Red | Tracker | Enrolment event metadata — query for who/when/how/what changed |

| Line Style | Meaning |
|-----------|---------|
| ──▶ Solid | Direct parent-child relationship (current → history, or tracker → history) |
| ┄┄▶ Dashed | Cross-table correlation (join to enrich data, not a direct dependency) |

---

## Node Details

### uid_master
| Property | Value |
|----------|-------|
| Full reference | `strot.mysql_uid_v2.uid_master` |
| Type | Current state (live) |
| Row count | ~1,455,874,640 |
| Columns | 30 |
| PK | `uid_master_key` (bigint) |
| Join key | `uid` (varchar, encrypted) |
| Partition key | `shard_hint` (varchar) |
| Unique columns | `isforeigner`, `nationality_code`, `uid_expiry_date`, `res_dod` (date of death) |
| Context | [md](./strot.mysql_uid_v2.uid_master.md) · [yaml](./strot.mysql_uid_v2.uid_master.yaml) |

### uid_his_master
| Property | Value |
|----------|-------|
| Full reference | `strot.mysql_uid_v2.uid_his_master` |
| Type | History (demographic) |
| Row count | ~2,874,468,722 |
| Columns | 28 |
| PK | `uid_his_key` (bigint) |
| Join keys | `uid` (to uid_master), `eid` (to uid_origin_tracker / uid_his_address) |
| Partition key | `shard_hint` |
| Unique column | `eid` (not in uid_master) |
| Missing vs uid_master | `isforeigner`, `nationality_code`, `uid_expiry_date` |
| Context | [md](./strot.mysql_uid_v2.uid_his_master.md) · [yaml](./strot.mysql_uid_v2.uid_his_master.yaml) |

### uid_address
| Property | Value |
|----------|-------|
| Full reference | `strot.mysql_uid_v2.uid_address` |
| Type | Current state (address) |
| Row count | ~1,455,878,397 |
| Columns | 31 |
| PK | `addr_key` (bigint) |
| Join key | `uid` (varchar, encrypted) |
| Partition key | `shard_hint` |
| Unique columns | All `res_addr_*` geographic hierarchy columns, `res_addr_pincode` |
| Context | [md](./strot.mysql_uid_v2.uid_address.md) · [yaml](./strot.mysql_uid_v2.uid_address.yaml) |

### uid_his_address
| Property | Value |
|----------|-------|
| Full reference | `strot.mysql_uid_v2.uid_his_address` |
| Type | History (address) |
| Row count | ~1,510,130,147 |
| Columns | 32 |
| PK | `his_addr_key` (bigint) |
| Join keys | `uid` (to uid_address), `eid` (to uid_origin_tracker / uid_his_master) |
| Partition key | `shard_hint` |
| Unique column | `eid` (not in uid_address) |
| Context | [md](./strot.mysql_uid_v2.uid_his_address.md) · [yaml](./strot.mysql_uid_v2.uid_his_address.yaml) |

### uid_origin_tracker_enriched
| Property | Value |
|----------|-------|
| Full reference | `strot.mysql_uid_v2.uid_origin_tracker_enriched` |
| Type | Enrolment tracker (event log) |
| Row count | ~3,292,012,027 |
| Columns | 68 |
| PK | `tracker_key` (bigint) |
| Join keys | `uid` (to all tables), `eid` (to history tables) |
| Partition key | `shard_hint` (**mandatory** — full scans time out) |
| Unique columns | `registrar_code`, `ea_code`, `operator_id`, `supervisor_id`, `enr_mode`, `enr_type`, `enr_status`, `update_ind`, `reject_ind`, `source`, `packet_version`, all 28 `updt_*` varbinary flags |
| Context | [md](./strot.mysql_uid_v2.uid_origin_tracker_enriched.md) · [yaml](./strot.mysql_uid_v2.uid_origin_tracker_enriched.yaml) |

---

## Edge Details (Relationships)

### Edge 1: uid_master → uid_his_master

| Property | Value |
|----------|-------|
| Type | One-to-Many (1:N) |
| Join keys | `uid`, `shard_hint` |
| Semantic | When a UID is updated in `uid_master`, the previous version is archived to `uid_his_master`. ~2.77 history rows per UID on average. |
| Direction | uid_master (parent, current) → uid_his_master (child, history) |

### Edge 2: uid_master → uid_address

| Property | Value |
|----------|-------|
| Type | One-to-One (1:1) |
| Join keys | `uid`, `shard_hint` |
| Semantic | `uid_master` has demographic/identity data, `uid_address` has address data. Together they form the complete current resident record. Near-exact 1:1 (both ~1.46B rows). |
| Direction | uid_master (identity) ↔ uid_address (address) — bidirectional |

### Edge 3: uid_address → uid_his_address

| Property | Value |
|----------|-------|
| Type | One-to-Many (1:N) |
| Join keys | `uid`, `shard_hint` |
| Semantic | When a UID's address is updated in `uid_address`, the previous version is archived to `uid_his_address`. |
| Direction | uid_address (parent, current) → uid_his_address (child, history) |

### Edge 4: uid_origin_tracker_enriched → uid_his_master

| Property | Value |
|----------|-------|
| Type | One-to-Many (1:N) |
| Join keys | `uid`, `eid`, `shard_hint` |
| Semantic | The tracker records the enrolment event metadata (who/when/how/what changed). `uid_his_master` stores the resulting demographic snapshot. Joining links the event to its outcome. |
| Direction | uid_origin_tracker (event) → uid_his_master (snapshot) |

### Edge 5: uid_origin_tracker_enriched → uid_his_address

| Property | Value |
|----------|-------|
| Type | One-to-Many (1:N) |
| Join keys | `uid`, `eid`, `shard_hint` |
| Semantic | Same as Edge 4, but for address snapshots. The tracker's `updt_address` flag (`b'11'`) indicates the address was changed in this event. |
| Direction | uid_origin_tracker (event) → uid_his_address (snapshot) |

### Edge 6: uid_his_master ↔ uid_his_address (cross-correlation)

| Property | Value |
|----------|-------|
| Type | One-to-Many (1:N) |
| Join keys | `uid`, `eid`, `shard_hint` |
| Semantic | For the same enrolment event (`eid`), both demographic and address history snapshots exist. Joining them gives a complete picture of what changed in that event. |
| Direction | uid_his_master (demographic snapshot) ↔ uid_his_address (address snapshot) — bidirectional |
| Line style | Dashed (correlation, not dependency) |

---

## Column Flow Graph

> Which columns flow between tables. Columns in **bold** are join keys.

```
                    ┌─────────────────────┐
                    │ uid_origin_tracker  │
                    │    _enriched        │
                    │                     │
                    │  tracker_key (PK)   │
                    │  uid ◄═══════════════════════════════╗
                    │  eid ◄═════════════════════╗         ║
                    │  shard_hint ◄══════════════════════════╣
                    │  enr_date           ║         ║         ║
                    │  enr_type           ║         ║         ║
                    │  enr_mode           ║         ║         ║
                    │  enr_status         ║         ║         ║
                    │  registrar_code     ║         ║         ║
                    │  ea_code            ║         ║         ║
                    │  operator_id        ║         ║         ║
                    │  update_ind         ║         ║         ║
                    │  reject_ind         ║         ║         ║
                    │  updt_* (28 flags)  ║         ║         ║
                    └─────────────────────┘         ║         ║
                           │ eid                   ║         ║
                           │ uid + shard_hint      ║         ║
                           ▼                       ▼         ║
              ┌──────────────────────┐  ┌──────────────────────┐
              │  uid_his_master      │  │  uid_his_address     │
              │                      │  │                      │
              │  uid_his_key (PK)    │  │  his_addr_key (PK)   │
              │  uid ◄══════════════════════════════════════════╣
              │  eid ◄══════════════════════════════════► eid   ║
              │  shard_hint ◄═══════════════════════════════════╝
              │  uid_status_key      │  │  res_addr_* (geo)    │
              │  res_dob_year        │  │  res_addr_pincode    │
              │  verification_type   │  │                      │
              │  poi / poa / pob     │  │                      │
              │  biometric_flag      │  │                      │
              │  isnri               │  │                      │
              └──────────┬───────────┘  └──────────┬───────────┘
                         │ uid                     │ uid
                         │ shard_hint              │ shard_hint
                         ▼                         ▼
              ┌──────────────────────┐  ┌──────────────────────┐
              │  uid_master          │  │  uid_address         │
              │                      │  │                      │
              │  uid_master_key (PK) │  │  addr_key (PK)       │
              │  uid ◄══════════════════════════════════════════╗
              │  shard_hint ◄═══════════════════════════════════╝
              │  uid_status_key      │  │  res_addr_* (geo)    │
              │  res_dob_year        │  │  res_addr_pincode    │
              │  verification_type   │  │                      │
              │  poi / poa / pob     │  │                      │
              │  isforeigner ✦       │  │                      │
              │  nationality_code ✦  │  │                      │
              │  uid_expiry_date ✦   │  │                      │
              │  res_dod ✦           │  │                      │
              └──────────────────────┘  └──────────────────────┘

              ✦ = unique to this table (not in history or other tables)
              ◄═══► = join key (shared column)
```

---

## Column Ownership Matrix

> Which table owns which column group. ✓ = present, ✗ = absent.

| Column / Column Group | uid_master | uid_his_master | uid_address | uid_his_address | uid_origin_tracker |
|-----------------------|:----------:|:--------------:|:-----------:|:---------------:|:------------------:|
| **uid** (join key) | ✓ | ✓ | ✓ | ✓ | ✓ |
| **shard_hint** (partition) | ✓ | ✓ | ✓ | ✓ | ✓ |
| **eid** (enrolment ID) | ✗ | ✓ | ✗ | ✓ | ✓ |
| Surrogate PK | `uid_master_key` | `uid_his_key` | `addr_key` | `his_addr_key` | `tracker_key` |
| `uid_status_key` | ✓ | ✓ | ✗ | ✗ | ✗ |
| `res_dob_year` | ✓ | ✓ | ✗ | ✗ | ✗ |
| `verification_type` / `enr_type` | ✓ (`verification_type`) | ✓ | ✗ | ✗ | ✓ (`enr_type`) |
| `poi` / `poa` / `pob` | ✓ | ✓ | ✗ | ✗ | ✗ (but `updt_poi/poa/pob` flags) |
| `info_shre_cnsnt` | ✓ | ✓ | ✗ | ✗ | ✗ (but `updt_info_sharing_cnst`) |
| `biometric_flag` | ✓ | ✓ | ✗ | ✗ | ✗ (but `updt_biometrics`) |
| `isnri` | ✓ | ✓ | ✗ | ✗ | ✗ (but `updt_nri`) |
| `res_dod` | ✓ | ✗ (NULL) | ✗ | ✗ | ✗ (but `updt_resident_dod`) |
| `isforeigner` | ✓ | ✗ | ✗ | ✗ | ✗ (but `updt_foreign_resident`) |
| `nationality_code` | ✓ | ✗ | ✗ | ✗ | ✗ (but `updt_nationality`) |
| `uid_expiry_date` | ✓ | ✗ | ✗ | ✗ | ✗ |
| `res_addr_*` (geo hierarchy) | ✗ | ✗ | ✓ | ✓ | ✗ (but `updt_address`) |
| `res_addr_pincode` | ✗ | ✗ | ✓ | ✓ | ✗ |
| `res_f_addr_line1/2/3` | ✗ | ✗ | ✓ (>99% NULL) | ✓ (>99% NULL) | ✗ |
| `registrar_code` / `ea_code` | ✗ | ✗ | ✗ | ✗ | ✓ |
| `operator_id` / `supervisor_id` | ✗ | ✗ | ✗ | ✗ | ✓ |
| `enr_mode` / `enr_status` | ✗ | ✗ | ✗ | ✗ | ✓ |
| `update_ind` / `reject_ind` | ✗ | ✗ | ✗ | ✗ | ✓ |
| `source` / `packet_version` | ✗ | ✗ | ✗ | ✗ | ✓ |
| `updt_*` (28 varbinary flags) | ✗ | ✗ | ✗ | ✗ | ✓ |
| `created_by` / `creation_date` | ✓ | ✓ | ✓ | ✓ | ✓ |
| `last_updated_by` / `last_updated_date` | ✓ | ✓ | ✓ | ✓ | ✓ |

---

## Concept Layer (Cross-cutting)

> Shared concepts that span multiple tables. These are semantic groups, not physical columns.

```
┌─────────────────────────────────────────────────────────────────┐
│                     SHARED CONCEPTS                              │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Identity     │  │ Enrolment    │  │ Update Tracking      │  │
│  │              │  │              │  │                      │  │
│  │ uid (all)    │  │ eid (his+trk)│  │ updt_* flags (trk)   │  │
│  │ shard_hint   │  │ enr_date     │  │ update_ind (trk)     │  │
│  │  (all)       │  │  (trk)       │  │ reject_ind (trk)     │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Demographics │  │ Address      │  │ Audit                │  │
│  │              │  │              │  │                      │  │
│  │ uid_status   │  │ res_addr_*   │  │ created_by (all)     │  │
│  │  (master+his)│  │  (addr+his)  │  │ creation_date (all)  │  │
│  │ res_dob_year │  │ pincode      │  │ last_updated_by(all) │  │
│  │  (master+his)│  │  (addr+his)  │  │ last_updated_date    │  │
│  │ poi/poa/pob  │  │              │  │  (all)               │  │
│  │  (master+his)│  │              │  │                      │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ PII          │  │ Deprecated   │  │ Data Quality         │  │
│  │              │  │              │  │                      │  │
│  │ uid (enc)    │  │ bnk_shre_    │  │ state name variants  │  │
│  │ guardian_uid │  │  cnsnt (NULL)│  │  (Orissa/Odisha)     │  │
│  │  (enc)       │  │ other_proof  │  │ country code variants│  │
│  │ mobile_hash  │  │  (NULL)      │  │  (356/India/001)     │  │
│  │ email_hash   │  │ res_f_addr_  │  │ literal 'NULL' str   │  │
│  │              │  │  line* (NULL)│  │ 'N' legacy values    │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Query Path Finder

> Given a data need, which tables and join path to use.

| Data Need | Start Table | Join Path | Join Keys |
|-----------|-------------|-----------|-----------|
| Current demographic info | `uid_master` | — | — |
| Current address | `uid_address` | — | — |
| Current demo + address | `uid_master` | → `uid_address` | `uid`, `shard_hint` |
| Demographic change history | `uid_his_master` | — | filter by `uid` |
| Address change history | `uid_his_address` | — | filter by `uid` |
| Full history (demo + address) | `uid_his_master` | → `uid_his_address` | `uid`, `eid`, `shard_hint` |
| What fields changed in an update | `uid_origin_tracker_enriched` | — | filter by `uid`, check `updt_*` |
| Who enrolled/updated and when | `uid_origin_tracker_enriched` | — | filter by `uid` |
| Event + resulting snapshots | `uid_origin_tracker_enriched` | → `uid_his_master` + `uid_his_address` | `uid`, `eid`, `shard_hint` |
| Current + history (demo) | `uid_master` | → `uid_his_master` | `uid`, `shard_hint` |
| Current + history (address) | `uid_address` | → `uid_his_address` | `uid`, `shard_hint` |
| Everything for a UID | `uid_master` | → `uid_address` → `uid_his_master` → `uid_his_address` → `uid_origin_tracker_enriched` | `uid`, `shard_hint` (+ `eid` for tracker/history) |

---

## Changelog

| Date | Change |
|------|--------|
| 2026-10-09 | Initial creation. 5 tables, 6 edges, column ownership matrix, concept layer, query path finder. |
