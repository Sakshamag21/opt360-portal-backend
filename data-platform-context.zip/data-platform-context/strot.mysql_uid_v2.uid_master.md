# Trino Table Context Layer — `strot.mysql_uid_v2.uid_master`

> Context layer for text-to-SQL. Catalog: `strot` · Schema: `mysql_uid_v2` · Table: `uid_master`

## Quick Facts

| Property | Value |
|----------|-------|
| Full table reference | `strot.mysql_uid_v2.uid_master` |
| Approximate row count | **1,455,874,640** (~1.46 billion) |
| Column count | 30 |
| Source connector | MySQL , exposed via Trino |
| Data date range | 2010-08-21 → 2026-10-09 (active, updated daily) |
| Read host | `10.10.116.39` |
| Write hosts | `10.10.116.75`, `10.10.118.10` |

> ⚠️ **Large table.** Always use `LIMIT`, partition/primary-key filters, or indexed predicates. Avoid `SELECT *` without a limit.

---

## Column Dictionary

| # | Column | Type | Description | Notes | Importance Based on Usage|
|---|--------|------|-------------|-------|--------------------------|
| 1 | `uid_master_key` | bigint | Surrogate primary key | Range `1`–`21,337,732`. **Not contiguous** (1.46B rows vs 21M max key → heavily reused/sharded). Useful for sampling with `WHERE uid_master_key <= N`. | Low|
| 2 | `uid` | varchar | Encrypted UID (Aadhaar number) | Base64-like encrypted blob (e.g. `+/nxcDCZlrItt6o+...`). **Never** store/return in plaintext. PII. | High|
| 3 | `uid_status_key` | integer | Status code of the UID | See [uid_status_key codes](#uid_status_key). `1` = active/issued (97.8% of rows). | Low|
| 4 | `res_dob_year` | varchar | Year of birth of resident | Stored as text. Range `1`–`2095`; bulk concentrated 1980s–2010s. Cast with `CAST(res_dob_year AS integer)` when filtering. The dob year greater than the current year is wrong or anomalous| High|
| 5 | `res_guardian_uid` | varchar | Encrypted UID of guardian, mostly available for child enrolment or Head of Family enrolment| Mostly `NULL` for adults; populated for child enrolments. PII (encrypted). | Medium|
| 6 | `res_guardian_eid` | varchar | Encrypted enrolment ID of guardian | Mostly `NULL`. PII (encrypted). | Low|
| 7 | `res_mobile_num_hash` | varchar | SHA-256 hash of resident's mobile number | Hex string (64 chars). PII (hashed). | Low|
| 8 | `res_email_id_hash` | varchar | SHA-256 hash of resident's email ID | Hex string (64 chars). Largely `NULL`. PII (hashed). | Low|
| 9 | `bnk_shre_cnsnt` | varchar | Bank-share consent flag | **Entirely NULL** in current data (deprecated column). | Low|
| 10 | `info_shre_cnsnt` | varchar | Info-share consent flag | `'1'` = consented (92.8%), `'0'` = not consented (7.2%). | Low|
| 11 | `verification_type` | varchar | Type of demographic verification | `'D'` = demographic (83.6%), `'H'` = head-of-family/biometric-based (15.4%), `'I'` = iris, `NULL` (0.9%). See [verification_type](#verification_type). | Medium|
| 12 | `poi` | varchar | Proof of Identity document submitted | Free-text document name (e.g. "Voter ID", "PAN Card"). `NULL` for ~17.8% (HoF-based). See [poi](#poi). | High|
| 13 | `poa` | varchar | Proof of Address document submitted | Free-text document name (e.g. "Voter ID", "Ration Card"). `NULL` for ~18.5%. See [poa](#poa). | High|
| 14 | `pob` | varchar | Proof of Date of Birth document submitted | Free-text document name. `NULL` for ~81.8% (DOB is optional). See [pob](#pob). | High|
| 15 | `hof_proof` | varchar | Head-of-Family relationship proof | Free-text. `NULL` for ~82.7% (only for HoF-linked enrolments). | Medium|
| 16 | `other_proof` | varchar | Other supporting proof | **Entirely NULL** in current data (deprecated column). | Low| 
| 17 | `res_lang_code` | varchar | Language code of resident's preferred language | Numeric-string code (e.g. `'06'`=Hindi, `'23'`=English). See [res_lang_code](#res_lang_code). | Medium| 
| 18 | `biometric_flag` | varchar | Whether biometrics were captured | `'1'` = yes (92.3%), `'0'` = no (7.7%). | Medium|
| 19 | `biometric_exception_ind` | boolean | Biometric exception indicator | `false` = no exception (71.5%), `NULL` (27.7%), `true` = exception (0.9%). | Low|
| 20 | `isnri` | varchar | Is Non-Resident Indian flag | `'0'` = no (99.996%), `'1'` = yes (~60k rows). | Medium|
| 21 | `res_dod` | timestamp(6) | Date of death of resident | `NULL` for living residents. Present values range 0006-07-09 → 2026-07-04. | High|
| 22 | `issue_date` | timestamp(6) | Date the UID was issued | Range 2010-08-21 → 2026-10-09. | High|
| 23 | `created_by` | varchar | Source/creator of the record | E.g. `enrolserver`, `enrolserver_151`, or ETL CSV filenames like `uid_master-ETL-1100-20160427.csv`. | Low|
| 24 | `creation_date` | timestamp(6) | Record creation timestamp | Range 2010-08-21 → 2026-10-09. | Medium|
| 25 | `last_updated_by` | varchar | Last updater | Typically `enrolserver`. | Medium|
| 26 | `last_updated_date` | timestamp(6) | Last update timestamp | Range 2010-08-21 → 2026-10-09. | High|
| 27 | `shard_hint` | varchar | Sharding hint, bsaically fisrt 2 digit of every adhaar number/UID, used for efficient quering as the MYSQL Sharding is done based on this | E.g. `'45'`. Used for data distribution. | High|
| 28 | `isforeigner` | varchar | Is foreigner flag | `NULL` (99.997%), `'1'` = yes (~47.7k rows). | Low|
| 29 | `nationality_code` | varchar | ISO country code of nationality | `NULL` for Indian nationals. Otherwise ISO-3166 codes (US, PK, NP, etc.) or numeric codes (`356`=India ISO-3166 numeric). See [nationality_code](#nationality_code). | Medium|
| 30 | `uid_expiry_date` | timestamp(6) | UID expiry date | Range 2024-08-24 → 2036-10-05 (10-year validity window). `NULL` for older/expired. | Low|

---

## Categorical Value Mappings

### uid_status_key

| Code | Count | % | Meaning (inferred) |
|------|-------|---|--------------------|
| 1 | 1,424,122,482 | 97.8% | Active / Issued |
| 99 | 27,669,280 | 1.9% | Deactivated / Cancelled |
| 8 | 1,494,506 | 0.1% | - |
| 3 | 1,063,388 | <0.1% | - |
| 43 | 410,401 | <0.1% | — |
| 6 | 384,229 | <0.1% | — |
| 7 | 325,560 | <0.1% | — |
| 28 | 242,921 | <0.1% | — |
| 50 | 64,857 | <0.1% | — |
| 4 | 56,886 | <0.1% | — |
| 33 | 30,886 | <0.1% | — |
| (others) | <10k each | — | Various transitional states |

> Codes `1` (active), `99` (deactivated), are the most semantically useful. Treat non-`1` codes carefully — exact meanings should be confirmed with the data dictionary.

### verification_type

| Code | Count | % | Meaning |
|------|-------|---|---------|
| `D` | 1,216,838,573 | 83.6% | Demographic verification (document-based) |
| `H` | 224,336,995 | 15.4% | Head-of-Family / biometric-based verification |
| `I` | 977,408 | <0.1% | Iris-based verification |
| `NULL` | 13,721,664 | 0.9% | Unspecified |

### info_shre_cnsnt
- `'1'` (1,350,902,849)
- `'0'` (104,971,791)

### biometric_flag
- `'1'` (1,343,861,311) = biometrics captured
- `'0'` (112,013,329) = biometrics not captured

### biometric_exception_ind
- `false` (1,040,816,136) = no biometric exception
- `NULL` (402,667,803) = not applicable
- `true` (12,390,701) = biometric exception (e.g. missing fingers)

### isnri / isforeigner
- `isnri`: `'0'` (99.996%), `'1'` (~60,468 NRI)
- `isforeigner`: `NULL` (Indian nationals, 99.997%), `'1'` (~47,743 foreigners)

### res_lang_code

No offical Mapping Available, ask the user about the mapping while using this column

| Code | Count |
|------|-------|
| `06` | 703,307,594 |
| `23` | 180,842,104 |
| `21` | 101,970,008 |
| `13` |  98,047,297 |
| `20` |  83,795,910 |
| `07` |  74,463,840 |
| `05` |  69,919,026 |
| `02` |  59,681,736 |
| `15` |  45,653,710 |
| `16` |  23,769,881 |
| `11`, `22`, `01`, `14`, `09`, `12` | smaller |

> A few rows contain Devanagari-digit variants (e.g. `०६`, `२०`) — data-quality artifacts. Normalize with `CAST` or `REPLACE` if grouping is needed.

### nationality_code
`NULL` for the vast majority (Indian nationals). For non-Indian, values are ISO-3166 alpha-2 (US, PK, NP, CA, GB, AU, JP, …) or numeric (`356` = India). Top non-null: US (~15.8k), `356` (~12.3k), PK (~8.4k), NP (~4.1k).

### poi (Proof of Identity) — top values
Voter ID, NPR Process, Ration/PDS Photo Card, Photo ID by Educational Institution, PAN Card, Passport, Driving License, Certificate of Identity (various issuers), etc. `NULL` for HoF-based enrolments. **Free-text** — exact phrasing varies; prefer `LIKE` matching.

### poa (Proof of Address) — top values
Voter ID, Ration Card, NPR Process, Certificate of Address (Village Panchayat), Bank Statement/Passbook, Electricity Bill, Passport, Driving License, etc. `NULL` for ~18.5%. **Free-text**.

### pob (Proof of Date of Birth) — top values
Birth Certificate, PAN Card, Marksheet (Govt Board/University), SSLC Book/Certificate, Passport, School Leaving Certificate, etc. `NULL` for ~81.8% (DOB proof is optional).

---

## Date Ranges

| Column | Min | Max |
|--------|-----|-----|
| `issue_date` | 2010-08-21 18:55:49 | 2026-10-09 02:10:12 |
| `creation_date` | 2010-08-21 18:55:49 | 2026-10-09 02:10:12 |
| `last_updated_date` | 2010-08-21 23:13:24 | 2026-10-09 02:10:13 |
| `res_dod` (date of death) | 0006-07-09 | 2026-07-04 |
| `uid_expiry_date` | 2024-08-24 | 2036-10-05 |

---

## Sample Row (anonymized shape)

```
uid_master_key   : 1224199
uid              : <encrypted base64 blob>
uid_status_key   : 1
res_dob_year     : '1994'
res_guardian_uid : NULL
res_mobile_num_hash : <64-char hex SHA-256>
info_shre_cnsnt  : '1'
verification_type: 'D'
poi              : 'Voter ID'
poa              : 'Gas Connection Bill (not older than 3 months)'
res_lang_code    : '06'
biometric_flag   : '1'
isnri            : '0'
issue_date       : 2013-12-28 18:34:35
created_by       : 'uid_master-ETL-1100-20160427.csv'
last_updated_by  : 'enrolserver'
shard_hint       : '45'
```

---

## Querying Guidance/ Rules (text-to-SQL)

1. **Always scope queries.** With 1.46B rows, prefer:
   - `LIMIT N`
   - Use `shard_hint` for faster partition pruning 
   - Date filters on `creation_date` / `issue_date` / `last_updated_date`
   - Status filters (`WHERE uid_status_key = 1` for active records only)
2. **Avoid full-table aggregations** without a predicate; they scan the entire table.
3. **Free-text columns** (`poi`, `poa`, `pob`, `hof_proof`) use inconsistent phrasing — use `LIKE '%keyword%'` and `LOWER()`.
4. **Type casting:** `res_dob_year` is `varchar` — cast to integer for numeric comparisons.
5. **PII handling:** `uid`, `res_guardian_uid`, `res_guardian_eid` are encrypted; `res_mobile_num_hash`, `res_email_id_hash` are hashed. Never attempt decryption in SQL.
6. **Deprecated/empty columns:** `bnk_shre_cnsnt` and `other_proof` are entirely NULL — do not rely on them.
7. **Consent filtering:** use `info_shre_cnsnt = '1'` to restrict to residents who consented to info sharing.
8. **Read vs write:** run `SELECT` on read host `10.10.116.39`; No write is allowed on this table.
9. **Priority:** the importance is defined in the column dictionary, mostly problems are solved with High and Medium priority column 
