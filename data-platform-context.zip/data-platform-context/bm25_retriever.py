#!/usr/bin/env python3
"""
BM25 (Okapi BM25) Retriever for GraphRAG — numpy only, no external dependencies.

BM25 is the industry standard for lexical retrieval, outperforming TF-IDF in
virtually every IR benchmark (TREC, BEIR, etc.). Key advantages:

  1. Term frequency saturation — the 10th occurrence of a term adds less
     score than the 1st (TF-IDF is linear, so 10x occurrences = 10x weight)
  2. Document length normalization — longer documents aren't unfairly
     penalized (TF-IDF divides by total terms, which is cruder)
  3. Better IDF — Robertson-Sparck Jones IDF more aggressively downweights
     common terms

Okapi BM25 scoring formula:

  score(q, d) = Σ IDF(qi) * [ f(qi,d) * (k1 + 1) ] / [ f(qi,d) + k1 * (1 - b + b * |d|/avgdl) ]

  where:
    IDF(qi)     = log( (N - df(qi) + 0.5) / (df(qi) + 0.5) + 1 )
    f(qi, d)    = frequency of term qi in document d
    |d|         = length of document d (number of terms)
    avgdl       = average document length across all documents
    k1 = 1.2    = term frequency saturation parameter
    b  = 0.75   = document length normalization parameter

Usage:
  from bm25_retriever import BM25GraphRAG
  retriever = BM25GraphRAG()
  results = retriever.search("how do I find demographic history", mode="hybrid")
"""

import sys
import json
import re
import math
import textwrap
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np

# Reuse the tokenizer, synonyms, and index from the existing retriever
from graph_rag_vector_retriever import (
    INDEX_PATH, STOPWORDS, SYNONYM_GROUPS, SYNONYM_MAP,
    tokenize, expand_synonyms,
)


# ─── BM25 Vectorizer ─────────────────────────────────────────────────────────

class BM25Vectorizer:
    """
    Okapi BM25 implementation from scratch using only numpy.
    Same interface as TfidfVectorizer — drop-in replacement.

    Key differences from TF-IDF:
      - TF saturation: score(f) = f*(k1+1) / (f + k1*(...))  [saturates]
        vs TF-IDF: score(f) = f/total  [linear]
      - Length norm: (1 - b + b * |d|/avgdl)  [tunable]
        vs TF-IDF: L2 normalization  [fixed]
      - IDF: log((N - df + 0.5)/(df + 0.5) + 1)  [probabilistic]
        vs TF-IDF: log((N+1)/(df+1)) + 1  [heuristic]
    """

    def __init__(self, k1=1.2, b=0.75):
        """
        Args:
            k1: Term frequency saturation parameter (1.2 is standard).
                Higher = more saturation (more occurrences matter less).
                Lower = less saturation (more occurrences matter more).
            b:  Document length normalization parameter (0.75 is standard).
                1.0 = full normalization, 0.0 = no normalization.
        """
        self.k1 = k1
        self.b = b
        self.vocabulary = {}        # term → index
        self.idf = None             # numpy array of BM25 IDF values
        self.doc_freq = None        # term frequencies per doc: (n_docs × vocab_size)
        self.doc_lengths = None     # numpy array: length of each document
        self.avgdl = 0              # average document length
        self.doc_ids = []           # list of document IDs
        self.n_docs = 0

    def fit(self, documents):
        """
        Build the BM25 index from documents.

        Args:
            documents: list of (doc_id, text) tuples
        """
        self.doc_ids = [d[0] for d in documents]
        self.n_docs = len(documents)

        # Build vocabulary and document frequencies
        df = Counter()  # document frequency: how many docs contain each term
        doc_token_counts = []  # list of Counter objects (term → count in doc)

        for doc_id, text in documents:
            tokens = tokenize(text)
            tc = Counter(tokens)
            doc_token_counts.append(tc)
            for term in tc:
                df[term] += 1

        # Create vocabulary index
        self.vocabulary = {term: idx for idx, term in enumerate(sorted(df.keys()))}
        vocab_size = len(self.vocabulary)

        # Compute BM25 IDF: log((N - df + 0.5) / (df + 0.5) + 1)
        # The +1 inside the log prevents negative IDF values for very common terms
        self.idf = np.zeros(vocab_size, dtype=np.float64)
        for term, idx in self.vocabulary.items():
            n = self.n_docs
            d = df[term]
            self.idf[idx] = math.log((n - d + 0.5) / (d + 0.5) + 1)

        # Build document term frequency matrix (raw counts, not normalized)
        self.doc_freq = np.zeros((self.n_docs, vocab_size), dtype=np.float64)
        self.doc_lengths = np.zeros(self.n_docs, dtype=np.float64)

        for i, tc in enumerate(doc_token_counts):
            doc_len = sum(tc.values())
            self.doc_lengths[i] = doc_len
            for term, count in tc.items():
                idx = self.vocabulary[term]
                self.doc_freq[i, idx] = count

        # Average document length
        self.avgdl = float(np.mean(self.doc_lengths)) if self.n_docs > 0 else 0

        return self

    def transform_query(self, query):
        """
        Transform a query into a set of query terms (with synonyms expanded).
        Returns the list of query term indices in the vocabulary.
        """
        tokens = expand_synonyms(tokenize(query))
        # Get unique terms that exist in vocabulary
        query_terms = []
        seen = set()
        for t in tokens:
            if t in self.vocabulary and t not in seen:
                query_terms.append(self.vocabulary[t])
                seen.add(t)
        return query_terms

    def search(self, query, top_k=10):
        """
        Search documents by BM25 score.
        Returns list of (doc_id, score) tuples, sorted by score descending.
        """
        query_terms = self.transform_query(query)
        if not query_terms:
            return []

        scores = self._score(query_terms)

        # Get top-k
        top_indices = np.argsort(scores)[::-1][:top_k]
        results = []
        for idx in top_indices:
            if scores[idx] > 0:
                results.append((self.doc_ids[idx], float(scores[idx])))
        return results

    def search_batch(self, query, top_k=10):
        """Same as search but also returns the query terms for debugging."""
        query_terms = self.transform_query(query)
        if not query_terms:
            return [], query_terms
        scores = self._score(query_terms)
        top_indices = np.argsort(scores)[::-1][:top_k]
        results = [(self.doc_ids[idx], float(scores[idx])) for idx in top_indices if scores[idx] > 0]
        return results, query_terms

    def _score(self, query_term_indices):
        """
        Compute BM25 scores for all documents given query terms.

        BM25 score = Σ IDF(qi) * [ f(qi,d) * (k1+1) ] / [ f(qi,d) + k1*(1 - b + b*|d|/avgdl) ]
        """
        n_docs = self.n_docs
        scores = np.zeros(n_docs, dtype=np.float64)

        # Length normalization factor for each document: (1 - b + b * |d| / avgdl)
        if self.avgdl > 0:
            length_norm = 1 - self.b + self.b * (self.doc_lengths / self.avgdl)
        else:
            length_norm = np.ones(n_docs)

        for term_idx in query_term_indices:
            # Term frequency in each document
            tf = self.doc_freq[:, term_idx]  # shape: (n_docs,)

            # BM25 term frequency component: f * (k1 + 1) / (f + k1 * length_norm)
            # Only non-zero where the term appears
            tf_component = np.where(
                tf > 0,
                (tf * (self.k1 + 1)) / (tf + self.k1 * length_norm),
                0
            )

            # Add IDF-weighted score for this term
            scores += self.idf[term_idx] * tf_component

        return scores


# ─── BM25 GraphRAG Retriever ─────────────────────────────────────────────────

class BM25GraphRAG:
    """
    GraphRAG retriever with BM25 scoring instead of TF-IDF.

    Same interface as VectorGraphRAG — drop-in replacement.
    Combines:
      1. BM25 scoring for entity/text-unit retrieval (better than TF-IDF)
      2. Community reports for global search
      3. Graph expansion (entity neighborhoods) for context enrichment
      4. Domain synonym expansion for bridging the lexical gap
    """

    def __init__(self, index_path=INDEX_PATH, k1=1.2, b=0.75):
        with open(index_path, "r", encoding="utf-8") as f:
            self.index = json.load(f)

        # Build lookup maps
        self.entity_map = {e["entity_id"]: e for e in self.index["entities"]}

        # Build adjacency
        self.outgoing = defaultdict(list)
        self.incoming = defaultdict(list)
        for rel in self.index["relationships"]:
            self.outgoing[rel["source"]].append(rel)
            self.incoming[rel["target"]].append(rel)

        # Build text units lookup
        self.text_units_by_entity = defaultdict(list)
        for tu in self.index["text_units"]:
            self.text_units_by_entity[tu["entity_id"]].append(tu)

        # Build documents for BM25
        # Each document = entity name + description + all text units + properties
        documents = []
        for entity in self.index["entities"]:
            eid = entity["entity_id"]
            parts = [entity["name"], entity.get("description", "")]
            props = entity.get("properties", {})
            for k, v in props.items():
                if isinstance(v, str) and len(v) < 200:
                    parts.append(f"{k} {v}")
                elif isinstance(v, list):
                    parts.append(f"{k} {' '.join(str(x) for x in v[:10])}")
            for tu in self.text_units_by_entity.get(eid, []):
                parts.append(tu["text"])
            for comm in self.index["communities"]:
                if eid in comm.get("entity_ids", []):
                    parts.append(comm["title"])

            doc_text = " ".join(parts)
            documents.append((eid, doc_text))

        # Also add community reports as documents
        for comm in self.index["communities"]:
            doc_text = f"{comm['title']} {comm['summary']} {' '.join(comm.get('key_relationships', []))} {' '.join(comm.get('query_examples', []))}"
            documents.append((comm["community_id"], doc_text))

        # Build BM25 index
        self.vectorizer = BM25Vectorizer(k1=k1, b=b)
        self.vectorizer.fit(documents)

        # Store community tokens
        self.community_tokens = {}
        for comm in self.index["communities"]:
            self.community_tokens[comm["community_id"]] = set(tokenize(comm["summary"] + " " + comm["title"]))

        # Store query paths
        self.query_paths = self.index.get("query_paths", [])

    def search(self, query, mode="hybrid", top_k=10, use_llm_rerank=False, llm_top_k=5):
        """
        Unified search. Same interface as VectorGraphRAG.search().

        Two-stage retrieval when use_llm_rerank=True:
          Stage 1: BM25 retrieves top 30 candidates (fast, high recall)
          Stage 2: LLM re-ranks the top candidates by semantic relevance (slow, high precision)
        """
        result = {"query": query, "mode": mode}

        if mode in ("global", "hybrid"):
            result["global_results"] = self._global_search(query, top_k=3)

        if mode in ("local", "hybrid"):
            # Stage 1: BM25 retrieval (always runs)
            bm25_results = self._local_search(query, top_k=top_k * 3 if use_llm_rerank else top_k)

            # Stage 2: LLM re-ranking (optional)
            if use_llm_rerank and bm25_results:
                try:
                    from llm_client import LLMClient
                    llm = LLMClient()

                    candidates = bm25_results[:llm_top_k]
                    candidate_texts = []
                    for c in candidates:
                        desc = c.get("description", "")[:150]
                        name = c.get("name", "")
                        etype = c.get("type", "")
                        candidate_texts.append({
                            "name": name,
                            "text": f"[{etype}] {name}: {desc}",
                            "_original": c,
                        })

                    ranked = llm.rerank(query, candidate_texts)

                    reranked = []
                    for item in ranked:
                        original = item.get("_original", {})
                        original["bm25_score"] = original.pop("score", 0)
                        original["llm_score"] = item.get("llm_score", 0)
                        original["llm_rank"] = item.get("llm_rank", 0)
                        original["score"] = item.get("llm_score", 0) / 10.0
                        reranked.append(original)

                    reranked_ids = {r["entity_id"] for r in reranked}
                    for r in bm25_results:
                        if r["entity_id"] not in reranked_ids:
                            r["bm25_score"] = r.pop("score", 0)
                            r["llm_score"] = 0
                            r["llm_rank"] = 0
                            reranked.append(r)

                    result["local_results"] = reranked[:top_k]
                    result["llm_reranked"] = True
                except Exception as e:
                    result["local_results"] = bm25_results[:top_k]
                    result["llm_reranked"] = False
                    result["llm_error"] = str(e)
            else:
                result["local_results"] = bm25_results[:top_k]
                result["llm_reranked"] = False

        if mode == "hybrid":
            local_communities = set()
            for lr in result.get("local_results", []):
                eid = lr["entity_id"]
                for comm in self.index["communities"]:
                    if eid in comm.get("entity_ids", []):
                        local_communities.add(comm["community_id"])
            result["local_community_ids"] = list(local_communities)

        return result

    def _global_search(self, query, top_k=3):
        """Global search: find relevant community reports via BM25."""
        results = self.vectorizer.search(query, top_k=20)

        comm_results = []
        for doc_id, score in results:
            if doc_id.startswith("C"):
                comm = next((c for c in self.index["communities"] if c["community_id"] == doc_id), None)
                if comm:
                    comm_results.append((score, comm))

        comm_results.sort(key=lambda x: x[0], reverse=True)

        return [{
            "community_id": comm["community_id"],
            "title": comm["title"],
            "score": round(score, 4),
            "summary": comm["summary"],
            "entity_count": comm["entity_count"],
            "key_relationships": comm.get("key_relationships", []),
            "query_examples": comm.get("query_examples", []),
        } for score, comm in comm_results[:top_k]]

    def _local_search(self, query, top_k=10):
        """Local search: find relevant entities via BM25, expand to neighborhoods."""
        results = self.vectorizer.search(query, top_k=30)

        entity_results = []
        for doc_id, score in results:
            if doc_id.startswith("E") and doc_id in self.entity_map:
                entity = self.entity_map[doc_id]
                entity_results.append((score, entity))

        output = []
        seen = set()
        for score, entity in entity_results[:top_k]:
            eid = entity["entity_id"]
            if eid in seen:
                continue
            seen.add(eid)

            neighbors = []
            for rel in self.outgoing.get(eid, []):
                target = self.entity_map.get(rel["target"])
                if target and target["entity_id"] not in seen:
                    neighbors.append({
                        "entity_id": target["entity_id"],
                        "name": target["name"],
                        "type": target["type"],
                        "relationship": rel["type"],
                        "description": rel["description"],
                    })
            for rel in self.incoming.get(eid, []):
                source = self.entity_map.get(rel["source"])
                if source and source["entity_id"] not in seen:
                    neighbors.append({
                        "entity_id": source["entity_id"],
                        "name": source["name"],
                        "type": source["type"],
                        "relationship": rel["type"],
                        "description": rel["description"],
                    })

            matched_texts = [tu["text"][:150] for tu in self.text_units_by_entity.get(eid, [])[:2]]

            output.append({
                "entity_id": eid,
                "name": entity["name"],
                "type": entity["type"],
                "score": round(score, 4),
                "description": entity.get("description", ""),
                "properties": entity.get("properties", {}),
                "matched_texts": matched_texts,
                "neighbors": neighbors[:15],
            })
        return output

    def get_table_context(self, table_name):
        """Get full context for a specific table. Same as VectorGraphRAG."""
        table_name = table_name.lower()
        eid = None
        for e in self.index["entities"]:
            if e["type"] == "TABLE" and e["name"].lower() == table_name:
                eid = e["entity_id"]
                entity = e
                break
        if not eid:
            return None

        columns = []
        joins = []
        for rel in self.outgoing.get(eid, []):
            target = self.entity_map.get(rel["target"])
            if target and target["type"] == "COLUMN":
                columns.append({
                    "name": target["name"],
                    "description": target.get("description", ""),
                    "properties": target.get("properties", {}),
                })
            elif target and target["type"] == "TABLE":
                joins.append({
                    "target_table": target["name"],
                    "relationship": rel["type"],
                    "description": rel["description"],
                    "properties": rel.get("properties", {}),
                })

        community = None
        for comm in self.index["communities"]:
            if eid in comm.get("entity_ids", []):
                community = {"id": comm["community_id"], "title": comm["title"]}
                break

        return {
            "table": entity["name"],
            "description": entity.get("description", ""),
            "properties": entity.get("properties", {}),
            "columns": columns,
            "joins": joins,
            "community": community,
        }

    def get_join_path(self, from_table, to_table):
        """Find join path between two tables. Same as VectorGraphRAG."""
        from_table = from_table.lower()
        to_table = to_table.lower()

        from_eid = None
        to_eid = None
        for e in self.index["entities"]:
            if e["type"] == "TABLE":
                if e["name"].lower() == from_table:
                    from_eid = e["entity_id"]
                if e["name"].lower() == to_table:
                    to_eid = e["entity_id"]

        if not from_eid or not to_eid:
            return None

        for rel in self.outgoing.get(from_eid, []):
            if rel["target"] == to_eid and rel["type"] == "JOINS_TO":
                return {
                    "from": from_table, "to": to_table, "direct": True,
                    "join_keys": rel.get("properties", {}).get("join_keys", []),
                    "cardinality": rel.get("properties", {}).get("cardinality", ""),
                    "description": rel["description"],
                }
        for rel in self.outgoing.get(to_eid, []):
            if rel["target"] == from_eid and rel["type"] == "JOINS_TO":
                return {
                    "from": from_table, "to": to_table, "direct": True,
                    "join_keys": rel.get("properties", {}).get("join_keys", []),
                    "cardinality": rel.get("properties", {}).get("cardinality", ""),
                    "description": rel["description"],
                }

        for qp in self.query_paths:
            if qp.get("start", "").lower() == from_table:
                for j in qp.get("joins", []):
                    if j.get("to", "").lower() == to_table:
                        return {"from": from_table, "to": to_table, "direct": False,
                                "join_keys": j.get("on", []), "via_query_path": qp.get("need", "")}

        return {"from": from_table, "to": to_table, "direct": False, "join_keys": [],
                "note": "No direct join found. Use uid and shard_hint as common keys."}

    def debug_query(self, query):
        """Show what the BM25 vectorizer is doing with a query — for debugging."""
        tokens = tokenize(query)
        expanded = expand_synonyms(tokens)
        results, query_terms = self.vectorizer.search_batch(query, top_k=10)

        matched_terms = []
        for t in expanded:
            if t in self.vectorizer.vocabulary:
                idx = self.vectorizer.vocabulary[t]
                matched_terms.append((t, float(self.vectorizer.idf[idx])))

        matched_terms.sort(key=lambda x: x[1], reverse=True)

        return {
            "query": query,
            "raw_tokens": tokens,
            "expanded_tokens": sorted(expanded),
            "vocabulary_size": len(self.vectorizer.vocabulary),
            "matched_terms": [(t, round(idf, 3)) for t, idf in matched_terms[:20]],
            "n_query_terms": len(query_terms),
            "top_results": [(doc_id, round(score, 4)) for doc_id, score in results[:10]],
        }
