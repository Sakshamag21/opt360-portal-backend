# Table: mysql_uidmasterv1.uidmasterv1_1.station_reg_helper

## Overview

| Property | Value |
|----------|-------|
| **Catalog** | `mysql_uidmasterv1` |
| **Schema** | `uidmasterv1_1` |
| **Table** | `station_reg_helper` |
| **Full Reference** | `mysql_uidmasterv1.uidmasterv1_1.station_reg_helper` |
| **Row Count** | ~296K (295,720) |
| **Columns** | 35 |
| **Date Range** | 2024-03-12 → 2026-10-16 |
| **Source** | MySQL (exposed via Trino) |
| **Access** | Read-only via Trino at `10.10.116.39:8080` |

## Description

Station registration helper table for Aadhaar enrolment stations. Tracks **TPM (Trusted Platform Module)** hardware security keys, **EK (Endorsement Key)** certificates, machine attestation, and station-to-registrar/EA mapping. Each row represents one enrolment machine/station registration record.

This table is in a **different schema** (`mysql_uidmasterv1.uidmasterv1_1`) from both `strot.mysql_uid_v2` and `flink_stream.stream_enu`. It contains **device-level** registration data, not enrolment or telemetry data.

## Column Dictionary (35 columns)

### Identity & Status

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `station_reg_helper_key` | bigint | Surrogate PK | Range 1–~296K |
| `machine_id` | varchar(200) | Unique machine ID | Always populated. `<MFR><UUID>` |
| `is_tpm_present` | tinyint | TPM present? | 1=yes (79%), 0=no (21%) |
| `status` | varchar(30) | Registration status | NULL (63%), ALLOW_ONLY_WITH_TPM (21%), ACTIVE (15%), CLEANED_UP (0.07%) |
| `registrar_id` | varchar(30) | Registrar code | NULL ~63%. 3-digit. Matches other schemas |
| `enrollment_agency_code` | varchar(30) | EA code | NULL ~63%. 4-digit. Matches enu_uc_opt_action_v2 |
| `station_id` | varchar(30) | Station ID | NULL ~63%. Links to enu_uc_opt_action_v2 |

### Timestamps

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `creation_date` | timestamp(0) | Record created | 2024-03-12 → 2026-10-16. **Safe for min/max** |
| `last_updated_date` | timestamp(0) | Last updated | 2024-03-12 → 2026-10-16. **Safe for min/max** |
| `capture_timestamp` | timestamp(0) | TPM info captured | ⚠️ **Zero dates — never use min/max**. Use creation_date instead |
| `attested_at` | timestamp(0) | Attestation time | NULL ~99.9%. Only 351 rows (2026-10-06 → 2026-10-16) |

### TPM Hardware

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `tpm_pub_key` | varchar(1000) | TPM public key | Always populated (empty for no-TPM). Very long |
| `tpm_version` | tinyint | TPM version | NULL ~62%. Only `2` (TPM 2.0) |
| `manufacturer` | varchar(255) | TPM manufacturer | NULL ~69%. ⚠️ Trailing null bytes — use `trim()` |
| `vendor` | varchar(255) | TPM vendor/model | NULL ~69%. ⚠️ Binary byte contamination — very messy |
| `firmware_major` | integer | Firmware major version | NULL ~69%. Range 1–700 |
| `firmware_minor` | integer | Firmware minor version | NULL ~69% |
| `is_signature_mismatch` | tinyint | Signature mismatch? | 0=no (99.3%), 1=yes (0.7%) |

### EK (Endorsement Key)

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `ek_type` | varchar(255) | EK key type | NULL ~69%. Only `RSA` |
| `ek_pub` | varchar(65535) | EK public key | NULL ~69%. Very long |
| `ek_pub_hash` | varchar(65535) | EK pub key hash | NULL ~66%. Very long |
| `ek_cert` | varchar(65535) | EK certificate | NULL ~69%. Very long |
| `ek_cert_state` | varchar(16) | EK cert state | NULL ~99.9%. `VALID` (351) |
| `ek_cert_source` | varchar(16) | EK cert source | NULL ~99.9%. `NV` (341), `WINDOWS` (10) |

### AIK (Attestation Identity Key)

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `aik_pub_key` | varchar(2000) | AIK public key | NULL ~100% (only 347 rows) |
| `ak_name` | varchar(128) | Attestation Key name | NULL ~100% |
| `aik_opaque_private_key` | varchar(65535) | AIK opaque private key | NULL ~100%. Sensitive |
| `aik_opaque_public_key` | varchar(65535) | AIK opaque public key | NULL ~100% |

### Opaque Keys & Attestation

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `opaque_private_key` | varchar(65535) | Opaque private key | NULL ~65%. Sensitive |
| `opaque_public_key` | varchar(65535) | Opaque public key | NULL ~65% |
| `payload_pub_key` | varchar(2000) | Payload public key | NULL ~65% |
| `attestation_state` | varchar(16) | Attestation state | `NONE` (99.9%), `ATTESTED` (0.1%) |
| `attested_by` | varchar(64) | Who attested | NULL ~100%. `SELF` (349) |

### Audit

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `created_by` | varchar(60) | Creator | `EMS` (99.998%), `uidai` (6) |
| `last_updated_by` | varchar(60) | Last updater | Typically `EMS` |

## status Values

| Value | Count | % | Meaning |
|-------|-------|---|---------|
| `NULL` | 187K | 63.2% | Unassigned / legacy |
| `ALLOW_ONLY_WITH_TPM` | 63K | 21.4% | Station allowed only with TPM |
| `ACTIVE` | 45K | 15.3% | Station active |
| `CLEANED_UP` | 202 | 0.07% | Decommissioned |

## manufacturer Values

> ⚠️ Trailing null bytes (`\x00`) — use `trim(manufacturer)` to clean before grouping.

| Value | Count | Meaning |
|-------|-------|---------|
| `NULL` | 203K | No TPM |
| `INTC` | 37K | Intel |
| `AMD\x00` | 25K | AMD |
| `NTC\x00` | 13K | Nuvoton Technology |
| `STM ` | 9K | STMicroelectronics |
| `IFX\x00` | 9K | Infineon |
| `MSFT` | 37 | Microsoft (software TPM) |
| `QCOM` | 1 | Qualcomm |

## ⚠️ Data Quality Issues

| Issue | Column(s) | Rule |
|-------|-----------|------|
| **Zero dates** | `capture_timestamp` | MySQL `0000-00-00` values cause JDBC errors on `min()`/`max()`. Use `creation_date` instead |
| **Trailing null bytes** | `manufacturer` | Values like `AMD\x00`, `NTC\x00`, `IFX\x00`. Use `trim(manufacturer)` |
| **Binary byte contamination** | `vendor` | Contains `\x00`, `\x01` etc. Very messy — use `manufacturer` instead for grouping |
| **Long crypto text** | `tpm_pub_key`, `ek_cert`, `ek_pub`, `opaque_*_key` | Very long base64/PEM text. Never SELECT without LIMIT |
| **Mostly NULL columns** | `aik_*`, `ak_name`, `attested_*`, `ek_cert_*` | Only populated for 351 attested machines |

## Querying Guidance

1. **No `shard_hint`** — small table (~296K rows), full scans OK but still add LIMIT
2. **Never use `min()`/`max()` on `capture_timestamp`** — zero dates cause JDBC errors. Use `creation_date`
3. **Never SELECT crypto key columns without LIMIT** — they contain very long base64/PEM text
4. **TPM columns are NULL ~69%** — filter with `WHERE is_tpm_present = 1` for TPM-equipped machines only
5. **Clean `manufacturer`** — use `trim(manufacturer)` before grouping (trailing null bytes)
6. **`vendor` is very messy** — use `manufacturer` instead for TPM vendor analysis
7. **`registrar_id` / `enrollment_agency_code`** match codes in `strot.mysql_uid_v2` and `flink_stream.stream_enu` — use for cross-schema joins
8. **No PII** — only machine/device identifiers and cryptographic keys

## Example Queries

### Count stations by status

```sql
SELECT status, count(*) AS cnt
FROM mysql_uidmasterv1.uidmasterv1_1.station_reg_helper
GROUP BY status
ORDER BY cnt DESC
LIMIT 100
```

### Active stations by registrar

```sql
SELECT registrar_id, count(*) AS active_stations
FROM mysql_uidmasterv1.uidmasterv1_1.station_reg_helper
WHERE status = 'ACTIVE'
  AND registrar_id IS NOT NULL
GROUP BY registrar_id
ORDER BY active_stations DESC
LIMIT 100
```

### TPM-equipped machines by manufacturer

```sql
SELECT trim(manufacturer) AS mfr, count(*) AS cnt
FROM mysql_uidmasterv1.uidmasterv1_1.station_reg_helper
WHERE is_tpm_present = 1
  AND manufacturer IS NOT NULL
GROUP BY trim(manufacturer)
ORDER BY cnt DESC
LIMIT 100
```

### Signature mismatches by registrar

```sql
SELECT registrar_id, count(*) AS mismatches
FROM mysql_uidmasterv1.uidmasterv1_1.station_reg_helper
WHERE is_signature_mismatch = 1
  AND registrar_id IS NOT NULL
GROUP BY registrar_id
ORDER BY mismatches DESC
LIMIT 100
```

### Recently registered stations (last 7 days)

```sql
SELECT machine_id, station_id, registrar_id, enrollment_agency_code,
       status, is_tpm_present, creation_date
FROM mysql_uidmasterv1.uidmasterv1_1.station_reg_helper
WHERE creation_date >= current_date - interval '7' day
ORDER BY creation_date DESC
LIMIT 100
```

### Attested machines

```sql
SELECT machine_id, station_id, registrar_id, attested_at, attested_by,
       ek_cert_state, ek_cert_source
FROM mysql_uidmasterv1.uidmasterv1_1.station_reg_helper
WHERE attestation_state = 'ATTESTED'
ORDER BY attested_at DESC
LIMIT 100
```
