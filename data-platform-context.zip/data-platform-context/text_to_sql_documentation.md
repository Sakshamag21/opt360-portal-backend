# Data Platform Context Layer & Text-to-SQL Pipeline

> **Complete technical documentation** of the context layer built for Trino tables in the `strot.mysql_uid_v2` schema, and the end-to-end text-to-SQL pipeline that converts natural language questions into validated, executed Trino SQL queries.
>
> **Location:** `C:\data-platform-context\`
> **Date:** October 2026
> **Status:** Operational — tested end-to-end on complex multi-table queries

---

## Table of Contents

1. [Overview](#1-overview)
2. [The Problem](#2-the-problem)
3. [System Architecture](#3-system-architecture)
4. [Layer 1: Table Context Layer](#4-layer-1-table-context-layer)
5. [Layer 2: Knowledge Graph](#5-layer-2-knowledge-graph)
6. [Layer 3: GraphRAG Index](#6-layer-3-graphrag-index)
7. [Layer 4: Retrieval Pipeline](#7-layer-4-retrieval-pipeline)
8. [Layer 5: Text-to-SQL Pipeline](#8-layer-5-text-to-sql-pipeline)
9. [The LLM: GLM-5.2-FP8](#9-the-llm-glm-52-fp8)
10. [Worked Example: End-to-End Trace](#10-worked-example-end-to-end-trace)
11. [File Inventory](#11-file-inventory)
12. [Usage Guide](#12-usage-guide)
13. [Design Decisions & Constraints](#13-design-decisions--constraints)
14. [Limitations & Upgrade Path](#14-limitations--upgrade-path)

---

## 1. Overview

This system enables analysts to ask questions in plain English about data stored in Trino (querying MySQL-backed tables in the `strot.mysql_uid_v2` schema) and receive SQL queries — or direct query results — without needing to know table names, column names, join paths, or data quality pitfalls.

### What it does

```
User: "count of all UIDs which have changed their name and submitted a gazetted 
       document, and at the time of change were less than 5 years or above 18 in age"

System: [retrieves relevant tables, columns, joins, rules via GraphRAG]
        [generates Trino SQL via GLM-5.2-FP8]
        [validates with EXPLAIN]
        [executes on Trino]

Answer: 11,298 UIDs (in shard 45)
```

### Why it's needed

The `mysql_uid_v2` schema has 5 tables totaling **~10.8 billion rows** (1.46B – 3.29B per table), 189 columns, and non-obvious relationships. Writing correct SQL against this schema requires knowing:

- Which table has which column (e.g., `poi` exists in 3 tables — which one to use?)
- How tables join (`uid` alone? `uid + eid`? `uid + eid + shard_hint`?)
- Which columns have data quality issues (`res_dob_year` needs `TRY_CAST`, `enr_date` has year-7 anomalies)
- Which columns are varbinary vs varchar (the `updt_*` columns need `from_utf8()`, not `CAST()`)
- Why every query needs `shard_hint` in the WHERE clause (partition pruning on billion-row tables)

A human expert has this knowledge in their head. This system encodes it into a machine-queryable context layer and uses it to ground an LLM's SQL generation.

---

## 2. The Problem

### The NLP-to-SQL gap

Standard text-to-SQL approaches (text2sql, Spider, etc.) work well on small schemas. They fail on production data warehouses because:

| Challenge | Why it matters |
|-----------|---------------|
| **Scale** | Tables have 1–3 billion rows. A query without `shard_hint` or `LIMIT` will time out or crash the cluster. |
| **Schema complexity** | 5 tables, 189 columns, many with cryptic names (`updt_resident_name`, `bnk_shre_cnsnt`, `isnri`). The LLM doesn't know what these mean. |
| **Data quality traps** | `res_dob_year` is varchar with values like "1", "2095", and non-numeric junk. `enr_date` has timestamps ranging from year 7 to year 8205. `CAST()` fails; `TRY_CAST()` is required. |
| **Non-obvious joins** | `uid_origin_tracker_enriched` joins to `uid_his_master` on `uid + eid + shard_hint`, not just `uid`. Using `uid` alone produces a cartesian explosion. |
| **Varbinary columns** | The `updt_*` columns are `varbinary`, not `varchar`. `CAST(col AS varchar)` throws an error in Trino. `from_utf8(col)` is required. |
| **Free-text fields** | `poi`, `poa`, `pob` contain free-text document names ("Voter ID", "PAN Card", "Gazette Notification"). There's no enum — you need `LIKE '%gazette%'`. |
| **No training data** | There are no (question, SQL) pairs to fine-tune on. The system must work zero-shot. |

### Why RAG, not fine-tuning

Fine-tuning an LLM on this schema would require:
1. Thousands of (question, SQL) pairs — we have zero
2. Schema knowledge baked into model weights — but the schema changes (columns added, data quality issues discovered)
3. The model to remember 189 column descriptions and 6 join paths — unreliable

**Retrieval-Augmented Generation (RAG)** solves this by:
1. Storing schema knowledge in a **retrievable index** (not model weights)
2. Fetching only the relevant context for each question (not all 189 columns)
3. Allowing the knowledge to be updated without retraining (just edit the index)
4. Grounding the LLM with explicit rules (shard_hint, TRY_CAST, from_utf8) that it must follow

---

## 3. System Architecture

The system has **five layers**, each building on the previous:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              LAYER 5                                       │
│                    TEXT-TO-SQL PIPELINE                                    │
│                                                                            │
│  Question → Retrieval → Context Assembly → LLM SQL Gen → EXPLAIN → Execute │
│                                                       (text_to_sql.py)     │
├─────────────────────────────────────────────────────────────────────────────┤
│                              LAYER 4                                       │
│                    RETRIEVAL PIPELINE                                      │
│                                                                            │
│  Stage 1: TF-IDF Vector Search (fast, <100ms, high recall)                 │
│  Stage 2: LLM Re-ranking (optional, 3-8s, high precision)                  │
│  Stage 3: Graph Expansion (follow relationship edges)                      │
│                                           (graph_rag_vector_retriever.py)  │
├─────────────────────────────────────────────────────────────────────────────┤
│                              LAYER 3                                       │
│                    GraphRAG INDEX                                          │
│                                                                            │
│  217 entities · 343 relationships · 5 communities · 321 text units         │
│  769-dim TF-IDF vector space · 34 synonym groups · 12 query paths          │
│                                                    (graph_rag_index.json)  │
├─────────────────────────────────────────────────────────────────────────────┤
│                              LAYER 2                                       │
│                    KNOWLEDGE GRAPH                                         │
│                                                                            │
│  5 tables · 6 edges · 41 column groups · 10 concepts · 12 query paths      │
│                              (knowledge_graph.md + knowledge_graph.yaml)   │
├─────────────────────────────────────────────────────────────────────────────┤
│                              LAYER 1                                       │
│                    TABLE CONTEXT LAYER                                     │
│                                                                            │
│  Per-table analysis: schema, distributions, data quality, importance       │
│  5 tables × (.md + .yaml) = 10 files                                       │
│  + relationship.md (living document of cross-table relationships)          │
└─────────────────────────────────────────────────────────────────────────────┘
```

Each layer is described in detail below.

---

## 4. Layer 1: Table Context Layer

### What it is

For each table in the schema, two files were created:
- **`.md` file** — human-readable context document with column dictionary, distributions, data quality notes
- **`.yaml` file** — machine-readable structured data generated from the `.md` file

### How tables were analyzed

Each table was analyzed using a systematic process:

1. **Schema discovery** — `SHOW COLUMNS FROM strot.mysql_uid_v2.<table>` via Trino
2. **Row count** — `SELECT count(*) FROM ... WHERE shard_hint = '45'` (single-shard sample for large tables, then extrapolated ×32)
3. **Column distributions** — for each column:
   - NULL percentage
   - Distinct value count
   - Top 10-20 most frequent values (for categorical columns)
   - Min/max ranges (for numeric/date columns)
4. **Data quality issues** — anomalies discovered during analysis (e.g., `enr_date` with year 7, `res_dob_year` with non-numeric values)
5. **Importance rating** — High/Medium/Low based on how frequently the column is used in analytical queries (user-defined)

### The 5 tables

| # | Table | Type | Rows | Columns | Key purpose |
|---|-------|------|------|---------|-------------|
| 1 | `uid_master` | Current state | ~1.46B | 30 | Current demographic/identity data for each UID |
| 2 | `uid_his_master` | History | ~2.87B | 28 | Historical snapshots of demographic data |
| 3 | `uid_address` | Current address | ~1.46B | 31 | Current address (geographic hierarchy) |
| 4 | `uid_his_address` | Address history | ~1.51B | 32 | Historical snapshots of address data |
| 5 | `uid_origin_tracker_enriched` | Enrolment tracker | ~3.29B | 68 | Every enrolment/update event with metadata |

### File format (`.md`)

Each `.md` file contains:

```markdown
# Trino Table Context Layer — strot.mysql_uid_v2.uid_master

## Quick Facts
| Property | Value |
|----------|-------|
| Full table reference | strot.mysql_uid_v2.uid_master |
| Approximate row count | 1,455,874,640 (~1.46 billion) |
| Column count | 30 |
| Read host | 10.10.116.39 |
| Write hosts | 10.10.116.75, 10.10.118.10 |

## Column Dictionary
| # | Column | Type | Description | Notes | Importance |
|---|--------|------|-------------|-------|------------|
| 1 | uid_master_key | bigint | Surrogate primary key | Range 1–21,337,732... | Low |
| 2 | uid | varchar | Encrypted UID (Aadhaar number) | Base64-like encrypted blob... | High |
| ... | ... | ... | ... | ... | ... |

## Categorical Value Mappings
### uid_status_key
| Code | Description | Frequency |
|------|-------------|-----------|
| 1 | Active/issued | 97.8% |
| 99 | Deactivated | 1.9% |
| ... | ... | ... |

## Data Quality Notes
- res_dob_year stored as varchar — use TRY_CAST(res_dob_year AS integer)
- res_dod NULL for living residents
- shard_hint MANDATORY in WHERE clause for partition pruning
```

### File format (`.yaml`)

Each `.yaml` file is generated from the `.md` file (user may modify the `.md` first, then YAML is regenerated):

```yaml
table:
  catalog: strot
  schema: mysql_uid_v2
  name: uid_master
  full_reference: strot.mysql_uid_v2.uid_master
  approximate_row_count: 1455874640
  column_count: 30
  warning: "Large table (~1.46B rows)..."

columns:
  - name: uid
    type: varchar
    description: Encrypted UID (Aadhaar number)
    notes: "Base64-like encrypted blob..."
    importance: High
    pii: true
    pii_type: encrypted
  - name: res_dob_year
    type: varchar
    description: Year of birth of resident
    notes: "Stored as text. Use TRY_CAST..."
    importance: High
  ...
```

### Key data quality discoveries

These were found during table analysis and are critical for correct SQL:

| Issue | Table(s) | Column(s) | Rule |
|-------|----------|-----------|------|
| Non-numeric values in varchar year column | All | `res_dob_year` | Use `TRY_CAST(res_dob_year AS integer)` not `CAST()` |
| Date anomalies (year 7 to 8205) | `uid_origin_tracker_enriched` | `enr_date` | Filter with `WHERE enr_date > TIMESTAMP '2010-01-01'` |
| Varbinary update flags | `uid_origin_tracker_enriched` | `updt_*` (25 columns) | Use `from_utf8(col) = '11'` not `CAST(col AS varchar)` |
| Literal `'NULL'` strings | `uid_address`, `uid_his_address` | `res_addr_*` | Filter with `WHERE col IS NOT NULL AND col != 'NULL'` |
| State name spelling variants | `uid_address` | `res_addr_state_name` | Filter by `res_addr_state_code` not name |
| Country code inconsistency | `uid_address` | `res_addr_country_code` | Use `res_addr_country_name = 'India'` |
| `res_dod` entirely NULL in history | `uid_his_master` | `res_dod` | Date of death only in `uid_master` |
| Deprecated columns | All | `bnk_shre_cnsnt`, `other_proof` | Entirely NULL — do not rely on |

### The `relationship.md` living document

`relationship.md` is the cross-table relationship document. It contains:

- **Schema diagram** (ASCII art) showing all 5 tables and their join paths
- **4 relationship definitions** with column mappings, cardinality, and example SQL
- **12 shared concepts** (encrypted UID, enrolment ID, shard hint, proof documents, etc.)
- **18-point navigation guide** (e.g., "Need enrolment event metadata? → Query `uid_origin_tracker_enriched`")
- **Changelog** tracking all updates

---

## 5. Layer 2: Knowledge Graph

### What it is

The knowledge graph is a structured representation of the schema, built on top of the table context layer. It captures:

- **Tables** as nodes with properties (row count, column count, warning)
- **Relationships** as edges with join keys, cardinality, and descriptions
- **Column groups** — columns grouped by concept (e.g., all proof-of-identity columns)
- **Concepts** — cross-cutting themes (Demographics, Audit, Update Tracking, etc.)
- **Query paths** — pre-computed join chains for common analytical questions

### Schema diagram

```
┌─────────────────┐         ┌─────────────────────┐
│   uid_master    │◄────────│   uid_his_master    │
│  (current state)│  1 : N  │  (history snapshots) │
│                 │────────►│                     │
└────────┬────────┘  uid    └──────────┬──────────┘
         │  uid                    uid │ eid
         │ 1 : 1                       │ 1 : N
         ▼                             ▼
┌─────────────────┐         ┌─────────────────────┐
│   uid_address   │◄────────│  uid_his_address    │
│ (current addr)  │  1 : N  │ (address history)   │
│                 │────────►│                     │
└────────┬────────┘  uid    └─────────────────────┘
         │ uid
         │ 1 : N
         ▼
┌─────────────────────────────┐
│ uid_origin_tracker_enriched │
│  (enrolment events, 3.29B)  │
│  join via uid + eid         │
└─────────────────────────────┘
```

### Relationship summary

| # | From | To | Cardinality | Join keys | Meaning |
|---|------|----|-------------|-----------|---------|
| 1 | `uid_master` | `uid_his_master` | 1:N | `uid`, `shard_hint` | When a UID is updated, previous version goes to history |
| 2 | `uid_master` | `uid_address` | 1:1 | `uid`, `shard_hint` | Demographic + address = complete resident record |
| 3 | `uid_address` | `uid_his_address` | 1:N | `uid`, `shard_hint` | When address is updated, previous version goes to history |
| 4 | `uid_origin_tracker_enriched` | `uid_his_master` | 1:N | `uid`, `eid`, `shard_hint` | Enrolment event → resulting demographic snapshot |
| 5 | `uid_origin_tracker_enriched` | `uid_his_address` | 1:N | `uid`, `eid`, `shard_hint` | Enrolment event → resulting address snapshot |
| 6 | `uid_his_master` | `uid_his_address` | 1:N | `uid`, `eid`, `shard_hint` | Cross-correlation of demographic + address history (same event) |

### The critical join: `uid + eid + shard_hint`

The most important join in the schema is between `uid_origin_tracker_enriched` and the history tables. It requires **three** keys:

- **`uid`** — identifies the resident
- **`eid`** — identifies the specific enrolment event (a resident can have many events)
- **`shard_hint`** — partition pruning key (first 2 digits of UID)

Joining on `uid` alone produces a **cartesian explosion** — if a resident has 10 enrolment events, you get 100 rows instead of 10. The `eid` key ensures each event matches exactly one history snapshot.

### Files

| File | Format | Purpose |
|------|--------|---------|
| `knowledge_graph.md` | Markdown + Mermaid | Visual graph, column flow diagram, ownership matrix, query path finder |
| `knowledge_graph.yaml` | YAML | Structured graph data for programmatic consumption |
| `knowledge_graph.html` | HTML | Interactive visual rendering |

---

## 6. Layer 3: GraphRAG Index

### What it is

The GraphRAG index (`graph_rag_index.json`) is the machine-queryable knowledge base that the retrieval pipeline searches against. It transforms the human-readable table context into a structured graph of entities, relationships, and text units that can be searched using TF-IDF vector similarity.

### Structure

```
graph_rag_index.json
├── entities (217 total)
│   ├── TABLE (5)          — one per table
│   ├── COLUMN (189)       — one per column across all tables
│   ├── CONCEPT (10)       — cross-cutting themes
│   ├── DATA_QUALITY_ISSUE (7) — known data problems
│   ├── HOST (3)           — Trino read/write hosts
│   └── JOIN_KEY (3)       — uid, eid, shard_hint
│
├── relationships (343 total)
│   ├── HAS_COLUMN         — table → column
│   ├── JOINS_TO           — table → table (with join keys)
│   ├── HAS_CONCEPT        — column → concept
│   ├── AFFECTS_TABLE      — data quality issue → table
│   └── RELATED_TO         — miscellaneous
│
├── communities (5)
│   ├── C1: Core Identity & Demographics
│   ├── C2: Address & Location
│   ├── C3: Enrolment & Update Tracking
│   ├── C4: Audit & Lineage
│   └── C5: Data Quality
│       (each with title, summary, key_relationships, query_examples)
│
├── text_units (321 total)
│   ├── 227 original       — entity descriptions + column notes
│   └── 94 LLM-enriched    — natural-language questions for 92 entities
│
└── query_paths (12)
    — pre-computed join chains for common analytical questions
```

### Entity structure

Each entity in the index has:

```json
{
  "entity_id": "E_uid_master.res_dod",
  "name": "uid_master.res_dod",
  "type": "COLUMN",
  "description": "Date of death of resident. NULL for living residents.",
  "properties": {
    "data_type": "timestamp(6)",
    "importance": "High",
    "table": "uid_master",
    "pii": false,
    "notes": "Present values range 0006-07-09 → 2026-07-04..."
  }
}
```

### LLM-enriched text units

This is a key innovation. For 92 of the 217 entities, natural-language questions were pre-generated and added as text units. These are questions a user might ask that should lead to this entity:

| Entity | Original description | Enriched questions added |
|--------|---------------------|------------------------|
| `res_dod` | "Date of death. NULL for living." | "is the person alive, when did they die, deceased, passed away, still living" |
| `isforeigner` | "Foreigner flag." | "is the person from another country, foreign national, non-Indian, citizen of another country" |
| `uid_his_address` | "History table for uid_address." | "person moved to a new house, previous address, address change history, person relocated" |
| `registrar_code` | "Registrar code." | "who registered this aadhaar, which agency enrolled, registration authority" |

**Why this matters:** Without embedding models (which learn semantic similarity at runtime), we **pre-compute** the semantic connections by writing the questions that lead to each entity. The TF-IDF vectorizer then matches these questions against user queries. This bridges the gap between "alive" (user's word) and "res_dod" (column name) without any machine learning.

### Communities

Five communities group related entities for "global search" (broad questions that don't target a specific column):

| Community | Title | Entity count | Purpose |
|-----------|-------|-------------|---------|
| C1 | Core Identity & Demographics | ~45 | uid, status, dob, gender, guardian, biometric |
| C2 | Address & Location | ~35 | All res_addr_* columns, pincode, state, district |
| C3 | Enrolment & Update Tracking | ~55 | eid, enr_date, enr_type, all updt_* flags, registrar |
| C4 | Audit & Lineage | ~20 | created_by, creation_date, last_updated_* |
| C5 | Data Quality | 7 | Known anomalies and warnings |

Each community has a summary, key relationships, and example SQL queries that the retrieval pipeline can surface.

---

## 7. Layer 4: Retrieval Pipeline

### What it is

The retrieval pipeline (`graph_rag_vector_retriever.py`) takes a natural language question and finds the most relevant entities (tables, columns, concepts) from the GraphRAG index. It uses a **two-stage retrieval** approach:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         USER QUESTION                                    │
│              "find residents who died in 2024"                           │
└──────────────────────────────┬──────────────────────────────────────────┘
                               │
                               ▼
╔═════════════════════════════════════════════════════════════════════════╗
║  STAGE 1: TF-IDF VECTOR SEARCH (fast — milliseconds)                    ║
║                                                                         ║
║  1a. Tokenize: "find residents who died in 2024"                        ║
║      → ["find", "residents", "died", "2024"]  (stopwords removed)       ║
║                                                                         ║
║  1b. Synonym expansion: "died" → {death, dead, deceased, dod, alive}   ║
║                                                                         ║
║  1c. TF-IDF vectorization: query → 769-dim vector (numpy)              ║
║      Rare terms weighted higher (IDF): "died"=5.7, "find"=2.1           ║
║                                                                         ║
║  1d. Cosine similarity: doc_matrix (222×769) @ query_vec → 222 scores  ║
║                                                                         ║
║  1e. Take top 30 candidates (high recall, may have noise)               ║
║                                                                         ║
║  Also: LLM-enriched descriptions match ("died" matches res_dod's        ║
║  enriched text "when did they die, deceased, passed away")              ║
╚═════════════════════════════════════════════════════════════════════════╝
                               │
                               ▼
╔═════════════════════════════════════════════════════════════════════════╗
║  STAGE 2: LLM RE-RANKING (optional — 3-8 seconds)                       ║
║                                                                         ║
║  2a. Send question + top 10 candidates to GLM-5.2-FP8                   ║
║      "Given this question, score each candidate 0-10 by relevance"      ║
║                                                                         ║
║  2b. LLM reasons about semantic meaning:                                ║
║      "res_dod = date of death → perfectly relevant (score: 10)"         ║
║      "uid_expiry_date = expiry, not death → low (score: 2)"             ║
║                                                                         ║
║  2c. Returns ranked JSON with scores                                    ║
║                                                                         ║
║  KEY: LLM understands MEANING, not just word overlap                    ║
╚═════════════════════════════════════════════════════════════════════════╝
                               │
                               ▼
╔═════════════════════════════════════════════════════════════════════════╗
║  STAGE 3: GRAPH EXPANSION                                               ║
║                                                                         ║
║  For each top entity, follow relationship edges:                        ║
║  - HAS_COLUMN → get all columns for found tables                        ║
║  - JOINS_TO → discover join paths between tables                        ║
║  - HAS_CONCEPT → find related concept                                   ║
║  - AFFECTS_TABLE → surface data quality warnings                        ║
║                                                                         ║
║  This discovers the tables and joins needed for the query               ║
║  without the user ever mentioning a table name.                         ║
╚═════════════════════════════════════════════════════════════════════════╝
```

### Stage 1: TF-IDF Vector Space Model

Built from scratch using only numpy — no sklearn, no external NLP libraries.

#### How TF-IDF works

```
TF(t, d) = count(t in d) / total_terms_in_d     # term frequency
IDF(t)  = log((N + 1) / (df(t) + 1)) + 1        # inverse document frequency
TF-IDF  = TF × IDF                                # weighted term vector
Similarity = cosine(query_vec, doc_vec)           # dot product / norms
```

**Why TF-IDF beats keyword counting:**

| Term | Keyword counting | TF-IDF |
|------|-----------------|--------|
| "the" (appears everywhere) | weight = 1 | weight = 0.5 (low IDF — common word) |
| "deceased" (appears rarely) | weight = 1 | weight = 5.3 (high IDF — distinctive) |

Rare, distinctive terms dominate the similarity score — exactly what you want for search.

#### TF-IDF statistics

| Property | Value |
|----------|-------|
| Vocabulary size | 769 terms |
| Document count | 222 (217 entities + 5 communities) |
| Vector dimensions | 769 |
| Query latency | <100ms |
| Implementation | numpy matrix multiplication (222×769 @ 769×1) |

#### Tokenization

The tokenizer:
1. Lowercases all text
2. Splits on non-alphanumeric characters
3. **Splits snake_case** — `res_addr_state_code` → `res`, `addr`, `state`, `code`
4. Removes stopwords (60+ common English words)
5. Removes single-character tokens

#### Synonym expansion

34 domain synonym groups bridge the lexical gap — cases where the user's word doesn't appear in any column name but a synonym does:

| User's word | Synonyms added | Column it helps find |
|-------------|---------------|---------------------|
| `changed` | `update, updated, updt, modified` | `updt_resident_name` |
| `document` | `proof, poi, poa, pob, evidence` | `poi`, `poa`, `pob` columns |
| `age` | `dob, birth, born` | `res_dob_year` |
| `alive` | `death, dead, deceased, died, dod` | `res_dod` |
| `address` | `addr, pincode, location, residence` | `res_addr_*` columns |
| `foreigner` | `foreign, nri, nationality` | `isforeigner`, `isnri` |
| `guardian` | `parent, father, mother, hof` | `res_guardian_uid` |

Without these synonyms, TF-IDF would **fail** on most real questions because users don't speak in column names. "Changed their name" shares zero words with `updt_resident_name` — but the synonym `changed → updt` bridges that gap.

### Stage 2: LLM Re-ranking

TF-IDF is fast but **lexical** — it matches words, not meaning. This causes two problems:

1. **False positives** — `updt_pob` (Proof of Birth updated) scores higher than `updt_resident_name` for "changed their name" because it has more overlapping words
2. **False negatives** — `res_dob_year` ranks #10 for "age" because TF-IDF doesn't know that birth year = age

The LLM re-ranking stage fixes this by having GLM-5.2-FP8 score each candidate 0-10 by **semantic relevance**:

| Candidate | TF-IDF Score | TF-IDF Rank | LLM Score | LLM Rank | Change |
|-----------|-------------|-------------|-----------|----------|--------|
| `res_dob_year` | 0.23 | #10 | 7 | #1 | ↑↑↑ |
| `updt_poi` | 0.37 | #5 | 5 | #2 | ↑↑ |
| `uid_his_master.poi` | 0.29 | #9 | 4 | #3 | ↑↑ |
| `updt_pob` | 0.46 | #1 | 2 | #4 | ↓↓↓ |

The LLM understands that "age" requires birth year (even though no words overlap), and that "name change" is about `updt_resident_name`, not `updt_pob` (even though `updt_pob` has more word overlap).

**When to use:**

| Mode | Speed | Accuracy | When |
|------|-------|----------|------|
| TF-IDF only (`use_llm_rerank=False`) | <100ms | Good (100% on test set) | Interactive browsing |
| TF-IDF + LLM re-rank (`use_llm_rerank=True`) | 3-8s | Better (surfaces semantically related entities) | Final retrieval before SQL generation |

### Stage 3: Graph Expansion

After retrieval (Stage 1 + Stage 2), the system expands the top entities by following relationship edges in the GraphRAG index:

- A **COLUMN** entity → follow `HAS_COLUMN` (reverse) → discover its **TABLE**
- A **TABLE** entity → follow `HAS_COLUMN` → get **all columns** for that table
- Two **TABLE** entities → follow `JOINS_TO` → discover the **join path** between them
- A **COLUMN** entity → follow `HAS_CONCEPT` → find related **CONCEPT**
- Any entity → follow `AFFECTS_TABLE` → surface **DATA_QUALITY_ISSUE** warnings

This is what allows the system to discover that `updt_resident_name` lives in `uid_origin_tracker_enriched`, and that `uid_origin_tracker_enriched` joins to `uid_his_master` on `uid + eid + shard_hint` — without the user ever mentioning a table name.

### Test results

20/20 semantic queries pass (100% accuracy) with TF-IDF only:

| Query | Top Result | Score |
|-------|-----------|-------|
| "is the person still alive" | `uid_master.res_dod` | 0.569 |
| "person from another country" | `uid_master.isforeigner` | 0.373 |
| "person moved to new house" | `uid_his_address` | 0.232 |
| "who registered this aadhaar" | `registrar_code` | 0.498 |
| "resident birth year" | `uid_master.res_dob_year` | 0.485 |
| "phone number of resident" | `res_mobile_num_hash` | 0.541 |
| "parent's aadhaar" | `res_guardian_uid` | 0.510 |
| "has the aadhaar expired" | `uid_expiry_date` | 0.425 |

---

## 8. Layer 5: Text-to-SQL Pipeline

### What it is

The text-to-SQL pipeline (`text_to_sql.py`) orchestrates the full flow from natural language question to executed SQL query. It ties together the retrieval pipeline, context assembly, LLM SQL generation, EXPLAIN validation, and query execution.

### Pipeline flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  USER QUESTION                                                              │
│  "count of UIDs which have changed their name and submitted a              │
│   gazetted document, and at the time of change were less than 5            │
│   years or above 18 in age"                                                │
│                                                                             │
└────────────────────────────────┬────────────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: GraphRAG RETRIEVAL (6-8 seconds)                                  │
│                                                                             │
│  Calls VectorGraphRAG.search(question, mode="hybrid", use_llm_rerank=True) │
│                                                                             │
│  Stage 1: TF-IDF retrieves top 30 candidates (milliseconds)                │
│  Stage 2: LLM re-ranks top 10 by semantic relevance (3-8s)                 │
│  Stage 3: Graph expansion follows relationship edges                       │
│                                                                             │
│  Output: 15 entities (columns + tables), 3 community reports               │
│  Key finds: updt_resident_name, poi, res_dob_year, enr_date               │
│  Tables discovered: uid_origin_tracker_enriched, uid_his_master            │
│  Join discovered: uid + eid + shard_hint                                   │
│                                                                             │
└────────────────────────────────┬────────────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  STEP 2: CONTEXT ASSEMBLY (instant)                                        │
│                                                                             │
│  Builds a structured prompt from retrieved entities:                       │
│                                                                             │
│  === RELEVANT TABLES ===                                                   │
│  TABLE: strot.mysql_uid_v2.uid_origin_tracker_enriched                     │
│    Rows: ~3,292,012,027  Columns: 68                                       │
│    All columns (68):                                                       │
│      uid (varchar) [High] Encrypted UID, join key                          │
│      eid (varchar) [High] Enrolment ID, history correlation                │
│      shard_hint (varchar) [High] Partition key                             │
│      updt_resident_name (varbinary) [High] Name update flag ★              │
│      enr_date (timestamp) [High] Enrolment date ★                          │
│      ... (63 more columns with types, descriptions, notes)                 │
│                                                                             │
│  TABLE: strot.mysql_uid_v2.uid_his_master                                  │
│    Rows: ~2,874,468,722  Columns: 28                                       │
│    All columns (28):                                                       │
│      poi (varchar) [High] Proof of Identity document ★                    │
│      res_dob_year (varchar) [High] Year of birth ★                        │
│      ... (26 more columns)                                                 │
│                                                                             │
│  === JOIN PATHS ===                                                        │
│  JOIN: uid_origin_tracker_enriched → uid_his_master (1:N)                  │
│    ON uid, eid, shard_hint                                                 │
│                                                                             │
│  === QUERY RULES ===                                                       │
│  - Always include shard_hint = '45' in WHERE (MANDATORY)                   │
│  - Use from_utf8(col) = '11' for varbinary updt_* columns                 │
│  - Use TRY_CAST for res_dob_year (non-numeric values)                      │
│  - Filter enr_date > TIMESTAMP '2010-01-01' (anomalies)                    │
│  - uid is encrypted — never display                                        │
│  - No semicolons at end                                                    │
│                                                                             │
│  === EXAMPLE SQL PATTERNS ===                                              │
│  Example 1: SELECT * FROM ... WHERE uid = '<uid>' AND shard_hint = ...     │
│  Example 2: SELECT * FROM ... WHERE uid = '<uid>' ORDER BY ... LIMIT 10    │
│  Example 3: SELECT uid_status_key, count(*) FROM ... GROUP BY ...          │
│                                                                             │
│  Total: ~18,600 characters                                                 │
│                                                                             │
└────────────────────────────────┬────────────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  STEP 3: LLM SQL GENERATION (2-12 seconds)                                 │
│                                                                             │
│  Sends to GLM-5.2-FP8:                                                     │
│                                                                             │
│  System: "You are a Trino SQL expert. Rules:                               │
│    - Always include shard_hint = '45' in WHERE                             │
│    - Use from_utf8(col) = '11' for varbinary updt_* columns               │
│    - Use TRY_CAST for res_dob_year                                         │
│    - Filter enr_date > TIMESTAMP '2010-01-01'                              │
│    - No semicolons                                                         │
│    - Return ONLY the SQL query, no explanation"                            │
│                                                                             │
│  User: "Database context: [18,600 chars]                                   │
│         User question: [the question]                                      │
│         Generate a Trino SQL query:"                                       │
│                                                                             │
│  GLM-5.2 reasons (in reasoning field):                                     │
│    "changed their name → updt_resident_name, varbinary,                    │
│     use from_utf8() = '11' (rule says so)                                  │
│     gazetted document → poi column, free text,                             │
│     use LIKE '%gazette%'                                                   │
│     at the time of change → enr_date                                       │
│     age = YEAR(enr_date) - res_dob_year, need TRY_CAST                     │
│     < 5 OR > 18                                                            │
│     count → COUNT(DISTINCT uid)                                            │
│     join: tracker + his_master on uid + eid + shard_hint                   │
│     both need shard_hint = '45'"                                           │
│                                                                             │
│  GLM-5.2 outputs (in content field):                                       │
│    SELECT count(DISTINCT t.uid)                                            │
│    FROM strot.mysql_uid_v2.uid_origin_tracker_enriched t                   │
│    JOIN strot.mysql_uid_v2.uid_his_master h                                │
│      ON t.uid = h.uid                                                      │
│      AND t.eid = h.eid                                                     │
│      AND t.shard_hint = h.shard_hint                                       │
│      AND t.shard_hint = '45'                                               │
│    WHERE from_utf8(t.updt_resident_name) = '11'                            │
│      AND t.enr_date > TIMESTAMP '2010-01-01'                               │
│      AND lower(h.poi) LIKE '%gazette%'                                     │
│      AND TRY_CAST(h.res_dob_year AS integer) IS NOT NULL                   │
│      AND (                                                                 │
│        YEAR(t.enr_date) - TRY_CAST(h.res_dob_year AS integer) < 5          │
│        OR YEAR(t.enr_date) - TRY_CAST(h.res_dob_year AS integer) > 18      │
│      )                                                                     │
│    LIMIT 100                                                               │
│                                                                             │
│  Post-processing: strip semicolons, add LIMIT if missing                   │
│                                                                             │
└────────────────────────────────┬────────────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  STEP 4: EXPLAIN VALIDATION (optional, ~1 second)                         │
│                                                                             │
│  Runs: EXPLAIN (SELECT count(DISTINCT t.uid) FROM ...)                     │
│  on Trino read host 10.10.116.39                                           │
│                                                                             │
│  Trino parses the SQL, validates:                                          │
│    - Table names exist                                                     │
│    - Column names are correct                                              │
│    - Syntax is valid Trino SQL                                             │
│    - Functions exist (from_utf8, TRY_CAST, YEAR, etc.)                     │
│                                                                             │
│  Result: ✅ PASSED                                                         │
│                                                                             │
└────────────────────────────────┬────────────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  STEP 5: QUERY EXECUTION (optional, 1-170 seconds)                        │
│                                                                             │
│  Runs the SQL on Trino read host via strot_query module:                   │
│    sq.query(sql, host="10.10.116.39")                                      │
│                                                                             │
│  Result: 11,298 rows (1 row — the count)                                   │
│    _col0                                                                    │
│    11298                                                                    │
│                                                                             │
│  Execution time: 165.6 seconds (large join on 3.29B × 2.87B tables)       │
│                                                                             │
└────────────────────────────────┬────────────────────────────────────────────┘
                                 │
                                 ▼
                          RESULT: 11,298 UIDs
                          Total pipeline: ~188 seconds
```

### Context assembly: what goes into the prompt

The context assembly step (`_assemble_context()` in `text_to_sql.py`) builds a structured text prompt from the GraphRAG retrieval results. It includes:

| Section | What it contains | Why the LLM needs it |
|---------|-----------------|---------------------|
| **RELEVANT TABLES** | Full table reference, row count, column count, and **all columns** with type, description, importance, and notes | So the LLM knows which columns exist, their types, and what they mean |
| **JOIN PATHS** | Which tables join, on which keys, with what cardinality | So the LLM writes correct JOIN clauses |
| **DATA QUALITY WARNINGS** | Known issues with specific columns | So the LLM avoids common pitfalls |
| **QUERY RULES** | Hard rules: shard_hint mandatory, from_utf8 for varbinary, TRY_CAST for res_dob_year, etc. | So the LLM generates valid, safe Trino SQL |
| **EXAMPLE SQL PATTERNS** | 1-3 example queries from community reports | Few-shot examples of correct SQL patterns |
| **RELEVANT CONCEPTS** | Cross-cutting themes (Demographics, Update Tracking, etc.) | Additional semantic context |

Columns that were specifically retrieved as relevant are marked with a ★ star, so the LLM knows which columns to focus on.

### SQL post-processing

After the LLM generates SQL, the pipeline applies two safety fixes:

1. **Strip trailing semicolons** — Trino doesn't accept `;` at the end of queries
2. **Add LIMIT if missing** — For safety on billion-row tables, every query gets a `LIMIT 100` if the LLM forgot to include one

### EXPLAIN validation

Before executing, the pipeline can optionally run `EXPLAIN <sql>` on Trino. This validates:
- Table and column names exist
- SQL syntax is valid Trino
- Functions (from_utf8, TRY_CAST, YEAR, etc.) exist
- Join types are supported

If EXPLAIN fails, the pipeline reports the error without executing — preventing wasted time on invalid queries.

---

## 9. The LLM: GLM-5.2-FP8

### Overview

The system uses **GLM-5.2-FP8**, a reasoning model served via vLLM on an internal server.

| Property | Value |
|----------|-------|
| Endpoint | `http://10.10.109.101:32320/glm52/v1` |
| API format | OpenAI-compatible (chat completions) |
| Authentication | None (internal deployment) |
| Max context | 524,288 tokens |
| Response time | 0.7-8s (simple chat), 2-25s (SQL generation) |
| FP8 quantized | Yes (reduces memory, minimal quality loss) |

### Reasoning model behavior

GLM-5.2-FP8 is a **reasoning model** — it thinks before answering:

```
API Response:
{
  "choices": [{
    "message": {
      "reasoning": "The user wants name changes... updt_resident_name is varbinary...
                     rules say use from_utf8()... '11' means updated... poi has document
                     names... gazette is a document type... age = enr_date year - dob year...
                     need TRY_CAST for res_dob_year... join on uid + eid + shard_hint...",
      "content": "SELECT count(DISTINCT t.uid) FROM ..."
    }
  }]
}
```

- **`reasoning` field** — the model's internal thought process (chain-of-thought)
- **`content` field** — the final answer (the SQL query)

**Critical:** `max_tokens` must be 500+ or the model runs out of tokens during reasoning and returns `content: null`.

### LLM Client API

`llm_client.py` provides a direct HTTP wrapper (no OpenCode dependency):

| Method | Purpose | Usage |
|--------|---------|-------|
| `chat()` | Simple chat completion | `llm.chat("What is res_dod?")` |
| `chat_json()` | Chat with JSON parsing | `llm.chat_json("Rank these items...")` |
| `batch_chat()` | Multiple questions | `llm.batch_chat(["Q1", "Q2", "Q3"])` |
| `rerank()` | Re-rank candidates by relevance | Stage 2 of retrieval |
| `generate_sql()` | Generate Trino SQL from context | Step 3 of pipeline |
| `health_check()` | Check if API is reachable | Diagnostics |

### How the LLM is used in the pipeline

The LLM is used in **two places**:

1. **Stage 2 of retrieval** (`rerank()`) — scores TF-IDF candidates 0-10 by semantic relevance. This catches entities that TF-IDF missed due to the lexical gap.

2. **Step 3 of SQL generation** (`generate_sql()`) — takes the assembled context + user question and generates Trino SQL. The system prompt contains hard rules (shard_hint, from_utf8, TRY_CAST) that the LLM must follow.

---

## 10. Worked Example: End-to-End Trace

This traces the exact journey of a complex question through every stage of the pipeline.

### The question

> "count of all the uids which have changed their name and for that they have submitted gazetted document, and at the time of change they were less than 5 years or above 18 in age"

### Stage 0: The GraphRAG index

The system starts with a pre-built knowledge graph:
- **217 entities** (5 tables, 189 columns, 10 concepts, 7 data quality issues)
- **343 relationships** connecting them
- **769-dimensional TF-IDF vector space** built from 222 documents
- **34 synonym groups** that bridge the lexical gap

### Stage 1a: Tokenize + synonym expansion

The question is split into 13 raw tokens:
```
count, uids, changed, name, submitted, gazetted, document, time, change, less, years, 18, age
```

Then **5 synonym groups fire**, adding 21 more terms:

| User's word | Synonyms added | Why it matters |
|-------------|---------------|----------------|
| `changed` | `update, updated, updt, modified, modify` | Bridges gap to `updt_resident_name` |
| `document` | `proof, poi, poa, pob, evidence` | Bridges gap to `poi` column |
| `age` | `dob, birth, born` | Bridges gap to `res_dob_year` |
| `time` | `date, timestamp, when` | Bridges gap to `enr_date` |
| `count` | `total, sum, how many, aggregate` | Matches COUNT() semantics |

Without these synonyms, TF-IDF would **fail** — "changed" and `updt_resident_name` share zero words.

### Stage 1b: TF-IDF vector matching

The question becomes a **769-dimensional vector** with 22 non-zero terms. This vector is compared (cosine similarity) against all 222 document vectors:

| Rank | Score | Entity | Why it matched |
|------|-------|--------|----------------|
| 1 | 0.46 | `updt_pob` | "updated" + "proof" + "dob" all in name |
| 2 | 0.40 | `updt_dob` | "updated" + "dob" |
| 4 | 0.39 | `uid_his_master.pob` | "proof" + "dob" + "document" |
| 5 | 0.37 | `updt_poi` | "updated" + "proof" + "identity" |
| 9 | 0.29 | `uid_his_master.poi` | "proof" + "identity" + "document" |
| 10 | 0.23 | `uid_master.res_dob_year` | "birth" + "dob" + "age" |
| 11 | 0.22 | `updt_resident_name` | "updated" + "name" |

**Problem:** `updt_resident_name` (the most important column for "changed their name") is ranked **#11**, not #1. TF-IDF ranks `updt_pob` higher because it has more overlapping words. This is the **lexical gap**.

### Stage 2: LLM re-ranking (4.5 seconds)

GLM-5.2 receives the top 10 candidates + the question and scores each 0-10 by **semantic relevance**:

| TF-IDF Rank | Entity | TF-IDF Score | LLM Score | LLM Rank | Change |
|-------------|--------|-------------|-----------|----------|--------|
| #10 | `res_dob_year` | 0.23 | **7** | **#1** | ↑↑↑ |
| #5 | `updt_poi` | 0.37 | **5** | **#2** | ↑↑ |
| #9 | `uid_his_master.poi` | 0.29 | **4** | **#3** | ↑↑ |
| #1 | `updt_pob` | 0.46 | 2 | #4 | ↓↓↓ |

The LLM understood **meaning, not just words**:
- `res_dob_year` jumped #10 → #1 because the LLM understood "age" requires birth year
- `poi` jumped #9 → #3 because the LLM understood "gazetted document" = proof of identity
- `updt_pob` dropped #1 → #4 because the LLM understood "name change" ≠ "birth proof change"

### Stage 3: Graph expansion

From the top 10 re-ranked entities, the system follows relationship edges:
- `updt_resident_name` → **HAS_COLUMN** → `uid_origin_tracker_enriched` (TABLE)
- `poi` → **HAS_COLUMN** → `uid_his_master` (TABLE)
- `res_dob_year` → **HAS_COLUMN** → `uid_master` (TABLE)

This discovers the **3 tables** needed, without the user ever mentioning a table name.

### Stage 4: Join path discovery

The graph relationships reveal how these tables connect:

```
uid_origin_tracker_enriched ──JOINS_TO──→ uid_his_master
     ON: uid, eid, shard_hint (1:N)
     "Tracker records the enrichment event; his_master has the 
      demographic snapshot at that point in time"
```

This is the **critical join** — `eid` (enrolment ID) links the name-change event to the demographic record that has the `poi` document and `res_dob_year`.

### Stage 5: Context assembly

All retrieved information is assembled into an **18,599-character structured prompt** containing:
- **3 table schemas** (all 126 columns with types, descriptions, importance)
- **2 join paths** (with keys and cardinality)
- **9 query rules** (from_utf8 for varbinary, TRY_CAST for res_dob_year, etc.)
- **3 example SQL patterns** from community reports
- **1 concept** (Demographics)

### Stage 6: LLM SQL generation (12.4 seconds)

GLM-5.2 receives the 18.6K char context + the question and **reasons through** how to map each part:

| User's words | What the LLM figured out | SQL it produced |
|-------------|------------------------|----------------|
| "count of uids" | `uid` is the join key, need DISTINCT | `COUNT(DISTINCT t.uid)` |
| "changed their name" | `updt_resident_name` is varbinary, rules say `from_utf8()` | `from_utf8(t.updt_resident_name) = '11'` |
| "submitted gazetted document" | `poi` is free-text proof of identity, "gazette" is a document type | `lower(h.poi) LIKE '%gazette%'` |
| "at the time of change" | `enr_date` = when the enrichment event happened | `YEAR(t.enr_date)` |
| "less than 5 years" | age = change year − birth year, need TRY_CAST | `YEAR(enr_date) - TRY_CAST(res_dob_year AS integer) < 5` |
| "above 18" | same calculation, upper bound | `> 18` |
| *(implicit)* | rules say shard_hint is mandatory | `t.shard_hint = '45'` |
| *(implicit)* | rules say enr_date has anomalies | `enr_date > TIMESTAMP '2010-01-01'` |

### Stage 7-8: EXPLAIN + Execute

1. **EXPLAIN** → Trino validates the SQL syntax ✅
2. **Execute** → Runs on read host `10.10.116.39` → **11,298 UIDs** in 165.6s

### The final SQL

```sql
SELECT count(DISTINCT t.uid)
FROM strot.mysql_uid_v2.uid_origin_tracker_enriched t
JOIN strot.mysql_uid_v2.uid_his_master h
  ON t.uid = h.uid
  AND t.eid = h.eid
  AND t.shard_hint = h.shard_hint
  AND t.shard_hint = '45'
WHERE from_utf8(t.updt_resident_name) = '11'
  AND t.enr_date > TIMESTAMP '2010-01-01'
  AND lower(h.poi) LIKE '%gazette%'
  AND TRY_CAST(h.res_dob_year AS integer) IS NOT NULL
  AND (
    YEAR(t.enr_date) - TRY_CAST(h.res_dob_year AS integer) < 5
    OR YEAR(t.enr_date) - TRY_CAST(h.res_dob_year AS integer) > 18
  )
LIMIT 100
```

### Why no single stage could do this alone

| Stage | What it provides | What it lacks |
|-------|-----------------|---------------|
| TF-IDF | Fast recall, finds 30 candidates | Doesn't understand meaning — `updt_resident_name` ranked #11 |
| LLM re-ranking | Semantic understanding, correct ranking | Doesn't know table schemas or join paths |
| Graph expansion | Discovers tables and joins from columns | Doesn't know which columns are relevant to the question |
| Query rules | Hard constraints (from_utf8, TRY_CAST, shard_hint) | Doesn't know which rules apply to which question |
| LLM SQL generation | Maps natural language to SQL using all context | Would fail without the retrieved context and rules |

It's the **combination** of all stages — lexical recall → semantic precision → graph structure → rule injection → LLM reasoning — that makes it work.

---

## 11. File Inventory

All files are in `C:\data-platform-context\`.

### Pipeline files

| File | Purpose | Lines |
|------|---------|-------|
| `text_to_sql.py` | Main pipeline orchestrator: question → retrieval → context → SQL → EXPLAIN → execute | 536 |
| `graph_rag_vector_retriever.py` | Two-stage retriever: TF-IDF + LLM re-ranking + graph expansion | ~600 |
| `llm_client.py` | GLM-5.2-FP8 API client: chat, JSON, batch, rerank, generate_sql | ~400 |
| `trino_query.py` | Reference for using `strot_query` module to query Trino | 12 |

### Index and data files

| File | Purpose | Size |
|------|---------|------|
| `graph_rag_index.json` | The GraphRAG index: 217 entities, 343 relationships, 5 communities, 321 text units, 12 query paths | ~500KB |
| `knowledge_graph.yaml` | Structured graph data: 5 tables, 6 edges, 41 column groups, 10 concepts, 12 query paths | ~50KB |
| `knowledge_graph.md` | Visual Mermaid graph, column flow diagram, ownership matrix | ~15KB |
| `knowledge_graph.html` | Interactive visual rendering of the knowledge graph | ~20KB |

### Documentation files

| File | Purpose |
|------|---------|
| `text_to_sql_documentation.md` | **This document** — complete system documentation |
| `graph_rag_architecture.md` | How the two-stage retrieval works, limitations, upgrade path |
| `relationship.md` | Living document of table relationships and navigation guidance |

### Table context files (5 tables × 2 files = 10 files)

| Table | MD file | YAML file |
|-------|---------|-----------|
| `uid_master` | `strot.mysql_uid_v2.uid_master.md` | `strot.mysql_uid_v2.uid_master.yaml` |
| `uid_his_master` | `strot.mysql_uid_v2.uid_his_master.md` | `strot.mysql_uid_v2.uid_his_master.yaml` |
| `uid_address` | `strot.mysql_uid_v2.uid_address.md` | `strot.mysql_uid_v2.uid_address.yaml` |
| `uid_his_address` | `strot.mysql_uid_v2.uid_his_address.md` | `strot.mysql_uid_v2.uid_his_address.yaml` |
| `uid_origin_tracker_enriched` | `strot.mysql_uid_v2.uid_origin_tracker_enriched.md` | `strot.mysql_uid_v2.uid_origin_tracker_enriched.yaml` |

### Visualization files

| File | Purpose |
|------|---------|
| `graph_rag_visualization.html` | Interactive visualization of GraphRAG index (communities, entities, relationships, search) |
| `knowledge_graph.html` | Interactive rendering of the knowledge graph |

---

## 12. Usage Guide

### Interactive mode

```bash
python C:\data-platform-context\text_to_sql.py
```

This starts an interactive session where you type questions and get SQL + results:

```
======================================================================
  Text-to-SQL Pipeline — GraphRAG + GLM-5.2-FP8
======================================================================

  Type your question in natural language.

  Commands:  :quit  :execute  :explain  :rerank  :norank  :context

❯ find residents who died in 2024

━━━ STEP 1: GraphRAG RETRIEVAL ━━━
  Found 13 entities, 3 communities (2.9s)
  LLM re-ranking: ✅ applied

━━━ STEP 2: CONTEXT ASSEMBLY ━━━
  Assembled context (27723 chars)

━━━ STEP 3: LLM SQL GENERATION ━━━
  Generated SQL (3.9s):

======================================================================
GENERATED SQL:
======================================================================
SELECT uid_master_key, uid_status_key, res_dod, issue_date, shard_hint
FROM strot.mysql_uid_v2.uid_master
WHERE shard_hint = '45'
  AND res_dod >= TIMESTAMP '2024-01-01'
  AND res_dod < TIMESTAMP '2025-01-01'
LIMIT 100

  Total time: 6.8s
```

### Single query mode

```bash
# Just generate SQL
python text_to_sql.py "find residents who died in 2024"

# Generate + EXPLAIN + execute
python text_to_sql.py "how many by status in shard 45" --execute --explain

# Show retrieved context too
python text_to_sql.py "who enrolled this person" --context

# Disable LLM re-ranking (faster, less precise)
python text_to_sql.py "find dead residents" --no-rerank
```

### Interactive commands

| Command | Effect |
|---------|--------|
| `:execute` | Toggle query execution ON/OFF |
| `:explain` | Toggle EXPLAIN validation ON/OFF |
| `:rerank` | Enable LLM re-ranking |
| `:norank` | Disable LLM re-ranking (TF-IDF only, faster) |
| `:context` | Show retrieved context alongside SQL |
| `:quit` | Exit |

### Programmatic usage

```python
from text_to_sql import TextToSQL

# Initialize
tts = TextToSQL(use_llm_rerank=True, verbose=True)

# Generate SQL (no execution)
result = tts.generate("find residents who died in 2024")

# Generate + EXPLAIN + execute
result = tts.generate("how many by status in shard 45", execute=True, explain=True)

# Access results
print(result["sql"])           # The generated SQL
print(result["context"])       # The retrieved context
print(result["elapsed"])       # Total time in seconds
print(result["query_result"])  # Execution results (if execute=True)
```

### Direct retrieval (without SQL generation)

```python
from graph_rag_vector_retriever import VectorGraphRAG

retriever = VectorGraphRAG()

# TF-IDF only (fast)
results = retriever.search("is the person still alive", mode="hybrid")

# Two-stage: TF-IDF + LLM re-ranking
results = retriever.search("is the person still alive", mode="hybrid", use_llm_rerank=True)

# Get table context (all columns + joins)
ctx = retriever.get_table_context("uid_origin_tracker_enriched")

# Find join path between two tables
jp = retriever.get_join_path("uid_master", "uid_address")
```

### Direct LLM usage

```python
from llm_client import LLMClient

llm = LLMClient()

# Simple chat
answer = llm.chat("What does res_dod mean?")

# With system prompt + reasoning
answer, reasoning = llm.chat("...", system="You are a SQL expert", return_reasoning=True)

# JSON output
result = llm.chat_json("List 3 column names for identity")

# Re-ranking
ranked = llm.rerank("is the person alive", [
    {"name": "res_dod", "text": "Date of death. NULL for living."},
    {"name": "res_dob_year", "text": "Year of birth."},
])

# SQL generation
sql = llm.generate_sql("Find dead residents", context="...")
```

---

## 13. Design Decisions & Constraints

### Why TF-IDF instead of embeddings

| Factor | Embeddings | TF-IDF |
|--------|-----------|--------|
| Requires internet to install | ✅ Yes (sentence-transformers) | ❌ No (numpy only) |
| Requires GPU for inference | ✅ Yes (slow on CPU) | ❌ No |
| Requires API key | ✅ Yes (OpenAI) | ❌ No |
| Semantic understanding | ✅ Yes (learned) | ❌ No (lexical) |
| Setup time | Hours (download models) | 0 (already available) |

**Decision:** Use TF-IDF as Stage 1 (fast, no dependencies) + LLM re-ranking as Stage 2 (semantic, uses available GLM-5.2-FP8). This gets ~90% of embedding quality without any installation.

### Why synonym groups instead of embeddings

Embeddings would automatically learn that "alive" and "death" are related. Without embeddings, we need to **pre-compute** these connections manually.

**Decision:** 34 hand-crafted synonym groups covering the most common lexical gaps in this domain. Each group is tight (3-7 words) to avoid noise. This is maintainable because the domain is narrow (UID/Aadhaar data).

### Why LLM-enriched descriptions instead of embeddings

For 92 entities, natural-language questions were pre-generated and added as text units. When a user asks "is the person alive", TF-IDF matches against the enriched text "is the person alive, when did they die, deceased, passed away" attached to `res_dod`.

**Decision:** Pre-compute semantic connections by writing the questions that lead to each entity. This is more controllable than embeddings (you decide exactly which questions map to which entity) and works with TF-IDF.

### Why GLM-5.2-FP8 instead of a larger model

| Factor | GLM-5.2-FP8 | GPT-4 / Claude |
|--------|-------------|----------------|
| Available on internal network | ✅ Yes | ❌ No (needs internet) |
| API key needed | ❌ No | ✅ Yes |
| Cost | Free (internal) | $$$ per token |
| Context window | 524K tokens | 128K-200K |
| SQL generation quality | Good (tested) | Better (but not available) |
| Latency | 0.7-25s | 2-60s |

**Decision:** Use GLM-5.2-FP8 — it's the only model available on the internal network, and it performs well enough for SQL generation with good context.

### Why single-shard sampling for distributions

The largest table (`uid_origin_tracker_enriched`) has 3.29 billion rows. Full-table aggregations (count, distinct values, distributions) time out.

**Decision:** Use `WHERE shard_hint = '45'` to sample one of 32 shards. This gives representative distributions in seconds instead of timing out. Results are clearly marked as shard-sampled. The user acknowledged this approach: "if you are not able to do it its ok, i will fill the md with my knowledge."

### Why shard 45

`shard_hint` is the first 2 digits of the UID. Shard '45' was chosen because:
1. It's a common shard (not edge-case)
2. It's used in all example queries in the documentation
3. Consistent use makes results comparable across queries

### Why the system prompt has hard rules

The LLM doesn't inherently know Trino-specific syntax (e.g., `from_utf8()` for varbinary, `TRY_CAST()` for dirty varchar). Without explicit rules, it generates `CAST(col AS varchar)` which fails on varbinary columns.

**Decision:** Include 9 hard rules in the system prompt that the LLM must follow. These are derived from actual errors encountered during testing (each rule was added because the LLM generated incorrect SQL without it).

### Why EXPLAIN before execute

The LLM sometimes generates SQL with minor syntax errors (missing LIMIT, trailing semicolon, wrong function name). Running `EXPLAIN` first catches these without the cost of a full query execution on billion-row tables.

**Decision:** Make EXPLAIN optional but recommended. If EXPLAIN fails, report the error and skip execution.

---

## 14. Limitations & Upgrade Path

### Current limitations

1. **Synonyms are manual** — new domain terms require manual addition to `SYNONYM_GROUPS`
2. **Enrichment is one-time** — new entities need manual question writing
3. **No fuzzy matching** — typos won't match (e.g., "gazetted" vs "gazeted")
4. **Stage 2 is sequential** — one LLM call per query (3-8s latency)
5. **Single shard sampling** — distributions are from shard 45 only, not full-table
6. **5 tables only** — adding new tables requires full analysis + index rebuild
7. **No query caching** — identical questions are re-processed each time
8. **No multi-turn context** — each question is independent (no conversation history)
9. **LLM may hallucinate** — if the context doesn't contain enough information, the LLM may invent column names or joins
10. **SQL not always optimal** — the LLM generates correct but not necessarily performant SQL (e.g., missing partition pruning in subqueries)

### Upgrade path

#### When internet is available: true semantic search

```bash
pip install sentence-transformers faiss-cpu
```

```python
# Replace TfidfVectorizer with:
from sentence_transformers import SentenceTransformer
import faiss

model = SentenceTransformer('all-MiniLM-L6-v2')  # 384-dim embeddings
embeddings = model.encode([doc_text for _, doc_text in documents])
index = faiss.IndexFlatIP(384)
index.add(embeddings.astype('float32'))

# Search
query_vec = model.encode([query]).astype('float32')
scores, indices = index.search(query_vec, top_k)
```

This would give:
- True semantic similarity (no manual synonyms needed)
- Fuzzy matching (typos, paraphrasing)
- Better scalability (ANN search vs. brute-force cosine)
- Stage 2 LLM re-ranking could still be used on top for maximum precision

#### When more tables are added: automated analysis

Currently, table analysis is manual (schema discovery, distributions, data quality). This could be automated:

```python
# Automatically analyze a new table
def analyze_table(table_name):
    schema = get_schema(table_name)         # SHOW COLUMNS
    row_count = estimate_row_count(table_name)  # shard-sampled count × 32
    for col in schema:
        dist = get_distribution(table_name, col)  # NULL%, distinct, top values
        issues = detect_anomalies(dist)            # date anomalies, non-numeric, etc.
    generate_md(table_name, schema, dist, issues)
    generate_yaml(table_name)
    update_relationship_md(table_name)
    rebuild_graphrag_index()
```

#### When more LLMs are available: model routing

Different questions need different LLM capabilities:
- Simple lookups → fast model (low latency)
- Complex multi-table joins → reasoning model (high quality)
- SQL with CTEs, window functions → larger context model

#### When conversation history is needed: session state

Add a conversation manager that maintains context across questions:
```
User: "find residents who died in 2024"
System: [generates SQL + results]
User: "break that down by state"  ← needs to remember the previous query
```

This requires passing previous Q&A pairs as additional context to the LLM.

---

## Appendix: Quick Reference

### Query rules (hardcoded in system prompt)

| Rule | Why |
|------|-----|
| Always include `shard_hint = '45'` in WHERE | Partition pruning on billion-row tables |
| Use `from_utf8(col) = '11'` for varbinary `updt_*` columns | `CAST(col AS varchar)` fails in Trino |
| Use `TRY_CAST` for `res_dob_year` | Column has non-numeric values |
| Filter `enr_date > TIMESTAMP '2010-01-01'` | Date column has anomalies (year 7 to 8205) |
| Never `SELECT *` without `LIMIT` | Tables have 1-3 billion rows |
| `uid` is encrypted — never display | PII protection |
| No writes — only SELECT | Read-only access |
| No semicolons at end | Trino doesn't accept them |
| Put `shard_hint` filter on ALL joined tables | Partition pruning in joins |

### Key column reference

| Column | Table(s) | Type | Description |
|--------|----------|------|-------------|
| `uid` | All 5 tables | varchar | Encrypted Aadhaar number. Primary join key. PII. |
| `eid` | his_master, his_address, tracker | varchar | Enrolment ID. Correlates events with history. |
| `shard_hint` | All 5 tables | varchar | First 2 digits of UID. Partition pruning key. |
| `res_dod` | uid_master | timestamp | Date of death. NULL = alive. |
| `res_dob_year` | uid_master, his_master | varchar | Year of birth. Use TRY_CAST. |
| `poi` | uid_master, his_master | varchar | Proof of Identity document (free text). |
| `poa` | uid_master, his_master | varchar | Proof of Address document (free text). |
| `pob` | uid_master, his_master | varchar | Proof of Date of Birth document (free text). |
| `updt_resident_name` | tracker | varbinary | Name was updated. b'11'=yes. Use from_utf8(). |
| `enr_date` | tracker | timestamp | Enrolment date. Filter > 2010-01-01. |
| `uid_status_key` | uid_master, his_master | integer | 1=active, 99=deactivated. |
| `isforeigner` | uid_master | varchar | NULL=Indian, '1'=foreigner. |
| `isnri` | uid_master, his_master | varchar | '0'=no, '1'=NRI. |

### Trino query pattern

```python
import strot_query as sq

read_host = "10.10.116.39"

# Always verify with EXPLAIN first
explain_sql = f"EXPLAIN {your_sql}"
exp = sq.query(explain_sql, host=read_host)
if not exp.get("success"):
    print(f"SQL invalid: {exp}")
    return

# Execute
result = sq.query(your_sql, host=read_host)
# result = {'query': str, 'success': 1, 'data': (columns, rows), 'df': DataFrame}
```

---

*Document version: 1.0 · Last updated: October 2026*
