@echo off
REM ─── GraphRAG Navigator Launcher ─────────────────────────────────────────────
REM Starts the Flask backend (serves API + built React frontend) on port 5051.
REM
REM Prerequisites:
REM   - Docker container "graphrag-postgres" must be running
REM   - Python with Flask installed
REM   - Frontend must be built (cd frontend && npm install && npm run build)
REM
REM Usage:   start.bat
REM Open:    http://localhost:5051

cd /d "%~dp0"

echo ════════════════════════════════════════════════════════════
echo  GraphRAG Navigator
echo ════════════════════════════════════════════════════════════

REM Check Docker container is running
docker ps | findstr "graphrag-postgres" >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Docker container 'graphrag-postgres' is not running.
    echo         Start it with:  cd ..\postgres ^&^& docker compose up -d
    pause
    exit /b 1
)

REM Check frontend is built
if not exist "frontend\dist\index.html" (
    echo [WARN] Frontend not built. Building now...
    pushd frontend
    call npm install
    call npm run build
    popd
)

echo.
echo  Starting backend on http://localhost:5051
echo  Press Ctrl+C to stop.
echo.

python backend\server.py
