import { useState, useEffect, useCallback } from 'react';
import { api } from './api';
import type { Entity, Relationship, Stats, TableInfo, ValidationItem, Selection } from './types';
import GraphCanvas from './components/GraphCanvas';
import Sidebar from './components/Sidebar';
import DetailsPanel from './components/DetailsPanel';
import EditDialog, { type EditDialogProps } from './components/EditDialog';

export default function App() {
  // ─── State ──────────────────────────────────────────────────────────────────
  const [stats, setStats] = useState<Stats | null>(null);
  const [tables, setTables] = useState<TableInfo[]>([]);
  const [entities, setEntities] = useState<Entity[]>([]);
  const [relationships, setRelationships] = useState<Relationship[]>([]);
  const [selection, setSelection] = useState<Selection>(null);
  const [searchResults, setSearchResults] = useState<Entity[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [graphTitle, setGraphTitle] = useState('Table Graph Overview');

  // Edit dialog state
  const [editDialog, setEditDialog] = useState<{
    open: boolean;
    mode: EditDialogProps['mode'];
    entity?: Entity | null;
    relationship?: Relationship | null;
  }>({ open: false, mode: 'create-entity' });

  // Path-finding state
  const [pathFrom, setPathFrom] = useState<string | null>(null);

  // ─── Load initial data ──────────────────────────────────────────────────────
  useEffect(() => {
    api.getStats().then(setStats).catch((e) => setError(e.message));
    api.getTables().then(setTables).catch((e) => setError(e.message));
    loadTableGraph();
  }, []);

  const loadTableGraph = useCallback(async () => {
    setLoading(true);
    setError('');
    setPathFrom(null);
    try {
      const data = await api.getTableGraph();
      setEntities(data.nodes);
      setRelationships(data.edges);
      setGraphTitle('Table Graph Overview');
      setSelection(null);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  // ─── Search ──────────────────────────────────────────────────────────────────
  const handleSearch = useCallback(async (query: string) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }
    try {
      const results = await api.getEntities({ search: query, limit: 50 });
      setSearchResults(results);
    } catch {
      setSearchResults([]);
    }
  }, []);

  // ─── Entity selection ───────────────────────────────────────────────────────
  const selectEntity = useCallback(async (entityId: string) => {
    setLoading(true);
    setError('');
    try {
      const data = await api.getEntity(entityId);
      setSelection({ kind: 'entity', entity: data.entity, relationships: data.relationships });
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  // ─── Relationship selection ─────────────────────────────────────────────────
  const selectRelationship = useCallback(
    (relId: number) => {
      const rel = relationships.find((r) => r.id === relId);
      if (rel) {
        setSelection({ kind: 'relationship', rel });
      }
    },
    [relationships],
  );

  // ─── Load subgraph for an entity ─────────────────────────────────────────────
  const loadSubgraph = useCallback(async (entityId: string, depth: number = 1) => {
    setLoading(true);
    setError('');
    setPathFrom(null);
    try {
      const data = await api.getSubgraph(entityId, depth);
      setEntities(data.nodes);
      setRelationships(data.edges);
      const center = data.nodes.find((n) => n.entity_id === entityId);
      setGraphTitle(`Subgraph: ${center?.name || entityId} (depth ${depth})`);
      await selectEntity(entityId);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [selectEntity]);

  // ─── Expand neighbors (double-click) ────────────────────────────────────────
  const handleNodeDoubleClick = useCallback(
    (entityId: string) => {
      loadSubgraph(entityId, 1);
    },
    [loadSubgraph],
  );

  // ─── Table select from sidebar ──────────────────────────────────────────────
  const handleTableSelect = useCallback(
    (entityId: string) => {
      loadSubgraph(entityId, 1);
    },
    [loadSubgraph],
  );

  // ─── Search result click ────────────────────────────────────────────────────
  const handleSearchResultClick = useCallback(
    (entityId: string) => {
      loadSubgraph(entityId, 1);
    },
    [loadSubgraph],
  );

  // ─── Validate ────────────────────────────────────────────────────────────────
  const handleValidate = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const items = await api.validate();
      setSelection({ kind: 'validation', items });
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  // ─── Find path ──────────────────────────────────────────────────────────────
  const handleFindPath = useCallback(
    (entityId: string) => {
      setPathFrom(entityId);
      setError('Now click another node in the graph to find the path to it.');
    },
    [],
  );

  const handlePathTarget = useCallback(
    async (targetId: string) => {
      if (!pathFrom) return;
      setLoading(true);
      setError('');
      try {
        const data = await api.findPath(pathFrom, targetId);
        setEntities(data.nodes);
        setRelationships(data.edges);
        const fromName = data.nodes.find((n) => n.entity_id === pathFrom)?.name || pathFrom;
        const toName = data.nodes.find((n) => n.entity_id === targetId)?.name || targetId;
        setGraphTitle(`Path: ${fromName} → ${toName}`);
        setPathFrom(null);
      } catch (e: any) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    },
    [pathFrom],
  );

  // ─── Node click (handles path-finding mode) ─────────────────────────────────
  const handleNodeClick = useCallback(
    (entityId: string) => {
      if (pathFrom && pathFrom !== entityId) {
        handlePathTarget(entityId);
      } else {
        selectEntity(entityId);
      }
    },
    [pathFrom, handlePathTarget, selectEntity],
  );

  // ─── Edit dialog handlers ───────────────────────────────────────────────────
  const openEditEntity = useCallback(() => {
    if (selection?.kind === 'entity') {
      setEditDialog({
        open: true,
        mode: 'edit-entity',
        entity: selection.entity,
      });
    }
  }, [selection]);

  const openEditRelationship = useCallback(() => {
    if (selection?.kind === 'relationship') {
      setEditDialog({
        open: true,
        mode: 'edit-relationship',
        relationship: selection.rel,
      });
    }
  }, [selection]);

  const openCreateEntity = useCallback(() => {
    setEditDialog({ open: true, mode: 'create-entity' });
  }, []);

  const openCreateRelationship = useCallback(() => {
    let prefill: Partial<Relationship> | null = null;
    if (selection?.kind === 'entity') {
      prefill = { source_id: selection.entity.entity_id };
    }
    setEditDialog({
      open: true,
      mode: 'create-relationship',
      relationship: prefill as Relationship | null,
    });
  }, [selection]);

  const handleSaveEdit = useCallback(
    async (data: any) => {
      if (editDialog.mode === 'create-entity') {
        const created = await api.createEntity(data);
        setEditDialog((d) => ({ ...d, open: false }));
        await loadSubgraph(created.entity_id, 1);
      } else if (editDialog.mode === 'edit-entity' && editDialog.entity) {
        await api.updateEntity(editDialog.entity.entity_id, data);
        await selectEntity(editDialog.entity.entity_id);
        setEditDialog((d) => ({ ...d, open: false }));
        // Refresh graph if entity is in current view
        setEntities((prev) =>
          prev.map((e) =>
            e.entity_id === editDialog.entity!.entity_id
              ? { ...e, ...data }
              : e,
          ),
        );
      } else if (editDialog.mode === 'create-relationship') {
        await api.createRelationship(data);
        setEditDialog((d) => ({ ...d, open: false }));
        // Refresh relationships
        if (selection?.kind === 'entity') {
          await selectEntity(selection.entity.entity_id);
        }
      } else if (editDialog.mode === 'edit-relationship' && editDialog.relationship) {
        await api.updateRelationship(editDialog.relationship.id, data);
        setEditDialog((d) => ({ ...d, open: false }));
        if (selection?.kind === 'entity') {
          await selectEntity(selection.entity.entity_id);
        }
      }
      // Refresh stats
      api.getStats().then(setStats).catch(() => {});
    },
    [editDialog, loadSubgraph, selectEntity, selection],
  );

  // ─── Delete handlers ────────────────────────────────────────────────────────
  const handleDelete = useCallback(async () => {
    if (!selection) return;
    if (!window.confirm('Are you sure you want to delete this? This cannot be undone.')) return;

    setLoading(true);
    try {
      if (selection.kind === 'entity') {
        await api.deleteEntity(selection.entity.entity_id);
        setEntities((prev) => prev.filter((e) => e.entity_id !== selection.entity.entity_id));
        setRelationships((prev) =>
          prev.filter(
            (r) =>
              r.source_id !== selection.entity.entity_id &&
              r.target_id !== selection.entity.entity_id,
          ),
        );
        setSelection(null);
      } else if (selection.kind === 'relationship') {
        await api.deleteRelationship(selection.rel.id);
        setRelationships((prev) => prev.filter((r) => r.id !== selection.rel.id));
        setSelection(null);
      }
      api.getStats().then(setStats).catch(() => {});
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [selection]);

  // ─── Render ──────────────────────────────────────────────────────────────────
  return (
    <div className="app">
      <Sidebar
        stats={stats}
        tables={tables}
        onSearch={handleSearch}
        onLoadTableGraph={loadTableGraph}
        onTableSelect={handleTableSelect}
        onValidate={handleValidate}
        onAddEntity={openCreateEntity}
        onAddRelationship={openCreateRelationship}
        searchResults={searchResults}
        onSearchResultClick={handleSearchResultClick}
      />

      <div className="main-area">
        <div className="main-header">
          <h2 className="graph-title">{graphTitle}</h2>
          <div className="graph-info">
            {entities.length > 0 && (
              <span className="graph-info-item">{entities.length} nodes</span>
            )}
            {relationships.length > 0 && (
              <span className="graph-info-item">{relationships.length} edges</span>
            )}
            {pathFrom && <span className="path-mode">🔗 Path mode: click target node</span>}
          </div>
        </div>

        {error && (
          <div className="error-bar" onClick={() => setError('')}>
            ⚠ {error} ✕
          </div>
        )}

        {loading && (
          <div className="loading-bar">
            <div className="loading-spinner" />
            Loading...
          </div>
        )}

        <GraphCanvas
          entities={entities}
          relationships={relationships}
          selectedEntityId={selection?.kind === 'entity' ? selection.entity.entity_id : undefined}
          onNodeClick={handleNodeClick}
          onEdgeClick={selectRelationship}
          onNodeDoubleClick={handleNodeDoubleClick}
        />
      </div>

      <DetailsPanel
        selection={selection}
        onEdit={selection?.kind === 'relationship' ? openEditRelationship : openEditEntity}
        onDelete={handleDelete}
        onExpand={(id) => loadSubgraph(id, 1)}
        onFindPath={handleFindPath}
        onEntityClick={selectEntity}
      />

      <EditDialog
        open={editDialog.open}
        mode={editDialog.mode}
        entity={editDialog.entity}
        relationship={editDialog.relationship}
        onClose={() => setEditDialog((d) => ({ ...d, open: false }))}
        onSave={handleSaveEdit}
      />
    </div>
  );
}
