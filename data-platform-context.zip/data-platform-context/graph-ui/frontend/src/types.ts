export interface Entity {
  entity_id: string;
  name: string;
  type: string;
  description: string | null;
  properties: Record<string, any>;
  search_text: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface Relationship {
  id: number;
  source_id: string;
  target_id: string;
  type: string;
  description: string | null;
  properties: Record<string, any>;
  source_name?: string;
  source_type?: string;
  target_name?: string;
  target_type?: string;
}

export interface GraphData {
  nodes: Entity[];
  edges: Relationship[];
}

export interface Stats {
  total_entities: number;
  total_relationships: number;
  total_query_paths: number;
  total_text_units: number;
  total_communities: number;
  entity_types: Record<string, number>;
  relationship_types: Record<string, number>;
}

export interface ValidationItem {
  category: string;
  severity: 'error' | 'warning' | 'info';
  message: string;
  items: any[];
  count: number;
}

export interface TableInfo {
  entity_id: string;
  name: string;
  description: string | null;
  properties: Record<string, any>;
  column_count: number;
}

export type Selection =
  | { kind: 'entity'; entity: Entity; relationships: Relationship[] }
  | { kind: 'relationship'; rel: Relationship }
  | { kind: 'validation'; items: ValidationItem[] }
  | null;
