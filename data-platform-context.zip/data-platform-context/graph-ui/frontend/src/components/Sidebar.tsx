import { useState, useEffect } from 'react';
import { api } from '../api';
import type { Stats, TableInfo } from '../types';

interface SidebarProps {
  stats: Stats | null;
  tables: TableInfo[];
  onSearch: (query: string) => void;
  onLoadTableGraph: () => void;
  onTableSelect: (entityId: string) => void;
  onValidate: () => void;
  onAddEntity: () => void;
  onAddRelationship: () => void;
  searchResults: { entity_id: string; name: string; type: string; description: string | null }[];
  onSearchResultClick: (entityId: string) => void;
}

export default function Sidebar({
  stats,
  tables,
  onSearch,
  onLoadTableGraph,
  onTableSelect,
  onValidate,
  onAddEntity,
  onAddRelationship,
  searchResults,
  onSearchResultClick,
}: SidebarProps) {
  const [searchInput, setSearchInput] = useState('');
  const [tableFilter, setTableFilter] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      onSearch(searchInput);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchInput, onSearch]);

  return (
    <div className="sidebar">
      {/* Header */}
      <div className="sidebar-header">
        <h1 className="sidebar-title">
          <span className="sidebar-logo">◈</span> GraphRAG Navigator
        </h1>
        {stats && (
          <div className="sidebar-stats">
            <span title="Entities">{stats.total_entities} entities</span>
            <span title="Relationships">{stats.total_relationships} rels</span>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="sidebar-actions">
        <button className="btn btn-primary" onClick={onLoadTableGraph}>
          📊 Load Table Graph
        </button>
        <button className="btn" onClick={onValidate}>
          ⚠ Validate
        </button>
        <button className="btn" onClick={onAddEntity}>
          ＋ Entity
        </button>
        <button className="btn" onClick={onAddRelationship}>
          ＋ Relationship
        </button>
      </div>

      {/* Search */}
      <div className="sidebar-section">
        <input
          className="search-input"
          type="text"
          placeholder="Search entities..."
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
        />
        {searchResults.length > 0 && searchInput && (
          <div className="search-results">
            {searchResults.slice(0, 30).map((r) => (
              <div
                key={r.entity_id}
                className="search-result-item"
                onClick={() => onSearchResultClick(r.entity_id)}
              >
                <span className={`type-badge type-${r.type?.toLowerCase()}`}>{r.type}</span>
                <span className="result-name">{r.name}</span>
              </div>
            ))}
            {searchResults.length > 30 && (
              <div className="search-more">{searchResults.length - 30} more...</div>
            )}
          </div>
        )}
      </div>

      {/* Stats breakdown */}
      {stats && (
        <div className="sidebar-section">
          <div className="section-title">Entity Types</div>
          {Object.entries(stats.entity_types)
            .sort((a, b) => b[1] - a[1])
            .map(([type, count]) => (
              <div key={type} className="stat-row">
                <span className={`type-badge type-${type.toLowerCase()}`}>{type}</span>
                <span className="stat-count">{count}</span>
              </div>
            ))}
        </div>
      )}

      {stats && Object.keys(stats.relationship_types).length > 0 && (
        <div className="sidebar-section">
          <div className="section-title">Relationship Types</div>
          {Object.entries(stats.relationship_types)
            .sort((a, b) => b[1] - a[1])
            .map(([type, count]) => (
              <div key={type} className="stat-row">
                <span className="rel-type-label">{type.replace(/_/g, ' ')}</span>
                <span className="stat-count">{count}</span>
              </div>
            ))}
        </div>
      )}

      {/* Tables list */}
      <div className="sidebar-section">
        <div className="section-title">Tables ({tables.length})</div>
        <input
          className="table-filter"
          type="text"
          placeholder="Filter tables..."
          value={tableFilter}
          onChange={(e) => setTableFilter(e.target.value)}
        />
        <div className="table-list">
          {tables
            .filter((t) => !tableFilter || t.name.toLowerCase().includes(tableFilter.toLowerCase()))
            .map((t) => (
              <div key={t.entity_id} className="table-item" onClick={() => onTableSelect(t.entity_id)}>
                <span className="table-name">{t.name}</span>
                <span className="table-cols">{t.column_count} cols</span>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
