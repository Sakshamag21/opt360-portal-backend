import { useState, useEffect } from 'react';
import type { Entity, Relationship } from '../types';

export interface EditDialogProps {
  open: boolean;
  mode: 'create-entity' | 'edit-entity' | 'create-relationship' | 'edit-relationship';
  entity?: Entity | null;
  relationship?: Relationship | null;
  onClose: () => void;
  onSave: (data: any) => Promise<void>;
}

export default function EditDialog({
  open,
  mode,
  entity,
  relationship,
  onClose,
  onSave,
}: EditDialogProps) {
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [propertiesText, setPropertiesText] = useState('{}');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const isEntity = mode === 'create-entity' || mode === 'edit-entity';

  useEffect(() => {
    if (!open) return;
    setError('');
    if (isEntity && entity) {
      setFormData({
        entity_id: entity.entity_id,
        name: entity.name,
        type: entity.type,
        description: entity.description || '',
        search_text: entity.search_text || '',
      });
      setPropertiesText(JSON.stringify(entity.properties || {}, null, 2));
    } else if (isEntity) {
      setFormData({
        entity_id: '',
        name: '',
        type: 'TABLE',
        description: '',
        search_text: '',
      });
      setPropertiesText('{}');
    } else if (relationship) {
      setFormData({
        source_id: relationship.source_id,
        target_id: relationship.target_id,
        type: relationship.type,
        description: relationship.description || '',
      });
      setPropertiesText(JSON.stringify(relationship.properties || {}, null, 2));
    } else {
      setFormData({
        source_id: '',
        target_id: '',
        type: 'HAS_COLUMN',
        description: '',
      });
      setPropertiesText('{}');
    }
  }, [open, mode, entity, relationship, isEntity]);

  if (!open) return null;

  const handleSave = async () => {
    setError('');
    setSaving(true);
    try {
      let props = {};
      try {
        props = JSON.parse(propertiesText);
      } catch {
        throw new Error('Properties is not valid JSON');
      }
      const data: any = { ...formData, properties: props };
      if (mode === 'edit-entity') {
        // Don't send entity_id (can't change PK)
        const { entity_id, ...rest } = data;
        await onSave(rest);
      } else {
        await onSave(data);
      }
    } catch (e: any) {
      setError(e.message || String(e));
    } finally {
      setSaving(false);
    }
  };

  const field = (label: string, key: string, type: string = 'text', opts?: any) => (
    <div className="form-field">
      <label>{label}</label>
      {type === 'textarea' ? (
        <textarea
          value={formData[key] || ''}
          onChange={(e) => setFormData({ ...formData, [key]: e.target.value })}
          rows={4}
          {...opts}
        />
      ) : type === 'select' ? (
        <select
          value={formData[key] || ''}
          onChange={(e) => setFormData({ ...formData, [key]: e.target.value })}
          {...opts}
        >
          {opts?.options?.map((o: string) => (
            <option key={o} value={o}>{o}</option>
          ))}
        </select>
      ) : (
        <input
          type={type}
          value={formData[key] || ''}
          onChange={(e) => setFormData({ ...formData, [key]: e.target.value })}
          disabled={opts?.disabled}
          {...opts}
        />
      )}
    </div>
  );

  const title = {
    'create-entity': 'Create Entity',
    'edit-entity': `Edit ${entity?.name || 'Entity'}`,
    'create-relationship': 'Create Relationship',
    'edit-relationship': `Edit Relationship #${relationship?.id}`,
  }[mode];

  const ENTITY_TYPES = ['TABLE', 'COLUMN', 'CONCEPT', 'JOIN_KEY', 'DATA_QUALITY_ISSUE', 'HOST'];
  const REL_TYPES = [
    'HAS_COLUMN', 'JOINS_TO', 'JOIN_KEY_IN_TABLE', 'CONCEPT_CONTAINS_COLUMN',
    'SEMANTICALLY_LINKED', 'AFFECTS_TABLE', 'HAS_CONCEPT',
  ];

  return (
    <div className="dialog-overlay" onClick={onClose}>
      <div className="dialog" onClick={(e) => e.stopPropagation()}>
        <div className="dialog-header">
          <h2>{title}</h2>
          <button className="dialog-close" onClick={onClose}>✕</button>
        </div>

        <div className="dialog-body">
          {isEntity ? (
            <>
              {mode === 'create-entity' &&
                field('Entity ID', 'entity_id', 'text', { placeholder: 'e.g. E0300' })}
              {mode === 'edit-entity' && (
                <div className="form-field">
                  <label>Entity ID (read-only)</label>
                  <input value={entity?.entity_id || ''} disabled />
                </div>
              )}
              {field('Name', 'name', 'text', { placeholder: 'e.g. uid_master' })}
              {field('Type', 'type', 'select', { options: ENTITY_TYPES })}
              {field('Description', 'description', 'textarea')}
              {field('Search Text', 'search_text', 'textarea')}
              <div className="form-field">
                <label>Properties (JSON)</label>
                <textarea
                  className="json-editor"
                  value={propertiesText}
                  onChange={(e) => setPropertiesText(e.target.value)}
                  rows={8}
                  spellCheck={false}
                  style={{ fontFamily: 'monospace', fontSize: 12 }}
                />
              </div>
            </>
          ) : (
            <>
              {field('Source ID', 'source_id', 'text', { placeholder: 'e.g. E0220' })}
              {field('Target ID', 'target_id', 'text', { placeholder: 'e.g. E0236' })}
              {field('Type', 'type', 'select', { options: REL_TYPES })}
              {field('Description', 'description', 'textarea')}
              <div className="form-field">
                <label>Properties (JSON)</label>
                <textarea
                  className="json-editor"
                  value={propertiesText}
                  onChange={(e) => setPropertiesText(e.target.value)}
                  rows={6}
                  spellCheck={false}
                  style={{ fontFamily: 'monospace', fontSize: 12 }}
                />
              </div>
            </>
          )}

          {error && <div className="dialog-error">{error}</div>}
        </div>

        <div className="dialog-footer">
          <button className="btn" onClick={onClose} disabled={saving}>Cancel</button>
          <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
            {saving ? 'Saving...' : 'Save'}
          </button>
        </div>
      </div>
    </div>
  );
}
