import { useCallback, useMemo } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  type Node,
  type Edge,
  type NodeProps,
  Handle,
  Position,
  MarkerType,
  BackgroundVariant,
} from '@xyflow/react';
import dagre from 'dagre';
import type { Entity, Relationship } from '../types';

// ─── Colors ────────────────────────────────────────────────────────────────────
export const TYPE_COLORS: Record<string, string> = {
  TABLE: '#3b82f6',
  COLUMN: '#10b981',
  CONCEPT: '#8b5cf6',
  JOIN_KEY: '#f59e0b',
  DATA_QUALITY_ISSUE: '#ef4444',
  HOST: '#6b7280',
};

const REL_COLORS: Record<string, string> = {
  HAS_COLUMN: '#10b981',
  JOINS_TO: '#3b82f6',
  JOIN_KEY_IN_TABLE: '#f59e0b',
  CONCEPT_CONTAINS_COLUMN: '#8b5cf6',
  SEMANTICALLY_LINKED: '#06b6d4',
  AFFECTS_TABLE: '#ef4444',
  HAS_CONCEPT: '#8b5cf6',
};

// ─── Custom node component ────────────────────────────────────────────────────
function EntityNode({ data }: NodeProps) {
  const d = data as any;
  const color = d.color || '#6b7280';
  const isSelected = d.selected;
  return (
    <div
      className="entity-node"
      style={{
        borderLeft: `4px solid ${color}`,
        boxShadow: isSelected ? `0 0 0 2px ${color}` : '0 1px 3px rgba(0,0,0,0.2)',
      }}
    >
      <Handle type="target" position={Position.Left} style={{ opacity: 0 }} />
      <div className="entity-node-type" style={{ color }}>
        {d.entityType}
      </div>
      <div className="entity-node-name" title={d.label as string}>
        {d.label}
      </div>
      <Handle type="source" position={Position.Right} style={{ opacity: 0 }} />
    </div>
  );
}

const nodeTypes = { entity: EntityNode };

// ─── Layout ────────────────────────────────────────────────────────────────────
function layoutGraph(nodes: Node[], edges: Edge[], direction: string = 'LR'): Node[] {
  const g = new dagre.graphlib.Graph();
  g.setDefaultEdgeLabel(() => ({}));
  g.setGraph({ rankdir: direction, nodesep: 30, ranksep: 60, marginx: 20, marginy: 20 });

  const nodeWidth = 200;
  const nodeHeight = 56;

  nodes.forEach((node) => {
    g.setNode(node.id, { width: nodeWidth, height: nodeHeight });
  });
  edges.forEach((edge) => {
    g.setEdge(edge.source, edge.target);
  });

  dagre.layout(g);

  return nodes.map((node) => {
    const pos = g.node(node.id);
    return {
      ...node,
      position: { x: pos.x - nodeWidth / 2, y: pos.y - nodeHeight / 2 },
    };
  });
}

// ─── Convert API data to React Flow ───────────────────────────────────────────
export function entitiesToNodes(entities: Entity[], selectedId?: string): Node[] {
  return entities.map((e) => ({
    id: e.entity_id,
    type: 'entity',
    data: {
      label: e.name,
      entityType: e.type,
      description: e.description,
      color: TYPE_COLORS[e.type] || '#6b7280',
      selected: e.entity_id === selectedId,
    },
    position: { x: 0, y: 0 },
  }));
}

export function relationshipsToEdges(rels: Relationship[]): Edge[] {
  return rels.map((r) => {
    const color = REL_COLORS[r.type] || '#94a3b8';
    return {
      id: `e${r.id}`,
      source: r.source_id,
      target: r.target_id,
      label: r.type.replace(/_/g, ' '),
      type: 'smoothstep',
      style: { stroke: color, strokeWidth: 1.5 },
      markerEnd: { type: MarkerType.ArrowClosed, color },
      data: { ...r },
      labelStyle: { fontSize: 10, fill: '#64748b' },
      labelBgStyle: { fill: '#f1f5f9' },
    };
  });
}

// ─── Main component ───────────────────────────────────────────────────────────
interface GraphCanvasProps {
  entities: Entity[];
  relationships: Relationship[];
  selectedEntityId?: string;
  onNodeClick: (entityId: string) => void;
  onEdgeClick: (relId: number) => void;
  onNodeDoubleClick: (entityId: string) => void;
}

export default function GraphCanvas({
  entities,
  relationships,
  selectedEntityId,
  onNodeClick,
  onEdgeClick,
  onNodeDoubleClick,
}: GraphCanvasProps) {
  const rawNodes = useMemo(
    () => entitiesToNodes(entities, selectedEntityId),
    [entities, selectedEntityId],
  );
  const rawEdges = useMemo(() => relationshipsToEdges(relationships), [relationships]);

  const { nodes, edges } = useMemo(() => {
    const laidOut = layoutGraph(rawNodes, rawEdges);
    return { nodes: laidOut, edges: rawEdges };
  }, [rawNodes, rawEdges]);

  const handleNodeClick = useCallback(
    (_: React.MouseEvent, node: Node) => {
      onNodeClick(node.id);
    },
    [onNodeClick],
  );

  const handleEdgeClick = useCallback(
    (_: React.MouseEvent, edge: Edge) => {
      const relId = edge.data?.id as number | undefined;
      if (relId !== undefined && relId !== null) onEdgeClick(relId);
    },
    [onEdgeClick],
  );

  const handleNodeDoubleClick = useCallback(
    (_: React.MouseEvent, node: Node) => {
      onNodeDoubleClick(node.id);
    },
    [onNodeDoubleClick],
  );

  return (
    <div className="graph-canvas">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        onNodeClick={handleNodeClick}
        onEdgeClick={handleEdgeClick}
        onNodeDoubleClick={handleNodeDoubleClick}
        fitView
        fitViewOptions={{ padding: 0.15, maxZoom: 1.5 }}
        minZoom={0.2}
        maxZoom={3}
        proOptions={{ hideAttribution: true }}
      >
        <Background variant={BackgroundVariant.Dots} gap={16} size={1} color="#e2e8f0" />
        <Controls position="bottom-right" showInteractive={false} />
        <MiniMap
          position="bottom-left"
          nodeColor={(node) => (node.data as any)?.color || '#94a3b8'}
          nodeStrokeWidth={2}
          pannable
          zoomable
          style={{ width: 160, height: 120 }}
        />
      </ReactFlow>

      {/* Legend */}
      <div className="graph-legend">
        <div className="legend-title">Legend</div>
        {Object.entries(TYPE_COLORS).map(([type, color]) => {
          const count = entities.filter((e) => e.type === type).length;
          if (count === 0) return null;
          return (
            <div key={type} className="legend-item">
              <span className="legend-dot" style={{ background: color }} />
              <span className="legend-label">{type.replace(/_/g, ' ')}</span>
              <span className="legend-count">{count}</span>
            </div>
          );
        })}
        {relationships.length > 0 && (
          <>
            <div className="legend-divider" />
            {Object.entries(REL_COLORS).map(([type, color]) => {
              const count = relationships.filter((r) => r.type === type).length;
              if (count === 0) return null;
              return (
                <div key={type} className="legend-item">
                  <span className="legend-line" style={{ background: color }} />
                  <span className="legend-label">{type.replace(/_/g, ' ')}</span>
                  <span className="legend-count">{count}</span>
                </div>
              );
            })}
          </>
        )}
      </div>
    </div>
  );
}
