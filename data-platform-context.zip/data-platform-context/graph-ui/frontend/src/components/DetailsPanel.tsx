import type { Selection } from '../types';

interface DetailsPanelProps {
  selection: Selection;
  onEdit: () => void;
  onDelete: () => void;
  onExpand: (entityId: string) => void;
  onFindPath: (entityId: string) => void;
  onEntityClick: (entityId: string) => void;
}

export default function DetailsPanel({
  selection,
  onEdit,
  onDelete,
  onExpand,
  onFindPath,
  onEntityClick,
}: DetailsPanelProps) {
  if (!selection) {
    return (
      <div className="details-panel">
        <div className="details-empty">
          <div className="details-empty-icon">◈</div>
          <p>Select an entity or relationship to see details</p>
          <p className="details-empty-hint">
            Click a node in the graph, search in the sidebar, or pick a table.
          </p>
        </div>
      </div>
    );
  }

  // ─── Entity details ────────────────────────────────────────────────────────
  if (selection.kind === 'entity') {
    const { entity, relationships } = selection;
    return (
      <div className="details-panel">
        <div className="details-header">
          <span className={`type-badge type-${entity.type.toLowerCase()}`}>{entity.type}</span>
          <h2 className="details-title" title={entity.name}>{entity.name}</h2>
          <div className="details-id">ID: {entity.entity_id}</div>
        </div>

        <div className="details-actions">
          <button className="btn btn-primary" onClick={onEdit}>✎ Edit</button>
          <button className="btn btn-danger" onClick={onDelete}>🗑 Delete</button>
        </div>

        {entity.description && (
          <div className="details-section">
            <div className="section-title">Description</div>
            <div className="details-description">{entity.description}</div>
          </div>
        )}

        {entity.search_text && entity.search_text !== entity.description && (
          <div className="details-section">
            <div className="section-title">Search Text</div>
            <div className="details-search-text">{entity.search_text}</div>
          </div>
        )}

        {entity.properties && Object.keys(entity.properties).length > 0 && (
          <div className="details-section">
            <div className="section-title">Properties</div>
            <div className="properties-grid">
              {Object.entries(entity.properties).map(([key, value]) => (
                <div key={key} className="property-row">
                  <span className="property-key">{key}</span>
                  <span className="property-value">
                    {typeof value === 'object' ? JSON.stringify(value) : String(value)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="details-section">
          <div className="section-title">Actions</div>
          <div className="details-actions-row">
            <button className="btn" onClick={() => onExpand(entity.entity_id)}>
              ⇱ Expand Neighbors
            </button>
            <button className="btn" onClick={() => onFindPath(entity.entity_id)}>
              🔗 Find Path From...
            </button>
          </div>
        </div>

        <div className="details-section">
          <div className="section-title">Relationships ({relationships.length})</div>
          <div className="rel-list">
            {relationships.map((r) => {
              const isSource = r.source_id === entity.entity_id;
              const otherId = isSource ? r.target_id : r.source_id;
              const otherName = isSource ? r.target_name : r.source_name;
              const otherType = isSource ? r.target_type : r.source_type;
              return (
                <div
                  key={r.id}
                  className="rel-item"
                  onClick={() => onEntityClick(otherId)}
                >
                  <div className="rel-direction">
                    {isSource ? '→' : '←'} <span className="rel-type">{r.type.replace(/_/g, ' ')}</span>
                  </div>
                  <div className="rel-other">
                    <span className={`type-badge-sm type-${otherType?.toLowerCase()}`}>{otherType}</span>
                    <span className="rel-other-name">{otherName}</span>
                  </div>
                  {r.description && <div className="rel-desc">{r.description}</div>}
                </div>
              );
            })}
            {relationships.length === 0 && (
              <div className="rel-empty">No relationships</div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ─── Relationship details ──────────────────────────────────────────────────
  if (selection.kind === 'relationship') {
    const { rel } = selection;
    return (
      <div className="details-panel">
        <div className="details-header">
          <span className="type-badge type-relationship">{rel.type.replace(/_/g, ' ')}</span>
          <h2 className="details-title">Relationship #{rel.id}</h2>
        </div>

        <div className="details-actions">
          <button className="btn btn-primary" onClick={onEdit}>✎ Edit</button>
          <button className="btn btn-danger" onClick={onDelete}>🗑 Delete</button>
        </div>

        <div className="details-section">
          <div className="section-title">Source → Target</div>
          <div className="rel-flow">
            <div className="rel-endpoint" onClick={() => onEntityClick(rel.source_id)}>
              <span className={`type-badge type-${rel.source_type?.toLowerCase()}`}>{rel.source_type}</span>
              <div className="rel-endpoint-name">{rel.source_name}</div>
              <div className="rel-endpoint-id">{rel.source_id}</div>
            </div>
            <div className="rel-arrow">→</div>
            <div className="rel-endpoint" onClick={() => onEntityClick(rel.target_id)}>
              <span className={`type-badge type-${rel.target_type?.toLowerCase()}`}>{rel.target_type}</span>
              <div className="rel-endpoint-name">{rel.target_name}</div>
              <div className="rel-endpoint-id">{rel.target_id}</div>
            </div>
          </div>
        </div>

        {rel.description && (
          <div className="details-section">
            <div className="section-title">Description</div>
            <div className="details-description">{rel.description}</div>
          </div>
        )}

        {rel.properties && Object.keys(rel.properties).length > 0 && (
          <div className="details-section">
            <div className="section-title">Properties</div>
            <div className="properties-grid">
              {Object.entries(rel.properties).map(([key, value]) => (
                <div key={key} className="property-row">
                  <span className="property-key">{key}</span>
                  <span className="property-value">
                    {typeof value === 'object' ? JSON.stringify(value) : String(value)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ─── Validation results ────────────────────────────────────────────────────
  if (selection.kind === 'validation') {
    return (
      <div className="details-panel">
        <div className="details-header">
          <h2 className="details-title">⚠ Validation Results</h2>
        </div>
        {selection.items.length === 0 ? (
          <div className="validation-clean">
            <div className="validation-clean-icon">✓</div>
            <p>All checks passed! No issues found.</p>
          </div>
        ) : (
          <div className="validation-list">
            {selection.items.map((item, i) => (
              <div key={i} className={`validation-item severity-${item.severity}`}>
                <div className="validation-header">
                  <span className={`severity-badge severity-${item.severity}`}>
                    {item.severity.toUpperCase()}
                  </span>
                  <span className="validation-category">{item.category}</span>
                  <span className="validation-count">{item.count}</span>
                </div>
                <div className="validation-message">{item.message}</div>
                {item.items.length > 0 && (
                  <div className="validation-items">
                    {item.items.slice(0, 10).map((it: any, j: number) => (
                      <div key={j} className="validation-subitem">
                        {it.name || it.entity_id || JSON.stringify(it).slice(0, 80)}
                      </div>
                    ))}
                    {item.items.length > 10 && (
                      <div className="validation-more">+{item.items.length - 10} more</div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  return null;
}
