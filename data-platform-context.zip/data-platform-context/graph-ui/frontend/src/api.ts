import type { Entity, Relationship, GraphData, Stats, ValidationItem, TableInfo } from './types';

const BASE = '/api';

async function fetchJSON<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, options);
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || `HTTP ${res.status}`);
  }
  return res.json();
}

export const api = {
  getStats: () => fetchJSON<Stats>(`${BASE}/stats`),

  getEntities: (params?: { type?: string; search?: string; limit?: number }) => {
    const q = new URLSearchParams();
    if (params?.type) q.set('type', params.type);
    if (params?.search) q.set('search', params.search);
    if (params?.limit) q.set('limit', String(params.limit));
    return fetchJSON<Entity[]>(`${BASE}/entities?${q}`);
  },

  getEntity: (id: string) =>
    fetchJSON<{ entity: Entity; relationships: Relationship[] }>(`${BASE}/entities/${encodeURIComponent(id)}`),

  createEntity: (data: Partial<Entity>) =>
    fetchJSON<Entity>(`${BASE}/entities`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }),

  updateEntity: (id: string, data: Partial<Entity>) =>
    fetchJSON<Entity>(`${BASE}/entities/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }),

  deleteEntity: (id: string) =>
    fetchJSON<{ deleted: string }>(`${BASE}/entities/${encodeURIComponent(id)}`, { method: 'DELETE' }),

  getRelationships: (params?: { source?: string; target?: string; type?: string }) => {
    const q = new URLSearchParams();
    if (params?.source) q.set('source', params.source);
    if (params?.target) q.set('target', params.target);
    if (params?.type) q.set('type', params.type);
    return fetchJSON<Relationship[]>(`${BASE}/relationships?${q}`);
  },

  createRelationship: (data: Partial<Relationship>) =>
    fetchJSON<Relationship>(`${BASE}/relationships`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }),

  updateRelationship: (id: number, data: Partial<Relationship>) =>
    fetchJSON<Relationship>(`${BASE}/relationships/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }),

  deleteRelationship: (id: number) =>
    fetchJSON<{ deleted: number }>(`${BASE}/relationships/${id}`, { method: 'DELETE' }),

  getTableGraph: () => fetchJSON<GraphData>(`${BASE}/graph/tables`),

  getSubgraph: (center: string, depth: number = 1) =>
    fetchJSON<GraphData>(`${BASE}/graph?center=${encodeURIComponent(center)}&depth=${depth}`),

  findPath: (from: string, to: string) =>
    fetchJSON<{ path: string[]; nodes: Entity[]; edges: Relationship[] }>(
      `${BASE}/path?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`,
    ),

  getTables: () => fetchJSON<TableInfo[]>(`${BASE}/tables`),

  validate: () => fetchJSON<ValidationItem[]>(`${BASE}/validate`),

  getEntityTypes: () => fetchJSON<string[]>(`${BASE}/entity-types`),

  getRelationshipTypes: () => fetchJSON<string[]>(`${BASE}/relationship-types`),
};
