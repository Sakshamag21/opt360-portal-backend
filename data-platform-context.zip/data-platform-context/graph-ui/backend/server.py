#!/usr/bin/env python3
"""
GraphRAG Navigator API — Flask backend.
Serves REST endpoints for browsing/editing the GraphRAG PostgreSQL graph.

Since psycopg2 can't be installed (no pip internet), uses `docker exec -i psql`.
"""

import subprocess, json, os, sys
from flask import Flask, request, jsonify, send_from_directory

app = Flask(__name__, static_folder=None)

# ─── Config ────────────────────────────────────────────────────────────────────
CONTAINER = "graphrag-postgres"
DB_USER = "graphrag"
DB_NAME = "graphrag"
PORT = 5051

# ─── DB helpers ────────────────────────────────────────────────────────────────

def pg_query(sql, params=None):
    """Execute a SELECT and return list of dicts. Wraps in json_agg for JSON output."""
    if params:
        # Build parameterized query manually (safe-ish since we control inputs)
        sql = _apply_params(sql, params)
    # Strip trailing semicolons — they break the json_agg wrapper
    sql = sql.rstrip().rstrip(";").strip()
    wrapped = f"SELECT coalesce(json_agg(row_to_json(t)), '[]'::json) FROM ({sql}) t;"
    return _exec_psql(wrapped)

def pg_query_one(sql, params=None):
    """Execute a SELECT and return a single dict (or None)."""
    if params:
        sql = _apply_params(sql, params)
    sql = sql.rstrip().rstrip(";").strip()
    wrapped = f"SELECT coalesce(row_to_json(t), 'null'::json) FROM ({sql}) t;"
    result = _exec_psql(wrapped)
    # row_to_json returns a single JSON object → parsed as dict
    if isinstance(result, dict):
        return result
    # If it came back as a list (shouldn't for row_to_json), take first
    if isinstance(result, list) and result:
        return result[0]
    return None

def pg_execute(sql, params=None):
    """Execute INSERT/UPDATE/DELETE with RETURNING. Returns list of dicts."""
    if params:
        sql = _apply_params(sql, params)
    sql = sql.rstrip().rstrip(";").strip()
    wrapped = f"WITH result AS ({sql}) SELECT coalesce(json_agg(row_to_json(r)), '[]'::json) FROM result r;"
    return _exec_psql(wrapped)

def _apply_params(sql, params):
    """Replace %(key)s placeholders with escaped values."""
    for key, val in (params or {}).items():
        if val is None:
            replacement = "NULL"
        elif isinstance(val, bool):
            replacement = "true" if val else "false"
        elif isinstance(val, (int, float)):
            replacement = str(val)
        else:
            escaped = str(val).replace("'", "''")
            replacement = f"'{escaped}'"
        sql = sql.replace(f"%({key})s", replacement)
    return sql

def _exec_psql(sql):
    """Execute SQL via docker exec -i psql, return parsed JSON."""
    try:
        result = subprocess.run(
            ["docker", "exec", "-i", CONTAINER, "psql", "-U", DB_USER, "-d", DB_NAME, "-t", "-A"],
            input=sql.encode("utf-8"),
            capture_output=True,
            timeout=30,
        )
        if result.returncode != 0:
            err = result.stderr.decode("utf-8", errors="replace").strip()
            raise Exception(f"psql error: {err}")
        out = result.stdout.decode("utf-8", errors="replace").strip()
        if not out or out == "null":
            return []
        return json.loads(out)
    except subprocess.TimeoutExpired:
        raise Exception("Query timed out (30s)")
    except json.JSONDecodeError as e:
        raise Exception(f"JSON parse error: {e}. Raw output: {out[:500]}")

def sql_escape(s):
    if s is None:
        return "NULL"
    return "'" + str(s).replace("'", "''") + "'"

def jsonb_literal(obj):
    return sql_escape(json.dumps(obj, ensure_ascii=False)) + "::jsonb"


# ═══════════════════════════════════════════════════════════════
#  API ROUTES
# ═══════════════════════════════════════════════════════════════

@app.route("/api/health")
def health():
    try:
        r = pg_query_one("SELECT count(*) AS cnt FROM entities")
        return jsonify({"status": "ok", "entities": r["cnt"]})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


# ─── Stats ─────────────────────────────────────────────────────────────────────

@app.route("/api/stats")
def stats():
    """Graph summary stats."""
    try:
        entity_types = pg_query("""
            SELECT type, count(*) AS count
            FROM entities GROUP BY type ORDER BY count DESC
        """)
        rel_types = pg_query("""
            SELECT type, count(*) AS count
            FROM relationships GROUP BY type ORDER BY count DESC
        """)
        totals = pg_query_one("""
            SELECT
                (SELECT count(*) FROM entities) AS total_entities,
                (SELECT count(*) FROM relationships) AS total_relationships,
                (SELECT count(*) FROM query_paths) AS total_query_paths,
                (SELECT count(*) FROM text_units) AS total_text_units,
                (SELECT count(*) FROM communities) AS total_communities
        """)
        return jsonify({
            "entity_types": {r["type"]: r["count"] for r in entity_types},
            "relationship_types": {r["type"]: r["count"] for r in rel_types},
            **totals,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─── Entities ──────────────────────────────────────────────────────────────────

@app.route("/api/entities")
def list_entities():
    """List entities with optional filtering. Params: type, search, limit."""
    try:
        conditions = []
        params = {}
        entity_type = request.args.get("type")
        search = request.args.get("search")
        limit = min(int(request.args.get("limit", 200)), 500)

        if entity_type:
            conditions.append("type = %(type)s")
            params["type"] = entity_type
        if search:
            conditions.append("(search_text ILIKE %(search)s OR name ILIKE %(search)s)")
            params["search"] = f"%{search}%"

        where = " AND ".join(conditions) if conditions else "TRUE"
        sql = f"""
            SELECT entity_id, name, type, description,
                   properties, search_text, created_at, updated_at
            FROM entities
            WHERE {where}
            ORDER BY type, name
            LIMIT {limit}
        """
        rows = pg_query(sql, params)
        return jsonify(rows)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/entities/<entity_id>")
def get_entity(entity_id):
    """Get a single entity with all its relationships."""
    try:
        entity = pg_query_one(
            "SELECT * FROM entities WHERE entity_id = %(id)s",
            {"id": entity_id},
        )
        if not entity:
            return jsonify({"error": "Entity not found"}), 404

        rels = pg_query("""
            SELECT r.id, r.source_id, r.target_id, r.type, r.description, r.properties,
                   se.name AS source_name, se.type AS source_type,
                   te.name AS target_name, te.type AS target_type
            FROM relationships r
            JOIN entities se ON r.source_id = se.entity_id
            JOIN entities te ON r.target_id = te.entity_id
            WHERE r.source_id = %(id)s OR r.target_id = %(id)s
            ORDER BY r.type
        """, {"id": entity_id})

        return jsonify({"entity": entity, "relationships": rels})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/entities", methods=["POST"])
def create_entity():
    """Create a new entity."""
    try:
        data = request.json
        entity_id = data["entity_id"]
        name = data["name"]
        etype = data["type"]
        description = data.get("description", "")
        properties = data.get("properties", {})
        search_text = data.get("search_text", f"{name} {description}")

        rows = pg_execute(f"""
            INSERT INTO entities (entity_id, name, type, description, properties, search_text)
            VALUES ({sql_escape(entity_id)}, {sql_escape(name)}, {sql_escape(etype)},
                    {sql_escape(description)}, {jsonb_literal(properties)}, {sql_escape(search_text)})
            RETURNING entity_id, name, type, description, properties, search_text, created_at, updated_at
        """)
        return jsonify(rows[0] if rows else {"error": "Insert failed"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/entities/<entity_id>", methods=["PUT"])
def update_entity(entity_id):
    """Update an entity. Only updates provided fields."""
    try:
        data = request.json
        sets = []
        if "name" in data:
            sets.append(f"name = {sql_escape(data['name'])}")
        if "type" in data:
            sets.append(f"type = {sql_escape(data['type'])}")
        if "description" in data:
            sets.append(f"description = {sql_escape(data['description'])}")
        if "search_text" in data:
            sets.append(f"search_text = {sql_escape(data['search_text'])}")
        if "properties" in data:
            sets.append(f"properties = {jsonb_literal(data['properties'])}")

        if not sets:
            return jsonify({"error": "No fields to update"}), 400

        rows = pg_execute(f"""
            UPDATE entities SET {', '.join(sets)}
            WHERE entity_id = {sql_escape(entity_id)}
            RETURNING entity_id, name, type, description, properties, search_text, created_at, updated_at
        """)
        if not rows:
            return jsonify({"error": "Entity not found"}), 404
        return jsonify(rows[0])
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/entities/<entity_id>", methods=["DELETE"])
def delete_entity(entity_id):
    """Delete an entity. Relationships cascade-delete via FK."""
    try:
        pg_execute(f"DELETE FROM entities WHERE entity_id = {sql_escape(entity_id)}")
        return jsonify({"deleted": entity_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─── Relationships ─────────────────────────────────────────────────────────────

@app.route("/api/relationships")
def list_relationships():
    """List relationships with optional filtering. Params: source, target, type."""
    try:
        conditions = []
        params = {}
        if request.args.get("source"):
            conditions.append("r.source_id = %(source)s")
            params["source"] = request.args["source"]
        if request.args.get("target"):
            conditions.append("r.target_id = %(target)s")
            params["target"] = request.args["target"]
        if request.args.get("type"):
            conditions.append("r.type = %(type)s")
            params["type"] = request.args["type"]

        where = " AND ".join(conditions) if conditions else "TRUE"
        limit = min(int(request.args.get("limit", 200)), 500)
        sql = f"""
            SELECT r.id, r.source_id, r.target_id, r.type, r.description, r.properties,
                   se.name AS source_name, se.type AS source_type,
                   te.name AS target_name, te.type AS target_type
            FROM relationships r
            JOIN entities se ON r.source_id = se.entity_id
            JOIN entities te ON r.target_id = te.entity_id
            WHERE {where}
            ORDER BY r.type, se.name, te.name
            LIMIT {limit}
        """
        return jsonify(pg_query(sql, params))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/relationships", methods=["POST"])
def create_relationship():
    """Create a new relationship."""
    try:
        data = request.json
        rows = pg_execute(f"""
            INSERT INTO relationships (source_id, target_id, type, description, properties)
            VALUES ({sql_escape(data['source_id'])}, {sql_escape(data['target_id'])},
                    {sql_escape(data['type'])}, {sql_escape(data.get('description', ''))},
                    {jsonb_literal(data.get('properties', {}))})
            RETURNING id, source_id, target_id, type, description, properties
        """)
        return jsonify(rows[0] if rows else {"error": "Insert failed"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/relationships/<int:rel_id>", methods=["PUT"])
def update_relationship(rel_id):
    """Update a relationship."""
    try:
        data = request.json
        sets = []
        if "type" in data:
            sets.append(f"type = {sql_escape(data['type'])}")
        if "description" in data:
            sets.append(f"description = {sql_escape(data['description'])}")
        if "properties" in data:
            sets.append(f"properties = {jsonb_literal(data['properties'])}")
        if "source_id" in data:
            sets.append(f"source_id = {sql_escape(data['source_id'])}")
        if "target_id" in data:
            sets.append(f"target_id = {sql_escape(data['target_id'])}")

        if not sets:
            return jsonify({"error": "No fields to update"}), 400

        rows = pg_execute(f"""
            UPDATE relationships SET {', '.join(sets)}
            WHERE id = {rel_id}
            RETURNING id, source_id, target_id, type, description, properties
        """)
        if not rows:
            return jsonify({"error": "Relationship not found"}), 404
        return jsonify(rows[0])
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/relationships/<int:rel_id>", methods=["DELETE"])
def delete_relationship(rel_id):
    """Delete a relationship."""
    try:
        pg_execute(f"DELETE FROM relationships WHERE id = {rel_id}")
        return jsonify({"deleted": rel_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─── Graph (for visualization) ────────────────────────────────────────────────

@app.route("/api/graph/tables")
def graph_tables():
    """High-level graph: all TABLE + JOIN_KEY + CONCEPT entities and inter-table relationships."""
    try:
        nodes = pg_query("""
            SELECT entity_id, name, type, description, properties
            FROM entities
            WHERE type IN ('TABLE', 'JOIN_KEY', 'CONCEPT')
            ORDER BY type, name
        """)
        edges = pg_query("""
            SELECT r.id, r.source_id, r.target_id, r.type, r.description, r.properties
            FROM relationships r
            WHERE r.source_id IN (SELECT entity_id FROM entities WHERE type IN ('TABLE', 'JOIN_KEY', 'CONCEPT'))
              AND r.target_id IN (SELECT entity_id FROM entities WHERE type IN ('TABLE', 'JOIN_KEY', 'CONCEPT'))
        """)
        return jsonify({"nodes": nodes, "edges": edges})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/graph")
def graph_subgraph():
    """Get a subgraph centered on an entity. Params: center (entity_id), depth (1-3)."""
    try:
        center = request.args.get("center")
        depth = min(int(request.args.get("depth", 1)), 3)

        if not center:
            return jsonify({"error": "center parameter required"}), 400

        # BFS: find all entities within `depth` hops
        visited = set()
        current = {center}
        all_node_ids = set()

        for _ in range(depth + 1):
            all_node_ids.update(current)
            if not current:
                break
            id_list = ", ".join(f"'{eid}'" for eid in current)
            neighbors = pg_query(f"""
                SELECT DISTINCT
                    CASE WHEN source_id IN ({id_list}) THEN target_id ELSE source_id END AS neighbor_id
                FROM relationships
                WHERE source_id IN ({id_list}) OR target_id IN ({id_list})
            """)
            current = {r["neighbor_id"] for r in neighbors if r["neighbor_id"] not in all_node_ids}

        if not all_node_ids:
            return jsonify({"nodes": [], "edges": []})

        id_list = ", ".join(f"'{eid}'" for eid in all_node_ids)
        nodes = pg_query(f"""
            SELECT entity_id, name, type, description, properties
            FROM entities WHERE entity_id IN ({id_list})
            ORDER BY type, name
        """)
        edges = pg_query(f"""
            SELECT r.id, r.source_id, r.target_id, r.type, r.description, r.properties
            FROM relationships r
            WHERE r.source_id IN ({id_list}) AND r.target_id IN ({id_list})
        """)
        return jsonify({"nodes": nodes, "edges": edges})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/path")
def find_path():
    """Find shortest path between two entities (BFS)."""
    try:
        from_id = request.args.get("from")
        to_id = request.args.get("to")
        if not from_id or not to_id:
            return jsonify({"error": "from and to parameters required"}), 400

        # BFS
        visited = {from_id: None}  # node -> parent
        queue = [from_id]
        found = False

        while queue and not found:
            next_queue = []
            for node in queue:
                if node == to_id:
                    found = True
                    break
                id_list = f"'{node}'"
                neighbors = pg_query(f"""
                    SELECT DISTINCT
                        CASE WHEN source_id = '{node}' THEN target_id ELSE source_id END AS neighbor_id
                    FROM relationships
                    WHERE source_id = '{node}' OR target_id = '{node}'
                """)
                for n in neighbors:
                    nid = n["neighbor_id"]
                    if nid not in visited:
                        visited[nid] = node
                        next_queue.append(nid)
            queue = next_queue

        if to_id not in visited:
            return jsonify({"path": [], "nodes": [], "edges": []})

        # Reconstruct path
        path = []
        node = to_id
        while node:
            path.append(node)
            node = visited[node]
        path.reverse()

        # Get entities and edges along path
        id_list = ", ".join(f"'{eid}'" for eid in path)
        nodes = pg_query(f"SELECT entity_id, name, type, description, properties FROM entities WHERE entity_id IN ({id_list})")
        edges = pg_query(f"""
            SELECT r.id, r.source_id, r.target_id, r.type, r.description, r.properties
            FROM relationships r
            WHERE r.source_id IN ({id_list}) AND r.target_id IN ({id_list})
        """)

        return jsonify({"path": path, "nodes": nodes, "edges": edges})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─── Tables (convenience) ─────────────────────────────────────────────────────

@app.route("/api/tables")
def list_tables():
    """List all TABLE entities with their column counts."""
    try:
        rows = pg_query("""
            SELECT
                e.entity_id,
                e.name,
                e.description,
                e.properties,
                (SELECT count(*) FROM relationships r
                 JOIN entities c ON r.target_id = c.entity_id
                 WHERE r.source_id = e.entity_id AND r.type = 'HAS_COLUMN' AND c.type = 'COLUMN') AS column_count
            FROM entities e
            WHERE e.type = 'TABLE'
            ORDER BY e.name
        """)
        return jsonify(rows)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─── Validation ───────────────────────────────────────────────────────────────

@app.route("/api/validate")
def validate():
    """Run data integrity checks."""
    try:
        results = []

        # 1. Orphaned entities (no relationships)
        orphans = pg_query("""
            SELECT e.entity_id, e.name, e.type
            FROM entities e
            WHERE NOT EXISTS (
                SELECT 1 FROM relationships r
                WHERE r.source_id = e.entity_id OR r.target_id = e.entity_id
            )
            AND e.type NOT IN ('CONCEPT', 'HOST')
            ORDER BY e.type, e.name
        """)
        if orphans:
            results.append({
                "category": "Orphaned Entities",
                "severity": "warning",
                "message": f"{len(orphans)} entities have no relationships (excluding CONCEPT/HOST)",
                "items": orphans[:20],
                "count": len(orphans),
            })

        # 2. Entities with empty descriptions
        empty_desc = pg_query("""
            SELECT entity_id, name, type
            FROM entities
            WHERE (description IS NULL OR description = '' OR description LIKE 'TODO%')
              AND type NOT IN ('CONCEPT')
            ORDER BY type, name
        """)
        if empty_desc:
            results.append({
                "category": "Missing Descriptions",
                "severity": "warning",
                "message": f"{len(empty_desc)} entities have empty or TODO descriptions",
                "items": empty_desc[:20],
                "count": len(empty_desc),
            })

        # 3. Duplicate entity names
        dups = pg_query("""
            SELECT name, count(*) AS cnt, array_agg(entity_id) AS ids, array_agg(type) AS types
            FROM entities
            GROUP BY name
            HAVING count(*) > 1
            ORDER BY cnt DESC
        """)
        if dups:
            results.append({
                "category": "Duplicate Names",
                "severity": "warning",
                "message": f"{len(dups)} entity names appear more than once",
                "items": dups[:20],
                "count": len(dups),
            })

        # 4. Relationships with empty descriptions
        empty_rel_desc = pg_query("""
            SELECT r.id, r.source_id, r.target_id, r.type
            FROM relationships r
            WHERE r.description IS NULL OR r.description = ''
        """)
        if empty_rel_desc:
            results.append({
                "category": "Relationship Descriptions",
                "severity": "info",
                "message": f"{len(empty_rel_desc)} relationships have empty descriptions",
                "items": empty_rel_desc[:20],
                "count": len(empty_rel_desc),
            })

        # 5. Columns not linked to any table
        unlinked_cols = pg_query("""
            SELECT e.entity_id, e.name
            FROM entities e
            WHERE e.type = 'COLUMN'
              AND NOT EXISTS (
                  SELECT 1 FROM relationships r
                  WHERE r.target_id = e.entity_id AND r.type = 'HAS_COLUMN'
              )
        """)
        if unlinked_cols:
            results.append({
                "category": "Unlinked Columns",
                "severity": "warning",
                "message": f"{len(unlinked_cols)} COLUMN entities are not linked to any table via HAS_COLUMN",
                "items": unlinked_cols[:20],
                "count": len(unlinked_cols),
            })

        # 6. Self-referencing relationships
        self_refs = pg_query("""
            SELECT id, source_id, target_id, type, description
            FROM relationships
            WHERE source_id = target_id
        """)
        if self_refs:
            results.append({
                "category": "Self-Referencing Relationships",
                "severity": "error",
                "message": f"{len(self_refs)} relationships point from an entity to itself",
                "items": self_refs[:20],
                "count": len(self_refs),
            })

        return jsonify(results)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─── Entity types ─────────────────────────────────────────────────────────────

@app.route("/api/entity-types")
def entity_types():
    """List all distinct entity types."""
    try:
        rows = pg_query("SELECT DISTINCT type FROM entities ORDER BY type")
        return jsonify([r["type"] for r in rows])
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/relationship-types")
def relationship_types():
    """List all distinct relationship types."""
    try:
        rows = pg_query("SELECT DISTINCT type FROM relationships ORDER BY type")
        return jsonify([r["type"] for r in rows])
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─── Serve frontend (production mode) ─────────────────────────────────────────

@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve_frontend(path):
    """Serve the built React frontend."""
    frontend_dist = os.path.join(os.path.dirname(__file__), "..", "frontend", "dist")
    if path and os.path.exists(os.path.join(frontend_dist, path)):
        return send_from_directory(frontend_dist, path)
    return send_from_directory(frontend_dist, "index.html")


if __name__ == "__main__":
    print(f"GraphRAG Navigator API starting on port {PORT}...")
    print(f"  PostgreSQL: {CONTAINER} (via docker exec)")
    app.run(host="0.0.0.0", port=PORT, debug=True)
