#!/usr/bin/env python3
"""
Chatbot API — Flask backend with JWT auth, RBAC, SSE pipeline streaming.

Roles:
  - admin:    full access + user management
  - analyst:  ask questions, verify SQL, manage own conversations

Run:
    python app.py
"""

import sys
import os
import json
import time
import uuid
import threading
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, request, jsonify, g, Response, stream_with_context, send_from_directory

import config
from db import pg_query, pg_query_one, pg_execute, sql_escape, jsonb_literal
from auth import (
    create_access_token, create_refresh_token, decode_token,
    hash_password, verify_password,
    get_user_by_id, get_user_by_username, get_user_by_email,
    auth_required, admin_required,
)
from pipeline import (
    create_task, get_task, cleanup_old_tasks,
    get_pipeline, trino_query, trino_explain,
)

import queue as queue_module


# ═══════════════════════════════════════════════════════════════
#  Flask App + Manual CORS (flask-cors not available)
# ═══════════════════════════════════════════════════════════════

app = Flask(__name__)
app.config["SECRET_KEY"] = config.SECRET_KEY


@app.after_request
def add_cors_headers(response):
    """Manual CORS handling."""
    origin = request.headers.get("Origin", "")
    if origin in config.CORS_ORIGINS:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Credentials"] = "true"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, X-Requested-With"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    return response


@app.before_request
def handle_preflight():
    """Handle OPTIONS preflight requests."""
    if request.method == "OPTIONS":
        response = jsonify({"ok": True})
        response.status_code = 204
        return response


def _now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _success(data=None, message=None):
    resp = {"success": True}
    if message:
        resp["message"] = message
    if data is not None:
        resp.update(data) if isinstance(data, dict) else resp.update({"data": data})
    return jsonify(resp)


def _error(message, code=400):
    return jsonify({"success": False, "error": message}), code


# ═══════════════════════════════════════════════════════════════
#  Health
# ═══════════════════════════════════════════════════════════════

@app.route("/api/health")
def health():
    """System health check — no auth required."""
    import requests
    trino_ok = False
    llm_ok = False
    try:
        r = requests.get(f"{config.TRINO_URL}/v1/info", timeout=3)
        trino_ok = r.status_code == 200
    except Exception:
        pass
    try:
        r = requests.get(f"{config.LLM_URL}/models", timeout=3)
        llm_ok = r.status_code == 200
    except Exception:
        pass
    return jsonify({
        "status": "ok",
        "services": {
            "trino": "online" if trino_ok else "offline",
            "llm": "online" if llm_ok else "offline",
            "database": "online",
        }
    })


# ═══════════════════════════════════════════════════════════════
#  Auth Routes
# ═══════════════════════════════════════════════════════════════

@app.route("/api/auth/login", methods=["POST"])
def login():
    """Authenticate user and return JWT tokens."""
    data = request.get_json() or {}
    username = data.get("username", "").strip()
    password = data.get("password", "")

    if not username or not password:
        return _error("Username and password required", 400)

    user = get_user_by_username(username)
    if not user:
        # Try email
        user = get_user_by_email(username)

    if not user or not verify_password(password, user["password_hash"]):
        return _error("Invalid credentials", 401)

    if not user.get("is_active"):
        return _error("Account deactivated. Contact admin.", 403)

    access_token = create_access_token(user["id"], user["username"], user["role"])
    refresh_token = create_refresh_token(user["id"])

    return _success({
        "token": access_token,
        "refreshToken": refresh_token,
        "user": {
            "id": user["id"],
            "username": user["username"],
            "email": user["email"],
            "role": user["role"],
            "fullName": user.get("full_name", ""),
        }
    })


@app.route("/api/auth/refresh", methods=["POST"])
def refresh():
    """Refresh an access token using a refresh token."""
    data = request.get_json() or {}
    refresh_token = data.get("refreshToken", "")

    if not refresh_token:
        return _error("Refresh token required", 400)

    try:
        payload = decode_token(refresh_token)
    except Exception:
        return _error("Invalid or expired refresh token", 401)

    if payload.get("type") != "refresh":
        return _error("Invalid token type", 401)

    user = get_user_by_id(payload.get("uid", int(payload.get("sub", 0))))
    if not user or not user.get("is_active"):
        return _error("User not found or deactivated", 401)

    access_token = create_access_token(user["id"], user["username"], user["role"])
    return _success({"token": access_token})


@app.route("/api/auth/me", methods=["GET"])
@auth_required
def me():
    """Get current user info."""
    user = g.current_user
    return _success({
        "user": {
            "id": user["id"],
            "username": user["username"],
            "email": user["email"],
            "role": user["role"],
            "fullName": user.get("full_name", ""),
            "isActive": user.get("is_active", True),
            "createdAt": user.get("created_at"),
        }
    })


@app.route("/api/auth/change-password", methods=["POST"])
@auth_required
def change_password():
    """Change the current user's password."""
    data = request.get_json() or {}
    old_password = data.get("oldPassword", "")
    new_password = data.get("newPassword", "")

    if not old_password or not new_password:
        return _error("Old and new passwords required", 400)
    if len(new_password) < 6:
        return _error("New password must be at least 6 characters", 400)

    user = get_user_by_username(g.current_user["username"])
    if not verify_password(old_password, user["password_hash"]):
        return _error("Current password is incorrect", 401)

    new_hash = hash_password(new_password)
    pg_execute(
        "UPDATE app_users SET password_hash = %(hash)s WHERE id = %(uid)s",
        {"hash": new_hash, "uid": g.current_user["id"]}
    )
    return _success(message="Password changed successfully")


# ═══════════════════════════════════════════════════════════════
#  User Management (admin only)
# ═══════════════════════════════════════════════════════════════

@app.route("/api/users", methods=["GET"])
@auth_required
@admin_required
def list_users():
    """List all users (admin only)."""
    users = pg_query(
        "SELECT id, username, email, role, full_name, is_active, created_at, updated_at "
        "FROM app_users ORDER BY created_at ASC"
    )
    return _success({"users": users})


@app.route("/api/users", methods=["POST"])
@auth_required
@admin_required
def create_user():
    """Create a new user (admin only)."""
    data = request.get_json() or {}
    username = data.get("username", "").strip()
    email = data.get("email", "").strip()
    password = data.get("password", "")
    role = data.get("role", "analyst")
    full_name = data.get("fullName", "").strip()

    if not username or not email or not password:
        return _error("Username, email, and password are required", 400)
    if role not in ("admin", "analyst"):
        return _error("Role must be 'admin' or 'analyst'", 400)
    if len(password) < 6:
        return _error("Password must be at least 6 characters", 400)

    # Check uniqueness
    existing = get_user_by_username(username)
    if existing:
        return _error("Username already exists", 409)
    existing = get_user_by_email(email)
    if existing:
        return _error("Email already exists", 409)

    pw_hash = hash_password(password)
    result = pg_execute(
        "INSERT INTO app_users (username, email, password_hash, role, full_name) "
        f"VALUES ({sql_escape(username)}, {sql_escape(email)}, {sql_escape(pw_hash)}, "
        f"{sql_escape(role)}, {sql_escape(full_name)}) RETURNING id, username, email, role, full_name, is_active, created_at"
    )
    if result:
        return _success({"user": result[0]}, message="User created successfully"), 201
    return _error("Failed to create user", 500)


@app.route("/api/users/<int:user_id>", methods=["PUT"])
@auth_required
@admin_required
def update_user(user_id):
    """Update a user (admin only)."""
    data = request.get_json() or {}

    user = pg_query_one("SELECT id FROM app_users WHERE id = %(uid)s", {"uid": user_id})
    if not user:
        return _error("User not found", 404)

    updates = []
    params = {"uid": user_id}

    if "role" in data:
        if data["role"] not in ("admin", "analyst"):
            return _error("Role must be 'admin' or 'analyst'", 400)
        updates.append("role = %(role)s")
        params["role"] = data["role"]

    if "fullName" in data:
        updates.append("full_name = %(fullName)s")
        params["fullName"] = data["fullName"]

    if "isActive" in data:
        updates.append("is_active = %(isActive)s")
        params["isActive"] = "true" if data["isActive"] else "false"

    if "password" in data and data["password"]:
        if len(data["password"]) < 6:
            return _error("Password must be at least 6 characters", 400)
        updates.append("password_hash = %(pwhash)s")
        params["pwhash"] = hash_password(data["password"])

    if not updates:
        return _error("No fields to update", 400)

    set_clause = ", ".join(updates)
    pg_execute(f"UPDATE app_users SET {set_clause} WHERE id = %(uid)s", params)

    updated = pg_query_one(
        "SELECT id, username, email, role, full_name, is_active, created_at, updated_at "
        "FROM app_users WHERE id = %(uid)s", {"uid": user_id}
    )
    return _success({"user": updated}, message="User updated")


@app.route("/api/users/<int:user_id>", methods=["DELETE"])
@auth_required
@admin_required
def delete_user(user_id):
    """Delete a user (admin only). Cannot delete yourself."""
    if user_id == g.current_user["id"]:
        return _error("Cannot delete your own account", 400)

    user = pg_query_one("SELECT id FROM app_users WHERE id = %(uid)s", {"uid": user_id})
    if not user:
        return _error("User not found", 404)

    pg_execute("DELETE FROM app_users WHERE id = %(uid)s", {"uid": user_id})
    return _success(message="User deleted")


# ═══════════════════════════════════════════════════════════════
#  Conversation CRUD
# ═══════════════════════════════════════════════════════════════

@app.route("/api/conversations", methods=["GET"])
@auth_required
def list_conversations():
    """List conversations for the current user."""
    user = g.current_user

    # Admins can see all conversations, analysts see only their own
    if user["role"] == "admin" and request.args.get("all") == "true":
        convs = pg_query(
            "SELECT c.id, c.title, c.created_at, c.updated_at, "
            "  (SELECT count(*) FROM app_messages m WHERE m.conv_id = c.id) AS message_count, "
            "  u.username, u.full_name "
            "FROM app_conversations c "
            "JOIN app_users u ON c.user_id = u.id "
            "ORDER BY c.updated_at DESC"
        )
    else:
        convs = pg_query(
            "SELECT c.id, c.title, c.created_at, c.updated_at, "
            "  (SELECT count(*) FROM app_messages m WHERE m.conv_id = c.id) AS message_count "
            "FROM app_conversations c "
            f"WHERE c.user_id = {user['id']} "
            "ORDER BY c.updated_at DESC"
        )
    return _success({"conversations": convs})


@app.route("/api/conversations", methods=["POST"])
@auth_required
def create_conversation():
    """Create a new conversation."""
    user = g.current_user
    data = request.get_json() or {}
    title = data.get("title", "New Chat")
    conv_id = f"conv_{uuid.uuid4().hex[:12]}"

    pg_execute(
        "INSERT INTO app_conversations (id, user_id, title) "
        f"VALUES ({sql_escape(conv_id)}, {user['id']}, {sql_escape(title)})"
    )
    conv = pg_query_one(
        "SELECT id, title, created_at, updated_at FROM app_conversations WHERE id = %(cid)s",
        {"cid": conv_id}
    )
    return _success({"conversation": conv}, message="Conversation created"), 201


@app.route("/api/conversations/<conv_id>", methods=["GET"])
@auth_required
def get_conversation(conv_id):
    """Get a conversation with all messages."""
    user = g.current_user
    conv = pg_query_one(
        "SELECT c.id, c.title, c.created_at, c.updated_at, c.user_id, u.username "
        "FROM app_conversations c JOIN app_users u ON c.user_id = u.id "
        "WHERE c.id = %(cid)s", {"cid": conv_id}
    )
    if not conv:
        return _error("Conversation not found", 404)

    # Analysts can only access their own conversations
    if user["role"] == "analyst" and conv["user_id"] != user["id"]:
        return _error("Access denied", 403)

    messages = pg_query(
        "SELECT id, role, content, created_at FROM app_messages "
        "WHERE conv_id = %(cid)s ORDER BY id ASC", {"cid": conv_id}
    )

    # Parse message content (JSON blob)
    parsed_messages = []
    for m in messages:
        try:
            content = json.loads(m["content"]) if isinstance(m["content"], str) else m["content"]
        except (json.JSONDecodeError, TypeError):
            content = {"role": m["role"], "content": m["content"]}
        parsed_messages.append(content)

    conv.pop("user_id", None)
    conv["messages"] = parsed_messages
    return _success({"conversation": conv})


@app.route("/api/conversations/<conv_id>", methods=["DELETE"])
@auth_required
def delete_conversation(conv_id):
    """Delete a conversation."""
    user = g.current_user
    conv = pg_query_one(
        "SELECT user_id FROM app_conversations WHERE id = %(cid)s", {"cid": conv_id}
    )
    if not conv:
        return _error("Conversation not found", 404)

    if user["role"] == "analyst" and conv["user_id"] != user["id"]:
        return _error("Access denied", 403)

    pg_execute("DELETE FROM app_conversations WHERE id = %(cid)s", {"cid": conv_id})
    return _success(message="Conversation deleted")


@app.route("/api/conversations/<conv_id>", methods=["PUT"])
@auth_required
def rename_conversation(conv_id):
    """Rename a conversation."""
    user = g.current_user
    data = request.get_json() or {}
    title = data.get("title", "").strip()

    if not title:
        return _error("Title required", 400)

    conv = pg_query_one("SELECT user_id FROM app_conversations WHERE id = %(cid)s", {"cid": conv_id})
    if not conv:
        return _error("Conversation not found", 404)

    if user["role"] == "analyst" and conv["user_id"] != user["id"]:
        return _error("Access denied", 403)

    pg_execute("UPDATE app_conversations SET title = %(title)s WHERE id = %(cid)s",
               {"title": title, "cid": conv_id})
    return _success(message="Conversation renamed")


# ═══════════════════════════════════════════════════════════════
#  Message Persistence
# ═══════════════════════════════════════════════════════════════

def save_message(conv_id, message):
    """Save a message to the DB. Returns the message DB id."""
    content_json = json.dumps(message, ensure_ascii=False, default=str)
    role = message.get("role", "assistant")
    result = pg_execute(
        "INSERT INTO app_messages (conv_id, role, content) "
        f"VALUES ({sql_escape(conv_id)}, {sql_escape(role)}, {sql_escape(content_json)}) "
        "RETURNING id"
    )
    msg_id = result[0]["id"] if result else None

    # Auto-title from first user message
    if role == "user":
        conv = pg_query_one("SELECT title FROM app_conversations WHERE id = %(cid)s", {"cid": conv_id})
        if conv and conv["title"] in (None, "", "New Chat"):
            text = message.get("content", "")
            title = text[:50] + ("..." if len(text) > 50 else "")
            pg_execute("UPDATE app_conversations SET title = %(title)s WHERE id = %(cid)s",
                       {"title": title, "cid": conv_id})

    return msg_id


def update_message(conv_id, msg_index, message):
    """Update an existing message by its 0-based index."""
    rows = pg_query(
        "SELECT id FROM app_messages WHERE conv_id = %(cid)s ORDER BY id ASC",
        {"cid": conv_id}
    )
    if msg_index < 0 or msg_index >= len(rows):
        return False
    db_id = rows[msg_index]["id"]
    content_json = json.dumps(message, ensure_ascii=False, default=str)
    pg_execute("UPDATE app_messages SET content = %(content)s WHERE id = %(id)s",
               {"content": content_json, "id": db_id})
    return True


def get_message_by_index(conv_id, msg_index):
    """Get a message by its 0-based index."""
    rows = pg_query(
        "SELECT id, role, content FROM app_messages WHERE conv_id = %(cid)s ORDER BY id ASC",
        {"cid": conv_id}
    )
    if msg_index < 0 or msg_index >= len(rows):
        return None
    m = rows[msg_index]
    try:
        content = json.loads(m["content"]) if isinstance(m["content"], str) else m["content"]
    except (json.JSONDecodeError, TypeError):
        content = {"role": m["role"], "content": m["content"]}
    content["_db_id"] = m["id"]
    content["_index"] = msg_index
    return content


def build_history(conv_id):
    """Build conversation history for context-aware follow-ups.
    Includes feedback from rejected queries so the LLM learns from past mistakes."""
    messages = pg_query(
        "SELECT role, content FROM app_messages WHERE conv_id = %(cid)s ORDER BY id ASC",
        {"cid": conv_id}
    )
    history = []
    for m in messages:
        try:
            content = json.loads(m["content"]) if isinstance(m["content"], str) else m["content"]
        except (json.JSONDecodeError, TypeError):
            continue
        if m["role"] == "user" and content.get("content"):
            history.append({"question": content["content"], "sql": None, "feedback": None, "status": None, "feedback_history": []})
        elif m["role"] == "assistant" and content.get("question") and content.get("sql"):
            fb = content.get("feedback")
            fb_history = content.get("feedback_history", [])
            status = content.get("status")
            if history:
                history[-1]["sql"] = content["sql"]
                history[-1]["feedback"] = fb
                history[-1]["status"] = status
                history[-1]["feedback_history"] = fb_history
            else:
                history.append({
                    "question": content["question"],
                    "sql": content["sql"],
                    "feedback": fb,
                    "status": status,
                    "feedback_history": fb_history,
                })
    return history


# ═══════════════════════════════════════════════════════════════
#  Pipeline API (SSE streaming)
# ═══════════════════════════════════════════════════════════════

@app.route("/api/pipeline/ask", methods=["POST"])
@auth_required
def pipeline_ask():
    """Start a pipeline task to generate SQL from a question.
    Returns a task_id for SSE streaming."""
    user = g.current_user
    data = request.get_json() or {}
    question = data.get("question", "").strip()
    conv_id = data.get("conversationId", "")

    if not question:
        return _error("Question required", 400)
    if not conv_id:
        return _error("conversationId required", 400)

    # Verify conversation access
    conv = pg_query_one("SELECT user_id FROM app_conversations WHERE id = %(cid)s", {"cid": conv_id})
    if not conv:
        return _error("Conversation not found", 404)
    if user["role"] == "analyst" and conv["user_id"] != user["id"]:
        return _error("Access denied", 403)

    settings = data.get("settings", {})
    history = build_history(conv_id)

    # Save user message
    save_message(conv_id, {"role": "user", "content": question})

    # Create task
    task = create_task(
        task_type="ask",
        user_id=user["id"],
        conv_id=conv_id,
        question=question,
        use_rerank=settings.get("useRerank", True),
        run_explain=settings.get("runExplain", True),
        history=history,
    )

    return _success({"taskId": task.task_id, "conversationId": conv_id})


@app.route("/api/pipeline/execute", methods=["POST"])
@auth_required
def pipeline_execute():
    """Start a task to execute approved SQL."""
    user = g.current_user
    data = request.get_json() or {}
    conv_id = data.get("conversationId", "")
    msg_index = data.get("messageIndex", -1)

    if not conv_id or msg_index < 0:
        return _error("conversationId and messageIndex required", 400)

    conv = pg_query_one("SELECT user_id FROM app_conversations WHERE id = %(cid)s", {"cid": conv_id})
    if not conv:
        return _error("Conversation not found", 404)
    if user["role"] == "analyst" and conv["user_id"] != user["id"]:
        return _error("Access denied", 403)

    msg = get_message_by_index(conv_id, msg_index)
    if not msg or not msg.get("sql"):
        return _error("Message not found or has no SQL", 404)

    # Update message status to executing
    msg["status"] = "executing"
    update_message(conv_id, msg_index, msg)

    task = create_task(
        task_type="execute",
        user_id=user["id"],
        conv_id=conv_id,
        sql=msg["sql"],
    )
    # Store msg_index in task for the stream to use
    task.kwargs["msg_index"] = msg_index

    return _success({"taskId": task.task_id, "conversationId": conv_id})


@app.route("/api/pipeline/regenerate", methods=["POST"])
@auth_required
def pipeline_regenerate():
    """Start a task to regenerate SQL with user feedback."""
    user = g.current_user
    data = request.get_json() or {}
    conv_id = data.get("conversationId", "")
    msg_index = data.get("messageIndex", -1)
    feedback = data.get("feedback", "").strip()

    if not conv_id or msg_index < 0:
        return _error("conversationId and messageIndex required", 400)
    if not feedback:
        return _error("Feedback required", 400)

    conv = pg_query_one("SELECT user_id FROM app_conversations WHERE id = %(cid)s", {"cid": conv_id})
    if not conv:
        return _error("Conversation not found", 404)
    if user["role"] == "analyst" and conv["user_id"] != user["id"]:
        return _error("Access denied", 403)

    msg = get_message_by_index(conv_id, msg_index)
    if not msg or not msg.get("sql"):
        return _error("Message not found or has no SQL", 404)

    # Update message status
    msg["status"] = "regenerating"
    msg["feedback"] = feedback
    fb_history = msg.get("feedback_history", [])
    fb_history.append({"feedback": feedback, "previous_sql": msg["sql"]})
    msg["feedback_history"] = fb_history
    update_message(conv_id, msg_index, msg)

    history = build_history(conv_id)
    settings = data.get("settings", {})

    # Admin can pass a modified context; otherwise use the stored one
    context = data.get("context") or msg.get("context", "")

    task = create_task(
        task_type="regenerate",
        user_id=user["id"],
        conv_id=conv_id,
        question=msg.get("question", ""),
        previous_sql=msg["sql"],
        feedback=feedback,
        context=context,
        history=history,
    )
    task.kwargs["msg_index"] = msg_index

    return _success({"taskId": task.task_id, "conversationId": conv_id})


@app.route("/api/feedback/merge", methods=["POST"])
@auth_required
def merge_feedback_to_graph():
    """Merge consolidated feedback into the GraphRAG knowledge graph.

    Called after a user approves and runs corrected SQL. Creates a QUERY_INSIGHT
    entity in the graph with the learned pattern, linked to relevant tables.

    Input: { conversationId, messageIndex }
    Returns: { insightEntityId, tablesLinked }
    """
    user = g.current_user
    data = request.get_json() or {}
    conv_id = data.get("conversationId", "")
    msg_index = data.get("messageIndex", -1)

    if not conv_id or msg_index < 0:
        return _error("conversationId and messageIndex required", 400)

    conv = pg_query_one("SELECT user_id FROM app_conversations WHERE id = %(cid)s", {"cid": conv_id})
    if not conv:
        return _error("Conversation not found", 404)
    if user["role"] == "analyst" and conv["user_id"] != user["id"]:
        return _error("Access denied", 403)

    msg = get_message_by_index(conv_id, msg_index)
    if not msg:
        return _error("Message not found", 404)

    fb_history = msg.get("feedback_history", [])
    if not fb_history:
        return _error("No feedback history found for this message", 400)

    question = msg.get("question", "")
    final_sql = msg.get("sql", "")

    # Use LLM to consolidate the feedback into a reusable insight
    fb_entries = []
    for fb in fb_history:
        fb_entries.append({
            "feedback": fb.get("feedback", ""),
            "rejected_sql": fb.get("previous_sql", ""),
        })

    consolidation_prompt = f"""You are a knowledge graph curator. A user asked a question, the initial SQL was rejected, and the user provided feedback. The SQL was then corrected and approved.

Consolidate this into a reusable "query insight" that will be stored in the knowledge graph so future queries benefit from this learning.

Question: {question}

Feedback history (oldest to newest):
{json.dumps(fb_entries, indent=2)}

Final approved SQL:
{final_sql}

Generate a JSON object with:
1. "insight_title": A short title (5-10 words) describing what was learned. Example: "Active UID count must filter deactivated records"
2. "insight_description": A detailed description of the correct query approach. Explain WHAT to do and WHY. Mention specific columns, filters, and join conditions that are important. 2-4 sentences.
3. "correct_sql_pattern": The SQL pattern (the approved SQL, cleaned up).
4. "key_columns": Array of column names that are critical for this query (e.g., ["uid_status_key", "uid_deactivated", "enr_date"])
5. "relevant_tables": Array of table names this insight applies to (e.g., ["uid_master"])
6. "search_keywords": Natural-language phrases users might type when asking similar questions (10-15 phrases). Example: "active UID count", "how many active aadhaar", "currently issued UIDs"

Return ONLY valid JSON."""

    try:
        from llm_client import LLMClient
        llm = LLMClient()
        content, reasoning = llm.chat(
            consolidation_prompt,
            system="You are a database knowledge graph curator. Return ONLY valid JSON.",
            temperature=0.1,
            max_tokens=2000,
            return_reasoning=True,
        )
    except Exception as e:
        return _error(f"LLM call failed: {e}", 500)

    if not content:
        return _error("LLM returned no content", 500)

    # Parse JSON
    import re as _re
    json_str = content.strip()
    json_str = _re.sub(r"^```json\s*", "", json_str)
    json_str = _re.sub(r"\s*```$", "", json_str)

    try:
        parsed = json.loads(json_str)
    except json.JSONDecodeError as e:
        return _error(f"LLM returned invalid JSON: {e}. Raw: {content[:300]}", 500)

    insight_title = parsed.get("insight_title", "")
    insight_desc = parsed.get("insight_description", "")
    sql_pattern = parsed.get("correct_sql_pattern", "")
    key_columns = parsed.get("key_columns", [])
    relevant_tables = parsed.get("relevant_tables", [])
    search_keywords = parsed.get("search_keywords", "")

    # Create a QUERY_INSIGHT entity in the graph
    max_entity = pg_query_one("SELECT entity_id FROM entities ORDER BY entity_id DESC LIMIT 1")
    if max_entity and max_entity.get("entity_id", "").startswith("E"):
        try:
            max_num = int(max_entity["entity_id"][1:])
        except ValueError:
            max_num = 0
    else:
        max_num = 0

    insight_eid = f"E{max_num + 1:04d}"

    # Build rich search_text for FTS discovery
    search_parts = [
        insight_title, insight_desc, question,
    ]
    # search_keywords may be a list or a string
    if isinstance(search_keywords, list):
        search_parts.append(" ".join(search_keywords))
    elif isinstance(search_keywords, str):
        search_parts.append(search_keywords)
    search_parts.extend([
        sql_pattern[:500], "QUERY_INSIGHT",
    ])
    for col in key_columns:
        search_parts.append(col)
    for tbl in relevant_tables:
        search_parts.append(tbl)
    insight_search = " ".join(str(p) for p in search_parts if p)

    insight_props = {
        "question": question,
        "correct_sql": sql_pattern,
        "key_columns": key_columns,
        "relevant_tables": relevant_tables,
        "feedback_entries": fb_entries,
        "source_conversation": conv_id,
        "created_by": user.get("username", ""),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }

    # Insert the QUERY_INSIGHT entity
    try:
        pg_execute(
            "INSERT INTO entities (entity_id, name, type, description, properties, search_text) "
            f"VALUES ({sql_escape(insight_eid)}, {sql_escape(insight_title)}, 'QUERY_INSIGHT', "
            f"{sql_escape(insight_desc)}, {jsonb_literal(insight_props)}, {sql_escape(insight_search)})"
        )
    except Exception as e:
        return _error(f"Failed to insert insight entity: {e}", 500)

    # Link to relevant TABLE entities via APPLIES_TO relationships
    # If LLM didn't return relevant_tables, try to extract from SQL
    if not relevant_tables and sql_pattern:
        import re as _re2
        # Look for table names in FROM/JOIN clauses
        found_tables = _re2.findall(r'(?:FROM|JOIN)\s+\w+\.\w+\.(\w+)|(?:FROM|JOIN)\s+(\w+)', sql_pattern, _re2.IGNORECASE)
        for ft in found_tables:
            name = ft[0] or ft[1]
            if name and name.lower() not in [t.lower() for t in relevant_tables]:
                relevant_tables.append(name)

    # Normalize table names: extract just the table name from qualified names like "strot.mysql_uid_v2.uid_master"
    normalized_tables = []
    for tbl_name in relevant_tables:
        tbl_str = str(tbl_name).strip()
        # If qualified (catalog.schema.table), take just the last part
        if "." in tbl_str:
            tbl_str = tbl_str.split(".")[-1]
        # Remove any surrounding quotes/backticks
        tbl_str = tbl_str.strip("`\"'[]")
        normalized_tables.append(tbl_str)

    tables_linked = 0
    linked_table_names = []
    for tbl_name in normalized_tables:
        tbl_name_lower = tbl_name.lower().strip()
        # Try exact match first
        tbl_row = pg_query_one(
            "SELECT entity_id, name FROM entities WHERE type = 'TABLE' AND lower(name) = %(name)s",
            {"name": tbl_name_lower}
        )
        # If no exact match, try LIKE (in case of prefix/suffix differences)
        if not tbl_row and len(tbl_name_lower) > 3:
            tbl_row = pg_query_one(
                "SELECT entity_id, name FROM entities WHERE type = 'TABLE' AND lower(name) LIKE %(pat)s LIMIT 1",
                {"pat": f"%{tbl_name_lower}%"}
            )
        if tbl_row:
            try:
                pg_execute(
                    "INSERT INTO relationships (source_id, target_id, type, description, properties) "
                    f"VALUES ({sql_escape(insight_eid)}, {sql_escape(tbl_row['entity_id'])}, "
                    f"'APPLIES_TO', {sql_escape(f'Query insight: {insight_title}')}, "
                    f"{jsonb_literal({'table': tbl_row.get('name', tbl_name), 'insight': insight_title})})"
                )
                tables_linked += 1
                linked_table_names.append(tbl_row.get('name', tbl_name))
            except Exception as rel_err:
                # Log but don't fail — the insight entity is still useful without the link
                import sys as _sys
                print(f"[feedback_merge] Failed to link to {tbl_name}: {rel_err}", file=_sys.stderr)

    # Mark message as feedback_merged
    msg["feedback_merged"] = True
    update_message(conv_id, msg_index, msg)

    # Audit log
    _audit_log(user["id"], conv_id, question, sql_pattern, "FEEDBACK_MERGE", 0, 0, insight_eid)

    return _success({
        "insightEntityId": insight_eid,
        "insightTitle": insight_title,
        "insightDescription": insight_desc,
        "tablesLinked": tables_linked,
        "linkedTableNames": linked_table_names,
        "relevantTables": relevant_tables,
        "searchKeywords": search_keywords,
    })


@app.route("/api/feedback/check", methods=["GET"])
@auth_required
def check_feedback_available():
    """Check if a message has feedback history that can be merged to graph.
    Input: ?conversationId=...&messageIndex=...
    """
    user = g.current_user
    conv_id = request.args.get("conversationId", "")
    try:
        msg_index = int(request.args.get("messageIndex", -1))
    except ValueError:
        msg_index = -1

    if not conv_id or msg_index < 0:
        return _success({"hasFeedback": False})

    conv = pg_query_one("SELECT user_id FROM app_conversations WHERE id = %(cid)s", {"cid": conv_id})
    if not conv:
        return _success({"hasFeedback": False})
    if user["role"] == "analyst" and conv["user_id"] != user["id"]:
        return _success({"hasFeedback": False})

    msg = get_message_by_index(conv_id, msg_index)
    if not msg:
        return _success({"hasFeedback": False})

    fb_history = msg.get("feedback_history", [])
    has_feedback = len(fb_history) > 0
    already_merged = msg.get("feedback_merged", False)

    return _success({
        "hasFeedback": has_feedback,
        "feedbackCount": len(fb_history),
        "alreadyMerged": already_merged,
    })


@app.route("/api/pipeline/stream/<task_id>")
def pipeline_stream(task_id):
    """SSE endpoint — streams events from a pipeline task.

    Token is passed as query param ?token= because EventSource
    doesn't support custom Authorization headers.
    """
    # Authenticate via query param token (EventSource can't set headers)
    token_param = request.args.get("token", "")
    auth_header = request.headers.get("Authorization", "")

    if auth_header.startswith("Bearer "):
        token = auth_header[7:]
    elif token_param:
        token = token_param
    else:
        return _error("Authentication required", 401)

    try:
        payload = decode_token(token)
    except Exception:
        return _error("Invalid or expired token", 401)

    if payload.get("type") != "access":
        return _error("Invalid token type", 401)

    user = get_user_by_id(payload.get("uid", int(payload.get("sub", 0))))
    if not user or not user.get("is_active"):
        return _error("User not found or deactivated", 401)
    g.current_user = user

    task = get_task(task_id)
    if not task:
        return _error("Task not found", 404)

    def event_stream():
        last_event_count = 0
        while True:
            # Drain all available events
            events_sent = False
            try:
                while True:
                    try:
                        event = task.events.get(timeout=0.1)
                        yield _sse_format(event["type"], event["data"])
                        events_sent = True
                        last_event_count += 1

                        # If this was the result event, save it
                        if event["type"] == "result":
                            _save_task_result(task, event["data"])

                    except queue_module.Empty:
                        break
            except Exception:
                pass

            if task.done:
                # Drain any remaining events
                while not task.events.empty():
                    event = task.events.get_nowait()
                    yield _sse_format(event["type"], event["data"])
                    if event["type"] == "result":
                        _save_task_result(task, event["data"])
                # Send final done event
                yield _sse_format("close", {"task_id": task.task_id})
                break

            if not events_sent:
                # Send keepalive comment
                yield ": keepalive\n\n"

    return Response(
        stream_with_context(event_stream()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        }
    )


def _sse_format(event_type, data):
    """Format an SSE event."""
    return f"event: {event_type}\ndata: {json.dumps(data, default=str)}\n\n"


def _save_task_result(task, result):
    """Save the task result to the database as a message."""
    try:
        conv_id = task.conv_id
        user_id = task.user_id

        if task.task_type == "ask":
            # Save as a new assistant message
            message = {
                "role": "assistant",
                "question": task.kwargs.get("question", ""),
                "intent": result.get("intent"),
                "sql": result.get("sql"),
                "context": result.get("context"),
                "reasoning": result.get("reasoning"),
                "explain_result": result.get("explain_result"),
                "query_result": result.get("query_result"),
                "metadata_answer": result.get("metadata_answer"),
                "metadata_data": result.get("metadata_data"),
                "status": result.get("status", "pending_verification"),
                "elapsed": 0,
                "steps": [],
                "feedback_history": [],
            }
            # Strip large internal data before saving
            if message.get("context") and len(str(message["context"])) > 50000:
                message["context"] = message["context"][:50000] + "...[truncated]"

            msg_id = save_message(conv_id, message)

            # Audit log
            if message.get("sql"):
                _audit_log(user_id, conv_id, message["question"], message["sql"],
                           "skipped", None, None, None)

        elif task.task_type in ("execute", "regenerate"):
            # Update the existing message
            msg_index = task.kwargs.get("msg_index", -1)
            if msg_index >= 0:
                msg = get_message_by_index(conv_id, msg_index)
                if msg:
                    if task.task_type == "execute":
                        msg["query_result"] = result.get("query_result")
                        msg["status"] = result.get("status", "completed")
                        # Audit log
                        qr = result.get("query_result", {})
                        if qr.get("success"):
                            _audit_log(user_id, conv_id, msg.get("question", ""), msg.get("sql", ""),
                                       "success", qr.get("row_count"), None, qr.get("query_id"))
                        else:
                            _audit_log(user_id, conv_id, msg.get("question", ""), msg.get("sql", ""),
                                       "failed", None, None, None, qr.get("error"))
                    elif task.task_type == "regenerate":
                        msg["sql"] = result.get("sql", msg.get("sql"))
                        msg["reasoning"] = result.get("reasoning", msg.get("reasoning"))
                        msg["query_result"] = None
                        msg["explain_result"] = None
                        msg["status"] = result.get("status", "pending_verification")
                        msg["feedback"] = None

                    update_message(conv_id, msg_index, msg)

    except Exception as e:
        print(f"[ERROR] Failed to save task result: {e}")


# ═══════════════════════════════════════════════════════════════
#  Admin: Context Remarks & Context Editing
# ═══════════════════════════════════════════════════════════════

@app.route("/api/messages/remark", methods=["POST"])
@auth_required
@admin_required
def add_context_remark():
    """Admin adds a remark on a message's retrieved context."""
    data = request.get_json() or {}
    conv_id = data.get("conversationId", "")
    msg_index = data.get("messageIndex", -1)
    remark = data.get("remark", "").strip()

    if not conv_id or msg_index < 0:
        return _error("conversationId and messageIndex required", 400)
    if not remark:
        return _error("Remark text required", 400)

    msg = get_message_by_index(conv_id, msg_index)
    if not msg:
        return _error("Message not found", 404)

    msg["admin_remark"] = remark
    msg["admin_remark_by"] = g.current_user["username"]
    msg["admin_remark_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    update_message(conv_id, msg_index, msg)

    _audit_log(g.current_user["id"], conv_id, msg.get("question", ""),
               msg.get("sql", ""), "remark_added", 0, 0, "", remark[:200])

    return _success({"message": "Remark saved"})


@app.route("/api/conversations/<conv_id>/messages/<int:msg_index>/context", methods=["PUT"])
@auth_required
@admin_required
def update_message_context(conv_id, msg_index):
    """Admin edits the retrieved context of a message (for re-generation)."""
    data = request.get_json() or {}
    context = data.get("context", "")

    conv = pg_query_one("SELECT user_id FROM app_conversations WHERE id = %(cid)s", {"cid": conv_id})
    if not conv:
        return _error("Conversation not found", 404)

    msg = get_message_by_index(conv_id, msg_index)
    if not msg:
        return _error("Message not found", 404)

    # Store original context if not already stored
    if not msg.get("original_context"):
        msg["original_context"] = msg.get("context", "")

    msg["context"] = context
    msg["context_edited"] = True
    msg["context_edited_by"] = g.current_user["username"]
    msg["context_edited_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    update_message(conv_id, msg_index, msg)

    return _success({"message": "Context updated"})


# ═══════════════════════════════════════════════════════════════
#  Admin: Add Table to GraphRAG (discover → generate → save)
# ═══════════════════════════════════════════════════════════════

@app.route("/api/admin/table/discover", methods=["POST"])
@auth_required
@admin_required
def discover_table():
    """Step 1: Discover a table's schema from Trino.
    Input: { table: "catalog.schema.table" }
    Returns: { columns: [...], rowCount: N, exists: true }
    """
    data = request.get_json() or {}
    table_ref = data.get("table", "").strip()

    if not table_ref:
        return _error("Table name required", 400)

    # Validate format: catalog.schema.table
    parts = table_ref.split(".")
    if len(parts) != 3:
        return _error("Table must be in format: catalog.schema.table (e.g., strot.mysql_uid_v2.uid_master)", 400)

    # Check if table already exists in GraphRAG
    existing = pg_query_one(
        "SELECT entity_id, name FROM entities WHERE type = 'TABLE' AND name = %(name)s",
        {"name": parts[2]}
    )
    if existing:
        return _error(f"Table '{parts[2]}' already exists in GraphRAG (entity_id: {existing['entity_id']})", 409)

    # Query Trino for columns
    try:
        result = trino_query(f"SHOW COLUMNS FROM {table_ref}", timeout=30)
    except Exception as e:
        return _error(f"Trino query failed: {e}", 500)

    if "error" in result:
        err_msg = result["error"].get("message", str(result["error"]))
        if "does not exist" in err_msg.lower() or "table not found" in err_msg.lower():
            return _error(f"Table '{table_ref}' not found in Trino", 404)
        return _error(f"Trino error: {err_msg}", 500)

    columns_data = result.get("data", [])
    if not columns_data:
        return _error(f"Table '{table_ref}' has no columns or is inaccessible", 404)

    columns = []
    for row in columns_data:
        columns.append({
            "name": row[0],
            "type": row[1] if len(row) > 1 else "",
            "extra": row[2] if len(row) > 2 else "",
            "comment": row[3] if len(row) > 3 else "",
        })

    # Get row count (best-effort — don't block for minutes on huge tables)
    row_count = None
    try:
        count_result = trino_query(f"SELECT count(*) FROM {table_ref}", timeout=60)
        if count_result.get("data") and count_result["data"][0]:
            row_count = int(count_result["data"][0][0])
    except Exception:
        pass  # row count is optional — huge tables may timeout

    # Get sample data (5 rows) — helps the LLM understand the data
    sample_data = []
    sample_columns = []
    try:
        sample_result = trino_query(f"SELECT * FROM {table_ref} LIMIT 5", timeout=30)
        if sample_result.get("data"):
            sample_data = sample_result["data"]
            sample_columns = [c["name"] for c in sample_result.get("columns", [])] if sample_result.get("columns") else []
    except Exception:
        pass  # sample data is optional

    return _success({
        "table": table_ref,
        "tableName": parts[2],
        "schema": f"{parts[0]}.{parts[1]}",
        "columns": columns,
        "rowCount": row_count,
        "sampleData": sample_data,
        "sampleColumns": sample_columns,
    })


@app.route("/api/admin/table/generate-context", methods=["POST"])
@auth_required
@admin_required
def generate_table_context():
    """Step 2: Use LLM to generate table + column descriptions.
    Input: { table, tableName, columns: [...], rowCount, sampleData, sampleColumns }
    Returns: { tableDescription, columns: [{name, type, description}], reasoning }
    """
    data = request.get_json() or {}
    table_ref = data.get("table", "").strip()
    table_name = data.get("tableName", table_ref.split(".")[-1] if table_ref else "")
    columns = data.get("columns", [])
    row_count = data.get("rowCount")
    sample_data = data.get("sampleData", [])
    sample_columns = data.get("sampleColumns", [])

    if not table_ref or not columns:
        return _error("Table name and columns required", 400)

    # Build column list for the prompt
    col_lines = []
    for col in columns:
        line = f"  - {col['name']} ({col['type']})"
        if col.get("comment"):
            line += f" — comment: {col['comment']}"
        col_lines.append(line)
    columns_text = "\n".join(col_lines)

    row_info = f" (~{row_count:,} rows)" if row_count else ""

    # Build sample data section for the prompt
    sample_section = ""
    if sample_data and sample_columns:
        sample_lines = []
        # Header
        sample_lines.append("  | " + " | ".join(sample_columns[:10]) + " |")
        sample_lines.append("  | " + " | ".join(["---"] * min(len(sample_columns), 10)) + " |")
        # Rows (truncate long values)
        for row in sample_data[:5]:
            vals = []
            for v in row[:10]:
                s = str(v) if v is not None else "NULL"
                if len(s) > 40:
                    s = s[:37] + "..."
                vals.append(s)
            sample_lines.append("  | " + " | ".join(vals) + " |")
        sample_section = f"""

Sample Data (first 5 rows):
{chr(10).join(sample_lines)}
"""
        sample_section += "\nUse the sample data to understand the actual data patterns, value formats, and relationships between columns.\n"

    prompt = f"""You are a database documentation expert. Given a Trino table, its columns, and sample data, generate clear, accurate descriptions.

Table: {table_ref}
Row count: {row_count or "unknown"}{row_info}

Columns:
{columns_text}
{sample_section}
Generate a JSON object with:
1. "table_description": A 1-3 sentence description of what this table stores and its purpose. Be specific about the domain (UID/Aadhaar data, biometrics, operators, stations, etc.). Mention the approximate row count if known.
2. "column_descriptions": An object mapping each column name to a concise description (1 sentence). Include:
   - What the column represents
   - If it's PII (personally identifiable information), note it
   - If it's a join key used to link to other tables, note which tables
   - For encrypted/encoded columns, note that they should not be decrypted
   - For status/flag columns, note the meaning of values if obvious from the name or sample data
   - For timestamp columns, note the date range if visible in samples
3. "search_keywords": A string of natural-language phrases and keywords that a user might type when looking for this table's data. Include 10-20 phrases. Examples: "request tracking", "how many requests were processed", "request status", "session tracking", "reference ID lookup". These will be used for full-text search indexing.

Example output:
{{
  "table_description": "Central source table for UID records. One row per UID with current status, biometric info, and resident details.",
  "column_descriptions": {{
    "uid": "Encrypted UID (Aadhaar number). PII — never decrypt or display.",
    "uid_status_key": "Status flag: 1=active/issued, 0=inactive/deactivated.",
    "enr_date": "Enrollment date timestamp."
  }},
  "search_keywords": "current status of a UID is the aadhaar active current demographic information latest resident data how many active UIDs resident identity table master table main UID table present day information live data what is the current status of the person"
}}"""

    try:
        from llm_client import LLMClient
        llm = LLMClient()
        content, reasoning = llm.chat(
            prompt,
            system="You are a database documentation expert specializing in UID/Aadhaar data systems. Return ONLY valid JSON.",
            temperature=0.1,
            max_tokens=4000,
            return_reasoning=True,
        )
    except Exception as e:
        return _error(f"LLM call failed: {e}", 500)

    if not content:
        return _error("LLM returned no content", 500)

    # Parse JSON from LLM response (strip code fences if present)
    import re as _re
    json_str = content.strip()
    json_str = _re.sub(r"^```json\s*", "", json_str)
    json_str = _re.sub(r"\s*```$", "", json_str)

    try:
        parsed = json.loads(json_str)
    except json.JSONDecodeError as e:
        return _error(f"LLM returned invalid JSON: {e}. Raw: {content[:300]}", 500)

    table_desc = parsed.get("table_description", "")
    col_descs = parsed.get("column_descriptions", {})
    search_keywords = parsed.get("search_keywords", "")

    # Merge LLM descriptions with original column data
    enriched_columns = []
    for col in columns:
        enriched = dict(col)
        enriched["description"] = col_descs.get(col["name"], "")
        enriched_columns.append(enriched)

    return _success({
        "table": table_ref,
        "tableName": table_name,
        "tableDescription": table_desc,
        "columns": enriched_columns,
        "reasoning": reasoning,
        "searchKeywords": search_keywords,
    })


@app.route("/api/admin/table/save", methods=["POST"])
@auth_required
@admin_required
def save_table_to_graph():
    """Step 3: Save verified table + columns to GraphRAG PostgreSQL.
    Input: { table, tableName, schema, tableDescription, columns, rowCount, searchKeywords, sampleData }
    Returns: { tableEntityId, columnEntityIds: [...] }
    """
    data = request.get_json() or {}
    table_ref = data.get("table", "").strip()
    table_name = data.get("tableName", "")
    schema = data.get("schema", "")
    table_desc = data.get("tableDescription", "")
    columns = data.get("columns", [])
    row_count = data.get("rowCount")
    search_keywords = data.get("searchKeywords", "")
    sample_data = data.get("sampleData", [])

    if not table_name or not columns:
        return _error("tableName and columns required", 400)

    # Double-check table doesn't already exist
    existing = pg_query_one(
        "SELECT entity_id FROM entities WHERE type = 'TABLE' AND name = %(name)s",
        {"name": table_name}
    )
    if existing:
        return _error(f"Table '{table_name}' already exists in GraphRAG", 409)

    # Get the next available entity IDs
    max_entity = pg_query_one("SELECT entity_id FROM entities ORDER BY entity_id DESC LIMIT 1")
    if max_entity and max_entity.get("entity_id", "").startswith("E"):
        try:
            max_num = int(max_entity["entity_id"][1:])
        except ValueError:
            max_num = 0
    else:
        max_num = 0

    table_eid = f"E{max_num + 1:04d}"
    col_eids = []
    for i in range(len(columns)):
        col_eids.append(f"E{max_num + 2 + i:04d}")

    # Build RICH search_text for TABLE entity — this is critical for FTS discovery.
    # Include: table name, full reference, description, all column names + descriptions,
    # natural language search keywords, and schema info.
    search_parts = [
        table_name,
        table_ref,
        schema,
        table_desc or "",
        search_keywords or "",
    ]
    # Add column names and descriptions
    for col in columns:
        search_parts.append(col.get("name", ""))
        search_parts.append(col.get("description", ""))
        search_parts.append(col.get("type", ""))
    table_search = " ".join(p for p in search_parts if p)

    # Build properties for TABLE entity
    table_props = {
        "full_reference": table_ref,
        "schema": schema,
        "row_count": row_count,
        "column_count": len(columns),
        "source_connector": "trino",
        "read_host": config.TRINO_URL,
        "write_allowed": False,
    }
    if sample_data:
        table_props["has_sample_data"] = True

    # Insert TABLE entity
    try:
        pg_execute(
            "INSERT INTO entities (entity_id, name, type, description, properties, search_text) "
            f"VALUES ({sql_escape(table_eid)}, {sql_escape(table_name)}, 'TABLE', "
            f"{sql_escape(table_desc)}, {jsonb_literal(table_props)}, {sql_escape(table_search)})"
        )
    except Exception as e:
        return _error(f"Failed to insert table entity: {e}", 500)

    # Insert COLUMN entities + HAS_COLUMN relationships
    col_entity_ids = []
    for i, col in enumerate(columns):
        col_eid = col_eids[i]
        col_name = f"{table_name}.{col['name']}"
        col_desc = col.get("description", "")
        col_type = col.get("type", "")
        # Rich search_text: column name, table name, type, description, table description, keywords
        col_search_parts = [
            col_name, col["name"], col_type, "COLUMN", table_name, table_ref,
            col_desc, table_desc[:200] if table_desc else "",
            search_keywords[:200] if search_keywords else "",
        ]
        col_search = " ".join(p for p in col_search_parts if p)

        col_props = {
            "table": table_name,
            "full_reference": table_ref,
            "data_type": col_type,
            "column_name": col["name"],
        }
        if col.get("comment"):
            col_props["comment"] = col["comment"]

        try:
            pg_execute(
                "INSERT INTO entities (entity_id, name, type, description, properties, search_text) "
                f"VALUES ({sql_escape(col_eid)}, {sql_escape(col_name)}, 'COLUMN', "
                f"{sql_escape(col_desc)}, {jsonb_literal(col_props)}, {sql_escape(col_search)})"
            )
            col_entity_ids.append(col_eid)
        except Exception as e:
            return _error(f"Failed to insert column entity {col_name}: {e}", 500)

        # Create HAS_COLUMN relationship
        rel_desc = f"Table {table_name} has column {col['name']} ({col_type})"
        try:
            pg_execute(
                "INSERT INTO relationships (source_id, target_id, type, description) "
                f"VALUES ({sql_escape(table_eid)}, {sql_escape(col_eid)}, 'HAS_COLUMN', "
                f"{sql_escape(rel_desc)})"
            )
        except Exception as e:
            print(f"[WARN] Failed to create relationship for {col_name}: {e}")

    # Audit log
    _audit_log(
        g.current_user["id"], "", f"Add table: {table_ref}",
        "", "table_added", len(columns), 0, "", table_desc[:200]
    )

    return _success({
        "message": f"Table '{table_name}' added to GraphRAG with {len(columns)} columns",
        "tableEntityId": table_eid,
        "columnEntityIds": col_entity_ids,
        "columnCount": len(columns),
    })


def _audit_log(user_id, conv_id, question, sql_text, status, row_count, latency, query_id, error=None):
    """Write to the audit log."""
    try:
        username = ""
        user = pg_query_one("SELECT username FROM app_users WHERE id = %(uid)s", {"uid": user_id})
        if user:
            username = user["username"]

        pg_execute(
            "INSERT INTO app_audit_log (user_id, username, conv_id, question, sql_text, "
            "execution_status, row_count, latency_seconds, trino_query_id, error_message) "
            f"VALUES ({user_id}, {sql_escape(username)}, {sql_escape(conv_id)}, "
            f"{sql_escape(question)}, {sql_escape(sql_text)}, {sql_escape(status)}, "
            f"{row_count or 'NULL'}, {latency or 'NULL'}, {sql_escape(query_id or '')}, "
            f"{sql_escape(error or '')})"
        )
    except Exception as e:
        print(f"[ERROR] Audit log failed: {e}")


# ═══════════════════════════════════════════════════════════════
#  Audit Log
# ═══════════════════════════════════════════════════════════════

@app.route("/api/audit", methods=["GET"])
@auth_required
def list_audit():
    """List audit log entries. Admins see all, analysts see their own."""
    user = g.current_user
    limit = min(int(request.args.get("limit", 50)), 200)

    if user["role"] == "admin":
        entries = pg_query(
            f"SELECT id, user_id, username, conv_id, question, sql_text, "
            f"execution_status, row_count, latency_seconds, trino_query_id, error_message, created_at "
            f"FROM app_audit_log ORDER BY created_at DESC LIMIT {limit}"
        )
    else:
        entries = pg_query(
            f"SELECT id, conv_id, question, sql_text, execution_status, row_count, "
            f"latency_seconds, trino_query_id, error_message, created_at "
            f"FROM app_audit_log WHERE user_id = {user['id']} "
            f"ORDER BY created_at DESC LIMIT {limit}"
        )
    return _success({"entries": entries, "count": len(entries)})


# ═══════════════════════════════════════════════════════════════
#  Serve React Frontend (production)
# ═══════════════════════════════════════════════════════════════

FRONTEND_DIST = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "chatbot-ui", "dist")

if os.path.isdir(FRONTEND_DIST):
    @app.route("/")
    def serve_index():
        return send_from_directory(FRONTEND_DIST, "index.html")

    @app.route("/<path:path>")
    def serve_static(path):
        full = os.path.join(FRONTEND_DIST, path)
        if os.path.isfile(full):
            return send_from_directory(FRONTEND_DIST, path)
        return send_from_directory(FRONTEND_DIST, "index.html")


# ═══════════════════════════════════════════════════════════════
#  Periodic Cleanup
# ═══════════════════════════════════════════════════════════════

def _cleanup_loop():
    """Background thread to clean up old completed tasks."""
    while True:
        time.sleep(300)  # every 5 minutes
        try:
            cleanup_old_tasks(max_age=3600)
        except Exception:
            pass


# Start cleanup thread
_cleanup_thread = threading.Thread(target=_cleanup_loop, daemon=True)
_cleanup_thread.start()


# ═══════════════════════════════════════════════════════════════
#  Main
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print(f"Chatbot API starting on port {config.FLASK_PORT}...")
    print(f"  Frontend dist: {FRONTEND_DIST} ({'found' if os.path.isdir(FRONTEND_DIST) else 'not found'})")
    print(f"  CORS origins: {config.CORS_ORIGINS}")
    print(f"  Default users: admin/admin123, analyst/analyst123")
    app.run(
        host=config.FLASK_HOST,
        port=config.FLASK_PORT,
        debug=False,
        threaded=True,
        use_reloader=False,
    )
