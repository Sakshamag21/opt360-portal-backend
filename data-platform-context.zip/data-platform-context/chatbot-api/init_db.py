#!/usr/bin/env python3
"""
Initialize the Chatbot API database schema in PostgreSQL.

Creates tables: app_users, app_conversations, app_messages, app_audit_log
Creates a default admin user if none exists.

Usage:
    python init_db.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import subprocess
from db import pg_query_one, pg_execute, sql_escape
from auth import hash_password


SCHEMA_SQL = """
-- ═══════════════════════════════════════════════════════════════
--  Users
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS app_users (
    id              SERIAL PRIMARY KEY,
    username        VARCHAR(50) UNIQUE NOT NULL,
    email           VARCHAR(100) UNIQUE NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    role            VARCHAR(20) NOT NULL DEFAULT 'analyst'
                    CHECK (role IN ('admin', 'analyst')),
    full_name       VARCHAR(100),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT NOW(),
    updated_at      TIMESTAMP DEFAULT NOW()
);

-- ═══════════════════════════════════════════════════════════════
--  Conversations
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS app_conversations (
    id          VARCHAR(20) PRIMARY KEY,
    user_id     INTEGER NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
    title       VARCHAR(200) DEFAULT 'New Chat',
    created_at  TIMESTAMP DEFAULT NOW(),
    updated_at  TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_app_conv_user ON app_conversations(user_id);

-- ═══════════════════════════════════════════════════════════════
--  Messages (JSON content blob — same pattern as SQLite version)
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS app_messages (
    id          SERIAL PRIMARY KEY,
    conv_id     VARCHAR(20) NOT NULL REFERENCES app_conversations(id) ON DELETE CASCADE,
    role        VARCHAR(20) NOT NULL,
    content     TEXT NOT NULL,
    created_at  TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_app_messages_conv ON app_messages(conv_id);

-- ═══════════════════════════════════════════════════════════════
--  Audit Log
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS app_audit_log (
    id                SERIAL PRIMARY KEY,
    user_id           INTEGER REFERENCES app_users(id),
    username          VARCHAR(50),
    conv_id           VARCHAR(20),
    question          TEXT,
    sql_text          TEXT,
    execution_status  VARCHAR(20),
    row_count         INTEGER,
    latency_seconds   FLOAT,
    trino_query_id    VARCHAR(100),
    error_message     TEXT,
    created_at        TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_app_audit_user ON app_audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_app_audit_created ON app_audit_log(created_at DESC);

-- ═══════════════════════════════════════════════════════════════
--  Updated_at trigger for conversations
-- ═══════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_app_conv_updated ON app_conversations;
CREATE TRIGGER trg_app_conv_updated
    BEFORE UPDATE ON app_conversations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trg_app_users_updated ON app_users;
CREATE TRIGGER trg_app_users_updated
    BEFORE UPDATE ON app_users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
"""


def run_schema():
    """Run the schema SQL via docker exec psql."""
    print("Creating schema...")
    # Write schema to a temp file and copy into container
    import tempfile
    with tempfile.NamedTemporaryFile(mode="w", suffix=".sql", delete=False, encoding="utf-8") as f:
        f.write(SCHEMA_SQL)
        schema_path = f.name

    try:
        # Copy schema file into container
        subprocess.run(
            ["docker", "cp", schema_path, f"graphrag-postgres:/tmp/schema.sql"],
            capture_output=True, check=True
        )
        # Execute schema
        result = subprocess.run(
            ["docker", "exec", "graphrag-postgres", "psql", "-U", "graphrag", "-d", "graphrag", "-f", "/tmp/schema.sql"],
            capture_output=True, text=True, encoding="utf-8"
        )
        if result.returncode != 0:
            print(f"Schema creation errors:\n{result.stderr}")
        else:
            print("Schema created successfully.")
            if result.stdout.strip():
                print(result.stdout)
    finally:
        os.unlink(schema_path)


def create_default_admin():
    """Create a default admin user if no users exist."""
    count = pg_query_one("SELECT count(*) AS cnt FROM app_users")
    if count and count["cnt"] > 0:
        print(f"Users already exist ({count['cnt']}). Skipping default admin creation.")
        return

    print("Creating default admin user...")
    username = "admin"
    email = "admin@uidai.gov.in"
    password = "admin123"
    pw_hash = hash_password(password)

    pg_execute(
        "INSERT INTO app_users (username, email, password_hash, role, full_name) "
        f"VALUES ({sql_escape(username)}, {sql_escape(email)}, {sql_escape(pw_hash)}, 'admin', 'System Administrator')"
    )

    print(f"  [OK] Admin user created:")
    print(f"    Username: {username}")
    print(f"    Email:    {email}")
    print(f"    Password: {password}")
    print(f"    Role:     admin")
    print(f"  [!] Please change the password after first login!")

    # Also create a demo analyst
    pg_execute(
        "INSERT INTO app_users (username, email, password_hash, role, full_name) "
        f"VALUES ('analyst', 'analyst@uidai.gov.in', {sql_escape(hash_password('analyst123'))}, 'analyst', 'Demo Analyst')"
    )
    print(f"\n  [OK] Demo analyst user created:")
    print(f"    Username: analyst")
    print(f"    Password: analyst123")
    print(f"    Role:     analyst")


def verify():
    """Verify the schema was created."""
    tables = pg_query_one(
        "SELECT count(*) AS cnt FROM information_schema.tables WHERE table_name LIKE 'app_%'"
    )
    print(f"\nVerification: {tables['cnt']} app_ tables found.")

    users = pg_query_one("SELECT count(*) AS cnt FROM app_users")
    print(f"Users: {users['cnt']}")


if __name__ == "__main__":
    run_schema()
    create_default_admin()
    verify()
    print(f"\n[OK] Database initialization complete.")
