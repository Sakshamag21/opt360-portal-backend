@echo off
REM ═══════════════════════════════════════════════════════════════
REM  Chatbot API + UI Launcher
REM  Starts the Flask backend (serves API + built React frontend)
REM ═══════════════════════════════════════════════════════════════

cd /d C:\data-platform-context\chatbot-api

echo ============================================
echo   UID Data Query Assistant
echo   Starting backend on port 8000...
echo ============================================
echo.
echo   URL:       http://localhost:8000
echo   Admin:     admin / admin123
echo   Analyst:   analyst / analyst123
echo.
echo   Press Ctrl+C to stop.
echo.

python app.py

pause
