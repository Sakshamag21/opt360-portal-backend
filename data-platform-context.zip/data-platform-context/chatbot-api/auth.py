#!/usr/bin/env python3
"""
Authentication & RBAC for the Chatbot API.

- JWT-based auth (access + refresh tokens)
- Password hashing via werkzeug.security
- Role-based access control: 'admin' and 'analyst'
- Decorators: @auth_required, @admin_required
"""

import jwt
import time
import functools
from werkzeug.security import generate_password_hash, check_password_hash
from flask import request, jsonify, g
from db import pg_query_one
from config import JWT_SECRET, JWT_ALGORITHM, JWT_EXPIRY_HOURS, JWT_REFRESH_DAYS


# ═══════════════════════════════════════════════════════════════
#  Token Management
# ═══════════════════════════════════════════════════════════════

def create_access_token(user_id, username, role):
    """Create a short-lived access token (24h)."""
    now = int(time.time())
    payload = {
        "sub": str(user_id),  # PyJWT requires sub to be a string
        "uid": user_id,       # numeric user id for convenience
        "username": username,
        "role": role,
        "type": "access",
        "iat": now,
        "exp": now + (JWT_EXPIRY_HOURS * 3600),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def create_refresh_token(user_id):
    """Create a long-lived refresh token (7 days)."""
    now = int(time.time())
    payload = {
        "sub": str(user_id),  # PyJWT requires sub to be a string
        "uid": user_id,
        "type": "refresh",
        "iat": now,
        "exp": now + (JWT_REFRESH_DAYS * 86400),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_token(token):
    """Decode and validate a JWT. Returns the payload or raises."""
    return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])


def hash_password(password):
    """Hash a password using werkzeug (PBKDF2)."""
    return generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)


def verify_password(password, password_hash):
    """Verify a password against its hash."""
    return check_password_hash(password_hash, password)


# ═══════════════════════════════════════════════════════════════
#  User Lookup
# ═══════════════════════════════════════════════════════════════

def get_user_by_id(user_id):
    """Fetch a user by ID. Returns dict or None."""
    return pg_query_one(
        "SELECT id, username, email, role, full_name, is_active, created_at "
        "FROM app_users WHERE id = %(user_id)s",
        {"user_id": user_id}
    )


def get_user_by_username(username):
    """Fetch a user by username (includes password_hash). Returns dict or None."""
    return pg_query_one(
        "SELECT id, username, email, password_hash, role, full_name, is_active, created_at "
        "FROM app_users WHERE username = %(username)s",
        {"username": username}
    )


def get_user_by_email(email):
    """Fetch a user by email. Returns dict or None."""
    return pg_query_one(
        "SELECT id, username, email, password_hash, role, full_name, is_active, created_at "
        "FROM app_users WHERE email = %(email)s",
        {"email": email}
    )


# ═══════════════════════════════════════════════════════════════
#  Auth Helpers
# ═══════════════════════════════════════════════════════════════

def extract_token_from_header():
    """Extract the Bearer token from the Authorization header."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return None
    return auth_header[7:]


def get_current_user():
    """Get the current authenticated user from the JWT in the request header.
    Returns (user_dict, error_response). If successful, error_response is None."""
    token = extract_token_from_header()
    if not token:
        return None, (jsonify({"error": "Missing Authorization header"}), 401)

    try:
        payload = decode_token(token)
    except jwt.ExpiredSignatureError:
        return None, (jsonify({"error": "Token expired"}), 401)
    except jwt.InvalidTokenError:
        return None, (jsonify({"error": "Invalid token"}), 401)

    if payload.get("type") != "access":
        return None, (jsonify({"error": "Invalid token type"}), 401)

    user = get_user_by_id(payload.get("uid", int(payload.get("sub", 0))))
    if not user:
        return None, (jsonify({"error": "User not found"}), 401)

    if not user.get("is_active"):
        return None, (jsonify({"error": "Account deactivated"}), 403)

    return user, None


# ═══════════════════════════════════════════════════════════════
#  Decorators
# ═══════════════════════════════════════════════════════════════

def auth_required(f):
    """Require a valid JWT. Sets g.current_user."""
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        user, error = get_current_user()
        if error:
            return error
        g.current_user = user
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    """Require admin role. Must be used after @auth_required."""
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        user = getattr(g, 'current_user', None)
        if not user:
            return jsonify({"error": "Not authenticated"}), 401
        if user.get("role") != "admin":
            return jsonify({"error": "Admin access required"}), 403
        return f(*args, **kwargs)
    return wrapper


def role_required(*roles):
    """Require one of the specified roles."""
    def decorator(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            user = getattr(g, 'current_user', None)
            if not user:
                return jsonify({"error": "Not authenticated"}), 401
            if user.get("role") not in roles:
                return jsonify({"error": f"Requires role: {', '.join(roles)}"}), 403
            return f(*args, **kwargs)
        return wrapper
    return decorator
