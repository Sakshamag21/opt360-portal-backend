#!/usr/bin/env python3
"""
Pipeline wrapper — integrates the text-to-SQL pipeline with the API.

Manages background tasks for:
  - ask:       Generate SQL from a question (no execution)
  - execute:   Run approved SQL against Trino
  - regenerate: Regenerate SQL using user feedback

Each task pushes SSE events to an event queue that the frontend consumes
via GET /api/pipeline/stream/<task_id>.
"""

import sys
import os
import time
import json
import uuid
import threading
import queue
import requests

# Ensure we can import the pipeline
CONTEXT_DIR = os.environ.get("CONTEXT_DIR", r"C:\data-platform-context")
sys.path.insert(0, CONTEXT_DIR)

from config import TRINO_URL, TRINO_USER


# ═══════════════════════════════════════════════════════════════
#  Task Manager — holds background pipeline tasks
# ═══════════════════════════════════════════════════════════════

class PipelineTask:
    """A background pipeline task with an SSE event queue."""

    def __init__(self, task_id, task_type, user_id, conv_id, **kwargs):
        self.task_id = task_id
        self.task_type = task_type  # "ask" | "execute" | "regenerate"
        self.user_id = user_id
        self.conv_id = conv_id
        self.events = queue.Queue()
        self.done = False
        self.error = None
        self.result = None
        self.kwargs = kwargs
        self.thread = threading.Thread(target=self._run, daemon=True)

    def emit(self, event_type, data):
        """Push an SSE event to the queue."""
        self.events.put({"type": event_type, "data": data})

    def _run(self):
        try:
            if self.task_type == "ask":
                self._run_ask()
            elif self.task_type == "execute":
                self._run_execute()
            elif self.task_type == "regenerate":
                self._run_regenerate()
        except Exception as e:
            self.error = str(e)
            self.emit("error", {"message": str(e)})
        finally:
            self.done = True
            self.emit("done", {"task_id": self.task_id})

    def start(self):
        self.thread.start()

    # ─── Ask: Generate SQL ──────────────────────────────────────

    def _run_ask(self):
        question = self.kwargs["question"]
        use_rerank = self.kwargs.get("use_rerank", True)
        history = self.kwargs.get("history", [])

        self.emit("status", {"message": "Starting pipeline..."})

        tts = get_pipeline()

        # Step 1: GraphRAG Retrieval
        self.emit("step_start", {"name": "GraphRAG Retrieval"})
        step_start = time.time()
        tts.use_llm_rerank = use_rerank
        rag_results = tts.retriever.search(
            question, mode="hybrid", top_k=15,
            use_llm_rerank=use_rerank, llm_top_k=10,
        )
        local_count = len(rag_results.get("local_results", []))
        global_count = len(rag_results.get("global_results", []))
        elapsed = round(time.time() - step_start, 2)
        self.emit("step_done", {
            "name": "GraphRAG Retrieval",
            "detail": f"{local_count} entities, {global_count} communities",
            "elapsed": elapsed,
        })

        # Step 2: Context Assembly
        self.emit("step_start", {"name": "Context Assembly"})
        step_start = time.time()
        context = tts._assemble_context(question, rag_results)
        elapsed = round(time.time() - step_start, 2)
        self.emit("step_done", {
            "name": "Context Assembly",
            "detail": f"{len(context):,} chars assembled",
            "elapsed": elapsed,
        })

        # Step 3: Intent Classification
        self.emit("step_start", {"name": "Intent Classification"})
        step_start = time.time()
        classification = tts.classifier.classify(question)
        intent = classification["intent"]
        elapsed = round(time.time() - step_start, 2)
        self.emit("step_done", {
            "name": "Intent Classification",
            "detail": f"Intent: {intent} ({classification['method']}, {classification['confidence']:.0%})",
            "elapsed": elapsed,
        })

        # Route based on intent
        if intent in ("METADATA", "SEMANTIC_SEARCH"):
            # Answer from graph — no SQL needed
            self.emit("step_start", {"name": "Metadata Handler"})
            step_start = time.time()
            meta_result = tts.metadata_handler.handle(question, intent)
            elapsed = round(time.time() - step_start, 2)
            self.emit("step_done", {
                "name": "Metadata Handler",
                "detail": f"Answered from graph ({intent})",
                "elapsed": elapsed,
            })
            self.result = {
                "intent": intent,
                "metadata_answer": meta_result["answer"],
                "metadata_data": meta_result.get("data", {}),
                "status": "completed",
            }
            self.emit("result", self.result)
            return

        # Step 4: LLM SQL Generation
        self.emit("step_start", {"name": "LLM SQL Generation"})
        step_start = time.time()

        prompt = _build_sql_prompt(question, context, history)
        content, reasoning = tts.llm.chat(
            prompt,
            system=_SQL_SYSTEM_PROMPT,
            temperature=0.1,
            max_tokens=3000,
            return_reasoning=True,
        )

        if not content:
            self.emit("step_error", {
                "name": "LLM SQL Generation",
                "error": f"LLM returned no content. Reasoning: {(reasoning or 'none')[:300]}",
            })
            self.result = {"status": "error", "error": "LLM returned no content"}
            self.emit("result", self.result)
            return

        # Clean up SQL
        sql = _clean_sql(content)

        elapsed = round(time.time() - step_start, 2)
        self.emit("step_done", {
            "name": "LLM SQL Generation",
            "detail": "GLM-5.2-FP8 generated SQL",
            "elapsed": elapsed,
        })

        # Step 5: EXPLAIN validation (optional)
        explain_result = None
        explain_plan = None
        if self.kwargs.get("run_explain", True):
            self.emit("step_start", {"name": "EXPLAIN Validation"})
            step_start = time.time()
            try:
                valid, err, plan_text = trino_explain(sql)
                explain_result = {"valid": valid, "error": err}
                if plan_text:
                    explain_plan = plan_text
                elapsed = round(time.time() - step_start, 2)
                if valid:
                    detail = "SQL syntax valid"
                    if plan_text:
                        # Count fragments/stages
                        frag_count = plan_text.count("Fragment")
                        if frag_count:
                            detail += f" · {frag_count} fragments"
                    self.emit("step_done", {
                        "name": "EXPLAIN Validation",
                        "detail": detail,
                        "elapsed": elapsed,
                    })
                else:
                    self.emit("step_warning", {
                        "name": "EXPLAIN Validation",
                        "detail": f"Issue: {err[:150]}",
                        "elapsed": elapsed,
                    })
            except Exception as e:
                elapsed = round(time.time() - step_start, 2)
                self.emit("step_warning", {
                    "name": "EXPLAIN Validation",
                    "detail": str(e)[:150],
                    "elapsed": elapsed,
                })

        self.result = {
            "intent": intent,
            "sql": sql,
            "reasoning": reasoning,
            "context": context,
            "explain_result": explain_result,
            "explain_plan": explain_plan,
            "status": "pending_verification",
        }
        self.emit("result", self.result)

    # ─── Execute: Run approved SQL ──────────────────────────────

    def _run_execute(self):
        sql = self.kwargs["sql"]

        self.emit("status", {"message": "Executing query against Trino..."})
        self.emit("step_start", {"name": "Query Execution"})
        step_start = time.time()

        exec_result = trino_query(sql, timeout=600)
        exec_stats = exec_result.get("stats", {})

        if "error" in exec_result:
            err_msg = exec_result["error"].get("message", str(exec_result["error"]))
            elapsed = round(time.time() - step_start, 2)
            self.emit("step_error", {
                "name": "Query Execution",
                "detail": err_msg[:150],
                "elapsed": elapsed,
            })
            self.result = {
                "query_result": {"success": False, "error": err_msg},
                "status": "completed",
            }
        else:
            cols = exec_result.get("columns", [])
            data = exec_result.get("data", [])
            col_names = [c.get("name", f"col_{i}") for i, c in enumerate(cols)] if cols else []
            elapsed = round(time.time() - step_start, 2)
            self.emit("step_done", {
                "name": "Query Execution",
                "detail": f"{len(data)} rows returned",
                "elapsed": elapsed,
            })

            # Step: Query Performance Analysis
            self.emit("step_start", {"name": "Performance Analysis"})
            perf_start = time.time()

            # Get the EXPLAIN plan (distributed) for the executed query
            explain_plan = None
            _, _, explain_plan = trino_explain(sql, timeout=30)

            perf_elapsed = round(time.time() - perf_start, 2)

            # Build performance report
            query_stats = {
                "execution_time_ms": int(elapsed * 1000),
                "query_id": exec_stats.get("query_id", exec_result.get("query_id", "")),
                "state": exec_stats.get("state", "FINISHED"),
                "cpu_time_ms": exec_stats.get("cpu_millis", 0),
                "wall_time_ms": exec_stats.get("wall_millis", 0),
                "queued_time_ms": exec_stats.get("queued_millis", 0),
                "peak_memory_bytes": exec_stats.get("peak_memory_bytes", 0),
                "processed_rows": exec_stats.get("processed_rows", 0),
                "processed_bytes": exec_stats.get("processed_bytes", 0),
                "physical_input_bytes": exec_stats.get("physical_input_bytes", 0),
                "physical_input_rows": exec_stats.get("physical_input_rows", 0),
                "scheduled_nodes": exec_stats.get("scheduled_nodes", 0),
                "active_nodes": exec_stats.get("active_nodes", 0),
                "total_nodes": exec_stats.get("total_nodes", 0),
                "explain_plan": explain_plan,
            }

            self.emit("step_done", {
                "name": "Performance Analysis",
                "detail": self._format_perf_summary(query_stats),
                "elapsed": perf_elapsed,
            })

            self.result = {
                "query_result": {
                    "success": True,
                    "columns": col_names,
                    "rows": data,
                    "row_count": len(data),
                    "query_id": exec_result.get("query_id", ""),
                },
                "query_stats": query_stats,
                "status": "completed",
            }

        self.emit("result", self.result)

    @staticmethod
    def _format_perf_summary(stats):
        """Short summary for the step_done detail."""
        parts = []
        cpu = stats.get("cpu_time_ms", 0)
        mem = stats.get("peak_memory_bytes", 0)
        rows = stats.get("processed_rows", 0)
        read = stats.get("physical_input_bytes", 0)
        if cpu:
            parts.append(f"CPU {cpu/1000:.1f}s")
        if mem:
            parts.append(f"peak mem {_human_bytes(mem)}")
        if rows:
            parts.append(f"{rows:,} rows scanned")
        if read:
            parts.append(f"read {_human_bytes(read)}")
        return " · ".join(parts) if parts else "stats captured"

    # ─── Regenerate: Fix SQL with user feedback ─────────────────

    def _run_regenerate(self):
        question = self.kwargs["question"]
        previous_sql = self.kwargs["previous_sql"]
        feedback = self.kwargs["feedback"]
        context = self.kwargs.get("context", "")
        history = self.kwargs.get("history", [])

        self.emit("status", {"message": "Regenerating SQL with your feedback..."})
        self.emit("step_start", {"name": "SQL Regeneration"})

        tts = get_pipeline()
        prompt = _build_correction_prompt(question, previous_sql, feedback, context, history)

        content, reasoning = tts.llm.chat(
            prompt,
            system=_SQL_SYSTEM_PROMPT,
            temperature=0.1,
            max_tokens=3000,
            return_reasoning=True,
        )

        if not content:
            self.emit("step_error", {
                "name": "SQL Regeneration",
                "error": f"LLM returned no content",
            })
            self.result = {"status": "error", "error": "LLM returned no content"}
            self.emit("result", self.result)
            return

        sql = _clean_sql(content)
        self.emit("step_done", {
            "name": "SQL Regeneration",
            "detail": "GLM-5.2 regenerated SQL based on feedback",
            "elapsed": 0,
        })

        # EXPLAIN validation for regenerated SQL
        explain_result = None
        explain_plan = None
        self.emit("step_start", {"name": "EXPLAIN Validation"})
        try:
            valid, err, plan_text = trino_explain(sql)
            explain_result = {"valid": valid, "error": err}
            if plan_text:
                explain_plan = plan_text
            if valid:
                detail = "SQL syntax valid"
                if plan_text:
                    frag_count = plan_text.count("Fragment")
                    if frag_count:
                        detail += f" · {frag_count} fragments"
                self.emit("step_done", {"name": "EXPLAIN Validation", "detail": detail, "elapsed": 0})
            else:
                self.emit("step_warning", {"name": "EXPLAIN Validation", "detail": f"Issue: {err[:150]}", "elapsed": 0})
        except Exception as e:
            self.emit("step_warning", {"name": "EXPLAIN Validation", "detail": str(e)[:150], "elapsed": 0})

        self.result = {
            "sql": sql,
            "reasoning": reasoning,
            "explain_result": explain_result,
            "explain_plan": explain_plan,
            "status": "pending_verification",
        }
        self.emit("result", self.result)


# ═══════════════════════════════════════════════════════════════
#  Task Registry
# ═══════════════════════════════════════════════════════════════

_tasks = {}
_tasks_lock = threading.Lock()


def create_task(task_type, user_id, conv_id, **kwargs):
    """Create and start a background pipeline task. Returns the task."""
    task_id = f"task_{uuid.uuid4().hex[:16]}"
    task = PipelineTask(task_id, task_type, user_id, conv_id, **kwargs)
    with _tasks_lock:
        _tasks[task_id] = task
    task.start()
    return task


def get_task(task_id):
    """Get a task by ID."""
    with _tasks_lock:
        return _tasks.get(task_id)


def cleanup_old_tasks(max_age=3600):
    """Remove completed tasks older than max_age seconds."""
    now = time.time()
    with _tasks_lock:
        to_remove = []
        for tid, task in _tasks.items():
            if task.done and hasattr(task, '_done_time') and (now - task._done_time) > max_age:
                to_remove.append(tid)
        for tid in to_remove:
            del _tasks[tid]


# ═══════════════════════════════════════════════════════════════
#  Pipeline (cached)
# ═══════════════════════════════════════════════════════════════

_pipeline = None
_pipeline_lock = threading.Lock()


def get_pipeline():
    """Get the cached TextToSQL pipeline instance."""
    global _pipeline
    with _pipeline_lock:
        if _pipeline is None:
            from text_to_sql import TextToSQL
            _pipeline = TextToSQL(use_llm_rerank=True, verbose=False)
        return _pipeline


# ═══════════════════════════════════════════════════════════════
#  SQL Prompt & Helpers
# ═══════════════════════════════════════════════════════════════

_SQL_SYSTEM_PROMPT = """You are a Trino SQL expert. Generate a valid Trino SQL query based on the user's question and the provided database context.

Rules:
- Only include shard_hint = '<value>' in the WHERE clause if the user explicitly mentions a specific shard in their question. Do NOT default to any shard.
- When using shard_hint, also add it to JOIN ON clauses for joined large tables.
- Never SELECT * without LIMIT on large tables (>1B rows)
- Use TRY_CAST instead of CAST for res_dob_year (has non-numeric values)
- Filter enr_date with WHERE enr_date > TIMESTAMP '2010-01-01' (has anomalies)
- For updt_* varbinary columns, use from_utf8(col) = '11' to filter (NOT CAST(col AS varchar)). b'00'=not updated, b'11'=updated.
- uid is encrypted — never try to decrypt or display it
- No writes allowed — only SELECT queries
- Do NOT add a semicolon at the end
- Return ONLY the SQL query, no explanation

IMPORTANT — Conversation Context:
- You are given the conversation history (previous questions and their SQL).
- If the current question is a follow-up, resolve references using the history.
- The SQL you generate must be a COMPLETE, standalone query.
- If PAST FEEDBACK is provided, it means a previous SQL was REJECTED by the user.
  You MUST learn from that feedback and NOT repeat the same mistake.
  Apply the feedback to ensure your SQL is correct."""


def _build_sql_prompt(question, context, history=None):
    """Build the user prompt for SQL generation.
    Includes conversation history with feedback from rejected queries in this chat.
    """
    history_block = ""
    if history:
        history_lines = []
        for i, h in enumerate(history, 1):
            sql_val = h.get("sql") or "(not yet generated)"
            history_lines.append(f"  Q{i}: {h['question']}")
            history_lines.append(f"  SQL {i}:\n{sql_val}")
            # Include feedback if this query had feedback (rejected + corrected)
            fb = h.get("feedback")
            fb_hist = h.get("feedback_history", [])
            if fb_hist:
                for fb_entry in fb_hist:
                    history_lines.append(f"  WARNING - FEEDBACK for Q{i}: SQL was REJECTED. User said: \"{fb_entry.get('feedback', '')}\"")
                    history_lines.append(f"  -> The rejected SQL was: {fb_entry.get('previous_sql', '')[:150]}")
                    history_lines.append(f"  -> Do NOT repeat this mistake.")
            elif fb:
                history_lines.append(f"  WARNING - FEEDBACK for Q{i}: The SQL was REJECTED. User said: \"{fb}\"")
                history_lines.append(f"  -> Do NOT repeat the same mistake.")
            history_lines.append("")
        history_block = f"""
=== CONVERSATION HISTORY (previous questions and SQL in this chat) ===
{chr(10).join(history_lines)}
The current question may be a follow-up to the above. Resolve any references accordingly.
If a previous query was rejected with feedback, make sure you don't repeat the same mistake.

"""

    return f"""Database context:
{context}
{history_block}User question: {question}

Generate a Trino SQL query:"""


def _human_bytes(n):
    """Convert bytes to human-readable string."""
    if not n or n == 0:
        return "0 B"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def _build_correction_prompt(question, previous_sql, feedback, context, history=None):
    """Build a prompt for regenerating SQL based on user feedback."""
    history_block = ""
    if history:
        history_lines = []
        for i, h in enumerate(history, 1):
            history_lines.append(f"  Q{i}: {h['question']}")
            history_lines.append(f"  SQL {i}:\n{h['sql']}")
            history_lines.append("")
        history_block = f"""
=== CONVERSATION HISTORY ===
{chr(10).join(history_lines)}
"""

    return f"""Database context:
{context}
{history_block}User question: {question}

The following SQL was previously generated but the USER REJECTED it:

--- PREVIOUS SQL (REJECTED) ---
{previous_sql}
--- END PREVIOUS SQL ---

The user provided this feedback explaining what's wrong and what to fix:
"{feedback}"

Please generate a CORRECTED Trino SQL query that:
1. Addresses the issues identified in the user's feedback
2. Still answers the original question correctly
3. Follows all the SQL rules from the system prompt

Generate a corrected Trino SQL query:"""


def _clean_sql(content):
    """Clean up SQL output from the LLM."""
    sql = content.strip()
    if sql.startswith("```"):
        lines = sql.split("\n")
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        sql = "\n".join(lines).strip()

    if sql.endswith(";"):
        sql = sql[:-1].strip()

    # Safety: ensure LIMIT on billion-row tables
    if "LIMIT" not in sql.upper():
        sql = sql.rstrip() + "\nLIMIT 100"

    return sql


# ═══════════════════════════════════════════════════════════════
#  Trino REST API
# ═══════════════════════════════════════════════════════════════

def trino_query(sql, timeout=600):
    """Execute a SQL query on Trino via the REST API.
    Returns columns, data, query_id, and execution stats."""
    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": "chatbot-api",
    }
    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()
    if "error" in result:
        return result

    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])

    query_id = result.get("id", "")
    final_stats = {}

    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.3)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        stats = result.get("stats", {})
        state = stats.get("state", "")
        # Capture stats on every poll; keep the latest
        if stats:
            final_stats = _extract_trino_stats(stats, query_id)
        if state in ("FINISHED", "FAILED", "CANCELED"):
            break
        attempts += 1

    # If we never entered the loop, try stats from initial response
    if not final_stats:
        stats = result.get("stats", {})
        if stats:
            final_stats = _extract_trino_stats(stats, query_id)

    return {"columns": columns, "data": all_data, "query_id": query_id, "stats": final_stats}


def _extract_trino_stats(stats, query_id=""):
    """Extract useful performance metrics from Trino stats object."""
    return {
        "query_id": query_id or stats.get("queryId", ""),
        "state": stats.get("state", ""),
        "elapsed_millis": stats.get("elapsedTimeMillis", 0),
        "queued_millis": stats.get("queuedTimeMillis", 0),
        "wall_millis": stats.get("wallTimeMillis", 0),
        "cpu_millis": stats.get("cpuTimeMillis", 0),
        "peak_memory_bytes": stats.get("peakMemoryBytes", 0),
        "processed_rows": stats.get("processedRows", 0),
        "processed_bytes": stats.get("processedBytes", 0),
        "physical_input_bytes": stats.get("physicalInputBytes", 0),
        "physical_input_rows": stats.get("physicalInputRows", 0),
        "scheduled_nodes": stats.get("scheduledNodes", 0),
        "active_nodes": stats.get("activeNodes", 0),
        "total_nodes": stats.get("totalNodes", 0),
        "progress": stats.get("progressPercentage", 0),
    }


def trino_explain(sql, timeout=30):
    """Run EXPLAIN to validate SQL syntax and capture the query plan.
    Returns (valid, error, plan_text)."""
    try:
        result = trino_query(f"EXPLAIN ({sql})", timeout=timeout)
        if "error" in result:
            err = result["error"].get("message", str(result["error"]))
            return False, err, None
        # EXPLAIN returns rows of plan text
        plan_text = ""
        if result.get("data"):
            plan_lines = []
            for row in result["data"]:
                if row and row[0]:
                    plan_lines.append(str(row[0]))
            plan_text = "\n".join(plan_lines)
        return True, None, plan_text
    except Exception as e:
        return False, str(e), None
