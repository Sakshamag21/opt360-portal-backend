#!/usr/bin/env python3
"""
Database helpers for the Chatbot API.

Uses `docker exec -i graphrag-postgres psql` since psycopg2 can't be installed.
Follows the same pattern as the GraphRAG Navigator backend.
"""

import subprocess
import json
import os
import tempfile
from config import PG_CONTAINER, PG_USER, PG_DB


def pg_query(sql, params=None):
    """Execute a SELECT and return list of dicts. Wraps in json_agg for JSON output."""
    if params:
        sql = _apply_params(sql, params)
    sql = sql.rstrip().rstrip(";").strip()
    wrapped = f"SELECT coalesce(json_agg(row_to_json(t)), '[]'::json) FROM ({sql}) t;"
    return _exec_psql(wrapped)


def pg_query_one(sql, params=None):
    """Execute a SELECT and return a single dict (or None)."""
    if params:
        sql = _apply_params(sql, params)
    sql = sql.rstrip().rstrip(";").strip()
    wrapped = f"SELECT coalesce(row_to_json(t), 'null'::json) FROM ({sql}) t;"
    result = _exec_psql(wrapped)
    if isinstance(result, dict):
        return result
    if isinstance(result, list) and result:
        return result[0]
    return None


def pg_execute(sql, params=None):
    """Execute INSERT/UPDATE/DELETE. Returns list of dicts (from RETURNING clause)."""
    if params:
        sql = _apply_params(sql, params)
    sql = sql.rstrip().rstrip(";").strip()
    # Use a CTE wrapper to capture RETURNING values
    if "returning" in sql.lower():
        wrapped = f"WITH result AS ({sql}) SELECT coalesce(json_agg(row_to_json(r)), '[]'::json) FROM result r;"
    else:
        wrapped = f"WITH result AS ({sql} RETURNING true AS ok) SELECT coalesce(json_agg(row_to_json(r)), '[]'::json) FROM result r;"
    return _exec_psql(wrapped)


def _apply_params(sql, params):
    """Replace %(key)s placeholders with safely escaped values."""
    for key, val in (params or {}).items():
        if val is None:
            replacement = "NULL"
        elif isinstance(val, bool):
            replacement = "true" if val else "false"
        elif isinstance(val, (int, float)):
            replacement = str(val)
        else:
            escaped = str(val).replace("'", "''")
            replacement = f"'{escaped}'"
        sql = sql.replace(f"%({key})s", replacement)
    return sql


def _exec_psql(sql):
    """Execute SQL via docker exec -i psql, return parsed JSON."""
    try:
        result = subprocess.run(
            ["docker", "exec", "-i", PG_CONTAINER, "psql", "-U", PG_USER, "-d", PG_DB, "-t", "-A"],
            input=sql.encode("utf-8"),
            capture_output=True,
            timeout=30,
        )
        if result.returncode != 0:
            err = result.stderr.decode("utf-8", errors="replace").strip()
            raise Exception(f"psql error: {err}")
        out = result.stdout.decode("utf-8", errors="replace").strip()
        if not out or out == "null":
            return []
        return json.loads(out)
    except subprocess.TimeoutExpired:
        raise Exception("Query timed out (30s)")
    except json.JSONDecodeError as e:
        raise Exception(f"JSON parse error: {e}. Raw: {out[:500]}")


def sql_escape(s):
    """Escape a string for safe SQL literal."""
    if s is None:
        return "NULL"
    return "'" + str(s).replace("'", "''") + "'"


def jsonb_literal(obj):
    """Convert a Python object to a jsonb SQL literal."""
    return sql_escape(json.dumps(obj, ensure_ascii=False, default=str)) + "::jsonb"
