#!/usr/bin/env python3
"""
Configuration for the Chatbot API backend.
"""

import os

# ─── Flask ────────────────────────────────────────────────────────────────────
FLASK_HOST = "0.0.0.0"
FLASK_PORT = 8000
FLASK_DEBUG = True
SECRET_KEY = os.environ.get("CHATBOT_SECRET_KEY", "change-this-in-production-please")

# ─── JWT ──────────────────────────────────────────────────────────────────────
JWT_SECRET = os.environ.get("JWT_SECRET", "chatbot-jwt-secret-key-2026-uidai")
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = 24  # access tokens valid for 24h
JWT_REFRESH_DAYS = 7   # refresh tokens valid for 7 days

# ─── PostgreSQL (GraphRAG container) ──────────────────────────────────────────
PG_CONTAINER = "graphrag-postgres"
PG_USER = "graphrag"
PG_DB = "graphrag"

# ─── Pipeline ─────────────────────────────────────────────────────────────────
CONTEXT_DIR = r"C:\data-platform-context"
TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"
LLM_URL = "http://10.10.109.101:32320/glm52/v1"

# ─── CORS ─────────────────────────────────────────────────────────────────────
# React dev server origin
CORS_ORIGINS = [
    "http://localhost:5173",
    "http://localhost:3000",
    "http://127.0.0.1:5173",
    "http://127.0.0.1:3000",
    "http://localhost:8000",
]
