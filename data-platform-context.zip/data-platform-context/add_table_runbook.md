# Adding a New Table — Runbook

> **Automation script:** `C:\data-platform-context\add_table.py`
> **Quick start:** `python C:\data-platform-context\add_table.py <catalog>.<schema>.<table>`

## Quick Reference

### Add a table (full automation)

```bash
python C:\data-platform-context\add_table.py flink_stream.stream_enu.enu_fraudsignal_stream
```

This runs all 9 steps automatically:
1. Discovers schema via Trino (columns, row count, sample, profile)
2. Generates YAML documentation
3. Generates MD documentation
4. Updates `graph_rag_index.json` (entities, relationships, query paths)
5. Updates `knowledge_graph.yaml` (table node)
6. Updates `text-to-sql.md` skill file (table section)
7. Updates `relationship.md` (catalogue, changelog)
8. Migrates PostgreSQL (incremental SQL + execute)
9. Runs retrieval tests

### Dry run (preview without changes)

```bash
python C:\data-platform-context\add_table.py flink_stream.stream_enu.enu_fraudsignal_stream --dry-run
```

Generates YAML + MD to `C:\Users\saksham.nisg\AppData\Local\Temp\opencode\add_table_dry_run\` for review. Does NOT update graph files, skill file, or PostgreSQL.

### Skip specific steps

```bash
# Skip PostgreSQL migration (e.g. container not running)
python C:\data-platform-context\add_table.py <table> --skip-postgres

# Skip skill file and relationship.md updates (do those manually)
python C:\data-platform-context\add_table.py <table> --skip-skill --skip-relationship

# Load discovery data from a saved JSON file (skip Trino)
python C:\data-platform-context\add_table.py <table> --skip-trino --data-file path/to/discovery.json
```

## What the Script Automates vs What Needs Manual Review

| Step | Automated? | Notes |
|------|-----------|-------|
| 1. Trino discovery (columns, count, sample, profile) | ✅ Fully automated | Profiling may be slow on large tables (>100M rows) |
| 2. YAML doc generation | ⚠️ Template generated | Fill in descriptions, source connector, querying guidance |
| 3. MD doc generation | ⚠️ Template generated | Fill in description, example queries |
| 4. `graph_rag_index.json` update | ✅ Fully automated | Adds TABLE, JOIN_KEY, CONCEPT, DATA_QUALITY_ISSUE entities + relationships |
| 5. `knowledge_graph.yaml` update | ✅ Fully automated | Adds table node with cross-schema join keys |
| 6. Skill file (`text-to-sql.md`) update | ⚠️ Template generated | Fill in column descriptions, add synonyms, add value tables |
| 7. `relationship.md` update | ⚠️ Partially automated | Adds to catalogue + changelog. Add navigation items + relationship sections manually |
| 8. PostgreSQL migration | ✅ Fully automated | Generates SQL, executes via `docker exec`, verifies |
| 9. Retrieval test | ✅ Fully automated | Tests full-text search on new entities |

## After Running the Script — Manual Review Checklist

1. **Edit the YAML file** (`C:\data-platform-context\<catalog>.<schema>.<table>.yaml`):
   - Fill in `description` (table-level)
   - Fill in `source_connector`
   - Fill in column `description` fields (all marked `TODO`)
   - Review and edit `notes` fields
   - Review `importance` levels
   - Add table-specific `querying_guidance` rules

2. **Edit the MD file** (`C:\data-platform-context\<catalog>.<schema>.<table>.md`):
   - Fill in `## Description` section
   - Review column dictionary (fill in `TODO` descriptions)
   - Add meaningful `## Example Queries`

3. **Edit the skill file** (`C:\Users\saksham.nisg\.config\opencode\skills\text-to-sql.md`):
   - Update frontmatter `description` (table count, column count, schema description)
   - Fill in column descriptions in the table section
   - Add synonyms to the Synonym Map
   - Add value tables for important categorical columns
   - Add Hard SQL Rules if the table introduces new query patterns
   - Add Query Patterns

4. **Edit `relationship.md`** (`C:\data-platform-context\relationship.md`):
   - Add Navigation Guide items (e.g. "Need X? → Query this table")
   - Add Relationship sections if the table joins to other tables
   - Update the cross-schema diagram if applicable

5. **Test with a natural-language question**:
   - Ask the text-to-SQL skill a question that should use the new table
   - Verify it retrieves the right context and generates correct SQL

## Cross-Schema Join Key Detection

The script automatically detects columns that match known cross-schema join key patterns:

| Join Key | Column Name Patterns |
|----------|---------------------|
| `operator_id` | `operator_id`, `operatorid`, `actor_id`, `supervisorid` |
| `registrar_code` | `registrar`, `registrar_id`, `registrar_code` |
| `ea_code` | `ea`, `enrollment_agency_code`, `ea_code`, `enrolmentagency` |
| `machine_id` | `machine_id`, `machinecode`, `pdata_id`, `machineid` |
| `session_id` | `session_id`, `sid` |
| `station_id` | `station_id`, `stationid` |
| `uid` | `uid`, `resident_uid`, `residentuid` |
| `eid` | `eid`, `event_id`, `eventid` |

When a column matches a pattern, the script:
- Adds a `HAS_COLUMN` relationship to the corresponding JOIN_KEY entity
- If another table already has the same join key, adds a cross-schema `JOINS_TO` relationship
- Adds the join key to the table's `cross_schema_join_keys` properties

## Data Quality Issue Detection

The script automatically detects:
- **Zero dates** (MySQL `0000-00-00`) — flags columns where `min()` returns a zero date
- **Deprecated columns** (100% NULL) — flags columns with all NULLs
- **Varchar numeric columns** — flags varchar columns with names containing `prediction`, `score`, `threshold`, `age`, `count`, `latency` (should use `TRY_CAST AS double`)

## Files Modified by the Script

| File | Location | Modified? |
|------|----------|-----------|
| YAML doc | `C:\data-platform-context\<catalog>.<schema>.<table>.yaml` | Created |
| MD doc | `C:\data-platform-context\<catalog>.<schema>.<table>.md` | Created |
| Discovery JSON | `C:\data-platform-context\<catalog>.<schema>.<table>.discovery.json` | Created |
| GraphRAG index | `C:\data-platform-context\graph_rag_index.json` | Updated (in-place) |
| Knowledge graph | `C:\data-platform-context\knowledge_graph.yaml` | Updated (in-place) |
| Skill file | `C:\Users\saksham.nisg\.config\opencode\skills\text-to-sql.md` | Updated (in-place) |
| Relationship doc | `C:\data-platform-context\relationship.md` | Updated (in-place) |
| Migration SQL | `C:\data-platform-context\postgres\migrate_incremental.sql` | Created |
| PostgreSQL DB | `graphrag-postgres` container (port 5432) | Updated (live) |

## Troubleshooting

### Trino connection fails
- Verify Trino is running: `curl http://10.10.116.39:8080/v1/info`
- Check network connectivity to `10.10.116.39`

### PostgreSQL container not running
- Start it: `docker start graphrag-postgres`
- Or skip: `python add_table.py <table> --skip-postgres`

### Profiling is slow on large tables
- The script runs `count(*)`, `approx_distinct()`, and `min()/max()` on each column
- For tables >1B rows, this can take 10+ minutes
- Use `--dry-run` first to verify column discovery, then run full

### Table already exists in graph
- The script checks for duplicates and skips if the table already exists
- To force re-add: manually remove the table entity from `graph_rag_index.json` first

### Retrieval test fails
- Raw `tsvector` search doesn't do synonym expansion
- The primary retriever (`graph_rag_vector_retriever.py`) handles synonyms + LLM re-ranking
- Manual verification: `docker exec graphrag-postgres psql -U graphrag -d graphrag -c "SELECT entity_id, name FROM entities WHERE name='<table_name>'"`
