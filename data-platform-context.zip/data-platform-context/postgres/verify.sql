SELECT 'EXTENSIONS' AS section, extname || ' ' || extversion AS detail FROM pg_extension
UNION ALL
SELECT 'TABLE', tablename FROM pg_tables WHERE schemaname = 'public'
UNION ALL
SELECT 'VIEW', viewname FROM pg_views WHERE schemaname = 'public'
UNION ALL
SELECT 'INDEX', indexname FROM pg_indexes WHERE schemaname = 'public'
ORDER BY section, detail;
