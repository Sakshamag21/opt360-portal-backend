-- ════════════════════════════════════════════════════════════════════════════
-- GraphRAG PostgreSQL Schema
-- 
-- One database for: graph storage + full-text search + vector search
-- 
-- Layers:
--   1. STRUCTURED  — entities, relationships, communities, query_paths (tables)
--   2. FULL-TEXT   — tsvector columns + GIN indexes (built-in BM25 via ts_rank)
--   3. VECTOR      — pgvector embedding column + HNSW index (for future embeddings)
--   4. GRAPH       — SQL joins on relationships table (Apache AGE can be added later)
-- ════════════════════════════════════════════════════════════════════════════

-- ─── EXTENSIONS ──────────────────────────────────────────────────────────────

CREATE EXTENSION IF NOT EXISTS vector;       -- pgvector: vector storage + ANN search
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";  -- UUID generation

-- ─── ENTITIES ────────────────────────────────────────────────────────────────
-- One row per entity: table, column, concept, data_quality_issue, host, join_key

CREATE TABLE IF NOT EXISTS entities (
    entity_id       TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    type            TEXT NOT NULL,              -- TABLE, COLUMN, CONCEPT, etc.
    description     TEXT,
    properties      JSONB DEFAULT '{}',         -- flexible metadata (data_type, importance, notes, etc.)
    search_text     TEXT,                       -- clean document text (entity-specific only, no cross-entity leakage)
    tsv             TSVECTOR,                   -- auto-populated from search_text
    embedding       VECTOR(768),                -- for future embedding model (NULL for now)
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE entities IS 'GraphRAG entities: tables, columns, concepts, data quality issues, hosts, join keys';
COMMENT ON COLUMN entities.search_text IS 'Clean entity-specific document text — no cross-entity leakage (no community titles, no parent table names in column docs)';

-- ─── RELATIONSHIPS ──────────────────────────────────────────────────────────
-- Graph edges: HAS_COLUMN, JOINS_TO, HAS_CONCEPT, AFFECTS, etc.

CREATE TABLE IF NOT EXISTS relationships (
    id              SERIAL PRIMARY KEY,
    source_id       TEXT NOT NULL REFERENCES entities(entity_id) ON DELETE CASCADE,
    target_id       TEXT NOT NULL REFERENCES entities(entity_id) ON DELETE CASCADE,
    type            TEXT NOT NULL,              -- HAS_COLUMN, JOINS_TO, HAS_CONCEPT, etc.
    description     TEXT,
    properties      JSONB DEFAULT '{}',         -- join_keys, cardinality, etc.
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE relationships IS 'Graph edges between entities (HAS_COLUMN, JOINS_TO, HAS_CONCEPT, etc.)';

-- ─── TEXT UNITS ─────────────────────────────────────────────────────────────
-- Natural-language descriptions and enriched questions per entity

CREATE TABLE IF NOT EXISTS text_units (
    unit_id         TEXT PRIMARY KEY,
    entity_id       TEXT REFERENCES entities(entity_id) ON DELETE CASCADE,
    text            TEXT NOT NULL,
    source          TEXT DEFAULT 'original',    -- 'original' or 'llm_enriched'
    tsv             TSVECTOR,                   -- auto-populated from text
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE text_units IS 'Natural-language text associated with entities (descriptions, enriched questions)';

-- ─── COMMUNITIES ────────────────────────────────────────────────────────────
-- Entity groupings with summaries and reports

CREATE TABLE IF NOT EXISTS communities (
    community_id        TEXT PRIMARY KEY,
    title               TEXT NOT NULL,
    summary             TEXT,
    entity_count        INTEGER DEFAULT 0,
    entity_ids          TEXT[] DEFAULT '{}',
    key_relationships   TEXT[] DEFAULT '{}',
    query_examples      TEXT[] DEFAULT '{}',
    report              TEXT,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE communities IS 'Entity communities with LLM-generated summaries and reports';

-- ─── QUERY PATHS ────────────────────────────────────────────────────────────
-- Pre-computed multi-table join paths

CREATE TABLE IF NOT EXISTS query_paths (
    id              SERIAL PRIMARY KEY,
    start_table     TEXT NOT NULL,
    need            TEXT,                       -- what this query path answers
    joins           JSONB DEFAULT '[]',         -- [{to, on, cardinality}, ...]
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE query_paths IS 'Pre-computed multi-table join paths for common query patterns';

-- ════════════════════════════════════════════════════════════════════════════
-- INDEXES
-- ════════════════════════════════════════════════════════════════════════════

-- ─── FULL-TEXT SEARCH (built-in BM25 via ts_rank) ───────────────────────────

CREATE INDEX IF NOT EXISTS idx_entities_tsv     ON entities   USING GIN(tsv);
CREATE INDEX IF NOT EXISTS idx_text_units_tsv   ON text_units USING GIN(tsv);

-- ─── JSONB PROPERTY LOOKUP ──────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_entities_props       ON entities      USING GIN(properties);
CREATE INDEX IF NOT EXISTS idx_relationships_props  ON relationships USING GIN(properties);

-- ─── GRAPH TRAVERSAL (relationship lookups) ─────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_rel_source  ON relationships(source_id);
CREATE INDEX IF NOT EXISTS idx_rel_target  ON relationships(target_id);
CREATE INDEX IF NOT EXISTS idx_rel_type    ON relationships(type);
CREATE INDEX IF NOT EXISTS idx_rel_source_type ON relationships(source_id, type);
CREATE INDEX IF NOT EXISTS idx_rel_target_type ON relationships(target_id, type);

-- ─── ENTITY LOOKUPS ─────────────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_entity_type ON entities(type);
CREATE INDEX IF NOT EXISTS idx_entity_name ON entities(name);

-- ─── TEXT UNIT LOOKUP ───────────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_text_units_entity ON text_units(entity_id);

-- ─── COMMUNITY MEMBERSHIP ───────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_communities_entities ON communities USING GIN(entity_ids);

-- ─── VECTOR SEARCH (HNSW — for when embeddings are available) ───────────────

CREATE INDEX IF NOT EXISTS idx_entities_embedding ON entities
    USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);

-- ════════════════════════════════════════════════════════════════════════════
-- TRIGGERS: Auto-populate tsvector from text
-- ════════════════════════════════════════════════════════════════════════════

-- Entities: build tsv from search_text (or fallback to name + description)
CREATE OR REPLACE FUNCTION update_entity_tsv() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.search_text IS NULL OR NEW.search_text = '' THEN
        NEW.search_text := COALESCE(NEW.name, '') || ' ' || COALESCE(NEW.description, '');
    END IF;
    NEW.tsv := to_tsvector('english', NEW.search_text);
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_entities_tsv ON entities;
CREATE TRIGGER trg_entities_tsv
    BEFORE INSERT OR UPDATE ON entities
    FOR EACH ROW EXECUTE FUNCTION update_entity_tsv();

-- Text units: build tsv from text
CREATE OR REPLACE FUNCTION update_text_unit_tsv() RETURNS TRIGGER AS $$
BEGIN
    NEW.tsv := to_tsvector('english', COALESCE(NEW.text, ''));
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_text_units_tsv ON text_units;
CREATE TRIGGER trg_text_units_tsv
    BEFORE INSERT OR UPDATE ON text_units
    FOR EACH ROW EXECUTE FUNCTION update_text_unit_tsv();

-- ════════════════════════════════════════════════════════════════════════════
-- CONVENIENCE VIEWS
-- ════════════════════════════════════════════════════════════════════════════

-- View: All columns with their parent table
CREATE OR REPLACE VIEW v_columns AS
SELECT
    c.entity_id,
    c.name AS column_name,
    c.description,
    c.properties->>'data_type' AS data_type,
    c.properties->>'importance' AS importance,
    c.properties->>'table' AS table_name,
    c.properties->>'notes' AS notes
FROM entities c
WHERE c.type = 'COLUMN';

-- View: All table-to-table relationships (joins)
CREATE OR REPLACE VIEW v_joins AS
SELECT
    r.id,
    s.name AS source_table,
    t.name AS target_table,
    r.type AS relationship_type,
    r.description,
    r.properties->>'join_keys' AS join_keys,
    r.properties->>'cardinality' AS cardinality
FROM relationships r
JOIN entities s ON r.source_id = s.entity_id
JOIN entities t ON r.target_id = t.entity_id
WHERE r.type = 'JOINS_TO'
  AND s.type = 'TABLE'
  AND t.type = 'TABLE';

-- View: Entity neighbors (graph expansion in one query)
CREATE OR REPLACE VIEW v_neighbors AS
SELECT DISTINCT
    r.source_id AS entity_id,
    r.target_id AS neighbor_id,
    e2.name AS neighbor_name,
    e2.type AS neighbor_type,
    e2.description AS neighbor_description,
    r.type AS relationship_type,
    r.description AS relationship_description
FROM relationships r
JOIN entities e2 ON r.target_id = e2.entity_id
UNION
SELECT DISTINCT
    r.target_id AS entity_id,
    r.source_id AS neighbor_id,
    e2.name AS neighbor_name,
    e2.type AS neighbor_type,
    e2.description AS neighbor_description,
    r.type AS relationship_type,
    r.description AS relationship_description
FROM relationships r
JOIN entities e2 ON r.source_id = e2.entity_id;

-- ════════════════════════════════════════════════════════════════════════════
-- DONE
-- ════════════════════════════════════════════════════════════════════════════
