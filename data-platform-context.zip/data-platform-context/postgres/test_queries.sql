-- Verify data counts
SELECT 'entities' AS table_name, count(*) FROM entities
UNION ALL SELECT 'relationships', count(*) FROM relationships
UNION ALL SELECT 'text_units', count(*) FROM text_units
UNION ALL SELECT 'communities', count(*) FROM communities
UNION ALL SELECT 'query_paths', count(*) FROM query_paths
ORDER BY table_name;

-- Check entity types
SELECT type, count(*) FROM entities GROUP BY type ORDER BY count DESC;

-- Check that tsv (full-text search vector) was auto-populated
SELECT entity_id, name, type, 
       left(search_text, 80) AS search_text_preview,
       tsv IS NOT NULL AS has_tsv
FROM entities 
WHERE type IN ('TABLE', 'COLUMN')
LIMIT 5;

-- Test full-text search: "person alive death"
SELECT entity_id, name, type, 
       ts_rank(tsv, query) AS score,
       left(description, 60) AS description_preview
FROM entities, to_tsquery('english', 'person & alive & death') query
WHERE tsv @@ query
ORDER BY score DESC
LIMIT 5;

-- Test full-text search: "name updated changed"
SELECT entity_id, name, type,
       ts_rank(tsv, query) AS score
FROM entities, to_tsquery('english', 'name & updated & changed') query
WHERE tsv @@ query
ORDER BY score DESC
LIMIT 5;

-- Test graph traversal: find all columns of uid_master
SELECT e.name, e.description, e.properties->>'data_type' AS data_type
FROM entities e
JOIN relationships r ON r.target_id = e.entity_id
JOIN entities t ON r.source_id = t.entity_id
WHERE t.name = 'uid_master' AND r.type = 'HAS_COLUMN'
ORDER BY e.name
LIMIT 10;

-- Test graph traversal: find table-to-table joins
SELECT * FROM v_joins;

-- Test vector column exists (should be NULL for now)
SELECT entity_id, name, embedding IS NULL AS no_embedding_yet
FROM entities
WHERE type = 'TABLE'
LIMIT 5;
