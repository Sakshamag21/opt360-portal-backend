#!/usr/bin/env python3
"""
add_table.py — Add a new Trino table to the text-to-SQL knowledge base.

Usage:
    python add_table.py <catalog>.<schema>.<table>
    python add_table.py flink_stream.stream_enu.new_table

    Options:
      --dry-run         Generate to temp, don't update real files
      --skip-trino      Skip Trino discovery (use --data-file instead)
      --data-file PATH  Load discovery data from a JSON file (instead of Trino)
      --skip-postgres   Skip PostgreSQL migration
      --help            Show this help

Workflow (9 steps):
    1. Discover schema via Trino (SHOW COLUMNS, row count, sample, profile)
    2. Generate YAML documentation
    3. Generate MD documentation
    4. Update graph_rag_index.json (entities, relationships, query paths)
    5. Update knowledge_graph.yaml (table node, edges, concepts)
    6. Update text-to-sql.md skill file (table section, synonyms)
    7. Update relationship.md (catalogue, navigation, changelog)
    8. Migrate PostgreSQL (incremental SQL + execute + verify)
    9. Run retrieval tests

Prerequisites:
    - Trino running at http://10.10.116.39:8080
    - PostgreSQL container 'graphrag-postgres' running
    - Python with requests, json
"""
import sys
import os
import json
import re
import subprocess
import time
import argparse
from datetime import datetime
from pathlib import Path

# ─── Configuration ────────────────────────────────────────────────────────────

TRINO_URL = "http://10.10.116.39:8080"
TRINO_USER = "analyst"
TRINO_SOURCE = "text-to-sql"

CONTEXT_DIR = r"C:\data-platform-context"
SKILL_FILE = r"C:\Users\saksham.nisg\.config\opencode\skills\text-to-sql.md"
GRAPH_RAG_JSON = os.path.join(CONTEXT_DIR, "graph_rag_index.json")
KNOWLEDGE_GRAPH_YAML = os.path.join(CONTEXT_DIR, "knowledge_graph.yaml")
RELATIONSHIP_MD = os.path.join(CONTEXT_DIR, "relationship.md")

PG_CONTAINER = "graphrag-postgres"
PG_USER = "graphrag"
PG_DB = "graphrag"

# ─── Cross-schema join key detection ─────────────────────────────────────────
# Maps column name patterns to known cross-schema join keys.
# When a new table has a column matching one of these patterns,
# it's automatically linked to the corresponding join key entity.

CROSS_SCHEMA_JOIN_KEYS = {
    "operator_id": {
        "patterns": ["operator_id", "operatorid", "actor_id", "supervisorid"],
        "description": "Operator login ID. Cross-schema join key. Appears across strot.mysql_uid_v2 and flink_stream.stream_enu.",
        "format": "e.g. MH_MIT_JG_NS249784",
    },
    "registrar_code": {
        "patterns": ["registrar", "registrar_id", "registrar_code"],
        "description": "3-digit registrar code. Cross-schema join key across all 3 schemas.",
        "format": "3-digit numeric",
    },
    "ea_code": {
        "patterns": ["ea", "enrollment_agency_code", "ea_code", "enrolmentagency"],
        "description": "4-digit EA code. Cross-schema join key across all 3 schemas.",
        "format": "4-digit numeric",
    },
    "machine_id": {
        "patterns": ["machine_id", "machinecode", "pdata_id", "machineid"],
        "description": "Machine/device ID (<manufacturer><UUID>). Cross-schema join key.",
        "format": "<manufacturer><UUID>",
    },
    "session_id": {
        "patterns": ["session_id", "sid"],
        "description": "Session ID. Cross-schema join key within flink_stream.",
        "format": "uc-<UUID> or S<timestamp>",
    },
    "station_id": {
        "patterns": ["station_id", "stationid"],
        "description": "Station identifier. Cross-schema join key.",
        "format": "station UUID/code",
    },
    "uid": {
        "patterns": ["uid", "resident_uid", "residentuid"],
        "description": "Encrypted UID (Aadhaar number). Cross-schema join key.",
        "format": "Base64-like encrypted blob",
    },
    "eid": {
        "patterns": ["eid", "event_id", "eventid"],
        "description": "Event/enrolment ID. Cross-schema join key.",
        "format": "UUID or enrolment ID string",
    },
}

# ─── Trino Query Execution ────────────────────────────────────────────────────

def trino_query(sql, timeout=300):
    """Execute a Trino query via REST API and return results."""
    import requests

    headers = {
        "Content-Type": "text/plain",
        "X-Trino-User": TRINO_USER,
        "X-Trino-Source": TRINO_SOURCE,
    }

    r = requests.post(f"{TRINO_URL}/v1/statement", headers=headers, data=sql, timeout=30)
    result = r.json()

    if "error" in result:
        raise Exception(f"Trino error: {result['error'].get('message', result['error'])}")

    all_data = []
    columns = result.get("columns", [])
    if result.get("data"):
        all_data.extend(result["data"])

    attempts = 0
    while result.get("nextUri") and attempts < 1000:
        time.sleep(0.3)
        r = requests.get(result["nextUri"], headers=headers, timeout=30)
        result = r.json()
        if result.get("data"):
            all_data.extend(result["data"])
        if not columns and result.get("columns"):
            columns = result["columns"]
        if result.get("error"):
            raise Exception(f"Trino error: {result['error'].get('message', result['error'])}")
        attempts += 1

    col_names = [c["name"] for c in columns] if columns else []
    return col_names, all_data


# ─── Step 1: Discover Table via Trino ─────────────────────────────────────────

def discover_table(catalog, schema, table):
    """Discover all metadata for a table via Trino."""
    full_ref = f"{catalog}.{schema}.{table}"
    print(f"\n{'='*70}")
    print(f"Step 1: Discovering {full_ref} via Trino")
    print(f"{'='*70}")

    info = {
        "catalog": catalog,
        "schema": schema,
        "table": table,
        "full_reference": full_ref,
        "discovered_at": datetime.now().isoformat(),
    }

    # 1a. SHOW COLUMNS
    print(f"\n  [1a] SHOW COLUMNS FROM {full_ref}...")
    try:
        cols_names, cols_data = trino_query(f"SHOW COLUMNS FROM {full_ref}")
        columns = []
        for row in cols_data:
            columns.append({
                "name": row[0],
                "type": row[1],
                "extra": row[2] if len(row) > 2 else "",
                "comment": row[3] if len(row) > 3 else "",
            })
        info["columns"] = columns
        print(f"       Found {len(columns)} columns")
    except Exception as e:
        print(f"       ERROR: {e}")
        sys.exit(1)

    # 1b. Row count
    print(f"\n  [1b] SELECT count(*) FROM {full_ref}...")
    try:
        _, count_data = trino_query(f"SELECT count(*) FROM {full_ref}")
        info["row_count"] = int(count_data[0][0])
        print(f"       Row count: {info['row_count']:,}")
    except Exception as e:
        print(f"       WARNING: Could not get row count: {e}")
        info["row_count"] = None

    # 1c. Sample rows
    print(f"\n  [1c] SELECT * FROM {full_ref} LIMIT 5...")
    try:
        sample_names, sample_data = trino_query(f"SELECT * FROM {full_ref} LIMIT 5")
        info["sample_columns"] = sample_names
        info["sample_rows"] = sample_data
        print(f"       Got {len(sample_data)} sample rows")
    except Exception as e:
        print(f"       WARNING: Could not get sample: {e}")
        info["sample_rows"] = []

    # 1d. Profile columns
    print(f"\n  [1d] Profiling columns...")
    info["column_profiles"] = {}

    for col in columns:
        col_name = col["name"]
        col_type = col["type"].lower()
        profile = {}

        # NULL count
        try:
            _, null_data = trino_query(
                f"SELECT count(*) - count(\"{col_name}\") FROM {full_ref}"
            )
            null_count = int(null_data[0][0])
            profile["null_count"] = null_count
            if info["row_count"]:
                profile["null_percent"] = round(null_count / info["row_count"] * 100, 2)
        except:
            pass

        # Distinct count (for cardinality detection)
        if info["row_count"] and info["row_count"] > 0:
            try:
                _, dist_data = trino_query(
                    f"SELECT approx_distinct(\"{col_name}\") FROM {full_ref}"
                )
                distinct_count = int(dist_data[0][0])
                profile["distinct_count"] = distinct_count
                profile["cardinality_ratio"] = round(distinct_count / info["row_count"] * 100, 2)

                # Categorical if low cardinality (< 100 distinct values or < 1% ratio)
                is_categorical = (
                    (distinct_count < 100 and distinct_count > 0) or
                    (profile.get("cardinality_ratio", 100) < 1 and distinct_count < 1000)
                )
                profile["is_categorical"] = is_categorical
            except:
                profile["is_categorical"] = False

        # Top values for categorical columns
        if profile.get("is_categorical"):
            try:
                _, top_data = trino_query(
                    f"SELECT \"{col_name}\", count(*) AS cnt FROM {full_ref} "
                    f"GROUP BY \"{col_name}\" ORDER BY cnt DESC LIMIT 20"
                )
                profile["top_values"] = [
                    {"value": row[0], "count": int(row[1])} for row in top_data
                ]
                print(f"       {col_name}: {len(profile['top_values'])} top values")
            except Exception as e:
                print(f"       {col_name}: could not get top values: {e}")

        # Date range for timestamp/date columns
        if "timestamp" in col_type or "date" in col_type:
            try:
                _, date_data = trino_query(
                    f"SELECT min(\"{col_name}\"), max(\"{col_name}\") FROM {full_ref}"
                )
                if date_data and date_data[0]:
                    profile["min_value"] = str(date_data[0][0])
                    profile["max_value"] = str(date_data[0][1])
                    print(f"       {col_name}: {profile['min_value']} -> {profile['max_value']}")

                    # Check for zero dates (MySQL '0000-00-00')
                    if "0000" in str(profile.get("min_value", "")):
                        profile["has_zero_dates"] = True
                        print(f"       WARNING: {col_name} has zero dates!")
            except Exception as e:
                # Try with TRY_CAST for zero dates
                try:
                    _, date_data = trino_query(
                        f"SELECT min(TRY_CAST(\"{col_name}\" AS timestamp)), "
                        f"max(TRY_CAST(\"{col_name}\" AS timestamp)) FROM {full_ref}"
                    )
                    if date_data and date_data[0]:
                        profile["min_value"] = str(date_data[0][0])
                        profile["max_value"] = str(date_data[0][1])
                        profile["has_zero_dates"] = True
                        print(f"       {col_name}: (with TRY_CAST) {profile.get('min_value')} -> {profile.get('max_value')}")
                except:
                    print(f"       {col_name}: could not get date range: {e}")

        info["column_profiles"][col_name] = profile

    # 1e. Detect cross-schema join keys
    print(f"\n  [1e] Detecting cross-schema join keys...")
    info["cross_schema_joins"] = []
    for col in columns:
        col_name_lower = col["name"].lower()
        for jk_name, jk_info in CROSS_SCHEMA_JOIN_KEYS.items():
            if col_name_lower in jk_info["patterns"]:
                info["cross_schema_joins"].append({
                    "column": col["name"],
                    "join_key": jk_name,
                    "description": jk_info["description"],
                    "format": jk_info["format"],
                })
                print(f"       Found: {col['name']} -> join key '{jk_name}'")
                break

    # 1f. Detect data quality issues
    print(f"\n  [1f] Detecting data quality issues...")
    info["data_quality_issues"] = []

    for col in columns:
        col_name = col["name"]
        profile = info["column_profiles"].get(col_name, {})

        # Zero dates
        if profile.get("has_zero_dates"):
            info["data_quality_issues"].append({
                "name": f"{col_name}_zero_dates",
                "description": f"{col_name} in {table} contains zero dates. Use a different date column or TRY_CAST.",
                "column": col_name,
                "fix": "Use TRY_CAST or a different date column",
            })

        # 100% NULL (deprecated)
        if profile.get("null_percent") == 100.0:
            info["data_quality_issues"].append({
                "name": f"{col_name}_deprecated",
                "description": f"{col_name} in {table} is 100% NULL (deprecated column).",
                "column": col_name,
                "fix": "Do not use this column",
            })

        # Varchar that might be numeric (for prediction/score columns)
        if "varchar" in col["type"].lower() and any(
            kw in col_name.lower() for kw in ["prediction", "score", "threshold", "age", "count", "latency"]
        ):
            info["data_quality_issues"].append({
                "name": f"{col_name}_varchar_numeric",
                "description": f"{col_name} in {table} is varchar but may contain numeric values. Use TRY_CAST({col_name} AS double).",
                "column": col_name,
                "fix": f"TRY_CAST({col_name} AS double)",
            })

    if info["data_quality_issues"]:
        print(f"       Found {len(info['data_quality_issues'])} data quality issues")
    else:
        print(f"       No data quality issues detected automatically")

    # 1g. Determine primary timestamp column
    print(f"\n  [1g] Identifying primary timestamp column...")
    info["primary_timestamp"] = None
    for col in columns:
        col_type = col["type"].lower()
        col_name_lower = col["name"].lower()
        if "timestamp" in col_type:
            # Prefer columns named like 'timestamp', 'ets', 'event_timestamp', 'created_at'
            if any(kw in col_name_lower for kw in ["timestamp", "ets", "created", "event_time"]):
                info["primary_timestamp"] = col["name"]
                break
    if not info["primary_timestamp"]:
        # Fall back to first timestamp column
        for col in columns:
            if "timestamp" in col["type"].lower():
                info["primary_timestamp"] = col["name"]
                break
    if info["primary_timestamp"]:
        print(f"       Primary timestamp: {info['primary_timestamp']}")
    else:
        print(f"       No timestamp column found")

    # 1h. Determine if shard_hint exists
    info["has_shard_hint"] = any(col["name"].lower() == "shard_hint" for col in columns)
    print(f"\n  [1h] Has shard_hint: {info['has_shard_hint']}")

    print(f"\n  Discovery complete!")
    return info


# ─── Step 2: Generate YAML Documentation ──────────────────────────────────────

def generate_yaml(info, output_dir):
    """Generate YAML documentation file."""
    full_ref = info["full_reference"]
    yaml_path = os.path.join(output_dir, f"{full_ref}.yaml")

    lines = []
    lines.append(f"# Auto-generated by add_table.py on {info['discovered_at']}")
    lines.append(f"# REVIEW AND EDIT before finalizing.")
    lines.append("")
    lines.append("table:")
    lines.append(f"  catalog: {info['catalog']}")
    lines.append(f"  schema: {info['schema']}")
    lines.append(f"  name: {info['table']}")
    lines.append(f"  full_reference: {full_ref}")
    lines.append(f"  source_connector: \"TODO: Specify source connector\"")
    lines.append(f"  approximate_row_count: {info.get('row_count', 'unknown')}")
    lines.append(f"  column_count: {len(info['columns'])}")
    lines.append(f'  description: "TODO: Write table description"')

    # Date range
    if info.get("primary_timestamp"):
        ts_profile = info["column_profiles"].get(info["primary_timestamp"], {})
        lines.append("  data_date_range:")
        lines.append(f'    min: "{ts_profile.get("min_value", "unknown")}"')
        lines.append(f'    max: "{ts_profile.get("max_value", "unknown")}"')
    else:
        lines.append("  data_date_range:")
        lines.append("    note: \"No timestamp column found\"")

    # Hosts
    lines.append("  hosts:")
    lines.append("    read:")
    lines.append("      - \"10.10.116.39\"")
    lines.append("    write_allowed: false")
    lines.append(f'    note: "Read-only access via Trino. {"No shard_hint — use " + info["primary_timestamp"] + " for partition pruning." if not info["has_shard_hint"] and info.get("primary_timestamp") else ""}"')
    lines.append(f'  warning: "{"Large table" if info.get("row_count") and info["row_count"] > 1000000 else "Table"} (~{info.get("row_count", "?"):,} rows). Always use LIMIT and predicates."')

    # Columns
    lines.append("")
    lines.append("columns:")
    for col in info["columns"]:
        profile = info["column_profiles"].get(col["name"], {})
        lines.append(f"  - name: {col['name']}")
        lines.append(f"    type: {col['type']}")
        lines.append(f'    description: "TODO: Describe {col["name"]}"')

        notes_parts = []
        if profile.get("null_count") is not None:
            null_pct = profile.get("null_percent", 0)
            if null_pct == 100:
                notes_parts.append("100% NULL (deprecated)")
            elif null_pct > 0:
                notes_parts.append(f"NULL for ~{null_pct}% of rows")
            else:
                notes_parts.append("Always populated (0 NULLs)")

        if profile.get("distinct_count"):
            dist = profile["distinct_count"]
            if dist == 1:
                notes_parts.append(f"Single value: {profile['top_values'][0]['value'] if profile.get('top_values') else '?'}")
            elif profile.get("is_categorical") and profile.get("top_values"):
                top_vals = profile["top_values"][:3]
                vals_str = ", ".join(f"'{v['value']}' ({v['count']:,})" for v in top_vals)
                notes_parts.append(f"Top values: {vals_str}")

        if profile.get("min_value") and profile.get("max_value"):
            notes_parts.append(f"Range: {profile['min_value']} to {profile['max_value']}")

        # Mark cross-schema join keys
        for csj in info.get("cross_schema_joins", []):
            if csj["column"] == col["name"]:
                notes_parts.append(f"Cross-schema join key: {csj['join_key']}")
                break

        notes = ". ".join(notes_parts) + "." if notes_parts else "TODO: Add notes"
        lines.append(f'    notes: "{notes}"')

        # Importance
        if col["name"].lower() in ["uid", "eid", "event_id", "eventid"] or any(
            csj["column"] == col["name"] for csj in info.get("cross_schema_joins", [])
        ):
            importance = "High"
        elif profile.get("is_categorical") and not profile.get("null_percent") == 100:
            importance = "Medium"
        elif profile.get("null_percent") == 100:
            importance = "Low"
        else:
            importance = "Medium"
        lines.append(f"    importance: {importance}")

        if profile.get("null_percent") == 100:
            lines.append("    deprecated: true")

    # Categorical mappings
    categorical_cols = [
        col for col in info["columns"]
        if info["column_profiles"].get(col["name"], {}).get("is_categorical")
        and info["column_profiles"].get(col["name"], {}).get("top_values")
    ]
    if categorical_cols:
        lines.append("")
        lines.append("categorical_mappings:")
        for col in categorical_cols:
            profile = info["column_profiles"][col["name"]]
            lines.append(f"  {col['name']}:")
            lines.append(f'    note: "TODO: Add note for {col["name"]}"')
            lines.append("    top_values:")
            for v in profile["top_values"][:20]:
                val_str = "null" if v["value"] is None else f'"{v["value"]}"'
                lines.append(f"      - value: {val_str}")
                lines.append(f"        count: {v['count']}")

    # Date ranges
    date_cols = [
        col for col in info["columns"]
        if "timestamp" in col["type"].lower() or "date" in col["type"].lower()
    ]
    if date_cols:
        lines.append("")
        lines.append("date_ranges:")
        for col in date_cols:
            profile = info["column_profiles"].get(col["name"], {})
            lines.append(f"  - column: {col['name']}")
            lines.append(f'    min: "{profile.get("min_value", "unknown")}"')
            lines.append(f'    max: "{profile.get("max_value", "unknown")}"')

    # Sample row
    if info.get("sample_rows"):
        lines.append("")
        lines.append("sample_row:")
        for i, col_name in enumerate(info["sample_columns"]):
            val = info["sample_rows"][0][i] if info["sample_rows"][0] else None
            val_str = "null" if val is None else f'"{val}"'
            lines.append(f"  {col_name}: {val_str}")

    # Querying guidance
    lines.append("")
    lines.append("querying_guidance:")
    if not info["has_shard_hint"] and info.get("primary_timestamp"):
        lines.append(f'  - rule: "No shard_hint column. Use {info["primary_timestamp"]} for partition pruning."')
    elif info["has_shard_hint"]:
        lines.append('  - rule: "Always include WHERE shard_hint = \'XX\' for partition pruning."')
    lines.append(f'  - rule: "Always add LIMIT to prevent massive result sets on ~{info.get("row_count", "?"):,} rows."')

    for dq in info.get("data_quality_issues", []):
        lines.append(f'  - rule: "{dq["description"]} Fix: {dq["fix"]}"')

    for csj in info.get("cross_schema_joins", []):
        lines.append(f'  - rule: "Cross-schema join key: {csj["column"]} links to {csj["join_key"]} in other schemas."')

    lines.append('  - rule: "TODO: Review and add table-specific query guidance."')

    yaml_content = "\n".join(lines) + "\n"

    with open(yaml_path, "w", encoding="utf-8") as f:
        f.write(yaml_content)

    print(f"  YAML written: {yaml_path} ({len(yaml_content)} chars)")
    return yaml_path


# ─── Step 3: Generate MD Documentation ────────────────────────────────────────

def generate_md(info, output_dir):
    """Generate MD documentation file."""
    full_ref = info["full_reference"]
    md_path = os.path.join(output_dir, f"{full_ref}.md")

    lines = []
    lines.append(f"# Table: {full_ref}")
    lines.append("")
    lines.append("<!-- Auto-generated by add_table.py. REVIEW AND EDIT before finalizing. -->")
    lines.append("")
    lines.append("## Overview")
    lines.append("")
    lines.append("| Property | Value |")
    lines.append("|----------|-------|")
    lines.append(f"| **Catalog** | `{info['catalog']}` |")
    lines.append(f"| **Schema** | `{info['schema']}` |")
    lines.append(f"| **Table** | `{info['table']}` |")
    lines.append(f"| **Full Reference** | `{full_ref}` |")
    rc = info.get("row_count")
    rc_str = f"~{rc:,}" if rc else "unknown"
    lines.append(f"| **Row Count** | {rc_str} |")
    lines.append(f"| **Columns** | {len(info['columns'])} |")

    if info.get("primary_timestamp"):
        ts_profile = info["column_profiles"].get(info["primary_timestamp"], {})
        lines.append(f"| **Date Range** | {ts_profile.get('min_value', '?')} → {ts_profile.get('max_value', '?')} |")
    lines.append(f"| **Source** | TODO: Specify source |")
    lines.append(f"| **Access** | Read-only via Trino at `10.10.116.39:8080` |")
    lines.append("")
    lines.append("## Description")
    lines.append("")
    lines.append("TODO: Write table description.")
    lines.append("")
    lines.append(f"## Column Dictionary ({len(info['columns'])} columns)")
    lines.append("")

    # Group columns by detected role
    lines.append("| Column | Type | Description | Notes |")
    lines.append("|--------|------|-------------|-------|")
    for col in info["columns"]:
        profile = info["column_profiles"].get(col["name"], {})
        notes_parts = []
        if profile.get("null_percent") is not None:
            if profile["null_percent"] == 100:
                notes_parts.append("~100% NULL (deprecated)")
            elif profile["null_percent"] > 0:
                notes_parts.append(f"NULL ~{profile['null_percent']}%")
            else:
                notes_parts.append("Always populated")

        if profile.get("is_categorical") and profile.get("top_values"):
            top = profile["top_values"][:3]
            vals = ", ".join(f"`{v['value']}`" if v['value'] is not None else "`NULL`" for v in top)
            notes_parts.append(f"Top: {vals}")

        if profile.get("min_value"):
            notes_parts.append(f"Range: {profile['min_value']} → {profile['max_value']}")

        for csj in info.get("cross_schema_joins", []):
            if csj["column"] == col["name"]:
                notes_parts.append(f"**Cross-schema join key** ({csj['join_key']})")
                break

        notes = ". ".join(notes_parts) if notes_parts else "TODO"
        lines.append(f"| `{col['name']}` | {col['type']} | TODO | {notes} |")

    # Categorical value tables
    categorical_cols = [
        col for col in info["columns"]
        if info["column_profiles"].get(col["name"], {}).get("is_categorical")
        and info["column_profiles"].get(col["name"], {}).get("top_values")
    ]
    for col in categorical_cols:
        profile = info["column_profiles"][col["name"]]
        lines.append("")
        lines.append(f"## {col['name']} Values")
        lines.append("")
        lines.append("| Value | Count |")
        lines.append("|-------|-------|")
        for v in profile["top_values"][:20]:
            val_str = "`NULL`" if v["value"] is None else f"`{v['value']}`"
            lines.append(f"| {val_str} | {v['count']:,} |")

    # Querying guidance
    lines.append("")
    lines.append("## Querying Guidance")
    lines.append("")
    idx = 1
    if not info["has_shard_hint"] and info.get("primary_timestamp"):
        lines.append(f"{idx}. **No `shard_hint`** — use `{info['primary_timestamp']}` for partition pruning")
        idx += 1
    lines.append(f"{idx}. **Always add LIMIT** — {rc_str} rows")
    idx += 1

    for dq in info.get("data_quality_issues", []):
        lines.append(f"{idx}. **{dq['name']}** — {dq['description']} Fix: `{dq['fix']}`")
        idx += 1

    for csj in info.get("cross_schema_joins", []):
        lines.append(f"{idx}. **Cross-schema join key**: `{csj['column']}` links to `{csj['join_key']}` in other schemas")
        idx += 1

    lines.append("")
    lines.append("## Example Queries")
    lines.append("")
    ts = info.get("primary_timestamp", "timestamp_col")
    lines.append("### TODO: Add example queries")
    lines.append("")
    lines.append("```sql")
    lines.append(f"SELECT *")
    lines.append(f"FROM {full_ref}")
    lines.append(f"WHERE {ts} >= current_date - interval '7' day")
    lines.append(f"LIMIT 20")
    lines.append("```")
    lines.append("")

    md_content = "\n".join(lines) + "\n"

    with open(md_path, "w", encoding="utf-8") as f:
        f.write(md_content)

    print(f"  MD written: {md_path} ({len(md_content)} chars)")
    return md_path


# ─── Step 4: Update graph_rag_index.json ──────────────────────────────────────

def update_graph_rag_json(info):
    """Update graph_rag_index.json with new entities, relationships, and query paths."""
    print(f"\n  Updating {GRAPH_RAG_JSON}...")

    with open(GRAPH_RAG_JSON, "r", encoding="utf-8") as f:
        d = json.load(f)

    # Check if table already exists
    existing = [e for e in d["entities"] if e.get("type") == "TABLE"
                and e.get("properties", {}).get("full_reference") == info["full_reference"]]
    if existing:
        print(f"  WARNING: Table {info['full_reference']} already exists in graph_rag_index.json (entity_id={existing[0]['entity_id']})")
        print(f"  Skipping graph_rag_index.json update. Use --force to override (not implemented yet).")
        return None, None, None

    # Find max entity ID
    max_eid = max(int(e["entity_id"][1:]) for e in d["entities"])
    max_rid = max(int(r["relationship_id"][1:]) for r in d["relationships"])

    new_entities = []
    new_rels = []

    # 4a. TABLE entity
    table_eid = f"E{max_eid + 1:04d}"
    ts_profile = info["column_profiles"].get(info["primary_timestamp"], {}) if info.get("primary_timestamp") else {}

    table_props = {
        "full_reference": info["full_reference"],
        "schema": f"{info['catalog']}.{info['schema']}",
        "row_count": info.get("row_count"),
        "column_count": len(info["columns"]),
        "pk": "unknown",
        "source_connector": "Trino",
        "date_range_min": str(ts_profile.get("min_value", "")),
        "date_range_max": str(ts_profile.get("max_value", "")),
        "read_host": "10.10.116.39",
        "write_allowed": False,
        "warning": f"{'Large table' if info.get('row_count') and info['row_count'] > 1000000 else 'Table'} (~{info.get('row_count', '?'):,} rows).",
    }

    # Add cross-schema join keys to properties
    if info.get("cross_schema_joins"):
        table_props["cross_schema_join_keys"] = {
            csj["column"]: csj["description"] for csj in info["cross_schema_joins"]
        }

    search_text = build_entity_search_text(info, "TABLE")

    new_entities.append({
        "entity_id": table_eid,
        "type": "TABLE",
        "name": info["table"],
        "description": f"TODO: Auto-discovered table. {info['full_reference']}. {len(info['columns'])} columns, ~{info.get('row_count', '?'):,} rows.",
        "properties": table_props,
        "search_text": search_text,
    })

    # 4b. JOIN_KEY entities (for cross-schema keys not already in the graph)
    existing_join_keys = {e["name"] for e in d["entities"] if e.get("type") == "JOIN_KEY"}
    eid_counter = max_eid + 2

    csj_entity_map = {}  # join_key_name -> entity_id
    for csj in info.get("cross_schema_joins", []):
        jk_name = csj["join_key"]
        if jk_name not in existing_join_keys and jk_name not in csj_entity_map:
            jk_eid = f"E{eid_counter:04d}"
            csj_entity_map[jk_name] = jk_eid
            eid_counter += 1
            new_entities.append({
                "entity_id": jk_eid,
                "type": "JOIN_KEY",
                "name": jk_name,
                "description": csj["description"],
                "properties": {
                    "format": csj["format"],
                    "schemas": [f"{info['catalog']}.{info['schema']}"],
                },
                "search_text": f"{jk_name} {csj['description']} Format: {csj['format']}. Cross-schema join key.",
            })
        elif jk_name in existing_join_keys:
            # Find existing entity ID
            for e in d["entities"]:
                if e.get("type") == "JOIN_KEY" and e["name"] == jk_name:
                    csj_entity_map[jk_name] = e["entity_id"]
                    break

    # 4c. CONCEPT entity for the table
    concept_eid = f"E{eid_counter:04d}"
    eid_counter += 1
    new_entities.append({
        "entity_id": concept_eid,
        "type": "CONCEPT",
        "name": f"{info['table'].title().replace('_', ' ')}",
        "description": f"Concept covering {info['table']} — {info['full_reference']}.",
        "properties": {"tables": [info["table"]]},
        "search_text": f"{info['table']} {info['full_reference']} concept",
    })

    # 4d. DATA_QUALITY_ISSUE entities
    dq_eids = []
    for dq in info.get("data_quality_issues", []):
        dq_eid = f"E{eid_counter:04d}"
        eid_counter += 1
        dq_eids.append((dq, dq_eid))
        new_entities.append({
            "entity_id": dq_eid,
            "type": "DATA_QUALITY_ISSUE",
            "name": dq["name"],
            "description": dq["description"],
            "properties": {
                "tables": [info["table"]],
                "columns": [dq["column"]],
                "fix": dq["fix"],
            },
            "search_text": f"{dq['name']} {dq['description']} Fix: {dq['fix']}",
        })

    # 4e. Relationships
    rid_counter = max_rid + 1

    # HAS_COLUMN for each cross-schema join key column
    for csj in info.get("cross_schema_joins", []):
        jk_eid = csj_entity_map.get(csj["join_key"])
        if jk_eid:
            new_rels.append({
                "relationship_id": f"R{rid_counter:04d}",
                "type": "HAS_COLUMN",
                "source": table_eid,
                "target": jk_eid,
                "properties": {"column_name": csj["column"]},
            })
            rid_counter += 1

    # JOIN_KEY_IN_TABLE (link join key to existing tables that have the same key)
    for csj in info.get("cross_schema_joins", []):
        jk_eid = csj_entity_map.get(csj["join_key"])
        if jk_eid:
            # Find existing TABLE entities that have this join key
            for e in d["entities"]:
                if e.get("type") == "TABLE" and e["entity_id"] != table_eid:
                    # Check if this table already has a HAS_COLUMN rel to this join key
                    existing_rel = any(
                        r.get("type") == "HAS_COLUMN"
                        and r.get("source") == e["entity_id"]
                        and r.get("target") == jk_eid
                        for r in d["relationships"]
                    )
                    if existing_rel:
                        # Add a cross-schema JOINS_TO relationship
                        new_rels.append({
                            "relationship_id": f"R{rid_counter:04d}",
                            "type": "JOINS_TO",
                            "source": table_eid,
                            "target": e["entity_id"],
                            "properties": {
                                "from_table": info["table"],
                                "to_table": e["name"],
                                "join_keys": [f"{csj['column']} ↔ {csj['column']}"],
                                "cardinality": "N:N",
                                "cross_schema": True,
                                "semantic": f"Cross-schema join via {csj['join_key']}",
                            },
                        })
                        rid_counter += 1

    # AFFECTS_TABLE for data quality issues
    for dq, dq_eid in dq_eids:
        new_rels.append({
            "relationship_id": f"R{rid_counter:04d}",
            "type": "AFFECTS_TABLE",
            "source": dq_eid,
            "target": table_eid,
            "properties": {"issue": dq["name"]},
        })
        rid_counter += 1

    # SEMANTICALLY_LINKED for concept
    new_rels.append({
        "relationship_id": f"R{rid_counter:04d}",
        "type": "SEMANTICALLY_LINKED",
        "source": concept_eid,
        "target": table_eid,
        "properties": {"concept": concept_eid, "note": f"{info['table']} is the primary table for this concept"},
    })
    rid_counter += 1

    # 4f. Query paths
    new_qps = [{
        "need": f"Query {info['table']}",
        "start": info["table"],
        "joins": [],
        "filter": info["primary_timestamp"] if info.get("primary_timestamp") else "TODO",
        "note": f"{'No shard_hint. Use ' + info['primary_timestamp'] + ' for partition pruning.' if not info['has_shard_hint'] and info.get('primary_timestamp') else 'Use shard_hint for partition pruning.'}",
    }]

    # Add to JSON
    d["entities"].extend(new_entities)
    d["relationships"].extend(new_rels)
    if "query_paths" not in d:
        d["query_paths"] = []
    d["query_paths"].extend(new_qps)

    # Update metadata
    from collections import Counter
    d["metadata"]["total_entities"] = len(d["entities"])
    d["metadata"]["total_relationships"] = len(d["relationships"])
    d["metadata"]["total_text_units"] = len(d.get("text_units", []))
    d["metadata"]["entity_type_counts"] = dict(Counter(e.get("type", "?") for e in d["entities"]))
    d["metadata"]["relationship_type_counts"] = dict(Counter(r.get("type", "?") for r in d["relationships"]))
    d["metadata"]["total_tables"] = sum(1 for e in d["entities"] if e.get("type") == "TABLE")

    with open(GRAPH_RAG_JSON, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2, ensure_ascii=False)

    print(f"  Added {len(new_entities)} entities, {len(new_rels)} relationships, {len(new_qps)} query paths")
    print(f"  Table entity: {table_eid}")
    return new_entities, new_rels, new_qps


def build_entity_search_text(info, entity_type):
    """Build rich search_text for an entity (similar to existing entities)."""
    parts = [info["table"], info["full_reference"]]

    if entity_type == "TABLE":
        parts.append(f"approximately {info.get('row_count', '?')} rows")
        parts.append(f"{len(info['columns'])} columns")
        if info.get("primary_timestamp"):
            ts_profile = info["column_profiles"].get(info["primary_timestamp"], {})
            parts.append(f"Primary timestamp: {info['primary_timestamp']}")
            if ts_profile.get("min_value"):
                parts.append(f"Date range: {ts_profile['min_value']} to {ts_profile.get('max_value')}")

        for csj in info.get("cross_schema_joins", []):
            parts.append(f"Cross-schema join key: {csj['column']} ({csj['join_key']})")

    return " ".join(parts)


# ─── Step 5: Update knowledge_graph.yaml ──────────────────────────────────────

def update_knowledge_graph_yaml(info):
    """Update knowledge_graph.yaml with new table node."""
    print(f"\n  Updating {KNOWLEDGE_GRAPH_YAML}...")

    with open(KNOWLEDGE_GRAPH_YAML, "r", encoding="utf-8") as f:
        content = f.read()

    # Check if table already exists
    if f"id: {info['table']}" in content:
        print(f"  WARNING: Table {info['table']} already exists in knowledge_graph.yaml. Skipping.")
        return False

    # Build table node YAML
    ts_profile = info["column_profiles"].get(info["primary_timestamp"], {}) if info.get("primary_timestamp") else {}

    table_node = f"""
  # ─── {info['catalog']}.{info['schema']}.{info['table']} (auto-added) ──────────────────────

  - id: {info['table']}
    full_reference: {info['full_reference']}
    schema: {info['catalog']}.{info['schema']}
    type: event_stream  # TODO: Review — could be 'current', 'history', 'reference', etc.
    category: todo  # TODO: Set category
    description: "TODO: Write description"
    row_count: {info.get('row_count', 'unknown')}
    column_count: {len(info['columns'])}
    pk: unknown  # TODO: Identify primary key
    join_keys:"""

    if info.get("cross_schema_joins"):
        table_node += "\n      cross_schema:"
        for csj in info["cross_schema_joins"]:
            table_node += f"\n        {csj['column']}: \"{csj['description']}\""
    if not info["has_shard_hint"]:
        table_node += "\n      no_shard_hint: true"
    else:
        table_node += "\n      partition: shard_hint"

    if info.get("primary_timestamp"):
        table_node += f"""
    date_range:
      column: {info['primary_timestamp']}
      min: "{ts_profile.get('min_value', 'unknown')}"
      max: "{ts_profile.get('max_value', 'unknown')}" """

    table_node += f"""
    context_files:
      md: {info['full_reference']}.md
      yaml: {info['full_reference']}.yaml
    importance: Medium  # TODO: Review
    warning: "{'Large table' if info.get('row_count') and info['row_count'] > 1000000 else 'Table'} (~{info.get('row_count', '?'):,} rows).{' No shard_hint — use ' + info['primary_timestamp'] + ' for partition pruning.' if not info['has_shard_hint'] and info.get('primary_timestamp') else ''}"
"""

    # Insert before RELATIONSHIP EDGES section
    marker = "# ─── RELATIONSHIP EDGES"
    if marker in content:
        content = content.replace(marker, table_node + "\n" + marker)
    else:
        content += "\n" + table_node

    with open(KNOWLEDGE_GRAPH_YAML, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"  Added table node for {info['table']}")
    return True


# ─── Step 6: Update skill file ────────────────────────────────────────────────

def update_skill_file(info):
    """Update text-to-sql.md skill file with new table section."""
    print(f"\n  Updating {SKILL_FILE}...")

    with open(SKILL_FILE, "r", encoding="utf-8") as f:
        content = f.read()

    # Check if table already exists
    if info["full_reference"] in content:
        print(f"  WARNING: Table {info['full_reference']} already in skill file. Skipping.")
        return False

    # 6a. Update frontmatter description (table/column counts)
    # Find current counts in description
    desc_match = re.search(r"Covers the (.+?) schema \((\d+) tables?, (\d+) columns?\)", content)
    if desc_match:
        # This is complex — just append a note for now
        print(f"  NOTE: Please manually update frontmatter description to include new table/column counts.")

    # 6b. Build table section
    ts = info.get("primary_timestamp", "timestamp_col")
    rc = info.get("row_count", "?")

    section = f"""
### `{info['catalog']}.{info['schema']}.{info['table']}`

<!-- Auto-added by add_table.py. REVIEW AND EDIT. -->

**~{rc:,} rows, {len(info['columns'])} columns** — TODO: Write description

| Property | Value |
|----------|-------|
| **Full Reference** | `{info['full_reference']}` |
| **Row Count** | ~{rc:,} |
| **Columns** | {len(info['columns'])} |
| **Primary Timestamp** | `{ts}` |
| **Has shard_hint** | {info['has_shard_hint']} |

#### Column Dictionary

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
"""
    for col in info["columns"]:
        profile = info["column_profiles"].get(col["name"], {})
        notes = ""
        if profile.get("null_percent") == 100:
            notes = "~100% NULL (deprecated)"
        elif profile.get("null_percent", 0) > 0:
            notes = f"NULL ~{profile['null_percent']}%"
        else:
            notes = "Always populated"

        if profile.get("is_categorical") and profile.get("top_values"):
            top = profile["top_values"][:3]
            vals = ", ".join(f"`{v['value']}`" if v['value'] is not None else "`NULL`" for v in top)
            notes += f". Top: {vals}"

        for csj in info.get("cross_schema_joins", []):
            if csj["column"] == col["name"]:
                notes += f". **Cross-schema join key: {csj['join_key']}**"
                break

        section += f"| `{col['name']}` | {col['type']} | TODO | {notes} |\n"

    # Add querying guidance
    section += f"\n#### Querying Guidance\n\n"
    section += f"- {'No `shard_hint` — use `' + ts + '` for partition pruning' if not info['has_shard_hint'] else 'Use `shard_hint` for partition pruning'}\n"
    section += f"- Always add LIMIT — ~{rc:,} rows\n"
    for dq in info.get("data_quality_issues", []):
        section += f"- **{dq['name']}**: {dq['description']}. Fix: `{dq['fix']}`\n"
    for csj in info.get("cross_schema_joins", []):
        section += f"- Cross-schema join key: `{csj['column']}` → `{csj['join_key']}`\n"

    # Add example query
    section += f"""
#### Example Query

```sql
SELECT *
FROM {info['full_reference']}
WHERE {ts} >= current_date - interval '7' day
LIMIT 20
```

"""

    # Insert section — find the right place based on schema
    # Try to find an existing schema section or the "## Value Tables" / "## Synonym Map" marker
    insert_marker = "## Value Tables"
    if insert_marker in content:
        content = content.replace(insert_marker, section + insert_marker)
    else:
        # Fall back to inserting before "## 9 Hard SQL Rules"
        insert_marker = "## 9 Hard SQL Rules"
        if insert_marker in content:
            content = content.replace(insert_marker, section + insert_marker)
        else:
            content += section

    with open(SKILL_FILE, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"  Added table section for {info['table']}")
    print(f"  NOTE: Please review and edit the auto-generated section.")
    return True


# ─── Step 7: Update relationship.md ───────────────────────────────────────────

def update_relationship_md(info):
    """Update relationship.md with new table in catalogue, navigation, and changelog."""
    print(f"\n  Updating {RELATIONSHIP_MD}...")

    with open(RELATIONSHIP_MD, "r", encoding="utf-8") as f:
        content = f.read()

    if info["full_reference"] in content:
        print(f"  WARNING: Table {info['full_reference']} already in relationship.md. Skipping.")
        return False

    # 7a. Add to Tables Catalogued
    # Find the last row in the table
    catalogued_marker = "## Tables Catalogued"
    if catalogued_marker in content:
        # Find the last table row (| N | ...)
        rows = re.findall(r"^\| (\d+) \|.*\|\s*$", content, re.MULTILINE)
        next_num = max(int(r) for r in rows) + 1 if rows else 1

        new_row = (f"| {next_num} | `{info['full_reference']}` | TODO: type | "
                   f"~{info.get('row_count', '?'):,} | {len(info['columns'])} | "
                   f"[md](./{info['full_reference']}.md) | [yaml](./{info['full_reference']}.yaml) |\n")

        # Insert after the last row
        last_row_match = list(re.finditer(r"^\| \d+ \|.*\|\s*$", content, re.MULTILINE))
        if last_row_match:
            pos = last_row_match[-1].end()
            content = content[:pos] + "\n" + new_row + content[pos:]

    # 7b. Add changelog entry
    today = datetime.now().strftime("%Y-%m-%d")
    changelog_entry = f"| {today} | Added `{info['full_reference']}` ({info.get('row_count', '?'):,} rows, {len(info['columns'])} cols) via add_table.py. TODO: Add description. |"

    # Find changelog table and insert after header
    changelog_marker = "| Date | Change |"
    if changelog_marker in content:
        # Find the second occurrence (header + separator)
        pos = content.find(changelog_marker)
        pos = content.find("\n", pos)  # end of header line
        pos = content.find("\n", pos + 1)  # end of separator line
        content = content[:pos + 1] + changelog_entry + "\n" + content[pos + 1:]

    with open(RELATIONSHIP_MD, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"  Added table to catalogue (row {next_num}) and changelog")
    print(f"  NOTE: Please add navigation guide items and relationship sections manually if needed.")
    return True


# ─── Step 8: Migrate PostgreSQL ───────────────────────────────────────────────

def migrate_postgres(new_entities, new_rels, new_qps):
    """Generate and execute incremental migration SQL against PostgreSQL."""
    if not new_entities:
        print(f"\n  Skipping PostgreSQL migration (no new entities)")
        return False

    print(f"\n  Generating incremental migration SQL...")

    def sql_escape(s):
        if s is None:
            return "NULL"
        return "'" + str(s).replace("'", "''") + "'"

    def jsonb_escape(obj):
        return sql_escape(json.dumps(obj, ensure_ascii=False))

    sql_lines = []
    sql_lines.append("-- Incremental migration (auto-generated by add_table.py)")
    sql_lines.append(f"-- Generated: {datetime.now().isoformat()}")
    sql_lines.append("BEGIN;")
    sql_lines.append("")

    # Entities
    sql_lines.append(f"-- === NEW ENTITIES ({len(new_entities)}) ===")
    for e in new_entities:
        search_text = e.get("search_text", "")
        sql_lines.append(
            f"INSERT INTO entities (entity_id, name, type, description, properties, search_text) VALUES "
            f"({sql_escape(e['entity_id'])}, {sql_escape(e['name'])}, {sql_escape(e['type'])}, "
            f"{sql_escape(e.get('description', ''))}, {jsonb_escape(e.get('properties', {}))}::jsonb, "
            f"{sql_escape(search_text)});"
        )

    # Relationships
    sql_lines.append("")
    sql_lines.append(f"-- === NEW RELATIONSHIPS ({len(new_rels)}) ===")
    for r in new_rels:
        props = r.get("properties", {})
        desc = props.get("semantic", "") or props.get("note", "")
        sql_lines.append(
            f"INSERT INTO relationships (source_id, target_id, type, description, properties) VALUES "
            f"({sql_escape(r['source'])}, {sql_escape(r['target'])}, {sql_escape(r['type'])}, "
            f"{sql_escape(desc)}, {jsonb_escape(props)}::jsonb);"
        )

    # Query paths
    sql_lines.append("")
    sql_lines.append(f"-- === NEW QUERY PATHS ({len(new_qps)}) ===")
    for qp in new_qps:
        sql_lines.append(
            f"INSERT INTO query_paths (start_table, need, joins) VALUES "
            f"({sql_escape(qp.get('start', ''))}, {sql_escape(qp.get('need', ''))}, "
            f"{jsonb_escape(qp.get('joins', []))}::jsonb);"
        )

    sql_lines.append("")
    sql_lines.append("COMMIT;")
    sql_lines.append("")
    sql_lines.append("-- Verification:")
    sql_lines.append("SELECT 'entities' AS t, count(*) FROM entities UNION ALL SELECT 'relationships', count(*) FROM relationships UNION ALL SELECT 'query_paths', count(*) FROM query_paths;")
    sql_lines.append("SELECT type, count(*) FROM entities GROUP BY type ORDER BY count(*) DESC;")

    sql_content = "\n".join(sql_lines)

    # Save SQL file
    sql_path = os.path.join(CONTEXT_DIR, "postgres", "migrate_incremental.sql")
    with open(sql_path, "w", encoding="utf-8") as f:
        f.write(sql_content)
    print(f"  SQL written: {sql_path}")

    # Execute via docker exec
    print(f"  Executing against {PG_CONTAINER}...")
    try:
        result = subprocess.run(
            ["docker", "exec", "-i", PG_CONTAINER, "psql", "-U", PG_USER, "-d", PG_DB],
            input=sql_content.encode("utf-8"),
            capture_output=True,
            timeout=60
        )
        stdout = result.stdout.decode("utf-8", errors="replace")
        stderr = result.stderr.decode("utf-8", errors="replace")

        if result.returncode == 0:
            print(f"  Migration successful!")
            print(f"  {stdout[-500:]}")  # Last 500 chars (verification output)
        else:
            print(f"  Migration FAILED!")
            print(f"  stderr: {stderr}")
            return False
    except Exception as e:
        print(f"  ERROR: {e}")
        return False

    return True


# ─── Step 9: Verify Retrieval ─────────────────────────────────────────────────

def verify_retrieval(info):
    """Run retrieval tests against PostgreSQL to confirm the new table is findable."""
    print(f"\n  Running retrieval tests...")

    # Build test queries based on table name and column names
    test_queries = [
        info["table"].replace("_", " "),
        info["full_reference"],
    ]

    # Add queries based on column names
    for col in info["columns"][:5]:
        test_queries.append(col["name"].replace("_", " "))

    # Add queries based on cross-schema join keys
    for csj in info.get("cross_schema_joins", []):
        test_queries.append(csj["join_key"].replace("_", " "))

    passed = 0
    failed = 0

    for query in test_queries:
        sql = f"SELECT entity_id, name, type FROM entities WHERE tsv @@ plainto_tsquery('english', '{query.replace(chr(39), chr(39)+chr(39))}') AND type='TABLE' ORDER BY ts_rank(tsv, plainto_tsquery('english', '{query.replace(chr(39), chr(39)+chr(39))}')) DESC LIMIT 3;"

        try:
            result = subprocess.run(
                ["docker", "exec", PG_CONTAINER, "psql", "-U", PG_USER, "-d", PG_DB, "-t", "-A", "-c", sql],
                capture_output=True, timeout=15
            )
            output = result.stdout.decode("utf-8", errors="replace").strip()
            rows = [r for r in output.split("\n") if r.strip() and "|" in r]

            found = any(info["table"] in r for r in rows)
            status = "[PASS]" if found else "[FAIL]"
            if found:
                passed += 1
            else:
                failed += 1

            top = rows[0].split("|")[1] if rows and "|" in rows[0] else "(none)"
            print(f"    {status} '{query}' -> top: {top}")
        except Exception as e:
            print(f"    [ERROR] '{query}': {e}")
            failed += 1

    print(f"\n  Results: {passed} passed, {failed} failed")
    return passed, failed


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Add a new Trino table to the text-to-SQL knowledge base.",
        usage="python add_table.py <catalog>.<schema>.<table> [options]"
    )
    parser.add_argument("table_ref", help="Full table reference: catalog.schema.table")
    parser.add_argument("--dry-run", action="store_true", help="Generate to temp, don't update real files")
    parser.add_argument("--skip-trino", action="store_true", help="Skip Trino discovery")
    parser.add_argument("--data-file", help="Load discovery data from JSON file")
    parser.add_argument("--skip-postgres", action="store_true", help="Skip PostgreSQL migration")
    parser.add_argument("--skip-skill", action="store_true", help="Skip skill file update")
    parser.add_argument("--skip-relationship", action="store_true", help="Skip relationship.md update")

    args = parser.parse_args()

    # Parse table reference
    parts = args.table_ref.split(".")
    if len(parts) != 3:
        print(f"ERROR: Table reference must be catalog.schema.table (got: {args.table_ref})")
        sys.exit(1)

    catalog, schema, table = parts
    print(f"\n{'='*70}")
    print(f"add_table.py — Adding {catalog}.{schema}.{table}")
    print(f"{'='*70}")
    print(f"  Dry run: {args.dry_run}")
    print(f"  Skip Trino: {args.skip_trino}")
    print(f"  Skip PostgreSQL: {args.skip_postgres}")

    output_dir = CONTEXT_DIR
    if args.dry_run:
        output_dir = os.path.join(os.environ.get("TEMP", "/tmp"), "opencode", "add_table_dry_run")
        os.makedirs(output_dir, exist_ok=True)
        print(f"  Output dir: {output_dir}")

    # Step 1: Discover
    if args.skip_trino and args.data_file:
        print(f"\n  Loading discovery data from {args.data_file}...")
        with open(args.data_file, "r") as f:
            info = json.load(f)
    elif args.skip_trino:
        print(f"\n  ERROR: --skip-trino requires --data-file")
        sys.exit(1)
    else:
        info = discover_table(catalog, schema, table)

    # Save discovery data
    discovery_path = os.path.join(output_dir, f"{info['full_reference']}.discovery.json")
    with open(discovery_path, "w", encoding="utf-8") as f:
        json.dump(info, f, indent=2, ensure_ascii=False, default=str)
    print(f"\n  Discovery data saved: {discovery_path}")

    # Step 2: Generate YAML
    print(f"\n{'='*70}")
    print(f"Step 2: Generate YAML documentation")
    print(f"{'='*70}")
    yaml_path = generate_yaml(info, output_dir)

    # Step 3: Generate MD
    print(f"\n{'='*70}")
    print(f"Step 3: Generate MD documentation")
    print(f"{'='*70}")
    md_path = generate_md(info, output_dir)

    if args.dry_run:
        print(f"\n{'='*70}")
        print(f"DRY RUN — Files generated to {output_dir}")
        print(f"  YAML: {yaml_path}")
        print(f"  MD: {md_path}")
        print(f"  Discovery: {discovery_path}")
        print(f"  Review these files, then run without --dry-run to update all files.")
        print(f"{'='*70}")
        return

    # Step 4: Update graph_rag_index.json
    print(f"\n{'='*70}")
    print(f"Step 4: Update graph_rag_index.json")
    print(f"{'='*70}")
    new_entities, new_rels, new_qps = update_graph_rag_json(info)

    # Step 5: Update knowledge_graph.yaml
    print(f"\n{'='*70}")
    print(f"Step 5: Update knowledge_graph.yaml")
    print(f"{'='*70}")
    update_knowledge_graph_yaml(info)

    # Step 6: Update skill file
    if not args.skip_skill:
        print(f"\n{'='*70}")
        print(f"Step 6: Update text-to-sql.md skill file")
        print(f"{'='*70}")
        update_skill_file(info)
    else:
        print(f"\n  Skipping skill file update (--skip-skill)")

    # Step 7: Update relationship.md
    if not args.skip_relationship:
        print(f"\n{'='*70}")
        print(f"Step 7: Update relationship.md")
        print(f"{'='*70}")
        update_relationship_md(info)
    else:
        print(f"\n  Skipping relationship.md update (--skip-relationship)")

    # Step 8: Migrate PostgreSQL
    if not args.skip_postgres and new_entities:
        print(f"\n{'='*70}")
        print(f"Step 8: Migrate PostgreSQL")
        print(f"{'='*70}")
        migrate_postgres(new_entities, new_rels, new_qps)
    else:
        print(f"\n  Skipping PostgreSQL migration")

    # Step 9: Verify retrieval
    if not args.skip_postgres and new_entities:
        print(f"\n{'='*70}")
        print(f"Step 9: Verify retrieval")
        print(f"{'='*70}")
        verify_retrieval(info)

    # Summary
    print(f"\n{'='*70}")
    print(f"SUMMARY")
    print(f"{'='*70}")
    print(f"  Table: {info['full_reference']}")
    print(f"  Rows:  {info.get('row_count', '?'):,}")
    print(f"  Cols:  {len(info['columns'])}")
    print(f"  Cross-schema joins: {len(info.get('cross_schema_joins', []))}")
    for csj in info.get("cross_schema_joins", []):
        print(f"    - {csj['column']} -> {csj['join_key']}")
    print(f"  Data quality issues: {len(info.get('data_quality_issues', []))}")
    for dq in info.get("data_quality_issues", []):
        print(f"    - {dq['name']}")
    print(f"  Primary timestamp: {info.get('primary_timestamp', 'none')}")
    print(f"  Has shard_hint: {info['has_shard_hint']}")
    print(f"")
    print(f"  Files created/updated:")
    print(f"    {yaml_path}")
    print(f"    {md_path}")
    print(f"    {GRAPH_RAG_JSON}")
    print(f"    {KNOWLEDGE_GRAPH_YAML}")
    if not args.skip_skill:
        print(f"    {SKILL_FILE}")
    if not args.skip_relationship:
        print(f"    {RELATIONSHIP_MD}")
    print(f"    {discovery_path}")
    print(f"")
    print(f"  TODO (manual review needed):")
    print(f"    1. Edit YAML: fill in descriptions, notes, querying guidance")
    print(f"    2. Edit MD: fill in description, example queries")
    print(f"    3. Edit skill file: update frontmatter counts, add synonyms, add value tables")
    print(f"    4. Edit relationship.md: add navigation guide items, relationship sections")
    print(f"    5. Test with a natural-language question")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
