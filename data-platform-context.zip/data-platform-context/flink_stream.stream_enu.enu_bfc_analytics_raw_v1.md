# Table: flink_stream.stream_enu.enu_bfc_analytics_raw_v1

## Overview

| Property | Value |
|----------|-------|
| **Catalog** | `flink_stream` |
| **Schema** | `stream_enu` |
| **Table** | `enu_bfc_analytics_raw_v1` |
| **Full Reference** | `flink_stream.stream_enu.enu_bfc_analytics_raw_v1` |
| **Row Count** | ~79M (78,908,636) |
| **Columns** | 30 |
| **Date Range** | 2026-03-09 → present (near-real-time) |
| **Source** | Flink streaming pipeline |
| **Access** | Read-only via Trino at `10.10.116.39:8080` |

## Description

**Biometric Fraud Check (BFC)** analytics raw table. Each row represents a biometric capture evaluation event — the BFC system runs ML models on captured biometrics (FACE, FINGER, IRIS) to detect fraud or anomalies.

**Two main model types:**
1. **AGE_VERIFICATION** (96% of rows) — Face age prediction model. Predicts the person's age from their face image. Result in `modelprediction` (decimal age string).
2. **UNSYSTEMATIC_MANUAL_CHECK** (4.3%) — Detects non-standard/anomalous biometric captures (finger swaps, flips, partial captures, photo-on-photo, etc.). Confidence in `modelscore`. Anomaly type in `errorreasoncode`.

## Column Dictionary (30 columns)

### Event Identity

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `eventid` | varchar | Event UUID | Always populated. Primary key |
| `eventname` | varchar | Event name | Always `bfc_biometric_capture_evaluated` |
| `eventtype` | varchar | Event type | Always `BFC-BI-EVENT` |
| `eventtimestamp` | timestamp(6) | Event time | **Primary filter column**. 2026-03 → present |
| `version` | varchar | Schema version | Always `2.0` |

### Source / Environment

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `sourceservice` | varchar | Source service | `enu-biofraud-check` (71%), NULL (29%) |
| `environment` | varchar | Environment | Always `PROD` |
| `dc` | varchar | Data center | Always `MDC` |

### Session / Capture

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `sid` | varchar | Session ID | Always populated. Links to telemetry_uc.sid |
| `refid` | varchar | Reference ID | NULL ~95% (only UNSYSTEMATIC events) |
| `modality` | varchar | Biometric modality | `FACE` (96%), `FINGER` (3.4%), `IRIS` (0.7%) |
| `subtype` | varchar | Capture subtype | NULL ~95%. `RIGHT_SLAP`, `LEFT_SLAP`, `RIGHT_IRIS`, `LEFT_IRIS` |
| `captureindex` | integer | Capture attempt (0-based) | 0=first (96%), 1=second (3.6%), 2+=retries |
| `analysistype` | varchar | Analysis type | NULL ~96%. `UNSYSTEMATIC_FINGER_CAPTURE_CHECK` etc. |

### Model Results

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `modelname` | varchar | ML model name | `AGE_VERIFICATION` (96%), `UNSYSTEMATIC_MANUAL_CHECK` (4.3%) |
| `modelprediction` | varchar | Model prediction | Age string for AGE_VERIFICATION (e.g. `26.25`). Use `TRY_CAST AS double` |
| `modelscore` | double | Model confidence | NULL ~96% (only UNSYSTEMATIC models). Range 0–3.0 |
| `modelscorebucket` | double | Score bucket | ⚠️ **Entirely NULL** (deprecated) |
| `modelthresholdbucket` | varchar | Threshold bucket | ⚠️ **Entirely NULL** (deprecated) |
| `modelpredictionobjectcount` | varchar | Object count | ⚠️ **Entirely NULL** (deprecated) |

### Operator / Comparison

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `operatorprediction` | varchar | Operator's assessment | NULL ~95%. `GENUINE` (3.3M), age ranges, `UNSYSTEMATIC` |
| `ispredictionmatched` | boolean | Model vs operator match | NULL ~95%. `false` (3.5M), `true` (129K) |

### Error / Anomaly

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `haserror` | boolean | Error occurred? | `false` (99.9%), `true` (0.1%, 80K) |
| `errorcategory` | varchar | Error category | NULL ~99.9%. ⚠️ Data quality issue — age ranges leaked in |
| `errorreasoncode` | varchar | Error reason | NULL ~99.9%. `SWAP`, `INCORRECT`, `FLIPPED`, etc. |

### Latency (deprecated)

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `modelcalllatencybucketms` | varchar | Model latency | ⚠️ **Entirely NULL** (deprecated) |
| `mfclatencybuckethrs` | varchar | MFC latency | ⚠️ **Entirely NULL** (deprecated) |

### Operator / Machine

| Column | Type | Description | Notes |
|--------|------|-------------|-------|
| `operatorid` | varchar | Operator login ID | ~100% populated. Matches enu_uc_opt_action_v2.operator_id |
| `machinecode` | varchar | Machine/device ID | ~100% populated. Matches telemetry_uc.pdata_id |

## modality Values

| Value | Count | % | Meaning |
|-------|-------|---|---------|
| `FACE` | 76M | 95.8% | Face biometric capture |
| `FINGER` | 2.7M | 3.4% | Fingerprint capture |
| `IRIS` | 555K | 0.7% | Iris scan capture |

## modelname Values

| Value | Count | % | modelscore | modelprediction |
|-------|-------|---|------------|-----------------|
| `AGE_VERIFICATION` | 76M | 95.7% | NULL | Predicted age (decimal string, e.g. `26.25`) |
| `UNSYSTEMATIC_MANUAL_CHECK` | 3.4M | 4.3% | Confidence 0–3.0 | `UNSYSTEMATIC` or category |
| `UNSYSTEMATIC_CHECK` | 13K | 0.02% | Very low (~0.0004) | Category |

## errorreasoncode Values (when haserror=true)

| Code | Count | Meaning |
|------|-------|---------|
| `SWAP` | 20K | Finger swap detected (wrong finger order) |
| `INCORRECT` | 14K | Incorrect capture |
| `UNSYSTEMATIC` | 12K | Unsystematic capture |
| `UNKNOWN_OBSERVATION` | 11K | Unknown anomaly |
| `FLIPPED` | 6K | Image flipped |
| `PARTIAL_CAPTURE` | 5.8K | Partial biometric capture |
| `POOR_QUALITY` | 2.8K | Poor image quality |
| `OUT_OF_FOCUS` | 1.5K | Out of focus |
| `BLURRED_IMAGE` | 1.4K | Blurred image |
| `BLANK` | 1.4K | Blank image |
| `INVERTED` | 1.3K | Image inverted |
| `MIXED` | 624 | Mixed capture types |
| `PHOTO_ON_PHOTO` | 498 | Photo-on-photo fraud |
| `MULTIPLE_CAPTURE` | 398 | Multiple captures |
| `FINGER_TIP` | 263 | Only fingertip |
| `NON_HUMAN` | 238 | Non-human biometric |
| `TOE_PRINT` | 220 | Toe print instead of finger |
| `VALID` | 159 | Marked valid (false positive) |
| `PHALANX` | 25 | Phalanx bone visible |

## ⚠️ Data Quality Issues

| Issue | Column(s) | Rule |
|-------|-----------|------|
| **5 entirely NULL columns** | `modelthresholdbucket`, `modelscorebucket`, `modelpredictionobjectcount`, `modelcalllatencybucketms`, `mfclatencybuckethrs` | Deprecated/unpopulated — do not rely on them |
| **modelprediction is varchar** | `modelprediction` | Contains decimal age strings. Use `TRY_CAST(modelprediction AS double)` — NOT `CAST()` which throws on non-numeric values |
| **modelscore NULL for AGE_VERIFICATION** | `modelscore` | NULL ~96%. Only populated for UNSYSTEMATIC models. For AGE_VERIFICATION, the age IS the prediction in `modelprediction` |
| **errorcategory has leaked data** | `errorcategory` | Operator prediction age ranges (e.g. `0-1`, `10-20`) leaked into this column. Use `errorreasoncode` for clean error analysis |

## Querying Guidance

1. **No `shard_hint`** — use `eventtimestamp` for partition pruning
2. **Always add LIMIT** — 79M rows
3. **`modelprediction` is varchar** — use `TRY_CAST(modelprediction AS double)` for numeric comparisons
4. **`modelscore` is NULL ~96%** — only for UNSYSTEMATIC models, not AGE_VERIFICATION
5. **5 deprecated columns** — entirely NULL, do not use
6. **Use `errorreasoncode`** (not `errorcategory`) for error analysis — cleaner data
7. **`operatorid`** matches `operator_id` in `enu_uc_opt_action_v2`
8. **`machinecode`** matches `pdata_id` in `telemetry_uc` and `machine_id` in `station_reg_helper`
9. **`sid`** links to `sid` in `telemetry_uc` for session correlation

## Example Queries

### Biometric anomalies by type (last 7 days)

```sql
SELECT errorreasoncode, modality, count(*) AS cnt
FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
WHERE eventtimestamp >= current_date - interval '7' day
  AND haserror = true
GROUP BY errorreasoncode, modality
ORDER BY cnt DESC
LIMIT 100
```

### Age prediction vs operator assessment (last 1 month)

```sql
SELECT
    modelname,
    count(*) AS total,
    count_if(ispredictionmatched = true) AS matched,
    count_if(ispredictionmatched = false) AS mismatched,
    round(count_if(ispredictionmatched = true) * 100.0 / count(*), 2) AS match_pct
FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
WHERE eventtimestamp >= current_date - interval '1' month
  AND operatorprediction IS NOT NULL
GROUP BY modelname
ORDER BY total DESC
LIMIT 100
```

### BFC events by modality and model (last 7 days)

```sql
SELECT modality, modelname, count(*) AS cnt
FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
WHERE eventtimestamp >= current_date - interval '7' day
GROUP BY modality, modelname
ORDER BY cnt DESC
LIMIT 100
```

### Error rate trend by day

```sql
SELECT
    date(eventtimestamp) AS event_date,
    count(*) AS total_events,
    count_if(haserror = true) AS errors,
    round(count_if(haserror = true) * 100.0 / count(*), 4) AS error_rate_pct
FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
WHERE eventtimestamp >= current_date - interval '30' day
GROUP BY date(eventtimestamp)
ORDER BY event_date DESC
LIMIT 100
```

### Average predicted age by operator (last 1 month)

```sql
SELECT
    operatorid,
    count(*) AS evaluations,
    round(avg(TRY_CAST(modelprediction AS double)), 2) AS avg_predicted_age
FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
WHERE eventtimestamp >= current_date - interval '1' month
  AND modelname = 'AGE_VERIFICATION'
GROUP BY operatorid
ORDER BY evaluations DESC
LIMIT 100
```

### Capture retry rate by modality

```sql
SELECT
    modality,
    count(*) AS total_captures,
    count_if(captureindex = 0) AS first_attempt,
    count_if(captureindex > 0) AS retries,
    round(count_if(captureindex > 0) * 100.0 / count(*), 2) AS retry_pct
FROM flink_stream.stream_enu.enu_bfc_analytics_raw_v1
WHERE eventtimestamp >= current_date - interval '7' day
GROUP BY modality
ORDER BY total_captures DESC
LIMIT 100
```
