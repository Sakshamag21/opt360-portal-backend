#!/usr/bin/env python3
"""
LLM Client for GLM-5.2-FP8 — direct API wrapper, no OpenCode dependency.

Model: glm-5.2-fp8 (reasoning model — thinks in 'reasoning' field, answers in 'content')
Endpoint: http://10.10.109.101:32320/glm52/v1 (OpenAI-compatible, served by vLLM)
Max context: 524,288 tokens

Usage:
  from llm_client import LLMClient

  llm = LLMClient()
  answer = llm.chat("What is 2+2?")                        # simple
  answer = llm.chat("...", system="You are a SQL expert")  # with system prompt
  answer, reasoning = llm.chat("...", return_reasoning=True)

  # Structured output (JSON)
  result = llm.chat_json("Rank these items: ...", schema_hint="Return a JSON array")

  # Batch (multiple questions in one call)
  results = llm.batch_chat(["Q1", "Q2", "Q3"])
"""

import json
import time
import requests
from typing import Optional, Tuple, List, Dict, Any

BASE_URL = "http://10.10.109.101:32320/glm52/v1"
MODEL = "glm-5.2-fp8"
DEFAULT_MAX_TOKENS = 4000
DEFAULT_TEMPERATURE = 0.1
DEFAULT_TIMEOUT = 300  # 5 minutes


class LLMClient:
    """Direct API client for GLM-5.2-FP8."""

    def __init__(
        self,
        base_url: str = BASE_URL,
        model: str = MODEL,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        temperature: float = DEFAULT_TEMPERATURE,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        self.base_url = base_url
        self.model = model
        self.default_max_tokens = max_tokens
        self.default_temperature = temperature
        self.timeout = timeout
        self.session = requests.Session()
        # Set headers for OpenAI-compatible API
        self.session.headers.update({
            "Content-Type": "application/json",
        })

    def chat(
        self,
        user_message: str,
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        return_reasoning: bool = False,
        return_usage: bool = False,
    ) -> str | Tuple[str, Optional[str]] | Tuple[str, Optional[str], Dict]:
        """
        Send a chat completion request.

        Args:
            user_message: The user's question/prompt
            system: Optional system prompt
            temperature: Override default temperature (0.1 = focused, 0.7 = creative)
            max_tokens: Override default max tokens
            return_reasoning: If True, also return the model's reasoning
            return_usage: If True, also return token usage stats

        Returns:
            content string, or (content, reasoning) if return_reasoning,
            or (content, reasoning, usage) if both flags set.
        """
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": user_message})

        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature if temperature is not None else self.default_temperature,
            "max_tokens": max_tokens or self.default_max_tokens,
        }

        start = time.time()
        r = self.session.post(
            f"{self.base_url}/chat/completions",
            json=payload,
            timeout=self.timeout,
        )
        elapsed = time.time() - start
        r.raise_for_status()

        data = r.json()
        choice = data["choices"][0]
        content = choice["message"].get("content")
        reasoning = choice["message"].get("reasoning")
        usage = data.get("usage", {})
        usage["elapsed_seconds"] = round(elapsed, 2)
        usage["finish_reason"] = choice.get("finish_reason")

        if return_usage:
            return content, reasoning, usage
        if return_reasoning:
            return content, reasoning
        return content

    def chat_json(
        self,
        user_message: str,
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> Any:
        """
        Send a chat request and parse the response as JSON.
        Adds "Return ONLY valid JSON, no markdown, no explanation." to the system prompt.
        Strips ```json fences if present.

        Returns:
            Parsed JSON (dict, list, etc.)
        """
        json_instruction = "Return ONLY valid JSON. No markdown code fences. No explanation. No text before or after the JSON."
        if system:
            full_system = f"{system}\n\n{json_instruction}"
        else:
            full_system = json_instruction

        content, reasoning, usage = self.chat(
            user_message,
            system=full_system,
            temperature=temperature,
            max_tokens=max_tokens,
            return_reasoning=True,
            return_usage=True,
        )

        if not content:
            raise ValueError(f"LLM returned no content. Reasoning: {reasoning[:200] if reasoning else 'none'}")

        # Strip markdown code fences if present
        text = content.strip()
        if text.startswith("```"):
            # Remove ```json or ``` prefix
            lines = text.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            text = "\n".join(lines).strip()

        try:
            return json.loads(text)
        except json.JSONDecodeError:
            # Try to extract JSON from the text
            import re
            json_match = re.search(r'\[.*\]|\{.*\}', text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            raise ValueError(f"Could not parse JSON from LLM response: {text[:200]}")

    def batch_chat(
        self,
        user_messages: List[str],
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> List[Optional[str]]:
        """
        Send multiple questions. Each gets its own API call.
        Returns list of content strings (None if failed).
        """
        results = []
        for i, msg in enumerate(user_messages):
            try:
                content = self.chat(
                    msg,
                    system=system,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                results.append(content)
            except Exception as e:
                results.append(None)
        return results

    def rerank(
        self,
        query: str,
        candidates: List[Dict[str, str]],
        candidate_text_key: str = "text",
    ) -> List[Dict[str, Any]]:
        """
        Re-rank candidates by semantic relevance to the query.

        Stage 2 of two-stage retrieval:
          Stage 1: TF-IDF retrieves top-N candidates (fast, high recall)
          Stage 2: LLM re-ranks them by true semantic relevance (slow, high precision)

        Args:
            query: The user's question
            candidates: List of dicts, each with at least candidate_text_key
            candidate_text_key: Key in each candidate dict that contains the text to rank

        Returns:
            Same list of candidates, sorted by relevance (most relevant first),
            each with an added 'llm_rank' and 'llm_score' field.
        """
        if not candidates:
            return []

        # Build the prompt
        candidate_lines = []
        for i, c in enumerate(candidates):
            text = c.get(candidate_text_key, "")[:200]
            name = c.get("name", f"item_{i}")
            candidate_lines.append(f"{i+1}. [{name}] {text}")

        prompt = f"""User question: "{query}"

Candidate items:
{chr(10).join(candidate_lines)}

Rank these {len(candidates)} items by relevance to the user question.
Return a JSON array of objects with "index" (1-based) and "score" (0-10, where 10 is perfectly relevant).
Sort by score descending (most relevant first).
Example format: [{{"index": 1, "score": 9}}, {{"index": 2, "score": 3}}]"""

        try:
            ranked = self.chat_json(
                prompt,
                system="You are a relevance ranking expert. Evaluate how relevant each item is to the user's question. Consider semantic meaning, not just keyword overlap.",
                temperature=0.1,
                max_tokens=2000,
            )

            # Apply ranking
            if isinstance(ranked, list):
                # Sort by score descending
                ranked.sort(key=lambda x: x.get("score", 0), reverse=True)

                result = []
                for r in ranked:
                    idx = r.get("index", 0) - 1
                    if 0 <= idx < len(candidates):
                        candidate = candidates[idx].copy()
                        candidate["llm_rank"] = len(result) + 1
                        candidate["llm_score"] = r.get("score", 0)
                        result.append(candidate)

                # Add any candidates not in the ranking
                ranked_indices = {r.get("index", 0) - 1 for r in ranked if isinstance(r, dict)}
                for i, c in enumerate(candidates):
                    if i not in ranked_indices:
                        candidate = c.copy()
                        candidate["llm_rank"] = len(result) + 1
                        candidate["llm_score"] = 0
                        result.append(candidate)

                return result

        except Exception as e:
            pass

        # Fallback: return original order
        for i, c in enumerate(candidates):
            c["llm_rank"] = i + 1
            c["llm_score"] = 0
        return candidates

    def generate_sql(
        self,
        question: str,
        context: str,
        temperature: float = 0.1,
    ) -> str:
        """
        Generate a SQL query from a natural language question + retrieved context.

        Args:
            question: Natural language question
            context: Retrieved context (table schemas, column descriptions, relationships)

        Returns:
            SQL query string
        """
        system = """You are a Trino SQL expert. Generate a valid Trino SQL query based on the user's question and the provided database context.

Rules:
- Always include shard_hint = '<value>' in WHERE clause for partition pruning. Use '45' as default if user doesn't specify a shard.
- For joins across large tables, put shard_hint filter on ALL joined tables in the JOIN ON clause.
- Never SELECT * without LIMIT on large tables (>1B rows)
- Use TRY_CAST instead of CAST for res_dob_year (has non-numeric values)
- Filter enr_date with WHERE enr_date > TIMESTAMP '2010-01-01' (has anomalies)
- For updt_* varbinary columns, use from_utf8(col) = '11' to filter (NOT CAST(col AS varchar)). b'00'=not updated, b'11'=updated.
- uid is encrypted — never try to decrypt or display it
- No writes allowed — only SELECT queries
- Do NOT add a semicolon at the end
- Return ONLY the SQL query, no explanation"""

        prompt = f"""Database context:
{context}

User question: {question}

Generate a Trino SQL query:"""

        content, reasoning = self.chat(
            prompt,
            system=system,
            temperature=temperature,
            max_tokens=3000,
            return_reasoning=True,
        )

        if not content:
            return f"-- LLM returned no content. Reasoning: {reasoning[:200] if reasoning else 'none'}"

        # Strip markdown if present
        text = content.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            text = "\n".join(lines).strip()

        return text

    def health_check(self) -> bool:
        """Check if the API is reachable and responding."""
        try:
            content = self.chat("Reply with: OK", max_tokens=50)
            return content is not None and "OK" in (content or "")
        except:
            return False


# ─── CLI for testing ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    import io
    import sys
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

    llm = LLMClient()

    print("=== GLM-5.2-FP8 LLM Client ===")
    print(f"Endpoint: {BASE_URL}")
    print(f"Model: {MODEL}")
    print()

    # Health check
    print("1. Health check...")
    ok = llm.health_check()
    print(f"   {'✅ API is healthy' if ok else '❌ API is down'}")
    print()

    # Simple chat
    print("2. Simple chat...")
    content, reasoning, usage = llm.chat(
        "What is the capital of India? Answer in one word.",
        return_reasoning=True,
        return_usage=True,
        max_tokens=500,
    )
    print(f"   Content: {content}")
    print(f"   Reasoning: {reasoning[:150] if reasoning else '(none)'}...")
    print(f"   Usage: {usage}")
    print()

    # JSON output
    print("3. JSON output...")
    result = llm.chat_json(
        "List 3 database column names for storing a person's identity. Return as JSON array of strings.",
        max_tokens=500,
    )
    print(f"   Result: {json.dumps(result, indent=2)}")
    print()

    # Re-ranking
    print("4. Re-ranking test...")
    candidates = [
        {"name": "res_dod", "text": "Date of death. NULL for living residents."},
        {"name": "res_dob_year", "text": "Year of birth."},
        {"name": "uid_status_key", "text": "Status code of the UID."},
        {"name": "operator_id", "text": "Who enrolled the person."},
        {"name": "isforeigner", "text": "Foreigner flag."},
    ]
    ranked = llm.rerank("is the person still alive", candidates)
    print(f"   Query: 'is the person still alive'")
    for c in ranked:
        print(f"   #{c['llm_rank']} {c['name']:20s} score={c['llm_score']:5.1f}  {c['text'][:50]}")
