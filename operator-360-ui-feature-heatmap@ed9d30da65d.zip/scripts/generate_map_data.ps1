$states = @(
  @{name="Andhra Pradesh";lat=15.9;lng=79.7},@{name="Arunachal Pradesh";lat=27.1;lng=93.6},
  @{name="Assam";lat=26.2;lng=92.9},@{name="Bihar";lat=25.1;lng=85.3},
  @{name="Chhattisgarh";lat=21.3;lng=81.9},@{name="Goa";lat=15.3;lng=74.0},
  @{name="Gujarat";lat=22.3;lng=71.2},@{name="Haryana";lat=29.1;lng=76.1},
  @{name="Himachal Pradesh";lat=31.1;lng=77.2},@{name="Jharkhand";lat=23.6;lng=85.3},
  @{name="Karnataka";lat=15.3;lng=75.7},@{name="Kerala";lat=10.9;lng=76.3},
  @{name="Madhya Pradesh";lat=23.5;lng=77.5},@{name="Maharashtra";lat=19.7;lng=75.7},
  @{name="Manipur";lat=24.7;lng=93.9},@{name="Meghalaya";lat=25.5;lng=91.4},
  @{name="Mizoram";lat=23.2;lng=92.8},@{name="Nagaland";lat=26.2;lng=94.6},
  @{name="Odisha";lat=20.9;lng=84.2},@{name="Punjab";lat=31.1;lng=75.3},
  @{name="Rajasthan";lat=27.0;lng=74.2},@{name="Sikkim";lat=27.5;lng=88.5},
  @{name="Tamil Nadu";lat=11.1;lng=78.7},@{name="Telangana";lat=17.4;lng=79.1},
  @{name="Tripura";lat=23.9;lng=91.9},@{name="Uttar Pradesh";lat=27.1;lng=80.9},
  @{name="Uttarakhand";lat=30.3;lng=79.0},@{name="West Bengal";lat=23.0;lng=87.9},
  @{name="Delhi";lat=28.6;lng=77.2},@{name="Jammu & Kashmir";lat=33.7;lng=76.9},
  @{name="Ladakh";lat=34.2;lng=77.6}
)

$stateCounts = @{}
foreach ($s in $states) { $stateCounts[$s.name] = @{h=0;m=0;l=0} }

$csvPath = Join-Path $PSScriptRoot "..\cleaned_operator_data_with_risk.csv"
$rows = Import-Csv $csvPath
$valid = $rows | Where-Object { $_.latitude -ne "" -and $_.longitude -ne "" -and $_.risk_bucket -ne "" -and $_.risk_bucket -ne "No" }

Write-Host "Valid operators: $($valid.Count)"

$opList = [System.Collections.Generic.List[string]]::new()

foreach ($row in $valid) {
  $lat = [double]$row.latitude
  $lng = [double]$row.longitude
  $rb = $row.risk_bucket

  if ($rb -eq "Critical" -or $rb -eq "High") { $rc = "h" }
  elseif ($rb -eq "Medium") { $rc = "m" }
  else { $rc = "l" }

  $minD = [double]::MaxValue
  $ns = $states[0].name
  foreach ($s in $states) {
    $d = ($lat - $s.lat)*($lat - $s.lat) + ($lng - $s.lng)*($lng - $s.lng)
    if ($d -lt $minD) { $minD = $d; $ns = $s.name }
  }

  $stateCounts[$ns][$rc]++
  $safeId = $row.operator_id -replace '"','\"'
  $opList.Add("[" + [math]::Round($lat,5) + "," + [math]::Round($lng,5) + ",`"$rc`",`"$safeId`"]")
}

Write-Host "Processed: $($opList.Count)"

# Build state summary JSON
$stateLines = [System.Collections.Generic.List[string]]::new()
foreach ($s in $states) {
  $sc = $stateCounts[$s.name]
  $total = $sc['h'] + $sc['m'] + $sc['l']
  $stateLines.Add("  `"$($s.name)`":{`"h`":$($sc['h']),`"m`":$($sc['m']),`"l`":$($sc['l']),`"total`":$total,`"centroid`":[$($s.lat),$($s.lng)]}")
}

$outPath = Join-Path $PSScriptRoot "..\src\resources\operatorMapData.json"

$sb = [System.Text.StringBuilder]::new()
[void]$sb.AppendLine("{")
[void]$sb.AppendLine("`"states`":{")
[void]$sb.AppendLine(($stateLines -join ",`n"))
[void]$sb.AppendLine("},")
[void]$sb.AppendLine("`"operators`":[")
[void]$sb.AppendLine(($opList -join ",`n"))
[void]$sb.AppendLine("]")
[void]$sb.AppendLine("}")

[System.IO.File]::WriteAllText($outPath, $sb.ToString())

$fileSize = (Get-Item $outPath).Length / 1MB
Write-Host "Written to $outPath (${fileSize:F1} MB)"
