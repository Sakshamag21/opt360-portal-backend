import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './Components/LandingPage';
import Callback from './Components/Callback';
import ProtectedRoute from './Components/ProtectedRoute';
import ProtectedLayout from './Components/ProtectedLayout';
import OperatorAnomalyDashboard from './Components/OperatorAnomalyDashboard';
import AnomalyIndicatorsPage from './Components/AnomalyIndicatorsPage';
import RegionEvaluationPage from './Components/RegionEvaluationPage';
import ViewOperatorsPage from './Components/ViewOperatorsPage';
import SearchPacketDetailsPage from './Components/SearchPacketDetailsPage';
import FeatureAnalysisPage from './Components/FeatureAnalysisPage';
import ProfilePage from './Components/ProfilePage';
import DynamicRiskMap from './Components/DynamicRiskMap';
import RiskHeatMap from './Components/RiskHeatMap';

function App() {
  return (
    <Router>
      <div className="flex flex-col min-h-screen">
        <main className="flex-grow">
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/callback" element={<Callback />} />
            
            {/* Protected Dashboard Routes (render PageNavigation + header once via ProtectedLayout) */}
            <Route
              element={
                <ProtectedRoute>
                  <ProtectedLayout />
                </ProtectedRoute>
              }
            >
              <Route path="/dashboard" element={<OperatorAnomalyDashboard />} />
              <Route path="/anomalyindicators" element={<AnomalyIndicatorsPage />} />
              <Route path="/regionevaluation" element={<RegionEvaluationPage />} />
              <Route path="/viewoperators" element={<ViewOperatorsPage />} />
              <Route path="/searchpacketdetails" element={<SearchPacketDetailsPage />} />
              <Route path="/featureanalysis" element={<FeatureAnalysisPage />} />
              <Route path="/dynamicriskmap" element={<DynamicRiskMap />} />
              <Route path="/riskheatmap" element={<RiskHeatMap />} />
              <Route path="/profile" element={<ProfilePage />} />
            </Route>

            {/* Redirect unknown routes to landing page */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
