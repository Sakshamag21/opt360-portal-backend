// src/RiskHeatMap.jsx
import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, useMap, useMapEvents, GeoJSON } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet.heat'; // Import the heat plugin


// Import local components
// PageWrapper and PageNavigation provided by ProtectedLayout — don't render here

// Import Mock Data
import { stateHeatData, districtHeatData } from './heatmapMockData';

// Component to track map zoom level
const ZoomTracker = ({ setZoomLevel }) => {
  const map = useMapEvents({
    zoomend: () => setZoomLevel(map.getZoom()),
  });
  return null;
};

// Custom React component to attach the heat layer to the Leaflet map
const HeatLayer = ({ points, zoomLevel }) => {
  const map = useMap();

  useEffect(() => {
    if (!map || !points.length) return;

    // Adjust radius based on zoom level (bigger blobs when zoomed out)
    const radius = zoomLevel < 7 ? 35 : 25;

    const heatLayer = L.heatLayer(points, {
      radius: radius,
      blur: 20,
      maxZoom: 12,
      max: 1.0,
      gradient: {
        0.0: 'blue',
        0.3: 'lime',
        0.5: 'yellow',
        0.8: 'orange',
        1.0: 'red'
      }
    });

    heatLayer.addTo(map);

    // Cleanup function: remove layer when points change or component unmounts
    return () => {
      map.removeLayer(heatLayer);
    };
  }, [map, points, zoomLevel]);

  return null;
};

const RiskHeatMap = () => {
  const [zoomLevel, setZoomLevel] = useState(5);
  const [points, setPoints] = useState([]);
  
  // GeoJSON states
  const [stateGeoData, setStateGeoData] = useState(null);
  const [districtGeoData, setDistrictGeoData] = useState(null);

  // Fetch GeoJSON boundaries
  useEffect(() => {
    fetch('https://raw.githubusercontent.com/geohacker/india/master/state/india_telengana.geojson')
      .then(response => response.json())
      .then(data => setStateGeoData(data))
      .catch(error => console.error("Error fetching State GeoJSON:", error));

    fetch('https://raw.githubusercontent.com/datameet/maps/master/geojson/Districts.geojson')
      .then(response => response.json())
      .then(data => setDistrictGeoData(data))
      .catch(error => console.error("Error fetching District GeoJSON:", error));
  }, []);

  // Switch heat data based on zoom level
  useEffect(() => {
    if (zoomLevel < 7) {
      setPoints(stateHeatData); // Show State-wise data
    } else {
      setPoints(districtHeatData); // Show District-wise data
    }
  }, [zoomLevel]);

  // Styles for boundaries
  const stateStyle = () => ({ fillColor: '#ffffff', weight: 2.5, color: '#444444', fillOpacity: 0.1 });
  const districtStyle = () => ({ fillColor: '#ffffff', weight: 1, color: '#888888', fillOpacity: 0.1 });

  const onEachFeature = (feature, layer) => {
    const name = feature.properties.NAME_1 || feature.properties.st_nm || feature.properties.DISTRICT;
    if (name) {
      layer.bindTooltip(name, { sticky: true });
    }
  };

  return (
    <>
      <div style={{ height: 'calc(100vh - 260px)', width: '100%', position: 'relative' }}>
        
        {/* Floating UI: Zoom Indicator & Legend */}
        <div style={{ position: 'absolute', top: '10px', right: '10px', zIndex: 1000, display: 'flex', gap: '15px' }}>
          
          {/* Legend */}
          <div style={{ background: 'white', padding: '15px', borderRadius: '4px', boxShadow: '0 2px 5px rgba(0,0,0,0.2)' }}>
            <strong>Risk Density Legend</strong>
            <div style={{ display: 'flex', flexDirection: 'column', marginTop: '10px', gap: '5px' }}>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <div style={{ width: '20px', height: '10px', background: 'red', marginRight: '8px' }}></div>
                High Risk Density
              </div>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <div style={{ width: '20px', height: '10px', background: 'orange', marginRight: '8px' }}></div>
                Medium-High Density
              </div>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <div style={{ width: '20px', height: '10px', background: 'yellow', marginRight: '8px' }}></div>
                Medium Density
              </div>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <div style={{ width: '20px', height: '10px', background: 'blue', marginRight: '8px' }}></div>
                Low/No Risk
              </div>
            </div>
          </div>

          {/* Zoom Level Indicator */}
          <div style={{ background: 'white', padding: '15px', borderRadius: '4px', boxShadow: '0 2px 5px rgba(0,0,0,0.2)', height: 'fit-content' }}>
            <strong>Current View:</strong> <br/>
            <small>{zoomLevel < 7 ? 'State-wise Aggregation' : 'District-wise Aggregation'}</small>
          </div>
        </div>

        <MapContainer 
          center={[22.5937, 78.9629]} 
          zoom={5} 
          style={{ height: '100%', width: '100%' }}
          maxBounds={L.latLngBounds(L.latLng(6, 68), L.latLng(37, 97))}
        >
          {/* Google Maps style tiles */}
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
            attribution='&copy; OpenStreetMap contributors &copy; CARTO'
          />
          
          <ZoomTracker setZoomLevel={setZoomLevel} />

          {/* LEVEL 1: Show State Borders (When Zoom < 7) */}
          {zoomLevel < 7 && stateGeoData && (
            <GeoJSON data={stateGeoData} style={stateStyle} onEachFeature={onEachFeature} />
          )}

          {/* LEVEL 2: Show District Borders (When Zoom >= 7) */}
          {zoomLevel >= 7 && districtGeoData && (
            <GeoJSON data={districtGeoData} style={districtStyle} onEachFeature={onEachFeature} />
          )}

          {/* Render the Heat Layer dynamically based on zoom */}
          <HeatLayer points={points} zoomLevel={zoomLevel} />
        </MapContainer>
      </div>
    </>
  );
};

export default RiskHeatMap;