import React from 'react';
import PatternAnalysisTab from './PatternAnalysisTab';

const AnomalyIndicatorsPage = () => (
  <>
    <PatternAnalysisTab />
  </>
);

export default AnomalyIndicatorsPage;
