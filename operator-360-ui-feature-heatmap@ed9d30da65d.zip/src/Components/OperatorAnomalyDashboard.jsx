import React from 'react';
import OverviewTab from './OverviewTab';

// This is the shell for the /dashboard route (Overview tab).
const OperatorAnomalyDashboard = () => (
  <>
    <OverviewTab />
  </>
);

export default OperatorAnomalyDashboard;
