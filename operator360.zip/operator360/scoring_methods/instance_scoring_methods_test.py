import findspark
findspark.init()
from pyspark.sql import functions as F, Window
from pyspark.sql import SparkSession
import logging
import pandas as pd
import numpy as np
from trino.dbapi import connect
import datetime as dt
logger = logging.getLogger(__name__)

def get_spark(job_name: str):
    spark = SparkSession.builder \
        .appName(f"opt360-instance-scoring-{job_name.replace('_','-')}") \
        .remote("sc://spark-connect-service.strot-spark.svc.cluster.local:15002") \
        .config("spark.sql.legacy.mysql.bitArrayMapping.enabled","true") \
        .config("spark.default.parallelism","800") \
        .config("spark.sql.shuffle.partitions", "800") \
        .getOrCreate()
    return spark

def multiple_col_to_one(
    spark: SparkSession,
    fraud_table: str,
    feature_id,
    period_in_days: float = 1,
    agg_method: str = None,
    weights: map = None,
    **kwargs
):
    print(period_in_days, type(period_in_days))
    print(agg_method, feature_id)
    
    # 1. Type Normalization & Early Validation
    if agg_method==None:
        period_in_days = 1
    agg_method_upper = agg_method.upper() if agg_method else 'SUM'
    
    if agg_method_upper == 'WEIGHTED_AVERAGE' and weights is None:
        raise ValueError("Weights mapping must be provided when agg_method is 'weighted_average'")
    
    # Convert string to a single-element list so it uses unified aggregation paths
    if isinstance(feature_id, str):
        feature_ids = [feature_id]
    elif isinstance(feature_id, list):
        feature_ids = feature_id
    else:
        raise TypeError("feature_id must be either a string or a list of strings")
        
    # Cast period_in_days safely to integer for date sub
    prev_date = F.date_sub(F.current_date(), int(float(period_in_days)))
    print("Lookback limit date:", prev_date)
    
    # 2. Extract Data & Apply Time Frame Filters once
    df_base = spark.table(fraud_table) \
        .withColumn("entity_id", F.col("entity_id").cast("string")) \
        .withColumn("feature_value", F.col("feature_value").cast("double")) \
        .filter(F.col("feature_id").isin(feature_ids)) \
        .filter(F.to_date(F.col("timestamp")) >= prev_date)

    # 3. Time Series Consolidation (Intra-Feature Aggregation)
    if agg_method_upper == 'MAX':
        pivot_agg = F.max("feature_value")
    elif agg_method_upper == 'MIN':
        pivot_agg = F.min("feature_value")
    elif agg_method_upper == 'AVERAGE':
        pivot_agg = F.avg("feature_value")
    else:
        pivot_agg = F.sum("feature_value")  # Default to sum for SUM and WEIGHTED_AVERAGE

    # Reshape the table via pivot to create dedicated columns per feature
    df_pivot = df_base.groupBy("entity_id").pivot("feature_id", feature_ids).agg(
        F.coalesce(pivot_agg, F.lit(0.0))
    )

    # Reference column markers safely
    incident_cols = [F.col(f"`{fid}`") for fid in feature_ids]

    # 4. Cross-Column Consolidation (Inter-Feature Aggregation)
    from functools import reduce
    
    if agg_method_upper == 'SUM':
        safe_cols = [F.coalesce(col, F.lit(0.0)) for col in incident_cols]
        df_combined = df_pivot.withColumn("final_value", reduce(lambda a, b: a + b, safe_cols))
        
    elif agg_method_upper == 'AVERAGE':
        safe_cols = [F.coalesce(col, F.lit(0.0)) for col in incident_cols]
        total_sum = reduce(lambda a, b: a + b, safe_cols)
        
        present_counts = [F.when(col.isNotNull(), 1).otherwise(0) for col in incident_cols]
        total_present = reduce(lambda a, b: a + b, present_counts)
        
        df_combined = df_pivot.withColumn(
            "final_value", 
            F.when(total_present > 0, total_sum / total_present).otherwise(F.lit(0.0))
        )
        
    elif agg_method_upper == 'MAX':
        df_combined = df_pivot.withColumn("final_value", F.greatest(*incident_cols))
        
    elif agg_method_upper == 'MIN':
        df_combined = df_pivot.withColumn("final_value", F.least(*incident_cols))
        
    elif agg_method_upper == 'WEIGHTED_AVERAGE':
        weighted_cols = [
            F.coalesce(F.col(f"`{fid}`"), F.lit(0.0)) * F.lit(float(weights.get(fid, 0.0))) 
            for fid in feature_ids
        ]
        weighted_sum = reduce(lambda a, b: a + b, weighted_cols)
        weight_total = sum(float(weights.get(fid, 0.0)) for fid in feature_ids)
        
        if weight_total == 0:
            raise ZeroDivisionError("The total sum of provided weights for the target features cannot be zero.")
            
        df_combined = df_pivot.withColumn("final_value", weighted_sum / F.lit(weight_total))
        df_combined.select(['entity_id', 'final_value']).show(30)
        
    else:
        raise NotImplementedError(f"Unsupported aggregation method: {agg_method}")

    return df_combined.select(['entity_id', 'final_value'])



def rank_scoring(
    spark: SparkSession,
    fraud_table: str,
    feature_id,
    range_start: float = 0.0,
    range_end: float = 1.0,
    is_inverse: bool = False,
    apply_threshold: bool = False,
    threshold: float = None,
    require_aggregation: bool = False,
    method: str = None,
    weights: map = None,
    **kwargs
):
    # 1. Input Sanitization
    if feature_id is None or fraud_table is None:
        raise RuntimeError('feature_id and fraud_table must be defined')
        
    req_agg = str(require_aggregation).strip().lower() == 'true'

    if req_agg:
        prev_date = F.date_sub(F.current_date(), 30)
    else:
        prev_date = F.date_sub(F.current_date(), 1)

    # 2. Extract and Align Dataframes Dynamically
    if method == 'weighted_average' and not isinstance(feature_id, str) and weights is not None:
        print("feature_id", feature_id)
        df = multiple_col_to_one(spark, fraud_table, feature_id, period_in_days=30, agg_method='weighted_average', weights=weights)
        print(df.count())
        df_latest = df.withColumnRenamed("final_value", "feature_value")
    else:
        df_base = spark.table(fraud_table).filter(F.col("feature_id") == feature_id)
        
        if df_base.rdd.isEmpty():
            logger.warning(f"No records discovered across the cluster for feature_id: {feature_id}")
            return spark.createDataFrame([], schema="entity_id string, score double")

        if not req_agg:
            max_date = df_base.select(F.max(F.to_date(F.col("timestamp")))).collect()[0][0]
            
            if max_date is None:
                logger.warning(f"Feature ID {feature_id} exists but contains no valid timestamps.")
                return spark.createDataFrame([], schema="entity_id string, score double")
                
            df_latest = df_base.filter(F.to_date(F.col("timestamp")) == F.lit(max_date)) \
                               .select('entity_id', F.col('feature_value').cast('double').alias('feature_value'))
        else:
            df_filt = df_base.filter(F.to_date(F.col("timestamp")) > F.lit(prev_date))
            df_latest = df_filt.groupBy('entity_id').agg(F.sum('feature_value').cast('double').alias('feature_value'))

    
    # 3. Apply Threshold Logic Safely
    if apply_threshold and threshold is not None:
        if is_inverse:
            df_latest = df_latest.withColumn(
                "adjusted_value", 
                F.when(F.col("feature_value") >= threshold, F.lit(threshold)).otherwise(F.col("feature_value"))
            )
        else:
            df_latest = df_latest.withColumn(
                "adjusted_value", 
                F.when(F.col("feature_value") <= threshold, F.lit(threshold)).otherwise(F.col("feature_value"))
            )
    else:
        df_latest = df_latest.withColumn("adjusted_value", F.col("feature_value"))

    # 4. Handle Windowing Safely
    total_count = df_latest.count()
    if total_count == 0:
        return df_latest.select('entity_id').withColumn("score", F.lit(range_start))

    if is_inverse:
        w = Window.orderBy(F.col("adjusted_value").asc())
    else:
        w = Window.orderBy(F.col("adjusted_value").desc())
        
    df_ranked = df_latest.withColumn("rank", F.rank().over(w))
    
    # 5. Calculate Score safely
    if total_count <= 1:
        df_final = df_ranked.withColumn("score", F.lit(float(range_end)))
    else:
        max_rank = df_ranked.agg(F.max("rank")).collect()[0][0]
        df_final = df_ranked.withColumn(
            "score",
            F.lit(float(range_end)) - ((F.col("rank") - 1) / (max_rank - 1)) * (float(range_end) - float(range_start))
        )
        
    print(total_count)

    df_final.select('entity_id', 'score').orderBy(F.col('score').asc()).show(20)
    df_final.select('entity_id', 'score').orderBy(F.col('score').desc()).show(20)
    
    df_final_capped = df_final.withColumn(
        "score",
        F.greatest(F.lit(range_start), F.least(F.col("score"), F.lit(range_end)))
    )
    
    return df_final_capped.select('entity_id', 'score')

def winsorized_zscoring(
    spark: SparkSession,
    fraud_table: str,
    feature_id,
    is_multiple_col: bool= False,
    period_in_days:float= 30.0,
    aggregation_method: str= None,
    weights: map=None,
    winsorize_percentile: float=0.99,
    sigmoid_scale: float=0.5,
    **kwargs
):
    value_col='final_value'
    df_combined= multiple_col_to_one(spark=spark,
                                    fraud_table=fraud_table,
                                    feature_id=feature_id,
                                    period_in_days=period_in_days,
                                    agg_method=aggregation_method if is_multiple_col else None,
                                    weights= weights if is_multiple_col else None
                                )
    print('df_combined')
    print(df_combined.show())
    
    stats = df_combined.select(
        F.mean(value_col).alias("mean_val"),
        F.stddev_pop(value_col).alias("stddev_val"),
        F.min(value_col).alias("min_val"),
        F.max(value_col).alias("max_val"),
        F.expr(f"percentile_approx({value_col}, {winsorize_percentile})").alias("percentile_threshold")
    ).collect()[0]
    
    mean_val = stats["mean_val"]
    stddev_val = stats["stddev_val"] if stats["stddev_val"] and stats["stddev_val"] > 0 else 1.0
    percentile_threshold = stats["percentile_threshold"]
    min_val = stats["min_val"]
    max_val = stats["max_val"]
    
    df_capped = df_combined.withColumn(
        f"{value_col}_capped",
        F.when(F.col(value_col) > percentile_threshold, percentile_threshold)
         .otherwise(F.col(value_col))
    )
    
    df_capped = df_capped.withColumn(
        "is_extreme_outlier",
        F.when(F.col(value_col) > percentile_threshold, True).otherwise(False)
    )
    df_with_zscore = df_capped.withColumn(
        "zscore",
        (F.col(f"{value_col}_capped") - F.lit(mean_val)) / F.lit(stddev_val)
    )
    
    df_normalized = df_with_zscore.withColumn(
        "score_sigmoid",
        F.lit(1.0) / (F.lit(1.0) + F.exp(-F.lit(sigmoid_scale) * F.col("zscore")))
    )
    
    df_normalized = df_normalized.withColumn(
        "score",
        F.when(F.col("is_extreme_outlier") == True, 0.99)
         .otherwise(F.col("score_sigmoid"))
    )
    
    df_normalized = df_normalized.drop(f"{value_col}_capped", "score_sigmoid")
    
    df_normalized = df_normalized.withColumn(
        "score",
        F.when(F.col("score") < 0, 0.0)
         .when(F.col("score") > 1, 1.0)
         .otherwise(F.col("score"))
    )
    
    return df_normalized



def zscore(
    spark: SparkSession,
    fraud_table: str,
    feature_id,
    is_multiple_col: bool = False,
    period_in_days: float = 30.0,
    aggregation_method: str = None,
    weights: map = None,
    require_aggregation=False,
    range_start: float = 0.0,
    range_end: float = 1.0,
    **kwargs
):
    value_col = 'final_value'

    print("agg_method:",aggregation_method)
    if require_aggregation=='True' or require_aggregation==True:
        df_combined = multiple_col_to_one(
            spark=spark,
            fraud_table=fraud_table,
            feature_id=feature_id,
            period_in_days=period_in_days,
            agg_method=aggregation_method if is_multiple_col else "SUM",
            weights=weights if is_multiple_col else None
        )
    else:
        df_combined = multiple_col_to_one(
            spark=spark,
            fraud_table=fraud_table,
            feature_id=feature_id,
            period_in_days=period_in_days,
            agg_method= None,
            weights= None
        )

    print(df_combined.count())
    print(df_combined.select(F.count_distinct("entity_id")).show())
    
    if df_combined.rdd.isEmpty():
        logger.warning("No data found for the given feature constraints.")
        return df_combined.withColumn("score", F.lit(range_start))

    print('df_combined')
    df_combined.show()
    
    stats = df_combined.select(
        F.mean(value_col).alias("mean_val"),
        F.stddev_pop(value_col).alias("stddev_val")
    ).collect()[0]
    
    mean_val = stats["mean_val"] if stats["mean_val"] is not None else 0.0
    
    stddev_val = stats["stddev_val"]
    if stddev_val is None or stddev_val == 0.0:
        stddev_val = 1.0 
    
    df_with_zscore = df_combined.withColumn(
        "zscore",
        (F.col(value_col) - F.lit(mean_val)) / F.lit(stddev_val)
    )
    
    df_final = df_with_zscore.withColumn("score", F.col("zscore")).drop("zscore")
    
    return df_final


def log_based_scoring(
    spark: SparkSession,
    fraud_table: str ,
    feature_id: str,
    range_start: float = 0,
    range_end: float = 1,
    period_in_days: int = 30,
    threshold: int = 0,
    **kwargs
):
    cutoff_date = F.date_sub(F.current_date(), int(period_in_days))
    
    df_feature = spark.table(fraud_table).filter(F.col("feature_id") == feature_id)
    df_filtered = df_feature.filter(F.to_date(F.col("timestamp")) >= cutoff_date)
    
    df_agg = df_filtered.groupBy("entity_id").agg(
        F.sum("feature_value").alias("feature_val")
    )
    
    df_agg = df_agg.filter(F.col("feature_val") > threshold)
    
    max_val_row = df_agg.select(F.max("feature_val").alias("max_val")).collect()[0]
    global_max = max_val_row["max_val"] if max_val_row["max_val"] is not None else 1.0
    
    df_scored = df_agg.withColumn(
        "score",
        F.lit(range_start) + (F.lit(range_end) - F.lit(range_start)) * 
        (F.log1p(F.col("feature_val")) / F.log1p(F.lit(global_max)))
    )
    df_final_capped = df_scored.withColumn(
        "score",
        F.greatest(F.lit(range_start), F.least(F.col("score"), F.lit(range_end)))
    )

    return df_final_capped.select('entity_id', 'score')
    

def wilson_fraud_scoring(
    spark: SparkSession,
    fraud_table: str,
    feature_id_numerator: str,
    feature_id_denominator: str,
    range_start: float = 0,
    range_end: float = 1,
    period_in_days: int = 30,
    **kwargs
):
    cutoff_date = F.date_sub(F.current_date(), int(period_in_days))
    
    df_num = (spark.table(fraud_table)
              .filter(F.col("feature_id") == feature_id_numerator)
              .filter(F.to_date(F.col("timestamp")) >= cutoff_date)
              .groupBy("entity_id").agg(F.sum("feature_value").alias("ups")))
    print("numerator")
    print(df_num.show())
    
    df_den = (spark.table(fraud_table)
              .filter(F.col("feature_id") == feature_id_denominator)
              .filter(F.to_date(F.col("timestamp")) >= cutoff_date)
              .groupBy("entity_id").agg(F.sum("feature_value").alias("n")))
    print("denominator")
    print(df_den.show())
    
    df_joined = df_num.join(df_den, on="entity_id", how="inner").filter(F.col("n") > 0)
    z = 1.96 
    df_scored = df_joined.withColumn("p", F.col("ups") / F.col("n"))
    
    df_scored = df_scored.withColumn(
        "wilson_lower_bound",
        (F.col("p") + (z**2 / (2 * F.col("n"))) - 
         z * F.sqrt((F.col("p") * (1 - F.col("p")) / F.col("n")) + (z**2 / (4 * F.col("n")**2)))) / 
        (1 + (z**2 / F.col("n")))
    )

    df_final = df_scored.withColumn(
        "score",
        F.lit(range_start) + (F.lit(range_end) - F.lit(range_start)) * F.col("wilson_lower_bound")
    ).select("entity_id", "ups", "n", "p", "score")

    df_final_capped = df_final.withColumn(
        "score",
        F.greatest(F.lit(range_start), F.least(F.col("score"), F.lit(range_end)))
    )
    
    return df_final_capped.select('entity_id', 'score')
    

def exponential_decay_scoring(
    spark: SparkSession,
    fraud_table: str ,
    feature_id: str ,
    period_in_days: float,
    range_start: float = 0,
    range_end: float = 1,
    time_unit: str='days',
    decay_rate: float=0.1,
    **kwargs
):
    df = spark.table(fraud_table).filter(F.col("feature_id") == feature_id)
    cutoff_date = F.date_sub(F.current_date(), int(period_in_days))

    df = df.filter(
        (F.to_date(F.col("timestamp")) >= F.lit(cutoff_date).cast('date')) 
    )
    
    df = df.withColumn(
        'timestamp',
        F.when(F.col('timestamp').cast('string').isNotNull(), 
               F.to_timestamp(F.col('timestamp')))
        .otherwise(F.col('timestamp'))
    )

    df = df.withColumn('date', F.to_date(F.col('timestamp')))
    
    df = df.groupBy('entity_id', 'date').agg(
        F.max('feature_value').alias('feature_value'),
        F.max('timestamp').alias('timestamp')
    )    
    
    current_time = df.agg(F.max('timestamp')).collect()[0][0]
    
    if time_unit == 'days':
        time_divisor = 86400 

    print(df.show())
    
    df = df.withColumn(
        'time_elapsed',
        (F.unix_timestamp(F.lit(current_time)) - F.unix_timestamp(F.col('timestamp'))) / time_divisor
    ).withColumn(
        'decay_weight',
        F.exp(-decay_rate * F.col('time_elapsed'))
    ).withColumn(
        'weighted_score',
        F.col('feature_value') * F.col('decay_weight')
    )
    
    risk_scores = df.groupBy('entity_id').agg(
        F.sum('weighted_score').alias('raw_risk_score'),
        F.count('feature_value').alias('event_count'),
        F.min('time_elapsed').alias('days_since_last_event')
    )
    
    min_max = risk_scores.agg(
        F.min('raw_risk_score').alias('min_score'),
        F.max('raw_risk_score').alias('max_score')
    ).collect()[0]
    
    min_score = min_max['min_score']
    max_score = min_max['max_score']
    
    if max_score > min_score:
        risk_scores = risk_scores.withColumn(
            'score',
            range_start + ((F.col('raw_risk_score') - min_score) / (max_score - min_score))* (range_end-range_start)
        )
        
        total_opt_ids = risk_scores.count()
        w = Window.orderBy(F.col('score').asc())
        
        risk_scores = risk_scores.withColumn(
            'rank',
            F.row_number().over(w)
        ).withColumn(
            'rank_score',
            (F.col('rank') / F.lit(total_opt_ids))
        )
    else:
        risk_scores = risk_scores.withColumn('risk_score', F.lit(0.5))
        risk_scores = risk_scores.withColumn('rank', F.lit(1))
        risk_scores = risk_scores.withColumn('rank_score', F.lit(0.5))
        
    
    risk_scores = risk_scores.select(
        'entity_id', 'score', 'raw_risk_score', 'rank', 'rank_score',
        'event_count', 'days_since_last_event'
    )

    df_final_capped = risk_scores.withColumn(
        "score",
        F.greatest(F.lit(range_start), F.least(F.col("score"), F.lit(range_end)))
    )
    
    return df_final_capped.select('entity_id', 'score')


# ==========================================
# MERGED RISK PRIORITIZATION MODEL (Pure Spark Implementation)
# ==========================================

def calculate_decayed_risk_score_spark(df, date_col, count_col, end_date_str, half_life_days=14):
    """
    PySpark function to calculate time-based exponential decay (SUM).
    """
    lambda_val = np.log(2) / half_life_days
    age_in_days = F.datediff(F.to_date(F.lit(end_date_str)), F.to_date(F.col(date_col)))
    weight = F.exp(F.lit(-lambda_val) * age_in_days)
    df = df.withColumn("decayed_count", weight * F.col(count_col))
    return df

def run_risk_prioritization_model_spark(
    spark, 
    fraud_table=None, 
    start_date='2026-07-20', 
    end_date='2026-08-20', 
    half_life_days=14, 
    range_start=0.0, 
    range_end=1.0, 
    **kwargs
):
    """
    Queries Trino and MySQL via Spark JDBC, applies decay, boundaries, z-scores, 
    and policy routing natively via Spark DataFrames. Returns (entity_id, score).
    """
    
    # Convert inputs safely
    half_life_days = int(float(half_life_days))
    range_start = float(range_start)
    range_end = float(range_end)
    
    # 1. Get Daily Raw Counts from Trino (Using Spark JDBC)
    trino_df = spark.read.format("jdbc") \
        .option("url", "jdbc:trino://10.10.116.75:8080") \
        .option("user", "opt_master_updt") \
        .option("query", f"""
            SELECT
                opt_id,
                packet_date,
                COUNT(eid) as daily_count
            FROM
                strot.operator360.opt_outstate_anomalous_enu_eid_daily
            WHERE
                machine_state != res_state
                AND packet_date >= DATE '{start_date}'
                AND packet_date <= DATE '{end_date}'
            GROUP BY
                opt_id,
                packet_date
        """) \
        .load()

    # 2. Get Operator State, EA, and REG from MySQL (Using Spark JDBC)
    mysql_df = spark.read.format("jdbc") \
        .option("url", "jdbc:mysql://10.10.108.224:3306/operator360") \
        .option("user", "Data_platform_W") \
        .option("password", "Dataplat_7634") \
        .option("query", "SELECT id, state, ea_code, reg_code FROM operator360.opt_master") \
        .load()

    # Merge metadata early to allow daily evaluation across dimensions
    trino_df = trino_df.join(mysql_df, trino_df.opt_id == mysql_df.id, "left").drop(mysql_df.id)
    trino_df = trino_df.na.fill("Unknown", subset=["state", "ea_code", "reg_code"])

    # 3. DAILY BOUNDARY DEFINITIONS (Office Policy Limits)
    state_limit = F.when(F.col("state") == "Assam", 5) \
                   .when(F.col("state") == "Sikkim", 2) \
                   .when(F.col("state") == "Arunachal Pradesh", 1) \
                   .when(F.col("state") == "Nagaland", 1) \
                   .when(F.col("state") == "Jammu & Kashmir", 3) \
                   .otherwise(10)
                   
    ea_limit = F.when(F.col("ea_code") == "EA_CORP_01", 8) \
                .when(F.col("ea_code") == "EA_CORP_02", 12) \
                .otherwise(15)
                
    reg_limit = F.when(F.col("reg_code") == "REG_BORDER_NE", 2) \
                 .when(F.col("reg_code") == "REG_NORTH_01", 10) \
                 .otherwise(20)
                 
    trino_df = trino_df.withColumn("state_limit", state_limit) \
                       .withColumn("ea_limit", ea_limit) \
                       .withColumn("reg_limit", reg_limit)

    # Apply daily validation flags (1 if breached, 0 otherwise)
    trino_df = trino_df.withColumn("state_violation", (F.col("daily_count") > F.col("state_limit")).cast("int")) \
                       .withColumn("ea_violation", (F.col("daily_count") > F.col("ea_limit")).cast("int")) \
                       .withColumn("reg_violation", (F.col("daily_count") > F.col("reg_limit")).cast("int"))

    # 4. Apply Exponential Decay to Daily Entries
    trino_df = calculate_decayed_risk_score_spark(
        df=trino_df,
        date_col="packet_date",
        count_col="daily_count",
        end_date_str=end_date,
        half_life_days=half_life_days
    )

    # 5. Aggregate to Operator Level (Month Summary)
    operator_agg_df = trino_df.groupBy("opt_id").agg(
        F.sum("decayed_count").alias("outstate_count"),
        F.sum("daily_count").alias("original_outstate_count"),
        F.max("daily_count").alias("max_daily_packets"),
        F.max("state_violation").alias("state_breached"),
        F.max("ea_violation").alias("ea_breached"),
        F.max("reg_violation").alias("reg_breached")
    )

    # Re-merge complete geographic strings for grouping functions
    merged_df = operator_agg_df.join(mysql_df, operator_agg_df.opt_id == mysql_df.id, "left").drop(mysql_df.id)
    merged_df = merged_df.na.fill("Unknown", subset=["state", "ea_code", "reg_code"])

    # 6. Calculate Z-Scores (Global, State, EA, REG)
    global_stats = merged_df.agg(
        F.mean("outstate_count").alias("mean_val"),
        F.stddev_pop("outstate_count").alias("stddev_val")
    ).collect()[0]
    
    original_mean = global_stats["mean_val"] if global_stats["mean_val"] is not None else 0.0
    original_std = global_stats["stddev_val"] if global_stats["stddev_val"] and global_stats["stddev_val"] > 0 else 1.0
    
    merged_df = merged_df.withColumn("z-score global", (F.col("outstate_count") - F.lit(original_mean)) / F.lit(original_std))

    w_state = Window.partitionBy("state")
    w_ea = Window.partitionBy("ea_code")
    w_reg = Window.partitionBy("reg_code")

    merged_df = merged_df.withColumn("s_mean", F.mean("outstate_count").over(w_state)) \
                         .withColumn("s_std", F.greatest(F.stddev_pop("outstate_count").over(w_state), F.lit(1.0))) \
                         .withColumn("state_z_score_diff", ((F.col("outstate_count") - F.col("s_mean")) / F.col("s_std")) - F.col("z-score global"))

    merged_df = merged_df.withColumn("e_mean", F.mean("outstate_count").over(w_ea)) \
                         .withColumn("e_std", F.greatest(F.stddev_pop("outstate_count").over(w_ea), F.lit(1.0))) \
                         .withColumn("ea_z_score_diff", ((F.col("outstate_count") - F.col("e_mean")) / F.col("e_std")) - F.col("z-score global"))

    merged_df = merged_df.withColumn("r_mean", F.mean("outstate_count").over(w_reg)) \
                         .withColumn("r_std", F.greatest(F.stddev_pop("outstate_count").over(w_reg), F.lit(1.0))) \
                         .withColumn("reg_z_score_diff", ((F.col("outstate_count") - F.col("r_mean")) / F.col("r_std")) - F.col("z-score global"))

    # 7. Convert Z-Score Variances to Percentiles
    w_state_pct = Window.orderBy(F.col("state_z_score_diff").asc())
    w_ea_pct = Window.orderBy(F.col("ea_z_score_diff").asc())
    w_reg_pct = Window.orderBy(F.col("reg_z_score_diff").asc())

    merged_df = merged_df.withColumn("pct_state", F.percent_rank().over(w_state_pct)) \
                         .withColumn("pct_ea", F.percent_rank().over(w_ea_pct)) \
                         .withColumn("pct_reg", F.percent_rank().over(w_reg_pct))

    # 8. Dynamic Multi-Layer Routing Policy
    any_breach = (F.col("state_breached") == 1) | (F.col("ea_breached") == 1) | (F.col("reg_breached") == 1)

    state_score = F.when(F.col("state_breached") == 1, F.col("pct_state")).otherwise(F.lit(None))
    ea_score = F.when(F.col("ea_breached") == 1, F.col("pct_ea")).otherwise(F.lit(None))
    reg_score = F.when(F.col("reg_breached") == 1, F.col("pct_reg")).otherwise(F.lit(None))

    # max_pct returns the highest percentile (0.0 to 1.0) among breached layers
    max_pct = F.when(any_breach, F.greatest(state_score, ea_score, reg_score)).otherwise(F.lit(-1.0))

    # 9. Scale the percentile to range_start and range_end
    scaled_score = F.when(
        max_pct != -1.0, 
        F.lit(range_start) + (F.lit(range_end) - F.lit(range_start)) * max_pct
    ).otherwise(F.lit(-1.0))

    layer_log = F.when(any_breach, F.concat_ws("+",
        F.when(F.col("state_breached") == 1, F.lit("STATE")).otherwise(F.lit("")),
        F.when(F.col("ea_breached") == 1, F.lit("EA")).otherwise(F.lit("")),
        F.when(F.col("reg_breached") == 1, F.lit("REG")).otherwise(F.lit(""))
    )).otherwise("NO_VIOLATIONS_EXCLUDED")

    layer_log = F.when(any_breach, F.concat(layer_log, F.lit("_MAX"))).otherwise(layer_log)

    merged_df = merged_df.withColumn("final_priority_score", scaled_score) \
                         .withColumn("dominant_risk_layer", layer_log)

    # CRITICAL FILTERING STEP: Drop operators who didn't breach any office criteria
    filtered_df = merged_df.filter(F.col("final_priority_score") != -1.0)

    # 10. Format Output to Match Orchestrator Schema (entity_id, score)
    final_df = filtered_df.select(
        F.col("opt_id").alias("entity_id"),
        F.col("final_priority_score").alias("score")
    ).orderBy(F.col("score").desc())

    print(f"Total priority threats retained: {final_df.count()}")
    
    return final_df.select('entity_id', 'score')