"""
Airflow 3 DAG: Operator Risk Analysis → ClickHouse

Pulls operator risk metadata from MySQL (opt_master),
fetches the latest category scores from Trino (strot.operator360.features_risk_v1),
ALWAYS pushes ALL matched operators to ClickHouse `operator360.risk_analysis`
(no tolerance filtering — every matched operator is pushed unconditionally),
saves a detailed CSV report containing the analysis values (risk score, max category, etc.),
and emails the report via Airflow's default email configuration.
"""
from __future__ import annotations

import logging
import os
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import clickhouse_connect
import mysql.connector
import pandas as pd
import polars as pl
from trino.dbapi import connect

from airflow.sdk import DAG
from airflow.providers.standard.operators.python import PythonOperator
import requests
# Airflow default email utility — uses the SMTP backend configured in airflow.cfg
try:
    from airflow.utils.email import send_email as _airflow_send_email
except Exception:                                      # pragma: no cover
    _airflow_send_email = None


# --------------------------------------------------------------------------- #
# Connection configuration
# --------------------------------------------------------------------------- #
TRINO_HOST = "10.10.116.39"
TRINO_HOST_FALLBACK = "10.10.116.75"
TRINO_PORT = 8080
TRINO_USER = "opt_master_updt"
TRINO_CATALOG_ICEBERG = "strot"

MYSQL_HOST = "10.10.106.159"
MYSQL_USER = "Data_platform_W"
MYSQL_PASSWORD = "Dataplat_7634"

CH_HOST = "10.10.120.86"
CH_USER = "default"
CH_PASSWORD = "qwerty"
CH_DATABASE = "default"
CH_TABLE = "risk_analysis"

# Report & email configuration
REPORT_DIR = "/tmp/risk_analysis_reports"
EMAIL_RECIPIENTS = ["techexecutive16-yp25@uidai.net.in"]
TOLERANCE = 0.1  # kept for reporting / analysis only — never blocks insertion

logger = logging.getLogger(__name__)
ZOHO_CLIQ_WEBHOOK_URL = "https://chat.uidai.gov.in/api/v2/bots/optnotifications/incoming?zapikey=1001.cb6c531ed8e5dfa2d79138ea6f227a11.fde5bcd85bf984e4b5c34bd0383106b9&channel=dataplatformtesting&dc=hdc"

# --- Network Proxy Configuration ---
PROXY_URL = "http://10.10.16.28:3128"
PROXIES = {"http": PROXY_URL, "https": PROXY_URL}

def send_zoho_cliq_alert(subject: str, body: str, report_path:str):
    """Sends an immediate alert to Zoho Cliq (used only if S3 logging fails)."""
    html_body_for_cliq = f"<h2>Pipeline Alert: {subject}</h2><p>An issue was detected.</p><hr><pre>{body}</pre>"
    payload = {"text": html_body_for_cliq}
    file_payload={
        "file":("risk_analysis_report.csv",open(report_path,"rb"), "text/csv")
    }
    try:
        response=requests.post(ZOHO_CLIQ_WEBHOOK_URL, data=payload,files=file_payload, proxies=PROXIES, timeout=10)
        print(response.json())
    except Exception as e:
        logger.error(f"Failed to send Zoho Cliq alert: {e}")


# --------------------------------------------------------------------------- #
# Generic DB helpers
# --------------------------------------------------------------------------- #
def _fetch_mysql_query(query, host=MYSQL_HOST, user=MYSQL_USER, password=MYSQL_PASSWORD):
    """Execute a MySQL query and return a Polars DataFrame."""
    connection = None
    try:
        connection = mysql.connector.connect(host=host, user=user, password=password)
        cursor = connection.cursor()
        cursor.execute(query)
        results = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description] if cursor.description else []

        safe_results = [
            [str(item) if item is not None else None for item in row]
            for row in results
        ]
        return pl.DataFrame(safe_results, schema=columns, orient="row") if columns else pl.DataFrame()
    except Exception:
        logger.exception("MySQL query execution failed.")
        raise
    finally:
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def _run_trino(query, host=TRINO_HOST, port=TRINO_PORT, user=TRINO_USER):
    """Run a Trino query and return a dict containing result data and metadata."""
    try:
        start_time = time.time()
        conn = connect(host=host, port=port, user=user)
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        end_time = time.time()

        if not body:
            return {
                "query": query,
                "success": 1,
                "data": body,
                "execution_time": end_time - start_time,
            }

        cols = [i[0] for i in cur.description]
        df = pd.DataFrame(body, columns=cols)
        return {
            "query": query,
            "success": 1,
            "data": (cols, body),
            "df": df,
            "execution_time": end_time - start_time,
        }
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}


# --------------------------------------------------------------------------- #
# Logging config
# --------------------------------------------------------------------------- #
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename="risk_categories.log",
    filemode="w",
)


# --------------------------------------------------------------------------- #
# DAG default args
# --------------------------------------------------------------------------- #
default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": datetime(2026, 8, 20, tzinfo=ZoneInfo("Asia/Kolkata")),
    "email": EMAIL_RECIPIENTS,
    "email_on_failure": True,
    "email_on_retry": True,
    "retries": 1,
}


# --------------------------------------------------------------------------- #
# Business-logic functions
# --------------------------------------------------------------------------- #
def fetch_category_scores(trino_host: str = TRINO_HOST_FALLBACK):
    query = """
    WITH tab1 AS (
        SELECT 
            entity_id, 
            feature_id, 
            feature_value,
            ROW_NUMBER() OVER (PARTITION BY entity_id, feature_id ORDER BY timestamp DESC) as rn
        FROM strot.operator360.features_risk_v1 
        WHERE feature_id LIKE '%category%'
    ),
    tab2 AS (
        SELECT entity_id, feature_id, feature_value 
        FROM tab1 
        WHERE rn = 1
    )
    SELECT 
        entity_id,
        MAX(CASE WHEN feature_id = 'auth_category_score_v2' THEN feature_value END)     AS auth_category_score_v2,
        MAX(CASE WHEN feature_id = 'document_category_score_v2' THEN feature_value END) AS document_category_score_v2,
        MAX(CASE WHEN feature_id = 'bio_category_score_v2' THEN feature_value END)      AS bio_category_score_v2,
        MAX(CASE WHEN feature_id = 'sustxn_category_score_v2' THEN feature_value END)   AS sustxn_category_score_v2,
        MAX(CASE WHEN feature_id = 'work_category_score_v2' THEN feature_value END)     AS work_category_score_v2,
        MAX(CASE WHEN feature_id = 'hardware_category_score_v2' THEN feature_value END) AS hardware_category_score_v2
    FROM tab2
    GROUP BY entity_id
    """
    data = _run_trino(query, host=trino_host)
    if "df" not in data:
        return None
    return data["df"]


def fetch_operators():
    """Fetch opt_id -> {name, ro, risk_score, risk_bucket} from MySQL opt_master."""
    conn = mysql.connector.connect(
        host=MYSQL_HOST,
        port=3306,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database="operator360",
    )
    operators = {}
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id, name, ro, risk_score, risk_bucket "
                "FROM opt_master WHERE risk_bucket IS NOT NULL"
            )
            for opt_id, name, ro, risk_score, risk_bucket in cur:
                operators[opt_id] = {
                    "name": name,
                    "ro": ro,
                    "risk_score": float(risk_score) if risk_score is not None else None,
                    "risk_bucket": risk_bucket or "",
                }
    finally:
        conn.close()
    return operators


def evaluate(operators, category_scores, ch_client, report_path):
    """
    ALWAYS push every matched operator to ClickHouse using the fixed schema.
    Save a detailed CSV report containing all analysis metrics for later review.
    """
    if category_scores is None or len(category_scores) == 0:
        logger.warning("category_scores is empty/None; nothing to evaluate.")
        os.makedirs(os.path.dirname(report_path), exist_ok=True)
        pd.DataFrame().to_csv(report_path, index=False)
        return {"processed": 0, "pushed": 0, "report_path": report_path}

    df = category_scores.copy()
    df["entity_id"] = df["entity_id"].astype(str).str.strip()

    category_columns = [
        "auth_category_score_v2",
        "document_category_score_v2",
        "bio_category_score_v2",
        "sustxn_category_score_v2",
        "work_category_score_v2",
        "hardware_category_score_v2",
    ]
    for col in category_columns:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
        else:
            logger.error(f"Missing expected column in category_scores: {col}")
            df[col] = pd.NA

    cat_indexed = df.groupby("entity_id", as_index=True).first()

    rows_to_insert = []
    report_rows = []
    counters = {
        "processed": 0,
        "pushed": 0,
        "skipped_no_match": 0,
        "skipped_no_risk_score": 0,
        "skipped_no_cat_values": 0,
    }

    now_utc = datetime.now(ZoneInfo("UTC"))

    for opt_id, meta in operators.items():
        opt_id_str = str(opt_id).strip()
        risk_score = meta.get("risk_score")
        ro_name = (meta.get("ro") or "").strip()
        name = meta.get("name", "")
        risk_bucket = meta.get("risk_bucket", "")

        # ---- Build a base report row (always added for analysis) ----
        base_report = {
            "opt_id": opt_id_str,
            "name": name,
            "ro_name": ro_name,
            "risk_score": risk_score if risk_score is not None else "",
            "max_category_score": "",
            "difference": "",
            "within_tolerance": "",
            "document_category_score": "",
            "work_category_score": "",
            "authentication_category_score": "",
            "suspicious_category_score": "",
            "biometrics_category_score": "",
            "hardware_category_score": "",
            "risk_bucket": risk_bucket,
            "status": "",
            "analyzed_at": now_utc.isoformat(),
        }

        if risk_score is None:
            counters["skipped_no_risk_score"] += 1
            base_report["status"] = "skipped_no_risk_score"
            report_rows.append(base_report)
            continue

        if opt_id_str not in cat_indexed.index:
            counters["skipped_no_match"] += 1
            base_report["status"] = "skipped_no_match"
            report_rows.append(base_report)
            continue

        row = cat_indexed.loc[opt_id_str]

        cat_vals = []
        for col in category_columns:
            v = row.get(col)
            if pd.notna(v):
                try:
                    cat_vals.append(float(v))
                except (TypeError, ValueError):
                    pass

        if not cat_vals:
            counters["skipped_no_cat_values"] += 1
            base_report["status"] = "skipped_no_cat_values"
            report_rows.append(base_report)
            continue

        max_cat = max(cat_vals)
        diff = abs(risk_score - max_cat)
        within_tol = 1 if diff <= TOLERANCE else 0
        counters["processed"] += 1

        def _safe(c):
            v = row.get(c)
            try:
                return float(v) if pd.notna(v) else 0.0
            except (TypeError, ValueError):
                return 0.0

        doc_score    = _safe("document_category_score_v2")
        work_score   = _safe("work_category_score_v2")
        auth_score   = _safe("auth_category_score_v2")
        susp_score   = _safe("sustxn_category_score_v2")
        bio_score    = _safe("bio_category_score_v2")
        hw_score     = _safe("hardware_category_score_v2")

        # ---- ALWAYS push — no tolerance gate ----
        rows_to_insert.append([
            ro_name,
            opt_id_str,
            doc_score,
            work_score,
            auth_score,
            susp_score,
            bio_score,
            hw_score,
            now_utc,
        ])
        counters["pushed"] += 1

        # ---- Enrich detailed report row ----
        base_report.update({
            "max_category_score": max_cat,
            "difference": diff,
            "within_tolerance": within_tol,
            "document_category_score": doc_score,
            "work_category_score": work_score,
            "authentication_category_score": auth_score,
            "suspicious_category_score": susp_score,
            "biometrics_category_score": bio_score,
            "hardware_category_score": hw_score,
            "status": "pushed",
        })
        report_rows.append(base_report)

    # ---- Insert ALL rows into ClickHouse (fixed original schema) ----
    if rows_to_insert:
        try:
            ch_client.insert(
                "operator360.risk_analysis",
                rows_to_insert,
                column_names=[
                    "ro_name",
                    "opt_id",
                    "document_category_score",
                    "work_category_score",
                    "authentication_category_score",
                    "suspicious_category_score",
                    "biometrics_category_score",
                    "hardware_category_score",
                    "updated_at",
                ],
            )
            logger.info(f"Inserted {len(rows_to_insert)} rows into operator360.risk_analysis")
        except Exception:
            logger.exception("ClickHouse insert failed.")
            raise
    else:
        logger.info("No rows matched for insertion into ClickHouse.")

    # ---- Save detailed CSV report ----
    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    report_df = pd.DataFrame(report_rows)
    report_df.to_csv(report_path, index=False)
    logger.info(f"Report saved to {report_path} ({len(report_df)} rows)")

    logger.info(f"Evaluate summary: {counters}")
    return {**counters, "report_path": report_path}


# --------------------------------------------------------------------------- #
# Airflow 3 task callables
# --------------------------------------------------------------------------- #
def _task_fetch_operators(**context):
    """Pull operator risk metadata from MySQL opt_master."""
    operators = fetch_operators()
    logger.info(f"Fetched {len(operators)} operators from MySQL opt_master.")
    return operators


def _task_fetch_category_scores(**context):
    """Pull the latest category scores per entity from Trino."""
    df = fetch_category_scores()
    if df is None:
        logger.warning("Trino returned no category scores.")
        return None
    logger.info(f"Fetched category scores for {len(df)} entities from Trino.")
    return df


def _task_evaluate_and_push(**context):
    """Join MySQL + Trino data, ALWAYS push to ClickHouse, save CSV report."""
    ti = context["ti"]
    operators = ti.xcom_pull(task_ids="fetch_operators")
    category_scores = ti.xcom_pull(task_ids="fetch_category_scores")

    ts = datetime.now(ZoneInfo("UTC")).strftime("%Y%m%d_%H%M%S")
    report_path = os.path.join(REPORT_DIR, f"risk_analysis_{ts}.csv")

    if not operators:
        logger.warning("No operators fetched; skipping evaluation.")
        os.makedirs(REPORT_DIR, exist_ok=True)
        pd.DataFrame().to_csv(report_path, index=False)
        return {"processed": 0, "pushed": 0, "report_path": report_path}

    ch_client = clickhouse_connect.get_client(
        host=CH_HOST,
        port=8123,
        database=CH_DATABASE,
        username=CH_USER,
        password=CH_PASSWORD,
    )

    try:
        results = evaluate(operators, category_scores, ch_client, report_path)
        logger.info(f"Final evaluation results: {results}")
        return results
    finally:
        try:
            ch_client.close()
        except Exception:
            pass


def _task_send_report_email(**context):
    """Email the saved CSV report using Airflow's default SMTP configuration."""
    ti = context["ti"]
    eval_results = ti.xcom_pull(task_ids="evaluate_and_push")

    report_path = eval_results.get("report_path") if eval_results else None

    if not report_path or not os.path.exists(report_path):
        logger.warning(f"Report file not found at {report_path}; cannot email.")
        return

    subject = (
        f"Operator Risk Analysis Report — "
        f"{datetime.now(ZoneInfo('UTC')).strftime('%Y-%m-%d %H:%M UTC')}"
    )

    pushed = eval_results.get("pushed", 0) if eval_results else 0
    processed = eval_results.get("processed", 0) if eval_results else 0
    skipped_no_match = eval_results.get("skipped_no_match", 0) if eval_results else 0
    skipped_no_risk = eval_results.get("skipped_no_risk_score", 0) if eval_results else 0
    skipped_no_cat = eval_results.get("skipped_no_cat_values", 0) if eval_results else 0

    html_content = f"""
    <html>
      <body>
        <h2>Operator Risk Analysis Report</h2>
        <p>Generated at: {datetime.now(ZoneInfo('UTC')).isoformat()}</p>
        <h3>Summary</h3>
        <table border="1" cellpadding="5" cellspacing="0">
          <tr><td>Processed</td><td>{processed}</td></tr>
          <tr><td>Pushed to ClickHouse</td><td>{pushed}</td></tr>
          <tr><td>Skipped (no Trino match)</td><td>{skipped_no_match}</td></tr>
          <tr><td>Skipped (no risk_score)</td><td>{skipped_no_risk}</td></tr>
          <tr><td>Skipped (no category values)</td><td>{skipped_no_cat}</td></tr>
        </table>
        <p>The full CSV report is attached.</p>
      </body>
    </html>
    """

    if _airflow_send_email is not None:
        try:
            _airflow_send_email(
                to=EMAIL_RECIPIENTS,
                subject=subject,
                content=html_content,
                files=[report_path],
            )
            logger.info(f"Report emailed to {EMAIL_RECIPIENTS}")
        except Exception:
            logger.exception("Failed to send email report.")
            raise
    else:
        logger.warning(
            "Airflow send_email utility is not available. "
            "Configure the SMTP backend in airflow.cfg to enable email reports."
        )
        
    try:
    
        send_zoho_cliq_alert(subject,html_content,report_path)
    except Exception as e:
        logger.exception(f"Error while sending the zoho cliq alert: {e}")


# --------------------------------------------------------------------------- #
# DAG definition
# --------------------------------------------------------------------------- #
with DAG(
    dag_id="operator_risk_analysis_to_clickhouse",
    description=(
        "Always push operator risk vs Trino category scores to ClickHouse, "
        "save a detailed CSV report, and email it via Airflow default SMTP"
    ),
    default_args=default_args,
    schedule="0 16 * * *",
    catchup=False,
    max_active_runs=1,
    tags=["operator360", "risk", "clickhouse", "trino", "mysql", "email"],
    doc_md=__doc__,
) as dag:

    fetch_operators_task = PythonOperator(
        task_id="fetch_operators",
        python_callable=_task_fetch_operators,
    )

    fetch_category_scores_task = PythonOperator(
        task_id="fetch_category_scores",
        python_callable=_task_fetch_category_scores,
    )

    evaluate_and_push_task = PythonOperator(
        task_id="evaluate_and_push",
        python_callable=_task_evaluate_and_push,
    )

    send_report_email_task = PythonOperator(
        task_id="send_report_email",
        python_callable=_task_send_report_email,
    )

    # fetch_operators and fetch_category_scores run in parallel;
    # both must complete before evaluate_and_push;
    # the report is emailed after evaluation finishes.
    [fetch_operators_task, fetch_category_scores_task] >> evaluate_and_push_task >> send_report_email_task