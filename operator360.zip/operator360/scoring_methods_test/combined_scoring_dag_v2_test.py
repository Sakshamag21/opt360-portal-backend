# v3: identical to combined_scoring_dag_v2.py except dag_id/job_name, plus a
# new sync_{key} task after every scoring task that gives Layer-3 scores the
# same treatment Layer-1 features already get in v3 (insert_work_features_test.py):
# a last_successful_run update and a ClickHouse push, both keyed by the same
# feature_name/feature_version this DAG already uses - so v3 scores are no
# longer silently sharing v2's untouched last_successful_run/ClickHouse state.
# Feature names/versions are intentionally unchanged from v2 (same underlying
# opt360_features registry rows/Spark scripts) - only the Airflow-level
# bookkeeping around each score is now isolated per operator_dag_manager_v2_test.py.
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from datetime import datetime, timedelta
from airflow.models import Variable
from operator360.signal_mechanism.signals_producer import get_signals_info, push_signals_kafka
import logging
import traceback
from airflow.exceptions import AirflowSkipException
import requests
from airflow.utils.trigger_rule import TriggerRule
import pytz
from kubernetes.client import models as k8s

from operator360.utils.pipeline_status import infer_category, wrap_shell_with_status_report, make_category_gate
from operator360.utils.pipeline_status_v2 import make_idempotency_gate, make_dependency_gate
from operator360.work_category_features.insert_work_features_test import update_last_successful_run
from operator360.clickhouse_serving_layer.opt360_clickhouse_feature_store_test import process_single_feature_to_clickhouse
from operator360.utils.pipeline_alerts_test import notify_failure

logger = logging.getLogger(__name__)

job_name = "combined_risk_scoring_v3_test"
desc = "Run all the combined_risk_score"
signal_api_base_ip="10.10.116.60:8000"

# The Layer-2 DAG each category score here depends on, plus the exact set of
# Layer-2 (feature_name, feature_version) pairs in it that belong to each
# category - mirrors instance_scoring_dag_v2_test.py's FEATURES dict.
# Transcribed rather than imported: importing another DAG file's module would
# re-execute its `with DAG(...)` block a second time at parse time.
LAYER2_DAG_ID_V3 = "instance_risk_scoring_v3_test"
CATEGORY_TO_LAYER2_SCORES = {
    "auth": [
        ("auth_failure_ratio_score", 2),
        ("auth_oddhour_txn_score", 2),
    ],
    "bio": [
        ("bio_mfc_fraud_score", 2),
        ("bio_mfc_fraud_zscore", 2),
        ("bio_sfc_fraud_zscore", 2),
    ],
    "hardware": [
        ("hardware_machine_signature_change_score", 2),
        ("hardware_machine_signature_change_zscore", 2),
        ("hardware_multiple_biodev_score", 2),
        ("hardware_multiple_biodev_zscore", 2),
    ],
    "sustxn": [
        ("sustxn_res_mobilechange_score", 2),
        ("sustxn_res_mobilechange_zscore", 2),
        ("sustxn_oddhour_pkts_score", 2),
        ("sustxn_oddhour_pkts_zscore", 2),
        ("sustxn_outstate_pkts_score", 2),
        ("sustxn_outstate_pkts_zscore", 2),
        ("sustxn_parallel_enrolment_score", 2),
        ("sustxn_res_namechange_score", 2),
        ("sustxn_res_namechange_zscore", 2),
    ],
    "work": [
        ("work_opt_hof_score", 2),
        ("work_pob_declared_score", 2),
        ("work_machine_change_score", 2),
        ("work_opt_machinesync_score", 2),
        ("work_multiple_optname_score", 2),
        ("work_multiple_optname_zscore", 2),
        ("work_machine_change_zscore", 2),
        ("work_opt_machinesync_zscore", 2),
        ("work_pob_declared_zscore", 2),
        ("work_opt_hof_zscore", 2),
    ],
}


custom_toleration = k8s.V1Toleration(
    key="strot",
    operator='Equal',
    value='true',
    effect='NoSchedule'
)



FEATURES={
    "work_category_score":{
        "feature_name":"work_category_score",
        "feature_version":2,
        "feature_id":"work_category_score_v2",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "bio_category_score":{
        "feature_name":"bio_category_score",
        "feature_version":2,
        "feature_id":"bio_category_score_v2",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "hardware_category_score":{
        "feature_name":"hardware_category_score",
        "feature_version":2,
        "feature_id":"hardware_category_score_v2",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "sustxn_category_score":{
        "feature_name":"sustxn_category_score",
        "feature_version":2,
        "feature_id":"sustxn_category_score_v2",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "auth_category_score":{
        "feature_name":"auth_category_score",
        "feature_version":2,
        "feature_id":"auth_category_score_v2",
        "dependencies":[],
        "signal_exists":False,
        "is_daily":True
    },
    "risk_score":{
        "feature_name":"risk_score",
        "feature_version":3,
        "feature_id":"risk_score_v3",
        # Waits on the 5 category-score tasks in THIS same DagRun (plain
        # intra-DAG task dependency via the generic wiring below, not an
        # S3 dependency-gate lookup - they're siblings in one run already).
        "dependencies":["work_category_score","bio_category_score","hardware_category_score","sustxn_category_score","auth_category_score"],
        "signal_exists":False,
        "is_daily":True
    }

}


def run_signals(feature_id):
    try:
        res_try=get_signals_info(feature_id)
        for signal_metadata in res_try:
            push_signals_kafka(signal_metadata)
    except Exception as e:
        print(f"Error in generating signal for feature id : {feature_id}, error: {e}")


# NEW (v3): gives every score the same last_successful_run + ClickHouse
# treatment insert_work_features_test.py already gives Layer-1 features -
# without this, v3 scores were reading/writing the exact same untouched
# state v2 scores use, so they always came out identical to v2.
def sync_feature_to_store(feature_name, feature_version, run_date):
    task_logger = logging.getLogger(f"sync {feature_name}:v{feature_version}")
    try:
        update_last_successful_run(feature_name, feature_version, run_date)
        process_single_feature_to_clickhouse(
            feature_name=feature_name,
            feature_version=feature_version,
            run_date=run_date,
        )
        task_logger.info(
            "Synced %s v%s for %s to ClickHouse and updated last_successful_run",
            feature_name, feature_version, run_date,
        )
    except Exception:
        error_msg = f"Score sync failed for {feature_name} v{feature_version}:\n{traceback.format_exc()}"
        task_logger.error(error_msg)
        notify_failure(feature_name, "Score Sync Error", error_msg)
        raise


default_args = {
    "owner": "Piyush Singh",
    "depends_on_past": False,
    "start_date": datetime(2026, 5, 12),
    "execution_timeout": timedelta(minutes=20),
    "email": ["techexe11.yp26@uidai.net.in"],
    "email_on_failure": True,
    "email_on_retry": True,
    "retries": 1,
}

with DAG(
    dag_id=job_name,
    default_args=default_args,
    description=desc,
    schedule="0 7 * * *",  # triggered only by controller_pipeline_v3
    catchup=False,
    max_active_runs=3,
    max_active_tasks=1,
    tags=["Operator360","Category Level Scoring","v3"]
) as dag:
    tasks = {}
    category_gates = {}
    idempotency_gates = {}  # key -> gate that skips this task if it already succeeded today

    for key, cfg in FEATURES.items():
        feature_category = infer_category(key)  # None for risk_score - no gate, no skip
        task_id = f'task-id-{cfg["feature_name"]}-{cfg["feature_version"]}'
        inner_cmd = f"""python3 -c "import boto3;session=boto3.session.Session(aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4');s3_client=session.client('s3',endpoint_url='http://10.10.103.12:425');s3_client.download_file('prd-bi-data-platform-uploads','sparkjobs/operator360/category_risk_scoring_combined/head_combined_risk_scoring.py','/tmp/head_combined_risk_scoring.py')" && python3 /tmp/head_combined_risk_scoring.py {cfg["feature_name"]} {cfg["feature_version"]}"""
        task = KubernetesPodOperator(
            namespace='strot-spark',
            service_account_name='strot-service-account',
            image='harbor-registry-prod.uidai.gov.in/data-platform/pyspark_duckdb:4.0.7',
            config_file='/opt/airflow/dags/gpu_kubeconfig_hdc',
            name= f'zzzz-{cfg["feature_name"]}-{cfg["feature_version"]}',
            task_id=task_id,
            cmds=["/bin/bash","-c"],
            arguments=[
                wrap_shell_with_status_report(inner_cmd, dag_id=job_name, task_key=task_id, category=feature_category)
            ],
            env_vars={
                "PIPELINE_RUN_ID": "{{ dag_run.conf.get('pipeline_run_id') or run_id }}",
                "TASK_LOG_URL": "{{ ti.log_url }}",
            },
            container_resources=k8s.V1ResourceRequirements(
                requests={"cpu": "1", "memory": "2Gi"},
                limits={"cpu": "1", "memory": "2Gi"}
            ),
            tolerations=[custom_toleration],
            in_cluster=False,
            get_logs=True,
            log_events_on_failure=True,
        )
        tasks[key] = task

        # A task should succeed at most once a day: if a same-day cascade
        # re-triggers this DAG (necessarily including every category valid
        # today, not just a newly-recovered one - see
        # _cascade_layer2_layer3()'s docstring in operator_dag_manager_v2.py
        # for why), this skips any category/risk_score task that already
        # reported success for today's pipeline_run_id instead of
        # re-running the Spark job and appending a duplicate score row.
        idempotency_gate = make_idempotency_gate(f"gate_dup_{task_id}", dag_id=job_name, task_key=task_id)
        idempotency_gates[key] = idempotency_gate
        idempotency_gate >> task

        # NEW (v3): after the Spark job appends today's score row, push it to
        # ClickHouse and record last_successful_run - same two calls
        # insert_work_features_test.py makes per-day for Layer-1 features.
        # Default trigger_rule (all_success) means this is skipped for free
        # whenever `task` itself was skipped by the idempotency/category gate.
        sync_task = PythonOperator(
            task_id=f"sync_{key}",
            python_callable=sync_feature_to_store,
            op_kwargs={
                "feature_name": cfg["feature_name"],
                "feature_version": cfg["feature_version"],
                "run_date": "{{ data_interval_start | ds }}",
            },
        )
        tasks[f"sync_{key}"] = sync_task
        task >> sync_task

        # A category score genuinely does need every one of its category's
        # Layer-2 scores (it's a rollup, not a single-feature read like
        # Layer 2's own scores) - but that's "all of this category's Layer-2
        # scores succeeded", not "the controller's valid_categories conf says
        # this category passed Layer 1". Gate on the former directly instead:
        # risk_score itself skips this (feature_category is None for it) and
        # depends on its 5 sibling tasks within this same DagRun instead (see
        # its "dependencies" entry above).
        if feature_category and feature_category in CATEGORY_TO_LAYER2_SCORES:
            deps = [
                (LAYER2_DAG_ID_V3, f"task-id-{name}-{version}")
                for name, version in CATEGORY_TO_LAYER2_SCORES[feature_category]
            ]
            dep_gate = make_dependency_gate(f"gate_dep_{key}", dependencies=deps)
            dep_gate >> idempotency_gate
        elif feature_category:
            if feature_category not in category_gates:
                category_gates[feature_category] = make_category_gate(f"gate_{feature_category}", feature_category)
            category_gates[feature_category] >> idempotency_gate

        if cfg['signal_exists']:
            signal_task = PythonOperator(
                task_id=f"signal_{key}",
                python_callable=run_signals,
                op_kwargs={
                    "feature_id": cfg["feature_id"]
                },
            )
            tasks[f"signals_{key}"] = signal_task

    # Apply dependencies defined in FEATURES
    for key, cfg in FEATURES.items():
        if "dependencies" in cfg and cfg["dependencies"]:
            for dep in cfg["dependencies"]:
                if dep in tasks:
                    tasks[dep] >> idempotency_gates[key]

        if "signal_exists" in cfg and cfg["signal_exists"]:
            if f"signals_{key}" in tasks:
                tasks[key] >> tasks[f"signals_{key}"]

    # Sequential execution with independence between groups
    task_list = list(tasks.values())

    # Track which tasks already have upstream dependencies
    tasks_with_dependencies = set()
    for key, cfg in FEATURES.items():
        if "dependencies" in cfg and cfg["dependencies"]:
            tasks_with_dependencies.add(tasks[key])

        # Mark signal tasks (they depend on their feature task)
        if cfg['signal_exists'] and f"signals_{key}" in tasks:
            tasks_with_dependencies.add(tasks[f"signals_{key}"])

    # Chain tasks sequentially, but use ALL_DONE for tasks without explicit dependencies
    # for i in range(len(task_list) - 1):
    #     current_task = task_list[i]
    #     next_task = task_list[i + 1]

    #     if next_task not in tasks_with_dependencies:
    #         next_task.trigger_rule = TriggerRule.ALL_DONE

    #     current_task >> next_task
