import logging
import smtplib
import os
import json
import time
import boto3
import requests
import urllib3
import traceback
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
from collections import defaultdict
from datetime import datetime, timezone

# Disable SSL warnings since we are adding verify=False to bypass corporate proxy inspection
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

# --- Email Configuration ---
SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25
SENDER_EMAIL = "airflow@uidai.net.in"
ALERT_RECIPIENTS = ["techexe11.yp26@uidai.net.in"]

# --- Zoho Cliq Configuration ---
ZOHO_CLIQ_WEBHOOK_URL = "https://chat.uidai.gov.in/api/v2/bots/optnotifications/incoming?zapikey=1001.cb6c531ed8e5dfa2d79138ea6f227a11.fde5bcd85bf984e4b5c34bd0383106b9&channel=dataplatformtesting&dc=hdc"
ZOHO_CLIQ_TEXT_LIMIT = 9000  # Safe margin under Zoho's 10000-char hard limit

# --- Network Proxy Configuration ---
PROXY_URL = "http://10.10.16.28:3128"
PROXIES = {"http": PROXY_URL, "https": PROXY_URL}

# --- Ceph S3 Configuration ---
CEPH_ENDPOINT_URL = "http://10.10.103.12:425"
CEPH_ACCESS_KEY = "9S0KLIQO7T2XCNGH4P4A"
CEPH_SECRET_KEY = "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4"
CEPH_BUCKET_NAME = "prd-bi-data-platform-test"
CEPH_CACHE_PREFIX = "cache/airflow/operator360"

# FIX: Define the actual Airflow IP to replace localhost in log links
AIRFLOW_BASE_IP = "10.10.118.36"

def _get_s3_client():
    return boto3.client('s3', endpoint_url=CEPH_ENDPOINT_URL, aws_access_key_id=CEPH_ACCESS_KEY, aws_secret_access_key=CEPH_SECRET_KEY)

def _get_today_error_queue_key():
    today_str = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    return f"{CEPH_CACHE_PREFIX}/error_queue/{today_str}_errors.json"

def _send_cliq_payload(payload: dict):
    """Centralized, robust function to send payloads to Zoho Cliq."""
    # 1. Clear proxy environment variables that Airflow might have set globally
    os.environ.pop("HTTP_PROXY", None)
    os.environ.pop("http_proxy", None)
    os.environ.pop("HTTPS_PROXY", None)
    os.environ.pop("https_proxy", None)
    
    try:
        # 2. Use data=payload (form-urlencoded) instead of json=payload 
        # because the Deluge script uses params.get("text") which expects form-data.
        response = requests.post(
            ZOHO_CLIQ_WEBHOOK_URL,
            data=payload,
            proxies=PROXIES,
            timeout=15,
            verify=False
        )
        if response.status_code != 200:
            logger.error(f"Zoho Cliq alert failed. Status: {response.status_code}, Response: {response.text}")
        else:
            logger.info("Zoho Cliq alert sent successfully.")
    except Exception as e:
        logger.error(f"Failed to send Zoho Cliq alert: {e}\n{traceback.format_exc()}")
def _chunk_text(text: str, max_len: int = ZOHO_CLIQ_TEXT_LIMIT):
    """
    Split a long string into chunks <= max_len characters.
    Tries to split on newline boundaries to keep formatting clean.
    """
    if len(text) <= max_len:
        return [text]

    chunks = []
    current = ""
    for line in text.split("\n"):
        # If a single line itself is longer than max_len, hard-split it
        if len(line) > max_len:
            if current:
                chunks.append(current)
                current = ""
            for i in range(0, len(line), max_len):
                chunks.append(line[i:i + max_len])
            continue

        # If adding this line would exceed the limit, flush current chunk
        if len(current) + len(line) + 1 > max_len:
            chunks.append(current)
            current = line
        else:
            current = current + "\n" + line if current else line

    if current:
        chunks.append(current)
    return chunks

def _send_cliq_text_safe(text: str):
    """
    Send text to Zoho Cliq, automatically splitting into multiple messages
    if it exceeds the 10,000-character limit.
    """
    chunks = _chunk_text(text, ZOHO_CLIQ_TEXT_LIMIT)
    total = len(chunks)
    for idx, chunk in enumerate(chunks, start=1):
        payload_text = chunk
        if total > 1:
            payload_text = f"(Part {idx}/{total})\n" + chunk
        _send_cliq_payload({"text": payload_text})
        
        # FIX: Add a 1-second delay between chunks to avoid Zoho Cliq API rate limits
        if total > 1 and idx < total:
            time.sleep(1)

def log_error_to_s3(feature_name: str, error_type: str, error_details: str, log_url: str = None):
    s3_client = _get_s3_client()
    s3_key = _get_today_error_queue_key()
    
    error_payload = {
        "feature_name": feature_name,
        "error_type": error_type,
        "error_details": error_details,
        "log_url": log_url,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    
    try:
        existing_data = []
        try:
            response = s3_client.get_object(Bucket=CEPH_BUCKET_NAME, Key=s3_key)
            content = response['Body'].read().decode('utf-8')
            existing_data = json.loads(content)
            if not isinstance(existing_data, list):
                existing_data = [existing_data]
        except s3_client.exceptions.NoSuchKey:
            existing_data = []
        except Exception as read_err:
            logger.error(f"Could not read existing error queue. Overwriting. Error: {read_err}")
            existing_data = []

        existing_data.append(error_payload)
        
        s3_client.put_object(
            Bucket=CEPH_BUCKET_NAME,
            Key=s3_key,
            Body=json.dumps(existing_data, indent=4, default=str),
            ContentType='application/json'
        )
        logger.info(f"Error logged to S3 queue: s3://{CEPH_BUCKET_NAME}/{s3_key}")
    except Exception as e:
        logger.error(f"Failed to log error to S3: {e}")
        # Fallback to immediate alerts if S3 fails completely
        subject = f"{error_type} - Feature: {feature_name}"
        safe_details = (error_details or "")[:8000]
        send_pipeline_alert(subject, safe_details)
        send_zoho_cliq_alert(subject, safe_details)

# def process_and_send_consolidated_alerts():
#     s3_client = _get_s3_client()
#     s3_key = _get_today_error_queue_key()
    
#     try:
#         response = s3_client.get_object(Bucket=CEPH_BUCKET_NAME, Key=s3_key)
#         content = response['Body'].read().decode('utf-8')
#         errors = json.loads(content)
        
#         if not errors:
#             logger.info("No errors found in the S3 queue. No consolidated alert sent.")
#             return
            
#         grouped_errors = defaultdict(list)
        
#         for error_data in errors:
#             error_type = error_data.get("error_type", "Unknown Error")
#             feature_name = error_data.get("feature_name", "Unknown Feature")
#             error_details = error_data.get("error_details", "")
#             log_url = error_data.get("log_url", "")
#             grouped_errors[error_type].append({"feature": feature_name, "details": error_details, "log_url": log_url})
            
#         html_body = "<html><body style='font-family: Arial, sans-serif; color: #333;'>"
#         html_body += "<h2 style='color: #d9534f;'>Consolidated Pipeline Alert</h2>"
#         html_body += f"<p>The following {len(errors)} features failed during the recent pipeline run:</p><hr>"
        
#         for error_type, features in grouped_errors.items():
#             html_body += f"<h3 style='color: #333;'>⚠️ {error_type} ({len(features)} features affected)</h3>"
#             html_body += "<ul>"
#             for item in features:
#                 short_details = item['details'][:500] + "..." if len(item['details']) > 500 else item['details']
#                 log_html = f" (<a href='{item['log_url']}'>View Logs</a>)" if item.get('log_url') else ""
#                 html_body += f"<li><strong>{item['feature']}</strong>{log_html}<br><pre style='font-size: 12px; background: #f9f9f9; padding: 5px;'>{short_details}</pre></li>"
#             html_body += "</ul>"
            
#         html_body += "<hr><p style='font-size: 12px; color: #888;'>This is an automated consolidated alert.</p></body></html>"
        
#         subject = f"Operator360 Pipeline Alert: {len(errors)} Failures Across {len(grouped_errors)} Categories"
        
#         # Send Consolidated Email
#         msg = MIMEMultipart("alternative")
#         msg["From"] = SENDER_EMAIL
#         msg["To"] = ", ".join(ALERT_RECIPIENTS)
#         msg["Subject"] = subject
#         msg.attach(MIMEText(html_body, "html"))
        
#         server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
#         server.sendmail(SENDER_EMAIL, ALERT_RECIPIENTS, msg.as_string())
#         server.quit()
#         logger.info(f"Consolidated alert email sent for {len(errors)} errors.")
        
#         # FIX: Send a concise Zoho Cliq alert to avoid hitting character limits
#         # FIX: Send Zoho Cliq alert with ONLY Feature Name and Log URL beside it
#         cliq_text = f"🚨 *Consolidated Pipeline Alert*\n{len(errors)} Failures Across {len(grouped_errors)} Categories.\n\n"
#         for error_type, features in grouped_errors.items():
#             cliq_text += f"*{error_type}* ({len(features)} features):\n"
#             for item in features:
#                 log_url = item.get('log_url', '')
#                 if log_url:
#                     # Puts the feature name and the raw log URL right beside it
#                     cliq_text += f"  - {item['feature']} - {log_url}\n"
#                 else:
#                     cliq_text += f"  - {item['feature']}\n"
#             cliq_text += "\n"
            
#         # Safely send (auto-chunks if > 10000 chars)
#         _send_cliq_text_safe(cliq_text)

#         # Clear the S3 queue
#         s3_client.delete_object(Bucket=CEPH_BUCKET_NAME, Key=s3_key)
#         logger.info("S3 error queue cleared successfully.")
        
#     except s3_client.exceptions.NoSuchKey:
#         logger.info("No errors found in the S3 queue (File does not exist). No consolidated alert sent.")
#     except Exception as e:
#         logger.error(f"Failed to process consolidated alerts: {e}\n{traceback.format_exc()}")


def process_and_send_consolidated_alerts():
    s3_client = _get_s3_client()
    s3_key = _get_today_error_queue_key()

    try:
        response = s3_client.get_object(Bucket=CEPH_BUCKET_NAME, Key=s3_key)
        content = response['Body'].read().decode('utf-8')
        errors = json.loads(content)

        if not errors:
            logger.info("No errors found in the S3 queue. No consolidated alert sent.")
            return

        # ------------------------------------------------------------------
        # 1. Build the consolidated HTML email (grouped by error_type) — unchanged
        # ------------------------------------------------------------------
        grouped_errors = defaultdict(list)
        for error_data in errors:
            error_type = error_data.get("error_type", "Unknown Error")
            feature_name = error_data.get("feature_name", "Unknown Feature")
            error_details = error_data.get("error_details", "")
            log_url = error_data.get("log_url", "")
            grouped_errors[error_type].append(
                {"feature": feature_name, "details": error_details, "log_url": log_url}
            )

        html_body = "<html><body style='font-family: Arial, sans-serif; color: #333;'>"
        html_body += "<h2 style='color: #d9534f;'>Consolidated Pipeline Alert</h2>"
        html_body += f"<p>The following {len(errors)} features failed during the recent pipeline run:</p><hr>"

        for error_type, features in grouped_errors.items():
            html_body += f"<h3 style='color: #333;'>⚠️ {error_type} ({len(features)} features affected)</h3>"
            html_body += "<ul>"
            for item in features:
                short_details = item['details'][:500] + "..." if len(item['details']) > 500 else item['details']
                log_html = f" (<a href='{item['log_url']}'>View Logs</a>)" if item.get('log_url') else ""
                html_body += (
                    f"<li><strong>{item['feature']}</strong>{log_html}<br>"
                    f"<pre style='font-size: 12px; background: #f9f9f9; padding: 5px;'>{short_details}</pre></li>"
                )
            html_body += "</ul>"

        html_body += "<hr><p style='font-size: 12px; color: #888;'>This is an automated consolidated alert.</p></body></html>"

        subject = f"Operator360 Pipeline Alert: {len(errors)} Failures Across {len(grouped_errors)} Categories"

        msg = MIMEMultipart("alternative")
        msg["From"] = SENDER_EMAIL
        msg["To"] = ", ".join(ALERT_RECIPIENTS)
        msg["Subject"] = subject
        msg.attach(MIMEText(html_body, "html"))

        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(SENDER_EMAIL, ALERT_RECIPIENTS, msg.as_string())
        server.quit()
        logger.info(f"Consolidated alert email sent for {len(errors)} errors.")

        # ------------------------------------------------------------------
        # 2. Zoho Cliq alert — chunked by feature_name.split('_')[0]
        #    One Cliq message per feature-prefix group instead of one big
        #    message split purely on character count.
        # ------------------------------------------------------------------
        grouped_by_prefix = defaultdict(list)
        for error_data in errors:
            feature_name = error_data.get("feature_name", "Unknown Feature") or "Unknown Feature"
            # Use the portion before the first underscore as the grouping key.
            # If there's no underscore, fall back to the whole feature_name.
            prefix = feature_name.split('_')[0] if '_' in feature_name else feature_name
            grouped_by_prefix[prefix].append(error_data)

        total_prefixes = len(grouped_by_prefix)
        logger.info(
            f"Sending {total_prefixes} Zoho Cliq messages (chunked by feature prefix)."
        )

        for idx, (prefix, prefix_errors) in enumerate(grouped_by_prefix.items(), start=1):
            # Sub-group the prefix's errors by error_type for readability
            sub_grouped = defaultdict(list)
            for error_data in prefix_errors:
                et = error_data.get("error_type", "Unknown Error")
                sub_grouped[et].append(error_data)

            cliq_text = (
                f"🚨 *Consolidated Pipeline Alert* (Group {idx}/{total_prefixes})\n"
                f"Feature Prefix: *{prefix}* — {len(prefix_errors)} failure(s)\n\n"
            )

            for error_type, items in sub_grouped.items():
                cliq_text += f"*{error_type}* ({len(items)} features):\n"
                for item in items:
                    feature = item.get('feature_name', 'Unknown Feature')
                    log_url = item.get('log_url', '')
                    if log_url:
                        cliq_text += f"  - {feature} - {log_url}\n"
                    else:
                        cliq_text += f"  - {feature}\n"
                cliq_text += "\n"

            # Safety net: if a single prefix group still exceeds the 9000-char
            # limit, _send_cliq_text_safe will further split it.
            _send_cliq_text_safe(cliq_text)

            # Throttle between prefix groups to avoid Zoho Cliq rate limits
            if idx < total_prefixes:
                time.sleep(1)

        # ------------------------------------------------------------------
        # 3. Clear the S3 queue
        # ------------------------------------------------------------------
        s3_client.delete_object(Bucket=CEPH_BUCKET_NAME, Key=s3_key)
        logger.info("S3 error queue cleared successfully.")

    except s3_client.exceptions.NoSuchKey:
        logger.info("No errors found in the S3 queue (File does not exist). No consolidated alert sent.")
    except Exception as e:
        logger.error(f"Failed to process consolidated alerts: {e}\n{traceback.format_exc()}")

def send_zoho_cliq_alert(subject: str, body: str):
    """Sends an immediate alert to Zoho Cliq (used only if S3 logging fails)."""
    # Plain text only - Zoho Cliq 'text' field is not HTML-parsed
    # Truncate body defensively to avoid huge single payloads
    max_body = 8000
    if len(body) > max_body:
        body = body[:max_body] + "\n...[truncated]"
    text = f"🚨 *Pipeline Alert: {subject}*\n\n{body}"
    _send_cliq_text_safe(text)

def send_pipeline_alert(subject: str, body: str):
    """Sends an immediate HTML email (used only if S3 logging fails)."""
    msg = MIMEMultipart("alternative")
    msg["From"] = SENDER_EMAIL
    msg["To"] = ", ".join(ALERT_RECIPIENTS)
    msg["Subject"] = f"[Operator360 Pipeline Alert] {subject}"
    html_content = f"<html><body><h2>Pipeline Alert: {subject}</h2><pre>{body}</pre></body></html>"
    msg.attach(MIMEText(html_content, "html"))
    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(SENDER_EMAIL, ALERT_RECIPIENTS, msg.as_string())
        server.quit()
    except Exception as e:
        logger.error(f"Failed to send alert email: {e}")

def notify_failure(feature_name: str, error_type: str, error_details: str, log_url: str = None):
    # FIX: Replace localhost with the actual Airflow Server IP so links work in emails
    if log_url:
        log_url = log_url.replace("localhost", AIRFLOW_BASE_IP)
        
    subject = f"{error_type} - Feature: {feature_name}"
    if error_type == "Raw Data Missing":
        body = f"Raw data is missing for feature '{feature_name}'.\n\nDetails:\n{error_details}"
    elif error_type == "Query Timeout":
        body = f"Query for feature '{feature_name}' exceeded the 30-minute timeout limit.\n\nDetails:\n{error_details}"
    elif error_type == "Trino Node Failure":
        body = f"Trino connection or execution failed for feature '{feature_name}'.\n\nDetails:\n{error_details}"
    else:
        body = f"An unhandled error occurred for feature '{feature_name}'.\n\nDetails:\n{error_details}"
        
    log_error_to_s3(feature_name, error_type, body, log_url)

def execute_trino_with_timeout(trino_func, query: str, feature_name: str, timeout_seconds: int = 1800, log_url: str = None):
    # FIX: Also replace localhost here so immediate fallback alerts have the correct IP
    if log_url:
        log_url = log_url.replace("localhost", AIRFLOW_BASE_IP)
        
    try:
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(trino_func, query)
            result = future.result(timeout=timeout_seconds)
            if isinstance(result, dict) and result.get("success") == 0:
                err_msg = result.get("msg", "Unknown Trino error")
                if "Connection refused" in err_msg or "node" in err_msg.lower() or "memory" in err_msg.lower():
                    notify_failure(feature_name, "Trino Node Failure", err_msg, log_url)
                else:
                    notify_failure(feature_name, "Query Execution Error", err_msg, log_url)
                raise RuntimeError(f"Trino query failed: {err_msg}")
            return result
    except FutureTimeoutError:
        error_msg = f"Query took longer than {timeout_seconds} seconds (30 minutes) and was aborted.\nQuery: {query}"
        notify_failure(feature_name, "Query Timeout", error_msg, log_url)
        raise RuntimeError(error_msg)
    except Exception as e:
        error_msg = f"Unexpected error during query execution: {str(e)}\n{traceback.format_exc()}"
        notify_failure(feature_name, "Unexpected Error", error_msg, log_url)
        raise