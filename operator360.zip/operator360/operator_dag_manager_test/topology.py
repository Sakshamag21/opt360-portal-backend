"""Static topology/config for the v3 controller (controller_pipeline_v3):
which Layer-1 DAGs feed which category, the Layer-2/3 dag_ids, and the
shared Ceph/Trino connection constants the other modules in this package
need. Split out of the original single-file operator_dag_manager_v2_test.py
so each concern (topology, daily state, DagRun control, reporting, DAG
wiring) lives in its own module instead of one ~900-line file.
"""
from datetime import timedelta

# ─── S3 bucket for daily reports / pending-retry state ───────────────────────
CEPH_ENDPOINT_URL = "http://10.10.103.12:425"
CEPH_ACCESS_KEY = "9S0KLIQO7T2XCNGH4P4A"
CEPH_SECRET_KEY = "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4"
CEPH_BUCKET_NAME = "prd-bi-data-platform-test"
CEPH_CACHE_PREFIX = "cache/airflow/operator360_v3"

# ─── v3 topology (local to this package - v1's pipeline_status.py constants
# are untouched, so v1 is never affected by anything in here) ────────────────
DAG_ID_TO_CATEGORY_V2 = {
    "auth_category_features_v3": "auth",
    "bio_packet_fraud_features_v3": "bio",
    "document_features_combined_v3": "document",
    "hardware_category_features_v3": "hardware",
    "sustxn_category_feature_v3": "sustxn",
    "work_category_feature_daily_v3": "work",
    # "work_category_feature_hourly_v3": "work",
}
CATEGORY_TO_DAG_ID_V2 = {v: k for k, v in DAG_ID_TO_CATEGORY_V2.items()}
LAYER1_DAG_IDS_V2 = list(DAG_ID_TO_CATEGORY_V2)
LAYER2_DAG_ID_V2 = "instance_risk_scoring_v3_test"
LAYER3_DAG_ID_V2 = "combined_risk_scoring_v3_test"

LAYER1_MAX_PARALLEL = 2
LAYER_WAIT_TIMEOUT = timedelta(minutes=180)
LAYER1_PROMOTION_HOUR = 9

# Trino connection used only for the risk_score data-presence check in reporting.py
TRINO_REPORT_HOST = "10.10.116.75"
TRINO_REPORT_PORT = 8080
TRINO_REPORT_USER = "controller_pipeline_v2_report"
