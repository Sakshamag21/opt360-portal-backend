"""v3 controller: same Layer 1 -> 2 -> 3 orchestration as operator_dag_manager.py,
plus a retry mechanism for categories that failed the daily promotion run,
now with a Layer 2/3 retry of its own too. See plan: floating-riding-dolphin.md.

Split into a package (topology.py, daily_state.py, dagrun_control.py,
reporting.py, this file) instead of one ~900-line module - this file only
defines the DAG and its task callables; everything else is imported.

Key difference from v1: a category failing at the promotion tick no longer
means it's done for the day. Every tick for the rest of that calendar day
(IST) - v3 runs every 6 hours - retry_pending_categories re-triggers whatever
Layer-1 category is still pending, and if a retry succeeds, cascades into
re-triggering Layer 2/3 so the category still lands in *today's*
risk_score - not tomorrow's. New in this pass: Layer 2/3 scores get the same
treatment directly (retry_layer2_failures / retry_layer3_failures), instead
of only being retried as a side effect of a Layer-1 cascade - see
dagrun_control.retry_layer_failures_if_any() for why that needed a
day-stable pipeline_run_id to actually work.

This file is entirely standalone from operator_dag_manager.py: separate
dag_ids throughout, so v1 keeps running completely unmodified.
"""
from __future__ import annotations
import logging
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import PythonOperator
from airflow.exceptions import AirflowSkipException

from operator360.utils.pipeline_alerts_test import Operator360SmtpNotifier
from operator360.utils.pipeline_status import read_layer_status, compute_category_verdicts

from operator360.operator_dag_manager_test.topology import (
    CATEGORY_TO_DAG_ID_V2,
    LAYER1_DAG_IDS_V2,
    LAYER1_MAX_PARALLEL,
    LAYER2_DAG_ID_V2,
    LAYER3_DAG_ID_V2,
    LAYER_WAIT_TIMEOUT,
    DAG_ID_TO_CATEGORY_V2,
)
from operator360.operator_dag_manager_test.daily_state import (
    daily_pipeline_run_id,
    read_pending_state,
    write_pending_state,
)
from operator360.operator_dag_manager_test.dagrun_control import (
    clear_failed_tasks_and_wait,
    cascade_layer2_layer3,
    retry_layer_failures_if_any,
)
from operator360.operator_dag_manager_test.reporting import (
    log_category_diagnostics,
    generate_daily_report,
    generate_retry_report,
)

logger = logging.getLogger(__name__)

default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": datetime(2026, 8, 18),
    "on_failure_callback": [
        Operator360SmtpNotifier(subject_prefix="Pipeline Notify Test", logger=logger)
    ],
    # Was retries=0: any transient blip in a controller task itself (an S3
    # hiccup reading pending state, a flaky Trino connect for the risk_score
    # presence check) used to fail the whole tick immediately instead of
    # absorbing it. A short, bounded retry here is cheap insurance - it does
    # NOT change how Layer 1/2/3 failures are handled (that's the
    # judge/retry machinery below, unaffected by this).
    "retries": 2,
    "retry_delay": timedelta(minutes=3),
}

with DAG(
    dag_id="controller_pipeline_v3",
    default_args=default_args,
    description="v3: Layer 1->2->3 orchestrator with retry-until-midnight for Layer 1 "
                "failures every 6 hours, cascading into same-day Layer 2/3 re-runs on a "
                "late success, plus a Layer 2/3 retry of its own each tick.",
    schedule="0 */6 * * *",
    catchup=False,
    max_active_runs=1,
    max_active_tasks=LAYER1_MAX_PARALLEL,
    tags=["controller", "orchestration", "operator360", "v3"],
) as dag:

    start = EmptyOperator(task_id="start")
    end = EmptyOperator(task_id="end", trigger_rule="all_done")
    fail_handler = EmptyOperator(task_id="fail_handler", trigger_rule="one_failed")

    pipeline_run_id_tpl = "{{ run_id }}"

    def _compute_run_mode(**context):
        logical_dt = context.get("data_interval_start")
        if logical_dt is None:
            raise RuntimeError(f"data_interval_start not found in context. Available keys: {list(context.keys())}")
        try:
            if hasattr(logical_dt, "in_timezone"):
                ist_dt = logical_dt.in_timezone("Asia/Kolkata")
            else:
                ist_dt = logical_dt.astimezone(ZoneInfo("Asia/Kolkata"))
        except Exception as e:
            raise RuntimeError(f"Timezone conversion failed. dt={logical_dt!r}, type={type(logical_dt)}, error={e}") from e

        is_daily_run = True
        date_str = ist_dt.strftime("%Y-%m-%d")
        logger.info("Compute Run Mode (v3): logical_dt=%s, IST_date=%s, is_daily_run=%s", logical_dt, date_str, is_daily_run)
        context["ti"].xcom_push(key="is_daily_run", value=is_daily_run)
        # Layer 2/3's ONLY protection against re-appending an already-scored
        # feature - see daily_state.daily_pipeline_run_id for why this has
        # to be stable across today's ticks, not this tick's own run_id.
        context["ti"].xcom_push(key="daily_pipeline_run_id", value=daily_pipeline_run_id(date_str))
        return is_daily_run

    compute_run_mode = PythonOperator(task_id="compute_run_mode", python_callable=_compute_run_mode)

    # ---------------- Layer 1: feature DAGs ----------------
    layer1_triggers = []
    for child_dag_id in LAYER1_DAG_IDS_V2:
        t = TriggerDagRunOperator(
            task_id=f"trigger_layer1_{child_dag_id}",
            trigger_dag_id=child_dag_id,
            conf={
                "pipeline_run_id": pipeline_run_id_tpl,
                "is_daily_run": (
                    "{{ 'true' if ti.xcom_pull(task_ids='compute_run_mode', key='is_daily_run') else 'false' }}"
                ),
            },
            execution_timeout=LAYER_WAIT_TIMEOUT,
            wait_for_completion=True,
            deferrable=False,
            poke_interval=30,
            reset_dag_run=True,
            allowed_states=["success", "failed"],
            failed_states=[],
        )
        layer1_triggers.append(t)
        compute_run_mode >> t
        t >> fail_handler

    def _gate_promotion(**context):
        is_daily_run = context["ti"].xcom_pull(task_ids="compute_run_mode", key="is_daily_run")
        if not is_daily_run:
            raise AirflowSkipException(
                "Not the daily promotion hour - Layer 1 ran for hourly-cadence features only, "
                "skipping judgement and Layer 2/3 this tick"
            )

    gate_promotion = PythonOperator(task_id="gate_promotion", python_callable=_gate_promotion)
    layer1_triggers >> gate_promotion

    def _judge_layer1(**context):
        ti = context["ti"]
        run_id = context["run_id"]
        logical_dt = context["data_interval_start"]
        date_str = logical_dt.astimezone(ZoneInfo("Asia/Kolkata")).strftime("%Y-%m-%d")

        valid_categories = []
        layer1_results = {}
        child_run_ids = {}

        for child_dag_id in LAYER1_DAG_IDS_V2:
            entries = read_layer_status(run_id, child_dag_id)
            verdicts = compute_category_verdicts(entries)
            category = DAG_ID_TO_CATEGORY_V2[child_dag_id]
            is_valid = bool(verdicts.get(category))
            layer1_results[category] = {"valid": is_valid, "reported_features": len(entries)}

            try:
                child_run_ids[category] = ti.xcom_pull(task_ids=f"trigger_layer1_{child_dag_id}")
            except Exception:
                child_run_ids[category] = None

            if is_valid:
                valid_categories.append(category)
            else:
                logger.error("Judge Layer 1 (v3): Category '%s' -> FAILED. Analyzing failures...", category)
                log_category_diagnostics("Layer1", category, child_dag_id, entries)

        ti.xcom_push(key="valid_categories", value=valid_categories)
        ti.xcom_push(key="layer1_results", value=layer1_results)

        state = read_pending_state(date_str)
        if state.get("original_pipeline_run_id") is None:
            state["original_pipeline_run_id"] = run_id
        for category in valid_categories:
            state["categories"].pop(category, None)
            if category not in state["valid_today"]:
                state["valid_today"].append(category)
        for category in set(DAG_ID_TO_CATEGORY_V2.values()) - set(state["valid_today"]):
            entry = state["categories"].setdefault(category, {"attempts": 0})
            entry["attempts"] = entry.get("attempts", 0) + 1
            entry["last_attempt_at"] = datetime.now(ZoneInfo("Asia/Kolkata")).isoformat()
            entry["last_pipeline_run_id"] = run_id
            if child_run_ids.get(category):
                entry["child_dag_run_id"] = child_run_ids[category]
            elif "child_dag_run_id" not in entry:
                logger.error(
                    "Judge Layer 1 (v3): no child_dag_run_id captured for category='%s' - "
                    "retry_pending_categories won't be able to target a clear for it.", category
                )
        write_pending_state(date_str, state)

        logger.info("Layer1 judgement complete (v3) - valid: %s, pending for retry: %s",
                    valid_categories, list(state["categories"].keys()))
        return valid_categories

    judge_layer1 = PythonOperator(task_id="judge_layer1", python_callable=_judge_layer1)
    gate_promotion >> judge_layer1

    def _gate_after_layer1(**context):
        valid_categories = context["ti"].xcom_pull(task_ids="judge_layer1", key="valid_categories") or []
        if not valid_categories:
            raise AirflowSkipException("No categories passed Layer 1 - skipping Layer 2 and Layer 3")

    gate_after_layer1 = PythonOperator(task_id="gate_after_layer1", python_callable=_gate_after_layer1)

    # ---------------- Layer 2: instance scoring ----------------
    trigger_layer2 = TriggerDagRunOperator(
        task_id="trigger_layer2",
        trigger_dag_id=LAYER2_DAG_ID_V2,
        conf={
            "pipeline_run_id": "{{ ti.xcom_pull(task_ids='compute_run_mode', key='daily_pipeline_run_id') }}",
            "valid_categories": "{{ ti.xcom_pull(task_ids='judge_layer1', key='valid_categories') | tojson }}",
        },
        execution_timeout=LAYER_WAIT_TIMEOUT,
        wait_for_completion=True,
        deferrable=False,
        poke_interval=30,
        reset_dag_run=True,
        allowed_states=["success", "failed"],
        failed_states=[],
    )
    trigger_layer2 >> fail_handler

    def _retry_layer2_failures(**context):
        ti = context["ti"]
        logical_dt = context["data_interval_start"]
        date_str = logical_dt.astimezone(ZoneInfo("Asia/Kolkata")).strftime("%Y-%m-%d")
        run_id = ti.xcom_pull(task_ids="trigger_layer2")
        retry_layer_failures_if_any(LAYER2_DAG_ID_V2, run_id, date_str, LAYER_WAIT_TIMEOUT.total_seconds())

    retry_layer2_failures = PythonOperator(
        task_id="retry_layer2_failures", python_callable=_retry_layer2_failures, trigger_rule="all_done",
    )
    trigger_layer2 >> retry_layer2_failures

    def _judge_layer2(**context):
        ti = context["ti"]
        daily_id = ti.xcom_pull(task_ids="compute_run_mode", key="daily_pipeline_run_id")
        layer1_valid = ti.xcom_pull(task_ids="judge_layer1", key="valid_categories") or []

        entries = read_layer_status(daily_id, LAYER2_DAG_ID_V2)
        verdicts = compute_category_verdicts(entries)

        entries_by_category = {}
        for e in entries:
            entries_by_category.setdefault(e.get("category"), []).append(e)

        valid_categories = []
        for category in layer1_valid:
            if verdicts.get(category):
                valid_categories.append(category)
            else:
                logger.error("Judge Layer 2 (v3): Category '%s' -> FAILED. Analyzing failures...", category)
                log_category_diagnostics("Layer2", category, LAYER2_DAG_ID_V2, entries_by_category.get(category, []))

        ti.xcom_push(key="valid_categories", value=valid_categories)
        ti.xcom_push(key="layer2_results", value=verdicts)
        return valid_categories

    judge_layer2 = PythonOperator(task_id="judge_layer2", python_callable=_judge_layer2, trigger_rule="all_done")
    retry_layer2_failures >> judge_layer2

    def _gate_after_layer2(**context):
        valid_categories = context["ti"].xcom_pull(task_ids="judge_layer2", key="valid_categories") or []
        if not valid_categories:
            raise AirflowSkipException("No categories passed Layer 2 - skipping Layer 3")

    gate_after_layer2 = PythonOperator(task_id="gate_after_layer2", python_callable=_gate_after_layer2)

    # ---------------- Layer 3: category scoring ----------------
    trigger_layer3 = TriggerDagRunOperator(
        task_id="trigger_layer3",
        trigger_dag_id=LAYER3_DAG_ID_V2,
        conf={
            "pipeline_run_id": "{{ ti.xcom_pull(task_ids='compute_run_mode', key='daily_pipeline_run_id') }}",
            "valid_categories": "{{ ti.xcom_pull(task_ids='judge_layer2', key='valid_categories') | tojson }}",
        },
        execution_timeout=LAYER_WAIT_TIMEOUT,
        wait_for_completion=True,
        deferrable=False,
        poke_interval=30,
        reset_dag_run=True,
        allowed_states=["success", "failed"],
        failed_states=[],
    )
    trigger_layer3 >> fail_handler

    def _retry_layer3_failures(**context):
        ti = context["ti"]
        logical_dt = context["data_interval_start"]
        date_str = logical_dt.astimezone(ZoneInfo("Asia/Kolkata")).strftime("%Y-%m-%d")
        run_id = ti.xcom_pull(task_ids="trigger_layer3")
        retry_layer_failures_if_any(LAYER3_DAG_ID_V2, run_id, date_str, LAYER_WAIT_TIMEOUT.total_seconds())

    retry_layer3_failures = PythonOperator(
        task_id="retry_layer3_failures", python_callable=_retry_layer3_failures, trigger_rule="all_done",
    )
    trigger_layer3 >> retry_layer3_failures

    # ---------------- Daily Report (promotion tick only) ----------------
    generate_daily_report_task = PythonOperator(
        task_id="generate_daily_report",
        python_callable=generate_daily_report,
        trigger_rule="all_done",
    )

    # ---------------- Retry orchestrator (every tick) ----------------
    def _retry_pending_categories(**context):
        logical_dt = context["data_interval_start"]
        date_str = logical_dt.astimezone(ZoneInfo("Asia/Kolkata")).strftime("%Y-%m-%d")

        state = read_pending_state(date_str)
        pending = state.get("categories", {})
        if not pending:
            logger.info("Retry (v3): nothing pending for %s", date_str)
            return

        original_run_id = state.get("original_pipeline_run_id") or context["run_id"]
        newly_valid = []

        for category in list(pending.keys()):
            child_dag_id = CATEGORY_TO_DAG_ID_V2[category]
            info = pending[category]
            child_dag_run_id = info.get("child_dag_run_id")

            if not child_dag_run_id:
                logger.error(
                    "Retry (v3): no child_dag_run_id recorded for category='%s' (dag=%s) - "
                    "judge_layer1 must not have captured it. Skipping this category this tick; "
                    "it stays pending and will be retried once a run_id is available.",
                    category, child_dag_id,
                )
                continue

            logger.info("Retry (v3): clearing failed tasks on %s/%s (category=%s)",
                        child_dag_id, child_dag_run_id, category)
            clear_failed_tasks_and_wait(child_dag_id, child_dag_run_id, LAYER_WAIT_TIMEOUT.total_seconds())

            entries = read_layer_status(original_run_id, child_dag_id)
            verdicts = compute_category_verdicts(entries)
            is_valid = bool(verdicts.get(category))

            info["attempts"] = info.get("attempts", 0) + 1
            info["last_attempt_at"] = datetime.now(ZoneInfo("Asia/Kolkata")).isoformat()

            if is_valid:
                logger.info("Retry (v3): category '%s' now PASSES.", category)
                newly_valid.append(category)
                pending.pop(category, None)
                if category not in state["valid_today"]:
                    state["valid_today"].append(category)
            else:
                logger.info("Retry (v3): category '%s' still failing, will retry again next tick.", category)
                log_category_diagnostics("Layer1-retry", category, child_dag_id, entries)

        write_pending_state(date_str, state)

        cascade_summary = None
        if newly_valid:
            logger.info("Retry (v3): newly valid this tick: %s - cascading into Layer 2/3", newly_valid)
            cascade_summary = cascade_layer2_layer3(
                state["valid_today"], logical_dt,
                retry_label=original_run_id,
                layer_wait_timeout_seconds=LAYER_WAIT_TIMEOUT.total_seconds(),
            )

        if newly_valid or cascade_summary:
            generate_retry_report(date_str, state, newly_valid, cascade_summary)

    retry_pending_categories = PythonOperator(
        task_id="retry_pending_categories",
        python_callable=_retry_pending_categories,
        trigger_rule="all_done",
        execution_timeout=timedelta(hours=2),
    )

    # ---------------- Wiring ----------------
    start >> compute_run_mode
    judge_layer1 >> gate_after_layer1 >> trigger_layer2
    judge_layer2 >> gate_after_layer2 >> trigger_layer3

    trigger_layer3 >> retry_layer3_failures >> generate_daily_report_task
    fail_handler >> generate_daily_report_task

    # Runs on every tick regardless of promotion-hour outcome
    # (trigger_rule=all_done), independent of whether gate_promotion/
    # judge_layer1/etc. ran, skipped, or failed this tick.
    compute_run_mode >> retry_pending_categories
    generate_daily_report_task >> retry_pending_categories
    retry_pending_categories >> end
