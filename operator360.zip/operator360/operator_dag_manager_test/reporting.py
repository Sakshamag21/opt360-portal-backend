"""Diagnostics and the daily/retry text reports uploaded to S3 - read-only
observability over the S3 status stores plus one Trino risk_score presence
check. No orchestration logic lives here, just reading, formatting, and
uploading.
"""
import logging
import os
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import requests
from trino.dbapi import connect
from airflow.exceptions import AirflowSkipException

from operator360.utils.pipeline_status import read_layer_status
from operator360.operator_dag_manager_test.topology import (
    CEPH_BUCKET_NAME,
    DAG_ID_TO_CATEGORY_V2,
    LAYER1_DAG_IDS_V2,
    LAYER1_PROMOTION_HOUR,
    LAYER2_DAG_ID_V2,
    LAYER3_DAG_ID_V2,
    TRINO_REPORT_HOST,
    TRINO_REPORT_PORT,
    TRINO_REPORT_USER,
)
from operator360.operator_dag_manager_test.daily_state import get_s3_client, daily_pipeline_run_id, read_pending_state

logger = logging.getLogger(__name__)


def log_category_diagnostics(layer_name: str, category: str, dag_id: str, entries: list) -> None:
    """Logs exactly which task(s) caused `category` to be marked invalid in
    this layer, with the error, its type, and a direct link to that task
    instance's Airflow log."""
    logger.error("====== %s FAILURE DIAGNOSTICS for category='%s' (dag=%s) ======",
                 layer_name.upper(), category, dag_id)

    if not entries:
        logger.error(
            "REASON: No S3 status records found for this category. "
            "The DAG likely timed out, was OOM-killed, or crashed before it could write its status to S3. "
            "Check the Airflow task instance logs for the child DAG directly."
        )
        return

    bad_entries = [e for e in entries if e.get("status") != "success"]

    if not bad_entries:
        logger.error(
            "REASON: All reported tasks succeeded, but the verdict still marked this category as invalid. "
            "This usually means a required feature/task didn't run at all (missing from S3 records)."
        )
        logger.info("Raw S3 entries evaluated: %s", entries)
        return

    for e in bad_entries:
        task_key = e.get("task_key", "UNKNOWN_TASK")
        status = e.get("status", "UNKNOWN_STATUS")
        error_type = e.get("error_type", "N/A")
        error_msg = e.get("error", "No error message provided in S3 record.")
        skip_reason = e.get("skip_reason", "")
        log_url = e.get("log_url", "No log URL provided")
        try_num = e.get("try_number", "N/A")

        logger.error("FAILED TASK -> task='%s' | status='%s' | try=%s", task_key, status, try_num)
        if status == "skipped":
            logger.error("SKIP REASON: %s", skip_reason or error_msg)
        else:
            logger.error("ERROR TYPE: %s", error_type)
            logger.error("ERROR MESSAGE: %s", error_msg)
        logger.error("Airflow Log URL: %s", log_url)
        logger.debug("Full raw entry dictionary: %s", e)


def _safe_get(entry, key, default="N/A"):
    if isinstance(entry, dict):
        return entry.get(key, default)
    return default


def safe_read_status(pipeline_run_id, dag_id):
    try:
        entries = read_layer_status(pipeline_run_id, dag_id)
        if not isinstance(entries, list):
            return [{"error": f"Unexpected return type from read_layer_status: {type(entries)}"}]
        return entries
    except Exception as e:
        logger.warning("Daily Report: Failed to read S3 status for %s: %s", dag_id, e)
        return [{"error": f"Failed to read S3 status: {e}"}]


def format_entries_report(entries, indent="  "):
    lines = []
    if not entries:
        lines.append(f"{indent}⚠️  NO S3 STATUS RECORDS FOUND")
        lines.append(f"{indent}    The DAG likely crashed, timed out, or was OOM-killed before writing status to S3.")
        lines.append(f"{indent}    ACTION: Check the child DAG's Airflow task instance logs directly.")
        return lines

    bad_entries = [e for e in entries if _safe_get(e, "status") != "success"]
    good_entries = [e for e in entries if _safe_get(e, "status") == "success"]

    if bad_entries:
        lines.append(f"{indent}Failed/Skipped tasks ({len(bad_entries)}):")
        for e in bad_entries:
            task_key = _safe_get(e, "task_key")
            status = _safe_get(e, "status")
            error_type = _safe_get(e, "error_type")
            error_msg = _safe_get(e, "error", "No error message provided")
            skip_reason = _safe_get(e, "skip_reason")
            log_url = _safe_get(e, "log_url")
            try_num = _safe_get(e, "try_number")

            lines.append(f"{indent}  ✗ Task: {task_key}")
            lines.append(f"{indent}    Status: {status}  |  Try: {try_num}")
            if status == "skipped":
                lines.append(f"{indent}    Skip Reason: {skip_reason or error_msg}")
            else:
                lines.append(f"{indent}    Error Type: {error_type}")
                lines.append(f"{indent}    Error: {error_msg}")
            lines.append(f"{indent}    Log URL: {log_url}")
    else:
        lines.append(f"{indent}All reported tasks succeeded.")

    if good_entries:
        lines.append(f"{indent}Successful tasks ({len(good_entries)}):")
        for e in good_entries:
            lines.append(f"{indent}  ✓ {_safe_get(e, 'task_key')}")

    return lines


def check_risk_score_data_written(date_str: str) -> dict:
    try:
        conn = connect(host=TRINO_REPORT_HOST, port=TRINO_REPORT_PORT, user=TRINO_REPORT_USER)
        cur = conn.cursor()
        cur.execute(
            "SELECT count(*) FROM strot.operator360_stagging.features_risk_v1 "
            f"WHERE feature_name = 'risk_score' AND date(timestamp) = date('{date_str}')"
        )
        row_count = cur.fetchone()[0]
        return {"checked": True, "row_count": row_count, "error": None}
    except Exception as e:
        logger.error("risk_score data-presence check failed: %s", e)
        return {"checked": False, "row_count": None, "error": str(e)}


def generate_daily_report(**context):
    """Same structure/purpose as v2's report, plus a 'today's retry state'
    section. Layer 2/3 status is now read under the day-stable
    pipeline_run_id (see daily_state.daily_pipeline_run_id) instead of this
    tick's own run_id, so it reflects every tick's cumulative attempts today
    instead of whatever - usually almost nothing, once gates start correctly
    skipping already-done work - happened in this one tick alone."""
    ti = context["ti"]
    run_id = context["run_id"]
    dag_run = context["dag_run"]
    logical_dt = context["data_interval_start"]

    is_daily_run = ti.xcom_pull(task_ids="compute_run_mode", key="is_daily_run")
    if is_daily_run is None:
        ist_hour = logical_dt.astimezone(ZoneInfo("Asia/Kolkata")).hour
        if ist_hour == LAYER1_PROMOTION_HOUR:
            is_daily_run = True
        else:
            raise AirflowSkipException("Not a daily promotion run (is_daily_run=None, IST hour != promotion hour)")
    if not is_daily_run:
        raise AirflowSkipException("Not a daily promotion run — no report generated.")

    date_str = logical_dt.astimezone(ZoneInfo("Asia/Kolkata")).strftime("%Y-%m-%d")
    daily_id = daily_pipeline_run_id(date_str)
    logger.info("Daily Report (v3): Generating comprehensive report for run_id=%s date=%s", run_id, date_str)

    try:
        # NOTE: pre-existing bug, left as-is - the first arg to os.getenv
        # should be an env VAR NAME, not a URL, so this always falls through
        # to the localhost default and the whole block below silently no-ops
        # via the except. None of task_states/task_timings/task_log_urls are
        # actually used in the report text below either way.
        base_url = os.getenv("http://10.10.118.36:8080", "http://localhost:8080")
        api_url = f"{base_url}/api/v1/dags/{dag_run.dag_id}/dagRuns/{run_id}/taskInstances"
        response = requests.get(api_url)
        response.raise_for_status()
    except Exception as e:
        logger.error("Failed to fetch task instances via REST API: %s", e)

    layer1_valid = ti.xcom_pull(task_ids="judge_layer1", key="valid_categories") or []
    layer1_results = ti.xcom_pull(task_ids="judge_layer1", key="layer1_results") or {}
    layer2_valid = ti.xcom_pull(task_ids="judge_layer2", key="valid_categories") or []
    layer2_results = ti.xcom_pull(task_ids="judge_layer2", key="layer2_results") or {}

    all_layer1_status = {d: safe_read_status(run_id, d) for d in LAYER1_DAG_IDS_V2}
    layer2_status = safe_read_status(daily_id, LAYER2_DAG_ID_V2)
    layer3_status = safe_read_status(daily_id, LAYER3_DAG_ID_V2)
    risk_score_check = check_risk_score_data_written(date_str)
    pending_state = read_pending_state(date_str)

    L = []
    L.append("=" * 110)
    L.append("  DAILY PIPELINE REPORT (v3) — controller_pipeline_v3")
    L.append("=" * 110)
    L.append(f"  Run ID:                          {run_id}")
    L.append(f"  Layer 2/3 daily pipeline_run_id: {daily_id}")
    L.append(f"  Logical Date (Data Interval):    {logical_dt}")
    L.append(f"  IST Date:                        {date_str}")
    L.append("")

    L.append("-" * 110)
    L.append("  LAYER 1 — CATEGORY PROGRESSION (as of this tick)")
    L.append("-" * 110)
    for child_dag_id in LAYER1_DAG_IDS_V2:
        category = DAG_ID_TO_CATEGORY_V2.get(child_dag_id, "UNKNOWN")
        entries = all_layer1_status.get(child_dag_id, [])
        l1_result = layer1_results.get(category, {})
        is_valid = l1_result.get("valid", False) if isinstance(l1_result, dict) else False
        L.append(f"  ┌─ DAG: {child_dag_id}  (category={category})")
        L.append(f"  │  Verdict: {'✓ PASSED' if is_valid else '✗ FAILED (queued for retry)'}")
        L.extend(format_entries_report(entries, indent="  │  "))
        L.append(f"  └{'─' * 100}")
    L.append("")

    L.append("-" * 110)
    L.append("  TODAY'S RETRY STATE (updates throughout the day, not just at report time)")
    L.append("-" * 110)
    L.append(f"  Valid today so far:  {pending_state.get('valid_today', [])}")
    L.append(f"  Still pending retry: {list(pending_state.get('categories', {}).keys()) or 'NONE'}")
    for cat, info in pending_state.get("categories", {}).items():
        L.append(f"    - {cat}: attempts={info.get('attempts')}, last_attempt_at={info.get('last_attempt_at')}")
    L.append("  (Retries run every 6 hours until midnight IST; check retry_update_*.txt reports for same-day updates.)")
    L.append("")

    L.append("-" * 110)
    L.append("  LAYER 2 / LAYER 3 (cumulative for today, across every tick)")
    L.append("-" * 110)
    L.append(f"  Categories PASSED Layer 2 (this tick's judgement): {layer2_valid if layer2_valid else 'NONE'}")
    L.append(f"  Layer 2 Verdicts (this tick):                      {layer2_results}")
    L.append(f"  Layer 2 S3 Status Records (all of today):          {len(layer2_status)}")
    L.extend(format_entries_report(layer2_status, indent="  "))
    L.append(f"  Layer 3 S3 Status Records (all of today):          {len(layer3_status)}")
    L.extend(format_entries_report(layer3_status, indent="  "))
    L.append("")

    L.append(f"  risk_score data-presence check (features_risk_v1, {date_str}):")
    if not risk_score_check["checked"]:
        L.append(f"    ⚠️  Could not verify - query failed: {risk_score_check['error']}")
    elif risk_score_check["row_count"] > 0:
        L.append(f"    ✓ {risk_score_check['row_count']} risk_score row(s) found for {date_str}.")
    else:
        L.append(f"    ✗ ZERO risk_score rows found for {date_str} as of this report.")
        L.append("      (May still be corrected later today by a retry cascade - check retry_update_*.txt.)")
    L.append("")
    L.append("=" * 110)
    L.append("  END OF REPORT")
    L.append("=" * 110)

    report_text = "\n".join(L)
    logger.info("Daily Report (v3):\n%s", report_text)

    date_path = logical_dt.strftime("%Y/%m/%d")
    s3_key = f"reports/controller_pipeline_v3/{date_path}/daily_report_{run_id}.txt"
    try:
        s3 = get_s3_client()
        s3.put_object(Bucket=CEPH_BUCKET_NAME, Key=s3_key, Body=report_text.encode("utf-8"), ContentType="text/plain")
        report_uri = f"s3://{CEPH_BUCKET_NAME}/{s3_key}"
        logger.info("Daily Report (v3) uploaded to: %s", report_uri)
        ti.xcom_push(key="daily_report_uri", value=report_uri)
        return report_uri
    except Exception as e:
        logger.error("Daily Report (v3): failed to upload to S3: %s", e)
        return None


def generate_retry_report(date_str: str, state: dict, newly_valid: list, cascade_summary: dict | None) -> None:
    """Small supplementary report uploaded whenever a retry tick changes
    anything, so a same-day recovery is visible without waiting for the next
    full daily report."""
    L = []
    L.append("=" * 90)
    L.append(f"  RETRY UPDATE — controller_pipeline_v3 — {date_str}")
    L.append("=" * 90)
    L.append(f"  Time (IST):            {datetime.now(ZoneInfo('Asia/Kolkata'))}")
    L.append(f"  Newly valid this tick: {newly_valid or 'NONE'}")
    L.append(f"  Valid today (total):   {state.get('valid_today', [])}")
    L.append(f"  Still pending:         {list(state.get('categories', {}).keys()) or 'NONE'}")
    for cat, info in state.get("categories", {}).items():
        L.append(f"    - {cat}: attempts={info.get('attempts')}, last_attempt_at={info.get('last_attempt_at')}")
    if cascade_summary:
        L.append("")
        L.append("  Layer 2/3 cascade triggered by this retry:")
        L.append(f"    Layer 2 run_id:    {cascade_summary.get('layer2_run_id')}")
        L.append(f"    Layer 2 valid:     {cascade_summary.get('layer2_valid')}")
        L.append(f"    Layer 3 triggered: {cascade_summary.get('layer3_triggered')}")
        L.append(f"    Layer 3 run_id:    {cascade_summary.get('layer3_run_id')}")
    L.append("=" * 90)
    report_text = "\n".join(L)
    logger.info("Retry Report:\n%s", report_text)

    ts = int(time.time())
    s3_key = f"reports/controller_pipeline_v3/{date_str.replace('-', '/')}/retry_update_{ts}.txt"
    try:
        s3 = get_s3_client()
        s3.put_object(Bucket=CEPH_BUCKET_NAME, Key=s3_key, Body=report_text.encode("utf-8"), ContentType="text/plain")
        logger.info("Retry Report uploaded to: s3://%s/%s", CEPH_BUCKET_NAME, s3_key)
    except Exception as e:
        logger.error("Retry Report: failed to upload to S3: %s", e)
