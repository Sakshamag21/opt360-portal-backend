"""S3-backed daily state: the pending-retry state Layer-1 categories carry
across ticks, and the day-stable pipeline_run_id Layer 2/3 need for their own
idempotency to actually work across ticks (see daily_pipeline_run_id's
docstring below for why that matters).
"""
import json
import logging

import boto3

from operator360.operator_dag_manager_test.topology import (
    CEPH_ACCESS_KEY,
    CEPH_BUCKET_NAME,
    CEPH_CACHE_PREFIX,
    CEPH_ENDPOINT_URL,
    CEPH_SECRET_KEY,
)

logger = logging.getLogger(__name__)


def get_s3_client():
    return boto3.client(
        "s3",
        endpoint_url=CEPH_ENDPOINT_URL,
        aws_access_key_id=CEPH_ACCESS_KEY,
        aws_secret_access_key=CEPH_SECRET_KEY,
    )


def daily_pipeline_run_id(date_str: str) -> str:
    """The id Layer 2/3 status records must be keyed under for the WHOLE
    calendar day - not each 6-hourly tick's own (different) Airflow run_id.

    Layer-1 features are protected against being re-run every tick by their
    own Trino-side last_successful_run check inside run_one_feature; the S3
    idempotency gate there (skip_if_already_succeeded) is just a fast-skip
    optimization layered on top of that, not the only thing preventing a
    duplicate insert. Layer-2/3 scores have no such Trino-side guard -
    instances_main.py/category_main.py always recompute and .append() - so
    their S3 idempotency gate (gate_dup_*) is their ONLY protection against
    re-appending a score that already succeeded earlier today.

    Before this fix, every trigger of Layer 2/3 used the controller's own
    per-tick `run_id` (a fresh value every 6 hours) as the conf pipeline_run_id,
    so a later tick's gate_dup_* lookup could never find an earlier tick's
    success record - it was keyed under a different id every time - and every
    6-hourly promotion tick re-ran and re-appended every score, whether or not
    it had already succeeded. Using this stable, date-derived id instead means
    every tick's status writes and reads land on the same key, so the
    idempotency/dependency gates actually see what already happened today.
    """
    return f"controller_pipeline_v3_daily_{date_str}"


def pending_state_key(date_str: str) -> str:
    return f"{CEPH_CACHE_PREFIX}/manager_status_v2/daily_pending/{date_str}.json"


def read_pending_state(date_str: str) -> dict:
    s3 = get_s3_client()
    key = pending_state_key(date_str)
    try:
        resp = s3.get_object(Bucket=CEPH_BUCKET_NAME, Key=key)
        return json.loads(resp["Body"].read().decode("utf-8"))
    except s3.exceptions.NoSuchKey:
        return {"date": date_str, "original_pipeline_run_id": None, "categories": {}, "valid_today": []}
    except Exception as e:
        logger.error("Failed to read pending-retry state for %s: %s", date_str, e)
        return {"date": date_str, "original_pipeline_run_id": None, "categories": {}, "valid_today": []}


def write_pending_state(date_str: str, state: dict) -> None:
    s3 = get_s3_client()
    key = pending_state_key(date_str)
    try:
        s3.put_object(
            Bucket=CEPH_BUCKET_NAME,
            Key=key,
            Body=json.dumps(state, default=str).encode("utf-8"),
            ContentType="application/json",
        )
    except Exception as e:
        logger.error("Failed to write pending-retry state for %s: %s", date_str, e)
