"""Direct DagRun manipulation: waiting on a triggered child DagRun, clearing
just its failed task instances for an in-place retry (used by both Layer-1
categories and, new in this pass, Layer-2/3 scores), and the Layer 2/3
cascade a same-day Layer-1 recovery triggers.
"""
import logging
import time
from zoneinfo import ZoneInfo

from airflow.models import DagBag, DagRun
from airflow.utils.session import create_session
from airflow.utils.state import DagRunState
from airflow.api.common.trigger_dag import trigger_dag

from operator360.utils.pipeline_status import read_layer_status, compute_category_verdicts
from operator360.operator_dag_manager_test.topology import LAYER2_DAG_ID_V2, LAYER3_DAG_ID_V2
from operator360.operator_dag_manager_test.daily_state import daily_pipeline_run_id

logger = logging.getLogger(__name__)


def wait_for_dagrun(dag_id: str, run_id: str, timeout_seconds: float, poke_interval: int = 20) -> str:
    deadline = time.time() + timeout_seconds
    with create_session() as session:
        while time.time() < deadline:
            dr = (
                session.query(DagRun)
                .filter(DagRun.dag_id == dag_id, DagRun.run_id == run_id)
                .first()
            )
            if dr is not None and dr.state in ("success", "failed"):
                return dr.state
            time.sleep(poke_interval)
    logger.error("Timed out waiting for %s / %s to finish", dag_id, run_id)
    return "timeout"


def clear_failed_tasks_and_wait(dag_id: str, run_id: str, timeout_seconds: float) -> str:
    """Retries a DagRun by clearing ONLY the failed task instances on it and
    letting the scheduler re-run just those - instead of triggering a whole
    new DagRun. This is what keeps a retry from re-inserting a duplicate row
    for anything that already succeeded, since none of the feature SQL (and
    none of the Layer 2/3 Spark writes) are delete-first/merge. Used both for
    a Layer-1 category's own DagRun and, new in this pass, for a Layer-2/3
    score's DagRun via retry_layer_failures_if_any() below - the mechanics
    are identical at the Airflow level, only the caller differs."""
    with create_session() as session:
        dr = session.query(DagRun).filter(DagRun.dag_id == dag_id, DagRun.run_id == run_id).first()
        if dr is None:
            logger.error("Retry: could not find original DagRun for %s/%s to clear", dag_id, run_id)
            return "not_found"
        exec_date = dr.execution_date

    dag_bag = DagBag(read_dags_from_db=True)
    target_dag = dag_bag.get_dag(dag_id)
    if target_dag is None:
        logger.error("Retry: could not load DAG definition for %s from DagBag", dag_id)
        return "dag_not_found"

    # only_failed=True clears exactly the task instances in a 'failed' state
    # for this run and leaves 'success'/'skipped' ones untouched - skipped
    # tasks (an hourly-cadence feature on a non-relevant tick, a dependency
    # gate that isn't ready yet, is_daily gating) are deliberately NOT
    # retried here, since a fresh full re-trigger next tick already covers
    # them once their dependency is actually ready.
    target_dag.clear(
        start_date=exec_date,
        end_date=exec_date,
        only_failed=True,
        dag_run_state=DagRunState.QUEUED,
    )
    logger.info("Retry: cleared failed task instances on %s/%s (execution_date=%s)", dag_id, run_id, exec_date)

    return wait_for_dagrun(dag_id, run_id, timeout_seconds)


def retry_layer_failures_if_any(dag_id: str, run_id: str, date_str: str, timeout_seconds: float) -> None:
    """NEW: score-level equivalent of the Layer-1 category retry, for Layer
    2/3. `run_id` is the specific child DagRun a trigger task just created
    (from its own XCom return value); status is read back under the
    day-stable pipeline_run_id (see daily_state.daily_pipeline_run_id) so it
    reflects every score's true state today, not just what this one DagRun
    itself wrote. A no-op if nothing in this DagRun actually failed (as
    opposed to succeeding or being skipped by a dependency/idempotency
    gate) - most ticks, most of the time, this does nothing."""
    if not run_id:
        logger.warning("Retry (Layer 2/3): no child DagRun id for %s - skipping.", dag_id)
        return
    pipeline_run_id = daily_pipeline_run_id(date_str)
    entries = read_layer_status(pipeline_run_id, dag_id)
    if not any(e.get("status") == "failed" for e in entries):
        return
    logger.info("Retry (Layer 2/3): clearing failed score tasks on %s/%s", dag_id, run_id)
    clear_failed_tasks_and_wait(dag_id, run_id, timeout_seconds)


def cascade_layer2_layer3(valid_categories: list, logical_dt, retry_label: str,
                           layer_wait_timeout_seconds: float) -> dict:
    """Re-triggers Layer 2 then Layer 3 with the current full set of
    categories valid today, so a category that only just cleared a Layer-1
    retry still makes it into today's risk_score. Uses the day-stable
    pipeline_run_id for both DAGs' trigger conf and status reads -
    `retry_label` only keeps the child DagRuns' own Airflow run_id
    readable/unique, it is NOT the id those DAGs use for their own
    idempotency bookkeeping.

    NOTE: unlike the Layer-1 retry above, this still triggers brand-new
    Layer 2/3 DagRuns rather than clearing specific tasks - risk_score's
    Layer-3 task depends on all 5 category-score tasks completing within the
    SAME DagRun, so a run that only includes the newly-recovered category
    wouldn't let risk_score compute at all. That means this cascade
    re-includes every category in valid_categories, not just the new one -
    but thanks to the day-stable pipeline_run_id, every score that already
    succeeded earlier today now correctly skips via gate_dup_*/gate_dep_*
    instead of re-appending a duplicate row. Each triggered DagRun also gets
    one immediate clear-and-retry pass via retry_layer_failures_if_any, same
    as the normal per-tick promotion path."""
    date_str = logical_dt.astimezone(ZoneInfo("Asia/Kolkata")).strftime("%Y-%m-%d")
    pipeline_run_id = daily_pipeline_run_id(date_str)
    summary = {"layer2_run_id": None, "layer2_valid": [], "layer3_run_id": None, "layer3_triggered": False}

    l2_run_id = f"retry_l2_{retry_label}_{int(time.time())}"
    summary["layer2_run_id"] = l2_run_id
    logger.info("Retry cascade: re-triggering %s (run_id=%s) with valid_categories=%s",
                LAYER2_DAG_ID_V2, l2_run_id, valid_categories)
    trigger_dag(
        dag_id=LAYER2_DAG_ID_V2,
        run_id=l2_run_id,
        conf={"pipeline_run_id": pipeline_run_id, "valid_categories": valid_categories},
        logical_date=logical_dt,
        replace_microseconds=False,
    )
    wait_for_dagrun(LAYER2_DAG_ID_V2, l2_run_id, layer_wait_timeout_seconds)
    retry_layer_failures_if_any(LAYER2_DAG_ID_V2, l2_run_id, date_str, layer_wait_timeout_seconds)

    l2_entries = read_layer_status(pipeline_run_id, LAYER2_DAG_ID_V2)
    l2_verdicts = compute_category_verdicts(l2_entries)
    l2_valid = [c for c in valid_categories if l2_verdicts.get(c)]
    summary["layer2_valid"] = l2_valid

    if not l2_valid:
        logger.warning("Retry cascade: no categories passed Layer 2 after retry - not triggering Layer 3")
        return summary

    l3_run_id = f"retry_l3_{retry_label}_{int(time.time())}"
    summary["layer3_run_id"] = l3_run_id
    summary["layer3_triggered"] = True
    logger.info("Retry cascade: re-triggering %s (run_id=%s) with valid_categories=%s",
                LAYER3_DAG_ID_V2, l3_run_id, l2_valid)
    trigger_dag(
        dag_id=LAYER3_DAG_ID_V2,
        run_id=l3_run_id,
        conf={"pipeline_run_id": pipeline_run_id, "valid_categories": l2_valid},
        logical_date=logical_dt,
        replace_microseconds=False,
    )
    wait_for_dagrun(LAYER3_DAG_ID_V2, l3_run_id, layer_wait_timeout_seconds)
    retry_layer_failures_if_any(LAYER3_DAG_ID_V2, l3_run_id, date_str, layer_wait_timeout_seconds)
    return summary
