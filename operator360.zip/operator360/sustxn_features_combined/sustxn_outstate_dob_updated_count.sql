insert into {destination_table} 
with tab1 as (
    select opt_id, count(*) as no_of_packets
    from strot.operator360.opt_outstate_anomalous_enu_eid_daily
    where date(event_timestamp)>= date('{min_pkt_date}') 
      and date(event_timestamp)<date('{max_pkt_date}')
      and enrolment_is_dob_updated = 1
    group by 1
)
select opt_id as entity_id,
        '{FEATURE_NAME}_24h_v{FEATURE_VERSION}' AS feature_id,
        '{FEATURE_NAME}' AS feature_name,
        '{FEATURE_VERSION}' AS feature_version,
        no_of_packets as feature_value,
        current_timestamp as timestamp,
        cast(Null as Varchar) as comments
from tab1 where no_of_packets>0