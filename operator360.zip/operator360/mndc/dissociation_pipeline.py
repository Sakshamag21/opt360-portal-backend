def write_data_to_mysql(query, data=None, host=mysql_connection_url, database='operator360',
                       admin_user=mysql_admin_user, admin_password=mysql_admin_password):
    """Execute a write (INSERT/UPDATE) query against MySQL, optionally in batch."""
    try:
        rows_desc = len(data) if data else 1
        logger.info(f"[MYSQL-WRITE] Connecting to host={host} db={database} | rows_to_write={rows_desc}")
        start_time = time.time()
        connection = mysql.connector.connect(
            host=host,
            user=admin_user,
            password=admin_password,
            database=database
        )
        cursor = connection.cursor()

        if data:
            cursor.executemany(query, data)
            logger.info(f"[MYSQL-WRITE] executemany completed | rows_affected={cursor.rowcount}")
        else:
            cursor.execute(query)
            logger.info(f"[MYSQL-WRITE] execute completed | rows_affected={cursor.rowcount}")

        connection.commit()
        logger.info("[MYSQL-WRITE] Transaction committed.")
        cursor.close()
        connection.close()
        elapsed = round(time.time() - start_time, 3)
        logger.info(f"[MYSQL-WRITE] Write completed in {elapsed}s")
        return True
    except Exception as e:
        logger.error(f"[MYSQL-WRITE] Database error: {e}", exc_info=True)
        return False


def user_status_0_inactive():
    data = trino('''
    with tab1 as (
        select user_code, user_key, user_status, inactive_reason_key,
               last_updated_date as dissociation_date
        from mysql_uidmasterv1.uidmasterv1_1.user
        where user_status = '0' and user_type_key in (5,6)
          and date(last_updated_date) >= date(current_date - interval '30' day)
    )
    select
        upper(user_code) as user_code,
        t1.user_key,
        t1.user_status,
        t1.dissociation_date,
        t1.inactive_reason_key   as reason_key,
        t2.inactive_reason_code  as reason_code
    from tab1 t1
    left join mysql_uidmasterv1.uidmasterv1_1.user_inactive_reason t2
           on t1.inactive_reason_key = t2.inactive_reason_key
    ''')
    
    if 'df' not in data:        
        return pd.DataFrame()
    
    return data['df']


def user_status_2_suspended():
    data = trino('''
    with tab1 as (
        select user_code, user_key, user_status,
               last_updated_date as last_updated_date_user
        from mysql_uidmasterv1.uidmasterv1_1.user
        where user_status = '2'
          and date(last_updated_date) >= date(current_date - interval '30' day)
    ),
    tab2 as (
        select t1.*,
               t2.activation_date      as dissociation_date,
               t2.blacklist_reason_key as blacklist_reason_key,
               t2.last_updated_date    as last_updated_date
        from tab1 t1
        left join mysql_uidmasterv1.uidmasterv1_1.operator_history t2
               on t1.user_key = t2.user_key
              and t2.operator_history_type = 'SUSPENSION_UNSUSPENSION'
    ),
    tab3 as (
        select *,
               row_number() over (partition by user_key order by last_updated_date desc) as rn
        from tab2
    ),
    tab4 as (
        select t1.*, t2.blacklist_reason_code
        from tab3 t1
        left join mysql_uidmasterv1.uidmasterv1_1.blacklist_reason t2
               on t1.blacklist_reason_key = t2.blacklist_reason_key
    )
    select
        upper(user_code) as user_code,
        user_key,
        user_status,
        dissociation_date,
        blacklist_reason_key   as reason_key,
        blacklist_reason_code  as reason_code
    from tab4
    where rn = 1
    ''')
    
    if 'df' not in data:        
        return pd.DataFrame()
    
    return data['df']


def user_status_4_dissociated():
    data = trino('''
    with tab1 as (
        select user_code, user_key, user_status,
               last_updated_date as last_updated_date_user
        from mysql_uidmasterv1.uidmasterv1_1.user
        where user_status = '4'
          and date(last_updated_date) >= date(current_date - interval '30' day)
    ),
    tab2 as (
        select t1.*,
               t2.activation_date     as dissociation_date,
               t2.inactive_reason_key as inactive_reason_key,
               t2.last_updated_date   as last_updated_date
        from tab1 t1
        left join mysql_uidmasterv1.uidmasterv1_1.operator_history t2
               on t1.user_key = t2.user_key
              and t2.operator_history_type = 'ONBOARDING_DISSOCIATION'
    ),
    tab3 as (
        select *,
               row_number() over (partition by user_key order by last_updated_date desc) as rn
        from tab2
    ),
    tab4 as (
        select t1.*, t2.inactive_reason_code
        from tab3 t1
        left join mysql_uidmasterv1.uidmasterv1_1.user_inactive_reason t2
               on t1.inactive_reason_key = t2.inactive_reason_key
    )
    select
        upper(user_code) as user_code,
        user_key,
        user_status,
        dissociation_date,
        inactive_reason_key   as reason_key,
        inactive_reason_code  as reason_code
    from tab4
    where rn = 1
    ''')
    
    if 'df' not in data:        
        return pd.DataFrame()
    
    return data['df']


def update_activeness():
    # 1. Gather all status updates into a structured list
    status_tasks = [
        {"name": "Inactive (0)", "fetch_func": user_status_0_inactive},
        {"name": "Suspended (2)", "fetch_func": user_status_2_suspended},
        {"name": "Dissociated (4)", "fetch_func": user_status_4_dissociated}
    ]
    
    # Parametrized query using batch executemany format (%s)
    # Fixed the leading comma syntax error and correctly structured targets
    batch_update_query = """
        UPDATE operator360.opt_master
        SET `is_active` = %s,
            `dissociation_date` = %s,
            `dissociation_reason_code` = %s,
            `dissociation_description` = %s,
            `updated_at` = CURRENT_TIMESTAMP()
        WHERE `id` = %s
    """

    for task in status_tasks:
        try:
            logger.info(f"[update_activeness] Fetching data for status: {task['name']}")
            df = task["fetch_func"]()
            
            if df.empty:
                logger.info(f"[update_activeness] No records found for status: {task['name']}. Skipping.")
                continue

            # CRITICAL FIX: Mapping DataFrame columns into tuples matching the %s placeholders.
            # Using 'user_code' as target for where id = %s. Change to 'user_key' if needed.
            db_data = [
                (
                    row['user_status'],
                    row['dissociation_date'] if pd.notna(row['dissociation_date']) else None,
                    row['reason_key'] if pd.notna(row['reason_key']) else None,
                    row['reason_code'] if pd.notna(row['reason_code']) else None,
                    row['user_code']  # Maps to `id` in the WHERE clause
                )
                for _, row in df.iterrows()
            ]
            
            logger.info(f"[update_activeness] Batch writing {len(db_data)} rows for status: {task['name']}")
            
            # Leveraging your built-in batch processing capabilities
            success = write_data_to_mysql(query=batch_update_query, data=db_data)
            
            if success:
                logger.info(f"[update_activeness] Successfully completed batch for {task['name']}")
            else:
                logger.error(f"[update_activeness] Failed to execute batch update for {task['name']}")
                
        except Exception as e:
            logger.exception(f"[update_activeness] Unhandled error during status loop [{task['name']}]: {e}")
            raise
