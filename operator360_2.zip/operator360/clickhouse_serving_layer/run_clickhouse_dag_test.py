# File: operator360/clickhouse_serving_layer/run_clickhouse_dag.py
from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from datetime import datetime, timedelta
from operator360.clickhouse_serving_layer.opt360_clickhouse_feature_store_test import run_opt360_clickhouse_feature_store

default_args = {
    "owner": "Piyush Singh",
    "email": ["techexe11.yp26@uidai.net.in"],
    "email_on_failure": True,
    "retries": 1,
}

with DAG(
    dag_id="run_clickhouse_feature_store",
    default_args=default_args,
    description="Wrapper DAG to trigger ClickHouse Feature Store ingestion",
    schedule="0 19 * * *",  # Runs every day at 7 PM
    catchup=False,
    start_date=datetime(2026, 8, 20),
) as dag:
    
    run_ch_task = PythonOperator(
        task_id="run_clickhouse_ingestion",
        python_callable=run_opt360_clickhouse_feature_store,
    )
    