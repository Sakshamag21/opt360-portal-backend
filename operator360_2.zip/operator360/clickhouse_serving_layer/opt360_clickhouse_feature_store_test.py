from __future__ import annotations

import logging
import time
import pandas as pd
import polars as pl
import clickhouse_connect
from trino.dbapi import connect
import mysql.connector

logger = logging.getLogger(__name__)

# --- Configuration ---
TRINO_HOST = "10.10.116.39"
TRINO_PORT = 8080
TRINO_USER = "airflow_dag_op"

MYSQL_HOST = "10.10.106.159"
MYSQL_USER = "Data_platform_W"
MYSQL_PASSWORD = "Dataplat_7634"

CH_HOST = '10.10.120.86'
CH_USER = 'default'
CH_PASSWORD = 'qwerty'
CH_DATABASE = 'default'
CH_TABLE = 'opt360_feature_store_test_v1'

ENTITY_BATCH_SIZE = 1000

# --- Helper Functions (Stateless Utilities) ---

def chunked(seq, size):
    """Yield successive chunks of length `size` from a list."""
    for i in range(0, len(seq), size):
        yield seq[i:i + size]

def _run_trino_query(query, host=TRINO_HOST, port=TRINO_PORT, user=TRINO_USER):
    """Run a Trino query and return a Pandas DataFrame."""
    start_time = time.time()
    conn = None
    try:
        conn = connect(host=host, port=port, user=user)
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        cols = [d[0] for d in cur.description] if cur.description else []
        df = pd.DataFrame(body, columns=cols) if cols else pd.DataFrame()
        return {"success": 1, "df": df, "execution_time": time.time() - start_time}
    except Exception as e:
        logger.exception("Trino query failed")
        return {"success": 0, "msg": str(e), "df": pd.DataFrame(), "execution_time": time.time() - start_time}
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass

def _fetch_mysql_query(query, host=MYSQL_HOST, user=MYSQL_USER, password=MYSQL_PASSWORD):
    """Execute MySQL query and return a Polars DataFrame."""
    connection = None
    try:
        connection = mysql.connector.connect(host=host, user=user, password=password)
        cursor = connection.cursor()
        cursor.execute(query)
        results = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description] if cursor.description else []
        
        safe_results = [
            [str(item) if item is not None else None for item in row]
            for row in results
        ]
        return pl.DataFrame(safe_results, schema=columns, orient="row") if columns else pl.DataFrame()
    except Exception:
        logger.exception("MySQL query execution failed.")
        raise
    finally:
        if connection:
            try:
                connection.close()
            except Exception:
                pass

def _get_feature_group(feature_id):
    """Maps the feature_id prefix to a human-readable feature group."""
    prefix = feature_id.split('_')[0] if '_' in feature_id else feature_id
    mapping = {
        'auth': 'Authentication',
        'bio': 'Biometrics',
        'work': 'Work',
        'harware': 'Hardware',
        'sustxn': 'Suspicious Transaction',
        'doc': "Document",
    }
    return mapping.get(prefix, prefix)

def _build_trino_query(dest_table, entity_ids_batch):
    """Builds the Trino query to fetch the latest feature_value for a batch of entities."""
    entity_ids_str = ", ".join(f"'{e}'" for e in entity_ids_batch)
    return f"""
        SELECT entity_id, feature_value, timestamp
        FROM (
            SELECT entity_id, feature_value, timestamp,
                ROW_NUMBER() OVER (PARTITION BY entity_id ORDER BY timestamp DESC) AS rn
            FROM {dest_table}
            WHERE entity_id IN ({entity_ids_str})
        )
        WHERE rn = 1
    """

def _get_feature_config(feature_name: str, feature_version: int) -> dict:
    """Fetches feature configuration for a single feature from Trino."""
    resp = _run_trino_query(f"""
        SELECT feature_id, destination_table, description
        FROM strot.operator360_stagging.opt360_features 
        WHERE feature_name = '{feature_name}' 
          AND version = '{feature_version}'
          AND status = 'PROD'
        LIMIT 1
    """)
    
    if not resp.get("success") or resp["df"].empty:
        raise ValueError(f"Feature config not found for {feature_name} v{feature_version}")
    
    return resp["df"].to_dict(orient='records')[0]

def get_risk_buckets() -> list[str]:
    """Returns the list of risk buckets to process."""
    return ['Critical', 'High', 'Medium', 'Low', 'No']

def process_feature_for_bucket(feature: dict, risk_bucket: str):
    """Processes a single feature for a single risk bucket with batched entity IDs."""
    feature_id = feature['feature_id']
    dest_table = feature['destination_table']
    description = feature['description']

    if pd.isna(dest_table) or not dest_table:
        return

    logger.info(f"ClickHouse Ingest: Processing feature_id: {feature_id} for bucket: {risk_bucket}")

    # 1. Fetch Entity IDs from MySQL
    mysql_query = f"""
        SELECT id FROM operator360.opt_master
        WHERE is_active = true AND risk_bucket = '{risk_bucket}'
    """
    data_df = _fetch_mysql_query(mysql_query)
    entity_ids = data_df['id'].to_list()

    if not entity_ids:
        logger.info(f"ClickHouse Ingest: No entities for bucket {risk_bucket}; skipping feature_id {feature_id}.")
        return

    # 2. Initialize ClickHouse Client
    ch_client = clickhouse_connect.get_client(
        host=CH_HOST, username=CH_USER, password=CH_PASSWORD, database=CH_DATABASE
    )

    # 3. Batched entity_id processing via Trino
    batch_dfs = []
    for batch_idx, batch in enumerate(chunked(entity_ids, ENTITY_BATCH_SIZE), start=1):
        trino_query = _build_trino_query(dest_table, batch)
        resp = _run_trino_query(trino_query)

        if not resp.get("success"):
            logger.error(f"ClickHouse Ingest: Trino query error for {feature_id} batch {batch_idx}: {resp.get('msg')}")
            continue

        if not resp["df"].empty:
            batch_dfs.append(resp["df"])

    if not batch_dfs:
        logger.info(f"ClickHouse Ingest: No data found for {feature_id} in bucket {risk_bucket}.")
        return

    result_df = pd.concat(batch_dfs, ignore_index=True)

    # 4. Transform (Vectorized) - Using feature_id to enrich the data
    feature_name = feature_id.replace('_', ' ')
    feature_group = _get_feature_group(feature_id)
    desc_safe = '' if pd.isna(description) else description

    result_df['feature_id'] = feature_id
    result_df['feature_name'] = feature_name
    result_df['description'] = desc_safe
    result_df['feature_group'] = feature_group
    result_df = result_df.rename(columns={'timestamp': 'last_updated_at'})
    result_df['last_updated_at'] = pd.to_datetime(result_df['last_updated_at'], errors='coerce')

    result_df = result_df.drop_duplicates(
        subset=['entity_id', 'feature_id'], keep='last'
    ).reset_index(drop=True)

    result_df = result_df[[
        'entity_id', 'feature_id', 'feature_value', 'feature_name',
        'description', 'last_updated_at', 'feature_group'
    ]]

    # 5. Upload to ClickHouse
    try:
        ch_client.insert_df(CH_TABLE, result_df)
        logger.info(f"ClickHouse Ingest: Successfully uploaded {len(result_df)} rows to ClickHouse for feature_id {feature_id} ({risk_bucket}).")
    except Exception as e:
        logger.exception(f"ClickHouse Ingest: ClickHouse insert failed for feature_id {feature_id} ({risk_bucket})")
        raise

def process_single_feature_to_clickhouse(feature_name: str, feature_version: int, run_date: str):
    """
    Callable function to ingest a single feature into ClickHouse immediately 
    after its calculation completes.
    """
    logger.info(f"ClickHouse Ingest: Starting ingestion for {feature_name} v{feature_version} (Date: {run_date})")
    
    try:
        feature_config = _get_feature_config(feature_name, feature_version)
        buckets = get_risk_buckets()
        
        for risk_bucket in buckets:
            process_feature_for_bucket(feature=feature_config, risk_bucket=risk_bucket)
            
        logger.info(f"ClickHouse Ingest: Completed ingestion for {feature_name} v{feature_version}")
    except Exception as e:
        logger.error(f"ClickHouse Ingest: Failed to process {feature_name} v{feature_version}: {e}")
        raise