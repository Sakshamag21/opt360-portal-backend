import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
import traceback

logger = logging.getLogger(__name__)

# --- Email Configuration ---
SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25
SENDER_EMAIL = "airflow@uidai.net.in"
ALERT_RECIPIENTS = ["techexe11.yp26@uidai.net.in"]

def send_pipeline_alert(subject: str, body: str):
    """Sends an HTML formatted alert email to the configured recipients."""
    msg = MIMEMultipart("alternative")
    msg["From"] = SENDER_EMAIL
    msg["To"] = ", ".join(ALERT_RECIPIENTS)
    msg["Subject"] = f"[Operator360 Pipeline Alert] {subject}"
    
    html_content = f"""
    <html>
      <body style="font-family: Arial, sans-serif; color: #333;">
        <h2 style="color: #d9534f;">Pipeline Alert: {subject}</h2>
        <p>An issue was detected in the <strong>Operator360 Feature Pipeline</strong>.</p>
        <hr style="border: 1px solid #ddd;">
        <pre style="background-color: #f9f9f9; padding: 10px; border-radius: 5px; white-space: pre-wrap; word-wrap: break-word;">{body}</pre>
        <p style="font-size: 12px; color: #888;">This is an automated alert. Please investigate the Airflow logs immediately.</p>
      </body>
    </html>
    """
    msg.attach(MIMEText(html_content, "html"))
    
    try:
        logger.info("Sending pipeline alert email: %s", subject)
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(SENDER_EMAIL, ALERT_RECIPIENTS, msg.as_string())
        server.quit()
        logger.info("Alert email sent successfully.")
    except Exception as e:
        logger.error("Failed to send alert email: %s", e)

def notify_failure(feature_name: str, error_type: str, error_details: str):
    """Maps specific error types to email alerts."""
    subject = f"{error_type} - Feature: {feature_name}"
    
    if error_type == "Raw Data Missing":
        body = f"Raw data is missing for feature '{feature_name}'.\n\nDetails:\n{error_details}"
    elif error_type == "Query Timeout":
        body = f"Query for feature '{feature_name}' exceeded the 30-minute timeout limit.\n\nDetails:\n{error_details}"
    elif error_type == "Trino Node Failure":
        body = f"Trino connection or execution failed for feature '{feature_name}'.\n\nDetails:\n{error_details}"
    else:
        body = f"An unhandled error occurred for feature '{feature_name}'.\n\nDetails:\n{error_details}"
        
    send_pipeline_alert(subject, body)

def execute_trino_with_timeout(trino_func, query: str, feature_name: str, timeout_seconds: int = 1800):
    """Executes a Trino query in a separate thread. 30-minute timeout."""
    try:
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(trino_func, query)
            result = future.result(timeout=timeout_seconds)
            
            if isinstance(result, dict) and result.get("success") == 0:
                err_msg = result.get("msg", "Unknown Trino error")
                if "Connection refused" in err_msg or "node" in err_msg.lower() or "memory" in err_msg.lower():
                    notify_failure(feature_name, "Trino Node Failure", err_msg)
                else:
                    notify_failure(feature_name, "Query Execution Error", err_msg)
                raise RuntimeError(f"Trino query failed: {err_msg}")
                    
            return result
            
    except FutureTimeoutError:
        error_msg = f"Query took longer than {timeout_seconds} seconds (30 minutes) and was aborted.\nQuery: {query}"
        notify_failure(feature_name, "Query Timeout", error_msg)
        raise RuntimeError(error_msg)
        
    except Exception as e:
        error_msg = f"Unexpected error during query execution: {str(e)}\n{traceback.format_exc()}"
        notify_failure(feature_name, "Unexpected Error", error_msg)
        raise