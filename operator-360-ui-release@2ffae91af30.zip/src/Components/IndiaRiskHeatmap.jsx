import React, { useEffect, useMemo, useRef, useState } from 'react';
import { MapContainer, TileLayer, useMap, Marker, Popup, GeoJSON, Tooltip } from 'react-leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import PageNavigation from './PageNavigation';
import PageWrapper from './ui/PageWrapper';
import { API_BASE_URL, getAuthHeaders } from '../config/apiConfig';

// Zoom thresholds to determine what data to show
const INDIA_ZOOM_THRESHOLD = 6;
const STATE_ZOOM_THRESHOLD = 8;

// Helper to force Leaflet to recalculate size on mount and track manual zoom
const MapResizer = ({ onZoomChange, onManualZoom }) => {
    const map = useMap();
    const isProgrammaticZoom = useRef(false);

    useEffect(() => {
        const resize = () => map.invalidateSize();
        const timer = setTimeout(resize, 100);
        
        const updateZoom = () => {
            const z = map.getZoom();
            onZoomChange(z);
            // If the zoom wasn't triggered by fitBounds (clicking a state/district), it's manual
            if (!isProgrammaticZoom.current) {
                onManualZoom(z);
            }
            isProgrammaticZoom.current = false; // Reset flag
        };

        // Intercept fitBounds to mark the next zoom as programmatic
        const originalFitBounds = map.fitBounds.bind(map);
        map.fitBounds = (bounds, options) => {
            isProgrammaticZoom.current = true;
            return originalFitBounds(bounds, options);
        };

        map.on('zoomend', updateZoom);
        return () => {
            clearTimeout(timer);
            map.off('zoomend', updateZoom);
            map.fitBounds = originalFitBounds; // Cleanup
        };
    }, [map, onZoomChange, onManualZoom]);
    return null;
};

const normalizeRiskBucket = (value) => {
    const normalized = (value || '').trim().toUpperCase();
    if (normalized === 'CRITICAL' || normalized === 'C') return 'Critical';
    if (normalized === 'HIGH' || normalized === 'H') return 'High';
    if (normalized === 'MEDIUM' || normalized === 'M') return 'Medium';
    if (normalized === 'LOW' || normalized === 'L') return 'Low';
    return 'NO';
};

const getRiskColor = (riskBucket) => {
    if (riskBucket === 'Critical') return '#7f1d1d';
    if (riskBucket === 'High') return '#ef4444';
    if (riskBucket === 'Medium') return '#f97316';
    if (riskBucket === 'Low') return '#eab308';
    return '#22c55e';
};

const createCustomIcon = (riskBucket) => {
    const color = getRiskColor(normalizeRiskBucket(riskBucket));
    return L.divIcon({
        className: 'custom-marker',
        html: `<div style="background-color: ${color}; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white; box-shadow: 0 0 8px 2px ${color};"></div>`,
        iconSize: [12, 12],
        iconAnchor: [6, 6],
        popupAnchor: [0, -6],
    });
};

// =========================================================================
// STATE LAYER (Level 1)
// =========================================================================
const StateBordersLayer = ({ geoJsonData, selectedState, onSelectState }) => {
    const map = useMap();
    useEffect(() => {
        if (!geoJsonData || !selectedState) return;
        const matchingFeature = geoJsonData.features.find((feature) => {
            const stateName = feature?.properties?.STNAME_SH || feature?.properties?.STNAME;
            return stateName && stateName.toLowerCase() === selectedState.toLowerCase();
        });
        if (!matchingFeature) return;
        const bounds = L.geoJSON(matchingFeature).getBounds();
        if (bounds && bounds.isValid && bounds.isValid()) {
            map.fitBounds(bounds);
        }
    }, [geoJsonData, selectedState, map]);

    const onEachState = (feature, layer) => {
        const stateName = feature.properties.STNAME_SH || feature.properties.STNAME;
        layer.bindTooltip(stateName, { sticky: true });
        layer.on({
            mouseover: (e) => {
                if (stateName !== selectedState) {
                    e.target.setStyle({ weight: 3, color: '#3b82f6', fillOpacity: 0.2 });
                }
            },
            mouseout: (e) => {
                if (stateName !== selectedState) {
                    e.target.setStyle({ weight: 1, color: '#1e293b', fillOpacity: 0 });
                }
            },
            click: (e) => {
                onSelectState(stateName);
                map.fitBounds(layer.getBounds());
            }
        });
    };

    if (!geoJsonData) return null;
    return (
        <GeoJSON
            data={geoJsonData}
            style={(feature) => {
                const isSelected = feature.properties.STNAME_SH === selectedState || feature.properties.STNAME === selectedState;
                return {
                    color: isSelected ? '#3b82f6' : '#1e293b',
                    weight: isSelected ? 4 : 1,
                    fillOpacity: isSelected ? 0.1 : 0,
                    dashArray: isSelected ? null : '3',
                };
            }}
            onEachFeature={onEachState}
        />
    );
};

// =========================================================================
// DISTRICT LAYER (Level 2)
// =========================================================================
const DistrictBordersLayer = ({ geoJsonData, selectedState, selectedDistrict, onSelectDistrict }) => {
    const map = useMap();
    const filteredData = useMemo(() => {
        if (!geoJsonData || !selectedState) return null;
        return {
            ...geoJsonData,
            features: geoJsonData.features.filter(f => {
                const stateName = f.properties.st_nm;
                return stateName && stateName.toLowerCase() === selectedState.toLowerCase() && f.properties.district;
            })
        };
    }, [geoJsonData, selectedState]);

    const onEachDistrict = (feature, layer) => {
        const districtName = feature.properties.district;
        if (!districtName) return;
        layer.bindTooltip(districtName, { sticky: true });
        layer.on({
            mouseover: (e) => {
                e.target.setStyle({ weight: 3, color: '#f97316', fillOpacity: 0.3 });
            },
            mouseout: (e) => {
                if (districtName !== selectedDistrict) {
                    e.target.setStyle({ weight: 1.5, color: '#475569', fillOpacity: 0 });
                }
            },
            click: (e) => {
                onSelectDistrict(districtName);
                map.fitBounds(layer.getBounds());
            }
        });
    };

    if (!filteredData || filteredData.features.length === 0) return null;
    return (
        <GeoJSON
            key={`${selectedState}-${selectedDistrict}`} 
            data={filteredData}
            style={(feature) => {
                const isSelected = feature.properties.district === selectedDistrict;
                return {
                    color: isSelected ? '#f97316' : '#475569',
                    weight: isSelected ? 4 : 1.5,
                    fillOpacity: isSelected ? 0.2 : 0,
                };
            }}
            onEachFeature={onEachDistrict}
        />
    );
};

// =========================================================================
// OPERATOR MARKERS (Level 3)
// =========================================================================
const DistrictOperators = ({ selectedState, selectedDistrict }) => {
    const [operators, setOperators] = useState([]);

    useEffect(() => {
        if (!selectedState || !selectedDistrict) {
            setOperators([]);
            return;
        }
        const url = `${API_BASE_URL}/api/district_operators?state=${encodeURIComponent(selectedState)}&district=${encodeURIComponent(selectedDistrict)}&limit=5000`;
        fetch(url, { method: 'GET', headers: getAuthHeaders() })
            .then((res) => {
                if (!res.ok) throw new Error('Failed to fetch operators');
                return res.json();
            })
            .then((data) => {
                const formattedOperators = (data.operators || []).map(([lat, lon, riskCode, id, opState, opDistrict]) => ({
                    latitude: lat,
                    longitude: lon,
                    risk_bucket: riskCode,
                    id: id,
                    state: opState,
                    district: opDistrict
                }));
                setOperators(formattedOperators);
            })
            .catch((err) => console.error('Error fetching district operators:', err));
    }, [selectedState, selectedDistrict]);

    return (
        <MarkerClusterGroup chunkedLoading>
            {operators.map((op) => {
                const normalizedRisk = normalizeRiskBucket(op.risk_bucket);
                const riskColor = getRiskColor(normalizedRisk);

                return (
                    <Marker key={op.id} position={[op.latitude, op.longitude]} icon={createCustomIcon(op.risk_bucket)}>
                        <Popup>
                            <div style={{ minWidth: '200px', fontFamily: 'sans-serif', fontSize: '13px', lineHeight: '1.8' }}>
                                <div style={{ marginBottom: '8px', paddingBottom: '8px', borderBottom: '1px solid #eee', color: '#111827', fontWeight: 'bold', fontSize: '14px' }}>
                                    Operator {op.id}
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#4b5563' }}>
                                    <span>State:</span>
                                    <strong style={{ color: '#111827' }}>{op.state}</strong>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#4b5563' }}>
                                    <span>District:</span>
                                    <strong style={{ color: '#111827' }}>{op.district}</strong>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#4b5563', marginTop: '4px' }}>
                                    <span>Risk:</span>
                                    <strong style={{ color: riskColor, textTransform: 'uppercase' }}>
                                        {normalizedRisk}
                                    </strong>
                                </div>
                            </div>
                        </Popup>
                    </Marker>
                );
            })}
        </MarkerClusterGroup>
    );
};

// =========================================================================
// HIGHLY OPTIMIZED IMD WEATHER CANVAS LAYER (WITH FAST MASK)
// =========================================================================
const ImdWeatherLayer = ({ geoJsonData, points }) => {
    const map = useMap();
    const canvasLayerRef = useRef(null);

    useEffect(() => {
        if (!map || !geoJsonData || points.length === 0) return;

        const createSprite = (stops) => {
            const c = document.createElement('canvas');
            c.width = c.height = 320;
            const cx = c.getContext('2d');
            const grad = cx.createRadialGradient(160, 160, 0, 160, 160, 160);
            stops.forEach(([offset, color]) => grad.addColorStop(offset, color));
            cx.fillStyle = grad;
            cx.beginPath();
            cx.arc(160, 160, 160, 0, Math.PI * 2);
            cx.fill();
            return c;
        };

        const whiteSprite = createSprite([
            [0, 'rgba(34, 197, 94, 0.9)'], [0.5, 'rgba(34, 197, 94, 0.4)'], [1, 'rgba(34, 197, 94, 0)']
        ]);
        const greenSprite = createSprite([
            [0, 'rgba(234, 179, 8, 0.9)'], [0.5, 'rgba(234, 179, 8, 0.4)'], [1, 'rgba(234, 179, 8, 0)']
        ]);
        const amberSprite = createSprite([
            [0, 'rgba(249, 115, 22, 0.9)'], [0.5, 'rgba(249, 115, 22, 0.4)'], [1, 'rgba(249, 115, 22, 0)']
        ]);
        const redSprite = createSprite([
            [0, 'rgba(239, 68, 68, 1)'], [0.5, 'rgba(239, 68, 68, 0.5)'], [1, 'rgba(239, 68, 68, 0)']
        ]);
        const crimsonSprite = createSprite([
            [0, 'rgba(127, 29, 29, 1)'], [0.5, 'rgba(127, 29, 29, 0.7)'], [1, 'rgba(127, 29, 29, 0)']
        ]);

        const CanvasLayer = L.Layer.extend({
            onAdd: function (map) {
                this._map = map;
                this._isZooming = false;
                this._canvas = L.DomUtil.create('canvas', 'leaflet-imd-layer');
                this._canvas.style.position = 'absolute';
                this._canvas.style.top = '0';
                this._canvas.style.left = '0';
                this._canvas.style.opacity = '0.85';
                this._canvas.style.transition = 'opacity 0.2s ease-in-out';
                this._canvas.style.pointerEvents = 'none';
                map.getPane('overlayPane').appendChild(this._canvas);
                map.on('zoomstart', this._onZoomStart, this);
                map.on('zoomend', this._onZoomEnd, this);
                map.on('viewreset resize moveend', this._update, this);
                this._update();
            },
            onRemove: function (map) {
                if (this._canvas && this._canvas.parentNode) map.getPane('overlayPane').removeChild(this._canvas);
                map.off('zoomstart', this._onZoomStart, this);
                map.off('zoomend', this._onZoomEnd, this);
                map.off('viewreset resize moveend', this._update, this);
            },
            _onZoomStart: function () {
                this._isZooming = true;
                if (this._canvas) this._canvas.style.opacity = '0';
            },
            _onZoomEnd: function () {
                this._isZooming = false;
                this._update();
                requestAnimationFrame(() => {
                    if (this._canvas && !this._isZooming) this._canvas.style.opacity = '0.85';
                });
            },
            _update: function () {
                if (this._isZooming) return;
                const size = this._map.getSize();
                if (this._canvas.width !== size.x || this._canvas.height !== size.y) {
                    this._canvas.width = size.x;
                    this._canvas.height = size.y;
                }
                const topLeft = this._map.containerPointToLayerPoint([0, 0]);
                L.DomUtil.setPosition(this._canvas, topLeft);
                const ctx = this._canvas.getContext('2d');
                if (!ctx) return;
                ctx.clearRect(0, 0, size.x, size.y);
                const currentBounds = this._map.getBounds();
                const paddedBounds = currentBounds.pad(0.2);
                const currentZoom = this._map.getZoom();
                const dynamicRadius = Math.max(30, currentZoom * 10);

                points.forEach(([lat, lng, zri]) => {
                    if (!paddedBounds.contains([lat, lng])) return;
                    const pt = this._map.latLngToLayerPoint([lat, lng]).subtract(topLeft);
                    let sprite = whiteSprite;
                    if (zri > 8.0) sprite = crimsonSprite;
                    else if (zri > 5.0) sprite = redSprite;
                    else if (zri > 2.0) sprite = amberSprite;
                    else if (zri > 0.0) sprite = greenSprite;
                    ctx.drawImage(sprite, pt.x - dynamicRadius, pt.y - dynamicRadius, dynamicRadius * 2, dynamicRadius * 2);
                });

                ctx.globalCompositeOperation = 'destination-in';
                ctx.fillStyle = '#000'; 
                ctx.beginPath();
                const renderCoords = (coords, type) => {
                    if (type === 'MultiPolygon') {
                        coords.forEach(polygon => renderCoords(polygon, 'Polygon'));
                        return;
                    }
                    coords.forEach((ring) => {
                        ring.forEach((coord, index) => {
                            const pt = this._map.latLngToLayerPoint([coord[1], coord[0]]).subtract(topLeft);
                            if (index === 0) ctx.moveTo(pt.x, pt.y);
                            else ctx.lineTo(pt.x, pt.y);
                        });
                        ctx.closePath();
                    });
                };
                geoJsonData.features.forEach((feature) => {
                    if (!feature || !feature.geometry) return;
                    renderCoords(feature.geometry.coordinates, feature.geometry.type);
                });
                ctx.fill();
                ctx.globalCompositeOperation = 'source-over'; 
            }
        });

        canvasLayerRef.current = new CanvasLayer();
        map.addLayer(canvasLayerRef.current);

        return () => {
            if (canvasLayerRef.current) {
                map.removeLayer(canvasLayerRef.current);
                canvasLayerRef.current = null;
            }
        };
    }, [map, geoJsonData, points]);

    return null;
};

// =========================================================================
// MAIN COMPONENT
// =========================================================================
const IndiaRiskHeatmap = () => {
    const [geoJsonData, setGeoJsonData] = useState(null);
    const [districtGeoJson, setDistrictGeoJson] = useState(null);
    const [heatPoints, setHeatPoints] = useState([]);
    const [heatLoading, setHeatLoading] = useState(true); 
    const [currentZoom, setCurrentZoom] = useState(5);
    const [selectedState, setSelectedState] = useState(null);
    const [selectedDistrict, setSelectedDistrict] = useState(null);
    
    // Stats state
    const [stats, setStats] = useState(null);
    const [countLoading, setCountLoading] = useState(false);
    const [viewLevel, setViewLevel] = useState('India');

    // Refs to manage debounce and prevent duplicate fetches
    const fetchTimer = useRef(null);
    const lastFetchedHeatmapUrl = useRef(null);
    const statsFetchTimer = useRef(null);

    const stateOptions = useMemo(() => {
        if (!geoJsonData?.features) return [];
        return [...new Set(
            geoJsonData.features
                .map((feature) => feature?.properties?.STNAME_SH || feature?.properties?.STNAME)
                .filter(Boolean)
        )].sort((a, b) => a.localeCompare(b));
    }, [geoJsonData]);

    useEffect(() => {
        fetch('/resources/INDIA_STATES.geojson')
            .then((res) => { if (!res.ok) throw new Error(`HTTP ${res.status}`); return res.json(); })
            .then((data) => setGeoJsonData(data))
            .catch((err) => console.error('Error loading India States GeoJSON:', err));
        fetch('/resources/INDIA_DISTRICTS.geojson')
            .then((res) => { if (!res.ok) throw new Error(`HTTP ${res.status}`); return res.json(); })
            .then((data) => setDistrictGeoJson(data))
            .catch((err) => console.error('Error loading India Districts GeoJSON:', err));
    }, []);

    // Handle Manual Zoom - Removes selections permanently
    const handleManualZoom = (zoom) => {
        if (zoom < INDIA_ZOOM_THRESHOLD) {
            // Zoomed out to India level
            if (selectedState || selectedDistrict) {
                setSelectedDistrict(null);
                setSelectedState(null);
            }
        } else if (zoom < STATE_ZOOM_THRESHOLD) {
            // Zoomed out to State level
            if (selectedDistrict) {
                setSelectedDistrict(null);
            }
        }
    };

    // Dynamic Stats Fetcher
    useEffect(() => {
        if (statsFetchTimer.current) clearTimeout(statsFetchTimer.current);

        if (!selectedState) {
            setViewLevel('India');
            setStats(null);
            setCountLoading(false);
            return;
        }

        let targetLevel = selectedDistrict ? 'District' : 'State';
        setViewLevel(targetLevel);
        setCountLoading(true);

        statsFetchTimer.current = setTimeout(() => {
            const params = new URLSearchParams();
            params.set('state', selectedState);
            if (selectedDistrict) params.set('district', selectedDistrict);
            
            fetch(`${API_BASE_URL}/api/operator_count?${params.toString()}`, {
                method: 'GET',
                headers: getAuthHeaders()
            })
                .then((res) => { if (!res.ok) throw new Error(`HTTP ${res.status}`); return res.json(); })
                .then((data) => {
                    setStats(data);
                    setCountLoading(false);
                })
                .catch((err) => {
                    console.error('Error fetching operator count:', err);
                    setCountLoading(false);
                });
        }, 400);
    }, [selectedState, selectedDistrict]);

    // Dynamic Heatmap Data Fetcher
    useEffect(() => {
        if (fetchTimer.current) clearTimeout(fetchTimer.current);

        const params = new URLSearchParams();
        if (selectedState) {
            params.set('state', selectedState);
            if (selectedDistrict) {
                params.set('district', selectedDistrict);
            }
        }
        const qs = params.toString();
        const url = `${API_BASE_URL}/api/heatmap-zri${qs ? `?${qs}` : ''}`;

        if (url === lastFetchedHeatmapUrl.current) return;

        setHeatLoading(true);

        fetchTimer.current = setTimeout(() => {
            lastFetchedHeatmapUrl.current = url;
            
            fetch(url, { method: 'GET', headers: getAuthHeaders() })
                .then((res) => { if (!res.ok) throw new Error(`HTTP ${res.status}`); return res.json(); })
                .then((data) => {
                    setHeatPoints(data || []);
                    setHeatLoading(false);
                })
                .catch((err) => {
                    console.error('Error fetching heatmap ZRI data:', err);
                    setHeatLoading(false);
                });
        }, 500);

        return () => {
            if (fetchTimer.current) clearTimeout(fetchTimer.current);
        };
    }, [selectedState, selectedDistrict]);

    const handleSelectState = (stateName) => {
        setSelectedState(stateName);
        setSelectedDistrict(null);
    };

    const handleSelectDistrict = (districtName) => {
        setSelectedDistrict(districtName);
    };

    const handleBack = () => {
        if (selectedDistrict) {
            setSelectedDistrict(null);
        } else if (selectedState) {
            setSelectedState(null);
        }
    };

    const handleStateDropdownChange = (event) => {
        const nextValue = event.target.value;
        if (!nextValue) {
            setSelectedDistrict(null);
            setSelectedState(null);
            return;
        }
        handleSelectState(nextValue);
    };

    const getPercentage = (val) => {
        if (!stats || !stats.total || stats.total === 0) return 0;
        return (val / stats.total) * 100;
    };

    return (
        <PageWrapper>
            <PageNavigation currentPage="indiariskheatmap" />
            
            {/* Dashboard Header */}
            <div className="mb-4 p-4 bg-white rounded-xl shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border border-gray-100">
                <div>
                    <h1 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                        <span className="relative flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                        </span>
                        India Risk Heatmap Dashboard
                    </h1>
                    <p className="text-sm text-gray-500 mt-1 ml-5">
                        Drill down from state to district level to analyze operator risk distribution.
                    </p>
                </div>

                <div className="flex items-center gap-3 w-full md:w-auto">
                    <button
                        onClick={handleBack}
                        disabled={!selectedState}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex items-center gap-2 shadow-sm ${
                            selectedState 
                            ? 'bg-blue-600 text-white hover:bg-blue-700 hover:shadow-md' 
                            : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                        }`}
                    >
                        ← Back
                    </button>
                    
                    <div className="relative flex-1 md:flex-none">
                        <select
                            aria-label="Select state"
                            value={selectedState || ''}
                            onChange={handleStateDropdownChange}
                            disabled={!stateOptions.length}
                            className="appearance-none w-full md:w-48 border border-gray-300 rounded-lg pl-3 pr-10 py-2 bg-white text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                        >
                            <option value="">All States</option>
                            {stateOptions.map((stateName) => (
                                <option key={stateName} value={stateName}>{stateName}</option>
                            ))}
                        </select>
                        <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>

            {/* Risk Scale Legend & Breadcrumb Toolbar */}
            <div className="mb-4 p-3 bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
                    <span className="text-xs font-bold uppercase tracking-widest text-gray-400">Risk Scale</span>
                    {[
                        { label: 'Critical', color: '#7f1d1d' },
                        { label: 'High', color: '#ef4444' },
                        { label: 'Medium', color: '#f97316' },
                        { label: 'Low', color: '#eab308' },
                        { label: 'No Risk', color: '#22c55e' }
                    ].map(item => (
                        <div key={item.label} className="flex items-center gap-2">
                            <span className="w-3 h-3 rounded-full shadow-sm" style={{ backgroundColor: item.color }}></span>
                            <span className="text-xs text-gray-700 font-medium">{item.label}</span>
                        </div>
                    ))}
                </div>

                <div className="flex items-center gap-2 text-sm font-medium text-gray-700 ml-auto">
                    <span className="text-gray-400 text-xs uppercase tracking-wider">Viewing:</span>
                    <span className="px-2 py-1 bg-gray-50 rounded">India</span>
                    {selectedState && <span className="text-gray-300">›</span>}
                    {selectedState && <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded">{selectedState}</span>}
                    {selectedDistrict && <span className="text-gray-300">›</span>}
                    {selectedDistrict && <span className="px-2 py-1 bg-orange-50 text-orange-700 rounded">{selectedDistrict}</span>}
                </div>
            </div>

            {heatLoading && (
                <div className="flex items-center gap-3 text-sm text-gray-600 mb-3 bg-blue-50 p-2 rounded-lg border border-blue-100">
                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                    <span className="font-medium text-blue-700">Fetching risk data & rendering map...</span>
                </div>
            )}

            <div className="relative w-full h-[75vh] z-0 overflow-hidden bg-slate-100 rounded-xl shadow-lg border border-gray-200">
                <MapContainer center={[22.5937, 78.9629]} zoom={5} minZoom={4} className="w-full h-full" preferCanvas={true}>
                    <MapResizer onZoomChange={setCurrentZoom} onManualZoom={handleManualZoom} />
                    <TileLayer
                        url="https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}"
                        attribution=''
                        maxZoom={16}
                    />
                    {geoJsonData && (
                        <StateBordersLayer
                            geoJsonData={geoJsonData}
                            selectedState={selectedState}
                            onSelectState={handleSelectState}
                        />
                    )}
                    {geoJsonData && heatPoints.length > 0 && (
                        <ImdWeatherLayer geoJsonData={geoJsonData} points={heatPoints} />
                    )}
                    {districtGeoJson && selectedState && (
                        <DistrictBordersLayer
                            geoJsonData={districtGeoJson}
                            selectedState={selectedState}
                            selectedDistrict={selectedDistrict}
                            onSelectDistrict={handleSelectDistrict}
                        />
                    )}
                    {selectedState && selectedDistrict && (
                        <DistrictOperators selectedState={selectedState} selectedDistrict={selectedDistrict} />
                    )}
                </MapContainer>

                {/* Glassmorphism Stats Panel - Hidden when viewing India level */}
                {viewLevel !== 'India' && (
                    <div className="absolute top-4 right-4 z-[1000] bg-white/85 backdrop-blur-md p-5 rounded-xl shadow-xl border border-white/50 min-w-[260px] transition-all duration-300">
                        <h3 className="font-bold text-gray-500 text-xs uppercase tracking-widest flex items-center gap-2">
                            {viewLevel} Analytics
                            <span className="bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full text-[10px]">Live</span>
                        </h3>
                        <p className="text-gray-900 mt-1 font-bold text-xl">
                            {viewLevel === 'District' ? selectedDistrict : selectedState}
                        </p>
                        
                        <div className="mt-4 pt-4 border-t border-gray-200/50">
                            <div className="flex justify-between items-end mb-4">
                                <p className="text-xs text-gray-500 uppercase font-semibold">Total Operators</p>
                                <p className="text-3xl font-extrabold text-gray-800 tracking-tight">
                                    {countLoading ? (
                                        <span className="inline-block w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></span>
                                    ) : (
                                        stats?.total?.toLocaleString()
                                    )}
                                </p>
                            </div>
                            
                            {!countLoading && stats && (
                                <div className="flex flex-col gap-3">
                                    {[
                                        { label: 'Critical', val: stats.critical, color: '#7f1d1d' },
                                        { label: 'High', val: stats.high, color: '#ef4444' },
                                        { label: 'Medium', val: stats.medium, color: '#f97316' },
                                        { label: 'Low', val: stats.low, color: '#eab308' },
                                        { label: 'No Risk', val: stats.no, color: '#22c55e' }
                                    ].map((item) => (
                                        <div key={item.label} className="flex flex-col gap-1">
                                            <div className="flex justify-between text-xs">
                                                <span className="font-medium text-gray-700 flex items-center gap-2">
                                                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }}></span>
                                                    {item.label}
                                                </span>
                                                <span className="font-bold text-gray-900">{item.val?.toLocaleString()}</span>
                                            </div>
                                            <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                                <div 
                                                    className="h-full rounded-full transition-all duration-500 ease-out" 
                                                    style={{ width: `${getPercentage(item.val)}%`, backgroundColor: item.color }}
                                                ></div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </PageWrapper>
    );
};

export default IndiaRiskHeatmap;