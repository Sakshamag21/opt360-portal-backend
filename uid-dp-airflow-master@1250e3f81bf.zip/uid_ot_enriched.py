from airflow import DAG
from datetime import datetime
from airflow.operators.python import PythonOperator
from strot_alert_notification import (
    alert_failure_callback,
    configure
)

job_name = "ot_enriched_update_daily"
desc = "OT Enriched update"
file_name = "origin_tracker_merge_daily"

# Spark Connect configuration
SPARK_CONNECT_URL = "sc://spark-connect-service.strot-spark.svc.cluster.local:15002"
configure(channel="dataplatformtesting")
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2026, 9, 22),
    'retries': 1,
    'on_failure_callback':  alert_failure_callback,
}

dag = DAG(
    f'{job_name}',
    default_args=default_args,
    description=f'{desc}',
    schedule="30 2 * * *",
    catchup=False,
    tags=['uid_master_tables']
)


import time
import boto3
import hashlib
import base64
import json
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark.sql import functions as f
from pyspark.sql.functions import col, row_number, date_format, when, struct, udf, hex, unhex
from concurrent.futures import ThreadPoolExecutor, as_completed
from pyspark.sql.types import StringType
import gc
import shutil


def run_ot_enriched_merge():
    """
    Run OT Enriched merge via Spark Connect
    """
    # Initialize Spark session via Spark Connect
    spark = (
        SparkSession.builder.remote(SPARK_CONNECT_URL)
        .appName("ot-enriched-merge-daily")
        .config("spark.sql.legacy.mysql.bitArrayMapping.enabled","true") \
        .getOrCreate()
    )

    print("Spark session created via Spark Connect")

    try:
        session = boto3.session.Session(
            aws_access_key_id='9S0KLIQO7T2XCNGH4P4A',
            aws_secret_access_key='XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4'
        )
        s3_client = session.client('s3', endpoint_url='http://10.10.103.12:425')
        s3_client.download_file('prd-bi-data-platform-configs', 'salt/salts.txt', '/tmp/salts_from_s3.txt')

        xyz = 0
        with open('/tmp/salts_from_s3.txt', "r") as file:
            salts = json.load(file)
            print("Salts file created")
            xyz = 1
        if xyz == 0:
            print("Unable to load salts file")
            raise Exception("Failed to load salts file")

        def process_sparkdf_ts(df):
            data_types = df.dtypes
            ts_columns = [x[0] for x in data_types if x[1] == "timestamp"]
            for ts_column in ts_columns:
                df = df.withColumn(ts_column, f.to_timestamp(f.to_timestamp(df[ts_column]), "yyyy-MM-dd HH:mm:ss"))
            return df

        @udf(returnType=StringType())
        def uid_hashing(number, salts=salts):
            salt = salts[str(number)[:2]]
            hasher = hashlib.sha256()
            hasher.update((salt + str(number)).encode())
            hashed_value = hasher.digest()
            b64_hash = base64.b64encode(hashed_value).decode('utf-8')
            return b64_hash

        mysql_username = "data_platform_R"
        mysql_password = "Data_p!atform_7634"
        mysql_table_to_read = "uid_origin_tracker"

        # Read specific columns using a SQL query
        def func(mysql_host, x, y):
            for i in range(x, y + 1):
                print(f"Fetching MySQL data for shard {i}")
                query = f"""(SELECT *,
                        substring(uid,1,2) as shard_hint,
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind, 2, 2), 32, '0'), 32, 1) , 
                            SUBSTRING(LPAD(CONV(reject_ind, 2, 2), 32, '0'), 32, 1)) AS BINARY) AS updt_UID_STATUS,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind, 2, 2), 32, '0'), 31, 1) , 
                            SUBSTRING(LPAD(CONV(reject_ind, 2, 2), 32, '0'), 31, 1)) AS BINARY) AS updt_RESIDENT_NAME,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind, 2, 2), 32, '0'), 30, 1) , 
                            SUBSTRING(LPAD(CONV(reject_ind, 2, 2), 32, '0'), 30, 1)) AS BINARY) AS updt_RESIDENT_NAME_LOCAL,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind, 2, 2), 32, '0'), 29, 1) , 
                            SUBSTRING(LPAD(CONV(reject_ind, 2, 2), 32, '0'), 29, 1)) AS BINARY) AS updt_DOB,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind, 2, 2), 32, '0'), 28, 1) , 
                            SUBSTRING(LPAD(CONV(reject_ind, 2, 2), 32,'0'),28 ,1)) AS BINARY) AS updt_DOB_TYPE,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind, 2, 2), 32,'0'),27 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),27 ,1)) AS BINARY) AS updt_GENDER,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),26 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),26 ,1)) AS BINARY) AS updt_GUARDIAN_DETAILS,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),25 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),25 ,1)) AS BINARY) AS updt_INTRODUCER_DETAILS,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),24 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),24 ,1)) AS BINARY) AS updt_MOBILE_DETAILS,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),23 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),23 ,1)) AS BINARY) AS updt_EMAIL_DETAILS,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),22 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),22 ,1)) AS BINARY) AS updt_BANK_SHARING_CNST,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),21 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),21 ,1)) AS BINARY) AS updt_INFO_SHARING_CNST,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),20 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),20 ,1)) AS BINARY) AS updt_RESIDENT_LANG_CODE,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),19 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),19 ,1)) AS BINARY) AS updt_HOF_PROOF,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),18 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),18 ,1)) AS BINARY) AS updt_RESIDENT_DOD,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),17 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),17 ,1)) AS BINARY) AS updt_ADDRESS,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),16 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),16 ,1)) AS BINARY) AS updt_ADDRESS_LOCAL,
                
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind, 2, 2), 32, '0'), 15, 1) , 
                            SUBSTRING(LPAD(CONV(reject_ind, 2, 2), 32, '0'), 15, 1)) AS BINARY) AS updt_EXTENDED_ATTRIBUTES,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind, 2, 2), 32, '0'), 14, 1) , 
                            SUBSTRING(LPAD(CONV(reject_ind, 2, 2), 32, '0'), 14, 1)) AS BINARY) AS updt_PHOTO,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind, 2, 2), 32, '0'), 13, 1) , 
                            SUBSTRING(LPAD(CONV(reject_ind, 2, 2), 32, '0'), 13, 1)) AS BINARY) AS updt_EXCEPTION_PHOTO,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind, 2, 2), 32, '0'), 12, 1) , 
                            SUBSTRING(LPAD(CONV(reject_ind, 2, 2), 32, '0'), 12, 1)) AS BINARY) AS updt_BIOMETRIC_EXCEPTION,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind, 2, 2), 32, '0'), 11, 1) , 
                            SUBSTRING(LPAD(CONV(reject_ind, 2, 2), 32, '0'), 11, 1)) AS BINARY) AS updt_BIOMETRICS,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind, 2, 2), 32, '0'), 10, 1) , 
                            SUBSTRING(LPAD(CONV(reject_ind, 2, 2), 32,'0'),10 ,1)) AS BINARY) AS updt_NRI,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),9 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),9 ,1)) AS BINARY) AS updt_FOREIGN_RESIDENT,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),8 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),8 ,1)) AS BINARY) AS updt_NATIONALITY,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),7 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),7 ,1)) AS BINARY) AS updt_POI,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),6 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),6 ,1)) AS BINARY) AS updt_POB,
                        
                        CAST(CONCAT(
                            SUBSTRING(LPAD(CONV(update_ind ,2 ,2),32,'0'),5 ,1 ) , 
                            SUBSTRING(LPAD(CONV(reject_ind ,2 ,2),32,'0'),5 ,1)) AS BINARY) AS updt_POA            
                
                        from {mysql_table_to_read} where date(enr_status_date) >= date(current_timestamp + interval '330' minute - interval '15' day)
                        ) as T"""
                mysql_db = f'uidv2_0_{i}'
                df_filtered = spark.read.format("jdbc") \
                    .option("url", f"jdbc:mysql://{mysql_host}:3306/{mysql_db}?zeroDateTimeBehavior=convertToNull&connectTimeout=30000&socketTimeout=600000&autoReconnect=true&maxReconnects=5") \
                    .option("dbtable", query) \
                    .option("user", mysql_username) \
                    .option("password", mysql_password) \
                    .option("driver", "com.mysql.cj.jdbc.Driver") \
                    .option("numPartitions", 5) \
                    .option("fetchsize", 100000) \
                    .load()

                df_filtered = process_sparkdf_ts(df_filtered)
                df_filtered = df_filtered.withColumn('uid', uid_hashing(df_filtered['uid']))
                df_filtered.createOrReplaceTempView(f"temp_view{i}")
                print(f"Finished fetching MySQL data for shard {i}")

        mysql_host_mapping = {
            "10.10.108.231": (20, 35),
            "10.10.108.232": (36, 51),
            "10.10.108.233": (52, 67),
            "10.10.108.234": (68, 83),
            "10.10.108.235": (84, 99)
        }
        for x in mysql_host_mapping:
            func(x, mysql_host_mapping[x][0], mysql_host_mapping[x][1])

        union_query = " UNION ALL ".join([f"""SELECT tracker_key, uid,refid,eid,enr_date,
                enr_num,enr_type,enr_mode,enr_status,enr_status_date,available_in_abis,app_num,registrar_code,ea_code,operator_id,supervisor_id,
                upload_time,update_ind,reject_ind, auth_extraction_status,auth_extraction_status_date,IsChild,linkedEnrolment_eid,
                cast(bestPhotoCbeffMatchIdx as int) as  bestPhotoCbeffMatchIdx,cast(bestLeftSlabCbeffMatchIdx as int) as  bestLeftSlabCbeffMatchIdx,
                cast(bestRightSlabCbeffMatchIdx as int) as  bestRightSlabCbeffMatchIdx,cast(bestThumbsSlabCbeffMatchIdx as int) as  bestThumbsSlabCbeffMatchIdx,
                cast(bestLeftIrisCbeffMatchIdx as int) as  bestLeftIrisCbeffMatchIdx,cast(bestRightIrisCbeffMatchIdx as int) as  bestRightIrisCbeffMatchIdx,
                packet_version,source,source_request_id,source_client_id,source_client_machine_id,source_client_version,created_by,creation_date,
                last_updated_by,last_updated_date, shard_hint,
                updt_uid_status,updt_resident_name,updt_resident_name_local,updt_dob,updt_dob_type,updt_gender,updt_guardian_details,
                updt_introducer_details,updt_mobile_details,updt_email_details,updt_bank_sharing_cnst,updt_info_sharing_cnst,updt_resident_lang_code,
                updt_hof_proof,updt_resident_dod,updt_address,updt_address_local,updt_extended_attributes,updt_photo,updt_exception_photo,
                updt_biometric_exception,updt_biometrics,updt_nri,updt_foreign_resident,updt_nationality,updt_poi,updt_pob,updt_poa FROM temp_view{i}""" for i in range(20, 100)])

        union_df = spark.sql(union_query)

        # Create a temporary view for the union result
        union_df.createOrReplaceTempView("unioned_data")

        result_df = spark.sql("""
            MERGE INTO strot.mysql_uid_v2.uid_origin_tracker_enriched t
            USING ( select tracker_key, uid,refid,eid,enr_date,
                enr_num,enr_type,enr_mode,enr_status,enr_status_date,available_in_abis,app_num,registrar_code,ea_code,operator_id,supervisor_id,
                upload_time,CAST(update_ind as BOOLEAN) AS update_ind, CAST(reject_ind as BOOLEAN) AS reject_ind,auth_extraction_status,auth_extraction_status_date,IsChild,linkedEnrolment_eid,
                cast(bestPhotoCbeffMatchIdx as int) as  bestPhotoCbeffMatchIdx,cast(bestLeftSlabCbeffMatchIdx as int) as  bestLeftSlabCbeffMatchIdx,
                cast(bestRightSlabCbeffMatchIdx as int) as  bestRightSlabCbeffMatchIdx,cast(bestThumbsSlabCbeffMatchIdx as int) as  bestThumbsSlabCbeffMatchIdx,
                cast(bestLeftIrisCbeffMatchIdx as int) as  bestLeftIrisCbeffMatchIdx,cast(bestRightIrisCbeffMatchIdx as int) as  bestRightIrisCbeffMatchIdx,
                packet_version,source,source_request_id,source_client_id,source_client_machine_id,source_client_version,created_by,creation_date,
                last_updated_by,last_updated_date, shard_hint,
                updt_uid_status,updt_resident_name,updt_resident_name_local,updt_dob,updt_dob_type,updt_gender,updt_guardian_details,
                updt_introducer_details,updt_mobile_details,updt_email_details,updt_bank_sharing_cnst,updt_info_sharing_cnst,updt_resident_lang_code,
                updt_hof_proof,updt_resident_dod,updt_address,updt_address_local,updt_extended_attributes,updt_photo,updt_exception_photo,
                updt_biometric_exception,updt_biometrics,updt_nri,updt_foreign_resident,updt_nationality,updt_poi,updt_pob,updt_poa from unioned_data ) s
            on t.shard_hint=s.shard_hint and t.tracker_key=s.tracker_key
            WHEN MATCHED 
                THEN UPDATE SET *
            WHEN NOT MATCHED BY TARGET
                THEN INSERT *
            """)
        result_df.show()
        print(f"Finished merging")

        print("✅ OT Enriched merge completed successfully")

    except Exception as e:
        print(f"❌ Error during OT Enriched merge: {e}")
        raise
    finally:
        spark.stop()


task = PythonOperator(
    task_id="ot_enriched_merge",
    python_callable=run_ot_enriched_merge,
    dag=dag,
)