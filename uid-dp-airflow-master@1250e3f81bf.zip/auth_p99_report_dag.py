import datetime
import pendulum
import pandas as pd
import smtplib
from trino.dbapi import connect
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from airflow import DAG
from airflow.operators.python import PythonOperator

# --- Settings ---
TRINO_HOST = "10.10.118.35"
TRINO_PORT = 8080
TRINO_USER = "airflow_dag_auth_p99"

SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25
SENDER_EMAIL = "airflow@uidai.net.in"

# UPDATE THIS LIST with the actual recipient emails
RECIPIENT_EMAILS = [
    "siduidai241202@gmail.com",
    "techexe17.yp24@uidai.net.in",
    "authappsupport.bdc@uidai.net.in",
    "biapplication.support@uidai.net.in",
    "kirankumar.g@uidai.net.in",
    "cidr.cctech@uidai.net.in",
    "authsupport@uidai.net.in",
    "aoe-tc@nic.in",
    "aoe9-tc@nic.in",
    "appops.eng34-tc@nic.in",
    "kiranb.tcs.uidai@nic.in"
]

# --- SQL Query 1: AUTH Latency ---
AUTH_QUERY = """    
WITH aggregated_data AS (
    SELECT
        date_add('minute', (minute(event_timestamp) / 15) * 15, date_trunc('hour', event_timestamp)) AS window_start,
        COUNT(enrolmentreferenceid) AS Count,
        approx_percentile(authDuration, ARRAY[0.80, 0.85, 0.90, 0.95, 0.98, 0.99]) AS percentiles
    FROM
        flink_stream.stream_auth.auth_txn_raw_union_v1
    WHERE
        event_timestamp >= CAST(current_date - INTERVAL '1' DAY AS TIMESTAMP)
        AND event_timestamp < CAST(current_date AS TIMESTAMP)
        AND aua != '0000340000'
    GROUP BY
        1
)
SELECT
    date_format(window_start, '%Y-%m-%d %H:%i:%s') AS Starting_Time,
    Count,
    percentiles[6] AS p99_latency,
    percentiles[5] AS p98_latency,
    percentiles[4] AS p95_latency,
    percentiles[3] AS p90_latency,
    percentiles[2] AS p85_latency,
    percentiles[1] AS p80_latency
FROM
    aggregated_data
ORDER BY
    window_start
"""

# --- SQL Query 2: KYC Latency ---
KYC_QUERY = """    
WITH aggregated_data AS (
    SELECT
        date_add('minute', (minute(event_timestamp) / 15) * 15, date_trunc('hour', event_timestamp)) AS window_start,
        COUNT(enr_ref_id) AS Count,
        approx_percentile(kyc_duration, ARRAY[0.80, 0.85, 0.90, 0.95, 0.98, 0.99]) AS percentiles
    FROM
        flink_stream.stream_auth.auth_kyc_raw_union_v1
    WHERE
        event_timestamp >= CAST(current_date - INTERVAL '1' DAY AS TIMESTAMP)
        AND event_timestamp < CAST(current_date AS TIMESTAMP)
        AND kua != '0000340000'
    GROUP BY
        1
)
SELECT
    date_format(window_start, '%Y-%m-%d %H:%i:%s') AS Starting_Time,
    Count,
    percentiles[6] AS p99_latency,
    percentiles[5] AS p98_latency,
    percentiles[4] AS p95_latency,
    percentiles[3] AS p90_latency,
    percentiles[2] AS p85_latency,
    percentiles[1] AS p80_latency
FROM
    aggregated_data
ORDER BY
    window_start
"""

# --- SQL Query 3: OTP Latency ---
OTP_QUERY = """    
WITH aggregated_data AS (
    SELECT
        date_add('minute', (minute(event_timestamp) / 15) * 15, date_trunc('hour', event_timestamp)) AS window_start,
        COUNT(resident_enref_id) AS Count,
        approx_percentile(CAST(otp_duration AS BIGINT), ARRAY[0.80, 0.85, 0.90, 0.95, 0.98, 0.99]) AS percentiles
    FROM
        flink_stream.stream_auth.auth_otp_raw_union_v1
    WHERE
        event_timestamp >= CAST(current_date - INTERVAL '1' DAY AS TIMESTAMP)
        AND event_timestamp < CAST(current_date AS TIMESTAMP)
        AND aua_code != '0000340000'
        AND regexp_like(otp_duration, '^[0-9]+$')
    GROUP BY
        1
)
SELECT
    date_format(window_start, '%Y-%m-%d %H:%i:%s') AS Starting_Time,
    Count,
    percentiles[6] AS p99_latency,
    percentiles[5] AS p98_latency,
    percentiles[4] AS p95_latency,
    percentiles[3] AS p90_latency,
    percentiles[2] AS p85_latency,
    percentiles[1] AS p80_latency
FROM
    aggregated_data
ORDER BY
    window_start
"""

def runquery_to_df(cur, query, label):
    print(f"Executing {label} query...")
    cur.execute(query)
    rows = cur.fetchall()
    cols = [i[0] for i in cur.description]
    df = pd.DataFrame(rows, columns=cols)
    print(f"{label} rows fetched: {len(df)}")
    return df

def fetch_and_process_data():
    print("Connecting to Trino and executing queries...")
    with connect(
            host=TRINO_HOST,
            port=TRINO_PORT,
            user=TRINO_USER,
            catalog=None,
            schema=None
    ) as conn:
        cur = conn.cursor()
        df_auth = runquery_to_df(cur, AUTH_QUERY, "AUTH")
        df_kyc  = runquery_to_df(cur, KYC_QUERY, "KYC")
        df_otp  = runquery_to_df(cur, OTP_QUERY, "OTP")

    ist_tz = pendulum.timezone("Asia/Kolkata")
    yesterday_date_obj = datetime.datetime.now(ist_tz) - datetime.timedelta(days=1)
    yesterday_str = yesterday_date_obj.strftime('%d_%b_%Y')
    yesterday_email_str = yesterday_date_obj.strftime('%d/%m/%Y')

    auth_csv = "/tmp/Auth_P99.csv"
    kyc_csv  = "/tmp/Kyc_P99.csv"
    otp_csv  = "/tmp/Otp_P99.csv"

    df_auth.to_csv(auth_csv, index=False)
    df_kyc.to_csv(kyc_csv, index=False)
    df_otp.to_csv(otp_csv, index=False)

    print(f"✅ AUTH data saved to {auth_csv}")
    print(f"✅ KYC  data saved to {kyc_csv}")
    print(f"✅ OTP  data saved to {otp_csv}")

    return {
        "auth_csv": auth_csv,
        "kyc_csv": kyc_csv,
        "otp_csv": otp_csv,
        "yesterday_email_str": yesterday_email_str,
        "auth_rows": len(df_auth),
        "kyc_rows": len(df_kyc),
        "otp_rows": len(df_otp),
    }

def send_email_task(**kwargs):
    data = kwargs['ti'].xcom_pull(task_ids='fetch_data_task')

    if not data or not data.get("auth_csv"):
        print("No data generated. Skipping email.")
        return

    auth_csv = data["auth_csv"]
    kyc_csv  = data["kyc_csv"]
    otp_csv  = data["otp_csv"]
    yesterday_email_str = data["yesterday_email_str"]
    auth_rows = data["auth_rows"]
    kyc_rows  = data["kyc_rows"]
    otp_rows  = data["otp_rows"]

    msg = MIMEMultipart()
    msg['From'] = SENDER_EMAIL
    msg['To'] = ", ".join(RECIPIENT_EMAILS)
    msg['Subject'] = f"P99 Reports - {yesterday_email_str}"

    body = f"""    
Hi Team,    
    
Please find attached the P99 reports for yesterday ({yesterday_email_str}).    
  
Summary of rows generated:  
- AUTH: {auth_rows} intervals  
- KYC: {kyc_rows} intervals  
- OTP: {otp_rows} intervals  
    
Regards,    
Data Platform Team    
"""
    msg.attach(MIMEText(body, 'plain'))

    attachments = [
        (auth_csv, "AUTH_Latency"),
        (kyc_csv,  "KYC_Latency"),
        (otp_csv,  "OTP_Latency"),
    ]

    for filepath, label in attachments:
        with open(filepath, "rb") as attachment:
            part = MIMEApplication(attachment.read(), Name=filepath.split("/")[-1])
        part['Content-Disposition'] = f'attachment; filename="{filepath.split("/")[-1]}"'
        msg.attach(part)

    try:
        print("Sending email...")
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.sendmail(SENDER_EMAIL, RECIPIENT_EMAILS, msg.as_string())
        print("✅ Email sent successfully!")
    except Exception as e:
        print(f"❌ Failed to send email: {e}")
        raise

    # ==========================================
# DAG DEFINITION
# ==========================================
ist_tz = pendulum.timezone("Asia/Kolkata")

default_args = {
    'owner': 'Siddhaarrth Iyer',
    'depends_on_past': False,
    'start_date': datetime.datetime(2026, 9, 10, tzinfo=ist_tz),
    'email': ['techexe17.yp24@uidai.net.in'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': datetime.timedelta(minutes=5),
    'retry_exponential_backoff': True,
    'retry_max_delay': datetime.timedelta(minutes=30)
}

dag = DAG(
    'auth_p99_reports_daily',
    default_args=default_args,
    description='Fetches AUTH/KYC/OTP latency percentiles (15-min buckets) and emails the reports daily at 5 AM IST',
    schedule='0 3 * * *',
    catchup=False
)

fetch_data_task = PythonOperator(
    task_id='fetch_data_task',
    python_callable=fetch_and_process_data,
    dag=dag,
)

send_email_task = PythonOperator(
    task_id='send_email_task',
    python_callable=send_email_task,
    retries=3,
    retry_delay=datetime.timedelta(minutes=5),
    retry_exponential_backoff=True,
    dag=dag,
)

fetch_data_task >> send_email_task