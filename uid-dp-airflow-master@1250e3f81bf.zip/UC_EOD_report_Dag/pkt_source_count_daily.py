import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import pandas as pd
import pendulum
from trino.dbapi import connect
from airflow import DAG
from airflow.operators.python import PythonOperator

# ==========================================
# CONFIGURATION
# ==========================================

# Trino Configuration
trino_host = "10.10.116.75"
trino_port = 8080
trino_user = "airflow_dag_op"

# SMTP Configuration
SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25

# Email Recipients
mail_list = ["data.analyst-tc@uidai.net.in", 
    "techexecutive22-yp23@uidai.net.in", 
    "productmgr4-tc@uidai.net.in",
    "dir.eu-hq@uidai.net.in",
    "dd.eu1-hq@uidai.net.in",
    "pm1.eu1-hq@uidai.net.in",
    "hoe.dev-tc@uidai.net.in",
    "Dd3.romumbai@uidai.net.in",
    "So5-romum@uidai.net.in",
    "Am1.romumbai@uidai.net.in",
    "Am3.romumbai@uidai.net.in",
    "reconcell.romumbai@uidai.net.in",
    "vivek.chand@csc.gov.in",
    "pmu1.eu1-hq@uidai.net.in",
    "alladgro@uidai.net.in",
    "allddro.uidai@uidai.net.in",
    "haridas.bhavani@uidai.net.in",
    "askhyd-rohyd@uidai.net.in",
    "dir3-rornc@uidai.net.in",
    "amka4-roblr@uidai.net.in",
    "amka1-roblr@uidai.net.in",
    "amtech.rodelhi@uidai.net.in",
    "amuk1.rodelhi@uidai.net.in",
    "pmdel.rodelhi@uidai.net.in",
    "amrajjaipur.rodelhi@uidai.net.in",
    "pmuk-rodelhi@uidai.net.in",
    "pm3-rohyd@uidai.net.in",
    "Itsupport.scl-sca@uidai.net.in",
    "allddgro@uidai.net.in",
    "shailendra.singh@uidai.net.in",
    "pm1-rolko@uidai.net.in",
    "dir1-rochd@uidai.net.in",
    "pm-rochd@uidai.net.in",
    "dir-mp.rodelhi@uidai.net.in",
    "ampb3-rochd@uidai.net.in",
    "amjk1-rochd@uidai.net.in",
    "pm.jk-rochd@uidai.net.in",
    "dd1-rochd@uidai.net.in"
]

bcc_list = []

# ==========================================
# QUERY TEMPLATE  
# ==========================================
email_query_template = '''
SELECT
  pkt_source,
  count(distinct enrolment_eid) AS count
FROM
  flink_stream.stream_enu.ens_packet_enriched
WHERE
pkt_source IN ('ECL', 'ECMP', 'UC')
  AND date(event_timestamp) = date({date_expr})
GROUP BY
  pkt_source
ORDER BY
  pkt_source ASC
'''

# ==========================================
# DAG DEFINITION  
# ==========================================
ist_tz = pendulum.timezone("Asia/Kolkata")

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime.datetime(2025, 6, 8, tzinfo=ist_tz),
    'email': ["data.analyst-tc@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': datetime.timedelta(minutes=2)
}

dag_7pm = DAG(
    'pkt_source_count_daily_mail_7PM',
    default_args=default_args,
    description='7PM DAG - UC/ECMP/ECL packet count + Total (Tabular Email Only)',
    schedule="0 19 * * *",          # Runs at 7:00 PM IST daily
    catchup=False
)

# ==========================================
# HELPERS
# ==========================================
def trino_fetch(query, catalog='flink_stream', schema='stream_enu',
                host=trino_host, port=trino_port, user=trino_user):
    try:
        conn = connect(host=host, port=port, user=user, catalog=catalog)
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"success": 1, "df": pd.DataFrame()}
        cols = [i[0] for i in cur.description]
        df = pd.DataFrame(body, columns=cols)
        return {"success": 1, "df": df}
    except Exception as e:
        return {"success": 0, "msg": str(e)}


def build_html_table(df: pd.DataFrame) -> str:
    """Render dataframe as a styled HTML table."""
    rows_html = ""
    for _, row in df.iterrows():
        pkt = row['pkt_source']
        cnt = row['count']
        # Highlight Total row
        if str(pkt).strip().upper() == 'TOTAL':
            rows_html += (
                f"<tr style='background-color:#1f4e79;color:#ffffff;font-weight:bold;'>"
                f"<td style='padding:8px 12px;border:1px solid #ccc;'>{pkt}</td>"
                f"<td style='padding:8px 12px;border:1px solid #ccc;text-align:right;'>{cnt:,}</td>"
                f"</tr>"
            )
        else:
            rows_html += (
                f"<tr style='background-color:#ffffff;'>"
                f"<td style='padding:8px 12px;border:1px solid #ccc;'>{pkt}</td>"
                f"<td style='padding:8px 12px;border:1px solid #ccc;text-align:right;'>{cnt:,}</td>"
                f"</tr>"
            )

    html = f"""
    <table style="border-collapse:collapse;font-family:Arial,sans-serif;font-size:13px;width:50%;">
        <thead>
            <tr style="background-color:#4472C4;color:#ffffff;">
                <th style="padding:8px 12px;border:1px solid #ccc;text-align:left;">Packet Source</th>
                <th style="padding:8px 12px;border:1px solid #ccc;text-align:right;">Distinct Enrolment Count</th>
            </tr>
        </thead>
        <tbody>
            {rows_html}
        </tbody>
    </table>
    """
    return html


def send_email_via_smtp(to_email, cc_emails, bcc_emails, html_body, subject):
    sender_email = "airflow@uidai.net.in"

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = to_email
    if cc_emails:
        msg['Cc'] = ", ".join(cc_emails)
    msg['Subject'] = subject

    msg.attach(MIMEText(html_body, 'html'))

    recipients = [to_email]
    if cc_emails:
        recipients.extend(cc_emails)
    if bcc_emails:
        recipients.extend(bcc_emails)

    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(sender_email, recipients, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"❌ SMTP Error: {str(e)}")
        return False


# ==========================================
# MAIN TASK
# ==========================================
def fetch_pkt_counts_and_mail(**kwargs):
    current_time_ist = datetime.datetime.now(ist_tz)
    report_time = current_time_ist
    report_date_str = report_time.strftime("%d-%m-%Y")

    day = report_time.day
    suffix = 'th' if 11 <= day <= 13 else {1: 'st', 2: 'nd', 3: 'rd'}.get(day % 10, 'th')
    full_date_str = f"{day}{suffix} {report_time.strftime('%B %Y')}"

    # Explicitly format today's date in YYYY-MM-DD format (e.g., '2026-09-24')
    # This guarantees it fetches data for the exact current year and date.
    date_expr = f"'{report_time.strftime('%Y-%m-%d')}'"
    query = email_query_template.format(date_expr=date_expr)

    print(f"Executing Trino query for exact date: {date_expr}")
    result = trino_fetch(query)

    if result["success"] == 0:
        raise RuntimeError(f"Trino extraction failed: {result.get('msg')}")

    df = result["df"]

    # Build the final dataframe with all 3 sources + Total row
    expected_sources = ['UC', 'ECMP', 'ECL']
    if df.empty:
        final_df = pd.DataFrame({
            'pkt_source': expected_sources,
            'count': [0, 0, 0]
        })
    else:
        df['count'] = pd.to_numeric(df['count'], errors='coerce').fillna(0).astype('int64')
        existing = dict(zip(df['pkt_source'], df['count']))
        rows = []
        for src in expected_sources:
            rows.append({'pkt_source': src, 'count': int(existing.get(src, 0))})
        final_df = pd.DataFrame(rows)

    # Add Total row
    total_count = int(final_df['count'].sum())
    total_row = pd.DataFrame([{'pkt_source': 'TOTAL', 'count': total_count}])
    final_df = pd.concat([final_df, total_row], ignore_index=True)

    print("Final Report DataFrame:")
    print(final_df.to_string(index=False))

    # ---- Build HTML email body ----
    html_table = build_html_table(final_df)

    html_body = f"""
    <html>
        <body style="font-family: Arial, sans-serif; color: #333333; line-height: 1.6;">
            <p>Dear All,</p>
            <p>Please find below the <b>Packet Source wise Enrolment Count</b> report for
               <b>{full_date_str}</b>.</p>
            <br>
            {html_table}
            <br>
            <p>Regards,<br>
            Data Platform Team</p>
            <br>
            <p style="font-size: 11px; color: #888888; font-style: italic;">
                <b>Note:</b> Count column reflects distinct enrolment_eid per packet source for the current date.
            </p>
        </body>
    </html>
    """

    subject = f"Packet Source wise Count Report - {report_date_str}"

    failed_emails = []
    for target_email in mail_list:
        try:
            success = send_email_via_smtp(
                to_email=target_email,
                cc_emails=cc_list,
                bcc_emails=bcc_list,
                html_body=html_body,
                subject=subject
            )
            if success:
                print(f"✅ Email sent successfully to: {target_email}")
            else:
                print(f"❌ Failed to send email to: {target_email}")
                failed_emails.append(target_email)
        except Exception as mail_error:
            print(f"Network error while sending to {target_email}: {str(mail_error)}")
            failed_emails.append(target_email)

    if failed_emails:
        raise RuntimeError(
            f"DAG FAILED. Could not send email to: {', '.join(failed_emails)}"
        )

    print("✅ DAG execution completed successfully.")


# ==========================================
# TASK
# ==========================================
task_7pm = PythonOperator(
    task_id='pkt_source_count_7PM_task',
    python_callable=fetch_pkt_counts_and_mail,
    dag=dag_7pm,
)

task_7pm