#dag

import requests
import json
import urllib3
from airflow.sdk import DAG # type: ignore
from datetime import datetime
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from kubernetes.client import models as k8s
from strot_alert_notification import (
    alert_failure_callback,
    configure
)

# Disable SSL warnings for corporate proxy
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

configure(channel="dataplatformtesting")
# ---------------------------------------------------------
# DAG DEFINITION
# ---------------------------------------------------------
job_name = "uid_status_kafka_publish"
desc = "Job to publish UID status changes to Kafka with idempotency"
pod_name = "uid-status-kafka-pod"
t_id = "run_uid_status_kafka"
driver_pod_name = "zz-uid-status-kafka-driver-pod"
file_name = "uid_status_kafka_publish"
namespace = 'strot-spark'
sa = 'strot-service-account'
storage_c = 'gpu-ceph-ext4'

default_args = {
    'owner': 'Goverdhan',
    'depends_on_past': False,
    'start_date': datetime(2026, 9, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'on_failure_callback':  alert_failure_callback
    #'on_success_callback': zoho_success_callback
}

custom_toleration = k8s.V1Toleration(
    key="strot",
    operator='Equal',
    value='true',
    effect='NoSchedule'
)

dag = DAG(
    f'{job_name}',
    default_args=default_args,
    description=f'{desc}',
    schedule='0 2 * * *',  # Runs daily at 2 AM
    catchup=False,
    tags=["UID", "status-change", "kafka", "idempotent", "zoho-alerts"]
)

# ---------------------------------------------------------
# SPARK TASK DEFINITION
# ---------------------------------------------------------
task = KubernetesPodOperator(
    namespace=f'{namespace}',
    service_account_name=f'{sa}',
    image="hbdc-harbor-registry-prod.uidai.net.in/data-platform/pyspark:3.4.2_3", 
    container_resources=k8s.V1ResourceRequirements(
        requests={'cpu': '1', 'memory': '2Gi'},
        limits={'cpu': '1', 'memory': '2Gi'}
    ),
    tolerations=[custom_toleration],
    config_file="/opt/airflow/dags/gpu_kubeconfig_hdc",
    name=f"{pod_name}", 
    task_id=f"{t_id}",
    cmds=["/bin/bash", "-c"],
    arguments=[f"""/opt/spark/bin/spark-submit \
            --master k8s://https://10.10.102.220:443 \
            --deploy-mode cluster \
            --name {driver_pod_name} \
            --class org.apache.spark.deploy.SparkSubmit \
            --conf spark.kubernetes.container.image=hbdc-harbor-registry-prod.uidai.net.in/data-platform/pyspark:3.4.2_3 \
            --conf spark.kubernetes.namespace={namespace} \
            --conf spark.serializer=org.apache.spark.serializer.KryoSerializer \
            --conf spark.driver.cores=4 \
            --conf spark.executor.cores=4 \
            --conf spark.executor.instances=10 \
            --conf spark.driver.memory=120g \
            --conf spark.executor.memory=256g \
            --conf spark.driver.maxResultSize=8g \
            --conf spark.kubernetes.driver.limit.cores=4 \
            --conf spark.kubernetes.executor.limit.cores=4 \
            --conf spark.kubernetes.driver.request.cores=4 \
            --conf spark.kubernetes.executor.request.cores=4 \
            --conf spark.driver.memoryOverhead=16g \
            --conf spark.executor.memoryOverhead=32g \
            --conf spark.executor.extraJavaOptions=-XX:+UseG1GC \
            --conf spark.hadoop.fs.s3a.aws.credentials.provider=org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider \
            --conf spark.kubernetes.driver.ownPersistentVolumeClaim=true \
            --conf spark.kubernetes.driver.reusePersistentVolumeClaim=true \
            --conf spark.kubernetes.local.dirs.tmpfs=true \
            --conf spark.shuffle.sort.io.plugin.class=org.apache.spark.shuffle.KubernetesLocalDiskShuffleDataIO \
            --conf spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.options.claimName=OnDemand \
            --conf spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.options.storageClass={storage_c} \
            --conf spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.options.sizeLimit=200Gi \
            --conf spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.mount.path=/data \
            --conf spark.kubernetes.executor.volumes.persistentVolumeClaim.spark-local-dir-1.mount.readOnly=false \
            --conf spark.local.dir=/data/temp \
            --conf spark.sql.warehouse.dir=/data/sqlwarehouse \
            --conf hadoop.tmp.dir=/data/hadoop_temp \
            --conf spark.hadoop.fs.s3a.impl=org.apache.hadoop.fs.s3a.S3AFileSystem \
            --conf spark.hadoop.fs.s3a.path.style.access=true \
            --conf spark.hadoop.fs.s3a.secret.key=XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4 \
            --conf spark.hadoop.fs.s3a.access.key=9S0KLIQO7T2XCNGH4P4A \
            --conf spark.hadoop.fs.s3a.endpoint=http://10.10.103.12:425 \
            --conf spark.hadoop.fs.s3a.bucket.prd-bi-data-platform-lake-refid-subaua-store-00.secret.key=1NsEKbrullapyCrWZw4mbOnAG6yCyXrPK5M7KLEO \
            --conf spark.hadoop.fs.s3a.bucket.prd-bi-data-platform-lake-refid-subaua-store-00.access.key=FY9PRV9EN12ACC5VZWBX \
            --conf spark.hadoop.fs.s3a.bucket.prd-bi-data-platform-lake-refid-subaua-store-00.endpoint=http://10.10.103.253:80 \
            --conf spark.sql.extensions=org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions \
            --conf spark.sql.catalog.strot=org.apache.iceberg.spark.SparkCatalog \
            --conf spark.sql.catalog.strot.type=hive \
            --conf spark.sql.catalog.strot.uri=thrift://10.10.116.77:9083 \
            --conf spark.sql.catalog.flink_stream=org.apache.iceberg.spark.SparkCatalog \
            --conf spark.sql.catalog.flink_stream.type=hive \
            --conf spark.sql.catalog.flink_stream.uri=thrift://10.10.118.50:9083 \
            --conf spark.sql.catalog.warm_store=org.apache.iceberg.spark.SparkCatalog \
            --conf spark.sql.catalog.warm_store.type=hive \
            --conf spark.sql.catalog.warm_store.uri=thrift://10.10.118.2:9083 \
            --conf spark.kubernetes.authenticate.driver.serviceAccountName={sa} \
            --conf spark.rpc.message.maxSize=1000 \
            --jars local:///opt/spark/jars/hadoop-aws-3.3.4.jar,local:///opt/spark/jars/iceberg-spark-runtime-3.4_2.12-1.5.2.jar,local:///opt/spark/jars/mysql-connector-java-8.0.30.jar \
            s3a://prd-bi-data-platform-uploads/sparkjobs/{file_name}.py"""], 
    in_cluster=False, 
    get_logs=True, 
    log_events_on_failure=True, 
    dag=dag,
)

task