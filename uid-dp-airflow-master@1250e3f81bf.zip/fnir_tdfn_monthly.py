from airflow.sdk import DAG
from airflow.operators.python import PythonOperator



import datetime
import calendar
from trino.dbapi import connect
import base64
import json
import requests
from io import StringIO
import pandas as pd
import boto3
import logging

trino_host="10.10.116.75"
trino_port=8080
trino_user="admin_reporting_af_tdfn"

from kafka import KafkaProducer
topic = "COMMAND.STROT.RCS.REQUEST"
bootstrap_servers = "10.10.105.225:9092,10.10.106.171:9092,10.10.107.110:9092,10.10.105.75:9092,10.10.105.98:9092,10.10.105.238:9092,10.10.107.130:9092,10.10.105.33:9092,10.10.106.195:9092,10.10.106.144:9092,10.10.105.227:9092"


rcs_host = '10.81.116.128'
rcs_port = '9090'

mail_list= ["director-techdev2@uidai.net.in"]
cc= "tobio.tc@uidai.net.in,nec.support@uidai.net.in,app.developer-tc@uidai.net.in,nare.saraswathi@uidai.net.in,app.tester1-tc@uidai.net.in,pm2-tc@uidai.net.in,prod.mgr1-tc@uidai.net.in,project.incharge-tc@uidai.net.in,bio.specialist-tc@uidai.net.in,surajmukare.tcs@uidai.net.in,prod.mgr2-tc@uidai.net.in,suvvalas.nec@uidai.net.in,swastikchandra.nec@uidai.net.in,hoe.dev-tc@uidai.net.in,techexe15.yp25@uidai.net.in,techexecutive14-yp23@uidai.net.in,techexecutive22-yp23@uidai.net.in,productmgr4-tc@uidai.net.in"

# cc="techexe15.yp25@uidai.net.in"


# This Query Uses Candidate Match Raw V1 Table to get scaled score and also earlier to set a threshold of 400,
# Now biometrcis team does need score also they asked to remove the scaled score thresold.

# tdfn_fnir ="""
#         WITH mytab AS(
#             SELECT reference_code as ref_code, candidate_ref_code as cand_ref_code, creation_date as mdd_check_date
#             FROM flink_stream.stream_enu.abis_candidate_match_analysis_v1 
#             WHERE MONTH(creation_date) = MONTH(DATE_TRUNC('month', CURRENT_DATE) - INTERVAL '1' DAY)
#             AND YEAR(DATE_TRUNC('month', CURRENT_DATE) - INTERVAL '1' DAY) = YEAR(creation_date)
#             AND true_duplicate=1
            
#         ),
#         mytab1 AS(
#             SELECT ref_code, mdd_check_date
#             FROM(
#                 SELECT ref_code,mdd_check_date,
#                 ROW_NUMBER() OVER(
#                     PARTITION BY ref_code ORDER BY mdd_check_date
#                 ) as rn
#                 FROM mytab
#                 ) sub
#             WHERE rn = 1
#         ),
#         mytab2 AS(
#             SELECT t.ref_code as ref_code, s.abis_code as abis_code,
#             t.mdd_check_date as mdd_check_date
#             FROM mytab1 t JOIN flink_stream.stream_enu.abis_request_tracker_union_v1 s ON t.ref_code=s.reference_code
#             WHERE s.request_type='IDENTIFY' AND s.status='DEDUP_FAILURE'
#         ),
#         mytab3 AS(
#             SELECT ref_code,abis_code,mdd_check_date
#             FROM ( SELECT ref_code,abis_code,mdd_check_date,
#                     ROW_NUMBER() OVER ( PARTITION BY ref_code,abis_code ORDER BY mdd_check_date) as rn 
#                     FROM mytab2
#                     ) sub
#             WHERE rn=1
#         ),
#         mytab4 AS(
#             SELECT DATE(mdd_check_date) as mdd_check_date,
#             COUNT_IF(abis_code='ABIS1') AS TD1,
#             COUNT_IF(abis_code='ABIS2') AS TD2,
#             COUNT_IF(abis_code='ABIS3') As TD3
#             FROM mytab3
#             GROUP BY 1
#             ORDER BY 1
#         ),
#         mytable AS(
#             SELECT t.ref_code as ref_code, t.cand_ref_code as cand_ref_code, s.scaled_score as scaled_score,
#             t.mdd_check_date as mdd_check_date
#             FROM mytab t 
#             JOIN flink_stream.stream_enu.enu_globalprocessaudit v ON t.ref_code=v.edata_refid
#             JOIN flink_stream.stream_enu.abis_candidate_match_raw_v1 s ON t.cand_ref_code=s.candidates_ref_code
#             WHERE v.enrolmenttype='N'
#         ),
#         mytable2 AS (
#             SELECT ref_code, cand_ref_code, scaled_score, mdd_check_date
#             FROM (
#                 SELECT ref_code,cand_ref_code,scaled_score,mdd_check_date,
#                 ROW_NUMBER() OVER (PARTITION BY ref_code, cand_ref_code ORDER BY scaled_score DESC) AS rn
#                 FROM mytable
#             ) sub
#             WHERE rn = 1
#         ),
#         mytable3 AS(
#             SELECT t.ref_code as ref_code, t.cand_ref_code as cand_ref_code, t.scaled_score as scaled_score, s.abis_code as abis_code, s.status as status,
#             t.mdd_check_date as mdd_check_date, MAX(s.last_updated_date) as applicant_identify_last_updated_date
#             FROM mytable2 t JOIN flink_stream.stream_enu.abis_request_tracker_union_v1 s ON t.ref_code=s.reference_code
#             WHERE s.request_type='IDENTIFY' AND s.status='DEDUP_SUCCESS'
#             GROUP BY 1,2,3,4,5,6
#         ),
#         mytable4 AS(
#             SELECT t.ref_code as ref_code, t.cand_ref_code as cand_ref_code, t.scaled_score as scaled_score, t.abis_code as abis_code, t.status as status,
#             t.applicant_identify_last_updated_date as applicant_identify_last_updated_date, t.mdd_check_date as mdd_check_date,
#             MIN(s.last_updated_date) as cand_insert_last_updated_date
#             FROM mytable3 t JOIN flink_stream.stream_enu.abis_request_tracker_union_v1 s ON t.cand_ref_code=s.reference_code AND t.abis_code=s.abis_code
#             WHERE s.request_type='INSERT' AND s.status='INSERT_SUCCESS'
#             GROUP BY 1,2,3,4,5,6,7
#         ),
#         mytable5 AS(

#             SELECT ref_code,cand_ref_code,scaled_score,abis_code,status,applicant_identify_last_updated_date,cand_insert_last_updated_date,mdd_check_date
#             FROM (
#                 SELECT ref_code, cand_ref_code, scaled_score, abis_code, status,
#                     applicant_identify_last_updated_date, cand_insert_last_updated_date, mdd_check_date,
#                     ROW_NUMBER() OVER (
#                         PARTITION BY ref_code, abis_code
#                         ORDER BY cand_insert_last_updated_date
#                     ) AS rn
#                 FROM mytable4
#                 WHERE applicant_identify_last_updated_date > cand_insert_last_updated_date
#             ) sub
#             WHERE rn = 1
#         ),
#         mytable6 AS(
#             SELECT DATE(mdd_check_date) as mdd_check_date,
#             COUNT_IF(abis_code='ABIS1') AS FN1,
#             COUNT_IF(abis_code='ABIS2') AS FN2,
#             COUNT_IF(abis_code='ABIS3') As FN3
#             FROM mytable5
#             GROUP BY 1
#             ORDER BY 1
#         )
#             SELECT 
#             CAST(COALESCE(t.mdd_check_date, s.mdd_check_date) AS varchar) AS mdd_check_date,
#             COALESCE(s.FN1, 0) AS FN1,
#             COALESCE(s.FN2, 0) AS FN2,
#             COALESCE(s.FN3, 0) AS FN3,
#             COALESCE(t.TD1, 0) AS TD1,
#             COALESCE(t.TD2, 0) AS TD2,
#             COALESCE(t.TD3, 0) AS TD3
#             FROM mytab4 t
#             FULL OUTER JOIN mytable6 s
#             ON t.mdd_check_date = s.mdd_check_date
            
#             UNION ALL
            
            
#             SELECT 
#             'TOTAL' AS mdd_check_date,
#             SUM(COALESCE(s.FN1, 0)) AS FN1,
#             SUM(COALESCE(s.FN2, 0)) AS FN2,
#             SUM(COALESCE(s.FN3, 0)) AS FN3,
#             SUM(COALESCE(t.TD1, 0)) AS TD1,
#             SUM(COALESCE(t.TD2, 0)) AS TD2,
#             SUM(COALESCE(t.TD3, 0)) AS TD3
#             FROM mytab4 t
#             FULL OUTER JOIN mytable6 s
#             ON t.mdd_check_date = s.mdd_check_date
            
#             ORDER BY 
#             CASE WHEN mdd_check_date = 'TOTAL' THEN 1 ELSE 0 END,
#             mdd_check_date
#     """

            

tdfn_fnir ="""
        WITH mytab AS(
            SELECT reference_code as ref_code, candidate_ref_code as cand_ref_code, creation_date as mdd_check_date
            FROM flink_stream.stream_enu.abis_candidate_match_analysis_v1 
            WHERE MONTH(creation_date) = MONTH(DATE_TRUNC('month', CURRENT_DATE) - INTERVAL '1' DAY)
            AND YEAR(creation_date) = YEAR(DATE_TRUNC('month', CURRENT_DATE) - INTERVAL '1' DAY)
            AND true_duplicate=1 
        ),
        mytab1 AS(
            SELECT ref_code, mdd_check_date
            FROM(
                SELECT ref_code,mdd_check_date,
                ROW_NUMBER() OVER(
                    PARTITION BY ref_code ORDER BY mdd_check_date
                ) as rn
                FROM mytab
                ) sub
            WHERE rn = 1
        ),
        mytab2 AS(
            SELECT t.ref_code as ref_code, s.abis_code as abis_code,
            t.mdd_check_date as mdd_check_date
            FROM mytab1 t JOIN flink_stream.stream_enu.abis_request_tracker_union_v1 s ON t.ref_code=s.reference_code
            WHERE s.request_type='IDENTIFY' AND s.status='DEDUP_FAILURE'
        ),
        mytab3 AS(
            SELECT ref_code,abis_code,mdd_check_date
            FROM ( SELECT ref_code,abis_code,mdd_check_date,
                    ROW_NUMBER() OVER ( PARTITION BY ref_code,abis_code ORDER BY mdd_check_date) as rn 
                    FROM mytab2
                    ) sub
            WHERE rn=1
        ),
        mytab4 AS(
            SELECT DATE(mdd_check_date) as mdd_check_date,
            COUNT_IF(abis_code='ABIS1') AS TD1,
            COUNT_IF(abis_code='ABIS2') AS TD2,
            COUNT_IF(abis_code='ABIS3') As TD3
            FROM mytab3
            GROUP BY 1
            ORDER BY 1
        ),
        mytable AS(
            select distinct edata_refid
            from flink_stream.stream_enu.enu_globalprocessaudit
            where enrolmenttype = 'N' AND date(ets) >= date_add('month' , -6, date_trunc('month', current_date))
        ),
        mytable2 AS(
            SELECT t.ref_code as ref_code, t.cand_ref_code as cand_ref_code,
            t.mdd_check_date as mdd_check_date
            FROM mytab t
            JOIN mytable v ON t.ref_code=v.edata_refid
        ),
        mytable3 AS(
            SELECT t.ref_code as ref_code, t.cand_ref_code as cand_ref_code, s.abis_code as abis_code, s.status as status,
            t.mdd_check_date as mdd_check_date, MAX(s.last_updated_date) as applicant_identify_last_updated_date
            FROM mytable2 t JOIN flink_stream.stream_enu.abis_request_tracker_union_v1 s ON t.ref_code=s.reference_code
            WHERE s.request_type='IDENTIFY' AND s.status='DEDUP_SUCCESS'
            GROUP BY 1,2,3,4,5
        ),
        mytable4 AS(
            SELECT t.ref_code as ref_code, t.cand_ref_code as cand_ref_code, t.abis_code as abis_code, t.status as status,
            t.applicant_identify_last_updated_date as applicant_identify_last_updated_date, t.mdd_check_date as mdd_check_date,
            MIN(s.last_updated_date) as cand_insert_last_updated_date
            FROM mytable3 t JOIN flink_stream.stream_enu.abis_request_tracker_union_v1 s ON t.cand_ref_code=s.reference_code AND t.abis_code=s.abis_code
            WHERE s.request_type='INSERT' AND s.status='INSERT_SUCCESS'
            GROUP BY 1,2,3,4,5,6
        ),
        mytable5 AS(

            SELECT ref_code,cand_ref_code,abis_code,status,applicant_identify_last_updated_date,cand_insert_last_updated_date,mdd_check_date
            FROM (
                SELECT ref_code, cand_ref_code, abis_code, status,
                    applicant_identify_last_updated_date, cand_insert_last_updated_date, mdd_check_date,
                    ROW_NUMBER() OVER (
                        PARTITION BY ref_code, abis_code
                        ORDER BY cand_insert_last_updated_date
                    ) AS rn
                FROM mytable4
                WHERE applicant_identify_last_updated_date > cand_insert_last_updated_date
            ) sub
            WHERE rn = 1
        ),
        mytable6 AS(
            SELECT DATE(mdd_check_date) as mdd_check_date,
            COUNT_IF(abis_code='ABIS1') AS FN1,
            COUNT_IF(abis_code='ABIS2') AS FN2,
            COUNT_IF(abis_code='ABIS3') As FN3
            FROM mytable5
            GROUP BY 1
            ORDER BY 1
        )
            SELECT 
            CAST(COALESCE(t.mdd_check_date, s.mdd_check_date) AS varchar) AS mdd_check_date,
            COALESCE(s.FN1, 0) AS FN1,
            COALESCE(s.FN2, 0) AS FN2,
            COALESCE(s.FN3, 0) AS FN3,
            COALESCE(t.TD1, 0) AS TD1,
            COALESCE(t.TD2, 0) AS TD2,
            COALESCE(t.TD3, 0) AS TD3
            FROM mytab4 t
            FULL OUTER JOIN mytable6 s
            ON t.mdd_check_date = s.mdd_check_date
            
            UNION ALL
            
            
            SELECT 
            'TOTAL' AS mdd_check_date,
            SUM(COALESCE(s.FN1, 0)) AS FN1,
            SUM(COALESCE(s.FN2, 0)) AS FN2,
            SUM(COALESCE(s.FN3, 0)) AS FN3,
            SUM(COALESCE(t.TD1, 0)) AS TD1,
            SUM(COALESCE(t.TD2, 0)) AS TD2,
            SUM(COALESCE(t.TD3, 0)) AS TD3
            FROM mytab4 t
            FULL OUTER JOIN mytable6 s
            ON t.mdd_check_date = s.mdd_check_date
            
            ORDER BY 
            CASE WHEN mdd_check_date = 'TOTAL' THEN 1 ELSE 0 END,
            mdd_check_date
    """

def previous_month():
    today = datetime.date.today()
    first_day_this_month = today.replace(day=1)
    last_day_prev_month = first_day_this_month - datetime.timedelta(days=1)
    return last_day_prev_month.strftime("%B_%Y"), last_day_prev_month.strftime("%B %Y")


def trino(query, host=trino_host, port=trino_port, user=trino_user):
    try:
        conn = connect(
            host=host,
            port=port,
            user=user
        )
        cur = conn.cursor()
        cur.execute(query)
        body = cur.fetchall()
        if not body:
            return {"query": query, "success": 1, "data": body}
        else:
            cols = [i[0] for i in cur.description]
            df = pd.DataFrame(body, columns=cols)
            return {"query": query, "success": 1, "data": (cols, body), "df": df}
    except Exception as e:
        return {"query": query, "success": 0, "msg": str(e)}


def query_to_base64(query):
    query_result = trino(query)
    if query_result["success"]==1 and "df" in query_result and  len(query_result['df'])>1:
        df = query_result['df']
        print(df.shape)
        csv_buffer = StringIO()
        df.to_csv(csv_buffer, index=False)
        encoded_csv = base64.b64encode(csv_buffer.getvalue().encode()).decode('utf-8')
        return encoded_csv
    elif query_result["success"]==1 :
        print("No Rows Returned by the Query!")
        return 1
    else:
        error_msg = query_result.get("msg", "Unknown Trino failure")
        print("Trino query might have failed! Error:", error_msg)
        raise RuntimeError(f"Trino query failed: {error_msg}")


def send_email_team(email, additional_info):
    url = f'http://{rcs_host}:{rcs_port}/messageReceiver/v1'
    
    payload = json.dumps({

    "residentId": "720447260190",
    "appName": "STROT",
    "idType": "uid",
    "event": "STROT_REPORT",
    "mobile": "8540864693",
    "email": email,
    "channel": [
        {
            "language": "23",
            "channel": "EMAIL"
        }

    ],
    "additionalInfo": additional_info
    })

    headers = {'content-type': 'application/json', 'Accept-Charset': 'UTF-8'}
    response = requests.post(url, data=payload, headers=headers)
    return response,email

def send_kafka_message(email, additional_info):
    try:
        message = {
            "residentId": "720447260190",
            "appName": "STROT",
            "idType": "uid",
            "event": "STROT_REPORT",
            "mobile": "8540864693",
            "email": email,
            "channel": [
                {
                    "language": "23",
                    "channel": "EMAIL"
                }
            ],
            "additionalInfo": additional_info
        }

        producer = KafkaProducer(
            bootstrap_servers=bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode("utf-8")
        )
        producer.send(topic, message)
        producer.flush()
        logging.info(f"Sent Kafka message to topic '{topic}' : {message}")
        producer.close()
    except Exception as e:
        logging.error(f"Error sending Kafka message: {e}", exc_info=True)
        raise

def trigger_email(query, email_list):
   
    encoded_csv = query_to_base64(query)
    date1, date2 = previous_month()
    html_content1 = f"<p>Please Find Attached the CSV File Containing True Duplicate and False Negative Counts per BSP For the Month of {date2}.<p>"
    html_content2 = f"<p>No Data Found. Data Sync Issues!</p>"
    file_name = f"td_fn_counts_{date1}.csv"
    emailSubject= f"FNIR: BSPs TD and FN Counts Report For {date2}"
    if encoded_csv != 1:
        additional_info = {
                "HTML_CONTENT": html_content1,
                "TITLE":" ",
                "RECEIVER": "Team",
                "emailSubject": emailSubject,
                "cc": cc,
            }

        if encoded_csv and isinstance(encoded_csv, str) and encoded_csv != 0:
            additional_info["attachment"] = encoded_csv
            additional_info["fileName"] = file_name
            for email in email_list:
                send_kafka_message(email, additional_info)
                print(f"Email sent to {email}")
                print(f"CC: {cc}")
                # response, email = send_email_team(email, additional_info)
                # if(response.status_code==200):
                #     print(f"Email sent to {email}: {response.status_code}, {response}")
                #     print(f"cc : {cc}")
                # else:
                #     print(email,response.status_code)
        else:
            print("Query failed — Trino query did not return data or failed to execute.")
            raise RuntimeError("Trino query failed — encoded_csv is 0. DAG will now fail to trigger alert.")
    else:
        print("No Data!")
        additional_info = {
                "HTML_CONTENT": html_content2,
                "TITLE":" ",
                "RECEIVER": "Team",
                "emailSubject": emailSubject,
                "cc": "app.developer-tc@uidai.net.in",
            }
        response, email = send_email_team("techexe15.yp25@uidai.net.in", additional_info)
        if(response.status_code==200):
            print(f"Email sent to {email}: {response.status_code}, {response}")
            print(f"cc : {cc}")
        else:
            print(email,response.status_code)


default_args = {
    'owner': 'inzamam',
    'depends_on_past': False,
    'start_date': datetime.datetime(2025,10,3),
    'email': ["techexe15.yp25@uidai.net.in","techexecutive22-yp23@uidai.net.in","techexecutive14-yp23@uidai.net.in"],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 1
}

dag= DAG(
    'reporting_td_fn_count_monthly',
    default_args=default_args,
    description="Dag to send TD and FN counts to the Team",
    schedule="30 6 7 * *",
    catchup=False,
    tags=["Reporting","TD","FN","FNIR"]
)

task_fnir_td_fn_monthly=PythonOperator(
    task_id='fetch_td_fn_monthly_report',
    python_callable=trigger_email,
    op_kwargs={'query': tdfn_fnir,'email_list': mail_list},
    trigger_rule='all_done',
    dag=dag,
)

task_fnir_td_fn_monthly
