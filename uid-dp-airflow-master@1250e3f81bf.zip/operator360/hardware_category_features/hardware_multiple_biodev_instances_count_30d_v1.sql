INSERT INTO {destination_table} 
WITH tab1 AS (
    SELECT
        entity_id,
        SUM(feature_value) AS feature_value,
        ARRAY_DISTINCT(
            FILTER(
                FLATTEN(
                    ARRAY_AGG(
                        SPLIT(COALESCE(comments, ''), ',')
                    )
                ),
                x -> x <> ''
            )
        ) AS fraud_machines,
        COUNT(*) AS count_of_machine_frauds
    FROM strot.operator360.features_hardware_v1
    WHERE CAST(timestamp AS date) >= CAST('{min_pkt_date}' AS date)
      AND CAST(timestamp AS date) < CAST('{max_pkt_date}' AS date)
      AND feature_id = 'hardware_multiple_biodev_instances_24h_v2'
    GROUP BY entity_id
)

SELECT
    entity_id,
    '{FEATURE_NAME}_v{FEATURE_VERSION}' AS feature_id,
    '{FEATURE_NAME}' AS feature_name,
    '{FEATURE_VERSION}' AS feature_version,
    feature_value,
    current_timestamp AS timestamp,
    'fraud_machines: ' 
        || array_join(fraud_machines, ',') 
        || ',number of packets: ' 
        || cast(count_of_machine_frauds AS varchar) AS comments
FROM tab1
WHERE feature_value > 0