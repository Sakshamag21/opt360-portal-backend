WITH tab1 AS (
    -- Find user_uids that have multiple user_codes AND more than one active user_code
    SELECT user_uid
    FROM mysql_uidmasterv1.uidmasterv1_1.user
    WHERE user_code IS NOT NULL
      AND user_code != ''
    GROUP BY user_uid
    HAVING COUNT(DISTINCT user_code) > 1
       AND COUNT(DISTINCT CASE WHEN user_status = '1' THEN user_code END) > 1
),
tab2 AS (
    -- Get active users and their previous state using LAG window functions
    SELECT
        user_uid,
        user_code,
        prev_user_code,
        CAST(last_updated_date AS TIMESTAMP) AS last_updated_date,
        prev_last_updated_date,
        inactive_reason_key,
        prev_inactive_reason_key,
        user_reg_org_key,
        prev_user_reg_org_key,
        user_status,
        prev_user_status,
        creation_date
    FROM (
        SELECT
            user_uid,
            user_code,
            LAG(user_code) OVER (PARTITION BY user_uid ORDER BY CAST(last_updated_date AS TIMESTAMP)) AS prev_user_code,
            CAST(last_updated_date AS TIMESTAMP) AS last_updated_date,
            LAG(CAST(last_updated_date AS TIMESTAMP)) OVER (PARTITION BY user_uid ORDER BY CAST(last_updated_date AS TIMESTAMP)) AS prev_last_updated_date,
            user_status,
            creation_date,
            LAG(user_status) OVER (PARTITION BY user_uid ORDER BY CAST(last_updated_date AS TIMESTAMP)) AS prev_user_status,
            inactive_reason_key,
            user_reg_org_key,
            LAG(inactive_reason_key) OVER (PARTITION BY user_uid ORDER BY CAST(last_updated_date AS TIMESTAMP)) AS prev_inactive_reason_key,
            LAG(user_reg_org_key) OVER (PARTITION BY user_uid ORDER BY CAST(last_updated_date AS TIMESTAMP)) AS prev_user_reg_org_key
        FROM mysql_uidmasterv1.uidmasterv1_1.user
        WHERE user_code IS NOT NULL
          AND user_code != ''
    ) t
    WHERE user_status = '1'
      AND user_uid IN (SELECT user_uid FROM tab1) -- Filter early for performance
),
tab3 AS (
    -- Join with risk scores for current and previous user_codes
    SELECT
        t2.*,
        curr_rs.risk_score AS risk_score,
        prev_rs.risk_score AS prev_risk_score
    FROM tab2 t2
    LEFT JOIN LATERAL (
        SELECT MAX(CAST(feature_value AS DOUBLE)) AS risk_score
        FROM strot.operator360.features_risk_v1
        WHERE feature_id LIKE '%risk_score%'
          AND entity_id = t2.user_code
          AND date("timestamp") >= date('2026-01-01')
          AND date("timestamp") <= current_date
          AND CAST("timestamp" AS TIMESTAMP) <= t2.prev_last_updated_date
    ) curr_rs ON TRUE
    LEFT JOIN LATERAL (
        SELECT MAX(CAST(feature_value AS DOUBLE)) AS risk_score
        FROM strot.operator360.features_risk_v1
        WHERE feature_id LIKE '%risk_score%'
          AND entity_id = t2.prev_user_code
          AND date("timestamp") >= date('2026-01-01')
          AND date("timestamp") <= current_date
          AND CAST("timestamp" AS TIMESTAMP) <= t2.prev_last_updated_date
    ) prev_rs ON TRUE
    WHERE t2.prev_user_status IS NOT NULL
      AND date(t2.creation_date) = date(current_date - interval '1' day) -- Look for records created exactly yesterday
)
-- Show all necessary data for these flagged users
SELECT
    user_uid,
    user_code,
    prev_user_code,
    user_status,
    prev_user_status,
    CAST(creation_date AS VARCHAR) AS creation_date,
    CAST(last_updated_date AS VARCHAR) AS last_updated_date,
    CAST(prev_last_updated_date AS VARCHAR) AS prev_last_updated_date,
    inactive_reason_key,
    prev_inactive_reason_key,
    user_reg_org_key,
    prev_user_reg_org_key,
    risk_score,
    prev_risk_score
FROM tab3
WHERE user_reg_org_key != prev_user_reg_org_key
  AND prev_risk_score > 0.7
ORDER BY user_uid, last_updated_date
