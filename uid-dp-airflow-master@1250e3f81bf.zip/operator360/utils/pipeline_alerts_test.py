import logging
import smtplib
import os
import json
import time
import boto3
import requests
import urllib3
import traceback
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
from collections import defaultdict
from datetime import datetime, timezone

# Disable SSL warnings since we are adding verify=False to bypass corporate proxy inspection
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

# --- Email Configuration ---
SMTP_HOST = "10.10.20.80"
SMTP_PORT = 25
SENDER_EMAIL = "airflow@uidai.net.in"
ALERT_RECIPIENTS = ["techexe11.yp26@uidai.net.in"]

# --- Zoho Cliq Configuration ---
ZOHO_CLIQ_WEBHOOK_URL = "https://chat.uidai.gov.in/api/v2/bots/optnotifications/incoming?zapikey=1001.cb6c531ed8e5dfa2d79138ea6f227a11.fde5bcd85bf984e4b5c34bd0383106b9&channel=dataplatformtesting&dc=hdc"

# --- Network Proxy Configuration ---
PROXY_URL = "http://10.10.16.28:3128"
PROXIES = {"http": PROXY_URL, "https": PROXY_URL}

# --- Ceph S3 Configuration ---
CEPH_ENDPOINT_URL = "http://10.10.103.12:425"
CEPH_ACCESS_KEY = "9S0KLIQO7T2XCNGH4P4A"
CEPH_SECRET_KEY = "XKlE3EeEQ7MHsvz2O9AXuDEJJDyTFhhCcxSnxtk4"
CEPH_BUCKET_NAME = "prd-bi-data-platform-test"
CEPH_CACHE_PREFIX = "cache/airflow/operator360"

# FIX: Define the actual Airflow IP to replace localhost in log links
AIRFLOW_BASE_IP = "10.10.118.36"

def _get_s3_client():
    return boto3.client('s3', endpoint_url=CEPH_ENDPOINT_URL, aws_access_key_id=CEPH_ACCESS_KEY, aws_secret_access_key=CEPH_SECRET_KEY)

def _get_today_error_queue_key():
    today_str = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    return f"{CEPH_CACHE_PREFIX}/error_queue/{today_str}_errors.json"

def _send_cliq_payload(payload: dict):
    """Centralized, robust function to send payloads to Zoho Cliq."""
    # 1. Clear proxy environment variables that Airflow might have set globally
    os.environ.pop("HTTP_PROXY", None)
    os.environ.pop("http_proxy", None)
    os.environ.pop("HTTPS_PROXY", None)
    os.environ.pop("https_proxy", None)
    
    try:
        # 2. Use explicit proxies, verify=False (bypasses corporate SSL inspection), and timeout
        response = requests.post(ZOHO_CLIQ_WEBHOOK_URL, data=payload, proxies=PROXIES, timeout=10, verify=False)
        if response.status_code != 200:
            logger.error(f"Zoho Cliq alert failed. Status: {response.status_code}, Response: {response.text}")
        else:
            logger.info("Zoho Cliq alert sent successfully.")
    except Exception as e:
        # FIX: Added traceback so we can see the EXACT error in Airflow logs if it fails
        logger.error(f"Failed to send Zoho Cliq alert: {e}\n{traceback.format_exc()}")

def log_error_to_s3(feature_name: str, error_type: str, error_details: str, log_url: str = None):
    s3_client = _get_s3_client()
    s3_key = _get_today_error_queue_key()
    
    error_payload = {
        "feature_name": feature_name,
        "error_type": error_type,
        "error_details": error_details,
        "log_url": log_url,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    
    try:
        existing_data = []
        try:
            response = s3_client.get_object(Bucket=CEPH_BUCKET_NAME, Key=s3_key)
            content = response['Body'].read().decode('utf-8')
            existing_data = json.loads(content)
            if not isinstance(existing_data, list):
                existing_data = [existing_data]
        except s3_client.exceptions.NoSuchKey:
            existing_data = []
        except Exception as read_err:
            logger.error(f"Could not read existing error queue. Overwriting. Error: {read_err}")
            existing_data = []

        existing_data.append(error_payload)
        
        s3_client.put_object(
            Bucket=CEPH_BUCKET_NAME,
            Key=s3_key,
            Body=json.dumps(existing_data, indent=4, default=str),
            ContentType='application/json'
        )
        logger.info(f"Error logged to S3 queue: s3://{CEPH_BUCKET_NAME}/{s3_key}")
    except Exception as e:
        logger.error(f"Failed to log error to S3: {e}")
        # Fallback to immediate alerts if S3 fails completely
        subject = f"{error_type} - Feature: {feature_name}"
        send_pipeline_alert(subject, error_details)
        send_zoho_cliq_alert(subject, error_details)

def process_and_send_consolidated_alerts():
    s3_client = _get_s3_client()
    s3_key = _get_today_error_queue_key()
    
    try:
        response = s3_client.get_object(Bucket=CEPH_BUCKET_NAME, Key=s3_key)
        content = response['Body'].read().decode('utf-8')
        errors = json.loads(content)
        
        if not errors:
            logger.info("No errors found in the S3 queue. No consolidated alert sent.")
            return
            
        grouped_errors = defaultdict(list)
        
        for error_data in errors:
            error_type = error_data.get("error_type", "Unknown Error")
            feature_name = error_data.get("feature_name", "Unknown Feature")
            error_details = error_data.get("error_details", "")
            log_url = error_data.get("log_url", "")
            grouped_errors[error_type].append({"feature": feature_name, "details": error_details, "log_url": log_url})
            
        html_body = "<html><body style='font-family: Arial, sans-serif; color: #333;'>"
        html_body += "<h2 style='color: #d9534f;'>Consolidated Pipeline Alert</h2>"
        html_body += f"<p>The following {len(errors)} features failed during the recent pipeline run:</p><hr>"
        
        for error_type, features in grouped_errors.items():
            html_body += f"<h3 style='color: #333;'>⚠️ {error_type} ({len(features)} features affected)</h3>"
            html_body += "<ul>"
            for item in features:
                short_details = item['details'][:500] + "..." if len(item['details']) > 500 else item['details']
                log_html = f" (<a href='{item['log_url']}'>View Logs</a>)" if item.get('log_url') else ""
                html_body += f"<li><strong>{item['feature']}</strong>{log_html}<br><pre style='font-size: 12px; background: #f9f9f9; padding: 5px;'>{short_details}</pre></li>"
            html_body += "</ul>"
            
        html_body += "<hr><p style='font-size: 12px; color: #888;'>This is an automated consolidated alert.</p></body></html>"
        
        subject = f"Operator360 Pipeline Alert: {len(errors)} Failures Across {len(grouped_errors)} Categories"
        
        # Send Consolidated Email
        msg = MIMEMultipart("alternative")
        msg["From"] = SENDER_EMAIL
        msg["To"] = ", ".join(ALERT_RECIPIENTS)
        msg["Subject"] = subject
        msg.attach(MIMEText(html_body, "html"))
        
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(SENDER_EMAIL, ALERT_RECIPIENTS, msg.as_string())
        server.quit()
        logger.info(f"Consolidated alert email sent for {len(errors)} errors.")
        
        # FIX: Send a concise Zoho Cliq alert to avoid hitting character limits
        # FIX: Send Zoho Cliq alert with ONLY Feature Name and Log URL beside it
        cliq_text = f"🚨 *Consolidated Pipeline Alert*\n{len(errors)} Failures Across {len(grouped_errors)} Categories.\n\n"
        for error_type, features in grouped_errors.items():
            cliq_text += f"*{error_type}* ({len(features)} features):\n"
            for item in features:
                log_url = item.get('log_url', '')
                if log_url:
                    # Puts the feature name and the raw log URL right beside it
                    cliq_text += f"  - {item['feature']} - {log_url}\n"
                else:
                    cliq_text += f"  - {item['feature']}\n"
            cliq_text += "\n"
            
        cliq_payload = {"text": cliq_text}
        _send_cliq_payload(cliq_payload)

        # Clear the S3 queue
        s3_client.delete_object(Bucket=CEPH_BUCKET_NAME, Key=s3_key)
        logger.info("S3 error queue cleared successfully.")
        
    except s3_client.exceptions.NoSuchKey:
        logger.info("No errors found in the S3 queue (File does not exist). No consolidated alert sent.")
    except Exception as e:
        logger.error(f"Failed to process consolidated alerts: {e}\n{traceback.format_exc()}")

def send_zoho_cliq_alert(subject: str, body: str):
    """Sends an immediate alert to Zoho Cliq (used only if S3 logging fails)."""
    html_body_for_cliq = f"<h2>Pipeline Alert: {subject}</h2><p>An issue was detected.</p><hr><pre>{body}</pre>"
    payload = {"text": html_body_for_cliq}
    _send_cliq_payload(payload)

def send_pipeline_alert(subject: str, body: str):
    """Sends an immediate HTML email (used only if S3 logging fails)."""
    msg = MIMEMultipart("alternative")
    msg["From"] = SENDER_EMAIL
    msg["To"] = ", ".join(ALERT_RECIPIENTS)
    msg["Subject"] = f"[Operator360 Pipeline Alert] {subject}"
    html_content = f"<html><body><h2>Pipeline Alert: {subject}</h2><pre>{body}</pre></body></html>"
    msg.attach(MIMEText(html_content, "html"))
    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60)
        server.sendmail(SENDER_EMAIL, ALERT_RECIPIENTS, msg.as_string())
        server.quit()
    except Exception as e:
        logger.error(f"Failed to send alert email: {e}")

def notify_failure(feature_name: str, error_type: str, error_details: str, log_url: str = None):
    # FIX: Replace localhost with the actual Airflow Server IP so links work in emails
    if log_url:
        log_url = log_url.replace("localhost", AIRFLOW_BASE_IP)
        
    subject = f"{error_type} - Feature: {feature_name}"
    if error_type == "Raw Data Missing":
        body = f"Raw data is missing for feature '{feature_name}'.\n\nDetails:\n{error_details}"
    elif error_type == "Query Timeout":
        body = f"Query for feature '{feature_name}' exceeded the 30-minute timeout limit.\n\nDetails:\n{error_details}"
    elif error_type == "Trino Node Failure":
        body = f"Trino connection or execution failed for feature '{feature_name}'.\n\nDetails:\n{error_details}"
    else:
        body = f"An unhandled error occurred for feature '{feature_name}'.\n\nDetails:\n{error_details}"
        
    log_error_to_s3(feature_name, error_type, body, log_url)

def execute_trino_with_timeout(trino_func, query: str, feature_name: str, timeout_seconds: int = 1800, log_url: str = None):
    # FIX: Also replace localhost here so immediate fallback alerts have the correct IP
    if log_url:
        log_url = log_url.replace("localhost", AIRFLOW_BASE_IP)
        
    try:
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(trino_func, query)
            result = future.result(timeout=timeout_seconds)
            if isinstance(result, dict) and result.get("success") == 0:
                err_msg = result.get("msg", "Unknown Trino error")
                if "Connection refused" in err_msg or "node" in err_msg.lower() or "memory" in err_msg.lower():
                    notify_failure(feature_name, "Trino Node Failure", err_msg, log_url)
                else:
                    notify_failure(feature_name, "Query Execution Error", err_msg, log_url)
                raise RuntimeError(f"Trino query failed: {err_msg}")
            return result
    except FutureTimeoutError:
        error_msg = f"Query took longer than {timeout_seconds} seconds (30 minutes) and was aborted.\nQuery: {query}"
        notify_failure(feature_name, "Query Timeout", error_msg, log_url)
        raise RuntimeError(error_msg)
    except Exception as e:
        error_msg = f"Unexpected error during query execution: {str(e)}\n{traceback.format_exc()}"
        notify_failure(feature_name, "Unexpected Error", error_msg, log_url)
        raise