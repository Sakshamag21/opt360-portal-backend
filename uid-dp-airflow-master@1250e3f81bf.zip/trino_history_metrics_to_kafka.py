import logging
from datetime import datetime, timedelta, timezone
import json
import uuid
import time
from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator
from trino.dbapi import connect
from kafka import KafkaProducer
from strot_alert_notification import (
    alert_failure_callback,
    alert_success_callback,
    alert_retry_callback,
    configure
)
# Define Timezones
IST = timezone(timedelta(hours=5, minutes=30))
UTC = timezone.utc
configure(channel="dataplatformtesting")
# Configuration
TRINO_HOST = '10.10.116.75'
TRINO_USER = 'airflow_collector'
ICEBERG_TABLE = 'strot.analytics_services.trino_query_history'

KAFKA_BROKER = ['10.10.105.225:9092','10.10.106.171:9092','10.10.107.110:9092','10.10.105.75:9092']
KAFKA_TOPIC = 'TRINO.QUERY.HISTORY.METRICS.V1'

log = logging.getLogger(__name__)



def convert_to_ist_str(utc_dt):
    """Converts a naive UTC datetime to an IST string without timezone offset."""
    if not utc_dt:
        return None
    # Trino returns naive timestamps, so we tell Python it's UTC
    utc_aware = utc_dt.replace(tzinfo=UTC)
    ist_aware = utc_aware.astimezone(IST)
    # Return as '2026-09-15 18:30:00' (no +05:30 suffix to keep ClickHouse happy)
    return ist_aware.strftime('%Y-%m-%d %H:%M:%S')



def trino_query(query):
    """Helper to execute Trino query and return rows"""
    conn = connect(host=TRINO_HOST, port=8080, user=TRINO_USER)
    cur = conn.cursor()
    cur.execute(query)
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows

def aggregate_and_push_to_kafka(**kwargs):
    producer = KafkaProducer(
        bootstrap_servers=KAFKA_BROKER,
        value_serializer=lambda v: json.dumps(v).encode('utf-8'),
        key_serializer=lambda k: k.encode('utf-8'),
        acks='all'
    )

    # Calculate 3 hours ago in UTC strictly in Python to avoid Trino timezone mismatches
    utc_now = datetime.now(UTC)
    three_hours_ago_utc = utc_now - timedelta(hours=3)
    # Format as string for Trino: '2026-09-15 12:30:00'
    time_str = three_hours_ago_utc.strftime('%Y-%m-%d %H:%M:%S')
    
    # Pass the literal UTC timestamp to Trino
    time_filter = f"created > timestamp '{time_str}'"
    log.info(f"Querying Iceberg with UTC filter: {time_filter}")
    
    # ==========================================
    # 1. Total Minutes by User and Host
    # ==========================================
    q1 = f"""
        SELECT date_trunc('hour', created) AS hr, "user", host,
               (sum(date_diff('millisecond', created, "end")) / 60000.0) AS val
        FROM {ICEBERG_TABLE}
        WHERE state = 'FINISHED' AND {time_filter}
        GROUP BY 1, 2, 3
    """
    q1_rows = trino_query(q1)
    log.info(f"Q1 returned {len(q1_rows)} rows.")
    for row in q1_rows:
        hr, user, host, val = row
        msg = {
            "eventId": str(uuid.uuid4()),
            "metric_name": "user_total_minutes",
            "host": host,
            "dim1": user,
            "dim2": "",
            "value": float(val) if val is not None else 0.0,
            "query_hour": convert_to_ist_str(hr),
            "eventTimestamp": int(time.time())
        }
        producer.send(KAFKA_TOPIC, key=f"user_total_minutes_{host}_{user}_{hr}", value=msg)

    # ==========================================
    # 2. Query Count by Client Source and Host
    # ==========================================
    q2 = f"""
        SELECT date_trunc('hour', created) AS hr, coalesce(source, 'Unknown Tool') AS src, host, count(query_id) AS val
        FROM {ICEBERG_TABLE}
        WHERE {time_filter}
        GROUP BY 1, 2, 3
    """
    q2_rows = trino_query(q2)
    log.info(f"Q2 returned {len(q2_rows)} rows.")
    for row in q2_rows:
        hr, src, host, val = row
        msg = {
            "eventId": str(uuid.uuid4()),
            "metric_name": "source_query_count",
            "host": host,
            "dim1": src,
            "dim2": "",
            "value": float(val) if val is not None else 0.0,
            "query_hour": convert_to_ist_str(hr),
            "eventTimestamp": int(time.time())
        }
        producer.send(KAFKA_TOPIC, key=f"source_query_count_{host}_{src}_{hr}", value=msg)

    # ==========================================
    # 3. Phases (Queued, Analysis, Planning, Execution)
    # ==========================================
    q3 = f"""
        SELECT date_trunc('hour', created) AS hr, 'Queued' AS phase, host, sum(queued_time_ms)/1000.0 AS val
        FROM {ICEBERG_TABLE} WHERE {time_filter} GROUP BY 1, 2, 3
        UNION ALL
        SELECT date_trunc('hour', created) AS hr, 'Analysis' AS phase, host, sum(analysis_time_ms)/1000.0 AS val
        FROM {ICEBERG_TABLE} WHERE {time_filter} GROUP BY 1, 2, 3
        UNION ALL
        SELECT date_trunc('hour', created) AS hr, 'Planning' AS phase, host, sum(planning_time_ms)/1000.0 AS val
        FROM {ICEBERG_TABLE} WHERE {time_filter} GROUP BY 1, 2, 3
        UNION ALL
        SELECT date_trunc('hour', created) AS hr, 'Execution' AS phase, host,
               (sum(date_diff('millisecond', created, "end")) - sum(queued_time_ms) - sum(analysis_time_ms) - sum(planning_time_ms))/1000.0 AS val
        FROM {ICEBERG_TABLE} WHERE {time_filter} GROUP BY 1, 2, 3
    """
    q3_rows = trino_query(q3)
    log.info(f"Q3 returned {len(q3_rows)} rows.")
    for row in q3_rows:
        hr, phase, host, val = row
        msg = {
            "eventId": str(uuid.uuid4()),
            "metric_name": "phase_total_seconds",
            "host": host,
            "dim1": phase,
            "dim2": "",
            "value": float(val) if val is not None else 0.0,
            "query_hour": convert_to_ist_str(hr),
            "eventTimestamp": int(time.time())
        }
        producer.send(KAFKA_TOPIC, key=f"phase_total_seconds_{host}_{phase}_{hr}", value=msg)

    # ==========================================
    # 4. Queue Status Counts
    # ==========================================
    q4 = f"""
        SELECT date_trunc('hour', created) AS hr, host,
               CASE WHEN queued_time_ms > 0 THEN 'Waited in Queue' ELSE 'Ran Immediately' END AS q_status,
               count(query_id) AS val
        FROM {ICEBERG_TABLE}
        WHERE {time_filter} AND host IS NOT NULL AND host != ''
        GROUP BY 1, 2, 3
    """
    q4_rows = trino_query(q4)
    log.info(f"Q4 returned {len(q4_rows)} rows.")
    for row in q4_rows:
        hr, host, q_status, val = row
        msg = {
            "eventId": str(uuid.uuid4()),
            "metric_name": "queue_status_count",
            "host": host,
            "dim1": q_status,
            "dim2": "",
            "value": float(val) if val is not None else 0.0,
            "query_hour": convert_to_ist_str(hr),
            "eventTimestamp": int(time.time())
        }
        producer.send(KAFKA_TOPIC, key=f"queue_status_count_{host}_{q_status}_{hr}", value=msg)

    # ==========================================
    # 5. Total Queries per Host
    # ==========================================
    q5 = f"""
        SELECT date_trunc('hour', created) AS hr, host, count(query_id) AS val
        FROM {ICEBERG_TABLE}
        WHERE {time_filter}
        GROUP BY 1, 2
    """
    q5_rows = trino_query(q5)
    log.info(f"Q5 returned {len(q5_rows)} rows.")
    for row in q5_rows:
        hr, host, val = row
        msg = {
            "eventId": str(uuid.uuid4()),
            "metric_name": "host_total_queries",
            "host": host,
            "dim1": "",
            "dim2": "",
            "value": float(val) if val is not None else 0.0,
            "query_hour": convert_to_ist_str(hr),
            "eventTimestamp": int(time.time())
        }
        producer.send(KAFKA_TOPIC, key=f"host_total_queries_{host}_{hr}", value=msg)

    # ==========================================
    # 6. Failure Count by Error Type
    # ==========================================
    q6 = f"""
        SELECT date_trunc('hour', created) AS hr, 
               coalesce(error_type, 'UNKNOWN') || ' (' || coalesce(error_code, 'N/A') || ')' AS err_label, 
               host, count(query_id) AS val
        FROM {ICEBERG_TABLE}
        WHERE state = 'FAILED' AND {time_filter}
        GROUP BY 1, 2, 3
    """
    q6_rows = trino_query(q6)
    log.info(f"Q6 returned {len(q6_rows)} rows.")
    for row in q6_rows:
        hr, err_label, host, val = row
        msg = {
            "eventId": str(uuid.uuid4()),
            "metric_name": "error_failure_count",
            "host": host,
            "dim1": err_label,
            "dim2": "",
            "value": float(val) if val is not None else 0.0,
            "query_hour": convert_to_ist_str(hr),
            "eventTimestamp": int(time.time())
        }
        producer.send(KAFKA_TOPIC, key=f"error_failure_count_{host}_{err_label}_{hr}", value=msg)

    # ==========================================
    # 9. Queries per Hour by Host and State
    # ==========================================
    q9 = f"""
        SELECT date_trunc('hour', created) AS hr, host, state, count(query_id) AS val
        FROM {ICEBERG_TABLE}
        WHERE state IN ('FINISHED', 'FAILED') AND {time_filter}
        GROUP BY 1, 2, 3
    """
    q9_rows = trino_query(q9)
    log.info(f"Q9 returned {len(q9_rows)} rows.")
    for row in q9_rows:
        hr, host, state, val = row
        msg = {
            "eventId": str(uuid.uuid4()),
            "metric_name": "host_state_hourly_count",
            "host": host,
            "dim1": state,
            "dim2": "",
            "value": float(val) if val is not None else 0.0,
            "query_hour": convert_to_ist_str(hr),
            "eventTimestamp": int(time.time())
        }
        producer.send(KAFKA_TOPIC, key=f"host_state_hourly_count_{host}_{state}_{hr}", value=msg)

    producer.flush()
    producer.close()
    log.info("All aggregated metrics pushed to Kafka successfully.")

default_args = {
    'owner': 'Goverdhan',
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'on_failure_callback': alert_failure_callback,
}

with DAG(
    dag_id='trino_history_aggregator_kafka_v4',
    default_args=default_args,
    description='Aggregates Trino history from Iceberg and pushes metrics to Kafka',
    schedule='*/15 * * * *',  # Every 15 minutes
    start_date=datetime(2026, 9, 14, tzinfo=IST),
    catchup=False,
    max_active_runs=1,
    max_active_tasks=1,
    tags=['trino', 'iceberg', 'kafka', 'clickhouse', 'aggregated'],
) as dag:
    agg_task = PythonOperator(
        task_id='aggregate_and_push_metrics',
        python_callable=aggregate_and_push_to_kafka,
    )
    agg_task  