from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import pandas as pd
import clickhouse_connect
import strot_query as sq
from strot_alert_notification import (
    alert_failure_callback,
    configure
)
# Import your custom SQL engine client here
# from your_module import sq 
configure(channel="dataplatformtesting")
default_args = {
    'owner': 'Goverdhan',
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'on_failure_callback':  alert_failure_callback
}

def transfer_iceberg_to_clickhouse_row_by_row(**kwargs):
    # 1. Calculate dates for past 3 days
    # Airflow's ds is the execution date. If running on 24th, ds is '2026-09-24'
    execution_date = datetime.now()
    
    start_date = execution_date - timedelta(days=3) # 21st
    end_date = execution_date - timedelta(days=1)   # 23rd
    
    start_date_str = start_date.strftime('%Y-%m-%d')
    end_date_str = end_date.strftime('%Y-%m-%d')
    
    print(f"Fetching data from Iceberg for dates: {start_date_str} to {end_date_str}")

    # 2. Define the Iceberg SQL query
    iceberg_query = f"""
    SELECT DISTINCT
        t1.packeteid AS packet_eid,
        t2.packetrefid AS packet_ref_id,
        t1.qa_vendorid AS qa_vendor_id,
        t1.qa_error_code AS qa_error_code,
        t1.qa_error_category AS qa_error_category,
        t1.qc_vendorid AS qc_vendor_id,
        t1.qc_errorcode AS qc_error_code,
        t1.qc_error_category AS qc_error_category,
        t1.check_date AS check_on_date,
        t2.packetlanguage AS language
    FROM
        strot.operator360.qc_error_audit_mismatch_report_v1 t1
    LEFT JOIN
        flink_stream.stream_qc.qc_operator_disposition t2
        ON t1.packeteid = t2.packeteid
    WHERE
        t1.check_date BETWEEN DATE '{start_date_str}' AND DATE '{end_date_str}'
    """
    
    # 3. Execute query on Iceberg
    df = sq.query(iceberg_query)['df']
    
    if df.empty:
        print(f"No data found in Iceberg for dates {start_date_str} to {end_date_str}")
        return

    print(f"Fetched {len(df)} rows from Iceberg. Starting row-by-row insertion into ClickHouse...")

    # 4. Connect to ClickHouse
    client = clickhouse_connect.get_client(
        host='10.10.120.86',
        port='8123',
        username='default',
        password='qwerty'
    )
    
    column_names = df.columns.tolist()
    inserted_count = 0

    # 5. Iterate through the DataFrame row by row
    for index, row in df.iterrows():
        # Convert pandas Series to a list, handling NaN -> None for ClickHouse
        row_data = [None if pd.isna(val) else val for val in row.tolist()]
        
        # Insert a single row. We pass it as a list containing one list (the row)
        client.insert(
            'analytics_qc.qc_error_audit_mismatch', 
            [row_data],                # Data must be a list of lists
            column_names=column_names  # Specify columns to map correctly
        )
        inserted_count += 1
        
    print(f"Successfully inserted {inserted_count} rows row-by-row into ClickHouse.")

# Define the DAG
with DAG(
    dag_id='iceberg_to_clickhouse_qc_error_mismatch_daily',
    default_args=default_args,
    description='Daily row-by-row load of past 3 days QC data from Iceberg to ClickHouse',
    schedule='0 8 * * *',  # Runs daily at 8:00 AM
    start_date=datetime(2026, 9, 24),
    catchup=False, 
    tags=['iceberg', 'clickhouse', 'etl', 'row-by-row'],
) as dag:

    run_transfer = PythonOperator(
        task_id='run_iceberg_to_clickhouse_transfer',
        python_callable=transfer_iceberg_to_clickhouse_row_by_row,
    )