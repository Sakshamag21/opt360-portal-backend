import findspark
findspark.init()
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
import os
import time
from pyspark.sql.functions import col, row_number, date_format,when,struct
from pyspark.sql.window import Window
from pyspark.sql.functions import col, hex, unhex
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
from pyspark.sql.types import IntegerType
from kafka import KafkaProducer, KafkaConsumer
import uuid
import json
import datetime
import pytz

producer_brokers=['10.10.105.225:9092',
                  '10.10.106.171:9092',
                  '10.10.107.110:9092',
                  '10.10.105.75:9092']
output_topic = 'DE.UC.ANALYTICS.AGGREGATION'
# output_topic='testing'

def get_spark(job_name: str):
    spark = SparkSession.builder \
        .appName(f"uc-{job_name}") \
        .remote("sc://spark-connect-service.strot-spark.svc.cluster.local:15002") \
        .config("spark.sql.legacy.mysql.bitArrayMapping.enabled","true") \
        .config("spark.default.parallelism","800") \
        .config("spark.sql.shuffle.partitions", '800') \
        .getOrCreate()
    
    return spark

def message_structure(data):
    ist_tz = pytz.timezone("Asia/Kolkata")
    ist_time = datetime.datetime.now(ist_tz)
    ist_string = ist_time.strftime("%Y-%m-%d %H:%M:%S")
    return {
        "aggregationValue": data.opt_count,
        "windowStartTimestamp": str(datetime.date.today()) + " 00:00:00",
        "aggregationType": "COUNT_DISTINCT",
        "windowDuration": "daily",
        "comments": {},
        "aggregationCount": data.opt_count,
        "windowEndTimestamp": ist_string,
        "publishedTimestamp": ist_string,
        "entityId": data.entity_id,
        "aggregationField": "operator_id",
        "entity": data.entity
    }
    



def send_partition_to_kafka(partition ,producer_brokers= producer_brokers):
    producer = KafkaProducer(bootstrap_servers=producer_brokers, acks=1, retries=2)
    for row in partition:
        output_message= message_structure(row)
        try:
            kafka_key= f"{(row.entity).lower()}:{row.entity_id}".encode('utf-8')
            producer.send(topic=output_topic, 
                          key= kafka_key,
                          value=json.dumps(output_message).encode('utf-8'))
        except Exception as e:
            print(e)
        # break
        


def main():
    
    spark= get_spark('us_distinct_opt_analysis')
    spark_df= spark.sql('''
       select count(distinct operator_id) as opt_count, ea as entity_id  , 'EA' as entity
       from flink_stream.stream_enu.enu_uc_opt_action_v2 
       where date(event_timestamp)=current_date()
       group by ea                 
    ''')
    spark_df.foreachPartition(send_partition_to_kafka)

    spark_df= spark.sql('''
       select count(distinct operator_id) as opt_count, registrar as entity_id  , 'REGISTRAR' as entity
       from flink_stream.stream_enu.enu_uc_opt_action_v2 
       where date(event_timestamp)=current_date()
       group by registrar                
    ''')
    
    spark_df.foreachPartition(send_partition_to_kafka)
        
    spark.sql('''
        WITH tab1 AS (
            SELECT DISTINCT eid, sid, error_type 
            FROM flink_stream.stream_enu.telemetry_uc 
            WHERE ets >= CURRENT_TIMESTAMP() - INTERVAL 1 HOUR
        ),

        tab2 AS (
            SELECT DISTINCT station_machine_code, operator_id, resident_sid, enrolment_type, stage, txn_id 
            FROM flink_stream.stream_enu.enu_uc_opt_action_v2 
            WHERE event_timestamp >= CURRENT_TIMESTAMP() - INTERVAL 1 HOUR
        ),

        tab3 AS (
            SELECT t1.error_type, t2.operator_id, t2.stage, t2.station_machine_code, t2.enrolment_type
            FROM tab2 t2 
            LEFT JOIN tab1 t1 ON t2.txn_id = t1.eid 
        )

        SELECT error_type, COUNT(*) AS opt_count, operator_id AS entity_id, "Operator" AS entity
        FROM tab3 
        WHERE operator_id IS NOT NULL AND operator_id != ''
        GROUP BY error_type, operator_id

        UNION ALL

        SELECT error_type, COUNT(*) AS opt_count, stage AS entity_id, "Stage" AS entity
        FROM tab3 
        WHERE stage IS NOT NULL AND stage != ''
        GROUP BY error_type, stage

        UNION ALL

        SELECT error_type, COUNT(*) AS opt_count, station_machine_code AS entity_id, "Machine ID" AS entity
        FROM tab3 
        WHERE station_machine_code IS NOT NULL AND station_machine_code != ''
        GROUP BY error_type, station_machine_code

        UNION ALL

        SELECT error_type, COUNT(*) AS opt_count, enrolment_type AS entity_id, "Enrolment Type" AS entity
        FROM tab3 
        WHERE enrolment_type IS NOT NULL AND enrolment_type != ''
        GROUP BY error_type, enrolment_type
    ''')
    

main()

