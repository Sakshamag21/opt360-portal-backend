import findspark
findspark.init()
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
import os
import time
from pyspark.sql.functions import col, row_number, date_format,when,struct
from pyspark.sql.window import Window
from pyspark.sql.functions import col, hex, unhex
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
from pyspark.sql.types import IntegerType
from kafka import KafkaProducer, KafkaConsumer
import uuid
import json

producer_brokers=['10.10.105.225:9092',
                  '10.10.106.171:9092',
                  '10.10.107.110:9092',
                  '10.10.105.75:9092']
output_topic = 'DE.UC.TXN.SID.ANALYSIS.V1'
# output_topic='STROT.TEST'

def get_spark(job_name: str):
    spark = SparkSession.builder \
        .appName(f"uc-{job_name}") \
        .remote("sc://spark-connect-service.strot-spark.svc.cluster.local:15002") \
        .config("spark.sql.legacy.mysql.bitArrayMapping.enabled","true") \
        .config("spark.default.parallelism","800") \
        .config("spark.sql.shuffle.partitions", '800') \
        .getOrCreate()
    
    return spark

def message_structure(data):
    # Current system time in epoch seconds
    current_time_epoch = int(time.time())
    return {
        "eventId":str(uuid.uuid4()),
        "entityId":data.operator_id,
        "entity":"OPERATOR",
        "analysisType":"INTER_STAGE_DURATION",
        "sid":data.resident_sid,
        "startFrom":data.stage_from,
        "startTo":data.stage_to,
        "value":"Duration (seconds)",
        "attributeValue": data.time_difference_seconds,
        "analysisWindow":"15min",
        "eventTimestamp": current_time_epoch,
    }



def send_partition_to_kafka(partition ,producer_brokers= producer_brokers):
    producer = KafkaProducer(bootstrap_servers=producer_brokers, acks=1, retries=2)
    for row in partition:
        output_message= message_structure(row)
        try:
            kafka_key= str(row.operator_id).encode('utf-8')
            producer.send(topic=output_topic, 
                          key= kafka_key,
                          value=json.dumps(output_message).encode('utf-8'))
        except Exception as e:
            print(e)
        # break
        


def main():
    
    spark= get_spark('us_step_analysis')
    now = F.current_timestamp()
    start_time = now - F.expr("INTERVAL 30 MINUTES")
    end_time = now - F.expr("INTERVAL 15 MINUTES")
    buffer_end_time = end_time + F.expr("INTERVAL 5 MINUTES")

    filtered_df = spark.table("flink_stream.stream_enu.enu_uc_opt_action_v2") \
        .filter(
            (F.col("event_timestamp") >= start_time) & 
            (F.col("event_timestamp") < buffer_end_time) & # Look 5 mins ahead
            (F.col("operator_id").isNotNull()) & (F.trim(F.col("operator_id")) != "") &
            (F.col("resident_sid").isNotNull()) & (F.trim(F.col("resident_sid")) != "")
        )

    # 4. Generate Consecutive Stages
    sid_window = Window.partitionBy("resident_sid").orderBy("event_timestamp")

    transitions_base_df = filtered_df \
        .withColumn("stage_from", F.col("stage")) \
        .withColumn("stage_from_time", F.col("event_timestamp")) \
        .withColumn("stage_to", F.lead("stage", 1).over(sid_window)) \
        .withColumn("stage_to_time", F.lead("event_timestamp", 1).over(sid_window)) \
        .filter(F.col("stage_to").isNotNull())

    # 5. Guardrail: Drop new transactions born in the buffer zone
    # This keeps your metric scope intact while capturing the trailing edge completions
    valid_transitions_df = transitions_base_df.filter(
        (F.col("stage_from_time") >= start_time) & 
        (F.col("stage_from_time") < end_time)
    )

    # 6. Process Metrics Window
    # operator_transition_window = Window.partitionBy("operator_id", "stage_from", "stage_to")
    print("valid_transitions_df")
    # print(valid_transitions_df.show())
    final_analysis_df = valid_transitions_df.withColumn(
        "time_difference_seconds", 
        F.col("stage_to_time").cast("timestamp").cast("long") - F.col("stage_from_time").cast("timestamp").cast("long")
    ).select(
        "operator_id", "stage_from", "stage_to", "time_difference_seconds","resident_sid"
    )
    
    # print(final_analysis_df.show())

    final_analysis_df= final_analysis_df.dropDuplicates(["operator_id", "resident_sid","stage_from", "stage_to"])
    
    final_analysis_df= final_analysis_df.orderBy("operator_id", "resident_sid","stage_from", "stage_to","time_difference_seconds")
    
    print("final_analysis_df")
    # print(final_analysis_df.show())
    # print("jskdvjsdvkds")
    
    # print(final_analysis_df.show(2))
    final_analysis_df.foreachPartition(send_partition_to_kafka)
        
    

main()

